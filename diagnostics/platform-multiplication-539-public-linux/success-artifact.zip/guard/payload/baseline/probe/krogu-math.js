(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'krogu-math'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'krogu-math'.");
    }
    globalThis['krogu-math'] = factory(typeof globalThis['krogu-math'] === 'undefined' ? {} : globalThis['krogu-math'], globalThis['kotlin-kotlin-stdlib']);
  }
}(function (_, kotlin_kotlin) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var clz32 = Math.clz32;
  var getKClassFromExpression = kotlin_kotlin.$_$.o7;
  var getKClass = kotlin_kotlin.$_$.p7;
  var compareTo = kotlin_kotlin.$_$.v5;
  var fromInt = kotlin_kotlin.$_$.d5;
  var subtract = kotlin_kotlin.$_$.m5;
  var add = kotlin_kotlin.$_$.t4;
  var Long = kotlin_kotlin.$_$.ga;
  var compare = kotlin_kotlin.$_$.x4;
  var NumberFormatException_init_$Create$ = kotlin_kotlin.$_$.s1;
  var isFinite = kotlin_kotlin.$_$.ya;
  var toBits = kotlin_kotlin.$_$.eb;
  var shiftRightUnsigned = kotlin_kotlin.$_$.k5;
  var bitwiseAnd = kotlin_kotlin.$_$.u4;
  var convertToInt = kotlin_kotlin.$_$.z4;
  var bitwiseOr = kotlin_kotlin.$_$.v4;
  var countTrailingZeroBits = kotlin_kotlin.$_$.va;
  var ArithmeticException_init_$Create$ = kotlin_kotlin.$_$.j1;
  var Unit_instance = kotlin_kotlin.$_$.z;
  var equalsLong = kotlin_kotlin.$_$.c5;
  var coerceIn = kotlin_kotlin.$_$.j7;
  var divide = kotlin_kotlin.$_$.b5;
  var modulo = kotlin_kotlin.$_$.f5;
  var negate = kotlin_kotlin.$_$.h5;
  var equals = kotlin_kotlin.$_$.z5;
  var noWhenBranchMatchedException = kotlin_kotlin.$_$.cb;
  var shiftRight = kotlin_kotlin.$_$.l5;
  var protoOf = kotlin_kotlin.$_$.y6;
  var objectCreate = kotlin_kotlin.$_$.x6;
  var ensureNotNull = kotlin_kotlin.$_$.xa;
  var abs = kotlin_kotlin.$_$.d7;
  var multiply = kotlin_kotlin.$_$.g5;
  var coerceAtMost = kotlin_kotlin.$_$.i7;
  var VOID = kotlin_kotlin.$_$.a;
  var to = kotlin_kotlin.$_$.ib;
  var get_ONE = kotlin_kotlin.$_$.s4;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.d;
  var padEnd = kotlin_kotlin.$_$.r8;
  var charCodeAt = kotlin_kotlin.$_$.s5;
  var toString = kotlin_kotlin.$_$.k;
  var substring = kotlin_kotlin.$_$.d9;
  var removePrefix = kotlin_kotlin.$_$.s8;
  var repeat = kotlin_kotlin.$_$.t8;
  var substring_0 = kotlin_kotlin.$_$.e9;
  var toNumber = kotlin_kotlin.$_$.n5;
  var numberToLong = kotlin_kotlin.$_$.i5;
  var charSequenceLength = kotlin_kotlin.$_$.u5;
  var initMetadataForCompanion = kotlin_kotlin.$_$.h6;
  var Number_0 = kotlin_kotlin.$_$.ja;
  var ArithmeticException = kotlin_kotlin.$_$.v9;
  var THROW_CCE = kotlin_kotlin.$_$.la;
  var hashCode = kotlin_kotlin.$_$.f6;
  var toCharArray = kotlin_kotlin.$_$.l9;
  var toByte = kotlin_kotlin.$_$.z6;
  var toShort = kotlin_kotlin.$_$.a7;
  var convertToShort = kotlin_kotlin.$_$.a5;
  var convertToByte = kotlin_kotlin.$_$.y4;
  var Comparable = kotlin_kotlin.$_$.z9;
  var initMetadataForClass = kotlin_kotlin.$_$.g6;
  var get_lastIndex = kotlin_kotlin.$_$.b3;
  var arrayCopy = kotlin_kotlin.$_$.w1;
  var fill = kotlin_kotlin.$_$.o2;
  var contentEquals = kotlin_kotlin.$_$.b2;
  var shiftLeft = kotlin_kotlin.$_$.j5;
  var toString_0 = kotlin_kotlin.$_$.b7;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.m1;
  var IllegalStateException_init_$Create$ = kotlin_kotlin.$_$.o1;
  var copyOf = kotlin_kotlin.$_$.h2;
  var IndexOutOfBoundsException_init_$Create$ = kotlin_kotlin.$_$.q1;
  var last = kotlin_kotlin.$_$.i3;
  var NullPointerException_init_$Create$ = kotlin_kotlin.$_$.r1;
  var countTrailingZeroBits_0 = kotlin_kotlin.$_$.ua;
  var Default_getInstance = kotlin_kotlin.$_$.v;
  var StringBuilder_init_$Create$ = kotlin_kotlin.$_$.h1;
  var _ULong___init__impl__c78o9k = kotlin_kotlin.$_$.q;
  var ULong = kotlin_kotlin.$_$.oa;
  var _ULong___get_data__impl__fggpzb = kotlin_kotlin.$_$.r;
  var invert = kotlin_kotlin.$_$.e5;
  var countLeadingZeroBits = kotlin_kotlin.$_$.ra;
  var countOneBits = kotlin_kotlin.$_$.sa;
  var countOneBits_0 = kotlin_kotlin.$_$.ta;
  var StringBuilder_init_$Create$_0 = kotlin_kotlin.$_$.i1;
  var until = kotlin_kotlin.$_$.m7;
  var Collection = kotlin_kotlin.$_$.u1;
  var isInterface = kotlin_kotlin.$_$.o6;
  var longArray = kotlin_kotlin.$_$.p6;
  var bitwiseXor = kotlin_kotlin.$_$.w4;
  var initMetadataForObject = kotlin_kotlin.$_$.k6;
  var enumEntries = kotlin_kotlin.$_$.p4;
  var Enum = kotlin_kotlin.$_$.aa;
  var get_lastIndex_0 = kotlin_kotlin.$_$.d3;
  var getStringHashCode = kotlin_kotlin.$_$.e6;
  var Char__compareTo_impl_ypi4mb = kotlin_kotlin.$_$.e;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.b1;
  var sorted = kotlin_kotlin.$_$.y3;
  var getValue = kotlin_kotlin.$_$.u2;
  var removeAll = kotlin_kotlin.$_$.v3;
  var lastOrNull = kotlin_kotlin.$_$.f3;
  var get_lastIndex_1 = kotlin_kotlin.$_$.c3;
  var LinkedHashMap_init_$Create$ = kotlin_kotlin.$_$.e1;
  var last_0 = kotlin_kotlin.$_$.g3;
  var first = kotlin_kotlin.$_$.s2;
  var numberRangeToNumber = kotlin_kotlin.$_$.r6;
  var ClosedRange = kotlin_kotlin.$_$.g7;
  var contains = kotlin_kotlin.$_$.l7;
  var contains_0 = kotlin_kotlin.$_$.d8;
  var DoubleCompanionObject_instance = kotlin_kotlin.$_$.t;
  var doubleFromBits = kotlin_kotlin.$_$.y5;
  var take = kotlin_kotlin.$_$.g9;
  var listOf = kotlin_kotlin.$_$.k3;
  var toString_1 = kotlin_kotlin.$_$.hb;
  var toBits_0 = kotlin_kotlin.$_$.db;
  var copyOfRange = kotlin_kotlin.$_$.g2;
  var indexOf = kotlin_kotlin.$_$.m8;
  var startsWith = kotlin_kotlin.$_$.x8;
  var startsWith_0 = kotlin_kotlin.$_$.y8;
  var digitToIntOrNull = kotlin_kotlin.$_$.e8;
  var IllegalArgumentException = kotlin_kotlin.$_$.da;
  var numberToByte = kotlin_kotlin.$_$.s6;
  var numberToShort = kotlin_kotlin.$_$.w6;
  var numberToInt = kotlin_kotlin.$_$.v6;
  var numberToDouble = kotlin_kotlin.$_$.u6;
  var _UInt___get_data__impl__f0vqqw = kotlin_kotlin.$_$.p;
  var ULong__toString_impl_f9au7k = kotlin_kotlin.$_$.s;
  var charArray = kotlin_kotlin.$_$.r5;
  var charSequenceGet = kotlin_kotlin.$_$.t5;
  var StringBuilder = kotlin_kotlin.$_$.z7;
  var initMetadataForInterface = kotlin_kotlin.$_$.i6;
  var Char = kotlin_kotlin.$_$.y9;
  var Char__toInt_impl_vasixd = kotlin_kotlin.$_$.j;
  var Companion_instance = kotlin_kotlin.$_$.x;
  var getOrNull = kotlin_kotlin.$_$.t2;
  var THROW_IAE = kotlin_kotlin.$_$.ma;
  var NumberFormatException = kotlin_kotlin.$_$.ia;
  var Error_init_$Create$ = kotlin_kotlin.$_$.l1;
  var IndexOutOfBoundsException = kotlin_kotlin.$_$.fa;
  var IndexOutOfBoundsException_init_$Init$ = kotlin_kotlin.$_$.p1;
  var captureStack = kotlin_kotlin.$_$.p5;
  //endregion
  //region block: pre-declaration
  initMetadataForCompanion(Companion);
  initMetadataForClass(BigDecimal, 'BigDecimal', VOID, Number_0, [Comparable]);
  initMetadataForClass(Workspace, 'Workspace');
  initMetadataForClass(WitnessSession, 'WitnessSession');
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(ParsedMagnitude537, 'ParsedMagnitude537', ParsedMagnitude537);
  initMetadataForClass(OddModulusContext, 'OddModulusContext');
  initMetadataForClass(DecimalBinaryPrefix, 'DecimalBinaryPrefix');
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(BigInteger, 'BigInteger', VOID, Number_0, [Comparable]);
  initMetadataForObject(CompactInteger529, 'CompactInteger529');
  initMetadataForClass(DecimalRounding, 'DecimalRounding', VOID, Enum);
  initMetadataForClass(DecimalAccumulator, 'DecimalAccumulator', DecimalAccumulator);
  initMetadataForClass(IntegerView583, 'IntegerView583');
  initMetadataForClass(Cells, 'Cells');
  initMetadataForClass(DecimalWords, 'DecimalWords');
  initMetadataForObject(DecimalDivision581, 'DecimalDivision581');
  initMetadataForClass(DecimalKey, 'DecimalKey', VOID, VOID, [Comparable]);
  initMetadataForCompanion(Companion_2);
  initMetadataForClass(State, 'State');
  initMetadataForClass(Pages, 'Pages');
  initMetadataForClass(Words, 'Words');
  initMetadataForObject(DecimalPower593, 'DecimalPower593');
  initMetadataForObject(DecimalPowers597, 'DecimalPowers597');
  initMetadataForClass(Cells_0, 'Cells');
  initMetadataForClass(DecimalWords_0, 'DecimalWords');
  initMetadataForObject(DecimalProduct580, 'DecimalProduct580');
  initMetadataForClass(Run, 'Run');
  initMetadataForClass(Parts, 'Parts');
  initMetadataForClass(BinaryMagnitude, 'BinaryMagnitude');
  initMetadataForCompanion(Companion_3);
  initMetadataForClass(DecimalSignedWork535, 'DecimalSignedWork535');
  initMetadataForClass(Cells_1, 'Cells');
  initMetadataForClass(DecimalWords_1, 'DecimalWords');
  initMetadataForObject(DecimalSquareRoot579, 'DecimalSquareRoot579');
  initMetadataForClass(View, 'View');
  initMetadataForClass(Cells_2, 'Cells');
  initMetadataForClass(Digits, 'Digits');
  initMetadataForObject(DecimalSum585, 'DecimalSum585');
  initMetadataForClass(Lexical, 'Lexical');
  initMetadataForClass(Cells_3, 'Cells');
  initMetadataForClass(Digits_0, 'Digits');
  initMetadataForObject(DecimalText588, 'DecimalText588');
  initMetadataForObject(Decimals, 'Decimals');
  initMetadataForClass(Value, 'Value');
  initMetadataForClass(Failure, 'Failure');
  initMetadataForClass(QuotientRemainder, 'QuotientRemainder');
  initMetadataForObject(MagnitudeLimits, 'MagnitudeLimits');
  initMetadataForClass(ParallelFrame539, 'ParallelFrame539');
  initMetadataForClass(Arena, 'Arena');
  initMetadataForObject(MagnitudeMultiplication, 'MagnitudeMultiplication');
  initMetadataForCompanion(Companion_4);
  initMetadataForClass(MathContext, 'MathContext');
  initMetadataForClass(MultiplicationPolicy539, 'MultiplicationPolicy539');
  initMetadataForClass(DecimalTextFormat, 'DecimalTextFormat', VOID, Enum);
  initMetadataForClass(RadixDigits537, 'RadixDigits537');
  function text$default(value, start, end, $super) {
    start = start === VOID ? 0 : start;
    end = end === VOID ? charSequenceLength(value) : end;
    var tmp;
    if ($super === VOID) {
      this.hq(value, start, end);
      tmp = Unit_instance;
    } else {
      tmp = $super.hq.call(this, value, start, end);
    }
    return tmp;
  }
  function characters(value, start, end) {
    var inductionVariable = start;
    if (inductionVariable < end)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.iv(value[index]);
      }
       while (inductionVariable < end);
  }
  function zeros(count) {
    var remaining = count;
    while (compare(remaining, new Long(0, 0)) > 0) {
      var tmp0 = remaining;
      // Inline function 'kotlin.comparisons.minOf' call
      var b = fromInt(get_ZERO_BLOCK537().length);
      var tmp$ret$0 = compare(tmp0, b) <= 0 ? tmp0 : b;
      var block = convertToInt(tmp$ret$0);
      this.hq(get_ZERO_BLOCK537(), 0, block);
      // Inline function 'kotlin.Long.minus' call
      var this_0 = remaining;
      remaining = subtract(this_0, fromInt(block));
    }
  }
  initMetadataForInterface(NumericSink537, 'NumericSink537');
  initMetadataForClass(ArraySink537, 'ArraySink537', VOID, VOID, [NumericSink537]);
  initMetadataForClass(AppendableSink537, 'AppendableSink537', VOID, VOID, [NumericSink537]);
  initMetadataForClass(DecimalLayout537, 'DecimalLayout537');
  initMetadataForCompanion(Companion_5);
  initMetadataForClass(NumericText537, 'NumericText537');
  initMetadataForObject(PrimalityCertainty, 'PrimalityCertainty');
  initMetadataForObject(PrimeSearchLimits, 'PrimeSearchLimits');
  initMetadataForCompanion(Companion_6);
  initMetadataForClass(RoundingMode, 'RoundingMode', VOID, Enum);
  initMetadataForClass(ArrayIndexOutOfBoundsException, 'ArrayIndexOutOfBoundsException', VOID, IndexOutOfBoundsException);
  //endregion
  function normalizedCoefficient529($this, value) {
    return getKClassFromExpression(value).equals(getKClass(BigInteger)) ? value : BigInteger_init_$Create$_4(value.ti());
  }
  function compareValues($this, a, aScale, b, bScale) {
    if (!(a.ui() === b.ui()))
      return compareTo(a.ui(), b.ui());
    if (a.ui() === 0)
      return 0;
    var tmp0 = fromInt(a.vi());
    // Inline function 'kotlin.Long.minus' call
    var other = b.vi();
    var digitDifference = subtract(tmp0, fromInt(other));
    var exponent = compare(digitDifference, new Long(0, 0)) > 0 && compare(bScale, subtract(new Long(-1, 2147483647), digitDifference)) > 0 ? 1 : compare(digitDifference, new Long(0, 0)) < 0 && compare(bScale, subtract(new Long(0, -2147483648), digitDifference)) < 0 ? -1 : add(bScale, digitDifference).t2(aScale);
    if (!(exponent === 0))
      return imul(exponent, a.ui());
    return imul(a.wi(b), a.ui());
  }
  function parse($this, value) {
    return DecimalText588_getInstance().gj(value, Companion_getInstance_4().yi_1);
  }
  function fromDouble($this, value) {
    if (!isFinite(value))
      throw NumberFormatException_init_$Create$('Infinite or NaN');
    if (value === 0.0)
      return $this.ij_1;
    var bits = toBits(value);
    var field = convertToInt(bitwiseAnd(shiftRightUnsigned(bits, 52), new Long(2047, 0)));
    // Inline function 'kotlin.Long.minus' call
    var this_0 = new Long(0, 1048576);
    var tmp$ret$0 = subtract(this_0, fromInt(1));
    var mantissa = bitwiseAnd(bits, tmp$ret$0);
    if (!(field === 0))
      mantissa = bitwiseOr(mantissa, new Long(0, 1048576));
    var exponent = ((field === 0 ? 1 : field) - 1023 | 0) - 52 | 0;
    if (exponent < 0) {
      var tmp0 = countTrailingZeroBits(mantissa);
      // Inline function 'kotlin.comparisons.minOf' call
      var b = -exponent | 0;
      var remove = Math.min(tmp0, b);
      mantissa = shiftRightUnsigned(mantissa, remove);
      exponent = exponent + remove | 0;
    }
    var coefficient = Companion_getInstance_1().fk(mantissa);
    var scale;
    if (exponent >= 0) {
      coefficient = coefficient.ik(exponent);
      scale = 0;
    } else {
      scale = -exponent | 0;
      coefficient = coefficient.hk(Companion_getInstance_1().fk(new Long(5, 0)).gk(scale));
    }
    return BigDecimal_init_$Create$_0(value < 0 ? coefficient.jk() : coefficient, scale);
  }
  function roundedDouble($this, value, mc) {
    var exact = fromDouble($this, value);
    var context = mc;
    return exact.ui() === 0 ? exact : exact.rk(context);
  }
  function tenPow($this, exponent) {
    if (compare(exponent, new Long(0, 0)) < 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    if (compare(exponent, new Long(646456992, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    if (compare(exponent, fromInt($this.uj_1.length)) < 0)
      return $this.uj_1[convertToInt(exponent)];
    var tmp0_safe_receiver = DecimalPowers597_getInstance().uk(convertToInt(exponent));
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    return Companion_getInstance_1().bk_1.gk(convertToInt(exponent));
  }
  function checkedScale($this, scale) {
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false))
      throw ArithmeticException_init_$Create$(compare(scale, new Long(0, 0)) < 0 ? 'Overflow' : 'Underflow');
    return convertToInt(scale);
  }
  function checkedRoundingScale($this, scale) {
    var narrowed = convertToInt(scale);
    if (!equalsLong(fromInt(narrowed), scale))
      throw ArithmeticException_init_$Create$(narrowed > 0 ? 'Underflow' : 'Overflow');
    return narrowed;
  }
  function saturatedScale($this, scale) {
    return convertToInt(coerceIn(scale, new Long(-2147483648, -1), new Long(2147483647, 0)));
  }
  function scaleForValue($this, scale, zero) {
    return zero ? saturatedScale($this, scale) : checkedScale($this, scale);
  }
  function exponentText($this, exponent) {
    return 'E' + (compare(exponent, new Long(0, 0)) >= 0 ? '+' : '') + exponent.toString();
  }
  function roundedDivide($this, numerator, denominator, mode) {
    if (getKClassFromExpression(numerator).equals(getKClass(BigInteger)) && getKClassFromExpression(denominator).equals(getKClass(BigInteger))) {
      var a = numerator.vk();
      var b = denominator.vk();
      if (!(a == null) && !(b == null) && !equals(b, new Long(0, 0))) {
        var quotient = divide(a, b);
        var remainder = modulo(a, b);
        if (equalsLong(remainder, new Long(0, 0)))
          return Companion_getInstance_1().fk(quotient);
        var sign = compare(a, new Long(0, 0)) < 0 === compare(b, new Long(0, 0)) < 0 ? 1 : -1;
        var r = compare(remainder, new Long(0, 0)) < 0 ? negate(remainder) : remainder;
        var d = compare(b, new Long(0, 0)) < 0 ? negate(b) : b;
        var half = r.t2(subtract(d, r));
        var tmp = Companion_getInstance_1();
        var tmp_0;
        if (increment($this, mode, sign, half, !equalsLong(bitwiseAnd(quotient, new Long(1, 0)), new Long(0, 0)))) {
          // Inline function 'kotlin.Long.plus' call
          tmp_0 = add(quotient, fromInt(sign));
        } else {
          tmp_0 = quotient;
        }
        return tmp.fk(tmp_0);
      }
    }
    var qr = numerator.wk(denominator);
    if (qr[1].ui() === 0)
      return qr[0];
    var sign_0 = imul(numerator.ui(), denominator.ui());
    var remainder_0 = qr[1].xk();
    var divisor = denominator.xk();
    var half_0 = remainder_0.zk(divisor.yk(remainder_0));
    return increment($this, mode, sign_0, half_0, qr[0].bl(0)) ? qr[0].al(Companion_getInstance_1().fk(fromInt(sign_0))) : qr[0];
  }
  function roundTiny($this, sign, mode) {
    return increment($this, mode, sign, -1, false) ? Companion_getInstance_1().fk(fromInt(sign)) : Companion_getInstance_1().yj_1;
  }
  function increment($this, mode, sign, half, odd) {
    var tmp;
    switch (mode.l2_1) {
      case 0:
        tmp = true;
        break;
      case 1:
        tmp = false;
        break;
      case 2:
        tmp = sign > 0;
        break;
      case 3:
        tmp = sign < 0;
        break;
      case 4:
        tmp = half >= 0;
        break;
      case 5:
        tmp = half > 0;
        break;
      case 6:
        tmp = half > 0 || (half === 0 && odd);
        break;
      case 7:
        throw ArithmeticException_init_$Create$('Rounding necessary');
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function BigDecimal_init_$Init$(value, scale, $this) {
    BigDecimal.call($this, scale, convertToInt(shiftRight(value, 32)), convertToInt(value), 1, null);
    return $this;
  }
  function BigDecimal_init_$Create$(value, scale) {
    return BigDecimal_init_$Init$(value, scale, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_0(coefficient, decimalScale, $this) {
    BigDecimal_init_$Init$_1(normalizedCoefficient529(Companion_getInstance(), coefficient), decimalScale, Unit_instance, $this);
    return $this;
  }
  function BigDecimal_init_$Create$_0(coefficient, decimalScale) {
    return BigDecimal_init_$Init$_0(coefficient, decimalScale, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_1(coefficient, scale, owned, $this) {
    BigDecimal.call($this, scale, coefficient.dl() ? convertToInt(shiftRight(coefficient.cl(), 32)) : 0, coefficient.dl() ? convertToInt(coefficient.cl()) : 0, coefficient.dl() ? 1 : 2, coefficient.dl() ? null : coefficient);
    return $this;
  }
  function BigDecimal_init_$Init$_2(value, $this) {
    BigDecimal.call($this, value.kk_1, value.lk_1, value.mk_1, value.nk_1, value.ok_1);
    return $this;
  }
  function compactValue529($this) {
    return CompactInteger529_getInstance().gl($this.lk_1, $this.mk_1);
  }
  function coefficientSnapshot($this) {
    var tmp0_elvis_lhs = $this.ok_1;
    return tmp0_elvis_lhs == null ? Companion_getInstance_1().fk(compactValue529($this)) : tmp0_elvis_lhs;
  }
  function storedSign529($this) {
    return $this.nk_1 === 1 ? CompactInteger529_getInstance().hl(compactValue529($this)) : ensureNotNull($this.ok_1).ui();
  }
  function BigDecimal_init_$Init$_3(value, $this) {
    BigDecimal_init_$Init$_0(value, 0, $this);
    return $this;
  }
  function BigDecimal_init_$Create$_1(value) {
    return BigDecimal_init_$Init$_3(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_4(value, mc, $this) {
    BigDecimal_init_$Init$_2(roundValue(BigDecimal_init_$Create$_1(value), mc), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_2(value, mc) {
    return BigDecimal_init_$Init$_4(value, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_5(unscaledVal, scale, mc, $this) {
    BigDecimal_init_$Init$_2(roundValue(BigDecimal_init_$Create$_0(unscaledVal, scale), mc), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_3(unscaledVal, scale, mc) {
    return BigDecimal_init_$Init$_5(unscaledVal, scale, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_6(value, $this) {
    BigDecimal_init_$Init$_7(fromInt(value), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_4(value) {
    return BigDecimal_init_$Init$_6(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_7(value, $this) {
    BigDecimal_init_$Init$(value, 0, $this);
    return $this;
  }
  function BigDecimal_init_$Create$_5(value) {
    return BigDecimal_init_$Init$_7(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_8(value, mc, $this) {
    BigDecimal_init_$Init$_9(fromInt(value), mc, $this);
    return $this;
  }
  function BigDecimal_init_$Create$_6(value, mc) {
    return BigDecimal_init_$Init$_8(value, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_9(value, mc, $this) {
    BigDecimal_init_$Init$_2(roundValue(BigDecimal_init_$Create$_5(value), mc), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_7(value, mc) {
    return BigDecimal_init_$Init$_9(value, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_10(value, $this) {
    BigDecimal_init_$Init$_2(parse(Companion_getInstance(), value), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_8(value) {
    return BigDecimal_init_$Init$_10(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_11(value, mc, $this) {
    BigDecimal_init_$Init$_2(value.length <= 646456992 ? roundValue(parse(Companion_getInstance(), value), mc) : DecimalText588_getInstance().gj(value, mc), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_9(value, mc) {
    return BigDecimal_init_$Init$_11(value, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_12(value, $this) {
    BigDecimal_init_$Init$_13(value, 0, value.length, $this);
    return $this;
  }
  function BigDecimal_init_$Create$_10(value) {
    return BigDecimal_init_$Init$_12(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_13(value, offset, len, $this) {
    BigDecimal_init_$Init$_2(DecimalText588_getInstance().il(value, offset, len, Companion_getInstance_4().yi_1), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_11(value, offset, len) {
    return BigDecimal_init_$Init$_13(value, offset, len, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_14(value, mc, $this) {
    BigDecimal_init_$Init$_15(value, 0, value.length, mc, $this);
    return $this;
  }
  function BigDecimal_init_$Create$_12(value, mc) {
    return BigDecimal_init_$Init$_14(value, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_15(value, offset, len, mc, $this) {
    BigDecimal_init_$Init$_2(DecimalText588_getInstance().il(value, offset, len, mc), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_13(value, offset, len, mc) {
    return BigDecimal_init_$Init$_15(value, offset, len, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_16(value, $this) {
    BigDecimal_init_$Init$_2(fromDouble(Companion_getInstance(), value), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_14(value) {
    return BigDecimal_init_$Init$_16(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_17(value, mc, $this) {
    BigDecimal_init_$Init$_2(roundedDouble(Companion_getInstance(), value, mc), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_15(value, mc) {
    return BigDecimal_init_$Init$_17(value, mc, objectCreate(protoOf(BigDecimal)));
  }
  function storedPrecision($this) {
    if ($this.nk_1 === 2 && !getKClassFromExpression(ensureNotNull($this.ok_1)).equals(getKClass(BigInteger)))
      return $this.ok_1.vi();
    var cached = $this.pk_1;
    if (!(cached === 0))
      return cached;
    var digits = $this.nk_1 === 1 ? CompactInteger529_getInstance().jl(compactValue529($this)) : ensureNotNull($this.ok_1).vi();
    $this.pk_1 = digits;
    return digits;
  }
  function contextualUnaryRound($this, mc) {
    return storedSign529($this) === 0 ? roundValue($this, mc) : $this.kl(mc);
  }
  function rawSum585($this, other, subtract_0, mc) {
    if ($this.nk_1 === 1 && other.nk_1 === 1) {
      var tmp0 = $this.kk_1;
      // Inline function 'kotlin.comparisons.maxOf' call
      var b = other.kk_1;
      var scale = Math.max(tmp0, b);
      var tmp = compactValue529($this);
      var tmp0_0 = fromInt(scale);
      // Inline function 'kotlin.Long.minus' call
      var other_0 = $this.kk_1;
      var tmp$ret$1 = subtract(tmp0_0, fromInt(other_0));
      var a = scaledCompact529($this, tmp, tmp$ret$1);
      var tmp_0 = compactValue529(other);
      var tmp0_1 = fromInt(scale);
      // Inline function 'kotlin.Long.minus' call
      var other_1 = other.kk_1;
      var tmp$ret$2 = subtract(tmp0_1, fromInt(other_1));
      var b_0 = scaledCompact529($this, tmp_0, tmp$ret$2);
      if (!(a == null) && !(b_0 == null)) {
        var result = subtract_0 ? subtract(a, b_0) : add(a, b_0);
        if (subtract_0 ? CompactInteger529_getInstance().ml(a, b_0, result) : CompactInteger529_getInstance().ll(a, b_0, result)) {
          var decimal = BigDecimal_init_$Create$(result, scale);
          return mc == null ? decimal : roundValue(decimal, mc);
        }
      }
    }
    var coefficient = coefficientSnapshot($this);
    var otherCoefficient529 = coefficientSnapshot(other);
    var tmp0_elvis_lhs = coefficient.nl(otherCoefficient529, $this.kk_1, other.kk_1, subtract_0, mc);
    var tmp_1;
    if (tmp0_elvis_lhs == null) {
      return null;
    } else {
      tmp_1 = tmp0_elvis_lhs;
    }
    var result_0 = tmp_1;
    return BigDecimal_init_$Create$_0(result_0.dd_1, result_0.ed_1);
  }
  function addValue($this, augend) {
    var tmp0 = $this.kk_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = augend.kk_1;
    var scale = Math.max(tmp0, b);
    return BigDecimal_init_$Create$_0(scaledCoefficient($this, scale).al(scaledCoefficient(augend, scale)), scale);
  }
  function addContextValue($this, augend, mc) {
    var tmp0 = $this.kk_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = augend.kk_1;
    var preferredScale = Math.max(tmp0, b);
    if ($this.ui() === 0 || augend.ui() === 0) {
      var nonzero = ($this.ui() === 0 ? augend : $this).rk(mc);
      if (nonzero.ui() === 0)
        return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, preferredScale);
      var tmp0_0 = fromInt(preferredScale);
      var tmp0_1 = fromInt(nonzero.kk_1);
      // Inline function 'kotlin.Long.plus' call
      var other = mc.ol_1;
      var tmp0_2 = add(tmp0_1, fromInt(other));
      // Inline function 'kotlin.Long.minus' call
      var other_0 = nonzero.ql();
      // Inline function 'kotlin.comparisons.minOf' call
      var b_0 = subtract(tmp0_2, fromInt(other_0));
      var scale = compare(tmp0_0, b_0) <= 0 ? tmp0_0 : b_0;
      return nonzero.rl(checkedScale(Companion_getInstance(), scale));
    }
    checkAdditionAlignment($this, augend, mc);
    var tmp;
    var tmp0_3 = fromInt($this.kk_1);
    // Inline function 'kotlin.Long.minus' call
    var other_1 = augend.kk_1;
    var tmp$ret$4 = subtract(tmp0_3, fromInt(other_1));
    if (compare(abs(tmp$ret$4), new Long(10000, 0)) < 0) {
      tmp = true;
    } else {
      var tmp_0 = abs(subtract(adjustedExponent($this), adjustedExponent(augend)));
      // Inline function 'kotlin.Long.plus' call
      var this_0 = fromInt(mc.ol_1);
      var tmp$ret$5 = add(this_0, fromInt(3));
      tmp = compare(tmp_0, tmp$ret$5) <= 0;
    }
    if (tmp) {
      var tmp0_elvis_lhs = rawSum585($this, augend, false, mc);
      return tmp0_elvis_lhs == null ? roundValue(addValue($this, augend), mc) : tmp0_elvis_lhs;
    }
    var large = compare(adjustedExponent($this), adjustedExponent(augend)) > 0 ? $this : augend;
    var small = large === $this ? augend : $this;
    var tmp0_4 = fromInt(large.kk_1);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_1 = subtract(add(fromInt(mc.ol_1), new Long(2, 0)), adjustedExponent(large));
    var workingScale = compare(tmp0_4, b_1) >= 0 ? tmp0_4 : b_1;
    var sticky = stickyAt(small, workingScale);
    var tmp1_elvis_lhs = rawSum585(large, sticky, false, mc);
    var result = tmp1_elvis_lhs == null ? roundValue(addValue(large, sticky), mc) : tmp1_elvis_lhs;
    var tmp0_5 = $this.kk_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_2 = augend.kk_1;
    var preferred = Math.max(tmp0_5, b_2);
    return result.ui() === 0 ? result.rl(preferred) : stripTo(result, preferred);
  }
  function checkAdditionAlignment($this, other, mc) {
    if ($this.kk_1 === other.kk_1)
      return Unit_instance;
    var dominant = $this.kk_1 <= other.kk_1 ? $this : other;
    var remote = dominant === $this ? other : $this;
    var tmp0 = fromInt(remote.kk_1);
    // Inline function 'kotlin.Long.minus' call
    var other_0 = remote.ql();
    // Inline function 'kotlin.Long.plus' call
    var this_0 = subtract(tmp0, fromInt(other_0));
    var leadingPosition = add(this_0, fromInt(1));
    var tmp0_0 = fromInt(dominant.kk_1);
    // Inline function 'kotlin.Long.minus' call
    var other_1 = dominant.ql();
    var tmp0_1 = subtract(tmp0_0, fromInt(other_1));
    // Inline function 'kotlin.Long.plus' call
    var other_2 = mc.ol_1;
    var roundingScale = add(tmp0_1, fromInt(other_2));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = fromInt(dominant.kk_1);
    var alignmentThreshold = add(this_1, fromInt(2));
    var tmp;
    if (compare(leadingPosition, alignmentThreshold) > 0) {
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$5 = add(roundingScale, fromInt(2));
      tmp = compare(leadingPosition, tmp$ret$5) > 0;
    } else {
      tmp = false;
    }
    if (tmp) {
      var tmp_0 = Companion_getInstance();
      // Inline function 'kotlin.comparisons.maxOf' call
      var a = fromInt(dominant.kk_1);
      // Inline function 'kotlin.Long.plus' call
      var this_2 = compare(a, roundingScale) >= 0 ? a : roundingScale;
      var tmp$ret$7 = add(this_2, fromInt(3));
      checkedScale(tmp_0, tmp$ret$7);
    }
  }
  function stickyAt($this, scale) {
    var coefficient = coefficientSnapshot($this);
    if ($this.ui() === 0 || compare(fromInt($this.kk_1), scale) <= 0)
      return $this;
    var drop = subtract(fromInt($this.kk_1), scale);
    var reportedPrecision = $this.ql();
    if (equalsLong(drop, fromInt(reportedPrecision)) && !equals(coefficient.vk(), new Long(0, 0)) && equalsLong(drop, fromInt(storedPrecision($this)))) {
      var tmp = Companion_getInstance_1().fk(fromInt($this.ui()));
      var tmp_0 = Companion_getInstance();
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$0 = add(scale, fromInt(1));
      return BigDecimal_init_$Create$_0(tmp, checkedScale(tmp_0, tmp$ret$0));
    }
    if (compare(drop, fromInt(reportedPrecision)) <= 0) {
      var divisor = tenPow(Companion_getInstance(), drop);
      var qr = coefficient.wk(divisor);
      var sticky = qr[1].ui() === 0 ? qr[0] : qr[0].hk(Companion_getInstance_1().bk_1).al(Companion_getInstance_1().fk(fromInt($this.ui())));
      var tmp_1;
      if (qr[1].ui() === 0) {
        tmp_1 = BigDecimal_init_$Create$_0(sticky, checkedScale(Companion_getInstance(), scale));
      } else {
        var tmp_2 = Companion_getInstance();
        // Inline function 'kotlin.Long.plus' call
        var tmp$ret$1 = add(scale, fromInt(1));
        tmp_1 = BigDecimal_init_$Create$_0(sticky, checkedScale(tmp_2, tmp$ret$1));
      }
      return tmp_1;
    }
    var tmp_3 = Companion_getInstance_1().fk(fromInt($this.ui()));
    var tmp_4 = Companion_getInstance();
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$2 = add(scale, fromInt(1));
    return BigDecimal_init_$Create$_0(tmp_3, checkedScale(tmp_4, tmp$ret$2));
  }
  function multiplyValue($this, multiplicand) {
    var tmp = Companion_getInstance();
    var tmp0 = fromInt($this.kk_1);
    // Inline function 'kotlin.Long.plus' call
    var other = multiplicand.kk_1;
    var tmp$ret$0 = add(tmp0, fromInt(other));
    var scale = scaleForValue(tmp, tmp$ret$0, storedSign529($this) === 0);
    if ($this.nk_1 === 1 && multiplicand.nk_1 === 1) {
      var a = compactValue529($this);
      var b = compactValue529(multiplicand);
      var result = multiply(a, b);
      if (CompactInteger529_getInstance().sl(a, b, result))
        return BigDecimal_init_$Create$(result, scale);
    }
    var coefficient = coefficientSnapshot($this);
    var multiplicandCoefficient529 = coefficientSnapshot(multiplicand);
    var otherCoefficient = multiplicandCoefficient529;
    return BigDecimal_init_$Create$_0(coefficient.hk(otherCoefficient), scale);
  }
  function checkDivisionByZero($this, divisor) {
    if (divisor.ui() === 0)
      throw ArithmeticException_init_$Create$($this.ui() === 0 ? 'Division undefined' : 'Division by zero');
  }
  function divideExactly($this, divisor) {
    var tmp0 = fromInt($this.kk_1);
    // Inline function 'kotlin.Long.minus' call
    var other = divisor.kk_1;
    var preferred = subtract(tmp0, fromInt(other));
    if ($this.ui() === 0)
      return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, saturatedScale(Companion_getInstance(), preferred));
    var tmp = fromInt($this.ql());
    var tmp0_0 = new Long(10, 0);
    // Inline function 'kotlin.Long.times' call
    var other_0 = divisor.ql();
    // Inline function 'kotlin.Long.plus' call
    var this_0 = multiply(tmp0_0, fromInt(other_0));
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(2));
    var tmp$ret$3 = divide(this_1, fromInt(3));
    var exactPrecision = convertToInt(coerceAtMost(add(tmp, tmp$ret$3), new Long(2147483647, 0)));
    checkDivisionNormalization($this, divisor, exactPrecision);
    var tmp0_safe_receiver = compactExactQuotient529($this, divisor);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return stripTo(tmp0_safe_receiver, saturatedScale(Companion_getInstance(), preferred));
    }
    var tmp1_elvis_lhs = exactDivisionCoefficient($this, divisor);
    var tmp_0;
    if (tmp1_elvis_lhs == null) {
      throw ArithmeticException_init_$Create$('Non-terminating decimal expansion');
    } else {
      tmp_0 = tmp1_elvis_lhs;
    }
    var quotient = tmp_0;
    return stripTo(BigDecimal_init_$Create$_0(quotient.dd_1, checkedScale(Companion_getInstance(), quotient.ed_1)), saturatedScale(Companion_getInstance(), preferred));
  }
  function exactDivisionCoefficient($this, divisor, forContext) {
    forContext = forContext === VOID ? false : forContext;
    var coefficient = coefficientSnapshot($this);
    var divisorCoefficient529 = coefficientSnapshot(divisor);
    var gcd = coefficient.tl(divisorCoefficient529);
    var denominator = divisorCoefficient529.xk().ul(gcd);
    var numerator = coefficient.ul(gcd);
    var divisorSign = forContext ? divisorCoefficient529.ui() : divisor.ui();
    if (divisorSign < 0)
      numerator = numerator.jk();
    var twos = denominator.vl();
    denominator = denominator.wl(twos);
    var five = Companion_getInstance_1().fk(new Long(5, 0));
    var fives = 0;
    $l$loop: while (true) {
      var qr = denominator.wk(five);
      if (!(qr[1].ui() === 0))
        break $l$loop;
      denominator = qr[0];
      fives = fives + 1 | 0;
    }
    if (!denominator.equals(Companion_getInstance_1().zj_1))
      return null;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = fives;
    var digits = Math.max(twos, b);
    var tmp0 = fromInt($this.kk_1);
    // Inline function 'kotlin.Long.minus' call
    var other = divisor.kk_1;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = subtract(tmp0, fromInt(other));
    var scale = add(this_0, fromInt(digits));
    if (compare(scale, new Long(-2147483648, -1)) < 0) {
      checkedScale(Companion_getInstance(), scale);
    }
    if (compare(scale, new Long(2147483647, 0)) > 0) {
      if (forContext)
        return null;
      checkedScale(Companion_getInstance(), scale);
    }
    numerator = numerator.ik(digits - twos | 0).hk(five.gk(digits - fives | 0));
    return to(numerator, scale);
  }
  function divideScaledCoefficients($this, divisor, coefficient, divisorCoefficient529, scale, roundingMode, scaleNumerator, raise, checkSourceSign) {
    checkSourceSign = checkSourceSign === VOID ? true : checkSourceSign;
    if (checkSourceSign && $this.ui() === 0)
      return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, scale);
    var tmp0 = quotientExponent($this, divisor);
    // Inline function 'kotlin.Long.plus' call
    var other = $this.kk_1;
    var tmp0_0 = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.minus' call
    var other_0 = divisor.kk_1;
    var tmp$ret$1 = subtract(tmp0_0, fromInt(other_0));
    var exponent = add(tmp$ret$1, scaleNumerator ? raise : negate(raise));
    if (compare(exponent, new Long(-1, -1)) < 0 && !(coefficient.ui() === 0) && !(divisorCoefficient529.ui() === 0)) {
      var sign = checkSourceSign ? imul($this.ui(), divisor.ui()) : imul(coefficient.ui(), divisorCoefficient529.ui());
      return BigDecimal_init_$Create$_0(roundTiny(Companion_getInstance(), sign, roundingMode), scale);
    }
    if (compare(raise, new Long(646456992, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    var numerator = scaleNumerator && compare(raise, new Long(0, 0)) > 0 ? coefficient.hk(tenPow(Companion_getInstance(), raise)) : coefficient;
    var denominator = !scaleNumerator && compare(raise, new Long(0, 0)) > 0 ? divisorCoefficient529.hk(tenPow(Companion_getInstance(), raise)) : divisorCoefficient529;
    if (!checkSourceSign && denominator.ui() === 0 && !(numerator.vk() == null))
      throw ArithmeticException_init_$Create$('/ by zero');
    return BigDecimal_init_$Create$_0(roundedDivide(Companion_getInstance(), numerator, denominator, roundingMode), scale);
  }
  function failScaledZeroDivision($this, zeroScale, target) {
    var coefficient = coefficientSnapshot($this);
    var compact = coefficient.vk();
    var tmp = Companion_getInstance();
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(target);
    var tmp$ret$0 = add(this_0, fromInt(zeroScale));
    var adjusted = scaleForValue(tmp, tmp$ret$0, equals(compact, new Long(0, 0)));
    var numerator = adjusted > $this.kk_1;
    var tmp_0;
    if (numerator) {
      tmp_0 = (target + zeroScale | 0) - $this.kk_1 | 0;
    } else {
      var tmp_1 = Companion_getInstance();
      // Inline function 'kotlin.Long.minus' call
      var this_1 = fromInt($this.kk_1);
      var tmp$ret$1 = subtract(this_1, fromInt(target));
      tmp_0 = saturatedScale(tmp_1, tmp$ret$1) - zeroScale | 0;
    }
    var raise = tmp_0;
    if (raise > 646456992)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    if (compact == null || raise > 18)
      throw ArithmeticException_init_$Create$('BigInteger divide by zero');
    if (numerator && raise > 0) {
      var factor = new Long(1, 0);
      // Inline function 'kotlin.repeat' call
      var inductionVariable = 0;
      if (inductionVariable < raise)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          // Inline function 'kotlin.Long.times' call
          var this_2 = factor;
          factor = multiply(this_2, fromInt(10));
        }
         while (inductionVariable < raise);
      if (compare(abs(compact), divide(new Long(-1, 2147483647), factor)) > 0)
        throw ArithmeticException_init_$Create$('BigInteger divide by zero');
    }
    throw ArithmeticException_init_$Create$('/ by zero');
  }
  function divideWideContext($this, divisor, mc, preferred, normalized, sourceDigits, divisorDigits) {
    var coefficient = coefficientSnapshot($this);
    var divisorCoefficient529 = coefficientSnapshot(divisor);
    var exact = exactDivisionCoefficient($this, divisor, true);
    if (!(exact == null) && exact.dd_1.xk().toString().length <= mc.ol_1)
      return BigDecimal_init_$Create$_0(exact.dd_1, divisionScale($this, exact.ed_1));
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(sourceDigits);
    var tmp0 = subtract(this_0, fromInt(divisorDigits));
    // Inline function 'kotlin.Long.minus' call
    var other = normalized < 0 ? 1 : 0;
    var exponent = subtract(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = mc.ol_1;
    var tmp$ret$2 = add(preferred, fromInt(other_0));
    var scale = subtract(subtract(tmp$ret$2, new Long(1, 0)), exponent);
    var shift = subtract(scale, preferred);
    if (compare(abs(shift), new Long(646456992, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    var numerator = compare(shift, new Long(0, 0)) > 0 ? coefficient.hk(tenPow(Companion_getInstance(), shift)) : coefficient;
    var denominator = compare(shift, new Long(0, 0)) < 0 ? divisorCoefficient529.hk(tenPow(Companion_getInstance(), negate(shift))) : divisorCoefficient529;
    var isExact = numerator.xl(denominator).ui() === 0;
    var value = roundedDivide(Companion_getInstance(), numerator, denominator, mc.pl_1);
    if (value.xk().toString().length > mc.ol_1) {
      value = value.ul(Companion_getInstance_1().bk_1);
      var _unary__edvuaz = scale;
      scale = subtract(_unary__edvuaz, get_ONE());
    }
    if (isExact)
      $l$loop: while (compare(scale, preferred) > 0 && compare(scale, new Long(-2147483648, -1)) > 0) {
        var qr = value.wk(Companion_getInstance_1().bk_1);
        if (!(qr[1].ui() === 0))
          break $l$loop;
        value = qr[0];
        var _unary__edvuaz_0 = scale;
        scale = subtract(_unary__edvuaz_0, get_ONE());
      }
    return BigDecimal_init_$Create$_0(value, divisionScale($this, scale));
  }
  function normalizedCompactOverflow($this, value, raise) {
    var magnitude = abs(value);
    if (equalsLong(magnitude, new Long(0, 0)))
      return false;
    if (compare(raise, new Long(18, 0)) > 0)
      return true;
    // Inline function 'kotlin.repeat' call
    var times = convertToInt(raise);
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = magnitude;
        // Inline function 'kotlin.Long.div' call
        var this_0 = new Long(-1, 2147483647);
        var tmp$ret$2 = divide(this_0, fromInt(10));
        if (compare(tmp, tmp$ret$2) > 0)
          return true;
        // Inline function 'kotlin.Long.times' call
        var this_1 = magnitude;
        magnitude = multiply(this_1, fromInt(10));
      }
       while (inductionVariable < times);
    return false;
  }
  function checkDivisionNormalization($this, divisor, precision, sourcePrecision, divisorPrecision) {
    sourcePrecision = sourcePrecision === VOID ? null : sourcePrecision;
    divisorPrecision = divisorPrecision === VOID ? null : divisorPrecision;
    var adjustment = normalizedComparison($this, divisor) > 0 ? 1 : 0;
    var divisorDigits = divisorPrecision == null ? divisor.ql() : divisorPrecision;
    var sourceDigits = sourcePrecision == null ? $this.ql() : sourcePrecision;
    var tmp0 = fromInt($this.kk_1);
    // Inline function 'kotlin.Long.minus' call
    var other = divisor.kk_1;
    var preferred = subtract(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.plus' call
    var this_0 = add(preferred, fromInt(precision));
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(divisorDigits));
    // Inline function 'kotlin.Long.minus' call
    var this_2 = subtract(this_1, fromInt(sourceDigits));
    var normalization = subtract(this_2, fromInt(adjustment));
    if (sourceDigits === storedPrecision($this) && divisorDigits === storedPrecision(divisor) && !(storedSign529($this) === 0) && !(storedSign529(divisor) === 0))
      return Unit_instance;
    divisionScale($this, normalization);
  }
  function divisionScale($this, scale) {
    var narrowed = convertToInt(scale);
    if (!equalsLong(fromInt(narrowed), scale))
      throw ArithmeticException_init_$Create$(narrowed > 0 ? 'Underflow' : 'Overflow');
    return narrowed;
  }
  function quotientExponent($this, divisor) {
    if ($this.nk_1 === 1 && divisor.nk_1 === 1) {
      var a = compactValue529($this);
      var b = compactValue529(divisor);
      if (!equalsLong(a, new Long(0, -2147483648)) && !equalsLong(b, new Long(0, -2147483648))) {
        var ad = CompactInteger529_getInstance().jl(a);
        var bd = CompactInteger529_getInstance().jl(b);
        // Inline function 'kotlin.Long.minus' call
        var this_0 = fromInt(ad);
        var tmp$ret$0 = subtract(this_0, fromInt(bd));
        var tmp0 = add(tmp$ret$0, fromInt(divisor.kk_1));
        // Inline function 'kotlin.Long.minus' call
        var other = $this.kk_1;
        var tmp0_0 = subtract(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.minus' call
        var other_0 = CompactInteger529_getInstance().yl(a, b, ad, bd) < 0 ? 1 : 0;
        return subtract(tmp0_0, fromInt(other_0));
      }
    }
    var coefficient = coefficientSnapshot($this);
    var divisorCoefficient529 = coefficientSnapshot(divisor);
    if (coefficient.vk() == null || divisorCoefficient529.vk() == null) {
      var tmp0_1 = fromInt(coefficient.vi());
      // Inline function 'kotlin.Long.minus' call
      var other_1 = divisorCoefficient529.vi();
      var tmp$ret$3 = subtract(tmp0_1, fromInt(other_1));
      var tmp0_2 = add(tmp$ret$3, fromInt(divisor.kk_1));
      // Inline function 'kotlin.Long.minus' call
      var other_2 = $this.kk_1;
      var tmp0_3 = subtract(tmp0_2, fromInt(other_2));
      // Inline function 'kotlin.Long.minus' call
      var other_3 = coefficient.wi(divisorCoefficient529) < 0 ? 1 : 0;
      return subtract(tmp0_3, fromInt(other_3));
    }
    var a_0 = coefficient.xk().toString();
    var b_0 = divisorCoefficient529.xk().toString();
    var tmp0_4 = fromInt(a_0.length);
    // Inline function 'kotlin.Long.minus' call
    var other_4 = b_0.length;
    var tmp$ret$6 = subtract(tmp0_4, fromInt(other_4));
    var tmp0_5 = add(tmp$ret$6, fromInt(divisor.kk_1));
    // Inline function 'kotlin.Long.minus' call
    var other_5 = $this.kk_1;
    var tmp0_6 = subtract(tmp0_5, fromInt(other_5));
    // Inline function 'kotlin.Long.minus' call
    var other_6 = normalizedComparison($this, divisor) < 0 ? 1 : 0;
    return subtract(tmp0_6, fromInt(other_6));
  }
  function normalizedComparison($this, divisor) {
    if ($this.nk_1 === 1 && divisor.nk_1 === 1) {
      var a = compactValue529($this);
      var b = compactValue529(divisor);
      if (!equalsLong(a, new Long(0, -2147483648)) && !equalsLong(b, new Long(0, -2147483648)))
        return CompactInteger529_getInstance().zl(a, b);
    }
    var coefficient = coefficientSnapshot($this);
    var divisorCoefficient529 = coefficientSnapshot(divisor);
    if (coefficient.vk() == null || divisorCoefficient529.vk() == null)
      return coefficient.wi(divisorCoefficient529);
    var a_0 = coefficient.xk().toString();
    var b_0 = divisorCoefficient529.xk().toString();
    var tmp0 = a_0.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_1 = b_0.length;
    var length = Math.max(tmp0, b_1);
    return compareTo(padEnd(a_0, length, _Char___init__impl__6a9atx(48)), padEnd(b_0, length, _Char___init__impl__6a9atx(48)));
  }
  function integralStrip($this, preferred, preserveIdentity) {
    var coefficient = coefficientSnapshot($this);
    if (coefficient.ui() === 0) {
      // Inline function 'kotlin.comparisons.minOf' call
      var a = $this.kk_1;
      var scale = Math.min(a, preferred);
      if (preserveIdentity && $this.kk_1 === scale)
        return $this;
      return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, scale);
    }
    var stripped = stripTo($this, preferred);
    return preserveIdentity ? stripped : BigDecimal_init_$Create$_0(coefficientSnapshot(stripped), stripped.kk_1);
  }
  function remainderElement($this, pair) {
    if (pair.length < 2) {
      arrayIndexFailure(1, pair.length);
    }
    return pair[1];
  }
  function roundValue($this, mc) {
    if (mc.ol_1 === 0)
      return $this;
    var drop = $this.ql() - mc.ol_1 | 0;
    if (drop <= 0)
      return $this;
    if ($this.nk_1 === 1 && getKClassFromExpression($this).equals(getKClass(BigDecimal))) {
      var compact = compactValue529($this);
      var scale = $this.kk_1;
      while (drop > 0) {
        var tmp = Companion_getInstance();
        var tmp0 = fromInt(scale);
        // Inline function 'kotlin.Long.minus' call
        var other = drop;
        var tmp$ret$0 = subtract(tmp0, fromInt(other));
        scale = checkedRoundingScale(tmp, tmp$ret$0);
        compact = roundedCompactPower529($this, compact, fromInt(drop), mc.pl_1);
        drop = CompactInteger529_getInstance().jl(compact) - mc.ol_1 | 0;
      }
      return BigDecimal_init_$Create$(compact, scale);
    }
    var coefficient = coefficientSnapshot($this);
    var value = coefficient;
    var scale_0 = $this.kk_1;
    while (drop > 0) {
      var tmp_0 = Companion_getInstance();
      var tmp0_0 = fromInt(scale_0);
      // Inline function 'kotlin.Long.minus' call
      var other_0 = drop;
      var tmp$ret$1 = subtract(tmp0_0, fromInt(other_0));
      scale_0 = checkedRoundingScale(tmp_0, tmp$ret$1);
      value = roundedDivide(Companion_getInstance(), value, tenPow(Companion_getInstance(), fromInt(drop)), mc.pl_1);
      drop = value.vi() - mc.ol_1 | 0;
    }
    return BigDecimal_init_$Create$_0(value, scale_0);
  }
  function setScaleValue($this, newScale, roundingMode) {
    if ($this.kk_1 === newScale)
      return $this;
    if ($this.ui() === 0)
      return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, newScale);
    var tmp0 = fromInt(newScale);
    // Inline function 'kotlin.Long.minus' call
    var other = $this.kk_1;
    var shift = subtract(tmp0, fromInt(other));
    if ($this.nk_1 === 1 && getKClassFromExpression($this).equals(getKClass(BigDecimal))) {
      var compact = compactValue529($this);
      if (compare(shift, new Long(0, 0)) <= 0)
        return BigDecimal_init_$Create$(roundedCompactPower529($this, compact, negate(shift), roundingMode), newScale);
      var scaled = scaledCompact529($this, compact, shift);
      if (!(scaled == null))
        return BigDecimal_init_$Create$(scaled, newScale);
    }
    var coefficient = coefficientSnapshot($this);
    var tmp;
    if (compare(shift, new Long(0, 0)) > 0) {
      var distance = checkedScale(Companion_getInstance(), shift);
      if (distance > 646456992)
        throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
      tmp = coefficient.hk(tenPow(Companion_getInstance(), shift));
    } else {
      var digits = fromInt(storedPrecision($this));
      tmp = compare(negate(shift), digits) > 0 ? roundTiny(Companion_getInstance(), $this.ui(), roundingMode) : equalsLong(negate(shift), digits) ? roundSubunitCoefficient($this, negate(shift), roundingMode) : roundedDivide(Companion_getInstance(), coefficient, tenPow(Companion_getInstance(), negate(shift)), roundingMode);
    }
    var value = tmp;
    return BigDecimal_init_$Create$_0(value, newScale);
  }
  function roundSubunitCoefficient($this, digits, mode) {
    var coefficient = coefficientSnapshot($this);
    var tmp = coefficient.xk();
    var tmp_0 = Companion_getInstance();
    // Inline function 'kotlin.Long.minus' call
    var tmp$ret$0 = subtract(digits, fromInt(1));
    var qr = tmp.wk(tenPow(tmp_0, tmp$ret$0));
    var leadingHalf = qr[0].zk(Companion_getInstance_1().fk(new Long(5, 0)));
    var half = leadingHalf === 0 && !(qr[1].ui() === 0) ? 1 : leadingHalf;
    var sign = coefficient.ui();
    return increment(Companion_getInstance(), mode, sign, half, false) ? Companion_getInstance_1().fk(fromInt(sign)) : Companion_getInstance_1().yj_1;
  }
  function stripTo($this, minScale, failOnOverflow) {
    failOnOverflow = failOnOverflow === VOID ? false : failOnOverflow;
    var scale = $this.kk_1;
    if ($this.nk_1 === 1) {
      var unscaled = compactValue529($this);
      while (!equalsLong(unscaled, new Long(0, 0)) && scale > minScale && equalsLong(modulo(unscaled, new Long(10, 0)), new Long(0, 0))) {
        unscaled = divide(unscaled, new Long(10, 0));
        scale = scale - 1 | 0;
      }
      if (failOnOverflow && scale === -2147483648 && !equalsLong(unscaled, new Long(0, 0)) && equalsLong(modulo(unscaled, new Long(10, 0)), new Long(0, 0)))
        throw ArithmeticException_init_$Create$('Overflow');
      return scale === $this.kk_1 ? $this : BigDecimal_init_$Create$(unscaled, scale);
    }
    var value = coefficientSnapshot($this);
    if (!(value.ui() === 0) && scale > minScale) {
      var qr = value.wk(Companion_getInstance_1().bk_1);
      if (qr[1].ui() === 0) {
        value = qr[0];
        scale = scale - 1 | 0;
        var twos = value.vl();
        $l$loop_0: while (scale > minScale && twos > 0) {
          var tmp0 = new Long(9, 0);
          // Inline function 'kotlin.Long.minus' call
          var this_0 = fromInt(scale);
          var tmp2 = subtract(this_0, fromInt(minScale));
          // Inline function 'kotlin.comparisons.minOf' call
          // Inline function 'kotlin.comparisons.minOf' call
          var b = fromInt(twos);
          // Inline function 'kotlin.comparisons.minOf' call
          var b_0 = compare(tmp2, b) <= 0 ? tmp2 : b;
          var tmp$ret$1 = compare(tmp0, b_0) <= 0 ? tmp0 : b_0;
          var chunk = convertToInt(tmp$ret$1);
          var remainder = ensureNotNull(value.xl(tenPow(Companion_getInstance(), fromInt(chunk))).vk());
          var exact = chunk;
          if (!equalsLong(remainder, new Long(0, 0))) {
            var low = remainder;
            exact = 0;
            while (equalsLong(modulo(low, new Long(10, 0)), new Long(0, 0))) {
              low = divide(low, new Long(10, 0));
              exact = exact + 1 | 0;
            }
          }
          if (exact === 0)
            break $l$loop_0;
          value = value.ul(tenPow(Companion_getInstance(), fromInt(exact)));
          scale = scale - exact | 0;
          twos = twos - exact | 0;
          if (exact < chunk)
            break $l$loop_0;
        }
      }
    }
    if (failOnOverflow && scale === -2147483648 && !(value.ui() === 0) && value.xl(Companion_getInstance_1().bk_1).ui() === 0)
      throw ArithmeticException_init_$Create$('Overflow');
    return scale === $this.kk_1 ? $this : BigDecimal_init_$Create$_0(value, scale);
  }
  function movePoint($this, scale) {
    var coefficient = coefficientSnapshot($this);
    if (equalsLong(scale, fromInt($this.kk_1)) && $this.kk_1 >= 0)
      return $this;
    var result = BigDecimal_init_$Create$_0(coefficient, scaleForValue(Companion_getInstance(), scale, coefficient.ui() === 0));
    return result.kk_1 < 0 ? result.rl(0) : result;
  }
  function finiteExactSquareRoot($this) {
    var coefficient = coefficientSnapshot($this);
    if (coefficient.ui() <= 0)
      return null;
    var odd = !(($this.kk_1 & 1) === 0);
    var tmp;
    if (odd) {
      var qr = coefficient.wk(Companion_getInstance_1().bk_1);
      if (!(qr[1].ui() === 0))
        return null;
      tmp = qr[0];
    } else {
      tmp = coefficient;
    }
    var integer = tmp;
    var root = integer.am();
    if (!(root[1].ui() === 0))
      return null;
    var tmp_0;
    if (odd) {
      // Inline function 'kotlin.Long.minus' call
      var this_0 = fromInt($this.kk_1);
      // Inline function 'kotlin.Long.div' call
      var this_1 = subtract(this_0, fromInt(1));
      tmp_0 = divide(this_1, fromInt(2));
    } else {
      // Inline function 'kotlin.Long.div' call
      var this_2 = fromInt($this.kk_1);
      tmp_0 = divide(this_2, fromInt(2));
    }
    var scale = tmp_0;
    return to(root[0], checkedScale(Companion_getInstance(), scale));
  }
  function finiteSquareRootResult($this, root, context, preferred) {
    var rounded = roundValue(BigDecimal_init_$Create$_0(root.dd_1, root.ed_1), context);
    var tmp;
    if (context.ol_1 === 0) {
      tmp = preferred;
    } else {
      var tmp0 = fromInt(preferred);
      var tmp0_0 = fromInt(rounded.kk_1);
      // Inline function 'kotlin.Long.plus' call
      var other = context.ol_1;
      var tmp0_1 = add(tmp0_0, fromInt(other));
      // Inline function 'kotlin.Long.minus' call
      var other_0 = storedPrecision(rounded);
      // Inline function 'kotlin.comparisons.minOf' call
      var b = subtract(tmp0_1, fromInt(other_0));
      var tmp$ret$2 = compare(tmp0, b) <= 0 ? tmp0 : b;
      tmp = convertToInt(tmp$ret$2);
    }
    var target = tmp;
    return rounded.kk_1 < target ? setScaleValue(rounded, target, RoundingMode_UNNECESSARY_getInstance()) : rounded;
  }
  function compareMagnitude($this, other) {
    if ($this.nk_1 === 1 && other.nk_1 === 1) {
      var left = compactValue529($this);
      var right = compactValue529(other);
      if (equalsLong(left, new Long(0, 0)) || equalsLong(right, new Long(0, 0)))
        return compareTo(equalsLong(left, new Long(0, 0)) ? 0 : 1, equalsLong(right, new Long(0, 0)) ? 0 : 1);
      var negativeLeft = compare(left, new Long(0, 0)) > 0 ? negate(left) : left;
      var negativeRight = compare(right, new Long(0, 0)) > 0 ? negate(right) : right;
      if ($this.kk_1 === other.kk_1)
        return negativeRight.t2(negativeLeft);
      var exponent = adjustedExponent($this).t2(adjustedExponent(other));
      if (!(exponent === 0))
        return exponent;
      return CompactInteger529_getInstance().zl(left, right);
    }
    var coefficient = coefficientSnapshot($this);
    var otherCoefficient529 = coefficientSnapshot(other);
    var left_0 = coefficient.xk();
    var right_0 = otherCoefficient529.xk();
    if (left_0.ui() === 0 || right_0.ui() === 0)
      return compareTo(left_0.ui(), right_0.ui());
    if ($this.kk_1 === other.kk_1)
      return left_0.zk(right_0);
    var exponent_0 = adjustedExponent($this).t2(adjustedExponent(other));
    if (!(exponent_0 === 0))
      return exponent_0;
    return left_0.wi(right_0);
  }
  function compactExactQuotient529($this, divisor) {
    if (!getKClassFromExpression($this).equals(getKClass(BigDecimal)) || !getKClassFromExpression(divisor).equals(getKClass(BigDecimal)) || !($this.nk_1 === 1) || !(divisor.nk_1 === 1))
      return null;
    var a = compactValue529($this);
    var b = compactValue529(divisor);
    if (equalsLong(a, new Long(0, 0)) || equalsLong(b, new Long(0, 0)))
      return null;
    var x = compare(a, new Long(0, 0)) > 0 ? negate(a) : a;
    var y = compare(b, new Long(0, 0)) > 0 ? negate(b) : b;
    while (!equalsLong(y, new Long(0, 0))) {
      var remainder = modulo(x, y);
      x = y;
      y = remainder;
    }
    if (equalsLong(x, new Long(-1, -1)) && (equalsLong(a, new Long(0, -2147483648)) || equalsLong(b, new Long(0, -2147483648))))
      return null;
    var numerator = divide(a, x);
    var denominator = divide(b, x);
    if (compare(denominator, new Long(0, 0)) < 0) {
      if (equalsLong(numerator, new Long(0, -2147483648)) || equalsLong(denominator, new Long(0, -2147483648)))
        return null;
      numerator = negate(numerator);
      denominator = negate(denominator);
    }
    var twos = countTrailingZeroBits(denominator);
    denominator = shiftRightUnsigned(denominator, twos);
    var fives = 0;
    $l$loop: while (true) {
      // Inline function 'kotlin.Long.rem' call
      var this_0 = denominator;
      var tmp$ret$0 = modulo(this_0, fromInt(5));
      if (!equalsLong(tmp$ret$0, new Long(0, 0))) {
        break $l$loop;
      }
      // Inline function 'kotlin.Long.div' call
      var this_1 = denominator;
      denominator = divide(this_1, fromInt(5));
      fives = fives + 1 | 0;
    }
    if (!equalsLong(denominator, new Long(1, 0)))
      return null;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_0 = fives;
    var digits = Math.max(twos, b_0);
    // Inline function 'kotlin.repeat' call
    var times = digits - twos | 0;
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var next = multiply(numerator, new Long(2, 0));
        if (!CompactInteger529_getInstance().sl(numerator, new Long(2, 0), next))
          return null;
        numerator = next;
      }
       while (inductionVariable < times);
    // Inline function 'kotlin.repeat' call
    var times_0 = digits - fives | 0;
    var inductionVariable_0 = 0;
    if (inductionVariable_0 < times_0)
      do {
        var index_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        var next_0 = multiply(numerator, new Long(5, 0));
        if (!CompactInteger529_getInstance().sl(numerator, new Long(5, 0), next_0))
          return null;
        numerator = next_0;
      }
       while (inductionVariable_0 < times_0);
    var tmp0 = fromInt($this.kk_1);
    // Inline function 'kotlin.Long.minus' call
    var other = divisor.kk_1;
    // Inline function 'kotlin.Long.plus' call
    var this_2 = subtract(tmp0, fromInt(other));
    var scale = add(this_2, fromInt(digits));
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false))
      return null;
    return BigDecimal_init_$Create$(numerator, convertToInt(scale));
  }
  function compactProductEquals529($this, quotient, divisor) {
    if (!(quotient.nk_1 === 1))
      return null;
    var q = compactValue529(quotient);
    var d = compactValue529(divisor);
    var product = multiply(q, d);
    if (!CompactInteger529_getInstance().sl(q, d, product))
      return null;
    var tmp0 = fromInt(quotient.kk_1);
    // Inline function 'kotlin.Long.plus' call
    var other = divisor.kk_1;
    var productScale = add(tmp0, fromInt(other));
    // Inline function 'kotlin.comparisons.maxOf' call
    var a = fromInt($this.kk_1);
    var commonScale = compare(a, productScale) >= 0 ? a : productScale;
    var tmp = compactValue529($this);
    // Inline function 'kotlin.Long.minus' call
    var other_0 = $this.kk_1;
    var tmp$ret$2 = subtract(commonScale, fromInt(other_0));
    var tmp0_elvis_lhs = scaledCompact529($this, tmp, tmp$ret$2);
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      return null;
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    var left = tmp_0;
    var tmp1_elvis_lhs = scaledCompact529($this, product, subtract(commonScale, productScale));
    var tmp_1;
    if (tmp1_elvis_lhs == null) {
      return null;
    } else {
      tmp_1 = tmp1_elvis_lhs;
    }
    var right = tmp_1;
    return equalsLong(left, right);
  }
  function compactQuotient529($this, divisor, scale, mode) {
    if (!getKClassFromExpression($this).equals(getKClass(BigDecimal)) || !getKClassFromExpression(divisor).equals(getKClass(BigDecimal)) || !($this.nk_1 === 1) || !(divisor.nk_1 === 1))
      return null;
    var a = compactValue529($this);
    var b = compactValue529(divisor);
    if (equalsLong(b, new Long(0, 0)))
      return null;
    var tmp0 = fromInt(scale);
    // Inline function 'kotlin.Long.plus' call
    var other = divisor.kk_1;
    var tmp0_0 = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.minus' call
    var other_0 = $this.kk_1;
    var shift = subtract(tmp0_0, fromInt(other_0));
    if (equalsLong(a, new Long(0, 0)))
      return BigDecimal_init_$Create$(new Long(0, 0), scale);
    if (compare(shift, new Long(0, 0)) >= 0) {
      var tmp0_elvis_lhs = scaledCompact529($this, a, shift);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        return null;
      } else {
        tmp = tmp0_elvis_lhs;
      }
      a = tmp;
    } else {
      var tmp1_elvis_lhs = scaledCompact529($this, b, negate(shift));
      var tmp_0;
      if (tmp1_elvis_lhs == null) {
        return null;
      } else {
        tmp_0 = tmp1_elvis_lhs;
      }
      b = tmp_0;
    }
    if (equalsLong(a, new Long(0, -2147483648)) && equalsLong(b, new Long(-1, -1)))
      return null;
    var quotient = divide(a, b);
    var remainder = modulo(a, b);
    if (equalsLong(remainder, new Long(0, 0)))
      return BigDecimal_init_$Create$(quotient, scale);
    var sign = compare(a, new Long(0, 0)) < 0 === compare(b, new Long(0, 0)) < 0 ? 1 : -1;
    var negativeRemainder = compare(remainder, new Long(0, 0)) > 0 ? negate(remainder) : remainder;
    var negativeDivisor = compare(b, new Long(0, 0)) > 0 ? negate(b) : b;
    var half = subtract(negativeDivisor, negativeRemainder).t2(negativeRemainder);
    var tmp_1;
    if (increment(Companion_getInstance(), mode, sign, half, !equalsLong(bitwiseAnd(quotient, new Long(1, 0)), new Long(0, 0)))) {
      // Inline function 'kotlin.Long.plus' call
      tmp_1 = add(quotient, fromInt(sign));
    } else {
      tmp_1 = quotient;
    }
    return BigDecimal_init_$Create$(tmp_1, scale);
  }
  function roundedCompactPower529($this, value, drop, mode) {
    if (equalsLong(drop, new Long(0, 0)) || equalsLong(value, new Long(0, 0)))
      return value;
    var sign = CompactInteger529_getInstance().hl(value);
    if (compare(drop, new Long(19, 0)) >= 0) {
      var negative = compare(value, new Long(0, 0)) > 0 ? negate(value) : value;
      var half = compare(drop, new Long(19, 0)) > 0 ? -1 : (new Long(-1156841472, -1164153219)).t2(negative);
      return increment(Companion_getInstance(), mode, sign, half, false) ? fromInt(sign) : new Long(0, 0);
    }
    var divisor = CompactInteger529_getInstance().bm(convertToInt(drop));
    var quotient = divide(value, divisor);
    var remainder = modulo(value, divisor);
    if (equalsLong(remainder, new Long(0, 0)))
      return quotient;
    var magnitude = compare(remainder, new Long(0, 0)) < 0 ? negate(remainder) : remainder;
    var half_0 = magnitude.t2(subtract(divisor, magnitude));
    var tmp;
    if (increment(Companion_getInstance(), mode, sign, half_0, !equalsLong(bitwiseAnd(quotient, new Long(1, 0)), new Long(0, 0)))) {
      // Inline function 'kotlin.Long.plus' call
      tmp = add(quotient, fromInt(sign));
    } else {
      tmp = quotient;
    }
    return tmp;
  }
  function scaledCompact529($this, value, raise) {
    if (equalsLong(value, new Long(0, 0)))
      return new Long(0, 0);
    if (compare(raise, new Long(18, 0)) > 0)
      return null;
    var result = value;
    // Inline function 'kotlin.repeat' call
    var times = convertToInt(raise);
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var next = multiply(result, new Long(10, 0));
        if (!CompactInteger529_getInstance().sl(result, new Long(10, 0), next))
          return null;
        result = next;
      }
       while (inductionVariable < times);
    return result;
  }
  function withScale529($this, scale) {
    return $this.nk_1 === 2 && !getKClassFromExpression(ensureNotNull($this.ok_1)).equals(getKClass(BigInteger)) ? BigDecimal_init_$Create$_0($this.ok_1, scale) : new BigDecimal(scale, $this.lk_1, $this.mk_1, $this.nk_1, $this.ok_1);
  }
  function adjustedExponent($this) {
    var tmp0 = fromInt($this.ql());
    // Inline function 'kotlin.Long.minus' call
    var other = $this.kk_1;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    return subtract(this_0, fromInt(1));
  }
  function scaledCoefficient($this, scale) {
    var coefficient = coefficientSnapshot($this);
    if (coefficient.ui() === 0)
      return coefficient;
    var tmp = Companion_getInstance();
    var tmp0 = fromInt(scale);
    // Inline function 'kotlin.Long.minus' call
    var other = $this.kk_1;
    var tmp$ret$0 = subtract(tmp0, fromInt(other));
    var distance = checkedScale(tmp, tmp$ret$0);
    return coefficient.hk(tenPow(Companion_getInstance(), fromInt(distance)));
  }
  function legacyText537($this, format) {
    var tmp;
    switch (format.l2_1) {
      case 0:
        tmp = $this.toString();
        break;
      case 1:
        tmp = $this.cm();
        break;
      case 2:
        tmp = $this.dm();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function textLayout537($this, format, maxChars) {
    var sign = storedSign529($this);
    var prefix = sign < 0 ? new Long(1, 0) : new Long(0, 0);
    var lowerDigits = $this.nk_1 === 1 ? fromInt(CompactInteger529_getInstance().jl(compactValue529($this))) : fromInt(ensureNotNull($this.ok_1).em());
    var tmp;
    if (format.equals(DecimalTextFormat_PLAIN_getInstance()) && $this.kk_1 < 0 && sign === 0) {
      tmp = new Long(1, 0);
    } else if (format.equals(DecimalTextFormat_PLAIN_getInstance()) && $this.kk_1 <= 0) {
      tmp = add(subtract(lowerDigits, fromInt($this.kk_1)), prefix);
    } else if (format.equals(DecimalTextFormat_PLAIN_getInstance())) {
      // Inline function 'kotlin.Long.plus' call
      var tmp0 = add(lowerDigits, fromInt(1));
      // Inline function 'kotlin.Long.plus' call
      var this_0 = fromInt($this.kk_1);
      // Inline function 'kotlin.comparisons.maxOf' call
      var b = add(this_0, fromInt(2));
      var tmp$ret$2 = compare(tmp0, b) >= 0 ? tmp0 : b;
      tmp = add(tmp$ret$2, prefix);
    } else {
      tmp = add(lowerDigits, prefix);
    }
    var lowerLength = tmp;
    checkTextLimit537(lowerLength, maxChars);
    var tmp_0;
    if ($this.nk_1 === 1) {
      var tmp_1 = Companion_getInstance_1();
      var tmp_2 = compactValue529($this);
      tmp_0 = tmp_1.gm(tmp_2, 10, maxChars == null ? null : subtract(maxChars, prefix));
    } else {
      var tmp_3 = ensureNotNull($this.ok_1);
      tmp_0 = tmp_3.fm(10, maxChars == null ? null : subtract(maxChars, prefix));
    }
    var digits = tmp_0;
    var layout = new DecimalLayout537(digits, $this.kk_1, sign < 0, format);
    checkTextLimit537(layout.sm_1, maxChars);
    return layout;
  }
  function canonicalStringValue($this) {
    var digits = magnitudeDigits529($this);
    var sign = layoutSign($this);
    var tmp0 = fromInt(digits.length);
    // Inline function 'kotlin.Long.minus' call
    var other = $this.kk_1;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    var exponent = subtract(this_0, fromInt(1));
    if ($this.kk_1 >= 0 && compare(exponent, new Long(-6, -1)) >= 0)
      return canonicalPlain($this, digits, sign);
    var tmp;
    if (digits.length === 1) {
      tmp = digits;
    } else {
      // Inline function 'kotlin.text.plus' call
      var this_1 = charCodeAt(digits, 0);
      tmp = toString(this_1) + '.' + substring(digits, 1);
    }
    var body = tmp;
    return (sign < 0 ? '-' : '') + body + exponentText(Companion_getInstance(), exponent);
  }
  function magnitudeDigits529($this) {
    return $this.nk_1 === 1 ? removePrefix(compactValue529($this).toString(), '-') : ensureNotNull($this.ok_1).xk().toString();
  }
  function layoutSign($this) {
    var compact = $this.nk_1 === 1 && !equalsLong(compactValue529($this), new Long(0, -2147483648)) ? compactValue529($this) : null;
    var directSign = $this.kk_1 === 0 || ($this.kk_1 === 2 && !(compact == null) && compare(compact, new Long(0, 0)) >= 0 && compare(compact, new Long(2147483647, 0)) < 0);
    return directSign ? storedSign529($this) : $this.ui();
  }
  function canonicalPlain($this, digits, sign) {
    if (compare(plainStringLength($this, digits.length, sign), new Long(2147483647, 0)) > 0) {
      plainStringTooLarge();
    }
    var body = $this.kk_1 === 0 ? digits : $this.kk_1 < digits.length ? substring_0(digits, 0, digits.length - $this.kk_1 | 0) + '.' + substring(digits, digits.length - $this.kk_1 | 0) : '0.' + repeat('0', $this.kk_1 - digits.length | 0) + digits;
    return (sign < 0 ? '-' : '') + body;
  }
  function plainStringLength($this, digits, sign) {
    var signLength = sign < 0 ? new Long(1, 0) : new Long(0, 0);
    return add(signLength, $this.kk_1 <= 0 ? subtract(fromInt(digits), fromInt($this.kk_1)) : $this.kk_1 < digits ? add(fromInt(digits), new Long(1, 0)) : add(fromInt($this.kk_1), new Long(2, 0)));
  }
  function integerLowBits($this, bits) {
    if ($this.nk_1 === 1 && getKClassFromExpression($this).equals(getKClass(BigDecimal))) {
      var value = compactValue529($this);
      if ($this.kk_1 >= 19)
        return new Long(0, 0);
      if ($this.kk_1 > 0) {
        // Inline function 'kotlin.repeat' call
        var times = $this.kk_1;
        var inductionVariable = 0;
        if (inductionVariable < times)
          do {
            var index = inductionVariable;
            inductionVariable = inductionVariable + 1 | 0;
            value = divide(value, new Long(10, 0));
          }
           while (inductionVariable < times);
      }
      if ($this.kk_1 < 0) {
        var raise = negate(fromInt($this.kk_1));
        if (compare(raise, fromInt(bits)) >= 0)
          return new Long(0, 0);
        // Inline function 'kotlin.repeat' call
        var times_0 = convertToInt(raise);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < times_0)
          do {
            var index_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            value = multiply(value, new Long(10, 0));
          }
           while (inductionVariable_0 < times_0);
      }
      return bits === 32 ? fromInt(convertToInt(value)) : value;
    }
    var coefficient = coefficientSnapshot($this);
    if ($this.kk_1 >= 0)
      return $this.tm().um();
    if (compare(negate(fromInt($this.kk_1)), fromInt(bits)) >= 0)
      return new Long(0, 0);
    var raise_0 = negate(fromInt($this.kk_1));
    if (!coefficient.wm(convertToInt(raise_0)))
      return coefficient.vm(convertToInt(raise_0), bits);
    return coefficient.hk(tenPow(Companion_getInstance(), negate(fromInt($this.kk_1)))).um();
  }
  function narrowExact($this, minimum, maximum) {
    var value = $this.xm();
    if (compare(value, minimum) < 0 || compare(value, maximum) > 0)
      throw ArithmeticException_init_$Create$('Overflow');
    return value;
  }
  function binaryValue($this, precision, minExponent, maxExponent) {
    var coefficient = coefficientSnapshot($this);
    var compact = coefficient.vk();
    if (equals(compact, new Long(0, 0)))
      return 0.0;
    var tmp;
    if (compact == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = precision === 24 ? Companion_getInstance_1().fk(compact).ym() : toNumber(compact);
    }
    var compactPrimitive = tmp;
    var maxCompactScale = precision === 24 ? new Long(10, 0) : new Long(22, 0);
    var tmp_0;
    if (!(compact == null)) {
      var tmp_1;
      if ($this.kk_1 === 0) {
        tmp_1 = true;
      } else {
        var tmp_2;
        var containsLower = negate(maxCompactScale);
        var containsArg = fromInt($this.kk_1);
        if (compare(containsLower, containsArg) <= 0 ? compare(containsArg, maxCompactScale) <= 0 : false) {
          tmp_2 = numberToLong(ensureNotNull(compactPrimitive)).equals(compact);
        } else {
          tmp_2 = false;
        }
        tmp_1 = tmp_2;
      }
      tmp_0 = tmp_1;
    } else {
      tmp_0 = false;
    }
    var compactPath = tmp_0;
    var resultSign = compactPath ? ensureNotNull(compact).t2(new Long(0, 0)) : $this.ui();
    var tmp0 = fromInt(coefficient.em());
    // Inline function 'kotlin.Long.minus' call
    var other = $this.kk_1;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    var lowerExponent = subtract(this_0, fromInt(1));
    if (compare(lowerExponent, new Long(400, 0)) > 0)
      return resultSign * Infinity;
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$4 = add(lowerExponent, fromInt(1));
    if (compare(tmp$ret$4, new Long(-400, -1)) < 0)
      return resultSign * 0.0;
    var tmp0_0 = (precision - minExponent | 0) + ((precision + 3 | 0) / 3 | 0) | 0;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = (maxExponent + 3 | 0) / 3 | 0;
    var midpointDigits = Math.max(tmp0_0, b);
    var prefix = coefficient.zm(midpointDigits);
    var tmp0_1 = fromInt(prefix.bn_1);
    // Inline function 'kotlin.Long.minus' call
    var other_0 = $this.kk_1;
    // Inline function 'kotlin.Long.minus' call
    var this_1 = subtract(tmp0_1, fromInt(other_0));
    var decimalExponent = subtract(this_1, fromInt(1));
    if (compare(decimalExponent, new Long(400, 0)) > 0)
      return resultSign * Infinity;
    if (compare(decimalExponent, new Long(-400, -1)) < 0)
      return resultSign * 0.0;
    var magnitude = prefix.dn_1 ? prefix.an_1.hk(Companion_getInstance_1().bk_1).al(Companion_getInstance_1().zj_1) : prefix.an_1;
    var tmp0_2 = fromInt($this.kk_1);
    // Inline function 'kotlin.Long.minus' call
    var other_1 = prefix.cn_1;
    var tmp0_3 = subtract(tmp0_2, fromInt(other_1));
    // Inline function 'kotlin.Long.plus' call
    var other_2 = prefix.dn_1 ? 1 : 0;
    var scale = add(tmp0_3, fromInt(other_2));
    var numerator = compare(scale, new Long(0, 0)) < 0 ? magnitude.hk(tenPow(Companion_getInstance(), negate(scale))) : magnitude;
    var denominator = compare(scale, new Long(0, 0)) > 0 ? tenPow(Companion_getInstance(), scale) : Companion_getInstance_1().zj_1;
    var exponent = numerator.en() - denominator.en() | 0;
    if (exponent >= 0) {
      if (numerator.zk(denominator.ik(exponent)) < 0) {
        exponent = exponent - 1 | 0;
      }
    } else if (numerator.ik(-exponent | 0).zk(denominator) < 0) {
      exponent = exponent - 1 | 0;
    }
    if (exponent > maxExponent)
      return resultSign * Infinity;
    var tmp_3 = precision - 1 | 0;
    // Inline function 'kotlin.comparisons.maxOf' call
    var a = exponent;
    var shift = tmp_3 - Math.max(a, minExponent) | 0;
    var top = shift >= 0 ? roundedDivide(Companion_getInstance(), numerator.ik(shift), denominator, RoundingMode_HALF_EVEN_getInstance()) : roundedDivide(Companion_getInstance(), numerator, denominator.ik(-shift | 0), RoundingMode_HALF_EVEN_getInstance());
    var tmp_4 = resultSign * toNumber(top.um());
    // Inline function 'kotlin.math.pow' call
    var n = -shift | 0;
    return tmp_4 * Math.pow(2.0, n);
  }
  function Companion() {
    Companion_instance_0 = this;
    this.hj_1 = new Long(-108976049, 1422333271);
    this.ij_1 = BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, 0);
    this.jj_1 = BigDecimal_init_$Create$_0(Companion_getInstance_1().zj_1, 0);
    this.kj_1 = BigDecimal_init_$Create$_0(Companion_getInstance_1().ak_1, 0);
    this.lj_1 = BigDecimal_init_$Create$_0(Companion_getInstance_1().bk_1, 0);
    this.mj_1 = 0;
    this.nj_1 = 1;
    this.oj_1 = 2;
    this.pj_1 = 3;
    this.qj_1 = 4;
    this.rj_1 = 5;
    this.sj_1 = 6;
    this.tj_1 = 7;
    var tmp = this;
    var tmp_0 = 0;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(19);
    while (tmp_0 < 19) {
      var tmp_2 = tmp_0;
      tmp_1[tmp_2] = Companion_getInstance_1().fk(CompactInteger529_getInstance().bm(tmp_2));
      tmp_0 = tmp_0 + 1 | 0;
    }
    tmp.uj_1 = tmp_1;
  }
  protoOf(Companion).fk = function (value) {
    return BigDecimal_init_$Create$_5(value);
  };
  protoOf(Companion).fn = function (unscaledVal, scale) {
    return BigDecimal_init_$Create$(unscaledVal, scale);
  };
  protoOf(Companion).gn = function (value) {
    return BigDecimal_init_$Create$_8(decimalDoubleString(value));
  };
  protoOf(Companion).hn = function (value, mc) {
    return DecimalText588_getInstance().in(value, 0, charSequenceLength(value), mc);
  };
  protoOf(Companion).jn = function (value, mc, $super) {
    mc = mc === VOID ? Companion_getInstance_4().yi_1 : mc;
    return $super === VOID ? this.hn(value, mc) : $super.hn.call(this, value, mc);
  };
  protoOf(Companion).kn = function (value, offset, length, mc) {
    return DecimalText588_getInstance().in(value, offset, length, mc);
  };
  protoOf(Companion).ln = function (value, offset, length, mc, $super) {
    mc = mc === VOID ? Companion_getInstance_4().yi_1 : mc;
    return $super === VOID ? this.kn(value, offset, length, mc) : $super.kn.call(this, value, offset, length, mc);
  };
  protoOf(Companion).mn = function (value, offset, length, maxInputChars, mc) {
    return DecimalText588_getInstance().nn(value, offset, length, maxInputChars, mc);
  };
  protoOf(Companion).on = function (value, offset, length, maxInputChars, mc, $super) {
    mc = mc === VOID ? Companion_getInstance_4().yi_1 : mc;
    return $super === VOID ? this.mn(value, offset, length, maxInputChars, mc) : $super.mn.call(this, value, offset, length, maxInputChars, mc);
  };
  protoOf(Companion).pn = function (value, offset, length, maxInputChars, mc) {
    return DecimalText588_getInstance().qn(value, offset, length, maxInputChars, mc);
  };
  protoOf(Companion).rn = function (value, offset, length, maxInputChars, mc, $super) {
    mc = mc === VOID ? Companion_getInstance_4().yi_1 : mc;
    return $super === VOID ? this.pn(value, offset, length, maxInputChars, mc) : $super.pn.call(this, value, offset, length, maxInputChars, mc);
  };
  var Companion_instance_0;
  function Companion_getInstance() {
    if (Companion_instance_0 == null)
      new Companion();
    return Companion_instance_0;
  }
  function BigDecimal(decimalScale, compactHigh, compactLow, representation, wideCoefficient) {
    Companion_getInstance();
    Number_0.call(this);
    this.kk_1 = decimalScale;
    this.lk_1 = compactHigh;
    this.mk_1 = compactLow;
    this.nk_1 = representation;
    this.ok_1 = wideCoefficient;
    this.pk_1 = 0;
    this.qk_1 = null;
  }
  protoOf(BigDecimal).dl = function () {
    return this.nk_1 === 1;
  };
  protoOf(BigDecimal).sn = function () {
    return getKClassFromExpression(this).equals(getKClass(BigDecimal)) && this.nk_1 === 1 && !equalsLong(compactValue529(this), new Long(0, -2147483648));
  };
  protoOf(BigDecimal).tn = function () {
    return compactValue529(this);
  };
  protoOf(BigDecimal).un = function () {
    return coefficientSnapshot(this);
  };
  protoOf(BigDecimal).vn = function () {
    return this.kk_1;
  };
  protoOf(BigDecimal).ql = function () {
    return storedPrecision(this);
  };
  protoOf(BigDecimal).ui = function () {
    return storedSign529(this);
  };
  protoOf(BigDecimal).xk = function () {
    return this.ui() < 0 ? this.jk() : this;
  };
  protoOf(BigDecimal).wn = function (mc) {
    return this.ui() < 0 ? this.xn(mc) : contextualUnaryRound(this, mc);
  };
  protoOf(BigDecimal).jk = function () {
    return this.nk_1 === 1 && !equalsLong(compactValue529(this), new Long(0, -2147483648)) ? BigDecimal_init_$Create$(negate(compactValue529(this)), this.kk_1) : BigDecimal_init_$Create$_0(coefficientSnapshot(this).jk(), this.kk_1);
  };
  protoOf(BigDecimal).xn = function (mc) {
    return contextualUnaryRound(this.jk(), mc);
  };
  protoOf(BigDecimal).yn = function () {
    return this;
  };
  protoOf(BigDecimal).kl = function (mc) {
    var result = roundValue(this, mc);
    return storedSign529(result) === 0 ? Companion_getInstance().ij_1 : result;
  };
  protoOf(BigDecimal).zn = function (augend) {
    var tmp0_elvis_lhs = rawSum585(this, augend, false, null);
    return tmp0_elvis_lhs == null ? addValue(this, augend) : tmp0_elvis_lhs;
  };
  protoOf(BigDecimal).ao = function (augend, mc) {
    var context = mc;
    if (context.ol_1 === 0)
      return this.zn(augend);
    return addContextValue(this, augend, context);
  };
  protoOf(BigDecimal).bo = function (subtrahend) {
    var operand = subtrahend;
    var tmp0_safe_receiver = rawSum585(this, operand, true, null);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var tmp0 = this.kk_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = operand.kk_1;
    var scale = Math.max(tmp0, b);
    return BigDecimal_init_$Create$_0(scaledCoefficient(this, scale).yk(scaledCoefficient(operand, scale)), scale);
  };
  protoOf(BigDecimal).co = function (subtrahend, mc) {
    var context = mc;
    return context.ol_1 === 0 ? this.bo(subtrahend) : this.ao(subtrahend.jk(), context);
  };
  protoOf(BigDecimal).do = function (multiplicand) {
    return multiplyValue(this, multiplicand);
  };
  protoOf(BigDecimal).eo = function (multiplicand, mc) {
    var context = mc;
    if (context.ol_1 === 0)
      return this.do(multiplicand);
    var operand = multiplicand;
    var tmp0 = fromInt(this.kk_1);
    // Inline function 'kotlin.Long.plus' call
    var other = operand.kk_1;
    var logicalScale = add(tmp0, fromInt(other));
    if (this.nk_1 === 1 && operand.nk_1 === 1) {
      var a = compactValue529(this);
      var b = compactValue529(operand);
      var product = multiply(a, b);
      if (CompactInteger529_getInstance().sl(a, b, product)) {
        if (compare(logicalScale, new Long(2147483647, 0)) <= 0 || equalsLong(a, new Long(0, 0)) || equalsLong(b, new Long(0, 0)))
          return roundValue(BigDecimal_init_$Create$(product, scaleForValue(Companion_getInstance(), logicalScale, equalsLong(a, new Long(0, 0)))), context);
        var neutral = BigDecimal_init_$Create$(product, 0);
        if (storedPrecision(neutral) <= context.ol_1) {
          checkedScale(Companion_getInstance(), logicalScale);
        }
        var rounded = neutral.rk(context);
        var tmp = Companion_getInstance();
        // Inline function 'kotlin.Long.plus' call
        var other_0 = rounded.kk_1;
        var tmp$ret$1 = add(logicalScale, fromInt(other_0));
        return withScale529(rounded, checkedScale(tmp, tmp$ret$1));
      }
    }
    var coefficient = coefficientSnapshot(this);
    var operandCoefficient = coefficientSnapshot(operand);
    if (compare(logicalScale, new Long(2147483647, 0)) <= 0 || coefficient.ui() === 0 || operandCoefficient.ui() === 0) {
      var scale = scaleForValue(Companion_getInstance(), logicalScale, coefficient.ui() === 0);
      var raw = coefficient.fo(operandCoefficient, fromInt(scale), context);
      if (!(raw == null))
        return BigDecimal_init_$Create$_0(raw.dd_1, raw.ed_1);
      return roundValue(BigDecimal_init_$Create$_0(coefficient.hk(operandCoefficient), scale), context);
    }
    var raw_0 = coefficient.fo(operandCoefficient, logicalScale, context);
    if (!(raw_0 == null))
      return BigDecimal_init_$Create$_0(raw_0.dd_1, raw_0.ed_1);
    var product_0 = BigDecimal_init_$Create$_0(coefficient.hk(operandCoefficient), 0);
    if (storedPrecision(product_0) <= context.ol_1) {
      checkedScale(Companion_getInstance(), logicalScale);
    }
    var rounded_0 = product_0.rk(context);
    var tmp_0 = coefficientSnapshot(rounded_0);
    var tmp_1 = Companion_getInstance();
    // Inline function 'kotlin.Long.plus' call
    var other_1 = rounded_0.kk_1;
    var tmp$ret$2 = add(logicalScale, fromInt(other_1));
    return BigDecimal_init_$Create$_0(tmp_0, checkedScale(tmp_1, tmp$ret$2));
  };
  protoOf(BigDecimal).go = function (divisor) {
    var operand = divisor;
    checkDivisionByZero(this, operand);
    var tmp;
    try {
      tmp = divideExactly(this, operand);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var _unused_var__etf5q3 = $p;
        throw ArithmeticException_init_$Create$('Non-terminating decimal expansion; no exact representable decimal result.');
      } else {
        throw $p;
      }
    }
    return tmp;
  };
  protoOf(BigDecimal).ho = function (divisor, roundingMode) {
    return this.io(divisor, this.kk_1, roundingMode);
  };
  protoOf(BigDecimal).jo = function (divisor, roundingMode) {
    var mode = Companion_instance_7.ko(roundingMode);
    return this.ho(divisor, mode);
  };
  protoOf(BigDecimal).lo = function (divisor, scale, roundingMode) {
    var mode = Companion_instance_7.ko(roundingMode);
    return this.io(divisor, scale, mode);
  };
  protoOf(BigDecimal).io = function (divisor, scale, roundingMode) {
    if (divisor.ui() === 0) {
      failScaledZeroDivision(this, divisor.kk_1, scale);
    }
    var tmp0_safe_receiver = compactQuotient529(this, divisor, scale, roundingMode);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var coefficient = coefficientSnapshot(this);
    var divisorCoefficient529 = coefficientSnapshot(divisor);
    var tmp0 = fromInt(scale);
    // Inline function 'kotlin.Long.plus' call
    var other = divisor.kk_1;
    var tmp0_0 = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.minus' call
    var other_0 = this.kk_1;
    var shift = subtract(tmp0_0, fromInt(other_0));
    var raw = coefficient.mo(divisorCoefficient529, shift, roundingMode);
    if (!(raw == null))
      return BigDecimal_init_$Create$_0(raw, scale);
    var tmp;
    if (!(coefficient.ui() === 0) && compare(abs(shift), new Long(646456992, 0)) > 0) {
      // Inline function 'kotlin.Long.plus' call
      var this_0 = quotientExponent(this, divisor);
      var tmp$ret$4 = add(this_0, fromInt(scale));
      tmp = compare(tmp$ret$4, new Long(-1, -1)) >= 0;
    } else {
      tmp = false;
    }
    if (tmp) {
      var tmp_0 = Companion_getInstance();
      var tmp0_1 = fromInt(scale);
      // Inline function 'kotlin.Long.plus' call
      var other_1 = divisor.kk_1;
      var tmp$ret$5 = add(tmp0_1, fromInt(other_1));
      scaleForValue(tmp_0, tmp$ret$5, false);
      if (compare(shift, new Long(0, 0)) <= 0) {
        var tmp_1 = Companion_getInstance();
        // Inline function 'kotlin.Long.minus' call
        var this_1 = fromInt(this.kk_1);
        var tmp$ret$6 = subtract(this_1, fromInt(scale));
        scaleForValue(tmp_1, tmp$ret$6, false);
      }
    }
    return divideScaledCoefficients(this, divisor, coefficient, divisorCoefficient529, scale, roundingMode, compare(shift, new Long(0, 0)) >= 0, abs(shift));
  };
  protoOf(BigDecimal).no = function (divisor, mc) {
    var context = mc;
    if (context.ol_1 === 0)
      return this.go(divisor);
    var operand = divisor;
    checkDivisionByZero(this, operand);
    var tmp0 = fromInt(this.kk_1);
    // Inline function 'kotlin.Long.minus' call
    var other = operand.kk_1;
    var preferredScale = subtract(tmp0, fromInt(other));
    if (this.ui() === 0)
      return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, saturatedScale(Companion_getInstance(), preferredScale));
    var sourceDigits = this.ql();
    var divisorDigits = operand.ql();
    if (getKClassFromExpression(this).equals(getKClass(BigDecimal)) && getKClassFromExpression(operand).equals(getKClass(BigDecimal)) && this.nk_1 === 1 && operand.nk_1 === 1) {
      var exact = compactExactQuotient529(this, operand);
      if (!(exact == null) && storedPrecision(exact) <= context.ol_1)
        return stripTo(exact, saturatedScale(Companion_getInstance(), preferredScale));
      var normalizedCompact = CompactInteger529_getInstance().zl(compactValue529(this), compactValue529(operand));
      // Inline function 'kotlin.Long.plus' call
      var this_0 = add(preferredScale, fromInt(context.ol_1));
      // Inline function 'kotlin.Long.minus' call
      var this_1 = add(this_0, fromInt(divisorDigits));
      var tmp0_0 = subtract(this_1, fromInt(sourceDigits));
      // Inline function 'kotlin.Long.minus' call
      var other_0 = normalizedCompact > 0 ? 1 : 0;
      var targetCompact = subtract(tmp0_0, fromInt(other_0));
      if ((compare(new Long(-2147483648, -1), preferredScale) <= 0 ? compare(preferredScale, new Long(2147483647, 0)) <= 0 : false) && (compare(new Long(-2147483648, -1), targetCompact) <= 0 ? compare(targetCompact, new Long(2147483647, 0)) <= 0 : false)) {
        var tmp0_safe_receiver = compactQuotient529(this, operand, convertToInt(targetCompact), context.pl_1);
        var result = tmp0_safe_receiver == null ? null : roundValue(tmp0_safe_receiver, context);
        if (!(result == null)) {
          var exactResult = compactProductEquals529(this, result, operand);
          if (!(exactResult == null))
            return exactResult ? stripTo(result, convertToInt(preferredScale)) : result;
        }
      }
    }
    var coefficient = coefficientSnapshot(this);
    var operandCoefficient529 = coefficientSnapshot(operand);
    var normalized = compareValues(Companion_getInstance(), coefficient.xk(), fromInt(sourceDigits), operandCoefficient529.xk(), fromInt(divisorDigits));
    var adjustment = normalized > 0 ? 1 : 0;
    // Inline function 'kotlin.Long.plus' call
    var this_2 = add(preferredScale, fromInt(context.ol_1));
    // Inline function 'kotlin.Long.minus' call
    var this_3 = add(this_2, fromInt(divisorDigits));
    // Inline function 'kotlin.Long.minus' call
    var this_4 = subtract(this_3, fromInt(sourceDigits));
    var targetScale = subtract(this_4, fromInt(adjustment));
    // Inline function 'kotlin.Long.plus' call
    var other_1 = operand.kk_1;
    var tmp0_1 = add(targetScale, fromInt(other_1));
    // Inline function 'kotlin.Long.minus' call
    var other_2 = this.kk_1;
    var shift = subtract(tmp0_1, fromInt(other_2));
    var streamed = coefficient.oo(operandCoefficient529, preferredScale, targetScale, shift, sourceDigits, divisorDigits, normalized, context);
    if (!(streamed == null))
      return BigDecimal_init_$Create$_0(streamed.dd_1, streamed.ed_1);
    if ((!(compare(new Long(-2147483648, -1), preferredScale) <= 0 ? compare(preferredScale, new Long(2147483647, 0)) <= 0 : false) || !(compare(new Long(-2147483648, -1), targetScale) <= 0 ? compare(targetScale, new Long(2147483647, 0)) <= 0 : false) || compare(abs(shift), new Long(646456992, 0)) > 0) && sourceDigits === storedPrecision(this) && divisorDigits === storedPrecision(operand) && !(coefficient.ui() === 0) && !(operandCoefficient529.ui() === 0)) {
      var tmp;
      try {
        tmp = divideWideContext(this, operand, context, preferredScale, normalized, sourceDigits, divisorDigits);
      } catch ($p) {
        var tmp_0;
        if ($p instanceof ArithmeticException) {
          var failure = $p;
          divisionScale(this, targetScale);
          if (!(compare(new Long(-2147483648, -1), preferredScale) <= 0 ? compare(preferredScale, new Long(2147483647, 0)) <= 0 : false)) {
            if (compare(abs(shift), new Long(646456992, 0)) > 0)
              throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
            divisionScale(this, preferredScale);
          }
          throw failure;
        } else {
          throw $p;
        }
      }
      return tmp;
    }
    divisionScale(this, targetScale);
    if (compare(abs(shift), new Long(646456992, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    var preferred = divisionScale(this, preferredScale);
    var target = checkedScale(Companion_getInstance(), targetScale);
    var compactSource = coefficient.vk();
    var compactDivisor = operandCoefficient529.vk();
    var compactNormalization = sourceDigits <= divisorDigits && divisorDigits < 18 && context.ol_1 < 18 && !(compactSource == null) && !(compactDivisor == null);
    var tmp_1;
    if (compactNormalization) {
      var tmp_2 = ensureNotNull(compactSource);
      // Inline function 'kotlin.Long.minus' call
      var this_5 = fromInt(divisorDigits);
      var tmp$ret$9 = subtract(this_5, fromInt(sourceDigits));
      tmp_1 = normalizedCompactOverflow(this, tmp_2, tmp$ret$9);
    } else {
      tmp_1 = false;
    }
    if (tmp_1)
      return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, preferred);
    if (compactNormalization && normalized === 0) {
      var sign = !(coefficient.ui() < 0 === operandCoefficient529.ui() < 0) ? new Long(-1, -1) : new Long(1, 0);
      var tmp_3 = Companion_getInstance_1().fk(sign);
      // Inline function 'kotlin.Long.plus' call
      // Inline function 'kotlin.Long.minus' call
      var this_6 = add(preferredScale, fromInt(divisorDigits));
      var tmp$ret$11 = subtract(this_6, fromInt(sourceDigits));
      return BigDecimal_init_$Create$_0(tmp_3, divisionScale(this, tmp$ret$11));
    }
    var result_0 = roundValue(divideScaledCoefficients(this, operand, coefficient, operandCoefficient529, target, context.pl_1, compare(shift, new Long(0, 0)) >= 0, abs(shift), false), context);
    var tmp_4 = Companion_getInstance();
    var tmp_5 = coefficientSnapshot(result_0).hk(operandCoefficient529);
    var tmp0_2 = fromInt(result_0.kk_1);
    // Inline function 'kotlin.Long.plus' call
    var other_3 = operand.kk_1;
    var tmp$ret$12 = add(tmp0_2, fromInt(other_3));
    var exact_0 = compareValues(tmp_4, tmp_5, tmp$ret$12, coefficient, fromInt(this.kk_1)) === 0;
    var tmp_6;
    if (!exact_0) {
      tmp_6 = result_0;
    } else if (coefficientSnapshot(result_0).ui() === 0) {
      var tmp_7 = Companion_getInstance_1().yj_1;
      // Inline function 'kotlin.comparisons.minOf' call
      var a = result_0.kk_1;
      var tmp$ret$13 = Math.min(a, preferred);
      tmp_6 = BigDecimal_init_$Create$_0(tmp_7, tmp$ret$13);
    } else {
      tmp_6 = stripTo(result_0, preferred);
    }
    return tmp_6;
  };
  protoOf(BigDecimal).po = function (divisor) {
    var coefficient = coefficientSnapshot(this);
    var operand = divisor;
    var operandCoefficient529 = coefficientSnapshot(operand);
    var tmp = Companion_getInstance();
    var tmp0 = fromInt(this.kk_1);
    // Inline function 'kotlin.Long.minus' call
    var other = operand.kk_1;
    var tmp$ret$0 = subtract(tmp0, fromInt(other));
    var preferred = saturatedScale(tmp, tmp$ret$0);
    var magnitude = compareMagnitude(this, operand);
    if (magnitude < 0)
      return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, preferred);
    var sourceSign = this.ui();
    if (sourceSign === 0 && !(operand.ui() === 0))
      return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, preferred);
    var sourcePrecision = this.ql();
    var sourceDigits = fromInt(sourcePrecision);
    var divisorPrecision = operand.ql();
    // Inline function 'kotlin.Long.times' call
    var this_0 = new Long(10, 0);
    var divisorDigits = multiply(this_0, fromInt(divisorPrecision));
    // Inline function 'kotlin.Long.div' call
    var tmp0_0 = divide(divisorDigits, fromInt(3));
    var tmp_0;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$3 = modulo(divisorDigits, fromInt(3));
    if (compare(tmp$ret$3, new Long(0, 0)) > 0) {
      tmp_0 = 1;
    } else {
      tmp_0 = 0;
    }
    // Inline function 'kotlin.Long.plus' call
    var other_0 = tmp_0;
    var guardDigits = add(tmp0_0, fromInt(other_0));
    var sourceScale = this.vn();
    var divisorScale = operand.vn();
    var tmp_1 = add(sourceDigits, guardDigits);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(sourceScale);
    var tmp$ret$5 = subtract(this_1, fromInt(divisorScale));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = add(tmp_1, abs(tmp$ret$5));
    var digits = add(this_2, fromInt(2));
    // Inline function 'kotlin.comparisons.minOf' call
    var b = new Long(2147483647, 0);
    var tmp$ret$7 = compare(digits, b) <= 0 ? digits : b;
    var legacyContext = new MathContext(convertToInt(tmp$ret$7), RoundingMode_DOWN_getInstance());
    var integral = coefficient.qo(operandCoefficient529, this.kk_1, operand.kk_1, sourcePrecision, divisorPrecision, sourceScale, divisorScale, sourceSign, magnitude);
    if (!(integral == null))
      return BigDecimal_init_$Create$_0(integral.dd_1, integral.ed_1);
    var result = this.no(operand, legacyContext);
    if (result.kk_1 > 0) {
      result = integralStrip(result.ro(0, RoundingMode_DOWN_getInstance()), preferred, true);
    }
    return preferred > result.kk_1 ? result.so(preferred, 7) : result;
  };
  protoOf(BigDecimal).to = function (divisor, mc) {
    var coefficient = coefficientSnapshot(this);
    var context = mc;
    if (context.ol_1 === 0)
      return this.po(divisor);
    var operand = divisor;
    var operandCoefficient529 = coefficientSnapshot(operand);
    if (compareMagnitude(this, operand) < 0)
      return this.po(operand);
    var tmp = Companion_getInstance();
    var tmp0 = fromInt(this.kk_1);
    // Inline function 'kotlin.Long.minus' call
    var other = operand.kk_1;
    var tmp$ret$0 = subtract(tmp0, fromInt(other));
    var preferred = saturatedScale(tmp, tmp$ret$0);
    var result = this.no(operand, new MathContext(context.ol_1, RoundingMode_DOWN_getInstance()));
    var resultScale = result.vn();
    if (resultScale < 0) {
      var certified = resultScale === result.kk_1 ? coefficient.uo(operandCoefficient529, this.kk_1, operand.kk_1, coefficientSnapshot(result), result.kk_1) : null;
      if (certified == null) {
        var residual = this.bo(result.do(operand));
        if (compareMagnitude(residual, operand) >= 0)
          throw ArithmeticException_init_$Create$('Division impossible');
      }
    } else if (result.vn() > 0) {
      result = result.ro(0, RoundingMode_DOWN_getInstance());
    }
    if (preferred > result.vn()) {
      var room = context.ol_1 - result.ql() | 0;
      if (room > 0) {
        var scale = result.vn();
        var tmp_0 = result;
        var tmp_1 = fromInt(scale);
        var tmp0_0 = fromInt(room);
        // Inline function 'kotlin.Long.minus' call
        var this_0 = fromInt(preferred);
        // Inline function 'kotlin.comparisons.minOf' call
        var b = subtract(this_0, fromInt(scale));
        var tmp$ret$2 = compare(tmp0_0, b) <= 0 ? tmp0_0 : b;
        return tmp_0.rl(convertToInt(add(tmp_1, tmp$ret$2)));
      }
    }
    return integralStrip(result, preferred, false);
  };
  protoOf(BigDecimal).vo = function (divisor) {
    var coefficient = coefficientSnapshot(this);
    var divisorCoefficient529 = coefficientSnapshot(divisor);
    var quotient = this.po(divisor);
    var residual = coefficient.uo(divisorCoefficient529, this.kk_1, divisor.kk_1, coefficientSnapshot(quotient), quotient.kk_1);
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [quotient, residual == null ? this.bo(quotient.do(divisor)) : BigDecimal_init_$Create$_0(residual.dd_1, residual.ed_1)];
  };
  protoOf(BigDecimal).wo = function (divisor, mc) {
    var coefficient = coefficientSnapshot(this);
    var divisorCoefficient529 = coefficientSnapshot(divisor);
    var context = mc;
    if (context.ol_1 === 0)
      return this.vo(divisor);
    var quotient = this.to(divisor, context);
    var residual = coefficient.uo(divisorCoefficient529, this.kk_1, divisor.kk_1, coefficientSnapshot(quotient), quotient.kk_1);
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [quotient, residual == null ? this.bo(quotient.do(divisor)) : BigDecimal_init_$Create$_0(residual.dd_1, residual.ed_1)];
  };
  protoOf(BigDecimal).xo = function (divisor) {
    return remainderElement(this, this.vo(divisor));
  };
  protoOf(BigDecimal).yo = function (divisor, mc) {
    return remainderElement(this, this.wo(divisor, mc));
  };
  protoOf(BigDecimal).rk = function (mc) {
    return this.kl(mc);
  };
  protoOf(BigDecimal).rl = function (newScale) {
    return this.so(newScale, 7);
  };
  protoOf(BigDecimal).so = function (newScale, roundingMode) {
    return setScaleValue(this, newScale, Companion_instance_7.ko(roundingMode));
  };
  protoOf(BigDecimal).ro = function (newScale, roundingMode) {
    return this.so(newScale, roundingMode.l2_1);
  };
  protoOf(BigDecimal).zo = function () {
    return storedSign529(this) === 0 ? Companion_getInstance().ij_1 : stripTo(this, -2147483648, true);
  };
  protoOf(BigDecimal).ap = function (n) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(this.kk_1);
    var tmp$ret$0 = add(this_0, fromInt(n));
    return movePoint(this, tmp$ret$0);
  };
  protoOf(BigDecimal).bp = function (n) {
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(this.kk_1);
    var tmp$ret$0 = subtract(this_0, fromInt(n));
    return movePoint(this, tmp$ret$0);
  };
  protoOf(BigDecimal).cp = function (n) {
    var tmp = Companion_getInstance();
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(this.kk_1);
    var tmp$ret$0 = subtract(this_0, fromInt(n));
    return withScale529(this, scaleForValue(tmp, tmp$ret$0, storedSign529(this) === 0));
  };
  protoOf(BigDecimal).dp = function () {
    return BigDecimal_init_$Create$_0(Companion_getInstance_1().zj_1, this.kk_1);
  };
  protoOf(BigDecimal).gk = function (n) {
    var coefficient = coefficientSnapshot(this);
    if (!(0 <= n ? n <= 999999999 : false))
      throw ArithmeticException_init_$Create$('Invalid operation');
    if (n === 0)
      return Companion_getInstance().jj_1;
    var tmp = Companion_getInstance();
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(this.kk_1);
    var tmp$ret$0 = multiply(this_0, fromInt(n));
    var scale = scaleForValue(tmp, tmp$ret$0, coefficient.ui() === 0);
    return BigDecimal_init_$Create$_0(coefficient.gk(n), scale);
  };
  protoOf(BigDecimal).ep = function (n, mc) {
    var coefficient = coefficientSnapshot(this);
    if (mc.ol_1 === 0)
      return this.gk(n);
    if (!(-999999999 <= n ? n <= 999999999 : false))
      throw ArithmeticException_init_$Create$('Invalid operation');
    if (n === 0)
      return Companion_getInstance().jj_1;
    var magnitude = n < 0 ? -n | 0 : n;
    var exponentDigits = magnitude.toString().length;
    if (exponentDigits > mc.ol_1)
      throw ArithmeticException_init_$Create$('Invalid operation');
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(mc.ol_1);
    // Inline function 'kotlin.Long.plus' call
    var this_1 = add(this_0, fromInt(exponentDigits));
    var mathematicalPrecision = add(this_1, fromInt(1));
    if (compare(mathematicalPrecision, new Long(646456992, 0)) > 0) {
      var base = coefficient.fp(this.kk_1);
      if (!(base == null)) {
        var mode = mc.pl_1;
        var accumulator = DecimalPower593_getInstance().mp(base, magnitude, mathematicalPrecision, mode);
        if (n < 0)
          accumulator = DecimalPower593_getInstance().np(accumulator, mathematicalPrecision, mc.ol_1, mode);
        var result = DecimalPower593_getInstance().pp(DecimalPower593_getInstance().op(accumulator, fromInt(mc.ol_1), mode));
        return BigDecimal_init_$Create$_0(result.dd_1, result.ed_1);
      }
    }
    // Inline function 'kotlin.Long.plus' call
    var this_2 = fromInt(mc.ol_1);
    // Inline function 'kotlin.Long.plus' call
    var this_3 = add(this_2, fromInt(exponentDigits));
    var tmp0 = add(this_3, fromInt(1));
    // Inline function 'kotlin.comparisons.minOf' call
    var b = new Long(2147483647, 0);
    var tmp$ret$4 = compare(tmp0, b) <= 0 ? tmp0 : b;
    var workPrecision = convertToInt(tmp$ret$4);
    var work = new MathContext(workPrecision, mc.pl_1);
    var result_0 = Companion_getInstance().jj_1;
    // Inline function 'kotlin.countLeadingZeroBits' call
    var bits = 32 - clz32(magnitude) | 0;
    var inductionVariable = bits - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        result_0 = result_0.eo(result_0, work);
        if (!((magnitude & 1 << i) === 0))
          result_0 = result_0.eo(this, work);
      }
       while (0 <= inductionVariable);
    if (n < 0)
      result_0 = Companion_getInstance().jj_1.no(result_0, work);
    return roundValue(result_0, mc);
  };
  protoOf(BigDecimal).qp = function (mc) {
    var coefficient = coefficientSnapshot(this);
    var sign = this.ui();
    if (sign < 0)
      throw ArithmeticException_init_$Create$('Attempted square root of negative BigDecimal');
    var context = mc;
    var preferred = this.kk_1 / 2 | 0;
    if (sign === 0)
      return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, preferred);
    var finiteRoot = finiteExactSquareRoot(this);
    if (!(finiteRoot == null))
      return finiteSquareRootResult(this, finiteRoot, context, preferred);
    if (context.ol_1 === 0 || context.pl_1.equals(RoundingMode_UNNECESSARY_getInstance())) {
      var normalized = this.zo();
      if (!((normalized.kk_1 & 1) === 0))
        throw ArithmeticException_init_$Create$('Computed square root not exact.');
      var tmp;
      if (normalized.un().equals(Companion_getInstance_1().zj_1)) {
        // Inline function 'kotlin.arrayOf' call
        // Inline function 'kotlin.js.unsafeCast' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp = [Companion_getInstance_1().zj_1, Companion_getInstance_1().yj_1];
      } else {
        tmp = normalized.un().am();
      }
      var root = tmp;
      if (!(root[1].ui() === 0) || (context.ol_1 > 0 && root[0].xk().toString().length > context.ol_1))
        throw ArithmeticException_init_$Create$('Computed square root not exact.');
      var exact = stripTo(BigDecimal_init_$Create$_0(root[0], normalized.kk_1 / 2 | 0), preferred);
      var rounded = roundValue(exact, context);
      var tmp_0;
      if (context.ol_1 === 0) {
        tmp_0 = preferred;
      } else {
        var tmp0 = fromInt(preferred);
        var tmp0_0 = fromInt(rounded.kk_1);
        // Inline function 'kotlin.Long.plus' call
        var other = context.ol_1;
        var tmp0_1 = add(tmp0_0, fromInt(other));
        // Inline function 'kotlin.Long.minus' call
        var other_0 = storedPrecision(rounded);
        // Inline function 'kotlin.comparisons.minOf' call
        var b = subtract(tmp0_1, fromInt(other_0));
        var tmp$ret$5 = compare(tmp0, b) <= 0 ? tmp0 : b;
        tmp_0 = convertToInt(tmp$ret$5);
      }
      var targetScale = tmp_0;
      if (coefficientSnapshot(rounded).ui() === 0)
        return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, targetScale);
      return rounded.kk_1 < targetScale ? setScaleValue(rounded, targetScale, RoundingMode_UNNECESSARY_getInstance()) : rounded;
    }
    var coefficientSign = coefficient.ui();
    if (coefficientSign === 0) {
      this.ql();
      return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, preferred);
    }
    var exponent = adjustedExponent(this);
    var tmp_1;
    if (compare(exponent, new Long(0, 0)) < 0) {
      // Inline function 'kotlin.Long.minus' call
      // Inline function 'kotlin.Long.div' call
      var this_0 = subtract(exponent, fromInt(1));
      tmp_1 = divide(this_0, fromInt(2));
    } else {
      // Inline function 'kotlin.Long.div' call
      tmp_1 = divide(exponent, fromInt(2));
    }
    var rootExponent = tmp_1;
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(context.ol_1);
    var tmp$ret$9 = subtract(this_1, fromInt(1));
    var workingScale = subtract(tmp$ret$9, rootExponent);
    var tmp0_2 = multiply(new Long(2, 0), workingScale);
    // Inline function 'kotlin.Long.minus' call
    var other_1 = this.kk_1;
    var shift = subtract(tmp0_2, fromInt(other_1));
    if (coefficientSign > 0 && compare(shift, new Long(0, 0)) > 0 && context.ol_1 > 268435455) {
      var digits = storedPrecision(this);
      var tmp0_3 = fromInt(digits);
      // Inline function 'kotlin.Long.minus' call
      var other_2 = this.kk_1;
      // Inline function 'kotlin.Long.minus' call
      var this_2 = subtract(tmp0_3, fromInt(other_2));
      var tmp$ret$12 = subtract(this_2, fromInt(1));
      if (equalsLong(exponent, tmp$ret$12)) {
        if (DecimalSquareRoot579_getInstance().up(context.ol_1))
          throw ArithmeticException_init_$Create$('BigInteger overflow');
        if (!DecimalSquareRoot579_getInstance().wp(digits, shift, workingScale)) {
          var result = DecimalSquareRoot579_getInstance().vp(coefficient, shift, context.ol_1, workingScale, preferred, context.pl_1);
          return BigDecimal_init_$Create$_0(result.dd_1, result.ed_1);
        }
      }
    }
    var scale = checkedScale(Companion_getInstance(), workingScale);
    var numerator = compare(shift, new Long(0, 0)) >= 0 ? coefficient.hk(tenPow(Companion_getInstance(), shift)) : coefficient;
    var denominator = compare(shift, new Long(0, 0)) < 0 ? tenPow(Companion_getInstance(), negate(shift)) : Companion_getInstance_1().zj_1;
    var qr = numerator.wk(denominator);
    var root_0 = qr[0].xp();
    var delta = qr[0].yk(root_0.hk(root_0));
    var exact_0 = delta.ui() === 0 && qr[1].ui() === 0;
    if (!exact_0) {
      var rootComparison = delta.zk(root_0);
      var tmp_2;
      if (!(rootComparison === 0)) {
        tmp_2 = rootComparison;
      } else {
        var quarter = denominator.wk(Companion_getInstance_1().fk(new Long(4, 0)));
        var remainderComparison = qr[1].zk(quarter[0]);
        tmp_2 = !(remainderComparison === 0) ? remainderComparison : -quarter[1].ui() | 0;
      }
      var half = tmp_2;
      if (increment(Companion_getInstance(), context.pl_1, 1, half, root_0.bl(0)))
        root_0 = root_0.al(Companion_getInstance_1().zj_1);
    }
    var result_0 = roundValue(BigDecimal_init_$Create$_0(root_0, scale), context);
    return exact_0 ? stripTo(result_0, preferred) : result_0;
  };
  protoOf(BigDecimal).yp = function (other) {
    if (this.kk_1 === other.kk_1 && this.nk_1 === 1 && other.nk_1 === 1 && !equalsLong(compactValue529(this), new Long(0, -2147483648)) && !equalsLong(compactValue529(other), new Long(0, -2147483648))) {
      var order = compactValue529(this).t2(compactValue529(other));
      return order < 0 ? -1 : order > 0 ? 1 : 0;
    }
    var coefficient = coefficientSnapshot(this);
    var operand = other;
    var operandCoefficient529 = coefficientSnapshot(operand);
    if (this.kk_1 === operand.kk_1) {
      var left = coefficient.vk();
      var right = operandCoefficient529.vk();
      if (!(left == null) && !(right == null)) {
        var order_0 = left.t2(right);
        return order_0 < 0 ? -1 : order_0 > 0 ? 1 : 0;
      }
    }
    var leftSign = this.ui();
    var rightSign = operand.ui();
    if (!(leftSign === rightSign))
      return leftSign < rightSign ? -1 : 1;
    if (leftSign === 0)
      return 0;
    var magnitude = compareMagnitude(this, operand);
    return magnitude < 0 ? leftSign > 0 ? -1 : 1 : magnitude > 0 ? leftSign > 0 ? 1 : -1 : 0;
  };
  protoOf(BigDecimal).d = function (other) {
    return this.yp(other instanceof BigDecimal ? other : THROW_CCE());
  };
  protoOf(BigDecimal).zp = function (value) {
    return this.yp(value) <= 0 ? this : value;
  };
  protoOf(BigDecimal).aq = function (value) {
    return this.yp(value) >= 0 ? this : value;
  };
  protoOf(BigDecimal).equals = function (other) {
    var tmp;
    var tmp_0;
    if (other instanceof BigDecimal) {
      tmp_0 = this.kk_1 === other.kk_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.nk_1 === 1 && other.nk_1 === 1 ? this.lk_1 === other.lk_1 && this.mk_1 === other.mk_1 : coefficientSnapshot(this).equals(coefficientSnapshot(other));
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(BigDecimal).hashCode = function () {
    if (!(this.nk_1 === 1)) {
      // Inline function 'kotlin.hashCode' call
      var tmp0_safe_receiver = this.ok_1;
      var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
      var tmp$ret$0 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
      return imul(31, tmp$ret$0) + this.kk_1 | 0;
    }
    var value = compactValue529(this);
    var magnitude = compare(value, new Long(0, 0)) < 0 ? negate(value) : value;
    var tmp0 = new Long(31, 0);
    // Inline function 'kotlin.Long.times' call
    var other = convertToInt(shiftRightUnsigned(magnitude, 32));
    var tmp$ret$1 = multiply(tmp0, fromInt(other));
    var hash = convertToInt(add(tmp$ret$1, bitwiseAnd(magnitude, new Long(-1, 0))));
    return imul(31, compare(value, new Long(0, 0)) < 0 ? -hash | 0 : hash) + this.kk_1 | 0;
  };
  protoOf(BigDecimal).bq = function (destination, format, maxChars) {
    checkTextLimit537(new Long(0, 0), maxChars);
    if (!getKClassFromExpression(this).equals(getKClass(BigDecimal)) || (this.nk_1 === 2 && !getKClassFromExpression(ensureNotNull(this.ok_1)).equals(getKClass(BigInteger)))) {
      var text = legacyText537(this, format);
      checkTextLimit537(fromInt(text.length), maxChars);
      destination.s(text);
      return fromInt(text.length);
    }
    if (format.equals(DecimalTextFormat_CANONICAL_getInstance())) {
      var tmp0_safe_receiver = this.qk_1;
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        checkTextLimit537(fromInt(tmp0_safe_receiver.length), maxChars);
        var start = 0;
        while (start < tmp0_safe_receiver.length) {
          // Inline function 'kotlin.Long.plus' call
          var this_0 = fromInt(start);
          var tmp0 = add(this_0, fromInt(256));
          // Inline function 'kotlin.comparisons.minOf' call
          var b = fromInt(tmp0_safe_receiver.length);
          var tmp$ret$3 = compare(tmp0, b) <= 0 ? tmp0 : b;
          var end = convertToInt(tmp$ret$3);
          destination.ia(tmp0_safe_receiver, start, end);
          start = end;
        }
        return fromInt(tmp0_safe_receiver.length);
      }
    }
    var layout = textLayout537(this, format, maxChars);
    layout.cq(new AppendableSink537(destination));
    return layout.sm_1;
  };
  protoOf(BigDecimal).dq = function (destination, format, maxChars, $super) {
    format = format === VOID ? DecimalTextFormat_CANONICAL_getInstance() : format;
    maxChars = maxChars === VOID ? null : maxChars;
    return $super === VOID ? this.bq(destination, format, maxChars) : $super.bq.call(this, destination, format, maxChars);
  };
  protoOf(BigDecimal).eq = function (destination, offset, length, format) {
    checkTextBuffer537(destination, offset, length);
    if (!getKClassFromExpression(this).equals(getKClass(BigDecimal)) || (this.nk_1 === 2 && !getKClassFromExpression(ensureNotNull(this.ok_1)).equals(getKClass(BigInteger)))) {
      var text = legacyText537(this, format);
      checkTextLimit537(fromInt(text.length), fromInt(length));
      (new ArraySink537(destination, offset)).hq(text, 0, text.length);
      return text.length;
    }
    if (format.equals(DecimalTextFormat_CANONICAL_getInstance())) {
      var tmp0_safe_receiver = this.qk_1;
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        checkTextLimit537(fromInt(tmp0_safe_receiver.length), fromInt(length));
        toCharArray(tmp0_safe_receiver, destination, offset, 0, tmp0_safe_receiver.length);
        return tmp0_safe_receiver.length;
      }
    }
    var layout = textLayout537(this, format, fromInt(length));
    layout.cq(new ArraySink537(destination, offset));
    return convertToInt(layout.sm_1);
  };
  protoOf(BigDecimal).iq = function (destination, offset, length, format, $super) {
    offset = offset === VOID ? 0 : offset;
    length = length === VOID ? destination.length - offset | 0 : length;
    format = format === VOID ? DecimalTextFormat_CANONICAL_getInstance() : format;
    return $super === VOID ? this.eq(destination, offset, length, format) : $super.eq.call(this, destination, offset, length, format);
  };
  protoOf(BigDecimal).toString = function () {
    var tmp0_safe_receiver = this.qk_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    // Inline function 'kotlin.also' call
    var this_0 = canonicalStringValue(this);
    this.qk_1 = this_0;
    return this_0;
  };
  protoOf(BigDecimal).cm = function () {
    var text = this.nk_1 === 1 ? compactValue529(this).toString() : ensureNotNull(this.ok_1).toString();
    if (this.kk_1 === 0)
      return text;
    if (this.kk_1 < 0) {
      if (this.ui() === 0)
        return '0';
      if (compare(subtract(fromInt(text.length), fromInt(this.kk_1)), new Long(2147483647, 0)) > 0) {
        plainStringTooLarge();
      }
      return text + repeat('0', convertToInt(negate(fromInt(this.kk_1))));
    }
    return canonicalPlain(this, magnitudeDigits529(this), this.ui());
  };
  protoOf(BigDecimal).dm = function () {
    var digits = magnitudeDigits529(this);
    var sign = layoutSign(this);
    var tmp0 = fromInt(digits.length);
    // Inline function 'kotlin.Long.minus' call
    var other = this.kk_1;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    var exp = subtract(this_0, fromInt(1));
    if (this.kk_1 >= 0 && compare(exp, new Long(-6, -1)) >= 0)
      return canonicalPlain(this, digits, sign);
    // Inline function 'kotlin.Long.rem' call
    // Inline function 'kotlin.Long.plus' call
    var this_1 = modulo(exp, fromInt(3));
    // Inline function 'kotlin.Long.rem' call
    var this_2 = add(this_1, fromInt(3));
    var tmp$ret$4 = modulo(this_2, fromInt(3));
    var mod = convertToInt(tmp$ret$4);
    // Inline function 'kotlin.Long.minus' call
    var engineeringExp = subtract(exp, fromInt(mod));
    var body;
    if (this.ui() === 0) {
      var decimals = (3 - mod | 0) % 3 | 0;
      if (!(mod === 0)) {
        // Inline function 'kotlin.Long.plus' call
        var this_3 = engineeringExp;
        engineeringExp = add(this_3, fromInt(3));
      }
      body = decimals === 0 ? '0' : '0.' + repeat('0', decimals);
    } else {
      var before = mod + 1 | 0;
      body = digits.length <= before ? padEnd(digits, before, _Char___init__impl__6a9atx(48)) : substring_0(digits, 0, before) + '.' + substring(digits, before);
    }
    return (sign < 0 ? '-' : '') + body + (equalsLong(engineeringExp, new Long(0, 0)) ? '' : exponentText(Companion_getInstance(), engineeringExp));
  };
  protoOf(BigDecimal).tm = function () {
    var coefficient = coefficientSnapshot(this);
    if (this.ui() === 0)
      return Companion_getInstance_1().yj_1;
    if (this.kk_1 <= 0)
      return coefficient.hk(tenPow(Companion_getInstance(), negate(fromInt(this.kk_1))));
    if (this.kk_1 >= this.ql())
      return Companion_getInstance_1().yj_1;
    return coefficient.ul(tenPow(Companion_getInstance(), fromInt(this.kk_1)));
  };
  protoOf(BigDecimal).jq = function () {
    return coefficientSnapshot(this.so(0, 7));
  };
  protoOf(BigDecimal).kq = function () {
    return convertToInt(integerLowBits(this, 32));
  };
  protoOf(BigDecimal).um = function () {
    return integerLowBits(this, 64);
  };
  protoOf(BigDecimal).lq = function () {
    return toByte(this.kq());
  };
  protoOf(BigDecimal).mq = function () {
    return toShort(this.kq());
  };
  protoOf(BigDecimal).nq = function () {
    return convertToInt(narrowExact(this, new Long(-2147483648, -1), new Long(2147483647, 0)));
  };
  protoOf(BigDecimal).oq = function () {
    return convertToShort(narrowExact(this, new Long(-32768, -1), new Long(32767, 0)));
  };
  protoOf(BigDecimal).pq = function () {
    return convertToByte(narrowExact(this, new Long(-128, -1), new Long(127, 0)));
  };
  protoOf(BigDecimal).xm = function () {
    if (this.nk_1 === 1 && this.kk_1 === 0 && (!equalsLong(compactValue529(this), new Long(0, -2147483648)) || getKClassFromExpression(this).equals(getKClass(BigDecimal))))
      return compactValue529(this);
    var coefficient = coefficientSnapshot(this);
    var compact = coefficient.vk();
    if (!(compact == null) && this.kk_1 === 0)
      return compact;
    if (this.ui() === 0)
      return new Long(0, 0);
    var tmp0 = fromInt(this.ql());
    // Inline function 'kotlin.Long.minus' call
    var other = this.kk_1;
    var tmp$ret$0 = subtract(tmp0, fromInt(other));
    if (compare(tmp$ret$0, new Long(0, 0)) <= 0)
      throw ArithmeticException_init_$Create$('Rounding necessary');
    var tmp0_0 = fromInt(this.ql());
    // Inline function 'kotlin.Long.minus' call
    var other_0 = this.kk_1;
    var tmp$ret$1 = subtract(tmp0_0, fromInt(other_0));
    if (compare(tmp$ret$1, new Long(19, 0)) > 0)
      throw ArithmeticException_init_$Create$('Overflow');
    var integer = this.so(0, 7);
    if (integer.ql() >= 19 && coefficientSnapshot(integer).en() > 63)
      throw ArithmeticException_init_$Create$('Overflow');
    return coefficientSnapshot(integer).um();
  };
  protoOf(BigDecimal).qq = function () {
    return binaryValue(this, 53, -1022, 1023);
  };
  protoOf(BigDecimal).ym = function () {
    return binaryValue(this, 24, -126, 127);
  };
  function compareLow($this, a, b) {
    var inductionVariable = get_lastIndex(b);
    if (0 <= inductionVariable)
      do {
        var j = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        if (!(a[j] === b[j]))
          return compareTo(a[j], b[j]);
      }
       while (0 <= inductionVariable);
    return 0;
  }
  function doubleResidue($this, value, modulus, gap) {
    var borrow = new Long(0, 0);
    var inductionVariable = 0;
    var last = modulus.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var j = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = fromInt(modulus[j]);
        // Inline function 'kotlin.Long.minus' call
        var other = value[j];
        var tmp$ret$0 = subtract(tmp0, fromInt(other));
        var difference = subtract(tmp$ret$0, borrow);
        gap[j] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
        borrow = compare(difference, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
      }
       while (inductionVariable <= last);
    if (compareLow($this, value, gap) >= 0) {
      borrow = new Long(0, 0);
      var inductionVariable_0 = 0;
      var last_0 = value.length - 1 | 0;
      if (inductionVariable_0 <= last_0)
        do {
          var j_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          var tmp0_0 = fromInt(value[j_0]);
          // Inline function 'kotlin.Long.minus' call
          var other_0 = gap[j_0];
          var tmp$ret$1 = subtract(tmp0_0, fromInt(other_0));
          var difference_0 = subtract(tmp$ret$1, borrow);
          value[j_0] = convertToInt(bitwiseAnd(difference_0, new Long(1073741823, 0)));
          borrow = compare(difference_0, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
        }
         while (inductionVariable_0 <= last_0);
    } else {
      var carry = new Long(0, 0);
      var inductionVariable_1 = 0;
      var last_1 = value.length - 1 | 0;
      if (inductionVariable_1 <= last_1)
        do {
          var j_1 = inductionVariable_1;
          inductionVariable_1 = inductionVariable_1 + 1 | 0;
          // Inline function 'kotlin.Long.times' call
          var this_0 = fromInt(value[j_1]);
          var tmp$ret$2 = multiply(this_0, fromInt(2));
          var sum = add(tmp$ret$2, carry);
          value[j_1] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
          carry = shiftRightUnsigned(sum, 30);
        }
         while (inductionVariable_1 <= last_1);
    }
  }
  function Workspace(size) {
    this.rq_1 = new Int32Array(size + 2 | 0);
    this.sq_1 = new Int32Array(size);
    this.tq_1 = new Int32Array(size);
    this.uq_1 = new Int32Array(size);
    this.vq_1 = new Int32Array(size);
  }
  function WitnessSession(context, power, twos, minusOne) {
    this.wq_1 = context;
    this.xq_1 = power;
    this.yq_1 = twos;
    this.zq_1 = materializeMagnitude(this.xq_1);
    this.ar_1 = new Workspace(this.wq_1.dr_1.length);
    this.br_1 = new Int32Array(this.wq_1.dr_1.length);
    this.cr_1 = magnitudeBits(this.xq_1);
    var tmp0 = materializeMagnitude(minusOne);
    // Inline function 'kotlin.collections.copyInto' call
    var destination = this.ar_1.sq_1;
    var endIndex = tmp0.length;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp = tmp0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp, destination, 0, 0, endIndex);
    multiply_0(this.wq_1, this.ar_1.sq_1, this.wq_1.gr_1, this.br_1, this.ar_1.rq_1);
  }
  protoOf(WitnessSession).hr = function (base) {
    var reduced = BigInteger_init_$Create$_1(base).ir(BigInteger_init_$Create$_0(1, this.wq_1.dr_1));
    fill(this.ar_1.sq_1, 0);
    var tmp0 = materializeMagnitude(reduced);
    // Inline function 'kotlin.collections.copyInto' call
    var destination = this.ar_1.sq_1;
    var endIndex = tmp0.length;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp = tmp0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp, destination, 0, 0, endIndex);
    var factor = this.ar_1.tq_1;
    var result = this.ar_1.uq_1;
    var next = this.ar_1.vq_1;
    multiply_0(this.wq_1, this.ar_1.sq_1, this.wq_1.gr_1, factor, this.ar_1.rq_1);
    var tmp0_0 = this.wq_1.fr_1;
    // Inline function 'kotlin.collections.copyInto' call
    var destination_0 = result;
    var endIndex_0 = tmp0_0.length;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_0 = tmp0_0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp_0, destination_0, 0, 0, endIndex_0);
    var inductionVariable = 0;
    var last = this.cr_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!((this.zq_1[i / 30 | 0] & 1 << (i % 30 | 0)) === 0)) {
          multiply_0(this.wq_1, result, factor, next, this.ar_1.rq_1);
          var previous = result;
          result = next;
          next = previous;
        }
        if ((i + 1 | 0) < this.cr_1) {
          multiply_0(this.wq_1, factor, factor, next, this.ar_1.rq_1);
          var previous_0 = factor;
          factor = next;
          next = previous_0;
        }
      }
       while (inductionVariable < last);
    if (contentEquals(result, this.wq_1.fr_1) || contentEquals(result, this.br_1))
      return true;
    var inductionVariable_0 = 1;
    var last_0 = this.yq_1;
    if (inductionVariable_0 < last_0)
      do {
        var r = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        multiply_0(this.wq_1, result, result, next, this.ar_1.rq_1);
        var previous_1 = result;
        result = next;
        next = previous_1;
        if (contentEquals(result, this.br_1))
          return true;
      }
       while (inductionVariable_0 < last_0);
    return false;
  };
  function multiply_0($this, a, b, out, scratch) {
    var n = $this.dr_1.length;
    fill(scratch, 0);
    var inductionVariable = 0;
    if (inductionVariable < n)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp;
        if (b == null) {
          tmp = i === 0 ? new Long(1, 0) : new Long(0, 0);
        } else {
          tmp = fromInt(b[i]);
        }
        var word = tmp;
        addProduct($this, a, word, scratch);
        var q = bitwiseAnd(multiply(fromInt(scratch[0]), $this.er_1), new Long(1073741823, 0));
        addProduct($this, $this.dr_1, q, scratch);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 <= n)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            scratch[j] = scratch[j + 1 | 0];
          }
           while (!(j === n));
        scratch[n + 1 | 0] = 0;
      }
       while (inductionVariable < n);
    if (!(scratch[n] === 0) || compareLow(Companion_instance_1, scratch, $this.dr_1) >= 0) {
      var borrow = new Long(0, 0);
      var inductionVariable_1 = 0;
      if (inductionVariable_1 < n)
        do {
          var j_0 = inductionVariable_1;
          inductionVariable_1 = inductionVariable_1 + 1 | 0;
          var tmp0 = fromInt(scratch[j_0]);
          // Inline function 'kotlin.Long.minus' call
          var other = $this.dr_1[j_0];
          var tmp$ret$0 = subtract(tmp0, fromInt(other));
          var difference = subtract(tmp$ret$0, borrow);
          scratch[j_0] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
          borrow = compare(difference, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
        }
         while (inductionVariable_1 < n);
      scratch[n] = convertToInt(subtract(fromInt(scratch[n]), borrow));
    }
    // Inline function 'kotlin.collections.copyInto' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_0 = scratch;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp_0, out, 0, 0, n);
  }
  function addProduct($this, a, word, scratch) {
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = a.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var j = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = multiply(fromInt(a[j]), word);
        // Inline function 'kotlin.Long.plus' call
        var other = scratch[j];
        var tmp$ret$0 = add(tmp0, fromInt(other));
        var sum = add(tmp$ret$0, carry);
        scratch[j] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(sum, 30);
      }
       while (inductionVariable <= last);
    var high = add(fromInt(scratch[a.length]), carry);
    scratch[a.length] = convertToInt(bitwiseAnd(high, new Long(1073741823, 0)));
    scratch[a.length + 1 | 0] = convertToInt(add(fromInt(scratch[a.length + 1 | 0]), shiftRightUnsigned(high, 30)));
  }
  function Companion_0() {
    this.jr_1 = 4096;
  }
  protoOf(Companion_0).kr = function (m) {
    var mWords = materializeMagnitude(m);
    var n = mWords.length;
    if (m.oi_1 <= 0 || n === 0 || n > 4096 || (mWords[0] & 1) === 0 || (n === 1 && mWords[0] === 1))
      return null;
    var size = fromInt(n);
    // Inline function 'kotlin.Long.plus' call
    var scratchCells = add(size, fromInt(2));
    // Inline function 'kotlin.Long.times' call
    var this_0 = new Long(2, 0);
    var tmp$ret$1 = multiply(this_0, fromInt(30));
    var setupSteps = multiply(tmp$ret$1, size);
    // Inline function 'kotlin.Long.plus' call
    var this_1 = multiply(new Long(16, 0), size);
    var payloadCells = add(this_1, fromInt(8));
    var payloadBytes = multiply(new Long(4, 0), payloadCells);
    if (compare(scratchCells, new Long(2147483647, 0)) > 0 || compare(setupSteps, new Long(2147483647, 0)) > 0 || compare(payloadCells, new Long(2147483647, 0)) > 0 || compare(payloadBytes, new Long(2147483647, 0)) > 0)
      return null;
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var modulus = mWords.slice();
    var inverse = new Long(1, 0);
    var inductionVariable = 1;
    if (inductionVariable < 30)
      do {
        var bit = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!equalsLong(bitwiseAnd(multiply(fromInt(modulus[0]), inverse), shiftLeft(new Long(1, 0), bit)), new Long(0, 0)))
          inverse = add(inverse, shiftLeft(new Long(1, 0), bit));
      }
       while (inductionVariable < 30);
    var rho = bitwiseAnd(subtract(new Long(1073741824, 0), inverse), new Long(1073741823, 0));
    var oneMont = new Int32Array(n);
    var r2 = new Int32Array(n);
    var gap = new Int32Array(n);
    r2[0] = 1;
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$5 = divide(setupSteps, fromInt(2));
    var half = convertToInt(tmp$ret$5);
    var inductionVariable_0 = 0;
    var last = convertToInt(setupSteps);
    if (inductionVariable_0 < last)
      do {
        var step = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        doubleResidue(this, r2, modulus, gap);
        if ((step + 1 | 0) === half) {
          // Inline function 'kotlin.collections.copyInto' call
          var endIndex = r2.length;
          // Inline function 'kotlin.js.unsafeCast' call
          // Inline function 'kotlin.js.asDynamic' call
          var tmp = r2;
          // Inline function 'kotlin.js.unsafeCast' call
          // Inline function 'kotlin.js.asDynamic' call
          arrayCopy(tmp, oneMont, 0, 0, endIndex);
        }
      }
       while (inductionVariable_0 < last);
    return new OddModulusContext(modulus, rho, oneMont, r2);
  };
  var Companion_instance_1;
  function Companion_getInstance_0() {
    return Companion_instance_1;
  }
  function generatePrime($this, bitLength, certainty, rnd) {
    if (bitLength < 2)
      throw ArithmeticException_init_$Create$('bitLength < 2');
    PrimeSearchLimits_instance.mr(bitLength);
    if (bitLength === 2)
      return BigInteger_init_$Create$_1($this.fk(fromInt(rnd.ue(2, 4))));
    var rounds = PrimalityCertainty_instance.nr(bitLength, certainty);
    while (true) {
      var n = randomBits($this, bitLength, rnd).or(bitLength - 1 | 0).or(0);
      if (rounds === 0 || passesPrimeTest(n, fromInt(rounds)))
        return n;
    }
  }
  function randomBits($this, numBits, rnd) {
    // Inline function 'kotlin.require' call
    if (!(numBits >= 0)) {
      var message = 'numBits must be non-negative';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(fromInt(numBits), new Long(7, 0));
    var tmp$ret$2 = divide(this_0, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$2));
    rnd.xe(bytes);
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(bytes.length === 0)) {
      bytes[0] = toByte(bytes[0] & (255 >>> ((8 - (numBits % 8 | 0) | 0) % 8 | 0) | 0));
    }
    return fromBytes($this, bytes, 0, bytes.length, false);
  }
  function parse_0($this, value, radix) {
    return parse_1($this, Companion_instance_6.pr(value), radix);
  }
  function decimalPrefixBuilder529($this, value, first, digits) {
    var builder = new ParsedMagnitude537();
    var index = first;
    var remaining = digits;
    var width = ((digits - 1 | 0) % 9 | 0) + 1 | 0;
    while (remaining > 0) {
      var power = 1;
      var block = 0;
      var count = 0;
      $l$loop: while (count < width) {
        var _unary__edvuaz = index;
        index = _unary__edvuaz + 1 | 0;
        var c = value.b(_unary__edvuaz);
        if (c === _Char___init__impl__6a9atx(46))
          continue $l$loop;
        var tmp = imul(block, 10);
        // Inline function 'kotlin.checkNotNull' call
        var tmp0 = numericDigit537(c, 10);
        var tmp$ret$1;
        $l$block: {
          // Inline function 'kotlin.checkNotNull' call
          if (tmp0 == null) {
            var message = 'Required value was null.';
            throw IllegalStateException_init_$Create$(toString_0(message));
          } else {
            tmp$ret$1 = tmp0;
            break $l$block;
          }
        }
        block = tmp + tmp$ret$1 | 0;
        power = imul(power, 10);
        count = count + 1 | 0;
      }
      builder.xr(power, block);
      remaining = remaining - width | 0;
      width = 9;
    }
    return builder;
  }
  function parse_1($this, value, radix) {
    if (!(2 <= radix ? radix <= 36 : false))
      throw NumberFormatException_init_$Create$('Radix out of range');
    if (value.tr_1 === 0)
      throw NumberFormatException_init_$Create$('Zero length BigInteger');
    var inductionVariable = 1;
    var last = value.tr_1;
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (value.b(index) === _Char___init__impl__6a9atx(45) || value.b(index) === _Char___init__impl__6a9atx(43))
          throw NumberFormatException_init_$Create$('Illegal embedded sign character');
      }
       while (inductionVariable < last);
    var start = 0;
    var sign = 1;
    if (value.b(0) === _Char___init__impl__6a9atx(45) || value.b(0) === _Char___init__impl__6a9atx(43)) {
      sign = value.b(0) === _Char___init__impl__6a9atx(45) ? -1 : 1;
      start = start + 1 | 0;
    }
    if (start === value.tr_1)
      throw NumberFormatException_init_$Create$('Zero length BigInteger');
    while (start < value.tr_1 && numericDigit537(value.b(start), radix) === 0) {
      start = start + 1 | 0;
    }
    if (start === value.tr_1)
      return $this.yj_1;
    if (MagnitudeLimits_instance.as(value.tr_1 - start | 0, radix)) {
      var inductionVariable_0 = start;
      var last_0 = value.tr_1;
      if (inductionVariable_0 < last_0)
        do {
          var i = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          if (numericDigit537(value.b(i), radix) == null) {
            invalidIntegerDigit($this, value, radix, start, i);
          }
        }
         while (inductionVariable_0 < last_0);
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    }
    var groupPower = radix;
    var groupWidth = 1;
    $l$loop: while (true) {
      // Inline function 'kotlin.Long.times' call
      var this_0 = fromInt(groupPower);
      var tmp$ret$0 = multiply(this_0, fromInt(radix));
      if (!(compare(tmp$ret$0, new Long(2147483647, 0)) <= 0)) {
        break $l$loop;
      }
      groupPower = imul(groupPower, radix);
      groupWidth = groupWidth + 1 | 0;
    }
    var builder = new ParsedMagnitude537();
    var index_0 = start;
    var width = (((value.tr_1 - start | 0) - 1 | 0) % groupWidth | 0) + 1 | 0;
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_1 = radix - 1 | 0;
    var radixUpperBits = 32 - clz32(this_1) | 0;
    while (index_0 < value.tr_1) {
      var tmp = fromInt(builder.bs());
      // Inline function 'kotlin.Long.times' call
      var this_2 = fromInt(width);
      var tmp$ret$2 = multiply(this_2, fromInt(radixUpperBits));
      if (compare(add(tmp, tmp$ret$2), new Long(2147483647, 0)) > 0) {
        var n = builder.cs(1);
        var base = $this.fk(fromInt(radix));
        var inductionVariable_1 = index_0;
        var last_1 = value.tr_1;
        if (inductionVariable_1 < last_1)
          do {
            var at = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var tmp0_elvis_lhs = numericDigit537(value.b(at), radix);
            var tmp_0;
            if (tmp0_elvis_lhs == null) {
              invalidIntegerDigit($this, value, radix, start, at);
            } else {
              tmp_0 = tmp0_elvis_lhs;
            }
            var digit = tmp_0;
            n = n.hk(base).al($this.fk(fromInt(digit)));
          }
           while (inductionVariable_1 < last_1);
        return sign < 0 ? n.jk() : n;
      }
      var block = 0;
      var power = 1;
      // Inline function 'kotlin.repeat' call
      var times = width;
      var inductionVariable_2 = 0;
      if (inductionVariable_2 < times)
        do {
          var index_1 = inductionVariable_2;
          inductionVariable_2 = inductionVariable_2 + 1 | 0;
          var tmp0_elvis_lhs_0 = numericDigit537(value.b(index_0), radix);
          var tmp_1;
          if (tmp0_elvis_lhs_0 == null) {
            invalidIntegerDigit(Companion_getInstance_1(), value, radix, start, index_0);
          } else {
            tmp_1 = tmp0_elvis_lhs_0;
          }
          var digit_0 = tmp_1;
          block = imul(block, radix) + digit_0 | 0;
          power = imul(power, radix);
          index_0 = index_0 + 1 | 0;
        }
         while (inductionVariable_2 < times);
      builder.xr(power, block);
      width = groupWidth;
    }
    return builder.cs(sign);
  }
  function ParsedMagnitude537() {
    this.ur_1 = new Long(0, 0);
    this.vr_1 = null;
    this.wr_1 = 0;
  }
  protoOf(ParsedMagnitude537).bs = function () {
    var tmp0_safe_receiver = this.vr_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      var tmp_0;
      if (this.wr_1 === 0) {
        tmp_0 = 0;
      } else {
        var tmp_1 = imul(this.wr_1 - 1 | 0, 30) + 32 | 0;
        // Inline function 'kotlin.countLeadingZeroBits' call
        var this_0 = tmp0_safe_receiver[this.wr_1 - 1 | 0];
        tmp_0 = tmp_1 - clz32(this_0) | 0;
      }
      tmp = tmp_0;
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? CompactInteger529_getInstance().ds(this.ur_1) : tmp1_elvis_lhs;
  };
  protoOf(ParsedMagnitude537).xr = function (power, block) {
    var tmp0_elvis_lhs = this.vr_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.run' call
      var tmp_0 = this.ur_1;
      // Inline function 'kotlin.Long.div' call
      var this_0 = new Long(0, -2147483648);
      var tmp$ret$2 = divide(this_0, fromInt(power));
      if (compare(tmp_0, tmp$ret$2) >= 0) {
        // Inline function 'kotlin.Long.times' call
        var this_1 = this.ur_1;
        var product = multiply(this_1, fromInt(power));
        // Inline function 'kotlin.Long.plus' call
        var this_2 = new Long(0, -2147483648);
        var tmp$ret$4 = add(this_2, fromInt(block));
        if (compare(product, tmp$ret$4) >= 0) {
          var tmp_1 = this;
          // Inline function 'kotlin.Long.minus' call
          tmp_1.ur_1 = subtract(product, fromInt(block));
          return Unit_instance;
        }
      }
      var magnitude = CompactInteger529_getInstance().es(convertToInt(shiftRight(this.ur_1, 32)), convertToInt(this.ur_1));
      this.wr_1 = magnitude.length;
      // Inline function 'kotlin.comparisons.maxOf' call
      var b = this.wr_1 + 1 | 0;
      var tmp$ret$6 = Math.max(4, b);
      // Inline function 'kotlin.also' call
      var this_3 = copyOf(magnitude, tmp$ret$6);
      this.vr_1 = this_3;
      tmp = this_3;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var words = tmp;
    var carry = fromInt(block);
    var inductionVariable = 0;
    var last = this.wr_1;
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_4 = fromInt(words[index]);
        var tmp$ret$9 = multiply(this_4, fromInt(power));
        var part = add(tmp$ret$9, carry);
        words[index] = convertToInt(bitwiseAnd(part, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(part, 30);
      }
       while (inductionVariable < last);
    while (!equalsLong(carry, new Long(0, 0))) {
      if (this.wr_1 === words.length) {
        // Inline function 'kotlin.Long.plus' call
        var this_5 = new Long(2147483647, 0);
        // Inline function 'kotlin.Long.minus' call
        var this_6 = add(this_5, fromInt(30));
        // Inline function 'kotlin.Long.div' call
        var this_7 = subtract(this_6, fromInt(1));
        var tmp0 = divide(this_7, fromInt(30));
        // Inline function 'kotlin.Long.times' call
        var this_8 = fromInt(words.length);
        // Inline function 'kotlin.comparisons.minOf' call
        var b_0 = multiply(this_8, fromInt(2));
        var tmp$ret$14 = compare(tmp0, b_0) <= 0 ? tmp0 : b_0;
        var next = convertToInt(tmp$ret$14);
        if (next === words.length)
          throw ArithmeticException_init_$Create$('BigInteger overflow');
        words = copyOf(words, next);
        this.vr_1 = words;
      }
      var tmp_2 = words;
      var _unary__edvuaz = this.wr_1;
      this.wr_1 = _unary__edvuaz + 1 | 0;
      tmp_2[_unary__edvuaz] = convertToInt(bitwiseAnd(carry, new Long(1073741823, 0)));
      carry = shiftRightUnsigned(carry, 30);
    }
    if (this.wr_1 > 0) {
      MagnitudeLimits_instance.fs(this.wr_1, words[this.wr_1 - 1 | 0]);
    }
  };
  protoOf(ParsedMagnitude537).cs = function (sign) {
    var words = this.vr_1;
    if (!(words == null))
      return normalized(Companion_getInstance_1(), sign, copyOf(words, this.wr_1));
    var tmp;
    if (sign < 0) {
      tmp = Companion_getInstance_1().fk(this.ur_1);
    } else if (equalsLong(this.ur_1, new Long(0, -2147483648))) {
      // Inline function 'kotlin.intArrayOf' call
      var tmp$ret$0 = new Int32Array([0, 0, 8]);
      tmp = BigInteger_init_$Create$_0(1, tmp$ret$0);
    } else {
      tmp = Companion_getInstance_1().fk(negate(this.ur_1));
    }
    return tmp;
  };
  protoOf(ParsedMagnitude537).gs = function (sign, scale) {
    if (this.vr_1 == null && (sign < 0 || !equalsLong(this.ur_1, new Long(0, -2147483648))))
      return Companion_getInstance().fn(sign < 0 ? this.ur_1 : negate(this.ur_1), scale);
    return BigDecimal_init_$Create$_0(this.cs(sign), scale);
  };
  function invalidIntegerDigit($this, value, radix, start, invalid) {
    var power = fromInt(radix);
    var width = 1;
    $l$loop: while (true) {
      // Inline function 'kotlin.Long.times' call
      var this_0 = power;
      var tmp$ret$0 = multiply(this_0, fromInt(radix));
      if (!(compare(tmp$ret$0, new Long(2147483647, 0)) <= 0)) {
        break $l$loop;
      }
      // Inline function 'kotlin.Long.times' call
      var this_1 = power;
      power = multiply(this_1, fromInt(radix));
      width = width + 1 | 0;
    }
    var firstWidth = (((value.tr_1 - start | 0) - 1 | 0) % width | 0) + 1 | 0;
    var groupStart = invalid < (start + firstWidth | 0) ? start : (start + firstWidth | 0) + imul(((invalid - start | 0) - firstWidth | 0) / width | 0, width) | 0;
    var groupEnd = groupStart === start ? start + firstWidth | 0 : groupStart + width | 0;
    var suffix = radix === 10 ? '' : ' under radix ' + radix;
    throw NumberFormatException_init_$Create$('For input string: "' + value.hs(groupStart, groupEnd) + '"' + suffix);
  }
  function fromBytes($this, bytes, off, len, twos) {
    var tmp;
    if (twos) {
      // Inline function 'kotlin.collections.isEmpty' call
      tmp = bytes.length === 0;
    } else {
      tmp = false;
    }
    if (tmp)
      throw NumberFormatException_init_$Create$('Zero length BigInteger');
    checkBounds($this, bytes, off, len);
    if (len === 0)
      return $this.yj_1;
    var negative = twos && bytes[off] < 0;
    var start = off;
    var end = off + len | 0;
    if (negative) {
      while ((end - start | 0) > 1 && bytes[start] === -1) {
        start = start + 1 | 0;
      }
    } else {
      while (start < end && bytes[start] === 0) {
        start = start + 1 | 0;
      }
      if (start === end)
        return $this.yj_1;
    }
    var result = new Int32Array(MagnitudeLimits_instance.is(end - start | 0, negative));
    var buffer = new Long(0, 0);
    var bufferedBits = 0;
    var word = 0;
    var carry = negative ? 1 : 0;
    var inductionVariable = end - 1 | 0;
    var last = start;
    if (last <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var raw = bytes[i] & 255;
        var converted = negative ? (raw ^ 255) + carry | 0 : raw;
        if (negative)
          carry = converted >>> 8 | 0;
        buffer = bitwiseOr(buffer, shiftLeft(fromInt(converted & 255), bufferedBits));
        bufferedBits = bufferedBits + 8 | 0;
        if (bufferedBits >= 30) {
          var _unary__edvuaz = word;
          word = _unary__edvuaz + 1 | 0;
          result[_unary__edvuaz] = convertToInt(bitwiseAnd(buffer, new Long(1073741823, 0)));
          buffer = shiftRightUnsigned(buffer, 30);
          bufferedBits = bufferedBits - 30 | 0;
        }
      }
       while (!(i === last));
    buffer = bitwiseOr(buffer, shiftLeft(fromInt(carry), bufferedBits));
    if (!equalsLong(buffer, new Long(0, 0))) {
      result[word] = convertToInt(buffer);
    }
    return normalized($this, negative ? -1 : 1, result);
  }
  function signedBytes($this, signum, bytes, off, len) {
    if (!(-1 <= signum ? signum <= 1 : false))
      throw NumberFormatException_init_$Create$('Invalid signum value');
    var magnitude = bytes;
    if (signum === 0) {
      checkBounds($this, magnitude, off, len);
      var inductionVariable = off;
      var last = off + len | 0;
      if (inductionVariable < last)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!(magnitude[i] === 0))
            throw NumberFormatException_init_$Create$('signum-magnitude mismatch');
        }
         while (inductionVariable < last);
      return $this.yj_1;
    }
    var n = fromBytes($this, magnitude, off, len, false);
    return signum < 0 ? n.jk() : n;
  }
  function checkBounds($this, bytes, off, len) {
    if (off < 0 || len < 0 || off > (bytes.length - len | 0))
      throw IndexOutOfBoundsException_init_$Create$('Range [' + off + ', ' + off + ' + ' + len + ') out of bounds for length ' + bytes.length);
  }
  function compactResult529($this, value) {
    return equalsLong(value, new Long(0, 0)) ? $this.yj_1 : BigInteger_init_$Create$(value);
  }
  function normalized($this, sign, words) {
    var length = words.length;
    while (length > 0 && words[length - 1 | 0] === 0) {
      length = length - 1 | 0;
    }
    if (length === 0)
      return $this.yj_1;
    MagnitudeLimits_instance.fs(length, words[length - 1 | 0]);
    return BigInteger_init_$Create$_0(sign, length === words.length ? words : copyOf(words, length));
  }
  function compareMagnitude_0($this, a, b) {
    if (!(a.length === b.length))
      return compareTo(a.length, b.length);
    var inductionVariable = a.length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        if (!(a[i] === b[i]))
          return compareTo(a[i], b[i]);
      }
       while (0 <= inductionVariable);
    return 0;
  }
  function addMagnitude($this, a, b) {
    var tmp0 = a.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_0 = b.length;
    var tmp$ret$0 = Math.max(tmp0, b_0);
    var out = new Int32Array(tmp$ret$0 + 1 | 0);
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = get_lastIndex(out);
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.collections.getOrElse' call
        var tmp;
        if (0 <= i ? i <= (a.length - 1 | 0) : false) {
          tmp = a[i];
        } else {
          tmp = 0;
        }
        var tmp$ret$1 = tmp;
        var tmp0_0 = fromInt(tmp$ret$1);
        // Inline function 'kotlin.collections.getOrElse' call
        var tmp_0;
        if (0 <= i ? i <= (b.length - 1 | 0) : false) {
          tmp_0 = b[i];
        } else {
          tmp_0 = 0;
        }
        // Inline function 'kotlin.Long.plus' call
        var other = tmp_0;
        var tmp$ret$5 = add(tmp0_0, fromInt(other));
        var n = add(tmp$ret$5, carry);
        out[i] = convertToInt(bitwiseAnd(n, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(n, 30);
      }
       while (inductionVariable < last);
    out[get_lastIndex(out)] = convertToInt(carry);
    return out;
  }
  function subtractMagnitude($this, a, b) {
    var out = new Int32Array(a.length);
    var borrow = new Long(0, 0);
    var inductionVariable = 0;
    var last = a.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = fromInt(a[i]);
        // Inline function 'kotlin.collections.getOrElse' call
        var tmp;
        if (0 <= i ? i <= (b.length - 1 | 0) : false) {
          tmp = b[i];
        } else {
          tmp = 0;
        }
        // Inline function 'kotlin.Long.minus' call
        var other = tmp;
        var tmp$ret$2 = subtract(tmp0, fromInt(other));
        var n = subtract(tmp$ret$2, borrow);
        out[i] = convertToInt(bitwiseAnd(n, new Long(1073741823, 0)));
        borrow = compare(n, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
      }
       while (inductionVariable <= last);
    return out;
  }
  function BigInteger_init_$Init$(value, $this) {
    BigInteger.call($this, CompactInteger529_getInstance().hl(value), convertToInt(shiftRight(value, 32)), convertToInt(value), 1, null);
    return $this;
  }
  function BigInteger_init_$Create$(value) {
    return BigInteger_init_$Init$(value, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_0(sign, words, $this) {
    BigInteger.call($this, sign, CompactInteger529_getInstance().ks(sign, words) ? convertToInt(shiftRight(CompactInteger529_getInstance().js(sign, words), 32)) : 0, CompactInteger529_getInstance().ks(sign, words) ? convertToInt(CompactInteger529_getInstance().js(sign, words)) : 0, CompactInteger529_getInstance().ks(sign, words) ? 1 : 2, CompactInteger529_getInstance().ks(sign, words) ? null : words);
    return $this;
  }
  function BigInteger_init_$Create$_0(sign, words) {
    return BigInteger_init_$Init$_0(sign, words, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_1(value, $this) {
    BigInteger.call($this, value.oi_1, value.pi_1, value.qi_1, value.ri_1, value.si_1);
    return $this;
  }
  function BigInteger_init_$Create$_1(value) {
    return BigInteger_init_$Init$_1(value, objectCreate(protoOf(BigInteger)));
  }
  function materializeMagnitude($this) {
    var tmp0_elvis_lhs = $this.si_1;
    return tmp0_elvis_lhs == null ? CompactInteger529_getInstance().es($this.pi_1, $this.qi_1) : tmp0_elvis_lhs;
  }
  function BigInteger_init_$Init$_2(value, $this) {
    BigInteger_init_$Init$_3(value, 10, $this);
    return $this;
  }
  function BigInteger_init_$Create$_2(value) {
    return BigInteger_init_$Init$_2(value, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_3(value, radix, $this) {
    BigInteger_init_$Init$_1(parse_0(Companion_getInstance_1(), value, radix), $this);
    return $this;
  }
  function BigInteger_init_$Create$_3(value, radix) {
    return BigInteger_init_$Init$_3(value, radix, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_4(value, $this) {
    BigInteger_init_$Init$_1(fromBytes(Companion_getInstance_1(), value, 0, value.length, true), $this);
    return $this;
  }
  function BigInteger_init_$Create$_4(value) {
    return BigInteger_init_$Init$_4(value, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_5(value, off, len, $this) {
    BigInteger_init_$Init$_1(fromBytes(Companion_getInstance_1(), value, off, len, true), $this);
    return $this;
  }
  function BigInteger_init_$Create$_5(value, off, len) {
    return BigInteger_init_$Init$_5(value, off, len, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_6(signum, magnitude, $this) {
    BigInteger_init_$Init$_7(signum, magnitude, 0, magnitude.length, $this);
    return $this;
  }
  function BigInteger_init_$Create$_6(signum, magnitude) {
    return BigInteger_init_$Init$_6(signum, magnitude, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_7(signum, magnitude, off, len, $this) {
    BigInteger_init_$Init$_1(signedBytes(Companion_getInstance_1(), signum, magnitude, off, len), $this);
    return $this;
  }
  function BigInteger_init_$Create$_7(signum, magnitude, off, len) {
    return BigInteger_init_$Init$_7(signum, magnitude, off, len, objectCreate(protoOf(BigInteger)));
  }
  function overflowingCompactResult529($this, wrapped, resultSign) {
    var magnitude = resultSign < 0 ? negate(wrapped) : wrapped;
    var high = convertToInt(shiftRightUnsigned(magnitude, 60)) | (equalsLong(wrapped, new Long(0, 0)) ? 16 : 0);
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$0 = new Int32Array([convertToInt(bitwiseAnd(magnitude, new Long(1073741823, 0))), convertToInt(bitwiseAnd(shiftRightUnsigned(magnitude, 30), new Long(1073741823, 0))), high]);
    return BigInteger_init_$Create$_0(resultSign, tmp$ret$0);
  }
  function compactCancellation529($this, other, subtract) {
    var wide;
    var small;
    var wideSign;
    var smallSign;
    if ($this.ri_1 === 2 && other.ri_1 === 1) {
      wide = $this;
      small = other;
      wideSign = $this.oi_1;
      smallSign = subtract ? -other.oi_1 | 0 : other.oi_1;
    } else if ($this.ri_1 === 1 && other.ri_1 === 2) {
      wide = other;
      small = $this;
      wideSign = subtract ? -other.oi_1 | 0 : other.oi_1;
      smallSign = $this.oi_1;
    } else
      return null;
    if (wideSign === smallSign)
      return null;
    var magnitude = ensureNotNull(wide.si_1);
    var tmp;
    if (!(magnitude.length === 3)) {
      tmp = true;
    } else {
      var containsArg = magnitude[2];
      tmp = !(8 <= containsArg ? containsArg <= 15 : false);
    }
    if (tmp)
      return null;
    var offset = bitwiseOr(bitwiseOr(shiftLeft(fromInt(magnitude[2] & 7), 60), shiftLeft(fromInt(magnitude[1]), 30)), fromInt(magnitude[0]));
    var value = small.cl();
    var delta = add(offset, compare(value, new Long(0, 0)) > 0 ? negate(value) : value);
    if (equalsLong(delta, new Long(0, 0)) && wideSign < 0)
      return compactResult529(Companion_getInstance_1(), new Long(0, -2147483648));
    if (compare(delta, new Long(0, 0)) >= 0)
      return null;
    var result = add(add(new Long(-1, 2147483647), delta), new Long(1, 0));
    return compactResult529(Companion_getInstance_1(), wideSign < 0 ? negate(result) : result);
  }
  function quotientStored($this, value) {
    var tmp$ret$0;
    $l$block_1: {
      // Inline function 'io.heapy.krogu.math.BigInteger.selectStoredDivision' call
      if (value.oi_1 === 0)
        throw ArithmeticException_init_$Create$('BigInteger divide by zero');
      if ($this.ri_1 === 1 && value.ri_1 === 1) {
        var a = $this.cl();
        var b = value.cl();
        var tmp;
        if (!true) {
          tmp = Companion_getInstance_1().yj_1;
        } else if (equalsLong(a, new Long(0, -2147483648)) && equalsLong(b, new Long(-1, -1))) {
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$1 = new Int32Array([0, 0, 8]);
          tmp = BigInteger_init_$Create$_0(1, tmp$ret$1);
        } else {
          tmp = compactResult529(Companion_getInstance_1(), divide(a, b));
        }
        var quotient = tmp;
        false ? compactResult529(Companion_getInstance_1(), modulo(a, b)) : Companion_getInstance_1().yj_1;
        tmp$ret$0 = quotient;
        break $l$block_1;
      }
      var words = materializeMagnitude($this);
      var valueWords = value.ri_1 === 1 ? null : value === $this ? words : materializeMagnitude(value);
      if (!(valueWords == null) && compareMagnitude_0(Companion_getInstance_1(), words, valueWords) < 0) {
        false ? normalized(Companion_getInstance_1(), $this.oi_1, words) : Companion_getInstance_1().yj_1;
        tmp$ret$0 = Companion_getInstance_1().yj_1;
        break $l$block_1;
      }
      var tmp1_elvis_lhs = valueWords == null ? null : valueWords.length;
      var n = tmp1_elvis_lhs == null ? ((magnitudeBits(value) + 30 | 0) - 1 | 0) / 30 | 0 : tmp1_elvis_lhs;
      var compactDivisor = valueWords == null ? value.cl() : new Long(0, 0);
      if (n === 1) {
        var tmp3_elvis_lhs = valueWords == null ? null : valueWords[0];
        var divisorWord = tmp3_elvis_lhs == null ? CompactInteger529_getInstance().ls(value.pi_1, value.qi_1, 0) : tmp3_elvis_lhs;
        var result = true ? new Int32Array(words.length) : null;
        var remainder = new Long(0, 0);
        var inductionVariable = words.length - 1 | 0;
        if (0 <= inductionVariable)
          do {
            var i = inductionVariable;
            inductionVariable = inductionVariable + -1 | 0;
            var tmp0 = shiftLeft(remainder, 30);
            // Inline function 'kotlin.Long.plus' call
            var other = words[i];
            var part = add(tmp0, fromInt(other));
            if (!(result == null)) {
              // Inline function 'kotlin.Long.div' call
              var tmp$ret$5 = divide(part, fromInt(divisorWord));
              result[i] = convertToInt(tmp$ret$5);
            }
            // Inline function 'kotlin.Long.rem' call
            remainder = modulo(part, fromInt(divisorWord));
          }
           while (0 <= inductionVariable);
        var tmp0_0 = !(result == null) ? normalized(Companion_getInstance_1(), imul($this.oi_1, value.oi_1), result) : Companion_getInstance_1().yj_1;
        var tmp_0;
        if (false) {
          var tmp_1 = Companion_getInstance_1();
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$7 = new Int32Array([convertToInt(remainder)]);
          tmp_0 = normalized(tmp_1, $this.oi_1, tmp$ret$7);
        } else {
          tmp_0 = Companion_getInstance_1().yj_1;
        }
        tmp$ret$0 = tmp0_0;
        break $l$block_1;
      }
      var tmp5_elvis_lhs = valueWords == null ? null : last(valueWords);
      var highWord = tmp5_elvis_lhs == null ? CompactInteger529_getInstance().ls(value.pi_1, value.qi_1, n - 1 | 0) : tmp5_elvis_lhs;
      // Inline function 'kotlin.countLeadingZeroBits' call
      var shift = clz32(highWord) - 2 | 0;
      var divisor = new Int32Array(n);
      if (!(valueWords == null)) {
        // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < n)
          do {
            var i_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp$ret$11 = valueWords[i_0];
            var digit = bitwiseOr(shiftLeft(fromInt(tmp$ret$11), shift), carry);
            divisor[i_0] = convertToInt(bitwiseAnd(digit, new Long(1073741823, 0)));
            carry = shiftRightUnsigned(digit, 30);
          }
           while (inductionVariable_0 < n);
        convertToInt(carry);
      } else {
        // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
        var carry_0 = new Long(0, 0);
        var inductionVariable_1 = 0;
        if (inductionVariable_1 < n)
          do {
            var i_1 = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var tmp$ret$13 = CompactInteger529_getInstance().ls(convertToInt(shiftRight(compactDivisor, 32)), convertToInt(compactDivisor), i_1);
            var digit_0 = bitwiseOr(shiftLeft(fromInt(tmp$ret$13), shift), carry_0);
            divisor[i_1] = convertToInt(bitwiseAnd(digit_0, new Long(1073741823, 0)));
            carry_0 = shiftRightUnsigned(digit_0, 30);
          }
           while (inductionVariable_1 < n);
        convertToInt(carry_0);
      }
      var dividend = new Int32Array(words.length + 1 | 0);
      var tmp_2 = words.length;
      // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
      var sourceSize = words.length;
      var carry_1 = new Long(0, 0);
      var inductionVariable_2 = 0;
      if (inductionVariable_2 < sourceSize)
        do {
          var i_2 = inductionVariable_2;
          inductionVariable_2 = inductionVariable_2 + 1 | 0;
          var tmp$ret$15 = words[i_2];
          var digit_1 = bitwiseOr(shiftLeft(fromInt(tmp$ret$15), shift), carry_1);
          dividend[i_2] = convertToInt(bitwiseAnd(digit_1, new Long(1073741823, 0)));
          carry_1 = shiftRightUnsigned(digit_1, 30);
        }
         while (inductionVariable_2 < sourceSize);
      dividend[tmp_2] = convertToInt(carry_1);
      var quotient_0 = true ? new Int32Array((words.length - n | 0) + 1 | 0) : null;
      // Inline function 'kotlin.Long.plus' call
      var this_0 = new Long(1073741823, 0);
      var radix = add(this_0, fromInt(1));
      var high = fromInt(divisor[n - 1 | 0]);
      var next = fromInt(divisor[n - 2 | 0]);
      var inductionVariable_3 = words.length - n | 0;
      if (0 <= inductionVariable_3)
        do {
          var j = inductionVariable_3;
          inductionVariable_3 = inductionVariable_3 + -1 | 0;
          var tmp0_1 = shiftLeft(fromInt(dividend[j + n | 0]), 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = dividend[(j + n | 0) - 1 | 0];
          var top = add(tmp0_1, fromInt(other_0));
          var tmp0_2 = divide(top, high);
          // Inline function 'kotlin.comparisons.minOf' call
          var b_0 = new Long(1073741823, 0);
          var estimate = compare(tmp0_2, b_0) <= 0 ? tmp0_2 : b_0;
          var residual = subtract(top, multiply(estimate, high));
          $l$loop: while (true) {
            var tmp_3;
            if (compare(residual, radix) < 0) {
              var tmp_4 = multiply(estimate, next);
              var tmp0_3 = shiftLeft(residual, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_1 = dividend[(j + n | 0) - 2 | 0];
              var tmp$ret$19 = add(tmp0_3, fromInt(other_1));
              tmp_3 = compare(tmp_4, tmp$ret$19) > 0;
            } else {
              tmp_3 = false;
            }
            if (!tmp_3) {
              break $l$loop;
            }
            var _unary__edvuaz = estimate;
            estimate = subtract(_unary__edvuaz, get_ONE());
            residual = add(residual, high);
          }
          var borrow = new Long(0, 0);
          var inductionVariable_4 = 0;
          if (inductionVariable_4 < n)
            do {
              var i_3 = inductionVariable_4;
              inductionVariable_4 = inductionVariable_4 + 1 | 0;
              var tmp0_4 = estimate;
              // Inline function 'kotlin.Long.times' call
              var other_2 = divisor[i_3];
              var tmp$ret$20 = multiply(tmp0_4, fromInt(other_2));
              var product = add(tmp$ret$20, borrow);
              var difference = subtract(fromInt(dividend[j + i_3 | 0]), bitwiseAnd(product, new Long(1073741823, 0)));
              dividend[j + i_3 | 0] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
              var tmp0_5 = shiftRightUnsigned(product, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_3 = compare(difference, new Long(0, 0)) < 0 ? 1 : 0;
              borrow = add(tmp0_5, fromInt(other_3));
            }
             while (inductionVariable_4 < n);
          var difference_0 = subtract(fromInt(dividend[j + n | 0]), borrow);
          dividend[j + n | 0] = convertToInt(bitwiseAnd(difference_0, new Long(1073741823, 0)));
          if (compare(difference_0, new Long(0, 0)) < 0) {
            var _unary__edvuaz_0 = estimate;
            estimate = subtract(_unary__edvuaz_0, get_ONE());
            var carry_2 = new Long(0, 0);
            var inductionVariable_5 = 0;
            if (inductionVariable_5 < n)
              do {
                var i_4 = inductionVariable_5;
                inductionVariable_5 = inductionVariable_5 + 1 | 0;
                var tmp0_6 = fromInt(dividend[j + i_4 | 0]);
                // Inline function 'kotlin.Long.plus' call
                var other_4 = divisor[i_4];
                var tmp$ret$22 = add(tmp0_6, fromInt(other_4));
                var sum = add(tmp$ret$22, carry_2);
                dividend[j + i_4 | 0] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
                carry_2 = shiftRightUnsigned(sum, 30);
              }
               while (inductionVariable_5 < n);
            dividend[j + n | 0] = convertToInt(bitwiseAnd(add(fromInt(dividend[j + n | 0]), carry_2), new Long(1073741823, 0)));
          }
          if (!(quotient_0 == null)) {
            quotient_0[j] = convertToInt(estimate);
          }
        }
         while (0 <= inductionVariable_3);
      var remainder_0 = false ? new Int32Array(n) : null;
      if (!(remainder_0 == null)) {
        var inductionVariable_6 = 0;
        if (inductionVariable_6 < n)
          do {
            var i_5 = inductionVariable_6;
            inductionVariable_6 = inductionVariable_6 + 1 | 0;
            remainder_0[i_5] = shift === 0 ? dividend[i_5] : dividend[i_5] >>> shift | 0 | convertToInt(bitwiseAnd(shiftLeft(fromInt(dividend[i_5 + 1 | 0]), 30 - shift | 0), new Long(1073741823, 0)));
          }
           while (inductionVariable_6 < n);
      }
      !(remainder_0 == null) ? normalized(Companion_getInstance_1(), $this.oi_1, remainder_0) : Companion_getInstance_1().yj_1;
      tmp$ret$0 = !(quotient_0 == null) ? normalized(Companion_getInstance_1(), imul($this.oi_1, value.oi_1), quotient_0) : Companion_getInstance_1().yj_1;
    }
    return tmp$ret$0;
  }
  function remainderStored($this, value) {
    var tmp$ret$0;
    $l$block_1: {
      // Inline function 'io.heapy.krogu.math.BigInteger.selectStoredDivision' call
      if (value.oi_1 === 0)
        throw ArithmeticException_init_$Create$('BigInteger divide by zero');
      if ($this.ri_1 === 1 && value.ri_1 === 1) {
        var a = $this.cl();
        var b = value.cl();
        var tmp;
        if (!false) {
          tmp = Companion_getInstance_1().yj_1;
        } else if (equalsLong(a, new Long(0, -2147483648)) && equalsLong(b, new Long(-1, -1))) {
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$1 = new Int32Array([0, 0, 8]);
          tmp = BigInteger_init_$Create$_0(1, tmp$ret$1);
        } else {
          tmp = compactResult529(Companion_getInstance_1(), divide(a, b));
        }
        var quotient = tmp;
        tmp$ret$0 = true ? compactResult529(Companion_getInstance_1(), modulo(a, b)) : Companion_getInstance_1().yj_1;
        break $l$block_1;
      }
      var words = materializeMagnitude($this);
      var valueWords = value.ri_1 === 1 ? null : value === $this ? words : materializeMagnitude(value);
      if (!(valueWords == null) && compareMagnitude_0(Companion_getInstance_1(), words, valueWords) < 0) {
        Companion_getInstance_1().yj_1;
        tmp$ret$0 = true ? normalized(Companion_getInstance_1(), $this.oi_1, words) : Companion_getInstance_1().yj_1;
        break $l$block_1;
      }
      var tmp1_elvis_lhs = valueWords == null ? null : valueWords.length;
      var n = tmp1_elvis_lhs == null ? ((magnitudeBits(value) + 30 | 0) - 1 | 0) / 30 | 0 : tmp1_elvis_lhs;
      var compactDivisor = valueWords == null ? value.cl() : new Long(0, 0);
      if (n === 1) {
        var tmp3_elvis_lhs = valueWords == null ? null : valueWords[0];
        var divisorWord = tmp3_elvis_lhs == null ? CompactInteger529_getInstance().ls(value.pi_1, value.qi_1, 0) : tmp3_elvis_lhs;
        var result = false ? new Int32Array(words.length) : null;
        var remainder = new Long(0, 0);
        var inductionVariable = words.length - 1 | 0;
        if (0 <= inductionVariable)
          do {
            var i = inductionVariable;
            inductionVariable = inductionVariable + -1 | 0;
            var tmp0 = shiftLeft(remainder, 30);
            // Inline function 'kotlin.Long.plus' call
            var other = words[i];
            var part = add(tmp0, fromInt(other));
            if (!(result == null)) {
              // Inline function 'kotlin.Long.div' call
              var tmp$ret$5 = divide(part, fromInt(divisorWord));
              result[i] = convertToInt(tmp$ret$5);
            }
            // Inline function 'kotlin.Long.rem' call
            remainder = modulo(part, fromInt(divisorWord));
          }
           while (0 <= inductionVariable);
        !(result == null) ? normalized(Companion_getInstance_1(), imul($this.oi_1, value.oi_1), result) : Companion_getInstance_1().yj_1;
        var tmp_0;
        if (true) {
          var tmp_1 = Companion_getInstance_1();
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$7 = new Int32Array([convertToInt(remainder)]);
          tmp_0 = normalized(tmp_1, $this.oi_1, tmp$ret$7);
        } else {
          tmp_0 = Companion_getInstance_1().yj_1;
        }
        tmp$ret$0 = tmp_0;
        break $l$block_1;
      }
      var tmp5_elvis_lhs = valueWords == null ? null : last(valueWords);
      var highWord = tmp5_elvis_lhs == null ? CompactInteger529_getInstance().ls(value.pi_1, value.qi_1, n - 1 | 0) : tmp5_elvis_lhs;
      // Inline function 'kotlin.countLeadingZeroBits' call
      var shift = clz32(highWord) - 2 | 0;
      var divisor = new Int32Array(n);
      if (!(valueWords == null)) {
        // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < n)
          do {
            var i_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp$ret$11 = valueWords[i_0];
            var digit = bitwiseOr(shiftLeft(fromInt(tmp$ret$11), shift), carry);
            divisor[i_0] = convertToInt(bitwiseAnd(digit, new Long(1073741823, 0)));
            carry = shiftRightUnsigned(digit, 30);
          }
           while (inductionVariable_0 < n);
        convertToInt(carry);
      } else {
        // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
        var carry_0 = new Long(0, 0);
        var inductionVariable_1 = 0;
        if (inductionVariable_1 < n)
          do {
            var i_1 = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var tmp$ret$13 = CompactInteger529_getInstance().ls(convertToInt(shiftRight(compactDivisor, 32)), convertToInt(compactDivisor), i_1);
            var digit_0 = bitwiseOr(shiftLeft(fromInt(tmp$ret$13), shift), carry_0);
            divisor[i_1] = convertToInt(bitwiseAnd(digit_0, new Long(1073741823, 0)));
            carry_0 = shiftRightUnsigned(digit_0, 30);
          }
           while (inductionVariable_1 < n);
        convertToInt(carry_0);
      }
      var dividend = new Int32Array(words.length + 1 | 0);
      var tmp_2 = words.length;
      // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
      var sourceSize = words.length;
      var carry_1 = new Long(0, 0);
      var inductionVariable_2 = 0;
      if (inductionVariable_2 < sourceSize)
        do {
          var i_2 = inductionVariable_2;
          inductionVariable_2 = inductionVariable_2 + 1 | 0;
          var tmp$ret$15 = words[i_2];
          var digit_1 = bitwiseOr(shiftLeft(fromInt(tmp$ret$15), shift), carry_1);
          dividend[i_2] = convertToInt(bitwiseAnd(digit_1, new Long(1073741823, 0)));
          carry_1 = shiftRightUnsigned(digit_1, 30);
        }
         while (inductionVariable_2 < sourceSize);
      dividend[tmp_2] = convertToInt(carry_1);
      var quotient_0 = false ? new Int32Array((words.length - n | 0) + 1 | 0) : null;
      // Inline function 'kotlin.Long.plus' call
      var this_0 = new Long(1073741823, 0);
      var radix = add(this_0, fromInt(1));
      var high = fromInt(divisor[n - 1 | 0]);
      var next = fromInt(divisor[n - 2 | 0]);
      var inductionVariable_3 = words.length - n | 0;
      if (0 <= inductionVariable_3)
        do {
          var j = inductionVariable_3;
          inductionVariable_3 = inductionVariable_3 + -1 | 0;
          var tmp0_0 = shiftLeft(fromInt(dividend[j + n | 0]), 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = dividend[(j + n | 0) - 1 | 0];
          var top = add(tmp0_0, fromInt(other_0));
          var tmp0_1 = divide(top, high);
          // Inline function 'kotlin.comparisons.minOf' call
          var b_0 = new Long(1073741823, 0);
          var estimate = compare(tmp0_1, b_0) <= 0 ? tmp0_1 : b_0;
          var residual = subtract(top, multiply(estimate, high));
          $l$loop: while (true) {
            var tmp_3;
            if (compare(residual, radix) < 0) {
              var tmp_4 = multiply(estimate, next);
              var tmp0_2 = shiftLeft(residual, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_1 = dividend[(j + n | 0) - 2 | 0];
              var tmp$ret$19 = add(tmp0_2, fromInt(other_1));
              tmp_3 = compare(tmp_4, tmp$ret$19) > 0;
            } else {
              tmp_3 = false;
            }
            if (!tmp_3) {
              break $l$loop;
            }
            var _unary__edvuaz = estimate;
            estimate = subtract(_unary__edvuaz, get_ONE());
            residual = add(residual, high);
          }
          var borrow = new Long(0, 0);
          var inductionVariable_4 = 0;
          if (inductionVariable_4 < n)
            do {
              var i_3 = inductionVariable_4;
              inductionVariable_4 = inductionVariable_4 + 1 | 0;
              var tmp0_3 = estimate;
              // Inline function 'kotlin.Long.times' call
              var other_2 = divisor[i_3];
              var tmp$ret$20 = multiply(tmp0_3, fromInt(other_2));
              var product = add(tmp$ret$20, borrow);
              var difference = subtract(fromInt(dividend[j + i_3 | 0]), bitwiseAnd(product, new Long(1073741823, 0)));
              dividend[j + i_3 | 0] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
              var tmp0_4 = shiftRightUnsigned(product, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_3 = compare(difference, new Long(0, 0)) < 0 ? 1 : 0;
              borrow = add(tmp0_4, fromInt(other_3));
            }
             while (inductionVariable_4 < n);
          var difference_0 = subtract(fromInt(dividend[j + n | 0]), borrow);
          dividend[j + n | 0] = convertToInt(bitwiseAnd(difference_0, new Long(1073741823, 0)));
          if (compare(difference_0, new Long(0, 0)) < 0) {
            var _unary__edvuaz_0 = estimate;
            estimate = subtract(_unary__edvuaz_0, get_ONE());
            var carry_2 = new Long(0, 0);
            var inductionVariable_5 = 0;
            if (inductionVariable_5 < n)
              do {
                var i_4 = inductionVariable_5;
                inductionVariable_5 = inductionVariable_5 + 1 | 0;
                var tmp0_5 = fromInt(dividend[j + i_4 | 0]);
                // Inline function 'kotlin.Long.plus' call
                var other_4 = divisor[i_4];
                var tmp$ret$22 = add(tmp0_5, fromInt(other_4));
                var sum = add(tmp$ret$22, carry_2);
                dividend[j + i_4 | 0] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
                carry_2 = shiftRightUnsigned(sum, 30);
              }
               while (inductionVariable_5 < n);
            dividend[j + n | 0] = convertToInt(bitwiseAnd(add(fromInt(dividend[j + n | 0]), carry_2), new Long(1073741823, 0)));
          }
          if (!(quotient_0 == null)) {
            quotient_0[j] = convertToInt(estimate);
          }
        }
         while (0 <= inductionVariable_3);
      var remainder_0 = true ? new Int32Array(n) : null;
      if (!(remainder_0 == null)) {
        var inductionVariable_6 = 0;
        if (inductionVariable_6 < n)
          do {
            var i_5 = inductionVariable_6;
            inductionVariable_6 = inductionVariable_6 + 1 | 0;
            remainder_0[i_5] = shift === 0 ? dividend[i_5] : dividend[i_5] >>> shift | 0 | convertToInt(bitwiseAnd(shiftLeft(fromInt(dividend[i_5 + 1 | 0]), 30 - shift | 0), new Long(1073741823, 0)));
          }
           while (inductionVariable_6 < n);
      }
      !(quotient_0 == null) ? normalized(Companion_getInstance_1(), imul($this.oi_1, value.oi_1), quotient_0) : Companion_getInstance_1().yj_1;
      tmp$ret$0 = !(remainder_0 == null) ? normalized(Companion_getInstance_1(), $this.oi_1, remainder_0) : Companion_getInstance_1().yj_1;
    }
    return tmp$ret$0;
  }
  function divideStored($this, value) {
    var tmp$ret$0;
    $l$block_1: {
      // Inline function 'io.heapy.krogu.math.BigInteger.selectStoredDivision' call
      if (value.oi_1 === 0)
        throw ArithmeticException_init_$Create$('BigInteger divide by zero');
      if ($this.ri_1 === 1 && value.ri_1 === 1) {
        var a = $this.cl();
        var b = value.cl();
        var tmp;
        if (!true) {
          tmp = Companion_getInstance_1().yj_1;
        } else if (equalsLong(a, new Long(0, -2147483648)) && equalsLong(b, new Long(-1, -1))) {
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$1 = new Int32Array([0, 0, 8]);
          tmp = BigInteger_init_$Create$_0(1, tmp$ret$1);
        } else {
          tmp = compactResult529(Companion_getInstance_1(), divide(a, b));
        }
        var quotient = tmp;
        // Inline function 'kotlin.arrayOf' call
        // Inline function 'kotlin.js.unsafeCast' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp$ret$0 = [quotient, true ? compactResult529(Companion_getInstance_1(), modulo(a, b)) : Companion_getInstance_1().yj_1];
        break $l$block_1;
      }
      var words = materializeMagnitude($this);
      var valueWords = value.ri_1 === 1 ? null : value === $this ? words : materializeMagnitude(value);
      if (!(valueWords == null) && compareMagnitude_0(Companion_getInstance_1(), words, valueWords) < 0) {
        // Inline function 'kotlin.arrayOf' call
        // Inline function 'kotlin.js.unsafeCast' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp$ret$0 = [Companion_getInstance_1().yj_1, true ? normalized(Companion_getInstance_1(), $this.oi_1, words) : Companion_getInstance_1().yj_1];
        break $l$block_1;
      }
      var tmp1_elvis_lhs = valueWords == null ? null : valueWords.length;
      var n = tmp1_elvis_lhs == null ? ((magnitudeBits(value) + 30 | 0) - 1 | 0) / 30 | 0 : tmp1_elvis_lhs;
      var compactDivisor = valueWords == null ? value.cl() : new Long(0, 0);
      if (n === 1) {
        var tmp3_elvis_lhs = valueWords == null ? null : valueWords[0];
        var divisorWord = tmp3_elvis_lhs == null ? CompactInteger529_getInstance().ls(value.pi_1, value.qi_1, 0) : tmp3_elvis_lhs;
        var result = true ? new Int32Array(words.length) : null;
        var remainder = new Long(0, 0);
        var inductionVariable = words.length - 1 | 0;
        if (0 <= inductionVariable)
          do {
            var i = inductionVariable;
            inductionVariable = inductionVariable + -1 | 0;
            var tmp0 = shiftLeft(remainder, 30);
            // Inline function 'kotlin.Long.plus' call
            var other = words[i];
            var part = add(tmp0, fromInt(other));
            if (!(result == null)) {
              // Inline function 'kotlin.Long.div' call
              var tmp$ret$11 = divide(part, fromInt(divisorWord));
              result[i] = convertToInt(tmp$ret$11);
            }
            // Inline function 'kotlin.Long.rem' call
            remainder = modulo(part, fromInt(divisorWord));
          }
           while (0 <= inductionVariable);
        var tmp0_0 = !(result == null) ? normalized(Companion_getInstance_1(), imul($this.oi_1, value.oi_1), result) : Companion_getInstance_1().yj_1;
        var tmp_0;
        if (true) {
          var tmp_1 = Companion_getInstance_1();
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$13 = new Int32Array([convertToInt(remainder)]);
          tmp_0 = normalized(tmp_1, $this.oi_1, tmp$ret$13);
        } else {
          tmp_0 = Companion_getInstance_1().yj_1;
        }
        // Inline function 'kotlin.arrayOf' call
        // Inline function 'kotlin.js.unsafeCast' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp$ret$0 = [tmp0_0, tmp_0];
        break $l$block_1;
      }
      var tmp5_elvis_lhs = valueWords == null ? null : last(valueWords);
      var highWord = tmp5_elvis_lhs == null ? CompactInteger529_getInstance().ls(value.pi_1, value.qi_1, n - 1 | 0) : tmp5_elvis_lhs;
      // Inline function 'kotlin.countLeadingZeroBits' call
      var shift = clz32(highWord) - 2 | 0;
      var divisor = new Int32Array(n);
      if (!(valueWords == null)) {
        // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < n)
          do {
            var i_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp$ret$20 = valueWords[i_0];
            var digit = bitwiseOr(shiftLeft(fromInt(tmp$ret$20), shift), carry);
            divisor[i_0] = convertToInt(bitwiseAnd(digit, new Long(1073741823, 0)));
            carry = shiftRightUnsigned(digit, 30);
          }
           while (inductionVariable_0 < n);
        convertToInt(carry);
      } else {
        // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
        var carry_0 = new Long(0, 0);
        var inductionVariable_1 = 0;
        if (inductionVariable_1 < n)
          do {
            var i_1 = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var tmp$ret$22 = CompactInteger529_getInstance().ls(convertToInt(shiftRight(compactDivisor, 32)), convertToInt(compactDivisor), i_1);
            var digit_0 = bitwiseOr(shiftLeft(fromInt(tmp$ret$22), shift), carry_0);
            divisor[i_1] = convertToInt(bitwiseAnd(digit_0, new Long(1073741823, 0)));
            carry_0 = shiftRightUnsigned(digit_0, 30);
          }
           while (inductionVariable_1 < n);
        convertToInt(carry_0);
      }
      var dividend = new Int32Array(words.length + 1 | 0);
      var tmp_2 = words.length;
      // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
      var sourceSize = words.length;
      var carry_1 = new Long(0, 0);
      var inductionVariable_2 = 0;
      if (inductionVariable_2 < sourceSize)
        do {
          var i_2 = inductionVariable_2;
          inductionVariable_2 = inductionVariable_2 + 1 | 0;
          var tmp$ret$24 = words[i_2];
          var digit_1 = bitwiseOr(shiftLeft(fromInt(tmp$ret$24), shift), carry_1);
          dividend[i_2] = convertToInt(bitwiseAnd(digit_1, new Long(1073741823, 0)));
          carry_1 = shiftRightUnsigned(digit_1, 30);
        }
         while (inductionVariable_2 < sourceSize);
      dividend[tmp_2] = convertToInt(carry_1);
      var quotient_0 = true ? new Int32Array((words.length - n | 0) + 1 | 0) : null;
      // Inline function 'kotlin.Long.plus' call
      var this_0 = new Long(1073741823, 0);
      var radix = add(this_0, fromInt(1));
      var high = fromInt(divisor[n - 1 | 0]);
      var next = fromInt(divisor[n - 2 | 0]);
      var inductionVariable_3 = words.length - n | 0;
      if (0 <= inductionVariable_3)
        do {
          var j = inductionVariable_3;
          inductionVariable_3 = inductionVariable_3 + -1 | 0;
          var tmp0_1 = shiftLeft(fromInt(dividend[j + n | 0]), 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = dividend[(j + n | 0) - 1 | 0];
          var top = add(tmp0_1, fromInt(other_0));
          var tmp0_2 = divide(top, high);
          // Inline function 'kotlin.comparisons.minOf' call
          var b_0 = new Long(1073741823, 0);
          var estimate = compare(tmp0_2, b_0) <= 0 ? tmp0_2 : b_0;
          var residual = subtract(top, multiply(estimate, high));
          $l$loop: while (true) {
            var tmp_3;
            if (compare(residual, radix) < 0) {
              var tmp_4 = multiply(estimate, next);
              var tmp0_3 = shiftLeft(residual, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_1 = dividend[(j + n | 0) - 2 | 0];
              var tmp$ret$28 = add(tmp0_3, fromInt(other_1));
              tmp_3 = compare(tmp_4, tmp$ret$28) > 0;
            } else {
              tmp_3 = false;
            }
            if (!tmp_3) {
              break $l$loop;
            }
            var _unary__edvuaz = estimate;
            estimate = subtract(_unary__edvuaz, get_ONE());
            residual = add(residual, high);
          }
          var borrow = new Long(0, 0);
          var inductionVariable_4 = 0;
          if (inductionVariable_4 < n)
            do {
              var i_3 = inductionVariable_4;
              inductionVariable_4 = inductionVariable_4 + 1 | 0;
              var tmp0_4 = estimate;
              // Inline function 'kotlin.Long.times' call
              var other_2 = divisor[i_3];
              var tmp$ret$29 = multiply(tmp0_4, fromInt(other_2));
              var product = add(tmp$ret$29, borrow);
              var difference = subtract(fromInt(dividend[j + i_3 | 0]), bitwiseAnd(product, new Long(1073741823, 0)));
              dividend[j + i_3 | 0] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
              var tmp0_5 = shiftRightUnsigned(product, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_3 = compare(difference, new Long(0, 0)) < 0 ? 1 : 0;
              borrow = add(tmp0_5, fromInt(other_3));
            }
             while (inductionVariable_4 < n);
          var difference_0 = subtract(fromInt(dividend[j + n | 0]), borrow);
          dividend[j + n | 0] = convertToInt(bitwiseAnd(difference_0, new Long(1073741823, 0)));
          if (compare(difference_0, new Long(0, 0)) < 0) {
            var _unary__edvuaz_0 = estimate;
            estimate = subtract(_unary__edvuaz_0, get_ONE());
            var carry_2 = new Long(0, 0);
            var inductionVariable_5 = 0;
            if (inductionVariable_5 < n)
              do {
                var i_4 = inductionVariable_5;
                inductionVariable_5 = inductionVariable_5 + 1 | 0;
                var tmp0_6 = fromInt(dividend[j + i_4 | 0]);
                // Inline function 'kotlin.Long.plus' call
                var other_4 = divisor[i_4];
                var tmp$ret$31 = add(tmp0_6, fromInt(other_4));
                var sum = add(tmp$ret$31, carry_2);
                dividend[j + i_4 | 0] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
                carry_2 = shiftRightUnsigned(sum, 30);
              }
               while (inductionVariable_5 < n);
            dividend[j + n | 0] = convertToInt(bitwiseAnd(add(fromInt(dividend[j + n | 0]), carry_2), new Long(1073741823, 0)));
          }
          if (!(quotient_0 == null)) {
            quotient_0[j] = convertToInt(estimate);
          }
        }
         while (0 <= inductionVariable_3);
      var remainder_0 = true ? new Int32Array(n) : null;
      if (!(remainder_0 == null)) {
        var inductionVariable_6 = 0;
        if (inductionVariable_6 < n)
          do {
            var i_5 = inductionVariable_6;
            inductionVariable_6 = inductionVariable_6 + 1 | 0;
            remainder_0[i_5] = shift === 0 ? dividend[i_5] : dividend[i_5] >>> shift | 0 | convertToInt(bitwiseAnd(shiftLeft(fromInt(dividend[i_5 + 1 | 0]), 30 - shift | 0), new Long(1073741823, 0)));
          }
           while (inductionVariable_6 < n);
      }
      // Inline function 'kotlin.arrayOf' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp$ret$0 = [!(quotient_0 == null) ? normalized(Companion_getInstance_1(), imul($this.oi_1, value.oi_1), quotient_0) : Companion_getInstance_1().yj_1, !(remainder_0 == null) ? normalized(Companion_getInstance_1(), $this.oi_1, remainder_0) : Companion_getInstance_1().yj_1];
    }
    return tmp$ret$0;
  }
  function shiftPower($this, value, distance) {
    var tmp;
    if (distance > 0 && !(value.oi_1 === 0)) {
      // Inline function 'kotlin.Long.plus' call
      var this_0 = fromInt(magnitudeBits(value));
      var tmp$ret$0 = add(this_0, fromInt(distance));
      tmp = compare(tmp$ret$0, new Long(2147483647, 0)) > 0;
    } else {
      tmp = false;
    }
    if (tmp)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    return shiftLeftValue(value, distance);
  }
  function oddModPowStored($this, exponent, modulus) {
    var words = materializeMagnitude($this);
    var tmp;
    if (exponent == null) {
      throw NullPointerException_init_$Create$();
    } else {
      tmp = exponent;
    }
    var power = tmp;
    if (power.equals(Companion_getInstance_1().zj_1))
      return $this;
    // Inline function 'kotlin.collections.isEmpty' call
    if (words.length === 0)
      return Companion_getInstance_1().yj_1;
    var m = BigInteger_init_$Create$_0(1, materializeMagnitude(modulus));
    var base = BigInteger_init_$Create$_0(1, words).ir(m);
    var result = Companion_getInstance_1().zj_1.ir(m);
    var bits = magnitudeBits(power);
    var baseWords = materializeMagnitude(base);
    var powerWords = materializeMagnitude(power);
    var trivialBase = base.oi_1 === 0 || (baseWords.length === 1 && baseWords[0] === 1);
    var tmp_0;
    if (powerWords.length === 1) {
      var tmp_1 = multiply(fromInt(powerWords[0]), fromInt(magnitudeBits(base)));
      // Inline function 'kotlin.Long.minus' call
      var this_0 = fromInt(magnitudeBits(m));
      var tmp$ret$1 = subtract(this_0, fromInt(1));
      tmp_0 = compare(tmp_1, tmp$ret$1) <= 0;
    } else {
      tmp_0 = false;
    }
    var belowModulus = tmp_0;
    var context = bits === 0 || trivialBase || belowModulus ? null : Companion_instance_1.kr(m);
    if (!(context == null))
      return context.ms(base, power, bits);
    var inductionVariable = 0;
    if (inductionVariable < bits)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!((powerWords[i / 30 | 0] & 1 << (i % 30 | 0)) === 0))
          result = multiplyMod(result, base, m);
        if ((i + 1 | 0) < bits)
          base = multiplyMod(base, base, m);
      }
       while (inductionVariable < bits);
    return result.oi_1 === 0 ? BigInteger_init_$Create$_1(result) : result;
  }
  function OddModulusContext(modulus, rho, oneMont, r2) {
    this.dr_1 = modulus;
    this.er_1 = rho;
    this.fr_1 = oneMont;
    this.gr_1 = r2;
  }
  protoOf(OddModulusContext).ms = function (base, power, bits) {
    var powerWords = materializeMagnitude(power);
    var workspace = new Workspace(this.dr_1.length);
    var tmp0 = materializeMagnitude(base);
    // Inline function 'kotlin.collections.copyInto' call
    var destination = workspace.sq_1;
    var endIndex = tmp0.length;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp = tmp0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp, destination, 0, 0, endIndex);
    var factor = workspace.tq_1;
    var result = workspace.uq_1;
    var next = workspace.vq_1;
    multiply_0(this, workspace.sq_1, this.gr_1, factor, workspace.rq_1);
    var tmp0_0 = this.fr_1;
    // Inline function 'kotlin.collections.copyInto' call
    var destination_0 = result;
    var endIndex_0 = tmp0_0.length;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_0 = tmp0_0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp_0, destination_0, 0, 0, endIndex_0);
    var inductionVariable = 0;
    if (inductionVariable < bits)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!((powerWords[i / 30 | 0] & 1 << (i % 30 | 0)) === 0)) {
          multiply_0(this, result, factor, next, workspace.rq_1);
          var previous = result;
          result = next;
          next = previous;
        }
        if ((i + 1 | 0) < bits) {
          multiply_0(this, factor, factor, next, workspace.rq_1);
          var previous_0 = factor;
          factor = next;
          next = previous_0;
        }
      }
       while (inductionVariable < bits);
    multiply_0(this, result, null, next, workspace.rq_1);
    var tmp0_1 = next;
    var tmp$ret$10;
    $l$block: {
      // Inline function 'kotlin.collections.all' call
      var inductionVariable_0 = 0;
      var last = tmp0_1.length;
      while (inductionVariable_0 < last) {
        var element = tmp0_1[inductionVariable_0];
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        if (!(element === 0)) {
          tmp$ret$10 = false;
          break $l$block;
        }
      }
      tmp$ret$10 = true;
    }
    if (tmp$ret$10)
      return BigInteger_init_$Create$_1(Companion_getInstance_1().yj_1);
    var tmp_1 = Companion_getInstance_1();
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$12 = next.slice();
    return normalized(tmp_1, 1, tmp$ret$12);
  };
  protoOf(OddModulusContext).ns = function (power, twos, minusOne) {
    return new WitnessSession(this, power, twos, minusOne);
  };
  function moduloPowerOfTwo($this, bits) {
    var words = materializeMagnitude($this);
    if ($this.en() <= bits)
      return $this;
    if (bits === 0)
      return Companion_getInstance_1().yj_1;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(bits);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(30));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = divide(this_2, fromInt(30));
    var out = copyOf(words, convertToInt(tmp$ret$2));
    if (!((bits % 30 | 0) === 0)) {
      out[get_lastIndex(out)] = last(out) & ((1 << (bits % 30 | 0)) - 1 | 0);
    }
    return normalized(Companion_getInstance_1(), 1, out);
  }
  function modPowPowerOfTwo($this, exponent, bits) {
    var base = moduloPowerOfTwo($this, bits);
    var result = Companion_getInstance_1().zj_1;
    var tmp;
    if (exponent == null) {
      throw NullPointerException_init_$Create$();
    } else {
      tmp = exponent;
    }
    var power = tmp;
    var limit = power.en();
    if ($this.bl(0)) {
      var tmp0 = bits - 1 | 0;
      // Inline function 'kotlin.comparisons.minOf' call
      var b = limit;
      limit = Math.min(tmp0, b);
    }
    var inductionVariable = 0;
    var last = limit;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (power.bl(i))
          result = multiplyPowerOfTwo(result, base, bits);
        if ((i + 1 | 0) < limit)
          base = multiplyPowerOfTwo(BigInteger_init_$Create$_0(base.oi_1, materializeMagnitude(base)), base, bits);
      }
       while (inductionVariable < last);
    return result;
  }
  function multiplyPowerOfTwo($this, value, bits) {
    var words = materializeMagnitude($this);
    var tmp0 = fromInt(magnitudeBits($this));
    // Inline function 'kotlin.Long.plus' call
    var other = magnitudeBits(value);
    var tmp$ret$0 = add(tmp0, fromInt(other));
    if (compare(tmp$ret$0, new Long(2147483647, 0)) <= 0)
      return moduloPowerOfTwo($this.hk(value), bits);
    var modulus = shiftLeftValue(Companion_getInstance_1().zj_1, bits);
    var a = BigInteger_init_$Create$_0(1, words).ir(modulus);
    var b = BigInteger_init_$Create$_0(1, materializeMagnitude(value)).ir(modulus);
    return a.os(b, modulus);
  }
  function multiplyMod($this, value, m) {
    var tmp;
    var tmp0 = fromInt(magnitudeBits($this));
    // Inline function 'kotlin.Long.plus' call
    var other = magnitudeBits(value);
    var tmp$ret$0 = add(tmp0, fromInt(other));
    if (compare(tmp$ret$0, new Long(2147483647, 0)) <= 0) {
      tmp = $this.hk(value).ir(m);
    } else {
      tmp = $this.os(value, m);
    }
    return tmp;
  }
  function sqrtStored($this) {
    var words = materializeMagnitude($this);
    if ($this.oi_1 < 0)
      throw ArithmeticException_init_$Create$('Negative BigInteger');
    if ($this.oi_1 === 0)
      return Companion_getInstance_1().yj_1;
    var bits = magnitudeBits($this);
    if (bits === 1)
      return normalized(Companion_getInstance_1(), 1, words);
    var value = BigInteger_init_$Create$_0(1, words);
    var x = shiftLeftValue(Companion_getInstance_1().zj_1, MagnitudeLimits_instance.ps(bits));
    while (true) {
      var next = shiftRightValue(x.al(quotientStored(value, x)), 1);
      if (compareMagnitude_0(Companion_getInstance_1(), materializeMagnitude(next), materializeMagnitude(x)) >= 0)
        return normalized(Companion_getInstance_1(), 1, materializeMagnitude(x));
      x = next;
    }
  }
  function shiftLeftValue($this, n) {
    if ($this.oi_1 === 0)
      return Companion_getInstance_1().yj_1;
    if (n === 0)
      return $this;
    if (n < 0)
      return n === -2147483648 ? $this.oi_1 < 0 ? Companion_getInstance_1().zj_1.jk() : Companion_getInstance_1().yj_1 : shiftRightValue($this, -n | 0);
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(magnitudeBits($this));
    var tmp$ret$0 = add(this_0, fromInt(n));
    if (compare(tmp$ret$0, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    if ($this.ri_1 === 1 && n < 64) {
      var value = $this.cl();
      var shifted = shiftLeft(value, n);
      if (equalsLong(shiftRight(shifted, n), value))
        return compactResult529(Companion_getInstance_1(), shifted);
    }
    var words = materializeMagnitude($this);
    var whole = n / 30 | 0;
    var bits = n % 30 | 0;
    var result = new Int32Array((words.length + whole | 0) + 1 | 0);
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = words.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var v = bitwiseOr(shiftLeft(fromInt(words[i]), bits), carry);
        result[i + whole | 0] = convertToInt(bitwiseAnd(v, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(v, 30);
      }
       while (inductionVariable <= last);
    result[words.length + whole | 0] = convertToInt(carry);
    return normalized(Companion_getInstance_1(), $this.oi_1, result);
  }
  function shiftRightValue($this, n) {
    if ($this.oi_1 === 0)
      return Companion_getInstance_1().yj_1;
    if (n === 0)
      return $this;
    if (n < 0) {
      if (n === -2147483648)
        throw ArithmeticException_init_$Create$('BigInteger overflow');
      return shiftLeftValue($this, -n | 0);
    }
    if (n >= magnitudeBits($this))
      return $this.oi_1 < 0 ? Companion_getInstance_1().zj_1.jk() : Companion_getInstance_1().yj_1;
    if ($this.ri_1 === 1)
      return compactResult529(Companion_getInstance_1(), shiftRight($this.cl(), n));
    var words = materializeMagnitude($this);
    var whole = n / 30 | 0;
    var bits = n % 30 | 0;
    var result = new Int32Array(words.length - whole | 0);
    var inductionVariable = 0;
    var last = result.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var v = words[i + whole | 0] >>> bits | 0;
        if (!(bits === 0) && ((i + whole | 0) + 1 | 0) < words.length)
          v = v | words[(i + whole | 0) + 1 | 0] << (30 - bits | 0) & 1073741823;
        result[i] = v;
      }
       while (inductionVariable <= last);
    var truncated = normalized(Companion_getInstance_1(), $this.oi_1, result);
    return $this.oi_1 < 0 && lowestSetBitValue($this) < n ? truncated.yk(Companion_getInstance_1().zj_1) : truncated;
  }
  function magnitudeBits($this) {
    var tmp;
    if ($this.ri_1 === 1) {
      tmp = CompactInteger529_getInstance().ds($this.cl());
    } else {
      var tmp_0 = imul(ensureNotNull($this.si_1).length - 1 | 0, 30) + 32 | 0;
      // Inline function 'kotlin.countLeadingZeroBits' call
      var this_0 = last($this.si_1);
      tmp = tmp_0 - clz32(this_0) | 0;
    }
    return tmp;
  }
  function lowestSetBitValue($this) {
    if ($this.ri_1 === 1) {
      var value = $this.cl();
      return equalsLong(value, new Long(0, 0)) ? -1 : countTrailingZeroBits(value);
    }
    var words = materializeMagnitude($this);
    var inductionVariable = 0;
    var last = words.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(words[i] === 0))
          return imul(i, 30) + countTrailingZeroBits_0(words[i]) | 0;
      }
       while (inductionVariable <= last);
    return -1;
  }
  function firstNonzeroWord($this) {
    if ($this.ri_1 === 1)
      return countTrailingZeroBits($this.cl()) / 30 | 0;
    var words = materializeMagnitude($this);
    var first = 0;
    while (words[first] === 0) {
      first = first + 1 | 0;
    }
    return first;
  }
  function testBitValue($this, n) {
    if (n < 0)
      throw ArithmeticException_init_$Create$('Negative bit address');
    if ($this.ri_1 === 1)
      return n >= 64 ? $this.oi_1 < 0 : !equalsLong(bitwiseAnd($this.cl(), shiftLeft(new Long(1, 0), n)), new Long(0, 0));
    var words = materializeMagnitude($this);
    if (n < 0)
      throw ArithmeticException_init_$Create$('Negative bit address');
    var index = n / 30 | 0;
    // Inline function 'kotlin.collections.getOrElse' call
    var tmp;
    if (0 <= index ? index <= (words.length - 1 | 0) : false) {
      tmp = words[index];
    } else {
      tmp = 0;
    }
    var raw = tmp;
    var tmp_0;
    if ($this.oi_1 >= 0) {
      tmp_0 = raw;
    } else {
      var first = firstNonzeroWord($this);
      tmp_0 = index < first ? 0 : index === first ? -raw | 0 : ~raw;
    }
    var word = tmp_0;
    return !((word & 1 << (n % 30 | 0)) === 0);
  }
  function changeBit($this, n, operation) {
    if (n < 0)
      throw ArithmeticException_init_$Create$('Negative bit address');
    var length32 = bitwiseLength32($this);
    var present = testBitValue($this, n);
    if (n === 2147483647 && (operation === 1 && present || (operation === 0 && !present)))
      return BigInteger_init_$Create$_1($this);
    if (n === 2147483647)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    var index = n / 30 | 0;
    var tmp;
    if (operation === 0) {
      // Inline function 'kotlin.Long.plus' call
      var this_0 = fromInt(n);
      // Inline function 'kotlin.Long.div' call
      var this_1 = add(this_0, fromInt(1));
      // Inline function 'kotlin.Long.plus' call
      var this_2 = divide(this_1, fromInt(32));
      var tmp$ret$2 = add(this_2, fromInt(1));
      tmp = convertToInt(tmp$ret$2);
    } else {
      tmp = (n / 32 | 0) + 2 | 0;
    }
    var addressedLength32 = tmp;
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$3 = Math.max(length32, addressedLength32);
    // Inline function 'kotlin.Long.times' call
    var this_3 = fromInt(tmp$ret$3);
    var width = multiply(this_3, fromInt(32));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.minus' call
    var this_4 = add(width, fromInt(30));
    // Inline function 'kotlin.Long.div' call
    var this_5 = subtract(this_4, fromInt(1));
    var tmp$ret$7 = divide(this_5, fromInt(30));
    var result = twosComplement($this, convertToInt(tmp$ret$7));
    var mask = 1 << (n % 30 | 0);
    result[index] = operation === 0 ? result[index] & ~mask : operation === 1 ? result[index] | mask : result[index] ^ mask;
    return bitwiseResult($this, result, width);
  }
  function bitwiseLength32($this) {
    return ($this.en() >>> 5 | 0) + 1 | 0;
  }
  function bitwise($this, value, op) {
    var tmp0 = bitwiseLength32($this);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = bitwiseLength32(value);
    var tmp$ret$0 = Math.max(tmp0, b);
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(tmp$ret$0);
    var width = multiply(this_0, fromInt(32));
    if (getKClassFromExpression($this).equals(getKClass(BigInteger)) && getKClassFromExpression(value).equals(getKClass(BigInteger)) && $this.ri_1 === 1 && value.ri_1 === 1)
      return BigInteger_init_$Create$(CompactInteger529_getInstance().gl(op($this.pi_1, value.pi_1), op($this.qi_1, value.qi_1)));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(width, fromInt(30));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$4 = divide(this_2, fromInt(30));
    var length = convertToInt(tmp$ret$4);
    var a = twosComplement($this, length);
    var b_0 = twosComplement(value, length);
    var tmp = 0;
    var tmp_0 = new Int32Array(length);
    while (tmp < length) {
      var tmp_1 = tmp;
      tmp_0[tmp_1] = op(a[tmp_1], b_0[tmp_1]) & 1073741823;
      tmp = tmp + 1 | 0;
    }
    var out = tmp_0;
    return bitwiseResult($this, out, width);
  }
  function bitwiseResult($this, out, width) {
    // Inline function 'kotlin.Long.minus' call
    // Inline function 'kotlin.Long.rem' call
    var this_0 = subtract(width, fromInt(1));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = modulo(this_0, fromInt(30));
    var tmp$ret$2 = add(this_1, fromInt(1));
    var highBits = convertToInt(tmp$ret$2);
    var highMask = (1 << highBits) - 1 | 0;
    out[get_lastIndex(out)] = last(out) & highMask;
    if (!((last(out) & 1 << (highBits - 1 | 0)) === 0)) {
      out[get_lastIndex(out)] = last(out) | 1073741823 ^ highMask;
    }
    var result = fromTwosComplement($this, out);
    return result.oi_1 === 0 ? BigInteger_init_$Create$_1(result) : result;
  }
  function fromTwosComplement($this, out) {
    if ((last(out) & 536870912) === 0)
      return normalized(Companion_getInstance_1(), 1, out);
    var carry = new Long(1, 0);
    var inductionVariable = 0;
    var last_0 = out.length - 1 | 0;
    if (inductionVariable <= last_0)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var v = add(fromInt(~out[i] & 1073741823), carry);
        out[i] = convertToInt(bitwiseAnd(v, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(v, 30);
      }
       while (inductionVariable <= last_0);
    return normalized(Companion_getInstance_1(), -1, out);
  }
  function twosComplement($this, length) {
    var words = materializeMagnitude($this);
    if ($this.oi_1 >= 0)
      return copyOf(words, length);
    var out = new Int32Array(length);
    var carry = new Long(1, 0);
    var inductionVariable = 0;
    var last = out.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.collections.getOrElse' call
        var tmp;
        if (0 <= i ? i <= (words.length - 1 | 0) : false) {
          tmp = words[i];
        } else {
          tmp = 0;
        }
        var tmp$ret$0 = tmp;
        var v = add(fromInt(~tmp$ret$0 & 1073741823), carry);
        out[i] = convertToInt(bitwiseAnd(v, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(v, 30);
      }
       while (inductionVariable <= last);
    return out;
  }
  function passesPrimeTest($this, rounds) {
    var n = $this.xk();
    if (n.equals(Companion_getInstance_1().ak_1))
      return true;
    if (!n.bl(0) || n.equals(Companion_getInstance_1().zj_1))
      return false;
    n.en();
    if (n.oi_1 < 0)
      return false;
    // Inline function 'kotlin.intArrayOf' call
    var smallPrimes = new Int32Array([2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]);
    var inductionVariable = 0;
    var last = smallPrimes.length;
    while (inductionVariable < last) {
      var p = smallPrimes[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      var prime = Companion_getInstance_1().fk(fromInt(p));
      if (n.equals(prime))
        return true;
      if (n.xl(prime).oi_1 === 0)
        return false;
    }
    var nm1 = n.yk(Companion_getInstance_1().zj_1);
    var s = nm1.vl();
    var d = nm1.wl(s);
    var ordinary = getKClassFromExpression(n).equals(getKClass(BigInteger)) && getKClassFromExpression(nm1).equals(getKClass(BigInteger)) && getKClassFromExpression(d).equals(getKClass(BigInteger));
    var attemptedContext = {_v: false};
    var witnesses = {_v: null};
    if (n.zk(Companion_getInstance_1().dk_1) < 0) {
      var indexedObject = Companion_getInstance_1().ek_1;
      var inductionVariable_0 = 0;
      var last_0 = indexedObject.length;
      while (inductionVariable_0 < last_0) {
        var base = indexedObject[inductionVariable_0];
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        if (!passesPrimeTest$passesWitness(ordinary, attemptedContext, witnesses, n, d, s, nm1, Companion_getInstance_1().fk(fromInt(base))))
          return false;
      }
      return true;
    }
    var remaining = rounds;
    while (compare(remaining, new Long(0, 0)) > 0) {
      var _unary__edvuaz = remaining;
      remaining = subtract(_unary__edvuaz, get_ONE());
      var a;
      do {
        a = randomBits(Companion_getInstance_1(), n.en(), Default_getInstance());
      }
       while (a.zk(Companion_getInstance_1().ak_1) < 0 || a.zk(nm1) >= 0);
      if (!passesPrimeTest$passesWitness(ordinary, attemptedContext, witnesses, n, d, s, nm1, a))
        return false;
    }
    return true;
  }
  function magnitudeWord32($this, index) {
    if ($this.ri_1 === 1) {
      var value = $this.cl();
      var magnitude = compare(value, new Long(0, 0)) < 0 ? negate(value) : value;
      return (0 <= index ? index <= 1 : false) ? bitwiseAnd(shiftRightUnsigned(magnitude, imul(index, 32)), new Long(-1, 0)) : new Long(0, 0);
    }
    var words = materializeMagnitude($this);
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(index);
    var start = multiply(this_0, fromInt(32));
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(start, fromInt(30));
    var word = convertToInt(tmp$ret$1);
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(start, fromInt(30));
    var offset = convertToInt(tmp$ret$2);
    var chunk = shiftRightUnsigned(fromInt(words[word]), offset);
    if ((word + 1 | 0) < words.length)
      chunk = bitwiseOr(chunk, shiftLeft(fromInt(words[word + 1 | 0]), 30 - offset | 0));
    return bitwiseAnd(chunk, new Long(-1, 0));
  }
  function toPowerOfTwoString($this, radix, negative) {
    var words = materializeMagnitude($this);
    var bitsPerDigit;
    switch (radix) {
      case 2:
        bitsPerDigit = 1;
        break;
      case 4:
        bitsPerDigit = 2;
        break;
      case 8:
        bitsPerDigit = 3;
        break;
      case 16:
        bitsPerDigit = 4;
        break;
      default:
        bitsPerDigit = 5;
        break;
    }
    var top = last(words);
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(words.length - 1 | 0);
    var tmp0 = multiply(this_0, fromInt(30));
    // Inline function 'kotlin.countLeadingZeroBits' call
    // Inline function 'kotlin.Long.plus' call
    var other = 32 - clz32(top) | 0;
    var bitLength = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = bitsPerDigit;
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(bitLength, fromInt(other_0));
    var tmp0_0 = subtract(this_1, fromInt(1));
    // Inline function 'kotlin.Long.div' call
    var other_1 = bitsPerDigit;
    var digitCountLong = divide(tmp0_0, fromInt(other_1));
    // Inline function 'kotlin.Long.plus' call
    var other_2 = negative ? 1 : 0;
    var capacityLong = add(digitCountLong, fromInt(other_2));
    if (compare(capacityLong, new Long(2147483647, 0)) > 0) {
      plainStringTooLarge();
    }
    var digitCount = convertToInt(digitCountLong);
    // Inline function 'kotlin.Long.minus' call
    var this_2 = shiftLeft(new Long(1, 0), bitsPerDigit);
    var mask = subtract(this_2, fromInt(1));
    var text = StringBuilder_init_$Create$(convertToInt(capacityLong));
    if (negative) {
      text.n(_Char___init__impl__6a9atx(45));
    }
    var inductionVariable = digitCount - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0_1 = fromInt(index);
        // Inline function 'kotlin.Long.times' call
        var other_3 = bitsPerDigit;
        var bit = multiply(tmp0_1, fromInt(other_3));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$9 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$9);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$10 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$10);
        var digit = shiftRightUnsigned(fromInt(words[word]), offset);
        if ((offset + bitsPerDigit | 0) > 30 && (word + 1 | 0) < words.length)
          digit = bitwiseOr(digit, shiftLeft(fromInt(words[word + 1 | 0]), 30 - offset | 0));
        text.n(charCodeAt('0123456789abcdefghijklmnopqrstuvwxyz', convertToInt(bitwiseAnd(digit, mask))));
      }
       while (0 <= inductionVariable);
    return text.toString();
  }
  function divideDecimalChunk($this, magnitude, length, divisor) {
    var remainder = new Long(0, 0);
    var inductionVariable = length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = shiftLeft(remainder, 30);
        // Inline function 'kotlin.Long.plus' call
        var other = magnitude[i];
        var part = add(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$1 = divide(part, fromInt(divisor));
        magnitude[i] = convertToInt(tmp$ret$1);
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(divisor));
      }
       while (0 <= inductionVariable);
    return convertToInt(remainder);
  }
  function compareDecimalScratch($this, magnitude, length, other) {
    if (!(length === other.length))
      return compareTo(length, other.length);
    var inductionVariable = length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var order = compareTo(magnitude[i], other[i]);
        if (!(order === 0))
          return order;
      }
       while (0 <= inductionVariable);
    return 0;
  }
  function DecimalBinaryPrefix(magnitude, decimalDigits, discardedDigits, sticky) {
    this.an_1 = magnitude;
    this.bn_1 = decimalDigits;
    this.cn_1 = discardedDigits;
    this.dn_1 = sticky;
  }
  function floatingValue($this, precision, maxExponent, dispatchSmallValue) {
    dispatchSmallValue = dispatchSmallValue === VOID ? true : dispatchSmallValue;
    if ($this.oi_1 === 0)
      return 0.0;
    var bits = magnitudeBits($this);
    if (dispatchSmallValue && bits <= 63) {
      var small = $this.um();
      return precision === 53 ? toNumber(small) : floatingValue(Companion_getInstance_1().fk(small), precision, maxExponent, false);
    }
    if (bits > maxExponent)
      return $this.oi_1 < 0 ? -Infinity : Infinity;
    var words = $this.si_1;
    var stored = $this.cl();
    var compactMagnitude = compare(stored, new Long(0, 0)) < 0 ? negate(stored) : stored;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = bits - precision | 0;
    var shift = Math.max(0, b);
    var top = new Long(0, 0);
    var inductionVariable = bits - 1 | 0;
    if (shift <= inductionVariable)
      do {
        var bit = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        top = bitwiseOr(shiftLeft(top, 1), floatingValue$magnitudeBit($this, compactMagnitude, words, bit) ? new Long(1, 0) : new Long(0, 0));
      }
       while (!(bit === shift));
    if (shift > 0 && floatingValue$magnitudeBit($this, compactMagnitude, words, shift - 1 | 0) && (lowestSetBitValue($this) < (shift - 1 | 0) || !equalsLong(bitwiseAnd(top, new Long(1, 0)), new Long(0, 0)))) {
      var _unary__edvuaz = top;
      top = add(_unary__edvuaz, get_ONE());
    }
    var tmp = $this.oi_1 * toNumber(top);
    // Inline function 'kotlin.math.pow' call
    return tmp * Math.pow(2.0, shift);
  }
  function Companion_1() {
    Companion_instance_2 = this;
    this.vj_1 = new Long(-1455686883, -1929601249);
    this.wj_1 = 30;
    this.xj_1 = new Long(1073741823, 0);
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$0 = new Int32Array([]);
    tmp.yj_1 = BigInteger_init_$Create$_0(0, tmp$ret$0);
    var tmp_0 = this;
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$1 = new Int32Array([1]);
    tmp_0.zj_1 = BigInteger_init_$Create$_0(1, tmp$ret$1);
    var tmp_1 = this;
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$2 = new Int32Array([2]);
    tmp_1.ak_1 = BigInteger_init_$Create$_0(1, tmp$ret$2);
    var tmp_2 = this;
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$3 = new Int32Array([10]);
    tmp_2.bk_1 = BigInteger_init_$Create$_0(1, tmp$ret$3);
    var tmp_3 = this;
    var tmp_4 = 0;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_5 = Array(33);
    while (tmp_4 < 33) {
      var tmp_6 = tmp_4;
      var value = tmp_6 - 16 | 0;
      var tmp_7;
      switch (value) {
        case 0:
          tmp_7 = Companion_getInstance_1().yj_1;
          break;
        case 1:
          tmp_7 = Companion_getInstance_1().zj_1;
          break;
        case 2:
          tmp_7 = Companion_getInstance_1().ak_1;
          break;
        case 10:
          tmp_7 = Companion_getInstance_1().bk_1;
          break;
        default:
          var tmp_8 = value < 0 ? -1 : 1;
          // Inline function 'kotlin.intArrayOf' call

          var tmp$ret$6 = new Int32Array([value < 0 ? -value | 0 : value]);
          tmp_7 = BigInteger_init_$Create$_0(tmp_8, tmp$ret$6);
          break;
      }
      tmp_5[tmp_6] = tmp_7;
      tmp_4 = tmp_4 + 1 | 0;
    }
    tmp_3.ck_1 = tmp_5;
    this.dk_1 = BigInteger_init_$Create$_2('3317044064679887385961981');
    var tmp_9 = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp_9.ek_1 = new Int32Array([2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41]);
  }
  protoOf(Companion_1).fk = function (value) {
    if (compare(new Long(-16, -1), value) <= 0 ? compare(value, new Long(16, 0)) <= 0 : false) {
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$0 = add(value, fromInt(16));
      return this.ck_1[convertToInt(tmp$ret$0)];
    }
    return BigInteger_init_$Create$(value);
  };
  protoOf(Companion_1).qs = function (bitLength, rnd) {
    return generatePrime(this, bitLength, 100, rnd);
  };
  protoOf(Companion_1).rs = function (numBits, rnd) {
    return randomBits(this, numBits, rnd);
  };
  protoOf(Companion_1).ss = function (bitLength, certainty, rnd) {
    return generatePrime(this, bitLength, certainty, rnd);
  };
  protoOf(Companion_1).ts = function (value, radix) {
    return parse_1(this, Companion_instance_6.pr(value), radix);
  };
  protoOf(Companion_1).us = function (value, radix, $super) {
    radix = radix === VOID ? 10 : radix;
    return $super === VOID ? this.ts(value, radix) : $super.ts.call(this, value, radix);
  };
  protoOf(Companion_1).vs = function (value, offset, length, radix) {
    return parse_1(this, Companion_instance_6.ws(value, offset, length), radix);
  };
  protoOf(Companion_1).xs = function (value, offset, length, radix, $super) {
    radix = radix === VOID ? 10 : radix;
    return $super === VOID ? this.vs(value, offset, length, radix) : $super.vs.call(this, value, offset, length, radix);
  };
  protoOf(Companion_1).ys = function (value, offset, length, radix) {
    return parse_1(this, Companion_instance_6.zs(value, offset, length), radix);
  };
  protoOf(Companion_1).at = function (value, offset, length, radix, $super) {
    offset = offset === VOID ? 0 : offset;
    length = length === VOID ? value.length - offset | 0 : length;
    radix = radix === VOID ? 10 : radix;
    return $super === VOID ? this.ys(value, offset, length, radix) : $super.ys.call(this, value, offset, length, radix);
  };
  protoOf(Companion_1).bt = function (value, offset, length, maxInputChars, radix) {
    return parse_1(this, Companion_instance_6.ws(value, offset, length).ct(maxInputChars), radix);
  };
  protoOf(Companion_1).dt = function (value, offset, length, maxInputChars, radix, $super) {
    radix = radix === VOID ? 10 : radix;
    return $super === VOID ? this.bt(value, offset, length, maxInputChars, radix) : $super.bt.call(this, value, offset, length, maxInputChars, radix);
  };
  protoOf(Companion_1).gm = function (value, radix, maxDigits) {
    var power = radix;
    var width = 1;
    $l$loop: while (true) {
      // Inline function 'kotlin.Long.times' call
      var this_0 = fromInt(power);
      var tmp$ret$0 = multiply(this_0, fromInt(radix));
      if (!(compare(tmp$ret$0, new Long(2147483647, 0)) <= 0)) {
        break $l$loop;
      }
      power = imul(power, radix);
      width = width + 1 | 0;
    }
    var negative = compare(value, new Long(0, 0)) > 0 ? negate(value) : value;
    var chunks = new Int32Array(3);
    var size = 0;
    do {
      var _unary__edvuaz = size;
      size = _unary__edvuaz + 1 | 0;
      var tmp0 = negative;
      // Inline function 'kotlin.Long.rem' call
      var other = power;
      var tmp$ret$1 = modulo(tmp0, fromInt(other));
      chunks[_unary__edvuaz] = -convertToInt(tmp$ret$1) | 0;
      var tmp0_0 = negative;
      // Inline function 'kotlin.Long.div' call
      var other_0 = power;
      negative = divide(tmp0_0, fromInt(other_0));
    }
     while (!equalsLong(negative, new Long(0, 0)));
    var result = new RadixDigits537(chunks, size, radix, width);
    checkTextLimit537(result.kt_1, maxDigits);
    return result;
  };
  protoOf(Companion_1).lt = function (value, first, digits, sign, scale) {
    return decimalPrefixBuilder529(this, value, first, digits).gs(sign, scale);
  };
  var Companion_instance_2;
  function Companion_getInstance_1() {
    if (Companion_instance_2 == null)
      new Companion_1();
    return Companion_instance_2;
  }
  function multiplyModuloBounded$addResidues($m, a, b) {
    var gap = $m.yk(b);
    return a.zk(gap) >= 0 ? a.yk(gap) : a.al(b);
  }
  function BigInteger$and$lambda(a, b) {
    return a & b;
  }
  function BigInteger$or$lambda(a, b) {
    return a | b;
  }
  function BigInteger$xor$lambda(a, b) {
    return a ^ b;
  }
  function BigInteger$andNot$lambda(a, b) {
    return a & ~b;
  }
  function passesPrimeTest$passesWitness(ordinary, attemptedContext, witnesses, n, d, s, nm1, a) {
    if (ordinary && getKClassFromExpression(a).equals(getKClass(BigInteger))) {
      if (!attemptedContext._v) {
        attemptedContext._v = true;
        var tmp0_safe_receiver = Companion_instance_1.kr(n);
        witnesses._v = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.ns(d, s, nm1);
      }
      var tmp1_safe_receiver = witnesses._v;
      if (tmp1_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        return tmp1_safe_receiver.hr(a);
      }
    }
    var x = a.mt(d, n);
    if (x.equals(Companion_getInstance_1().zj_1) || x.equals(nm1))
      return true;
    var inductionVariable = 1;
    if (inductionVariable < s)
      do {
        var r = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        x = multiplyMod(x, x, n);
        if (x.equals(nm1))
          return true;
      }
       while (inductionVariable < s);
    return false;
  }
  function floatingValue$magnitudeBit(this$0, compactMagnitude, words, n) {
    return this$0.ri_1 === 1 ? !equalsLong(bitwiseAnd(compactMagnitude, shiftLeft(new Long(1, 0), n)), new Long(0, 0)) : !((ensureNotNull(words)[n / 30 | 0] & 1 << (n % 30 | 0)) === 0);
  }
  function BigInteger(sign, compactHigh, compactLow, representation, wideWords) {
    Companion_getInstance_1();
    Number_0.call(this);
    this.oi_1 = sign;
    this.pi_1 = compactHigh;
    this.qi_1 = compactLow;
    this.ri_1 = representation;
    this.si_1 = wideWords;
  }
  protoOf(BigInteger).dl = function () {
    return this.ri_1 === 1;
  };
  protoOf(BigInteger).cl = function () {
    return CompactInteger529_getInstance().gl(this.pi_1, this.qi_1);
  };
  protoOf(BigInteger).ui = function () {
    return this.oi_1;
  };
  protoOf(BigInteger).xk = function () {
    return this.oi_1 < 0 ? this.jk() : this;
  };
  protoOf(BigInteger).jk = function () {
    if (this.oi_1 === 0)
      return this;
    if (this.ri_1 === 1 && !equalsLong(this.cl(), new Long(0, -2147483648)))
      return BigInteger_init_$Create$(negate(this.cl()));
    return BigInteger_init_$Create$_0(-this.oi_1 | 0, materializeMagnitude(this));
  };
  protoOf(BigInteger).al = function (value) {
    if (this.oi_1 === 0)
      return value;
    if (value.oi_1 === 0)
      return this;
    if (this.ri_1 === 1 && value.ri_1 === 1) {
      var a = this.cl();
      var b = value.cl();
      var result = add(a, b);
      if (CompactInteger529_getInstance().ll(a, b, result))
        return compactResult529(Companion_getInstance_1(), result);
      return overflowingCompactResult529(this, result, this.oi_1);
    }
    var tmp0_safe_receiver = compactCancellation529(this, value, false);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var words = materializeMagnitude(this);
    var valueWords = value === this ? words : materializeMagnitude(value);
    if (this.oi_1 === value.oi_1)
      return normalized(Companion_getInstance_1(), this.oi_1, addMagnitude(Companion_getInstance_1(), words, valueWords));
    var cmp = compareMagnitude_0(Companion_getInstance_1(), words, valueWords);
    return cmp === 0 ? Companion_getInstance_1().yj_1 : cmp > 0 ? normalized(Companion_getInstance_1(), this.oi_1, subtractMagnitude(Companion_getInstance_1(), words, valueWords)) : normalized(Companion_getInstance_1(), value.oi_1, subtractMagnitude(Companion_getInstance_1(), valueWords, words));
  };
  protoOf(BigInteger).yk = function (value) {
    if (value.oi_1 === 0)
      return this;
    if (this.oi_1 === 0)
      return value.jk();
    if (this.ri_1 === 1 && value.ri_1 === 1) {
      var a = this.cl();
      var b = value.cl();
      var result = subtract(a, b);
      if (CompactInteger529_getInstance().ml(a, b, result))
        return compactResult529(Companion_getInstance_1(), result);
      return overflowingCompactResult529(this, result, this.oi_1);
    }
    var tmp0_safe_receiver = compactCancellation529(this, value, true);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var words = materializeMagnitude(this);
    var valueWords = value === this ? words : materializeMagnitude(value);
    if (!(this.oi_1 === value.oi_1))
      return normalized(Companion_getInstance_1(), this.oi_1, addMagnitude(Companion_getInstance_1(), words, valueWords));
    var cmp = compareMagnitude_0(Companion_getInstance_1(), words, valueWords);
    return cmp === 0 ? Companion_getInstance_1().yj_1 : cmp > 0 ? normalized(Companion_getInstance_1(), this.oi_1, subtractMagnitude(Companion_getInstance_1(), words, valueWords)) : normalized(Companion_getInstance_1(), -this.oi_1 | 0, subtractMagnitude(Companion_getInstance_1(), valueWords, words));
  };
  protoOf(BigInteger).hk = function (value) {
    if (this.oi_1 === 0 || value.oi_1 === 0)
      return Companion_getInstance_1().yj_1;
    if (this.ri_1 === 1 && value.ri_1 === 1) {
      var a = this.cl();
      var b = value.cl();
      var result = multiply(a, b);
      if (CompactInteger529_getInstance().sl(a, b, result))
        return compactResult529(Companion_getInstance_1(), result);
    }
    if (this.ri_1 === 1 && value.ri_1 === 2 && magnitudeBits(this) <= 30) {
      MagnitudeMultiplication_getInstance().st(magnitudeBits(this), magnitudeBits(value));
      var scalar = this.cl();
      var word = convertToInt(compare(scalar, new Long(0, 0)) < 0 ? negate(scalar) : scalar);
      return normalized(Companion_getInstance_1(), imul(this.oi_1, value.oi_1), MagnitudeMultiplication_getInstance().tt(word, ensureNotNull(value.si_1)));
    }
    if (this.ri_1 === 2 && value.ri_1 === 1 && magnitudeBits(value) <= 30) {
      MagnitudeMultiplication_getInstance().st(magnitudeBits(this), magnitudeBits(value));
      var scalar_0 = value.cl();
      var word_0 = convertToInt(compare(scalar_0, new Long(0, 0)) < 0 ? negate(scalar_0) : scalar_0);
      return normalized(Companion_getInstance_1(), imul(this.oi_1, value.oi_1), MagnitudeMultiplication_getInstance().tt(word_0, ensureNotNull(this.si_1)));
    }
    var words = materializeMagnitude(this);
    var valueWords = value === this ? words : materializeMagnitude(value);
    MagnitudeMultiplication_getInstance().st(magnitudeBits(this), magnitudeBits(value));
    return normalized(Companion_getInstance_1(), imul(this.oi_1, value.oi_1), MagnitudeMultiplication_getInstance().ut(words, valueWords));
  };
  protoOf(BigInteger).vt = function (value) {
    return this.hk(value);
  };
  protoOf(BigInteger).nl = function (value, leftScale, rightScale, subtract, mc) {
    var tmp1_elvis_lhs = mc == null ? null : mc.ol_1;
    var precision = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    if (leftScale === rightScale && (precision === 0 || precision > 646456993))
      return null;
    var rightSign = subtract ? -value.oi_1 | 0 : value.oi_1;
    if (materializedDecimalSum585(this.oi_1, rightSign, magnitudeBits(this), magnitudeBits(value), leftScale, rightScale))
      return null;
    var leftDigits = this.oi_1 === 0 ? 0 : this.vi();
    var rightDigits = value.oi_1 === 0 ? 0 : value.vi();
    if (!certifiedDecimalSumSpan585(leftDigits, rightDigits, leftScale, rightScale, precision))
      return null;
    var words = materializeMagnitude(this);
    return DecimalSum585_getInstance().au(this.oi_1, words, leftScale, rightSign, materializeMagnitude(value), rightScale, mc);
  };
  protoOf(BigInteger).fo = function (value, scale, mc) {
    if (this.oi_1 === 0 || value.oi_1 === 0 || !needsRawDecimalProduct580(magnitudeBits(this), magnitudeBits(value)))
      return null;
    var words = materializeMagnitude(this);
    return DecimalProduct580_getInstance().eu(imul(this.oi_1, value.oi_1), words, materializeMagnitude(value), scale, mc);
  };
  protoOf(BigInteger).oo = function (value, preferred, target, shift, sourceDigits, divisorDigits, normalized, mc) {
    if (this.oi_1 === 0 || value.oi_1 === 0)
      return null;
    if (materializedDecimalDivision581(magnitudeBits(this), magnitudeBits(value), mc.ol_1, preferred, target, shift))
      return null;
    if (!(sourceDigits === this.vi()) || !(divisorDigits === value.vi()) || !(normalized === this.wi(value)))
      return null;
    var words = materializeMagnitude(this);
    if (mc.ol_1 > 646456993)
      return DecimalDivision581_getInstance().ju(imul(this.oi_1, value.oi_1), BigInteger_init_$Create$_0(1, words), BigInteger_init_$Create$_0(1, materializeMagnitude(value)), preferred, mc.ol_1);
    return DecimalDivision581_getInstance().eu(imul(this.oi_1, value.oi_1), words, materializeMagnitude(value), preferred, mc);
  };
  protoOf(BigInteger).qo = function (value, sourceScale, divisorScale, sourceDigits, divisorDigits, reportedSourceScale, reportedDivisorScale, sourceSign, magnitude) {
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(sourceScale);
    var preferred = subtract(this_0, fromInt(divisorScale));
    if (!(compare(new Long(-2147483648, -1), preferred) <= 0 ? compare(preferred, new Long(2147483647, 0)) <= 0 : false) || this.oi_1 === 0 || value.oi_1 === 0 || !(sourceSign === this.oi_1) || !(reportedSourceScale === sourceScale) || !(reportedDivisorScale === divisorScale) || !(sourceDigits === this.vi()) || !(divisorDigits === value.vi()))
      return null;
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(sourceDigits);
    var tmp = subtract(this_1, fromInt(sourceScale));
    // Inline function 'kotlin.Long.minus' call
    var this_2 = fromInt(divisorDigits);
    var tmp$ret$2 = subtract(this_2, fromInt(divisorScale));
    var exponents = tmp.t2(tmp$ret$2);
    var storedMagnitude = !(exponents === 0) ? exponents : this.wi(value);
    if (!(compareTo(magnitude, 0) === compareTo(storedMagnitude, 0)) || storedMagnitude < 0)
      return null;
    var words = materializeMagnitude(this);
    if (compare(preferred, new Long(0, 0)) < 0) {
      var zeros = negate(preferred);
      var tmp_0;
      if (compare(zeros, fromInt(divisorDigits)) >= 0) {
        var tmp_1 = add(fromInt(sourceDigits), zeros);
        var tmp_2 = new Long(646456993, 0);
        // Inline function 'kotlin.Long.times' call
        var this_3 = new Long(2, 0);
        var tmp$ret$3 = multiply(this_3, fromInt(divisorDigits));
        // Inline function 'kotlin.Long.minus' call
        var this_4 = add(tmp_2, tmp$ret$3);
        var tmp$ret$4 = subtract(this_4, fromInt(1));
        tmp_0 = compare(tmp_1, tmp$ret$4) > 0;
      } else {
        tmp_0 = false;
      }
      if (tmp_0)
        return DecimalDivision581_getInstance().ju(imul(this.oi_1, value.oi_1), BigInteger_init_$Create$_0(1, words), BigInteger_init_$Create$_0(1, materializeMagnitude(value)), preferred, 2147483647);
      return DecimalDivision581_getInstance().ku(imul(this.oi_1, value.oi_1), words, materializeMagnitude(value), convertToInt(preferred));
    }
    var power = Companion_getInstance_1().bk_1.gk(convertToInt(preferred));
    var absoluteDivisor = BigInteger_init_$Create$_0(1, materializeMagnitude(value));
    var denominator = equalsLong(preferred, new Long(0, 0)) ? absoluteDivisor : absoluteDivisor.hk(power);
    var quotient = quotientStored(BigInteger_init_$Create$_0(1, words), denominator);
    var coefficient = equalsLong(preferred, new Long(0, 0)) ? quotient : quotient.hk(power);
    return to(this.oi_1 === value.oi_1 || coefficient.oi_1 === 0 ? coefficient : BigInteger_init_$Create$_0(-1, materializeMagnitude(coefficient)), convertToInt(preferred));
  };
  protoOf(BigInteger).uo = function (value, sourceScale, divisorScale, quotient, quotientScale) {
    if (value.oi_1 === 0 || materializedDecimalResidual583(magnitudeBits(this), magnitudeBits(value), magnitudeBits(quotient), sourceScale, divisorScale, quotientScale))
      return null;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(sourceScale);
    var preferred = subtract(this_0, fromInt(divisorScale));
    if (compare(preferred, new Long(-2147483648, -1)) < 0)
      return this.lu(value, sourceScale, divisorScale, quotient, quotientScale);
    var tmp;
    if (!(compare(new Long(-2147483648, -1), preferred) <= 0 ? compare(preferred, new Long(2147483647, 0)) <= 0 : false)) {
      tmp = true;
    } else {
      var tmp_0 = fromInt(quotientScale);
      // Inline function 'kotlin.comparisons.maxOf' call
      var b = new Long(0, 0);
      var tmp$ret$1 = compare(preferred, b) >= 0 ? preferred : b;
      tmp = compare(tmp_0, tmp$ret$1) > 0;
    }
    if (tmp)
      return null;
    if (this.oi_1 === 0)
      return quotient.oi_1 === 0 && equalsLong(fromInt(quotientScale), preferred) ? to(Companion_getInstance_1().yj_1, sourceScale) : null;
    var sourceDigits = this.vi();
    var divisorDigits = value.vi();
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(sourceDigits);
    var tmp_1 = subtract(this_1, fromInt(sourceScale));
    // Inline function 'kotlin.Long.minus' call
    var this_2 = fromInt(divisorDigits);
    var tmp$ret$3 = subtract(this_2, fromInt(divisorScale));
    var exponents = tmp_1.t2(tmp$ret$3);
    var magnitude = !(exponents === 0) ? exponents : this.wi(value);
    var words = materializeMagnitude(this);
    if (quotient.oi_1 === 0)
      return equalsLong(fromInt(quotientScale), preferred) && magnitude < 0 ? to(BigInteger_init_$Create$_0(this.oi_1, words), sourceScale) : null;
    if (!(quotient.oi_1 === imul(this.oi_1, value.oi_1)) || magnitude < 0)
      return null;
    if (compare(preferred, new Long(0, 0)) < 0)
      return DecimalDivision581_getInstance().mu(this.oi_1, words, materializeMagnitude(value), materializeMagnitude(quotient), convertToInt(preferred), divisorScale, quotientScale);
    var absoluteDivisor = BigInteger_init_$Create$_0(1, materializeMagnitude(value));
    var denominator = equalsLong(preferred, new Long(0, 0)) ? absoluteDivisor : absoluteDivisor.hk(Companion_getInstance_1().bk_1.gk(convertToInt(preferred)));
    var qr = divideStored(BigInteger_init_$Create$_0(1, words), denominator);
    if (!DecimalDivision581_getInstance().nu(materializeMagnitude(quotient), quotientScale, materializeMagnitude(qr[0])))
      return null;
    var residual = qr[1];
    return to(this.oi_1 < 0 && !(residual.oi_1 === 0) ? BigInteger_init_$Create$_0(-1, materializeMagnitude(residual)) : residual, sourceScale);
  };
  protoOf(BigInteger).mo = function (value, shift, mode) {
    if (this.oi_1 === 0 || value.oi_1 === 0)
      return null;
    var tmp;
    var tmp_0;
    if (compare(new Long(-646456992, -1), shift) <= 0 ? compare(shift, new Long(646456992, 0)) <= 0 : false) {
      var tmp_1 = fromInt(magnitudeBits(this));
      var tmp_2 = new Long(4, 0);
      // Inline function 'kotlin.comparisons.maxOf' call
      var b = new Long(0, 0);
      var tmp$ret$0 = compare(shift, b) >= 0 ? shift : b;
      tmp_0 = compare(add(tmp_1, multiply(tmp_2, tmp$ret$0)), new Long(2147483647, 0)) <= 0;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      var tmp_3 = fromInt(magnitudeBits(value));
      var tmp_4 = new Long(4, 0);
      var tmp0 = negate(shift);
      // Inline function 'kotlin.comparisons.maxOf' call
      var b_0 = new Long(0, 0);
      var tmp$ret$1 = compare(tmp0, b_0) >= 0 ? tmp0 : b_0;
      tmp = compare(add(tmp_3, multiply(tmp_4, tmp$ret$1)), new Long(2147483647, 0)) <= 0;
    } else {
      tmp = false;
    }
    if (tmp)
      return null;
    var words = materializeMagnitude(this);
    return DecimalDivision581_getInstance().ou(imul(this.oi_1, value.oi_1), words, materializeMagnitude(value), shift, mode);
  };
  protoOf(BigInteger).lu = function (value, sourceScale, divisorScale, quotient, quotientScale) {
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(sourceScale);
    var preferred = subtract(this_0, fromInt(divisorScale));
    if (compare(preferred, new Long(-2147483648, -1)) >= 0 || this.oi_1 === 0 || value.oi_1 === 0 || quotient.oi_1 === 0 || !(quotient.oi_1 === imul(this.oi_1, value.oi_1)))
      return null;
    var tmp0 = fromInt(sourceScale);
    // Inline function 'kotlin.Long.plus' call
    var this_1 = fromInt(quotientScale);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = add(this_1, fromInt(divisorScale));
    var residualScale = compare(tmp0, b) >= 0 ? tmp0 : b;
    if (!(compare(new Long(-2147483648, -1), residualScale) <= 0 ? compare(residualScale, new Long(2147483647, 0)) <= 0 : false))
      return null;
    var words = materializeMagnitude(this);
    var tmp;
    try {
      tmp = DecimalDivision581_getInstance().ju(imul(this.oi_1, value.oi_1), BigInteger_init_$Create$_0(1, words), BigInteger_init_$Create$_0(1, materializeMagnitude(value)), preferred, 2147483647);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var _unused_var__etf5q3 = $p;
        return null;
      } else {
        throw $p;
      }
    }
    var exact = tmp;
    var tmp_1;
    var tmp0_0 = fromInt(exact.dd_1.vi());
    // Inline function 'kotlin.Long.minus' call
    var other = exact.ed_1;
    var tmp_2 = subtract(tmp0_0, fromInt(other));
    // Inline function 'kotlin.Long.minus' call
    var this_2 = fromInt(quotient.vi());
    var tmp$ret$4 = subtract(this_2, fromInt(quotientScale));
    if (!equalsLong(tmp_2, tmp$ret$4)) {
      tmp_1 = true;
    } else {
      tmp_1 = !(exact.dd_1.wi(quotient) === 0);
    }
    if (tmp_1)
      return null;
    return to(Companion_getInstance_1().yj_1, convertToInt(residualScale));
  };
  protoOf(BigInteger).fp = function (scale) {
    return this.oi_1 === 0 ? null : DecimalPower593_getInstance().pu(this.oi_1, materializeMagnitude(this), scale);
  };
  protoOf(BigInteger).ul = function (value) {
    return quotientStored(this, value);
  };
  protoOf(BigInteger).xl = function (value) {
    return remainderStored(this, value);
  };
  protoOf(BigInteger).wk = function (value) {
    return divideStored(this, value);
  };
  protoOf(BigInteger).gk = function (exponent) {
    if (exponent < 0)
      throw ArithmeticException_init_$Create$('Negative exponent');
    if (exponent === 0)
      return Companion_getInstance_1().zj_1;
    if (this.equals(Companion_getInstance_1().zj_1))
      return Companion_getInstance_1().zj_1;
    if (this.oi_1 === 0 || exponent === 1)
      return this;
    var absolute = this.xk();
    var twos = absolute.vl();
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(twos);
    var shift = multiply(this_0, fromInt(exponent));
    if (compare(shift, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    var part = absolute.wl(twos);
    var bits = part.en();
    var negative = this.oi_1 < 0 && !((exponent & 1) === 0);
    if (bits === 1)
      return shiftPower(this, negative ? Companion_getInstance_1().fk(new Long(-1, -1)) : Companion_getInstance_1().zj_1, convertToInt(shift));
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(bits);
    // Inline function 'kotlin.Long.times' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = multiply(this_2, fromInt(exponent));
    if (compare(tmp$ret$2, new Long(2147483647, 0)) >= 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    // Inline function 'kotlin.Long.times' call
    var this_3 = fromInt(bits);
    var estimate = multiply(this_3, fromInt(exponent));
    if (compare(estimate, new Long(64, 0)) <= 0) {
      if (part.oi_1 === 0) {
        emptyPowMagnitude();
      }
      // Inline function 'kotlin.Long.plus' call
      var this_4 = fromInt(magnitudeBits(part));
      // Inline function 'kotlin.Long.div' call
      var this_5 = add(this_4, fromInt(31));
      var tmp$ret$5 = divide(this_5, fromInt(32));
      var count = convertToInt(tmp$ret$5);
      var factor = magnitudeWord32(part, count - 1 | 0);
      var e = equalsLong(factor, new Long(2, 0)) ? 0 : exponent;
      var product = equalsLong(factor, new Long(2, 0)) ? shiftLeft(new Long(1, 0), exponent) : new Long(1, 0);
      while (!(e === 0)) {
        if (!((e & 1) === 0))
          product = multiply(product, factor);
        e = e >>> 1 | 0;
        if (!(e === 0))
          factor = multiply(factor, factor);
      }
      var compactShift = compare(add(estimate, shift), new Long(64, 0)) <= 0;
      if (compactShift)
        product = shiftLeft(product, convertToInt(shift));
      // Inline function 'kotlin.toULong' call
      var this_6 = product;
      var magnitude = _ULong___init__impl__c78o9k(this_6);
      var packed = new Int32Array(3);
      var size = 0;
      while (!equals(new ULong(magnitude), new ULong(_ULong___init__impl__c78o9k(new Long(0, 0))))) {
        var _unary__edvuaz = size;
        size = _unary__edvuaz + 1 | 0;
        var tmp0 = magnitude;
        // Inline function 'kotlin.toULong' call
        var this_7 = new Long(1073741823, 0);
        // Inline function 'kotlin.ULong.and' call
        var other = _ULong___init__impl__c78o9k(this_7);
        // Inline function 'kotlin.ULong.toInt' call
        var this_8 = _ULong___init__impl__c78o9k(bitwiseAnd(_ULong___get_data__impl__fggpzb(tmp0), _ULong___get_data__impl__fggpzb(other)));
        packed[_unary__edvuaz] = convertToInt(_ULong___get_data__impl__fggpzb(this_8));
        // Inline function 'kotlin.ULong.shr' call
        var this_9 = magnitude;
        magnitude = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_9), 30));
      }
      var tmp;
      if (size === 0) {
        // Inline function 'kotlin.intArrayOf' call
        var tmp$ret$11 = new Int32Array([]);
        tmp = BigInteger_init_$Create$_0(0, tmp$ret$11);
      } else {
        tmp = normalized(Companion_getInstance_1(), negative ? -1 : 1, packed);
      }
      var value = tmp;
      return compactShift ? value : shiftPower(this, value, convertToInt(shift));
    }
    var e_0 = exponent;
    var base = normalized(Companion_getInstance_1(), part.oi_1, materializeMagnitude(part));
    var result = Companion_getInstance_1().zj_1;
    while (!(e_0 === 0)) {
      if (!((e_0 & 1) === 0))
        result = result.hk(base);
      e_0 = e_0 >>> 1 | 0;
      if (!(e_0 === 0))
        base = base.hk(base);
    }
    return shiftPower(this, negative ? result.jk() : result, convertToInt(shift));
  };
  protoOf(BigInteger).tl = function (value) {
    var words = materializeMagnitude(this);
    if (value.oi_1 === 0)
      return this.xk();
    if (this.oi_1 === 0)
      return value.xk();
    var a = BigInteger_init_$Create$_0(1, words);
    var b = BigInteger_init_$Create$_0(1, materializeMagnitude(value));
    while (!(b.oi_1 === 0)) {
      var r = remainderStored(a, b);
      a = b;
      b = r;
    }
    return normalized(Companion_getInstance_1(), 1, materializeMagnitude(a));
  };
  protoOf(BigInteger).ir = function (m) {
    if (m.oi_1 <= 0)
      throw ArithmeticException_init_$Create$('BigInteger: modulus not positive');
    var r = this.xl(m);
    return r.oi_1 < 0 ? r.al(m) : r;
  };
  protoOf(BigInteger).mt = function (exponent, m) {
    if (m.oi_1 <= 0)
      throw ArithmeticException_init_$Create$('BigInteger: modulus not positive');
    var power = exponent;
    if (power.oi_1 === 0)
      return m.equals(Companion_getInstance_1().zj_1) ? Companion_getInstance_1().yj_1 : Companion_getInstance_1().zj_1;
    if (this.equals(Companion_getInstance_1().zj_1))
      return m.equals(Companion_getInstance_1().zj_1) ? Companion_getInstance_1().yj_1 : Companion_getInstance_1().zj_1;
    if (this.equals(Companion_getInstance_1().yj_1) && power.oi_1 >= 0)
      return Companion_getInstance_1().yj_1;
    if (this.equals(Companion_getInstance_1().fk(new Long(-1, -1))) && !power.bl(0))
      return m.equals(Companion_getInstance_1().zj_1) ? Companion_getInstance_1().yj_1 : Companion_getInstance_1().zj_1;
    var inverse = power.oi_1 < 0;
    var e = inverse ? power.jk() : power;
    var base = this.oi_1 < 0 || this.zk(m) >= 0 ? this.ir(m) : this;
    var tmp;
    if (m.bl(0)) {
      tmp = oddModPowStored(base, e, m);
    } else {
      var p = m.vl();
      var oddModulus = m.wl(p);
      var oddBase = this.oi_1 < 0 || this.zk(oddModulus) >= 0 ? this.ir(oddModulus) : this;
      var oddResidue = oddModulus.equals(Companion_getInstance_1().zj_1) ? Companion_getInstance_1().yj_1 : oddModPowStored(oddBase, e, oddModulus);
      var binaryResidue = modPowPowerOfTwo(base, e, p);
      var binaryModulus = shiftLeftValue(Companion_getInstance_1().zj_1, p);
      var binaryInverse = binaryModulus.qu(oddModulus);
      var oddInverse = oddModulus.qu(binaryModulus);
      var tmp_0;
      // Inline function 'kotlin.Long.times' call
      var this_0 = fromInt(magnitudeBits(m));
      // Inline function 'kotlin.Long.plus' call
      var this_1 = multiply(this_0, fromInt(2));
      var tmp$ret$1 = add(this_1, fromInt(2));
      if (compare(tmp$ret$1, new Long(2147483647, 0)) <= 0) {
        tmp_0 = oddResidue.hk(binaryModulus).hk(binaryInverse).al(binaryResidue.hk(oddModulus).hk(oddInverse)).ir(m);
      } else {
        var modulus = BigInteger_init_$Create$_0(1, materializeMagnitude(m));
        var left = multiplyMod(oddResidue.hk(binaryModulus), binaryInverse, modulus);
        var right = multiplyMod(binaryResidue.hk(oddModulus), oddInverse, modulus);
        var gap = modulus.yk(right);
        tmp_0 = left.zk(gap) >= 0 ? left.yk(gap) : left.al(right);
      }
      tmp = tmp_0;
    }
    var result = tmp;
    return inverse ? result.qu(m) : result;
  };
  protoOf(BigInteger).qu = function (m) {
    var words = materializeMagnitude(this);
    if (m.oi_1 <= 0)
      throw ArithmeticException_init_$Create$('BigInteger: modulus not positive');
    if (m.equals(Companion_getInstance_1().zj_1))
      return Companion_getInstance_1().yj_1;
    var mWords = materializeMagnitude(m);
    var reduced = this.oi_1 < 0 || compareMagnitude_0(Companion_getInstance_1(), words, mWords) >= 0 ? this.ir(m) : this;
    if (reduced.equals(Companion_getInstance_1().zj_1))
      return Companion_getInstance_1().zj_1;
    if (reduced.oi_1 === 0)
      throw ArithmeticException_init_$Create$('BigInteger not invertible.');
    var modulus = BigInteger_init_$Create$_0(1, mWords);
    var r = modulus;
    var nextR = BigInteger_init_$Create$_0(1, materializeMagnitude(reduced));
    var t = Companion_getInstance_1().yj_1;
    var nextT = Companion_getInstance_1().zj_1;
    while (!(nextR.oi_1 === 0)) {
      var qr = divideStored(r, nextR);
      var temp = t.yk(qr[0].hk(nextT));
      t = nextT;
      nextT = temp;
      r = nextR;
      nextR = qr[1];
    }
    if (!r.equals(Companion_getInstance_1().zj_1))
      throw ArithmeticException_init_$Create$('BigInteger not invertible.');
    return t.ir(modulus);
  };
  protoOf(BigInteger).os = function (value, m) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(this.oi_1 >= 0 && value.oi_1 >= 0 && m.oi_1 > 0 && this.zk(m) < 0 && value.zk(m) < 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var result = Companion_getInstance_1().yj_1;
    var addend = this;
    var bits = magnitudeBits(value);
    var inductionVariable = 0;
    if (inductionVariable < bits)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (value.bl(i))
          result = multiplyModuloBounded$addResidues(m, result, addend);
        if ((i + 1 | 0) < bits)
          addend = multiplyModuloBounded$addResidues(m, addend, addend);
      }
       while (inductionVariable < bits);
    return result;
  };
  protoOf(BigInteger).xp = function () {
    return sqrtStored(this);
  };
  protoOf(BigInteger).am = function () {
    var words = materializeMagnitude(this);
    var root = sqrtStored(this);
    var square = root.hk(root);
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [root, normalized(Companion_getInstance_1(), 1, subtractMagnitude(Companion_getInstance_1(), words, materializeMagnitude(square)))];
  };
  protoOf(BigInteger).ik = function (n) {
    return shiftLeftValue(this, n);
  };
  protoOf(BigInteger).wl = function (n) {
    return shiftRightValue(this, n);
  };
  protoOf(BigInteger).en = function () {
    if (this.ri_1 === 1) {
      var value = this.cl();
      return 64 - countLeadingZeroBits(compare(value, new Long(0, 0)) < 0 ? invert(value) : value) | 0;
    }
    var words = materializeMagnitude(this);
    var bits = magnitudeBits(this);
    if (this.oi_1 >= 0 || !(countOneBits(last(words)) === 1))
      return bits;
    var inductionVariable = 0;
    var last_0 = get_lastIndex(words);
    if (inductionVariable < last_0)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(words[i] === 0))
          return bits;
      }
       while (inductionVariable < last_0);
    return bits - 1 | 0;
  };
  protoOf(BigInteger).ru = function () {
    if (this.ri_1 === 1) {
      var value = this.cl();
      if (compare(value, new Long(0, 0)) >= 0)
        return countOneBits_0(value);
      return (countOneBits_0(negate(value)) + this.vl() | 0) - 1 | 0;
    }
    var words = materializeMagnitude(this);
    if (this.oi_1 >= 0) {
      // Inline function 'kotlin.collections.sumOf' call
      var sum = 0;
      var inductionVariable = 0;
      var last = words.length;
      while (inductionVariable < last) {
        var element = words[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = sum;
        sum = tmp + countOneBits(element) | 0;
      }
      return sum;
    }
    // Inline function 'kotlin.collections.sumOf' call
    var sum_0 = 0;
    var inductionVariable_0 = 0;
    var last_0 = words.length;
    while (inductionVariable_0 < last_0) {
      var element_0 = words[inductionVariable_0];
      inductionVariable_0 = inductionVariable_0 + 1 | 0;
      var tmp_0 = sum_0;
      sum_0 = tmp_0 + countOneBits(element_0) | 0;
    }
    return (sum_0 + this.vl() | 0) - 1 | 0;
  };
  protoOf(BigInteger).vl = function () {
    return lowestSetBitValue(this);
  };
  protoOf(BigInteger).bl = function (n) {
    return testBitValue(this, n);
  };
  protoOf(BigInteger).or = function (n) {
    return changeBit(this, n, 1);
  };
  protoOf(BigInteger).su = function (n) {
    return changeBit(this, n, 0);
  };
  protoOf(BigInteger).tu = function (n) {
    return changeBit(this, n, 2);
  };
  protoOf(BigInteger).uu = function () {
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(bitwiseLength32(this));
    var width = multiply(this_0, fromInt(32));
    if (getKClassFromExpression(this).equals(getKClass(BigInteger)) && this.ri_1 === 1)
      return BigInteger_init_$Create$(invert(this.cl()));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(width, fromInt(30));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$3 = divide(this_2, fromInt(30));
    var result = twosComplement(this, convertToInt(tmp$ret$3));
    var inductionVariable = 0;
    var last = result.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        result[i] = ~result[i] & 1073741823;
      }
       while (inductionVariable <= last);
    return bitwiseResult(this, result, width);
  };
  protoOf(BigInteger).vu = function (value) {
    return bitwise(this, value, BigInteger$and$lambda);
  };
  protoOf(BigInteger).wu = function (value) {
    return bitwise(this, value, BigInteger$or$lambda);
  };
  protoOf(BigInteger).xu = function (value) {
    return bitwise(this, value, BigInteger$xor$lambda);
  };
  protoOf(BigInteger).yu = function (value) {
    return bitwise(this, value, BigInteger$andNot$lambda);
  };
  protoOf(BigInteger).zu = function (certainty) {
    if (certainty <= 0)
      return true;
    return passesPrimeTest(this, fromInt(PrimalityCertainty_instance.av(certainty)));
  };
  protoOf(BigInteger).bv = function () {
    var words = materializeMagnitude(this);
    if (this.oi_1 < 0)
      throw ArithmeticException_init_$Create$('start < 0: ' + this.toString());
    if (this.oi_1 === 0 || (words.length === 1 && words[0] === 1))
      return Companion_getInstance_1().ak_1;
    PrimeSearchLimits_instance.mr(magnitudeBits(this));
    var n = this.al(Companion_getInstance_1().zj_1).or(0);
    var candidateIndex = Companion_getInstance_1().zj_1;
    while (true) {
      PrimeSearchLimits_instance.mr(magnitudeBits(n));
      if (passesPrimeTest(n, PrimalityCertainty_instance.cv(candidateIndex.en())))
        return n;
      n = n.al(Companion_getInstance_1().ak_1);
      candidateIndex = candidateIndex.al(Companion_getInstance_1().zj_1);
    }
  };
  protoOf(BigInteger).zk = function (other) {
    if (this.ri_1 === 1 && other.ri_1 === 1) {
      var order = this.cl().t2(other.cl());
      return order < 0 ? -1 : order > 0 ? 1 : 0;
    }
    var words = materializeMagnitude(this);
    var operand = other;
    if (!(this.oi_1 === operand.oi_1))
      return this.oi_1 < operand.oi_1 ? -1 : 1;
    var magnitude = compareMagnitude_0(Companion_getInstance_1(), words, materializeMagnitude(operand));
    return magnitude < 0 ? -this.oi_1 | 0 : magnitude > 0 ? this.oi_1 : 0;
  };
  protoOf(BigInteger).d = function (other) {
    return this.zk(other instanceof BigInteger ? other : THROW_CCE());
  };
  protoOf(BigInteger).dv = function (value) {
    return this.zk(value) < 0 ? this : value;
  };
  protoOf(BigInteger).ev = function (value) {
    return this.zk(value) > 0 ? this : value;
  };
  protoOf(BigInteger).equals = function (other) {
    var tmp;
    var tmp_0;
    if (other instanceof BigInteger) {
      tmp_0 = this.oi_1 === other.oi_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.ri_1 === 1 ? other.ri_1 === 1 && this.pi_1 === other.pi_1 && this.qi_1 === other.qi_1 : other.ri_1 === 2 && contentEquals(ensureNotNull(this.si_1), ensureNotNull(other.si_1));
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(BigInteger).hashCode = function () {
    var hash = 0;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(magnitudeBits(this));
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(31));
    var tmp$ret$1 = divide(this_1, fromInt(32));
    var count = convertToInt(tmp$ret$1);
    var inductionVariable = count - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var chunk = magnitudeWord32(this, i);
        var tmp0 = new Long(31, 0);
        // Inline function 'kotlin.Long.times' call
        var other = hash;
        var tmp$ret$2 = multiply(tmp0, fromInt(other));
        hash = convertToInt(add(tmp$ret$2, chunk));
      }
       while (0 <= inductionVariable);
    return imul(hash, this.oi_1);
  };
  protoOf(BigInteger).toString = function () {
    return this.fv(10);
  };
  protoOf(BigInteger).fv = function (radix) {
    if (this.oi_1 === 0)
      return '0';
    var r = (2 <= radix ? radix <= 36 : false) ? radix : 10;
    var magnitude = this.xk();
    if ((2 <= radix ? radix <= 36 : false) && getKClassFromExpression(this).equals(getKClass(BigInteger)) && getKClassFromExpression(magnitude).equals(getKClass(BigInteger)) && magnitude.oi_1 > 0) {
      switch (r) {
        case 2:
        case 4:
        case 8:
        case 16:
        case 32:
          return toPowerOfTwoString(magnitude, r, this.oi_1 < 0);
      }
    }
    if (getKClassFromExpression(this).equals(getKClass(BigInteger)) && getKClassFromExpression(magnitude).equals(getKClass(BigInteger)) && magnitude.oi_1 > 0) {
      var digits = this.gv(r);
      var tmp0 = digits.kt_1;
      // Inline function 'kotlin.Long.plus' call
      var other = this.oi_1 < 0 ? 1 : 0;
      var length = add(tmp0, fromInt(other));
      if (compare(length, new Long(2147483647, 0)) > 0) {
        plainStringTooLarge();
      }
      // Inline function 'kotlin.text.buildString' call
      var capacity = convertToInt(length);
      // Inline function 'kotlin.apply' call
      var this_0 = StringBuilder_init_$Create$(capacity);
      var sink = new AppendableSink537(this_0);
      if (this.oi_1 < 0) {
        sink.iv(_Char___init__impl__6a9atx(45));
      }
      digits.jv(sink);
      return this_0.toString();
    }
    var divisor = Companion_getInstance_1().fk(fromInt(r));
    var text = StringBuilder_init_$Create$_0();
    var value = magnitude;
    while (!(value.oi_1 === 0)) {
      var qr = value.wk(divisor);
      text.n(charCodeAt('0123456789abcdefghijklmnopqrstuvwxyz', qr[1].kq()));
      value = qr[0];
    }
    if (this.oi_1 < 0) {
      text.n(_Char___init__impl__6a9atx(45));
    }
    return text.n1().toString();
  };
  protoOf(BigInteger).kv = function (destination, radix, maxChars) {
    checkTextLimit537(new Long(0, 0), maxChars);
    if (!getKClassFromExpression(this).equals(getKClass(BigInteger))) {
      var text = this.fv(radix);
      checkTextLimit537(fromInt(text.length), maxChars);
      destination.s(text);
      return fromInt(text.length);
    }
    var prefix = this.oi_1 < 0 ? new Long(1, 0) : new Long(0, 0);
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$0 = add(prefix, fromInt(1));
    checkTextLimit537(tmp$ret$0, maxChars);
    var tmp = (2 <= radix ? radix <= 36 : false) ? radix : 10;
    var digits = this.fm(tmp, maxChars == null ? null : subtract(maxChars, prefix));
    var length = add(prefix, digits.kt_1);
    checkTextLimit537(length, maxChars);
    var sink = new AppendableSink537(destination);
    if (this.oi_1 < 0) {
      sink.iv(_Char___init__impl__6a9atx(45));
    }
    digits.jv(sink);
    return length;
  };
  protoOf(BigInteger).lv = function (destination, radix, maxChars, $super) {
    radix = radix === VOID ? 10 : radix;
    maxChars = maxChars === VOID ? null : maxChars;
    return $super === VOID ? this.kv(destination, radix, maxChars) : $super.kv.call(this, destination, radix, maxChars);
  };
  protoOf(BigInteger).mv = function (destination, offset, length, radix) {
    checkTextBuffer537(destination, offset, length);
    if (!getKClassFromExpression(this).equals(getKClass(BigInteger))) {
      var text = this.fv(radix);
      checkTextLimit537(fromInt(text.length), fromInt(length));
      (new ArraySink537(destination, offset)).hq(text, 0, text.length);
      return text.length;
    }
    var prefix = this.oi_1 < 0 ? new Long(1, 0) : new Long(0, 0);
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$0 = add(prefix, fromInt(1));
    checkTextLimit537(tmp$ret$0, fromInt(length));
    var digits = this.fm((2 <= radix ? radix <= 36 : false) ? radix : 10, subtract(numberToLong(length), prefix));
    var required = add(prefix, digits.kt_1);
    checkTextLimit537(required, fromInt(length));
    var sink = new ArraySink537(destination, offset);
    if (this.oi_1 < 0) {
      sink.iv(_Char___init__impl__6a9atx(45));
    }
    digits.jv(sink);
    return convertToInt(required);
  };
  protoOf(BigInteger).nv = function (destination, offset, length, radix, $super) {
    offset = offset === VOID ? 0 : offset;
    length = length === VOID ? destination.length - offset | 0 : length;
    radix = radix === VOID ? 10 : radix;
    return $super === VOID ? this.mv(destination, offset, length, radix) : $super.mv.call(this, destination, offset, length, radix);
  };
  protoOf(BigInteger).fm = function (radix, maxDigits) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(2 <= radix ? radix <= 36 : false)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (this.ri_1 === 1)
      return Companion_getInstance_1().gm(this.cl(), radix, maxDigits);
    var words = ensureNotNull(this.si_1);
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_0 = radix - 1 | 0;
    var upperBits = 32 - clz32(this_0) | 0;
    var tmp;
    if (this.oi_1 === 0) {
      tmp = new Long(1, 0);
    } else {
      // Inline function 'kotlin.Long.div' call
      var this_1 = fromInt(magnitudeBits(this) - 1 | 0);
      // Inline function 'kotlin.Long.plus' call
      var this_2 = divide(this_1, fromInt(upperBits));
      tmp = add(this_2, fromInt(1));
    }
    var lowerDigits = tmp;
    checkTextLimit537(lowerDigits, maxDigits);
    if (this.oi_1 === 0) {
      // Inline function 'kotlin.intArrayOf' call
      var tmp$ret$6 = new Int32Array([0]);
      return new RadixDigits537(tmp$ret$6, 1, radix, 1);
    }
    var power = radix;
    var width = 1;
    $l$loop: while (true) {
      // Inline function 'kotlin.Long.times' call
      var this_3 = fromInt(power);
      var tmp$ret$7 = multiply(this_3, fromInt(radix));
      if (!(compare(tmp$ret$7, new Long(2147483647, 0)) <= 0)) {
        break $l$loop;
      }
      power = imul(power, radix);
      width = width + 1 | 0;
    }
    if ((radix & (radix - 1 | 0)) === 0) {
      var bitsPerDigit = countTrailingZeroBits_0(radix);
      var bitsPerChunk = imul(bitsPerDigit, width);
      var bitLength = fromInt(magnitudeBits(this));
      // Inline function 'kotlin.Long.plus' call
      // Inline function 'kotlin.Long.minus' call
      var this_4 = add(bitLength, fromInt(bitsPerDigit));
      // Inline function 'kotlin.Long.div' call
      var this_5 = subtract(this_4, fromInt(1));
      var digits = divide(this_5, fromInt(bitsPerDigit));
      checkTextLimit537(digits, maxDigits);
      // Inline function 'kotlin.Long.plus' call
      // Inline function 'kotlin.Long.minus' call
      var this_6 = add(bitLength, fromInt(bitsPerChunk));
      // Inline function 'kotlin.Long.div' call
      var this_7 = subtract(this_6, fromInt(1));
      var tmp$ret$13 = divide(this_7, fromInt(bitsPerChunk));
      var count = convertToInt(tmp$ret$13);
      var chunks = new Int32Array(count);
      var inductionVariable = 0;
      var last = chunks.length - 1 | 0;
      if (inductionVariable <= last)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          // Inline function 'kotlin.Long.times' call
          var this_8 = fromInt(index);
          var bit = multiply(this_8, fromInt(bitsPerChunk));
          // Inline function 'kotlin.Long.div' call
          var tmp$ret$15 = divide(bit, fromInt(30));
          var word = convertToInt(tmp$ret$15);
          // Inline function 'kotlin.Long.rem' call
          var tmp$ret$16 = modulo(bit, fromInt(30));
          var offset = convertToInt(tmp$ret$16);
          var chunk = shiftRightUnsigned(fromInt(words[word]), offset);
          if ((offset + bitsPerChunk | 0) > 30 && (word + 1 | 0) < words.length)
            chunk = bitwiseOr(chunk, shiftLeft(fromInt(words[word + 1 | 0]), 30 - offset | 0));
          chunks[index] = convertToInt(bitwiseAnd(chunk, fromInt(power - 1 | 0)));
        }
         while (inductionVariable <= last);
      return new RadixDigits537(chunks, count, radix, width);
    }
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var scratch = words.slice();
    var remaining = scratch.length;
    var chunks_0 = new Int32Array(4);
    var count_0 = 0;
    while (remaining > 0) {
      if (count_0 === chunks_0.length) {
        var tmp0 = new Long(2147483647, 0);
        // Inline function 'kotlin.Long.times' call
        var this_9 = fromInt(chunks_0.length);
        // Inline function 'kotlin.comparisons.minOf' call
        var b = multiply(this_9, fromInt(2));
        var tmp$ret$20 = compare(tmp0, b) <= 0 ? tmp0 : b;
        var next = convertToInt(tmp$ret$20);
        if (next === chunks_0.length) {
          plainStringTooLarge();
        }
        chunks_0 = copyOf(chunks_0, next);
      }
      var tmp_0 = chunks_0;
      var _unary__edvuaz = count_0;
      count_0 = _unary__edvuaz + 1 | 0;
      tmp_0[_unary__edvuaz] = divideDecimalChunk(this, scratch, remaining, power);
      while (remaining > 0 && scratch[remaining - 1 | 0] === 0) {
        remaining = remaining - 1 | 0;
      }
    }
    return new RadixDigits537(chunks_0, count_0, radix, width);
  };
  protoOf(BigInteger).gv = function (radix, maxDigits, $super) {
    maxDigits = maxDigits === VOID ? null : maxDigits;
    return $super === VOID ? this.fm(radix, maxDigits) : $super.fm.call(this, radix, maxDigits);
  };
  protoOf(BigInteger).ti = function () {
    var length = (this.en() / 8 | 0) + 1 | 0;
    var magnitude = this.oi_1 < 0 ? this.xk().yk(Companion_getInstance_1().zj_1) : this;
    var tmp = 0;
    var tmp_0 = new Int8Array(length);
    while (tmp < length) {
      var tmp_1 = tmp;
      var byte = 0;
      var inductionVariable = 0;
      if (inductionVariable <= 7)
        do {
          var b = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (magnitude.bl(imul((length - tmp_1 | 0) - 1 | 0, 8) + b | 0))
            byte = byte | 1 << b;
        }
         while (inductionVariable <= 7);
      tmp_0[tmp_1] = toByte(this.oi_1 < 0 ? ~byte : byte);
      tmp = tmp + 1 | 0;
    }
    return tmp_0;
  };
  protoOf(BigInteger).kq = function () {
    if (this.ri_1 === 1)
      return this.qi_1;
    var words = materializeMagnitude(this);
    // Inline function 'kotlin.collections.getOrElse' call
    var tmp;
    if (0 <= 0 ? 0 <= (words.length - 1 | 0) : false) {
      tmp = words[0];
    } else {
      tmp = 0;
    }
    var tmp_0 = tmp;
    // Inline function 'kotlin.collections.getOrElse' call
    var tmp_1;
    if (0 <= 1 ? 1 <= (words.length - 1 | 0) : false) {
      tmp_1 = words[1];
    } else {
      tmp_1 = 0;
    }
    var low = tmp_0 | tmp_1 << 30;
    return this.oi_1 < 0 ? -low | 0 : low;
  };
  protoOf(BigInteger).um = function () {
    if (this.ri_1 === 1)
      return this.cl();
    var words = materializeMagnitude(this);
    var value = new Long(0, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var a = words.length;
    var inductionVariable = Math.min(a, 3) - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        value = bitwiseOr(shiftLeft(value, 30), fromInt(words[i]));
      }
       while (0 <= inductionVariable);
    return this.oi_1 < 0 ? negate(value) : value;
  };
  protoOf(BigInteger).wm = function (raise) {
    var tmp = fromInt(magnitudeBits(this));
    // Inline function 'kotlin.Long.times' call
    var this_0 = new Long(4, 0);
    var tmp$ret$0 = multiply(this_0, fromInt(raise));
    return compare(add(tmp, tmp$ret$0), new Long(2147483647, 0)) <= 0;
  };
  protoOf(BigInteger).vm = function (raise, bits) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(bits === 32 || bits === 64)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(0 <= raise ? raise < bits : false)) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    var tmp;
    if (this.ri_1 === 1) {
      tmp = this.cl();
    } else {
      var words = materializeMagnitude(this);
      var low = new Long(0, 0);
      // Inline function 'kotlin.comparisons.minOf' call
      var a = words.length;
      var inductionVariable = Math.min(a, 3) - 1 | 0;
      if (0 <= inductionVariable)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + -1 | 0;
          low = bitwiseOr(shiftLeft(low, 30), fromInt(words[i]));
        }
         while (0 <= inductionVariable);
      tmp = this.oi_1 < 0 ? negate(low) : low;
    }
    var value = tmp;
    // Inline function 'kotlin.repeat' call
    var inductionVariable_0 = 0;
    if (inductionVariable_0 < raise)
      do {
        var index = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        value = multiply(value, new Long(10, 0));
      }
       while (inductionVariable_0 < raise);
    return bits === 32 ? fromInt(convertToInt(value)) : value;
  };
  protoOf(BigInteger).vk = function () {
    if (!(this.ri_1 === 1))
      return null;
    var value = this.cl();
    return equalsLong(value, new Long(0, -2147483648)) ? null : value;
  };
  protoOf(BigInteger).em = function () {
    return this.oi_1 === 0 ? 1 : convertToInt(shiftRightUnsigned(multiply(fromInt(magnitudeBits(this) - 1 | 0), new Long(1292913986, 0)), 32)) + 1 | 0;
  };
  protoOf(BigInteger).vi = function () {
    if (this.ri_1 === 1)
      return CompactInteger529_getInstance().jl(this.cl());
    var words = materializeMagnitude(this);
    if (this.oi_1 === 0)
      return 1;
    var lower = this.em();
    if (lower === 646456993)
      return lower;
    var tmp0_elvis_lhs = DecimalPowers597_getInstance().uk(lower);
    var threshold = tmp0_elvis_lhs == null ? Companion_getInstance_1().bk_1.gk(lower) : tmp0_elvis_lhs;
    return lower + (compareMagnitude_0(Companion_getInstance_1(), words, materializeMagnitude(threshold)) >= 0 ? 1 : 0) | 0;
  };
  protoOf(BigInteger).wi = function (other) {
    if (this.ri_1 === 1 && other.ri_1 === 1)
      return CompactInteger529_getInstance().zl(this.cl(), other.cl());
    var words = materializeMagnitude(this);
    if (this.oi_1 === 0 || other.oi_1 === 0)
      return compareTo(this.oi_1 === 0 ? 0 : 1, other.oi_1 === 0 ? 0 : 1);
    var difference = this.vi() - other.vi() | 0;
    if (difference === 0)
      return compareMagnitude_0(Companion_getInstance_1(), words, materializeMagnitude(other));
    var longer = difference > 0 ? this : other;
    var shorter = difference > 0 ? other : this;
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var quotient = materializeMagnitude(longer).slice();
    var length = quotient.length;
    var drop = difference > 0 ? difference : -difference | 0;
    var sticky = false;
    while (drop >= 9) {
      var remainder = divideDecimalChunk(this, quotient, length, 1000000000);
      sticky = sticky || !(remainder === 0);
      while (length > 0 && quotient[length - 1 | 0] === 0) {
        length = length - 1 | 0;
      }
      drop = drop - 9 | 0;
    }
    if (drop > 0) {
      var divisor = 1;
      // Inline function 'kotlin.repeat' call
      var times = drop;
      var inductionVariable = 0;
      if (inductionVariable < times)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          divisor = imul(divisor, 10);
        }
         while (inductionVariable < times);
      var remainder_0 = divideDecimalChunk(this, quotient, length, divisor);
      sticky = sticky || !(remainder_0 === 0);
      while (length > 0 && quotient[length - 1 | 0] === 0) {
        length = length - 1 | 0;
      }
    }
    var quotientOrder = compareDecimalScratch(this, quotient, length, materializeMagnitude(shorter));
    var order = !(quotientOrder === 0) ? quotientOrder : sticky ? 1 : 0;
    return difference > 0 ? order : -order | 0;
  };
  protoOf(BigInteger).zm = function (maxDigits) {
    var words = materializeMagnitude(this);
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(maxDigits > 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (this.oi_1 === 0)
      return new DecimalBinaryPrefix(Companion_getInstance_1().yj_1, 1, 0, false);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = this.em() - maxDigits | 0;
    var trim = Math.max(0, b);
    var absolute = BigInteger_init_$Create$_0(1, words);
    var tmp;
    if (trim === 0) {
      // Inline function 'kotlin.arrayOf' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp = [absolute, Companion_getInstance_1().yj_1];
    } else {
      tmp = divideStored(absolute, Companion_getInstance_1().bk_1.gk(trim));
    }
    var qr = tmp;
    var digits = qr[0].toString();
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_0 = digits.length - maxDigits | 0;
    var extra = Math.max(0, b_0);
    var tmp_0;
    if (!(qr[1].oi_1 === 0)) {
      tmp_0 = true;
    } else {
      var tmp0 = until(maxDigits, digits.length);
      var tmp$ret$8;
      $l$block_0: {
        // Inline function 'kotlin.collections.any' call
        var tmp_1;
        if (isInterface(tmp0, Collection)) {
          tmp_1 = tmp0.m();
        } else {
          tmp_1 = false;
        }
        if (tmp_1) {
          tmp$ret$8 = false;
          break $l$block_0;
        }
        var inductionVariable = tmp0.kf_1;
        var last = tmp0.lf_1;
        if (inductionVariable <= last)
          do {
            var element = inductionVariable;
            inductionVariable = inductionVariable + 1 | 0;
            var it = element;
            if (!(charCodeAt(digits, it) === _Char___init__impl__6a9atx(48))) {
              tmp$ret$8 = true;
              break $l$block_0;
            }
          }
           while (!(element === last));
        tmp$ret$8 = false;
      }
      tmp_0 = tmp$ret$8;
    }
    var sticky = tmp_0;
    var prefix = extra === 0 ? qr[0] : BigInteger_init_$Create$_2(substring_0(digits, 0, maxDigits));
    return new DecimalBinaryPrefix(prefix, trim + digits.length | 0, trim + extra | 0, sticky);
  };
  protoOf(BigInteger).lq = function () {
    return toByte(this.kq());
  };
  protoOf(BigInteger).mq = function () {
    return toShort(this.kq());
  };
  protoOf(BigInteger).qq = function () {
    return floatingValue(this, 53, 1024);
  };
  protoOf(BigInteger).ym = function () {
    return floatingValue(this, 24, 128);
  };
  protoOf(BigInteger).nq = function () {
    if (magnitudeBits(this) > 32 || this.en() > 31)
      throw ArithmeticException_init_$Create$('BigInteger out of int range');
    return this.kq();
  };
  protoOf(BigInteger).xm = function () {
    if (magnitudeBits(this) > 64 || this.en() > 63)
      throw ArithmeticException_init_$Create$('BigInteger out of long range');
    return this.um();
  };
  protoOf(BigInteger).oq = function () {
    if (magnitudeBits(this) > 32 || this.en() > 15)
      throw ArithmeticException_init_$Create$('BigInteger out of short range');
    return this.mq();
  };
  protoOf(BigInteger).pq = function () {
    if (magnitudeBits(this) > 32 || this.en() > 7)
      throw ArithmeticException_init_$Create$('BigInteger out of byte range');
    return this.lq();
  };
  function get_lowestSetBit(_this__u8e3s4) {
    return _this__u8e3s4.vl();
  }
  function CompactInteger529() {
    CompactInteger529_instance = this;
    this.el_1 = new Long(1073741823, 0);
    var tmp = this;
    // Inline function 'kotlin.run' call
    var power = {_v: new Long(-1, -1)};
    var tmp_0 = 0;
    var tmp_1 = longArray(19);
    while (tmp_0 < 19) {
      var tmp_2 = tmp_0;
      if (!(tmp_2 === 0)) {
        power._v = multiply(power._v, new Long(10, 0));
      }
      tmp_1[tmp_2] = power._v;
      tmp_0 = tmp_0 + 1 | 0;
    }
    tmp.fl_1 = tmp_1;
  }
  protoOf(CompactInteger529).hl = function (value) {
    return compare(value, new Long(0, 0)) < 0 ? -1 : compare(value, new Long(0, 0)) > 0 ? 1 : 0;
  };
  protoOf(CompactInteger529).gl = function (high, low) {
    return bitwiseOr(shiftLeft(fromInt(high), 32), bitwiseAnd(fromInt(low), new Long(-1, 0)));
  };
  protoOf(CompactInteger529).ll = function (a, b, result) {
    return compare(bitwiseAnd(bitwiseXor(a, result), bitwiseXor(b, result)), new Long(0, 0)) >= 0;
  };
  protoOf(CompactInteger529).ml = function (a, b, result) {
    return compare(bitwiseAnd(bitwiseXor(a, b), bitwiseXor(a, result)), new Long(0, 0)) >= 0;
  };
  protoOf(CompactInteger529).sl = function (a, b, result) {
    return equalsLong(a, new Long(0, 0)) || equalsLong(b, new Long(0, 0)) || ((!equalsLong(a, new Long(0, -2147483648)) || !equalsLong(b, new Long(-1, -1))) && (!equalsLong(b, new Long(0, -2147483648)) || !equalsLong(a, new Long(-1, -1))) && equalsLong(divide(result, a), b));
  };
  protoOf(CompactInteger529).bm = function (exponent) {
    return negate(this.fl_1[exponent]);
  };
  protoOf(CompactInteger529).jl = function (value) {
    var negative = compare(value, new Long(0, 0)) > 0 ? negate(value) : value;
    var lower = 1;
    var upper = 19;
    while (lower < upper) {
      var middle = (lower + upper | 0) >>> 1 | 0;
      if (compare(negative, this.fl_1[middle]) > 0)
        upper = middle;
      else
        lower = middle + 1 | 0;
    }
    return lower;
  };
  protoOf(CompactInteger529).zl = function (a, b) {
    return this.yl(a, b, this.jl(a), this.jl(b));
  };
  protoOf(CompactInteger529).yl = function (a, b, leftDigits, rightDigits) {
    var left = compare(a, new Long(0, 0)) > 0 ? negate(a) : a;
    var right = compare(b, new Long(0, 0)) > 0 ? negate(b) : b;
    var difference = leftDigits - rightDigits | 0;
    var sticky = false;
    if (difference > 0) {
      // Inline function 'kotlin.repeat' call
      var inductionVariable = 0;
      if (inductionVariable < difference)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var tmp;
          if (sticky) {
            tmp = true;
          } else {
            // Inline function 'kotlin.Long.rem' call
            var this_0 = left;
            var tmp$ret$2 = modulo(this_0, fromInt(10));
            tmp = !equalsLong(tmp$ret$2, new Long(0, 0));
          }
          sticky = tmp;
          // Inline function 'kotlin.Long.div' call
          var this_1 = left;
          left = divide(this_1, fromInt(10));
        }
         while (inductionVariable < difference);
    }
    if (difference < 0) {
      // Inline function 'kotlin.repeat' call
      var times = -difference | 0;
      var inductionVariable_0 = 0;
      if (inductionVariable_0 < times)
        do {
          var index_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          var tmp_0;
          if (sticky) {
            tmp_0 = true;
          } else {
            // Inline function 'kotlin.Long.rem' call
            var this_2 = right;
            var tmp$ret$6 = modulo(this_2, fromInt(10));
            tmp_0 = !equalsLong(tmp$ret$6, new Long(0, 0));
          }
          sticky = tmp_0;
          // Inline function 'kotlin.Long.div' call
          var this_3 = right;
          right = divide(this_3, fromInt(10));
        }
         while (inductionVariable_0 < times);
    }
    var order = right.t2(left);
    return !(order === 0) ? order : !sticky ? 0 : difference > 0 ? 1 : -1;
  };
  protoOf(CompactInteger529).ds = function (value) {
    var magnitude = compare(value, new Long(0, 0)) < 0 ? negate(value) : value;
    return 64 - countLeadingZeroBits(magnitude) | 0;
  };
  protoOf(CompactInteger529).ks = function (sign, words) {
    return words.length < 3 || (words.length === 3 && (words[2] < 8 || (sign < 0 && words[2] === 8 && words[1] === 0 && words[0] === 0)));
  };
  protoOf(CompactInteger529).js = function (sign, words) {
    var magnitude = new Long(0, 0);
    var inductionVariable = words.length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        magnitude = bitwiseOr(shiftLeft(magnitude, 30), fromInt(words[i]));
      }
       while (0 <= inductionVariable);
    return sign < 0 ? negate(magnitude) : magnitude;
  };
  protoOf(CompactInteger529).ls = function (high, low, index) {
    var negative = high < 0;
    var lo = negative ? -low | 0 : low;
    var hi = negative ? ~high + (low === 0 ? 1 : 0) | 0 : high;
    switch (index) {
      case 0:
        return lo & 1073741823;
      case 1:
        return (lo >>> 30 | 0 | hi << 2) & 1073741823;
      case 2:
        return hi >>> 28 | 0;
      default:
        return 0;
    }
  };
  protoOf(CompactInteger529).es = function (high, low) {
    var bits = this.ds(this.gl(high, low));
    var tmp = 0;
    var tmp_0 = (bits + 29 | 0) / 30 | 0;
    var tmp_1 = new Int32Array(tmp_0);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      tmp_1[tmp_2] = CompactInteger529_getInstance().ls(high, low, tmp_2);
      tmp = tmp + 1 | 0;
    }
    return tmp_1;
  };
  var CompactInteger529_instance;
  function CompactInteger529_getInstance() {
    if (CompactInteger529_instance == null)
      new CompactInteger529();
    return CompactInteger529_instance;
  }
  var static_init_called;
  function static_init() {
    if (static_init_called)
      return Unit_instance;
    static_init_called = true;
    DecimalRounding_EACH_STEP_instance = new DecimalRounding('EACH_STEP', 0);
    DecimalRounding_FINAL_RESULT_instance = new DecimalRounding('FINAL_RESULT', 1);
  }
  var DecimalRounding_EACH_STEP_instance;
  var DecimalRounding_FINAL_RESULT_instance;
  function values() {
    static_init();
    return [DecimalRounding_EACH_STEP_getInstance(), DecimalRounding_FINAL_RESULT_getInstance()];
  }
  function get_entries() {
    static_init();
    if ($ENTRIES == null)
      $ENTRIES = enumEntries(values());
    return $ENTRIES;
  }
  var $ENTRIES;
  function DecimalRounding(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function addValue_0($this, value) {
    checkTermBudget($this);
    var input = observed($this, value);
    var inputDigits = $this.qv_1 == null ? 0 : checkedDigits($this, input);
    if (equalsLong($this.xv_1, new Long(0, 0))) {
      var result = $this.pv_1.equals(DecimalRounding_EACH_STEP_getInstance()) ? input.rk($this.ov_1) : input;
      store($this, result);
    } else {
      var direct = input.sn();
      var fallback = direct ? null : input.un().vk();
      var tmp;
      if (direct) {
        tmp = input.tn();
      } else {
        tmp = fallback == null ? new Long(0, 0) : fallback;
      }
      var incoming = tmp;
      if ($this.wv_1 == null && $this.vv_1 == null && (direct || !(fallback == null)) && $this.uv_1 === input.vn() && ($this.pv_1.equals(DecimalRounding_FINAL_RESULT_getInstance()) || $this.ov_1.ol_1 === 0) && !additionOverflows($this, $this.tv_1, incoming)) {
        var result_0 = add($this.tv_1, incoming);
        if (!($this.qv_1 == null)) {
          checkWork($this, fromInt(longDigits($this, result_0)));
        }
        $this.tv_1 = result_0;
      } else {
        if ($this.pv_1.equals(DecimalRounding_FINAL_RESULT_getInstance())) {
          var work = expandedCopy($this);
          if (!($this.qv_1 == null)) {
            checkWork($this, work.aw(fromInt(input.vn()), fromInt(inputDigits)));
          }
          work.bw(input);
          $this.wv_1 = work;
          $this.vv_1 = null;
          var _unary__edvuaz = $this.xv_1;
          $this.xv_1 = add(_unary__edvuaz, get_ONE());
          return $this;
        }
        var current = stored($this);
        if (!($this.qv_1 == null)) {
          var tmp0 = current.vn();
          // Inline function 'kotlin.comparisons.maxOf' call
          var b = input.vn();
          var tmp$ret$0 = Math.max(tmp0, b);
          var targetScale = fromInt(tmp$ret$0);
          var tmp0_0 = add(fromInt(checkedDigits($this, current)), targetScale);
          // Inline function 'kotlin.Long.minus' call
          var other = current.vn();
          var tmp0_1 = subtract(tmp0_0, fromInt(other));
          var tmp0_2 = add(fromInt(inputDigits), targetScale);
          // Inline function 'kotlin.Long.minus' call
          var other_0 = input.vn();
          // Inline function 'kotlin.comparisons.maxOf' call
          var b_0 = subtract(tmp0_2, fromInt(other_0));
          // Inline function 'kotlin.Long.plus' call
          var this_0 = compare(tmp0_1, b_0) >= 0 ? tmp0_1 : b_0;
          var estimate = add(this_0, fromInt(1));
          checkWork($this, estimate);
        }
        var result_1 = $this.pv_1.equals(DecimalRounding_EACH_STEP_getInstance()) ? current.ao(input, $this.ov_1) : current.zn(input);
        store($this, result_1);
      }
    }
    var _unary__edvuaz_0 = $this.xv_1;
    $this.xv_1 = add(_unary__edvuaz_0, get_ONE());
    return $this;
  }
  function addProductValue($this, left, right) {
    checkTermBudget($this);
    var a = observed($this, left);
    var b = observed($this, right);
    if (!($this.qv_1 == null)) {
      var tmp0 = fromInt(checkedDigits($this, a));
      // Inline function 'kotlin.Long.plus' call
      var other = checkedDigits($this, b);
      var tmp$ret$0 = add(tmp0, fromInt(other));
      checkWork($this, tmp$ret$0);
    }
    if ($this.pv_1.equals(DecimalRounding_FINAL_RESULT_getInstance())) {
      var tmp0_0 = fromInt(a.vn());
      // Inline function 'kotlin.Long.plus' call
      var other_0 = b.vn();
      var productScale = add(tmp0_0, fromInt(other_0));
      var work = equalsLong($this.xv_1, new Long(0, 0)) ? new DecimalSignedWork535(productScale) : expandedCopy($this);
      if (!($this.qv_1 == null) && !equalsLong($this.xv_1, new Long(0, 0))) {
        var tmp0_1 = fromInt(checkedDigits($this, a));
        // Inline function 'kotlin.Long.plus' call
        var other_1 = checkedDigits($this, b);
        var tmp$ret$2 = add(tmp0_1, fromInt(other_1));
        checkWork($this, work.aw(productScale, tmp$ret$2));
      }
      work.cw(a, b);
      $this.wv_1 = work;
      $this.vv_1 = null;
      var _unary__edvuaz = $this.xv_1;
      $this.xv_1 = add(_unary__edvuaz, get_ONE());
      return $this;
    }
    var product = $this.pv_1.equals(DecimalRounding_EACH_STEP_getInstance()) ? a.eo(b, $this.ov_1) : a.do(b);
    if (equalsLong($this.xv_1, new Long(0, 0))) {
      store($this, product);
      $this.xv_1 = new Long(1, 0);
      return $this;
    }
    return addValue_0($this, product);
  }
  function checkTermBudget($this) {
    if (equalsLong($this.xv_1, new Long(-1, 2147483647)) || (!($this.rv_1 == null) && compare($this.xv_1, $this.rv_1) >= 0))
      throw ArithmeticException_init_$Create$('Decimal term limit exceeded');
  }
  function checkWork($this, digits) {
    if (!($this.qv_1 == null) && compare(digits, $this.qv_1) > 0)
      throw ArithmeticException_init_$Create$('Decimal work limit exceeded');
  }
  function checkedDigits($this, value) {
    if (value.sn()) {
      // Inline function 'kotlin.also' call
      var this_0 = longDigits($this, value.tn());
      checkWork($this, fromInt(this_0));
      return this_0;
    }
    var coefficient = value.un();
    var small = coefficient.vk();
    if (!(small == null)) {
      // Inline function 'kotlin.also' call
      var this_1 = longDigits($this, small);
      checkWork($this, fromInt(this_1));
      return this_1;
    }
    checkWork($this, fromInt(coefficient.em()));
    // Inline function 'kotlin.also' call
    var this_2 = value.ql();
    checkWork($this, fromInt(this_2));
    return this_2;
  }
  function store($this, value) {
    $this.wv_1 = null;
    var direct = value.sn();
    var fallback = direct ? null : value.un().vk();
    if (!direct && fallback == null)
      $this.vv_1 = value;
    else {
      $this.tv_1 = direct ? value.tn() : ensureNotNull(fallback);
      $this.uv_1 = value.vn();
      $this.vv_1 = null;
    }
  }
  function stored($this) {
    var tmp0_elvis_lhs = $this.vv_1;
    return tmp0_elvis_lhs == null ? Companion_getInstance().fn($this.tv_1, $this.uv_1) : tmp0_elvis_lhs;
  }
  function expandedCopy($this) {
    var tmp0_safe_receiver = $this.wv_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.dw();
    var tmp;
    if (tmp1_elvis_lhs == null) {
      // Inline function 'kotlin.let' call
      var value = stored($this);
      // Inline function 'kotlin.also' call
      var this_0 = new DecimalSignedWork535(fromInt(value.vn()));
      this_0.bw(value);
      tmp = this_0;
    } else {
      tmp = tmp1_elvis_lhs;
    }
    return tmp;
  }
  function observed($this, value) {
    return getKClassFromExpression(value).equals(getKClass(BigDecimal)) ? value : BigDecimal_init_$Create$_0(value.un(), value.vn());
  }
  function additionOverflows($this, a, b) {
    return compare(b, new Long(0, 0)) > 0 && compare(a, subtract(new Long(-1, 2147483647), b)) > 0 || (compare(b, new Long(0, 0)) < 0 && compare(a, subtract(new Long(0, -2147483648), b)) < 0);
  }
  function longDigits($this, value) {
    var negative = compare(value, new Long(0, 0)) > 0 ? negate(value) : value;
    var digits = 1;
    while (compare(negative, new Long(-10, -1)) <= 0) {
      // Inline function 'kotlin.Long.div' call
      var this_0 = negative;
      negative = divide(this_0, fromInt(10));
      digits = digits + 1 | 0;
    }
    return digits;
  }
  function DecimalAccumulator(context, rounding, maxWorkingDigits, maxTerms) {
    context = context === VOID ? Companion_getInstance_4().yi_1 : context;
    rounding = rounding === VOID ? DecimalRounding_FINAL_RESULT_getInstance() : rounding;
    maxWorkingDigits = maxWorkingDigits === VOID ? null : maxWorkingDigits;
    maxTerms = maxTerms === VOID ? null : maxTerms;
    this.ov_1 = context;
    this.pv_1 = rounding;
    this.qv_1 = maxWorkingDigits;
    this.rv_1 = maxTerms;
    this.sv_1 = false;
    this.tv_1 = new Long(0, 0);
    this.uv_1 = 0;
    this.vv_1 = null;
    this.wv_1 = null;
    this.xv_1 = new Long(0, 0);
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!((this.qv_1 == null || compare(this.qv_1, new Long(0, 0)) > 0) && (this.rv_1 == null || compare(this.rv_1, new Long(0, 0)) > 0))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
  }
  protoOf(DecimalAccumulator).zn = function (value) {
    var tmp$ret$0;
    $l$block: {
      // Inline function 'io.heapy.krogu.math.DecimalAccumulator.mutate' call
      // Inline function 'kotlin.check' call
      if (!!this.sv_1) {
        var message = 'Reentrant decimal accumulation';
        throw IllegalStateException_init_$Create$(toString_0(message));
      }
      this.sv_1 = true;
      try {
        tmp$ret$0 = addValue_0(this, value);
        break $l$block;
      }finally {
        this.sv_1 = false;
      }
    }
    return tmp$ret$0;
  };
  protoOf(DecimalAccumulator).ew = function (left, right) {
    var tmp$ret$0;
    $l$block: {
      // Inline function 'io.heapy.krogu.math.DecimalAccumulator.mutate' call
      // Inline function 'kotlin.check' call
      if (!!this.sv_1) {
        var message = 'Reentrant decimal accumulation';
        throw IllegalStateException_init_$Create$(toString_0(message));
      }
      this.sv_1 = true;
      try {
        tmp$ret$0 = addProductValue(this, left, right);
        break $l$block;
      }finally {
        this.sv_1 = false;
      }
    }
    return tmp$ret$0;
  };
  protoOf(DecimalAccumulator).fw = function () {
    if (this.pv_1.equals(DecimalRounding_FINAL_RESULT_getInstance())) {
      if (equalsLong(this.xv_1, new Long(0, 0)))
        return Companion_getInstance().ij_1;
      var tmp0_elvis_lhs = this.wv_1;
      return (tmp0_elvis_lhs == null ? expandedCopy(this) : tmp0_elvis_lhs).gw(this.ov_1);
    }
    var value = equalsLong(this.xv_1, new Long(0, 0)) ? Companion_getInstance().ij_1 : stored(this);
    return value;
  };
  protoOf(DecimalAccumulator).b4 = function () {
    // Inline function 'kotlin.check' call
    if (!!this.sv_1) {
      var message = 'Reentrant decimal accumulation';
      throw IllegalStateException_init_$Create$(toString_0(message));
    }
    this.tv_1 = new Long(0, 0);
    this.uv_1 = 0;
    this.vv_1 = null;
    this.wv_1 = null;
    this.xv_1 = new Long(0, 0);
  };
  function fma(_this__u8e3s4, multiplier, addend, context, rounding, maxWorkingDigits) {
    context = context === VOID ? Companion_getInstance_4().yi_1 : context;
    rounding = rounding === VOID ? DecimalRounding_FINAL_RESULT_getInstance() : rounding;
    maxWorkingDigits = maxWorkingDigits === VOID ? null : maxWorkingDigits;
    return (new DecimalAccumulator(context, rounding, maxWorkingDigits, new Long(2, 0))).ew(_this__u8e3s4, multiplier).zn(addend).fw();
  }
  function sumDecimals(_this__u8e3s4, context, rounding, maxWorkingDigits, maxTerms) {
    context = context === VOID ? Companion_getInstance_4().yi_1 : context;
    rounding = rounding === VOID ? DecimalRounding_FINAL_RESULT_getInstance() : rounding;
    maxWorkingDigits = maxWorkingDigits === VOID ? null : maxWorkingDigits;
    maxTerms = maxTerms === VOID ? null : maxTerms;
    var accumulator = new DecimalAccumulator(context, rounding, maxWorkingDigits, maxTerms);
    var _iterator__ex2g4s = _this__u8e3s4.o();
    while (_iterator__ex2g4s.p()) {
      var value = _iterator__ex2g4s.q();
      accumulator.zn(value);
    }
    return accumulator.fw();
  }
  function dotProduct(_this__u8e3s4, other, context, rounding, maxWorkingDigits, maxTerms) {
    context = context === VOID ? Companion_getInstance_4().yi_1 : context;
    rounding = rounding === VOID ? DecimalRounding_FINAL_RESULT_getInstance() : rounding;
    maxWorkingDigits = maxWorkingDigits === VOID ? null : maxWorkingDigits;
    maxTerms = maxTerms === VOID ? null : maxTerms;
    var accumulator = new DecimalAccumulator(context, rounding, maxWorkingDigits, maxTerms);
    var left = _this__u8e3s4.o();
    var right = other.o();
    while (left.p() && right.p()) {
      accumulator.ew(left.q(), right.q());
    }
    // Inline function 'kotlin.require' call
    if (!(!left.p() && !right.p())) {
      var message = 'Dot product lengths differ';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    return accumulator.fw();
  }
  function DecimalRounding_EACH_STEP_getInstance() {
    static_init();
    return DecimalRounding_EACH_STEP_instance;
  }
  function DecimalRounding_FINAL_RESULT_getInstance() {
    static_init();
    return DecimalRounding_FINAL_RESULT_instance;
  }
  function trim($this) {
    while ($this.iw_1 > 0 && $this.hw_1.y($this.iw_1 - 1 | 0) === 0) {
      $this.iw_1 = $this.iw_1 - 1 | 0;
    }
  }
  function IntegerView583(coefficient, length, coefficientDigits, lastNonzero) {
    this.lw_1 = coefficient;
    this.mw_1 = length;
    this.nw_1 = coefficientDigits;
    this.ow_1 = lastNonzero;
  }
  protoOf(IntegerView583).pw = function (position) {
    // Inline function 'kotlin.check' call
    if (!(compare(new Long(0, 0), position) <= 0 ? compare(position, this.mw_1) < 0 : false)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return compare(position, this.nw_1) < 0 ? ensureNotNull(this.lw_1).qw(position, this.nw_1) : 0;
  };
  protoOf(IntegerView583).rw = function (position) {
    return compare(position, this.ow_1) >= 0;
  };
  function integerView583($this, coefficient, scale) {
    if (coefficient == null)
      return new IntegerView583(null, new Long(0, 0), new Long(0, 0), new Long(0, 0));
    var digits = coefficient.sw();
    var zeros = coefficient.tw();
    if (scale > 0 && compare(zeros, fromInt(scale)) < 0)
      return null;
    return new IntegerView583(coefficient, subtract(digits, fromInt(scale)), digits, subtract(digits, zeros));
  }
  function exactResult($this, q, sign, preferred, exponent, kept, precision) {
    // Inline function 'kotlin.Long.minus' call
    var this_0 = add(preferred, kept);
    var tmp$ret$0 = subtract(this_0, fromInt(1));
    var scale = subtract(tmp$ret$0, exponent);
    while (q.uw()) {
      // Inline function 'kotlin.check' call
      if (!(q.vw() === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var _unary__edvuaz = scale;
      scale = subtract(_unary__edvuaz, get_ONE());
    }
    var tmp0 = subtract(preferred, scale);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = new Long(0, 0);
    var tmp0_0 = compare(tmp0, b) >= 0 ? tmp0 : b;
    // Inline function 'kotlin.comparisons.minOf' call
    var b_0 = subtract(precision, q.sw());
    var padding = compare(tmp0_0, b_0) <= 0 ? tmp0_0 : b_0;
    var resultScale = checkedScale_0($this, add(scale, padding));
    var remaining = padding;
    while (compare(remaining, new Long(0, 0)) > 0) {
      q.xr(10, 0);
      var _unary__edvuaz_0 = remaining;
      remaining = subtract(_unary__edvuaz_0, get_ONE());
    }
    return publish($this, q, sign, resultScale);
  }
  function increment_0($this, mode, sign, half, odd) {
    var tmp;
    switch (mode.l2_1) {
      case 0:
        tmp = true;
        break;
      case 1:
        tmp = false;
        break;
      case 2:
        tmp = sign > 0;
        break;
      case 3:
        tmp = sign < 0;
        break;
      case 4:
        tmp = half >= 0;
        break;
      case 5:
        tmp = half > 0;
        break;
      case 6:
        tmp = half > 0 || (half === 0 && odd);
        break;
      case 7:
        throw ArithmeticException_init_$Create$('Rounding necessary');
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function checkedScale_0($this, scale) {
    var narrowed = convertToInt(scale);
    if (!equalsLong(fromInt(narrowed), scale))
      throw ArithmeticException_init_$Create$(narrowed > 0 ? 'Underflow' : 'Overflow');
    return narrowed;
  }
  function decimalChunks($this, words, scratch) {
    var inductionVariable = 0;
    var last = words.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        scratch.ww(i, words[i]);
      }
       while (inductionVariable <= last);
    var size = words.length;
    var tmp0 = new Long(646456993, 0);
    var tmp0_0 = new Long(10, 0);
    // Inline function 'kotlin.Long.times' call
    var other = words.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(tmp0_0, fromInt(other));
    var digitBound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(digitBound, fromInt(8));
    var tmp$ret$3 = divide(this_0, fromInt(9));
    var result = new DecimalWords(convertToInt(tmp$ret$3));
    while (size > 0) {
      var remainder = new Long(0, 0);
      var inductionVariable_0 = size - 1 | 0;
      if (0 <= inductionVariable_0)
        do {
          var i_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + -1 | 0;
          var tmp0_1 = shiftLeft(remainder, 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = scratch.y(i_0);
          var part = add(tmp0_1, fromInt(other_0));
          // Inline function 'kotlin.Long.div' call
          var other_1 = 1000000000;
          var tmp$ret$5 = divide(part, fromInt(other_1));
          scratch.ww(i_0, convertToInt(tmp$ret$5));
          // Inline function 'kotlin.Long.rem' call
          var other_2 = 1000000000;
          remainder = modulo(part, fromInt(other_2));
        }
         while (0 <= inductionVariable_0);
      result.xw(convertToInt(remainder));
      while (size > 0 && scratch.y(size - 1 | 0) === 0) {
        size = size - 1 | 0;
      }
    }
    // Inline function 'kotlin.check' call
    if (!(result.iw_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return result;
  }
  function publish($this, decimal, sign, scale) {
    var tmp0 = new Long(2147483647, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(new Long(4, 0), decimal.sw());
    var bitBound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bitBound, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = divide(this_0, fromInt(30));
    var tmp$ret$3 = add(this_1, fromInt(1));
    var binary = new Cells(convertToInt(tmp$ret$3));
    var size = 0;
    var inductionVariable = decimal.iw_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var carry = fromInt(decimal.y(i));
        var j = 0;
        while (j < size) {
          var tmp0_0 = fromInt(binary.y(j));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$4 = multiply(tmp0_0, fromInt(other));
          var part = add(tmp$ret$4, carry);
          binary.ww(j, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
          j = j + 1 | 0;
        }
        if (!equalsLong(carry, new Long(0, 0))) {
          var _unary__edvuaz = size;
          size = _unary__edvuaz + 1 | 0;
          binary.ww(_unary__edvuaz, convertToInt(carry));
        }
        var tmp0_1 = new Long(30, 0);
        // Inline function 'kotlin.Long.times' call
        var other_0 = size - 1 | 0;
        // Inline function 'kotlin.Long.plus' call
        var this_2 = multiply(tmp0_1, fromInt(other_0));
        var tmp0_2 = add(this_2, fromInt(32));
        // Inline function 'kotlin.countLeadingZeroBits' call
        var this_3 = binary.y(size - 1 | 0);
        // Inline function 'kotlin.Long.minus' call
        var other_1 = clz32(this_3);
        var bits = subtract(tmp0_2, fromInt(other_1));
        if (compare(bits, new Long(2147483647, 0)) > 0)
          throw ArithmeticException_init_$Create$('BigInteger overflow');
      }
       while (0 <= inductionVariable);
    var tmp0_3 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_4 = multiply(tmp0_3, fromInt(other_2));
    var tmp0_4 = add(this_4, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_5 = binary.y(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_5);
    var bits_0 = subtract(tmp0_4, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_6 = add(bits_0, fromInt(7));
    var tmp$ret$14 = divide(this_6, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$14));
    var inductionVariable_0 = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_7 = new Long(8, 0);
        var bit = multiply(this_7, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$16 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$16);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$17 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$17);
        var value = shiftRightUnsigned(fromInt(binary.y(word)), offset);
        if (offset > 22 && (word + 1 | 0) < size)
          value = bitwiseOr(value, shiftLeft(fromInt(binary.y(word + 1 | 0)), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last);
    return to(BigInteger_init_$Create$_6(sign, bytes), scale);
  }
  function Cells(limit) {
    this.jw_1 = limit;
    var tmp = this;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(limit);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(8192));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = divide(this_2, fromInt(8192));
    // Inline function 'kotlin.arrayOfNulls' call
    var size = convertToInt(tmp$ret$2);
    tmp.kw_1 = Array(size);
  }
  protoOf(Cells).y = function (index) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.jw_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tmp0_safe_receiver = this.kw_1[index / 8192 | 0];
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver[index % 8192 | 0];
    return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  };
  protoOf(Cells).ww = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.jw_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var slot = index / 8192 | 0;
    var tmp0_elvis_lhs = this.kw_1[slot];
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.comparisons.minOf' call
      var b = this.jw_1 - imul(slot, 8192) | 0;
      var tmp$ret$1 = Math.min(8192, b);
      // Inline function 'kotlin.also' call
      var this_0 = new Int32Array(tmp$ret$1);
      this.kw_1[slot] = this_0;
      tmp = this_0;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var page = tmp;
    page[index % 8192 | 0] = value;
  };
  function DecimalWords(capacity) {
    this.hw_1 = new Cells(capacity);
    this.iw_1 = 0;
  }
  protoOf(DecimalWords).y = function (index) {
    return this.hw_1.y(index);
  };
  protoOf(DecimalWords).xw = function (value) {
    this.hw_1.ww(this.iw_1, value);
    this.iw_1 = this.iw_1 + 1 | 0;
  };
  protoOf(DecimalWords).sw = function () {
    // Inline function 'kotlin.check' call
    if (!(this.iw_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var width = 1;
    var top = this.hw_1.y(this.iw_1 - 1 | 0);
    while (width < 9 && top >= DecimalDivision581_getInstance().iu_1[width]) {
      width = width + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.iw_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = width;
    return add(tmp0_0, fromInt(other_0));
  };
  protoOf(DecimalWords).tw = function () {
    var index = 0;
    while (this.hw_1.y(index) === 0) {
      index = index + 1 | 0;
    }
    var value = this.hw_1.y(index);
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = index;
    var zeros = multiply(tmp0, fromInt(other));
    while ((value % 10 | 0) === 0) {
      value = value / 10 | 0;
      var _unary__edvuaz = zeros;
      zeros = add(_unary__edvuaz, get_ONE());
    }
    return zeros;
  };
  protoOf(DecimalWords).qw = function (position, digits) {
    // Inline function 'kotlin.Long.minus' call
    var tmp$ret$0 = subtract(digits, fromInt(1));
    var at = subtract(tmp$ret$0, position);
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(at, fromInt(9));
    var tmp = this.hw_1.y(convertToInt(tmp$ret$1));
    var tmp_0 = DecimalDivision581_getInstance().iu_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(at, fromInt(9));
    return (tmp / tmp_0[convertToInt(tmp$ret$2)] | 0) % 10 | 0;
  };
  protoOf(DecimalWords).yw = function () {
    return !((this.hw_1.y(0) % 2 | 0) === 0);
  };
  protoOf(DecimalWords).uw = function () {
    return (this.hw_1.y(0) % 10 | 0) === 0;
  };
  protoOf(DecimalWords).xr = function (factor, addend) {
    var carry = fromInt(addend);
    var inductionVariable = 0;
    var last = this.iw_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(this.hw_1.y(i));
        var tmp$ret$0 = multiply(this_0, fromInt(factor));
        var part = add(tmp$ret$0, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$1 = modulo(part, fromInt(other));
        this.hw_1.ww(i, convertToInt(tmp$ret$1));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < last);
    if (!equalsLong(carry, new Long(0, 0))) {
      this.xw(convertToInt(carry));
    }
    trim(this);
  };
  protoOf(DecimalWords).zw = function (source, factor) {
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = source.iw_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(source.hw_1.y(i));
        var tmp$ret$0 = multiply(this_0, fromInt(factor));
        var part = add(tmp$ret$0, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$1 = modulo(part, fromInt(other));
        this.hw_1.ww(i, convertToInt(tmp$ret$1));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < last);
    this.iw_1 = source.iw_1;
    if (!equalsLong(carry, new Long(0, 0))) {
      this.xw(convertToInt(carry));
    }
  };
  protoOf(DecimalWords).ax = function (other) {
    if (!(this.iw_1 === other.iw_1))
      return compareTo(this.iw_1, other.iw_1);
    var inductionVariable = this.iw_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var order = compareTo(this.hw_1.y(i), other.hw_1.y(i));
        if (!(order === 0))
          return order;
      }
       while (0 <= inductionVariable);
    return 0;
  };
  protoOf(DecimalWords).bx = function (other) {
    var borrow = new Long(0, 0);
    var inductionVariable = 0;
    var last = this.iw_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = fromInt(this.hw_1.y(i));
        // Inline function 'kotlin.Long.minus' call
        var other_0 = i < other.iw_1 ? other.hw_1.y(i) : 0;
        var tmp$ret$0 = subtract(tmp0, fromInt(other_0));
        var part = subtract(tmp$ret$0, borrow);
        borrow = compare(part, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
        if (compare(part, new Long(0, 0)) < 0) {
          var tmp0_0 = part;
          // Inline function 'kotlin.Long.plus' call
          var other_1 = 1000000000;
          part = add(tmp0_0, fromInt(other_1));
        }
        this.hw_1.ww(i, convertToInt(part));
      }
       while (inductionVariable < last);
    // Inline function 'kotlin.check' call
    if (!equalsLong(borrow, new Long(0, 0))) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    trim(this);
  };
  protoOf(DecimalWords).cx = function () {
    var i = 0;
    while (i < this.iw_1 && this.hw_1.y(i) === 999999999) {
      this.hw_1.ww(i, 0);
      i = i + 1 | 0;
    }
    if (i === this.iw_1) {
      this.xw(1);
    } else {
      this.hw_1.ww(i, this.hw_1.y(i) + 1 | 0);
    }
  };
  protoOf(DecimalWords).vw = function () {
    var remainder = new Long(0, 0);
    var inductionVariable = this.iw_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.hw_1.y(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(10));
        this.hw_1.ww(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(10));
      }
       while (0 <= inductionVariable);
    trim(this);
    return convertToInt(remainder);
  };
  protoOf(DecimalWords).dx = function (count) {
    // Inline function 'kotlin.check' call
    if (!(this.iw_1 > 0 && compare(count, new Long(0, 0)) >= 0 && compare(add(this.sw(), count), new Long(646456993, 0)) <= 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(count, fromInt(9));
    var whole = convertToInt(tmp$ret$1);
    if (!(whole === 0)) {
      var inductionVariable = this.iw_1 - 1 | 0;
      if (0 <= inductionVariable)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + -1 | 0;
          this.hw_1.ww(i + whole | 0, this.hw_1.y(i));
        }
         while (0 <= inductionVariable);
      var inductionVariable_0 = 0;
      if (inductionVariable_0 < whole)
        do {
          var i_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          this.hw_1.ww(i_0, 0);
        }
         while (inductionVariable_0 < whole);
      this.iw_1 = this.iw_1 + whole | 0;
    }
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(count, fromInt(9));
    var rest = convertToInt(tmp$ret$2);
    if (!(rest === 0)) {
      this.xr(DecimalDivision581_getInstance().iu_1[rest], 0);
    }
  };
  protoOf(DecimalWords).ex = function (count) {
    // Inline function 'kotlin.check' call
    if (!(this.iw_1 > 0 && compare(count, new Long(0, 0)) >= 0 && compare(count, this.tw()) <= 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(count, fromInt(9));
    var whole = convertToInt(tmp$ret$1);
    var inductionVariable = 0;
    if (inductionVariable < whole)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.check' call
        if (!(this.hw_1.y(i) === 0)) {
          throw IllegalStateException_init_$Create$('Check failed.');
        }
      }
       while (inductionVariable < whole);
    var remaining = this.iw_1 - whole | 0;
    var inductionVariable_0 = 0;
    if (inductionVariable_0 < remaining)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        this.hw_1.ww(i_0, this.hw_1.y(i_0 + whole | 0));
      }
       while (inductionVariable_0 < remaining);
    this.iw_1 = remaining;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$3 = modulo(count, fromInt(9));
    var rest = convertToInt(tmp$ret$3);
    if (!(rest === 0)) {
      var factor = DecimalDivision581_getInstance().iu_1[rest];
      var residual = new Long(0, 0);
      var inductionVariable_1 = this.iw_1 - 1 | 0;
      if (0 <= inductionVariable_1)
        do {
          var i_1 = inductionVariable_1;
          inductionVariable_1 = inductionVariable_1 + -1 | 0;
          var tmp0 = residual;
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp0_0 = multiply(tmp0, fromInt(other));
          // Inline function 'kotlin.Long.plus' call
          var other_0 = this.hw_1.y(i_1);
          var part = add(tmp0_0, fromInt(other_0));
          // Inline function 'kotlin.Long.div' call
          var tmp$ret$6 = divide(part, fromInt(factor));
          this.hw_1.ww(i_1, convertToInt(tmp$ret$6));
          // Inline function 'kotlin.Long.rem' call
          residual = modulo(part, fromInt(factor));
        }
         while (0 <= inductionVariable_1);
      // Inline function 'kotlin.check' call
      if (!equalsLong(residual, new Long(0, 0))) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
    }
    trim(this);
  };
  function fixedScale592$nextDigit(position, inputDigits, a, remainder, trial, b) {
    var input = compare(position._v, inputDigits) < 0 ? a.qw(position._v, inputDigits) : 0;
    var _unary__edvuaz = position._v;
    position._v = add(_unary__edvuaz, get_ONE());
    remainder.xr(10, input);
    var digit = 9;
    $l$loop: while (digit > 0) {
      trial.zw(b, digit);
      if (remainder.ax(trial) >= 0)
        break $l$loop;
      digit = digit - 1 | 0;
    }
    if (!(digit === 0)) {
      remainder.bx(trial);
    }
    return digit;
  }
  function DecimalDivision581() {
    DecimalDivision581_instance = this;
    this.fu_1 = 1000000000;
    this.gu_1 = 8192;
    this.hu_1 = new Long(646456993, 0);
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.iu_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalDivision581).ju = function (sign, left, right, preferred, precision) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(fromInt(precision), new Long(646456993, 0)) > 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var gcd = left.tl(right);
    var numerator = left.ul(gcd);
    var denominator = right.ul(gcd);
    var twos = denominator.vl();
    denominator = denominator.wl(twos);
    var five = Companion_getInstance_1().fk(new Long(5, 0));
    var fives = 0;
    $l$loop: while (true) {
      var qr = denominator.wk(five);
      if (!(qr[1].ui() === 0))
        break $l$loop;
      denominator = qr[0];
      fives = fives + 1 | 0;
    }
    if (!denominator.equals(Companion_getInstance_1().zj_1))
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = fives;
    var places = Math.max(twos, b);
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$4 = add(preferred, fromInt(places));
    var scale = checkedScale_0(this, tmp$ret$4);
    if (places > twos)
      numerator = numerator.ik(places - twos | 0);
    if (places > fives)
      numerator = numerator.hk(five.gk(places - fives | 0));
    return to(sign < 0 ? numerator.jk() : numerator, scale);
  };
  protoOf(DecimalDivision581).eu = function (sign, left, right, preferred, context) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(sign === -1 || sign === 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    var tmp_0;
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(left.length === 0)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      // Inline function 'kotlin.collections.isEmpty' call
      tmp_0 = !(right.length === 0);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = context.ol_1 > 0;
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(new Long(1, -1), preferred) <= 0 ? compare(preferred, new Long(-1, 0)) <= 0 : false)) {
      var message_1 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_1));
    }
    var tmp0 = left.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = right.length;
    var tmp$ret$13 = Math.max(tmp0, b);
    var scratch = new Cells(tmp$ret$13);
    var a = decimalChunks(this, left, scratch);
    var b_0 = decimalChunks(this, right, scratch);
    var inputDigits = a.sw();
    var lastNonzero = subtract(inputDigits, a.tw());
    var remainder = new DecimalWords(b_0.iw_1 + 1 | 0);
    var trial = new DecimalWords(b_0.iw_1 + 1 | 0);
    var precision = fromInt(context.ol_1);
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.plus' call
    var this_0 = add(precision, fromInt(1));
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(9));
    var tmp$ret$17 = add(this_2, fromInt(1));
    var quotient = new DecimalWords(convertToInt(tmp$ret$17));
    var position = new Long(0, 0);
    var kept = new Long(0, 0);
    var exponent = new Long(0, 0);
    $l$loop_0: while (true) {
      var input = compare(position, inputDigits) < 0 ? a.qw(position, inputDigits) : 0;
      var _unary__edvuaz = position;
      position = add(_unary__edvuaz, get_ONE());
      remainder.xr(10, input);
      var digit = 9;
      $l$loop: while (digit > 0) {
        trial.zw(b_0, digit);
        if (remainder.ax(trial) >= 0)
          break $l$loop;
        digit = digit - 1 | 0;
      }
      if (!(digit === 0)) {
        remainder.bx(trial);
      }
      var exact = remainder.iw_1 === 0 && compare(position, lastNonzero) >= 0;
      if (equalsLong(kept, new Long(0, 0)) && digit === 0) {
        // Inline function 'kotlin.check' call
        if (!!exact) {
          throw IllegalStateException_init_$Create$('Check failed.');
        }
        continue $l$loop_0;
      }
      if (equalsLong(kept, new Long(0, 0)))
        exponent = subtract(inputDigits, position);
      if (compare(kept, precision) < 0) {
        quotient.xr(10, digit);
        var _unary__edvuaz_0 = kept;
        kept = add(_unary__edvuaz_0, get_ONE());
        if (exact)
          return exactResult(this, quotient, sign, preferred, exponent, kept, precision);
      } else {
        if (digit === 0 && exact)
          return exactResult(this, quotient, sign, preferred, exponent, kept, precision);
        var half = digit === 5 && !exact ? 1 : compareTo(digit, 5);
        if (increment_0(this, context.pl_1, sign, half, quotient.yw())) {
          quotient.cx();
        }
        // Inline function 'kotlin.Long.minus' call
        var this_3 = add(preferred, precision);
        var tmp$ret$19 = subtract(this_3, fromInt(1));
        var scale = subtract(tmp$ret$19, exponent);
        if (compare(quotient.sw(), precision) > 0) {
          // Inline function 'kotlin.check' call
          if (!(quotient.vw() === 0)) {
            throw IllegalStateException_init_$Create$('Check failed.');
          }
          var _unary__edvuaz_1 = scale;
          scale = subtract(_unary__edvuaz_1, get_ONE());
        }
        return publish(this, quotient, sign, checkedScale_0(this, scale));
      }
    }
  };
  protoOf(DecimalDivision581).ou = function (sign, left, right, shift, mode) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(sign === -1 || sign === 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(left.length === 0)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      // Inline function 'kotlin.collections.isEmpty' call
      tmp = !(right.length === 0);
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(new Long(-2147483647, -2), shift) <= 0 ? compare(shift, new Long(2147483646, 1)) <= 0 : false)) {
      var message_1 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_1));
    }
    var tmp0 = left.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = right.length;
    var tmp$ret$13 = Math.max(tmp0, b);
    var scratch = new Cells(tmp$ret$13);
    var a = decimalChunks(this, left, scratch);
    var b_0 = decimalChunks(this, right, scratch);
    var inputDigits = a.sw();
    var limit = add(inputDigits, shift);
    if (compare(limit, new Long(0, 0)) < 0)
      return increment_0(this, mode, sign, -1, false) ? Companion_getInstance_1().fk(fromInt(sign)) : Companion_getInstance_1().yj_1;
    if (compare(subtract(limit, b_0.sw()), new Long(646456993, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    var lastNonzero = subtract(inputDigits, a.tw());
    var remainder = new DecimalWords(b_0.iw_1 + 1 | 0);
    var trial = new DecimalWords(b_0.iw_1 + 1 | 0);
    var tmp0_0 = new Long(646456993, 0);
    var tmp0_1 = new Long(1, 0);
    // Inline function 'kotlin.Long.plus' call
    var this_0 = subtract(limit, b_0.sw());
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_1 = add(this_0, fromInt(1));
    // Inline function 'kotlin.comparisons.minOf' call
    var b_2 = compare(tmp0_1, b_1) >= 0 ? tmp0_1 : b_1;
    var maximumDigits = compare(tmp0_0, b_2) <= 0 ? tmp0_0 : b_2;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(maximumDigits, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(9));
    var tmp$ret$19 = add(this_2, fromInt(1));
    var quotient = new DecimalWords(convertToInt(tmp$ret$19));
    var position = {_v: new Long(0, 0)};
    var zeros = new Long(0, 0);
    $l$loop: while (compare(position._v, limit) < 0) {
      var digit = fixedScale592$nextDigit(position, inputDigits, a, remainder, trial, b_0);
      if (digit === 0) {
        if (!(quotient.iw_1 === 0)) {
          var _unary__edvuaz = zeros;
          zeros = add(_unary__edvuaz, get_ONE());
        }
      } else {
        var tmp_0;
        if (quotient.iw_1 === 0) {
          tmp_0 = new Long(1, 0);
        } else {
          // Inline function 'kotlin.Long.plus' call
          var this_3 = add(quotient.sw(), zeros);
          tmp_0 = add(this_3, fromInt(1));
        }
        var digits = tmp_0;
        if (compare(digits, new Long(646456993, 0)) > 0)
          throw ArithmeticException_init_$Create$('BigInteger overflow');
        if (!(quotient.iw_1 === 0)) {
          quotient.dx(zeros);
        }
        quotient.xr(10, digit);
        zeros = new Long(0, 0);
      }
      if (remainder.iw_1 === 0 && compare(position._v, lastNonzero) >= 0) {
        if (!(quotient.iw_1 === 0))
          zeros = add(zeros, subtract(limit, position._v));
        position._v = limit;
        break $l$loop;
      }
    }
    if (!(quotient.iw_1 === 0)) {
      if (compare(add(quotient.sw(), zeros), new Long(646456993, 0)) > 0)
        throw ArithmeticException_init_$Create$('BigInteger overflow');
      quotient.dx(zeros);
    }
    if (!(remainder.iw_1 === 0) || compare(position._v, lastNonzero) < 0) {
      var guard = fixedScale592$nextDigit(position, inputDigits, a, remainder, trial, b_0);
      var sticky = !(remainder.iw_1 === 0) || compare(position._v, lastNonzero) < 0;
      var half = guard === 5 && sticky ? 1 : compareTo(guard, 5);
      if (increment_0(this, mode, sign, half, !(quotient.iw_1 === 0) && quotient.yw())) {
        quotient.cx();
      }
    }
    if (quotient.iw_1 === 0)
      return Companion_getInstance_1().yj_1;
    if (compare(quotient.sw(), new Long(646456993, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    return publish(this, quotient, sign, 0).dd_1;
  };
  protoOf(DecimalDivision581).ku = function (sign, left, right, preferred) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(sign === -1 || sign === 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    var tmp_0;
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(left.length === 0)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      // Inline function 'kotlin.collections.isEmpty' call
      tmp_0 = !(right.length === 0);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = preferred < 0;
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    var tmp0 = left.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = right.length;
    var tmp$ret$10 = Math.max(tmp0, b);
    var scratch = new Cells(tmp$ret$10);
    var a = decimalChunks(this, left, scratch);
    var b_0 = decimalChunks(this, right, scratch);
    var inputDigits = a.sw();
    var lastNonzero = subtract(inputDigits, a.tw());
    var limit = subtract(inputDigits, fromInt(preferred));
    var remainder = new DecimalWords(b_0.iw_1 + 1 | 0);
    var trial = new DecimalWords(b_0.iw_1 + 1 | 0);
    var tmp0_0 = new Long(1, 0);
    var tmp0_1 = new Long(646456993, 0);
    // Inline function 'kotlin.Long.plus' call
    var this_0 = subtract(limit, b_0.sw());
    // Inline function 'kotlin.comparisons.minOf' call
    var b_1 = add(this_0, fromInt(1));
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_2 = compare(tmp0_1, b_1) <= 0 ? tmp0_1 : b_1;
    var quotientDigits = compare(tmp0_0, b_2) >= 0 ? tmp0_0 : b_2;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(quotientDigits, fromInt(8));
    var tmp$ret$15 = divide(this_1, fromInt(9));
    var quotient = new DecimalWords(convertToInt(tmp$ret$15));
    var position = new Long(0, 0);
    var zeros = new Long(0, 0);
    $l$loop_0: while (compare(position, limit) < 0) {
      var input = compare(position, inputDigits) < 0 ? a.qw(position, inputDigits) : 0;
      var _unary__edvuaz = position;
      position = add(_unary__edvuaz, get_ONE());
      remainder.xr(10, input);
      var digit = 9;
      $l$loop: while (digit > 0) {
        trial.zw(b_0, digit);
        if (remainder.ax(trial) >= 0)
          break $l$loop;
        digit = digit - 1 | 0;
      }
      if (!(digit === 0)) {
        remainder.bx(trial);
      }
      if (digit === 0) {
        if (!(quotient.iw_1 === 0)) {
          var _unary__edvuaz_0 = zeros;
          zeros = add(_unary__edvuaz_0, get_ONE());
        }
      } else {
        var tmp_1;
        if (quotient.iw_1 === 0) {
          tmp_1 = new Long(1, 0);
        } else {
          // Inline function 'kotlin.Long.plus' call
          var this_2 = add(quotient.sw(), zeros);
          tmp_1 = add(this_2, fromInt(1));
        }
        var digits = tmp_1;
        if (compare(digits, new Long(646456993, 0)) > 0)
          throw ArithmeticException_init_$Create$('BigInteger overflow');
        if (!(quotient.iw_1 === 0)) {
          quotient.dx(zeros);
        }
        quotient.xr(10, digit);
        zeros = new Long(0, 0);
      }
      if (remainder.iw_1 === 0 && compare(position, lastNonzero) >= 0) {
        if (quotient.iw_1 === 0)
          return to(Companion_getInstance_1().yj_1, preferred);
        zeros = add(zeros, subtract(limit, position));
        break $l$loop_0;
      }
    }
    if (quotient.iw_1 === 0)
      return to(Companion_getInstance_1().yj_1, preferred);
    var tmp0_2 = negate(zeros);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_3 = fromInt(preferred);
    var scale = compare(tmp0_2, b_3) >= 0 ? tmp0_2 : b_3;
    var padding = add(zeros, scale);
    if (compare(add(quotient.sw(), padding), new Long(646456993, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    quotient.dx(padding);
    return publish(this, quotient, sign, convertToInt(scale));
  };
  protoOf(DecimalDivision581).nu = function (candidate, scale, integer) {
    var tmp0 = candidate.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = integer.length;
    var tmp$ret$0 = Math.max(tmp0, b);
    var scratch = new Cells(tmp$ret$0);
    var tmp;
    // Inline function 'kotlin.collections.isEmpty' call
    if (candidate.length === 0) {
      tmp = null;
    } else {
      tmp = decimalChunks(this, candidate, scratch);
    }
    var coefficient = tmp;
    var tmp0_elvis_lhs = integerView583(this, coefficient, scale);
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      return false;
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    var expected = tmp_0;
    // Inline function 'kotlin.collections.isEmpty' call
    if (integer.length === 0)
      return equalsLong(expected.mw_1, new Long(0, 0));
    var actual = decimalChunks(this, integer, scratch);
    if (!equalsLong(actual.sw(), expected.mw_1))
      return false;
    var position = new Long(0, 0);
    while (compare(position, expected.mw_1) < 0) {
      if (!(actual.qw(position, expected.mw_1) === expected.pw(position)))
        return false;
      var _unary__edvuaz = position;
      position = add(_unary__edvuaz, get_ONE());
    }
    return true;
  };
  protoOf(DecimalDivision581).mu = function (sign, left, right, candidate, preferred, divisorScale, quotientScale) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(sign === -1 || sign === 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    var tmp_0;
    var tmp_1;
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(left.length === 0)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      // Inline function 'kotlin.collections.isEmpty' call
      tmp_1 = !(right.length === 0);
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = preferred < 0;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = quotientScale <= 0;
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    var tmp_2;
    // Inline function 'kotlin.collections.isEmpty' call
    if (candidate.length === 0) {
      tmp_2 = !(quotientScale === preferred);
    } else {
      tmp_2 = false;
    }
    if (tmp_2)
      return null;
    var tmp0 = left.length;
    var tmp2 = right.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var c = candidate.length;
    var tmp$ret$11 = Math.max(tmp0, tmp2, c);
    var scratch = new Cells(tmp$ret$11);
    var a = decimalChunks(this, left, scratch);
    var b = decimalChunks(this, right, scratch);
    var tmp_3;
    // Inline function 'kotlin.collections.isEmpty' call
    if (candidate.length === 0) {
      tmp_3 = null;
    } else {
      tmp_3 = decimalChunks(this, candidate, scratch);
    }
    var q = tmp_3;
    var tmp0_elvis_lhs = integerView583(this, q, quotientScale);
    var tmp_4;
    if (tmp0_elvis_lhs == null) {
      return null;
    } else {
      tmp_4 = tmp0_elvis_lhs;
    }
    var expected = tmp_4;
    var inputDigits = a.sw();
    var lastNonzero = subtract(inputDigits, a.tw());
    var limit = subtract(inputDigits, fromInt(preferred));
    var remainder = new DecimalWords(b.iw_1 + 1 | 0);
    var trial = new DecimalWords(b.iw_1 + 1 | 0);
    var position = new Long(0, 0);
    var emitted = new Long(0, 0);
    var started = false;
    $l$loop_0: while (compare(position, limit) < 0) {
      var input = compare(position, inputDigits) < 0 ? a.qw(position, inputDigits) : 0;
      var _unary__edvuaz = position;
      position = add(_unary__edvuaz, get_ONE());
      remainder.xr(10, input);
      var digit = 9;
      $l$loop: while (digit > 0) {
        trial.zw(b, digit);
        if (remainder.ax(trial) >= 0)
          break $l$loop;
        digit = digit - 1 | 0;
      }
      if (!(digit === 0)) {
        remainder.bx(trial);
      }
      if (!(digit === 0))
        started = true;
      if (started) {
        if (compare(emitted, expected.mw_1) >= 0 || !(digit === expected.pw(emitted)))
          return null;
        var _unary__edvuaz_0 = emitted;
        emitted = add(_unary__edvuaz_0, get_ONE());
      }
      if (remainder.iw_1 === 0 && compare(position, lastNonzero) >= 0) {
        var remaining = subtract(limit, position);
        if (started) {
          if (!equalsLong(add(emitted, remaining), expected.mw_1) || !expected.rw(emitted))
            return null;
          emitted = add(emitted, remaining);
        } else if (!equalsLong(expected.mw_1, new Long(0, 0)))
          return null;
        break $l$loop_0;
      }
    }
    if (!equalsLong(emitted, expected.mw_1))
      return null;
    var tmp0_0 = negate(fromInt(preferred));
    // Inline function 'kotlin.comparisons.minOf' call
    var b_0 = negate(fromInt(quotientScale));
    var removed = compare(tmp0_0, b_0) <= 0 ? tmp0_0 : b_0;
    var scale = subtract(fromInt(divisorScale), removed);
    // Inline function 'kotlin.check' call
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    if (remainder.iw_1 === 0)
      return to(Companion_getInstance_1().yj_1, convertToInt(scale));
    remainder.ex(removed);
    return publish(this, remainder, sign, convertToInt(scale));
  };
  var DecimalDivision581_instance;
  function DecimalDivision581_getInstance() {
    if (DecimalDivision581_instance == null)
      new DecimalDivision581();
    return DecimalDivision581_instance;
  }
  function materializedDecimalDivision581(leftBits, rightBits, precision, preferred, target, shift) {
    if (leftBits <= 0 || rightBits <= 0 || precision <= 0 || !(compare(new Long(-2147483648, -1), preferred) <= 0 ? compare(preferred, new Long(2147483647, 0)) <= 0 : false) || !(compare(new Long(-2147483648, -1), target) <= 0 ? compare(target, new Long(2147483647, 0)) <= 0 : false) || equalsLong(target, new Long(-2147483648, -1)) || !(compare(new Long(-646456992, -1), shift) <= 0 ? compare(shift, new Long(646456992, 0)) <= 0 : false))
      return false;
    var numeratorBits = add(fromInt(leftBits), compare(shift, new Long(0, 0)) > 0 ? multiply(new Long(4, 0), shift) : new Long(0, 0));
    var denominatorBits = add(fromInt(rightBits), compare(shift, new Long(0, 0)) < 0 ? multiply(new Long(-4, -1), shift) : new Long(0, 0));
    var tmp;
    if (compare(numeratorBits, new Long(2147483647, 0)) <= 0 && compare(denominatorBits, new Long(2147483647, 0)) <= 0) {
      // Inline function 'kotlin.Long.times' call
      var this_0 = new Long(4, 0);
      // Inline function 'kotlin.Long.plus' call
      var this_1 = multiply(this_0, fromInt(precision));
      var tmp$ret$1 = add(this_1, fromInt(rightBits));
      tmp = compare(tmp$ret$1, new Long(2147483647, 0)) <= 0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function materializedDecimalResidual583(sourceBits, divisorBits, quotientBits, sourceScale, divisorScale, quotientScale) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(quotientScale);
    var productScale = add(this_0, fromInt(divisorScale));
    if (!(compare(new Long(-2147483648, -1), productScale) <= 0 ? compare(productScale, new Long(2147483647, 0)) <= 0 : false))
      return false;
    // Inline function 'kotlin.comparisons.maxOf' call
    var a = fromInt(sourceScale);
    var scale = compare(a, productScale) >= 0 ? a : productScale;
    // Inline function 'kotlin.Long.minus' call
    var sourceRaise = subtract(scale, fromInt(sourceScale));
    var productRaise = subtract(scale, productScale);
    if (!(compare(new Long(0, 0), sourceRaise) <= 0 ? compare(sourceRaise, new Long(646456992, 0)) <= 0 : false) || !(compare(new Long(0, 0), productRaise) <= 0 ? compare(productRaise, new Long(646456992, 0)) <= 0 : false))
      return false;
    var tmp;
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$3 = Math.max(sourceBits, 1);
    if (compare(add(fromInt(tmp$ret$3), multiply(new Long(4, 0), sourceRaise)), new Long(2147483646, 0)) <= 0) {
      // Inline function 'kotlin.comparisons.maxOf' call
      var tmp$ret$4 = Math.max(quotientBits, 1);
      var tmp0 = fromInt(tmp$ret$4);
      // Inline function 'kotlin.comparisons.maxOf' call
      // Inline function 'kotlin.Long.plus' call
      var other = Math.max(divisorBits, 1);
      var tmp$ret$6 = add(tmp0, fromInt(other));
      tmp = compare(add(tmp$ret$6, multiply(new Long(4, 0), productRaise)), new Long(2147483646, 0)) <= 0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function numericallyEquals(_this__u8e3s4, other) {
    return toDecimalKey(_this__u8e3s4).equals(toDecimalKey(other));
  }
  function DecimalKey(value) {
    var snapshot = BigDecimal_init_$Create$_0(value.un(), value.vn());
    this.fx_1 = snapshot.ui();
    if (this.fx_1 === 0) {
      this.gx_1 = '0';
      this.hx_1 = new Long(0, 0);
    } else {
      var text = removePrefix(snapshot.un().toString(), '-');
      var end = text.length;
      while (charCodeAt(text, end - 1 | 0) === _Char___init__impl__6a9atx(48)) {
        end = end - 1 | 0;
      }
      this.gx_1 = substring_0(text, 0, end);
      var tmp = this;
      var tmp0 = fromInt(snapshot.vn());
      // Inline function 'kotlin.Long.minus' call
      var other = text.length - end | 0;
      tmp.hx_1 = subtract(tmp0, fromInt(other));
    }
    this.ix_1 = imul(31, imul(31, this.fx_1) + getStringHashCode(this.gx_1) | 0) + this.hx_1.hashCode() | 0;
  }
  protoOf(DecimalKey).equals = function (other) {
    var tmp;
    var tmp_0;
    var tmp_1;
    if (other instanceof DecimalKey) {
      tmp_1 = this.fx_1 === other.fx_1;
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = equalsLong(this.hx_1, other.hx_1);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.gx_1 === other.gx_1;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(DecimalKey).hashCode = function () {
    return this.ix_1;
  };
  protoOf(DecimalKey).jx = function (other) {
    if (!(this.fx_1 === other.fx_1))
      return compareTo(this.fx_1, other.fx_1);
    if (this.fx_1 === 0)
      return 0;
    var exponentOrder = subtract(fromInt(this.gx_1.length), this.hx_1).t2(subtract(fromInt(other.gx_1.length), other.hx_1));
    if (!(exponentOrder === 0))
      return imul(this.fx_1, exponentOrder);
    var inductionVariable = 0;
    var tmp0 = this.gx_1.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = other.gx_1.length;
    var last = Math.max(tmp0, b);
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var left = index < this.gx_1.length ? charCodeAt(this.gx_1, index) : _Char___init__impl__6a9atx(48);
        var right = index < other.gx_1.length ? charCodeAt(other.gx_1, index) : _Char___init__impl__6a9atx(48);
        if (!(left === right))
          return imul(this.fx_1, Char__compareTo_impl_ypi4mb(left, right));
      }
       while (inductionVariable < last);
    return 0;
  };
  protoOf(DecimalKey).d = function (other) {
    return this.jx(other instanceof DecimalKey ? other : THROW_CCE());
  };
  protoOf(DecimalKey).toString = function () {
    return (this.fx_1 < 0 ? '-' : '') + this.gx_1 + 'E' + negate(this.hx_1).toString();
  };
  function toDecimalKey(_this__u8e3s4) {
    return new DecimalKey(_this__u8e3s4);
  }
  function Companion_2() {
  }
  protoOf(Companion_2).kx = function () {
    // Inline function 'kotlin.also' call
    var this_0 = new Words(2);
    this_0.xw(1);
    return this_0;
  };
  var Companion_instance_3;
  function Companion_getInstance_2() {
    return Companion_instance_3;
  }
  function State(sign, core, zeros, scale) {
    this.ox_1 = sign;
    this.px_1 = core;
    this.qx_1 = zeros;
    this.rx_1 = scale;
  }
  protoOf(State).sw = function () {
    return add(this.px_1.sw(), this.qx_1);
  };
  function multiply_1($this, left, right, precision, mode) {
    var tmp0 = fromInt(left.rx_1);
    // Inline function 'kotlin.Long.plus' call
    var other = right.rx_1;
    var scale = add(tmp0, fromInt(other));
    if (compare(scale, new Long(-2147483648, -1)) < 0) {
      checkedScale_1($this, scale);
    }
    var a = left.px_1;
    var b = right.px_1;
    var tmp0_0 = fromInt(a.nx_1);
    // Inline function 'kotlin.Long.plus' call
    var other_0 = b.nx_1;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = add(tmp0_0, fromInt(other_0));
    var tmp$ret$2 = add(this_0, fromInt(1));
    var product = new Words(cellCount($this, tmp$ret$2));
    product.sx(a.nx_1 + b.nx_1 | 0);
    var inductionVariable = 0;
    var last = a.nx_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        var last_0 = b.nx_1;
        if (inductionVariable_0 < last_0)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp0_1 = fromInt(a.y(i));
            // Inline function 'kotlin.Long.times' call
            var other_1 = b.y(j);
            var tmp0_2 = multiply(tmp0_1, fromInt(other_1));
            // Inline function 'kotlin.Long.plus' call
            var other_2 = product.y(i + j | 0);
            var tmp$ret$4 = add(tmp0_2, fromInt(other_2));
            var part = add(tmp$ret$4, carry);
            var tmp = i + j | 0;
            // Inline function 'kotlin.Long.rem' call
            var other_3 = 1000000000;
            var tmp$ret$5 = modulo(part, fromInt(other_3));
            product.ww(tmp, convertToInt(tmp$ret$5));
            // Inline function 'kotlin.Long.div' call
            var other_4 = 1000000000;
            carry = divide(part, fromInt(other_4));
          }
           while (inductionVariable_0 < last_0);
        product.ww(i + b.nx_1 | 0, convertToInt(carry));
      }
       while (inductionVariable < last);
    product.tx();
    return roundOwned($this, imul(left.ox_1, right.ox_1), product, add(left.qx_1, right.qx_1), scale, precision, mode);
  }
  function roundOwned($this, sign, core, zeroTail, scale, precision, mode) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(new Long(1, 0), precision) <= 0 ? compare(precision, new Long(-2147483639, 0)) <= 0 : false)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var initialTail = core.tw();
    if (!equalsLong(initialTail, new Long(0, 0))) {
      core.ux(initialTail);
    }
    var zeros = add(zeroTail, initialTail);
    var tmp0 = subtract(add(core.sw(), zeros), precision);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = new Long(0, 0);
    var drop = compare(tmp0, b) >= 0 ? tmp0 : b;
    if (compare(drop, zeros) <= 0) {
      zeros = subtract(zeros, drop);
    } else {
      var coreDrop = subtract(drop, zeros);
      // Inline function 'kotlin.Long.minus' call
      var tmp$ret$4 = subtract(coreDrop, fromInt(1));
      var guard = core.pw(tmp$ret$4);
      // Inline function 'kotlin.Long.minus' call
      var tmp$ret$5 = subtract(coreDrop, fromInt(1));
      var sticky = core.vx(tmp$ret$5);
      core.ux(coreDrop);
      zeros = new Long(0, 0);
      var inexact = !(guard === 0) || sticky;
      var half = guard === 5 && sticky ? 1 : compareTo(guard, 5);
      if (inexact && increment_1($this, mode, sign, half, core.yw())) {
        core.cx();
        if (compare(core.sw(), precision) > 0) {
          // Inline function 'kotlin.check' call
          if (!(core.wx(10) === 0)) {
            throw IllegalStateException_init_$Create$('Check failed.');
          }
          var _unary__edvuaz = drop;
          drop = add(_unary__edvuaz, get_ONE());
        }
      }
    }
    return commit($this, sign, core, zeros, subtract(scale, drop));
  }
  function exactReciprocal($this, value) {
    var remaining = value.px_1.dw();
    var factor;
    var chunk;
    var chunkPower;
    var reciprocalBase;
    if ((remaining.y(0) % 2 | 0) === 0) {
      factor = 2;
      chunk = 536870912;
      chunkPower = 29;
      reciprocalBase = 5;
    } else if ((remaining.y(0) % 5 | 0) === 0) {
      factor = 5;
      chunk = 244140625;
      chunkPower = 12;
      reciprocalBase = 2;
    } else
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    var count = new Long(0, 0);
    while (remaining.xx(chunk) === 0) {
      // Inline function 'kotlin.check' call
      if (!(remaining.wx(chunk) === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var tmp0 = count;
      // Inline function 'kotlin.Long.plus' call
      var other = chunkPower;
      count = add(tmp0, fromInt(other));
      if (compare(count, new Long(2147483647, 0)) >= 0)
        throw ArithmeticException_init_$Create$('BigInteger overflow');
    }
    while (remaining.xx(factor) === 0) {
      // Inline function 'kotlin.check' call
      if (!(remaining.wx(factor) === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var _unary__edvuaz = count;
      count = add(_unary__edvuaz, get_ONE());
      if (compare(count, new Long(2147483647, 0)) >= 0)
        throw ArithmeticException_init_$Create$('BigInteger overflow');
    }
    if (!remaining.yx())
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    var tmp0_0 = add(value.qx_1, count);
    // Inline function 'kotlin.Long.minus' call
    var other_0 = value.rx_1;
    var tmp$ret$3 = subtract(tmp0_0, fromInt(other_0));
    var scale = checkedScale_1($this, tmp$ret$3);
    var coefficient = Companion_getInstance_1().fk(fromInt(reciprocalBase)).gk(convertToInt(count));
    var natural = ensureNotNull(coefficient.fp(scale));
    return new State(value.ox_1, natural.px_1, natural.qx_1, natural.rx_1);
  }
  function commit($this, sign, core, zeroTail, scale) {
    // Inline function 'kotlin.check' call
    if (!(core.nx_1 > 0 && (sign === -1 || sign === 1))) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tail = core.tw();
    if (!equalsLong(tail, new Long(0, 0))) {
      core.ux(tail);
    }
    return new State(sign, core, add(zeroTail, tail), checkedScale_1($this, scale));
  }
  function checkedScale_1($this, scale) {
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false))
      throw ArithmeticException_init_$Create$(compare(scale, new Long(0, 0)) < 0 ? 'Overflow' : 'Underflow');
    return convertToInt(scale);
  }
  function cellCount($this, count) {
    // Inline function 'kotlin.check' call
    if (!(compare(new Long(1, 0), count) <= 0 ? compare(count, new Long(477218593, 0)) <= 0 : false)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return convertToInt(count);
  }
  function increment_1($this, mode, sign, half, odd) {
    var tmp;
    switch (mode.l2_1) {
      case 0:
        tmp = true;
        break;
      case 1:
        tmp = false;
        break;
      case 2:
        tmp = sign > 0;
        break;
      case 3:
        tmp = sign < 0;
        break;
      case 4:
        tmp = half >= 0;
        break;
      case 5:
        tmp = half > 0;
        break;
      case 6:
        tmp = half > 0 || (half === 0 && odd);
        break;
      case 7:
        throw ArithmeticException_init_$Create$('Rounding necessary');
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function Pages(capacity) {
    this.zx_1 = capacity;
    var tmp = this;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(this.zx_1);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(8192));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = divide(this_2, fromInt(8192));
    // Inline function 'kotlin.arrayOfNulls' call
    var size = convertToInt(tmp$ret$2);
    tmp.ay_1 = Array(size);
  }
  protoOf(Pages).y = function (index) {
    // Inline function 'kotlin.check' call
    if (!(0 <= index ? index < this.zx_1 : false)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tmp0_safe_receiver = this.ay_1[index / 8192 | 0];
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver[index % 8192 | 0];
    return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  };
  protoOf(Pages).ww = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(0 <= index ? index < this.zx_1 : false)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var slot = index / 8192 | 0;
    var tmp0_elvis_lhs = this.ay_1[slot];
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.run' call
      // Inline function 'kotlin.Long.times' call
      var this_0 = fromInt(slot);
      var start = multiply(this_0, fromInt(8192));
      var tmp0 = new Long(8192, 0);
      // Inline function 'kotlin.comparisons.minOf' call
      var b = subtract(fromInt(this.zx_1), start);
      var tmp$ret$4 = compare(tmp0, b) <= 0 ? tmp0 : b;
      // Inline function 'kotlin.also' call
      var this_1 = new Int32Array(convertToInt(tmp$ret$4));
      this.ay_1[slot] = this_1;
      tmp = this_1;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var page = tmp;
    page[index % 8192 | 0] = value;
  };
  function Words(capacity) {
    this.lx_1 = capacity;
    this.mx_1 = new Pages(this.lx_1);
    this.nx_1 = 0;
  }
  protoOf(Words).y = function (index) {
    return this.mx_1.y(index);
  };
  protoOf(Words).ww = function (index, value) {
    this.mx_1.ww(index, value);
  };
  protoOf(Words).sx = function (length) {
    // Inline function 'kotlin.check' call
    if (!(this.nx_1 === 0 && length <= this.lx_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    this.nx_1 = length;
  };
  protoOf(Words).xw = function (value) {
    var _unary__edvuaz = this.nx_1;
    this.nx_1 = _unary__edvuaz + 1 | 0;
    this.mx_1.ww(_unary__edvuaz, value);
  };
  protoOf(Words).tx = function () {
    while (this.nx_1 > 0 && this.mx_1.y(this.nx_1 - 1 | 0) === 0) {
      this.nx_1 = this.nx_1 - 1 | 0;
    }
  };
  protoOf(Words).yx = function () {
    return this.nx_1 === 1 && this.mx_1.y(0) === 1;
  };
  protoOf(Words).yw = function () {
    return !(this.nx_1 === 0) && !((this.mx_1.y(0) % 2 | 0) === 0);
  };
  protoOf(Words).sw = function () {
    // Inline function 'kotlin.check' call
    if (!(this.nx_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var width = 1;
    var top = this.mx_1.y(this.nx_1 - 1 | 0);
    while (width < 9 && top >= DecimalPower593_getInstance().lp_1[width]) {
      width = width + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.nx_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = width;
    return add(tmp0_0, fromInt(other_0));
  };
  protoOf(Words).dw = function () {
    var tmp = DecimalPower593_getInstance();
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(this.nx_1);
    var tmp$ret$0 = add(this_0, fromInt(1));
    var result = new Words(cellCount(tmp, tmp$ret$0));
    var inductionVariable = 0;
    var last = this.nx_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        result.xw(this.mx_1.y(i));
      }
       while (inductionVariable < last);
    return result;
  };
  protoOf(Words).tw = function () {
    // Inline function 'kotlin.check' call
    if (!(this.nx_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var whole = 0;
    while (this.mx_1.y(whole) === 0) {
      whole = whole + 1 | 0;
    }
    var low = this.mx_1.y(whole);
    var extra = 0;
    while ((low % 10 | 0) === 0) {
      low = low / 10 | 0;
      extra = extra + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = whole;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = extra;
    return add(tmp0_0, fromInt(other_0));
  };
  protoOf(Words).pw = function (position) {
    // Inline function 'kotlin.check' call
    if (!(compare(position, new Long(0, 0)) >= 0 && compare(position, this.sw()) < 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(position, fromInt(9));
    var tmp = this.mx_1.y(convertToInt(tmp$ret$1));
    var tmp_0 = DecimalPower593_getInstance().lp_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(position, fromInt(9));
    return (tmp / tmp_0[convertToInt(tmp$ret$2)] | 0) % 10 | 0;
  };
  protoOf(Words).vx = function (count) {
    // Inline function 'kotlin.check' call
    if (!(compare(count, new Long(0, 0)) >= 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(count, fromInt(9));
    var whole = convertToInt(tmp$ret$1);
    var inductionVariable = 0;
    if (inductionVariable < whole)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(this.mx_1.y(i) === 0))
          return true;
      }
       while (inductionVariable < whole);
    var tmp;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(count, fromInt(9));
    if (!equalsLong(tmp$ret$2, new Long(0, 0))) {
      var tmp_0 = this.mx_1.y(whole);
      var tmp_1 = DecimalPower593_getInstance().lp_1;
      // Inline function 'kotlin.Long.rem' call
      var tmp$ret$3 = modulo(count, fromInt(9));
      tmp = !((tmp_0 % tmp_1[convertToInt(tmp$ret$3)] | 0) === 0);
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(Words).ux = function (count) {
    // Inline function 'kotlin.check' call
    if (!(compare(count, new Long(0, 0)) >= 0 && compare(count, this.sw()) < 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(count, fromInt(9));
    var whole = convertToInt(tmp$ret$1);
    var length = this.nx_1 - whole | 0;
    var inductionVariable = 0;
    if (inductionVariable < length)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.mx_1.ww(i, this.mx_1.y(i + whole | 0));
      }
       while (inductionVariable < length);
    this.nx_1 = length;
    var tmp = DecimalPower593_getInstance().lp_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(count, fromInt(9));
    var divisor = tmp[convertToInt(tmp$ret$2)];
    if (!(divisor === 1))
      this.wx(divisor);
    else {
      this.tx();
    }
  };
  protoOf(Words).wx = function (divisor) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(1 <= divisor ? divisor < 1000000000 : false)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var remainder = new Long(0, 0);
    var inductionVariable = this.nx_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.mx_1.y(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$5 = divide(part, fromInt(divisor));
        this.mx_1.ww(i, convertToInt(tmp$ret$5));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(divisor));
      }
       while (0 <= inductionVariable);
    this.tx();
    return convertToInt(remainder);
  };
  protoOf(Words).xx = function (divisor) {
    var remainder = new Long(0, 0);
    var inductionVariable = this.nx_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.mx_1.y(i);
        // Inline function 'kotlin.Long.rem' call
        var this_0 = add(tmp0_0, fromInt(other_0));
        remainder = modulo(this_0, fromInt(divisor));
      }
       while (0 <= inductionVariable);
    return convertToInt(remainder);
  };
  protoOf(Words).xr = function (multiplier, addition) {
    var carry = fromInt(addition);
    var inductionVariable = 0;
    var last = this.nx_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(this.mx_1.y(i));
        var tmp$ret$0 = multiply(this_0, fromInt(multiplier));
        var part = add(tmp$ret$0, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$1 = modulo(part, fromInt(other));
        this.mx_1.ww(i, convertToInt(tmp$ret$1));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < last);
    if (!equalsLong(carry, new Long(0, 0))) {
      this.xw(convertToInt(carry));
    }
  };
  protoOf(Words).by = function (source, multiplier) {
    this.nx_1 = 0;
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = source.nx_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(source.y(i));
        var tmp$ret$0 = multiply(this_0, fromInt(multiplier));
        var part = add(tmp$ret$0, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$1 = modulo(part, fromInt(other));
        this.xw(convertToInt(tmp$ret$1));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < last);
    if (!equalsLong(carry, new Long(0, 0))) {
      this.xw(convertToInt(carry));
    }
    this.tx();
  };
  protoOf(Words).cy = function (other) {
    if (!(this.nx_1 === other.nx_1))
      return compareTo(this.nx_1, other.nx_1);
    var inductionVariable = this.nx_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        if (!(this.mx_1.y(i) === other.y(i)))
          return compareTo(this.mx_1.y(i), other.y(i));
      }
       while (0 <= inductionVariable);
    return 0;
  };
  protoOf(Words).dy = function (other) {
    var borrow = new Long(0, 0);
    var inductionVariable = 0;
    var last = this.nx_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = fromInt(this.mx_1.y(i));
        // Inline function 'kotlin.Long.minus' call
        var other_0 = i < other.nx_1 ? other.y(i) : 0;
        var tmp$ret$0 = subtract(tmp0, fromInt(other_0));
        var part = subtract(tmp$ret$0, borrow);
        if (compare(part, new Long(0, 0)) < 0) {
          var tmp0_0 = part;
          // Inline function 'kotlin.Long.plus' call
          var other_1 = 1000000000;
          part = add(tmp0_0, fromInt(other_1));
          borrow = new Long(1, 0);
        } else
          borrow = new Long(0, 0);
        this.mx_1.ww(i, convertToInt(part));
      }
       while (inductionVariable < last);
    // Inline function 'kotlin.check' call
    if (!equalsLong(borrow, new Long(0, 0))) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    this.tx();
  };
  protoOf(Words).cx = function () {
    var i = 0;
    while (i < this.nx_1 && this.mx_1.y(i) === 999999999) {
      this.mx_1.ww(i, 0);
      i = i + 1 | 0;
    }
    if (i === this.nx_1) {
      this.xw(1);
    } else {
      this.mx_1.ww(i, this.mx_1.y(i) + 1 | 0);
    }
  };
  protoOf(Words).ey = function (exponent) {
    // Inline function 'kotlin.check' call
    if (!(this.nx_1 === 0 && compare(exponent, new Long(0, 0)) >= 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(exponent, fromInt(9));
    var at = convertToInt(tmp$ret$1);
    var tmp = DecimalPower593_getInstance().lp_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(exponent, fromInt(9));
    this.mx_1.ww(at, tmp[convertToInt(tmp$ret$2)]);
    this.nx_1 = at + 1 | 0;
  };
  function reciprocal$nextDigit(remainder, trial, denominator) {
    remainder.xr(10, 0);
    var digit = 9;
    $l$loop: while (digit > 0) {
      trial.by(denominator, digit);
      if (remainder.cy(trial) >= 0)
        break $l$loop;
      digit = digit - 1 | 0;
    }
    if (!(digit === 0)) {
      remainder.dy(trial);
    }
    return digit;
  }
  function DecimalPower593() {
    DecimalPower593_instance = this;
    this.gp_1 = 1000000000;
    this.hp_1 = 8192;
    this.ip_1 = new Long(646456993, 0);
    this.jp_1 = new Long(-2147483639, 0);
    this.kp_1 = new Long(477218593, 0);
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.lp_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalPower593).pu = function (sign, words, scale) {
    var tmp;
    var tmp_0;
    switch (sign) {
      case -1:
      case 1:
        // Inline function 'kotlin.collections.isNotEmpty' call

        // Inline function 'kotlin.collections.isEmpty' call

        tmp_0 = !(words.length === 0);
        break;
      default:
        tmp_0 = false;
        break;
    }
    if (tmp_0) {
      tmp = last(words) > 0;
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var scratch = words.slice();
    var size = scratch.length;
    var tmp0 = new Long(646456993, 0);
    var tmp0_0 = new Long(10, 0);
    // Inline function 'kotlin.Long.times' call
    var other = size;
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(tmp0_0, fromInt(other));
    var bound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bound, fromInt(8));
    var tmp$ret$10 = divide(this_0, fromInt(9));
    var decimal = new Words(cellCount(this, tmp$ret$10));
    while (!(size === 0)) {
      var remainder = new Long(0, 0);
      var inductionVariable = size - 1 | 0;
      if (0 <= inductionVariable)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + -1 | 0;
          var tmp0_1 = shiftLeft(remainder, 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = scratch[i];
          var part = add(tmp0_1, fromInt(other_0));
          // Inline function 'kotlin.Long.div' call
          var other_1 = 1000000000;
          var tmp$ret$12 = divide(part, fromInt(other_1));
          scratch[i] = convertToInt(tmp$ret$12);
          // Inline function 'kotlin.Long.rem' call
          var other_2 = 1000000000;
          remainder = modulo(part, fromInt(other_2));
        }
         while (0 <= inductionVariable);
      decimal.xw(convertToInt(remainder));
      while (!(size === 0) && scratch[size - 1 | 0] === 0) {
        size = size - 1 | 0;
      }
    }
    return commit(this, sign, decimal, new Long(0, 0), fromInt(scale));
  };
  protoOf(DecimalPower593).mp = function (base, exponent, precision, mode) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!((1 <= exponent ? exponent <= 999999999 : false) && (compare(new Long(1, 0), precision) <= 0 ? compare(precision, new Long(-2147483639, 0)) <= 0 : false))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var result = commit(this, 1, Companion_instance_3.kx(), new Long(0, 0), new Long(0, 0));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var bits = 32 - clz32(exponent) | 0;
    var inductionVariable = bits - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var bit = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        result = multiply_1(this, result, result, precision, mode);
        if (!((exponent & 1 << bit) === 0))
          result = multiply_1(this, result, base, precision, mode);
      }
       while (0 <= inductionVariable);
    return result;
  };
  protoOf(DecimalPower593).op = function (value, precision, mode) {
    return roundOwned(this, value.ox_1, value.px_1.dw(), value.qx_1, fromInt(value.rx_1), precision, mode);
  };
  protoOf(DecimalPower593).np = function (value, precision, destinationPrecision, mode) {
    var tmp;
    if (destinationPrecision > 0 && compare(precision, new Long(-2147483639, 0)) <= 0) {
      var containsArg = subtract(precision, fromInt(destinationPrecision));
      tmp = compare(new Long(2, 0), containsArg) <= 0 ? compare(containsArg, new Long(10, 0)) <= 0 : false;
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (value.px_1.yx()) {
      var tmp_0 = Companion_instance_3.kx();
      var tmp_1 = new Long(0, 0);
      var tmp0 = value.qx_1;
      // Inline function 'kotlin.Long.minus' call
      var other = value.rx_1;
      var tmp$ret$3 = subtract(tmp0, fromInt(other));
      return commit(this, value.ox_1, tmp_0, tmp_1, tmp$ret$3);
    }
    if (compare(fromInt(destinationPrecision), new Long(646456993, 0)) > 0)
      return exactReciprocal(this, value);
    var denominator = value.px_1;
    var digits = denominator.sw();
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(denominator.nx_1);
    var tmp$ret$4 = add(this_0, fromInt(1));
    var remainder = new Words(cellCount(this, tmp$ret$4));
    // Inline function 'kotlin.Long.minus' call
    var tmp$ret$5 = subtract(digits, fromInt(1));
    remainder.ey(tmp$ret$5);
    // Inline function 'kotlin.Long.plus' call
    var this_1 = fromInt(denominator.nx_1);
    var tmp$ret$6 = add(this_1, fromInt(1));
    var trial = new Words(cellCount(this, tmp$ret$6));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.plus' call
    var this_2 = add(precision, fromInt(1));
    // Inline function 'kotlin.Long.div' call
    var this_3 = add(this_2, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_4 = divide(this_3, fromInt(9));
    var tmp$ret$10 = add(this_4, fromInt(1));
    var quotient = new Words(cellCount(this, tmp$ret$10));
    var kept = new Long(0, 0);
    while (compare(kept, precision) < 0) {
      quotient.xr(10, reciprocal$nextDigit(remainder, trial, denominator));
      var _unary__edvuaz = kept;
      kept = add(_unary__edvuaz, get_ONE());
      if (remainder.nx_1 === 0) {
        // Inline function 'kotlin.Long.minus' call
        var this_5 = add(negate(fromInt(value.rx_1)), kept);
        var tmp$ret$11 = subtract(this_5, fromInt(1));
        var scale = add(add(tmp$ret$11, digits), value.qx_1);
        return commit(this, value.ox_1, quotient, new Long(0, 0), scale);
      }
    }
    var guard = reciprocal$nextDigit(remainder, trial, denominator);
    var sticky = !(remainder.nx_1 === 0);
    var half = guard === 5 && sticky ? 1 : compareTo(guard, 5);
    if ((!(guard === 0) || sticky) && increment_1(this, mode, value.ox_1, half, quotient.yw())) {
      quotient.cx();
    }
    // Inline function 'kotlin.Long.minus' call
    var this_6 = add(negate(fromInt(value.rx_1)), precision);
    var tmp$ret$12 = subtract(this_6, fromInt(1));
    var scale_0 = add(add(tmp$ret$12, digits), value.qx_1);
    if (compare(quotient.sw(), precision) > 0) {
      // Inline function 'kotlin.check' call
      if (!(quotient.wx(10) === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var _unary__edvuaz_0 = scale_0;
      scale_0 = subtract(_unary__edvuaz_0, get_ONE());
    }
    return commit(this, value.ox_1, quotient, new Long(0, 0), scale_0);
  };
  protoOf(DecimalPower593).pp = function (value) {
    var digits = value.sw();
    if (compare(digits, new Long(646456993, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    // Inline function 'kotlin.Long.div' call
    var this_0 = value.qx_1;
    var whole = divide(this_0, fromInt(9));
    // Inline function 'kotlin.Long.rem' call
    var this_1 = value.qx_1;
    var tmp$ret$1 = modulo(this_1, fromInt(9));
    var offset = convertToInt(tmp$ret$1);
    var tmp;
    if (offset === 0) {
      tmp = value.px_1;
    } else {
      // Inline function 'kotlin.also' call
      var this_2 = value.px_1.dw();
      this_2.xr(DecimalPower593_getInstance().lp_1[offset], 0);
      tmp = this_2;
    }
    var decimal = tmp;
    var cells = add(fromInt(decimal.nx_1), whole);
    var tmp0 = new Long(2147483647, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(new Long(4, 0), digits);
    var bitBound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_3 = add(bitBound, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_4 = divide(this_3, fromInt(30));
    var tmp$ret$7 = add(this_4, fromInt(1));
    var binary = new Pages(cellCount(this, tmp$ret$7));
    var size = 0;
    var at = cells;
    while (!equalsLong(at, new Long(0, 0))) {
      var _unary__edvuaz = at;
      at = subtract(_unary__edvuaz, get_ONE());
      var carry = compare(at, whole) < 0 ? new Long(0, 0) : fromInt(decimal.y(convertToInt(subtract(at, whole))));
      var inductionVariable = 0;
      var last = size;
      if (inductionVariable < last)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var tmp0_0 = fromInt(binary.y(i));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$8 = multiply(tmp0_0, fromInt(other));
          var part = add(tmp$ret$8, carry);
          binary.ww(i, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
        }
         while (inductionVariable < last);
      if (!equalsLong(carry, new Long(0, 0))) {
        var _unary__edvuaz_0 = size;
        size = _unary__edvuaz_0 + 1 | 0;
        binary.ww(_unary__edvuaz_0, convertToInt(carry));
      }
      var tmp0_1 = new Long(30, 0);
      // Inline function 'kotlin.Long.times' call
      var other_0 = size - 1 | 0;
      // Inline function 'kotlin.Long.plus' call
      var this_5 = multiply(tmp0_1, fromInt(other_0));
      var tmp0_2 = add(this_5, fromInt(32));
      // Inline function 'kotlin.countLeadingZeroBits' call
      var this_6 = binary.y(size - 1 | 0);
      // Inline function 'kotlin.Long.minus' call
      var other_1 = clz32(this_6);
      var bits = subtract(tmp0_2, fromInt(other_1));
      if (compare(bits, new Long(2147483647, 0)) > 0)
        throw ArithmeticException_init_$Create$('BigInteger overflow');
    }
    var tmp0_3 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_7 = multiply(tmp0_3, fromInt(other_2));
    var tmp0_4 = add(this_7, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_8 = binary.y(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_8);
    var bits_0 = subtract(tmp0_4, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_9 = add(bits_0, fromInt(7));
    var tmp$ret$18 = divide(this_9, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$18));
    var inductionVariable_0 = 0;
    var last_0 = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last_0)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_10 = new Long(8, 0);
        var bit = multiply(this_10, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$20 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$20);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$21 = modulo(bit, fromInt(30));
        var shift = convertToInt(tmp$ret$21);
        var part_0 = shiftRightUnsigned(fromInt(binary.y(word)), shift);
        if (shift > 22 && (word + 1 | 0) < size)
          part_0 = bitwiseOr(part_0, shiftLeft(fromInt(binary.y(word + 1 | 0)), 30 - shift | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(part_0, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last_0);
    return to(BigInteger_init_$Create$_6(value.ox_1, bytes), value.rx_1);
  };
  var DecimalPower593_instance;
  function DecimalPower593_getInstance() {
    if (DecimalPower593_instance == null)
      new DecimalPower593();
    return DecimalPower593_instance;
  }
  function DecimalPowers597() {
    DecimalPowers597_instance = this;
    this.sk_1 = 128;
    var tmp = this;
    // Inline function 'kotlin.run' call
    var value = {_v: Companion_getInstance_1().zj_1};
    var tmp_0 = 0;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(129);
    while (tmp_0 < 129) {
      var tmp_2 = tmp_0;
      if (!(tmp_2 === 0)) {
        value._v = value._v.hk(Companion_getInstance_1().bk_1);
      }
      tmp_1[tmp_2] = value._v;
      tmp_0 = tmp_0 + 1 | 0;
    }
    tmp.tk_1 = tmp_1;
  }
  protoOf(DecimalPowers597).uk = function (exponent) {
    return (0 <= exponent ? exponent <= 128 : false) ? this.tk_1[exponent] : null;
  };
  var DecimalPowers597_instance;
  function DecimalPowers597_getInstance() {
    if (DecimalPowers597_instance == null)
      new DecimalPowers597();
    return DecimalPowers597_instance;
  }
  function increment_2($this, mode, sign, half, odd) {
    var tmp;
    switch (mode.l2_1) {
      case 0:
        tmp = true;
        break;
      case 1:
        tmp = false;
        break;
      case 2:
        tmp = sign > 0;
        break;
      case 3:
        tmp = sign < 0;
        break;
      case 4:
        tmp = half >= 0;
        break;
      case 5:
        tmp = half > 0;
        break;
      case 6:
        tmp = half > 0 || (half === 0 && odd);
        break;
      case 7:
        throw ArithmeticException_init_$Create$('Rounding necessary');
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function checkedScale_2($this, scale) {
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false))
      throw ArithmeticException_init_$Create$(compare(scale, new Long(0, 0)) < 0 ? 'Overflow' : 'Underflow');
    return convertToInt(scale);
  }
  function decimalChunks_0($this, words, scratch) {
    var inductionVariable = 0;
    var last = words.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        scratch.ww(i, words[i]);
      }
       while (inductionVariable <= last);
    var size = words.length;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = new Long(646456993, 0);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(8));
    var tmp$ret$1 = divide(this_1, fromInt(9));
    var chunks = new DecimalWords_0(convertToInt(tmp$ret$1));
    while (!(size === 0)) {
      var remainder = new Long(0, 0);
      var inductionVariable_0 = size - 1 | 0;
      if (0 <= inductionVariable_0)
        do {
          var i_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + -1 | 0;
          var tmp0 = shiftLeft(remainder, 30);
          // Inline function 'kotlin.Long.plus' call
          var other = scratch.y(i_0);
          var part = add(tmp0, fromInt(other));
          // Inline function 'kotlin.Long.div' call
          var other_0 = 1000000000;
          var tmp$ret$3 = divide(part, fromInt(other_0));
          scratch.ww(i_0, convertToInt(tmp$ret$3));
          // Inline function 'kotlin.Long.rem' call
          var other_1 = 1000000000;
          remainder = modulo(part, fromInt(other_1));
        }
         while (0 <= inductionVariable_0);
      chunks.xw(convertToInt(remainder));
      while (size > 0 && scratch.y(size - 1 | 0) === 0) {
        size = size - 1 | 0;
      }
    }
    // Inline function 'kotlin.check' call
    if (!(chunks.iy_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return chunks;
  }
  function binaryCoefficient($this, decimal, sign) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = new Long(2147483647, 0);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(30));
    var tmp$ret$2 = add(this_2, fromInt(1));
    var binary = new Cells_0(convertToInt(tmp$ret$2));
    var size = 0;
    var inductionVariable = decimal.iy_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var carry = fromInt(decimal.y(i));
        var j = 0;
        while (j < size) {
          var tmp0 = fromInt(binary.y(j));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$3 = multiply(tmp0, fromInt(other));
          var part = add(tmp$ret$3, carry);
          binary.ww(j, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
          j = j + 1 | 0;
        }
        if (!equalsLong(carry, new Long(0, 0))) {
          var _unary__edvuaz = size;
          size = _unary__edvuaz + 1 | 0;
          binary.ww(_unary__edvuaz, convertToInt(carry));
        }
        var tmp0_0 = new Long(30, 0);
        // Inline function 'kotlin.Long.times' call
        var other_0 = size - 1 | 0;
        // Inline function 'kotlin.Long.plus' call
        var this_3 = multiply(tmp0_0, fromInt(other_0));
        var tmp0_1 = add(this_3, fromInt(32));
        // Inline function 'kotlin.countLeadingZeroBits' call
        var this_4 = binary.y(size - 1 | 0);
        // Inline function 'kotlin.Long.minus' call
        var other_1 = clz32(this_4);
        var bits = subtract(tmp0_1, fromInt(other_1));
        if (compare(bits, new Long(2147483647, 0)) > 0)
          throw ArithmeticException_init_$Create$('BigInteger overflow');
      }
       while (0 <= inductionVariable);
    var tmp0_2 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_5 = multiply(tmp0_2, fromInt(other_2));
    var tmp0_3 = add(this_5, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_6 = binary.y(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_6);
    var bits_0 = subtract(tmp0_3, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_7 = add(bits_0, fromInt(7));
    var tmp$ret$13 = divide(this_7, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$13));
    var inductionVariable_0 = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_8 = new Long(8, 0);
        var bit = multiply(this_8, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$15 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$15);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$16 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$16);
        var value = shiftRightUnsigned(fromInt(binary.y(word)), offset);
        if (offset > 22 && (word + 1 | 0) < size)
          value = bitwiseOr(value, shiftLeft(fromInt(binary.y(word + 1 | 0)), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last);
    return BigInteger_init_$Create$_6(sign, bytes);
  }
  function Cells_0(limit) {
    this.fy_1 = limit;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.gy_1 = ArrayList_init_$Create$();
  }
  protoOf(Cells_0).y = function (index) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.fy_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var page = index / 8192 | 0;
    return page < this.gy_1.z() ? this.gy_1.y(page)[index % 8192 | 0] : 0;
  };
  protoOf(Cells_0).ww = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.fy_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var page = index / 8192 | 0;
    while (this.gy_1.z() <= page) {
      this.gy_1.w(new Int32Array(8192));
    }
    this.gy_1.y(page)[index % 8192 | 0] = value;
  };
  function DecimalWords_0(capacity) {
    this.hy_1 = new Cells_0(capacity);
    this.iy_1 = 0;
  }
  protoOf(DecimalWords_0).y = function (index) {
    return this.hy_1.y(index);
  };
  protoOf(DecimalWords_0).ww = function (index, value) {
    this.hy_1.ww(index, value);
  };
  protoOf(DecimalWords_0).sx = function (length) {
    // Inline function 'kotlin.check' call
    if (!(this.iy_1 === 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    this.iy_1 = length;
  };
  protoOf(DecimalWords_0).xw = function (value) {
    this.hy_1.ww(this.iy_1, value);
    this.iy_1 = this.iy_1 + 1 | 0;
  };
  protoOf(DecimalWords_0).tx = function () {
    while (this.iy_1 > 0 && this.hy_1.y(this.iy_1 - 1 | 0) === 0) {
      this.iy_1 = this.iy_1 - 1 | 0;
    }
  };
  protoOf(DecimalWords_0).sw = function () {
    // Inline function 'kotlin.check' call
    if (!(this.iy_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var topDigits = 1;
    var top = this.hy_1.y(this.iy_1 - 1 | 0);
    while (topDigits < 9 && top >= DecimalProduct580_getInstance().du_1[topDigits]) {
      topDigits = topDigits + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.iy_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = topDigits;
    var tmp$ret$2 = add(tmp0_0, fromInt(other_0));
    return convertToInt(tmp$ret$2);
  };
  protoOf(DecimalWords_0).jy = function (count) {
    var whole = count / 9 | 0;
    var length = this.iy_1 - whole | 0;
    var inductionVariable = 0;
    if (inductionVariable < length)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.hy_1.ww(i, this.hy_1.y(i + whole | 0));
      }
       while (inductionVariable < length);
    this.iy_1 = length;
    this.wx(DecimalProduct580_getInstance().du_1[count % 9 | 0]);
    this.tx();
  };
  protoOf(DecimalWords_0).wx = function (divisor) {
    var remainder = new Long(0, 0);
    var inductionVariable = this.iy_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.hy_1.y(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(divisor));
        this.hy_1.ww(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(divisor));
      }
       while (0 <= inductionVariable);
    this.tx();
    return convertToInt(remainder);
  };
  protoOf(DecimalWords_0).cx = function () {
    var i = 0;
    while (i < this.iy_1 && this.hy_1.y(i) === 999999999) {
      this.hy_1.ww(i, 0);
      i = i + 1 | 0;
    }
    if (i === this.iy_1) {
      this.xw(1);
    } else {
      this.hy_1.ww(i, this.hy_1.y(i) + 1 | 0);
    }
  };
  function DecimalProduct580() {
    DecimalProduct580_instance = this;
    this.bu_1 = 1000000000;
    this.cu_1 = 8192;
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.du_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalProduct580).eu = function (sign, left, right, scale, context) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(sign === -1 || sign === 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(left.length === 0)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      // Inline function 'kotlin.collections.isEmpty' call
      tmp = !(right.length === 0);
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    var precision = context.ol_1;
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(precision > 0)) {
      var message_1 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_1));
    }
    if (compare(scale, new Long(-2147483648, -1)) < 0) {
      checkedScale_2(this, scale);
    }
    var tmp0 = left.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = right.length;
    var tmp$ret$13 = Math.max(tmp0, b);
    var scratch = new Cells_0(tmp$ret$13);
    var a = decimalChunks_0(this, left, scratch);
    var b_0 = decimalChunks_0(this, right, scratch);
    var tmp0_0 = fromInt(a.iy_1);
    // Inline function 'kotlin.Long.plus' call
    var other = b_0.iy_1;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = add(tmp0_0, fromInt(other));
    var tmp$ret$15 = add(this_0, fromInt(1));
    var capacity = convertToInt(tmp$ret$15);
    var product = new DecimalWords_0(capacity);
    product.sx(capacity - 1 | 0);
    var inductionVariable = 0;
    var last = a.iy_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        var last_0 = b_0.iy_1;
        if (inductionVariable_0 < last_0)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var at = i + j | 0;
            var tmp0_1 = fromInt(a.y(i));
            // Inline function 'kotlin.Long.times' call
            var other_0 = b_0.y(j);
            var tmp0_2 = multiply(tmp0_1, fromInt(other_0));
            // Inline function 'kotlin.Long.plus' call
            var other_1 = product.y(at);
            var tmp$ret$17 = add(tmp0_2, fromInt(other_1));
            var part = add(tmp$ret$17, carry);
            // Inline function 'kotlin.Long.rem' call
            var other_2 = 1000000000;
            var tmp$ret$18 = modulo(part, fromInt(other_2));
            product.ww(at, convertToInt(tmp$ret$18));
            // Inline function 'kotlin.Long.div' call
            var other_3 = 1000000000;
            carry = divide(part, fromInt(other_3));
          }
           while (inductionVariable_0 < last_0);
        product.ww(i + b_0.iy_1 | 0, convertToInt(carry));
      }
       while (inductionVariable < last);
    product.tx();
    var digits = product.sw();
    if (compare(scale, new Long(2147483647, 0)) > 0 && digits <= precision) {
      checkedScale_2(this, scale);
    }
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(digits);
    var tmp0_3 = subtract(this_1, fromInt(precision));
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_1 = new Long(0, 0);
    var drop = compare(tmp0_3, b_1) >= 0 ? tmp0_3 : b_1;
    if (!equalsLong(drop, new Long(0, 0))) {
      // Inline function 'kotlin.Long.minus' call
      var this_2 = drop;
      var guardPosition = subtract(this_2, fromInt(1));
      // Inline function 'kotlin.Long.div' call
      var tmp$ret$23 = divide(guardPosition, fromInt(9));
      var guardCell = convertToInt(tmp$ret$23);
      // Inline function 'kotlin.Long.rem' call
      var tmp$ret$24 = modulo(guardPosition, fromInt(9));
      var offset = convertToInt(tmp$ret$24);
      var guard = (product.y(guardCell) / this.du_1[offset] | 0) % 10 | 0;
      var sticky = !((product.y(guardCell) % this.du_1[offset] | 0) === 0);
      var i_0 = 0;
      while (!sticky && i_0 < guardCell) {
        sticky = !(product.y(i_0) === 0);
        i_0 = i_0 + 1 | 0;
      }
      var inexact = !(guard === 0) || sticky;
      var tmp_0;
      if (guard === 5) {
        tmp_0 = sticky ? 1 : 0;
      } else {
        tmp_0 = compareTo(guard, 5);
      }
      var half = tmp_0;
      product.jy(convertToInt(drop));
      if (inexact && increment_2(this, context.pl_1, sign, half, !((product.y(0) % 2 | 0) === 0))) {
        product.cx();
        if (product.sw() > precision) {
          // Inline function 'kotlin.check' call
          if (!(product.wx(10) === 0)) {
            throw IllegalStateException_init_$Create$('Check failed.');
          }
          var _unary__edvuaz = drop;
          drop = add(_unary__edvuaz, get_ONE());
        }
      }
    }
    var finalScale = checkedScale_2(this, subtract(scale, drop));
    return to(binaryCoefficient(this, product, sign), finalScale);
  };
  var DecimalProduct580_instance;
  function DecimalProduct580_getInstance() {
    if (DecimalProduct580_instance == null)
      new DecimalProduct580();
    return DecimalProduct580_instance;
  }
  function needsRawDecimalProduct580(leftBits, rightBits) {
    var tmp;
    if (leftBits > 0 && rightBits > 0) {
      // Inline function 'kotlin.Long.plus' call
      var this_0 = fromInt(leftBits);
      var tmp$ret$0 = add(this_0, fromInt(rightBits));
      tmp = compare(tmp$ret$0, new Long(2147483647, 0)) > 0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function align($this, incomingScale) {
    if (compare(incomingScale, $this.yv_1) <= 0)
      return Unit_instance;
    var distance = subtract(incomingScale, $this.yv_1);
    var tmp = Companion_getInstance_3().oy_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$0 = modulo(distance, fromInt(9));
    var factor = fromInt(tmp[convertToInt(tmp$ret$0)]);
    // Inline function 'kotlin.Long.div' call
    var offset = divide(distance, fromInt(9));
    var shifted = new DecimalSignedWork535(incomingScale);
    // Inline function 'io.heapy.krogu.math.DecimalSignedWork535.cells' call
    var _iterator__ex2g4s = sorted($this.zv_1.h2()).o();
    while (_iterator__ex2g4s.p()) {
      var page = _iterator__ex2g4s.q();
      var words = getValue($this.zv_1, page);
      var inductionVariable = 0;
      var last = words.length - 1 | 0;
      if (inductionVariable <= last)
        do {
          var offset_0 = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!(words[offset_0] === 0)) {
            // Inline function 'kotlin.Long.times' call
            var this_0 = fromInt(page);
            // Inline function 'kotlin.Long.plus' call
            var this_1 = multiply(this_0, fromInt(256));
            var tmp0 = add(this_1, fromInt(offset_0));
            var value = words[offset_0];
            addCell(shifted, add(tmp0, offset), multiply(numberToLong(value), factor));
          }
        }
         while (inductionVariable <= last);
    }
    $this.zv_1 = shifted.zv_1;
    $this.yv_1 = incomingScale;
  }
  function addCell($this, start, contribution) {
    var index = start;
    var carry = contribution;
    while (!equalsLong(carry, new Long(0, 0))) {
      // Inline function 'kotlin.check' call
      if (!(compare(new Long(0, 0), index) <= 0 ? compare(index, new Long(2147483647, 0)) < 0 : false)) {
        var message = 'Expanded decimal index invariant';
        throw IllegalStateException_init_$Create$(toString_0(message));
      }
      // Inline function 'kotlin.Long.div' call
      var this_0 = index;
      var tmp$ret$2 = divide(this_0, fromInt(256));
      var page = convertToInt(tmp$ret$2);
      // Inline function 'kotlin.Long.rem' call
      var this_1 = index;
      var tmp$ret$3 = modulo(this_1, fromInt(256));
      var offset = convertToInt(tmp$ret$3);
      var tmp0_safe_receiver = $this.zv_1.g2(page);
      var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver[offset];
      var sum = add(fromInt(tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs), carry);
      // Inline function 'kotlin.Long.rem' call
      var other = 1000000000;
      var tmp$ret$4 = modulo(sum, fromInt(other));
      var digit = convertToInt(tmp$ret$4);
      if (!(digit === 0) || $this.zv_1.e2(page)) {
        // Inline function 'kotlin.collections.getOrPut' call
        var this_2 = $this.zv_1;
        var value = this_2.g2(page);
        var tmp;
        if (value == null) {
          var answer = new Int32Array(256);
          this_2.n3(page, answer);
          tmp = answer;
        } else {
          tmp = value;
        }
        tmp[offset] = digit;
      }
      // Inline function 'kotlin.Long.div' call
      var other_0 = 1000000000;
      carry = divide(sum, fromInt(other_0));
      var _unary__edvuaz = index;
      index = add(_unary__edvuaz, get_ONE());
    }
  }
  function pruneZeros($this) {
    var tmp = $this.zv_1.j2();
    removeAll(tmp, DecimalSignedWork535$pruneZeros$lambda);
  }
  function Run(start, end, digit) {
    this.py_1 = start;
    this.qy_1 = end;
    this.ry_1 = digit;
  }
  protoOf(Run).toString = function () {
    return 'Run(start=' + this.py_1.toString() + ', end=' + this.qy_1.toString() + ', digit=' + this.ry_1 + ')';
  };
  protoOf(Run).hashCode = function () {
    var result = this.py_1.hashCode();
    result = imul(result, 31) + this.qy_1.hashCode() | 0;
    result = imul(result, 31) + this.ry_1 | 0;
    return result;
  };
  protoOf(Run).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Run))
      return false;
    if (!equalsLong(this.py_1, other.py_1))
      return false;
    if (!equalsLong(this.qy_1, other.qy_1))
      return false;
    if (!(this.ry_1 === other.ry_1))
      return false;
    return true;
  };
  function Parts(sign, words) {
    this.sy_1 = sign;
    this.ty_1 = words;
  }
  protoOf(Parts).toString = function () {
    return 'Parts(sign=' + this.sy_1 + ', words=' + toString_0(this.ty_1) + ')';
  };
  protoOf(Parts).hashCode = function () {
    var result = this.sy_1;
    result = imul(result, 31) + hashCode(this.ty_1) | 0;
    return result;
  };
  protoOf(Parts).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Parts))
      return false;
    if (!(this.sy_1 === other.sy_1))
      return false;
    if (!equals(this.ty_1, other.ty_1))
      return false;
    return true;
  };
  function parts($this, value) {
    var sign = value.ui();
    var bytes = value.xk().ti();
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(bytes.length);
    // Inline function 'kotlin.Long.div' call
    var this_1 = multiply(this_0, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(29));
    var tmp$ret$2 = add(this_2, fromInt(1));
    var words = new Int32Array(convertToInt(tmp$ret$2));
    var size = 0;
    var inductionVariable = 0;
    var last = bytes.length;
    while (inductionVariable < last) {
      var byte = bytes[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      var carry = fromInt(byte & 255);
      var inductionVariable_0 = 0;
      var last_0 = size;
      if (inductionVariable_0 < last_0)
        do {
          var i = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          // Inline function 'kotlin.Long.times' call
          var this_3 = fromInt(words[i]);
          var tmp$ret$3 = multiply(this_3, fromInt(256));
          var part = add(tmp$ret$3, carry);
          // Inline function 'kotlin.Long.rem' call
          var other = 1000000000;
          var tmp$ret$4 = modulo(part, fromInt(other));
          words[i] = convertToInt(tmp$ret$4);
          // Inline function 'kotlin.Long.div' call
          var other_0 = 1000000000;
          carry = divide(part, fromInt(other_0));
        }
         while (inductionVariable_0 < last_0);
      if (!equalsLong(carry, new Long(0, 0))) {
        var _unary__edvuaz = size;
        size = _unary__edvuaz + 1 | 0;
        words[_unary__edvuaz] = convertToInt(carry);
      }
    }
    return new Parts(sign, copyOf(words, size));
  }
  function BinaryMagnitude(decimalDigits) {
    var tmp = this;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = multiply(numberToLong(4), decimalDigits);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(30));
    var tmp$ret$2 = add(this_2, fromInt(2));
    tmp.uy_1 = new Int32Array(convertToInt(tmp$ret$2));
    this.vy_1 = 0;
  }
  protoOf(BinaryMagnitude).xr = function (multiplier, addition) {
    var carry = fromInt(addition);
    var inductionVariable = 0;
    var last = this.vy_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(this.uy_1[i]);
        var tmp$ret$0 = multiply(this_0, fromInt(multiplier));
        var part = add(tmp$ret$0, carry);
        this.uy_1[i] = convertToInt(bitwiseAnd(part, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(part, 30);
      }
       while (inductionVariable < last);
    if (!equalsLong(carry, new Long(0, 0))) {
      var _unary__edvuaz = this.vy_1;
      this.vy_1 = _unary__edvuaz + 1 | 0;
      this.uy_1[_unary__edvuaz] = convertToInt(carry);
    }
  };
  protoOf(BinaryMagnitude).wx = function (divisor) {
    var remainder = new Long(0, 0);
    var inductionVariable = this.vy_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = shiftLeft(remainder, 30);
        // Inline function 'kotlin.Long.plus' call
        var other = this.uy_1[i];
        var part = add(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$1 = divide(part, fromInt(divisor));
        this.uy_1[i] = convertToInt(tmp$ret$1);
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(divisor));
      }
       while (0 <= inductionVariable);
    while (this.vy_1 > 0 && this.uy_1[this.vy_1 - 1 | 0] === 0) {
      this.vy_1 = this.vy_1 - 1 | 0;
    }
    return convertToInt(remainder);
  };
  protoOf(BinaryMagnitude).bs = function () {
    var tmp;
    if (this.vy_1 === 0) {
      tmp = new Long(0, 0);
    } else {
      var tmp0 = new Long(30, 0);
      // Inline function 'kotlin.Long.times' call
      var other = this.vy_1 - 1 | 0;
      // Inline function 'kotlin.Long.plus' call
      var this_0 = multiply(tmp0, fromInt(other));
      var tmp0_0 = add(this_0, fromInt(32));
      // Inline function 'kotlin.countLeadingZeroBits' call
      var this_1 = this.uy_1[this.vy_1 - 1 | 0];
      // Inline function 'kotlin.Long.minus' call
      var other_0 = clz32(this_1);
      tmp = subtract(tmp0_0, fromInt(other_0));
    }
    return tmp;
  };
  protoOf(BinaryMagnitude).cs = function (sign) {
    var bits = this.bs();
    if (compare(bits, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    if (equalsLong(bits, new Long(0, 0)))
      return Companion_getInstance_1().yj_1;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bits, fromInt(7));
    var tmp$ret$1 = divide(this_0, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$1));
    var inductionVariable = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_1 = new Long(8, 0);
        var bit = multiply(this_1, fromInt(i));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$3 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$3);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$4 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$4);
        var value = shiftRightUnsigned(fromInt(this.uy_1[word]), offset);
        if (offset > 22 && (word + 1 | 0) < this.vy_1)
          value = bitwiseOr(value, shiftLeft(fromInt(this.uy_1[word + 1 | 0]), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable <= last);
    return BigInteger_init_$Create$_6(sign, bytes);
  };
  function Companion_3() {
    Companion_instance_4 = this;
    this.ky_1 = 1000000000;
    this.ly_1 = 256;
    this.my_1 = new Long(646456993, 0);
    this.ny_1 = new Long(1073741823, 0);
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.oy_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  var Companion_instance_4;
  function Companion_getInstance_3() {
    if (Companion_instance_4 == null)
      new Companion_3();
    return Companion_instance_4;
  }
  function DecimalSignedWork535$pruneZeros$lambda(_destruct__k2r9zo) {
    // Inline function 'kotlin.collections.component2' call
    var words = _destruct__k2r9zo.d2();
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.all' call
      var inductionVariable = 0;
      var last = words.length;
      while (inductionVariable < last) {
        var element = words[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (!(element === 0)) {
          tmp$ret$1 = false;
          break $l$block;
        }
      }
      tmp$ret$1 = true;
    }
    return tmp$ret$1;
  }
  function result$append(runs, start, end, value) {
    if (value === 0 || equalsLong(start, end))
      return Unit_instance;
    var last = lastOrNull(runs);
    if (!(last == null) && equalsLong(last.qy_1, start) && last.ry_1 === value)
      last.qy_1 = end;
    else {
      // Inline function 'kotlin.collections.plusAssign' call
      var element = new Run(start, end, value);
      runs.w(element);
    }
  }
  function result$runAt(runs, index) {
    var low = 0;
    var high = get_lastIndex_1(runs);
    while (low <= high) {
      var middle = (low + high | 0) >>> 1 | 0;
      var run = runs.y(middle);
      if (compare(index, run.py_1) < 0)
        high = middle - 1 | 0;
      else if (compare(index, run.qy_1) >= 0)
        low = middle + 1 | 0;
      else
        return run;
    }
    return null;
  }
  function result$digitAt(runs, position) {
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$0 = divide(position, fromInt(9));
    var tmp0_safe_receiver = result$runAt(runs, tmp$ret$0);
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.ry_1;
    var tmp = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    var tmp_0 = Companion_getInstance_3().oy_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$1 = modulo(position, fromInt(9));
    return (tmp / tmp_0[convertToInt(tmp$ret$1)] | 0) % 10 | 0;
  }
  function result$trailingNines(drop, digits, runs) {
    var position = drop;
    while (compare(position, digits) < 0 && result$digitAt(runs, position) === 9) {
      // Inline function 'kotlin.Long.div' call
      var this_0 = position;
      var tmp$ret$0 = divide(this_0, fromInt(9));
      var run = ensureNotNull(result$runAt(runs, tmp$ret$0));
      var tmp;
      var tmp_0;
      // Inline function 'kotlin.Long.rem' call
      var this_1 = position;
      var tmp$ret$1 = modulo(this_1, fromInt(9));
      if (equalsLong(tmp$ret$1, new Long(0, 0))) {
        tmp_0 = run.ry_1 === 999999999;
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        // Inline function 'kotlin.Long.times' call
        var this_2 = run.qy_1;
        // Inline function 'kotlin.comparisons.minOf' call
        var b = multiply(this_2, fromInt(9));
        tmp = compare(digits, b) <= 0 ? digits : b;
      } else {
        // Inline function 'kotlin.Long.plus' call
        var this_3 = position;
        tmp = add(this_3, fromInt(1));
      }
      position = tmp;
    }
    return subtract(position, drop);
  }
  function DecimalSignedWork535(scale) {
    Companion_getInstance_3();
    this.yv_1 = scale;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.zv_1 = LinkedHashMap_init_$Create$();
  }
  protoOf(DecimalSignedWork535).dw = function () {
    // Inline function 'kotlin.also' call
    var this_0 = new DecimalSignedWork535(this.yv_1);
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = this.zv_1.j2().o();
    while (_iterator__ex2g4s.p()) {
      var _destruct__k2r9zo = _iterator__ex2g4s.q();
      // Inline function 'kotlin.collections.component1' call
      var page = _destruct__k2r9zo.c2();
      // Inline function 'kotlin.collections.component2' call
      var words = _destruct__k2r9zo.d2();
      var tmp0 = this_0.zv_1;
      // Inline function 'kotlin.collections.copyOf' call
      // Inline function 'kotlin.js.asDynamic' call
      // Inline function 'kotlin.collections.set' call
      var value = words.slice();
      tmp0.n3(page, value);
    }
    return this_0;
  };
  protoOf(DecimalSignedWork535).aw = function (otherScale, otherDigits) {
    var top = new Long(-1, -1);
    // Inline function 'io.heapy.krogu.math.DecimalSignedWork535.cells' call
    var _iterator__ex2g4s = sorted(this.zv_1.h2()).o();
    while (_iterator__ex2g4s.p()) {
      var page = _iterator__ex2g4s.q();
      var words = getValue(this.zv_1, page);
      var inductionVariable = 0;
      var last = words.length - 1 | 0;
      if (inductionVariable <= last)
        do {
          var offset = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!(words[offset] === 0)) {
            // Inline function 'kotlin.Long.times' call
            var this_0 = fromInt(page);
            // Inline function 'kotlin.Long.plus' call
            var this_1 = multiply(this_0, fromInt(256));
            var tmp0 = add(this_1, fromInt(offset));
            words[offset];
            top = tmp0;
          }
        }
         while (inductionVariable <= last);
    }
    // Inline function 'kotlin.comparisons.maxOf' call
    var a = this.yv_1;
    var target = compare(a, otherScale) >= 0 ? a : otherScale;
    var tmp;
    if (compare(top, new Long(0, 0)) < 0) {
      tmp = new Long(1, 0);
    } else {
      // Inline function 'kotlin.Long.plus' call
      var this_2 = top;
      // Inline function 'kotlin.Long.times' call
      var this_3 = add(this_2, fromInt(1));
      var tmp$ret$6 = multiply(this_3, fromInt(9));
      tmp = subtract(add(tmp$ret$6, target), this.yv_1);
    }
    var tmp0_0 = tmp;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = subtract(add(otherDigits, target), otherScale);
    // Inline function 'kotlin.Long.plus' call
    var this_4 = compare(tmp0_0, b) >= 0 ? tmp0_0 : b;
    return add(this_4, fromInt(1));
  };
  protoOf(DecimalSignedWork535).bw = function (value) {
    var parts_0 = parts(this, value.un());
    align(this, fromInt(value.vn()));
    var tmp0 = this.yv_1;
    // Inline function 'kotlin.Long.minus' call
    var other = value.vn();
    var shift = subtract(tmp0, fromInt(other));
    var tmp = Companion_getInstance_3().oy_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$1 = modulo(shift, fromInt(9));
    var factor = fromInt(tmp[convertToInt(tmp$ret$1)]);
    // Inline function 'kotlin.Long.div' call
    var base = divide(shift, fromInt(9));
    var inductionVariable = 0;
    var last = parts_0.ty_1.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.plus' call
        var tmp$ret$3 = add(base, fromInt(i));
        addCell(this, tmp$ret$3, multiply(multiply(numberToLong(parts_0.sy_1), fromInt(parts_0.ty_1[i])), factor));
      }
       while (inductionVariable <= last);
    pruneZeros(this);
  };
  protoOf(DecimalSignedWork535).cw = function (left, right) {
    var tmp0 = fromInt(left.vn());
    // Inline function 'kotlin.Long.plus' call
    var other = right.vn();
    var productScale = add(tmp0, fromInt(other));
    align(this, productScale);
    if (left.ui() === 0 || right.ui() === 0)
      return Unit_instance;
    var a = parts(this, left.un());
    var b = parts(this, right.un());
    var shift = subtract(this.yv_1, productScale);
    var tmp = Companion_getInstance_3().oy_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$1 = modulo(shift, fromInt(9));
    var factor = fromInt(tmp[convertToInt(tmp$ret$1)]);
    // Inline function 'kotlin.Long.div' call
    var base = divide(shift, fromInt(9));
    var sign = imul(a.sy_1, b.sy_1);
    var inductionVariable = 0;
    var last = a.ty_1.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var inductionVariable_0 = 0;
        var last_0 = b.ty_1.length - 1 | 0;
        if (inductionVariable_0 <= last_0)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp0_0 = fromInt(a.ty_1[i]);
            // Inline function 'kotlin.Long.times' call
            var other_0 = b.ty_1[j];
            var product = multiply(tmp0_0, fromInt(other_0));
            // Inline function 'kotlin.Long.plus' call
            // Inline function 'kotlin.Long.plus' call
            var this_0 = add(base, fromInt(i));
            var tmp_0 = add(this_0, fromInt(j));
            // Inline function 'kotlin.Long.rem' call
            var other_1 = 1000000000;
            var tmp$ret$6 = modulo(product, fromInt(other_1));
            addCell(this, tmp_0, multiply(multiply(numberToLong(sign), tmp$ret$6), factor));
            // Inline function 'kotlin.Long.plus' call
            // Inline function 'kotlin.Long.plus' call
            var this_1 = add(base, fromInt(i));
            // Inline function 'kotlin.Long.plus' call
            var this_2 = add(this_1, fromInt(j));
            var tmp_1 = add(this_2, fromInt(1));
            // Inline function 'kotlin.Long.div' call
            var other_2 = 1000000000;
            var tmp$ret$10 = divide(product, fromInt(other_2));
            addCell(this, tmp_1, multiply(multiply(numberToLong(sign), tmp$ret$10), factor));
          }
           while (inductionVariable_0 <= last_0);
      }
       while (inductionVariable <= last);
    pruneZeros(this);
  };
  protoOf(DecimalSignedWork535).gw = function (context) {
    var sign = 0;
    // Inline function 'io.heapy.krogu.math.DecimalSignedWork535.cells' call
    var _iterator__ex2g4s = sorted(this.zv_1.h2()).o();
    while (_iterator__ex2g4s.p()) {
      var page = _iterator__ex2g4s.q();
      var words = getValue(this.zv_1, page);
      var inductionVariable = 0;
      var last = words.length - 1 | 0;
      if (inductionVariable <= last)
        do {
          var offset = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!(words[offset] === 0)) {
            // Inline function 'kotlin.Long.times' call
            var this_0 = fromInt(page);
            // Inline function 'kotlin.Long.plus' call
            var this_1 = multiply(this_0, fromInt(256));
            add(this_1, fromInt(offset));
            sign = words[offset] < 0 ? -1 : 1;
          }
        }
         while (inductionVariable <= last);
    }
    if (sign === 0)
      return Companion_getInstance().ij_1;
    // Inline function 'kotlin.collections.mutableListOf' call
    var runs = ArrayList_init_$Create$();
    var cursor = new Long(0, 0);
    var borrow = 0;
    // Inline function 'io.heapy.krogu.math.DecimalSignedWork535.cells' call
    var _iterator__ex2g4s_0 = sorted(this.zv_1.h2()).o();
    while (_iterator__ex2g4s_0.p()) {
      var page_0 = _iterator__ex2g4s_0.q();
      var words_0 = getValue(this.zv_1, page_0);
      var inductionVariable_0 = 0;
      var last_1 = words_0.length - 1 | 0;
      if (inductionVariable_0 <= last_1)
        do {
          var offset_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          if (!(words_0[offset_0] === 0)) {
            // Inline function 'kotlin.Long.times' call
            var this_2 = fromInt(page_0);
            // Inline function 'kotlin.Long.plus' call
            var this_3 = multiply(this_2, fromInt(256));
            var tmp0 = add(this_3, fromInt(offset_0));
            var signed = words_0[offset_0];
            if (!(borrow === 0) && compare(tmp0, cursor) > 0) {
              result$append(runs, cursor, tmp0, 999999999);
            }
            var value = imul(sign, signed) + borrow | 0;
            if (value < 0) {
              // Inline function 'kotlin.Long.plus' call
              var tmp$ret$9 = add(tmp0, fromInt(1));
              result$append(runs, tmp0, tmp$ret$9, value + 1000000000 | 0);
              borrow = -1;
            } else {
              // Inline function 'kotlin.Long.plus' call
              var tmp$ret$10 = add(tmp0, fromInt(1));
              result$append(runs, tmp0, tmp$ret$10, value);
              borrow = 0;
            }
            // Inline function 'kotlin.Long.plus' call
            cursor = add(tmp0, fromInt(1));
          }
        }
         while (inductionVariable_0 <= last_1);
    }
    var tmp;
    if (borrow === 0) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      tmp = !runs.m();
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.check' call
    if (!tmp) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var last_2 = last_0(runs);
    var topDigits = 1;
    while (topDigits < 9 && last_2.ry_1 >= Companion_getInstance_3().oy_1[topDigits]) {
      topDigits = topDigits + 1 | 0;
    }
    // Inline function 'kotlin.Long.minus' call
    var this_4 = last_2.qy_1;
    // Inline function 'kotlin.Long.times' call
    var this_5 = subtract(this_4, fromInt(1));
    var tmp0_0 = multiply(this_5, fromInt(9));
    // Inline function 'kotlin.Long.plus' call
    var other = topDigits;
    var digits = add(tmp0_0, fromInt(other));
    var tmp_0;
    if (context.ol_1 === 0) {
      tmp_0 = new Long(0, 0);
    } else {
      var tmp0_1 = new Long(0, 0);
      // Inline function 'kotlin.Long.minus' call
      var other_0 = context.ol_1;
      // Inline function 'kotlin.comparisons.maxOf' call
      var b = subtract(digits, fromInt(other_0));
      tmp_0 = compare(tmp0_1, b) >= 0 ? tmp0_1 : b;
    }
    var drop = tmp_0;
    var tmp_1;
    if (equalsLong(drop, new Long(0, 0))) {
      tmp_1 = false;
    } else {
      // Inline function 'kotlin.Long.minus' call
      var position = subtract(drop, fromInt(1));
      var guard = result$digitAt(runs, position);
      // Inline function 'kotlin.Long.div' call
      var cell = divide(position, fromInt(9));
      var tmp_2;
      if (compare(first(runs).py_1, cell) < 0) {
        tmp_2 = true;
      } else {
        var tmp0_safe_receiver = result$runAt(runs, cell);
        var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.ry_1;
        var tmp_3 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
        var tmp_4 = Companion_getInstance_3().oy_1;
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$21 = modulo(position, fromInt(9));
        tmp_2 = !((tmp_3 % tmp_4[convertToInt(tmp$ret$21)] | 0) === 0);
      }
      var sticky = tmp_2;
      var inexact = !(guard === 0) || sticky;
      var tmp_5;
      if (guard === 5) {
        tmp_5 = sticky ? 1 : 0;
      } else {
        tmp_5 = compareTo(guard, 5);
      }
      var half = tmp_5;
      var tmp_6;
      if (inexact) {
        var tmp_7;
        switch (context.pl_1.l2_1) {
          case 0:
            tmp_7 = true;
            break;
          case 1:
            tmp_7 = false;
            break;
          case 2:
            tmp_7 = sign > 0;
            break;
          case 3:
            tmp_7 = sign < 0;
            break;
          case 4:
            tmp_7 = half >= 0;
            break;
          case 5:
            tmp_7 = half > 0;
            break;
          case 6:
            tmp_7 = half > 0 || (half === 0 && !((result$digitAt(runs, drop) % 2 | 0) === 0));
            break;
          case 7:
            throw ArithmeticException_init_$Create$('Rounding necessary');
          default:
            noWhenBranchMatchedException();
            break;
        }
        tmp_6 = tmp_7;
      } else {
        tmp_6 = false;
      }
      tmp_1 = tmp_6;
    }
    var increment = tmp_1;
    var quotientDigits = subtract(digits, drop);
    var nines = increment ? result$trailingNines(drop, digits, runs) : new Long(0, 0);
    var carry = increment && equalsLong(nines, quotientDigits);
    // Inline function 'kotlin.Long.plus' call
    var other_1 = carry ? 1 : 0;
    var roundedDigits = add(quotientDigits, fromInt(other_1));
    var tmp_8;
    if (increment) {
      tmp_8 = nines;
    } else {
      var position_0 = drop;
      while (compare(position_0, digits) < 0 && result$digitAt(runs, position_0) === 0) {
        // Inline function 'kotlin.Long.div' call
        var this_6 = position_0;
        var cell_0 = divide(this_6, fromInt(9));
        if (result$runAt(runs, cell_0) == null) {
          var low = 0;
          var high = runs.z();
          while (low < high) {
            var middle = (low + high | 0) >>> 1 | 0;
            if (compare(runs.y(middle).py_1, cell_0) <= 0)
              low = middle + 1 | 0;
            else
              high = middle;
          }
          // Inline function 'kotlin.Long.times' call
          var this_7 = runs.y(low).py_1;
          // Inline function 'kotlin.comparisons.minOf' call
          var b_0 = multiply(this_7, fromInt(9));
          position_0 = compare(digits, b_0) <= 0 ? digits : b_0;
        } else {
          var _unary__edvuaz = position_0;
          position_0 = add(_unary__edvuaz, get_ONE());
        }
      }
      tmp_8 = subtract(position_0, drop);
    }
    var trailingZeros = tmp_8;
    var tmp_9;
    if (context.ol_1 > 0) {
      var tmp0_2 = new Long(0, 0);
      // Inline function 'kotlin.Long.minus' call
      var other_2 = context.ol_1;
      // Inline function 'kotlin.comparisons.maxOf' call
      var b_1 = subtract(roundedDigits, fromInt(other_2));
      tmp_9 = compare(tmp0_2, b_1) >= 0 ? tmp0_2 : b_1;
    } else {
      tmp_9 = new Long(0, 0);
    }
    var trim = tmp_9;
    var tmp0_3 = trim;
    var tmp0_4 = subtract(this.yv_1, drop);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = 2147483647;
    var tmp2 = subtract(tmp0_4, fromInt(other_3));
    // Inline function 'kotlin.comparisons.maxOf' call
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_2 = subtract(roundedDigits, new Long(646456993, 0));
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_3 = compare(tmp2, b_2) >= 0 ? tmp2 : b_2;
    trim = compare(tmp0_3, b_3) >= 0 ? tmp0_3 : b_3;
    if (compare(trim, trailingZeros) > 0)
      throw ArithmeticException_init_$Create$('Decimal result exceeds supported range');
    if (compare(roundedDigits, new Long(646456993, 0)) > 0 || compare(subtract(this.yv_1, drop), new Long(2147483647, 0)) > 0) {
      var tmp0_5 = trim;
      var tmp0_6 = new Long(0, 0);
      var tmp0_7 = subtract(this.yv_1, drop);
      // Inline function 'kotlin.Long.minus' call
      var other_4 = -2147483648;
      // Inline function 'kotlin.comparisons.maxOf' call
      var b_4 = subtract(tmp0_7, fromInt(other_4));
      // Inline function 'kotlin.comparisons.minOf' call
      var b_5 = compare(tmp0_6, b_4) >= 0 ? tmp0_6 : b_4;
      // Inline function 'kotlin.comparisons.maxOf' call
      var b_6 = compare(trailingZeros, b_5) <= 0 ? trailingZeros : b_5;
      trim = compare(tmp0_5, b_6) >= 0 ? tmp0_5 : b_6;
    }
    var resultScale = subtract(subtract(this.yv_1, drop), trim);
    var tmp0_8 = new Long(0, 0);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_7 = subtract(new Long(-2147483648, -1), resultScale);
    var appendZeros = compare(tmp0_8, b_7) >= 0 ? tmp0_8 : b_7;
    if (compare(add(subtract(roundedDigits, trim), appendZeros), new Long(646456993, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    var binary = new BinaryMagnitude(add(subtract(roundedDigits, trim), appendZeros));
    // Inline function 'kotlin.Long.minus' call
    var position_1 = subtract(digits, fromInt(1));
    while (compare(position_1, add(drop, trim)) >= 0) {
      var tmp0_9 = new Long(9, 0);
      // Inline function 'kotlin.Long.plus' call
      var this_8 = subtract(subtract(position_1, drop), trim);
      // Inline function 'kotlin.comparisons.minOf' call
      var b_8 = add(this_8, fromInt(1));
      var tmp$ret$39 = compare(tmp0_9, b_8) <= 0 ? tmp0_9 : b_8;
      var count = convertToInt(tmp$ret$39);
      var chunk = 0;
      // Inline function 'kotlin.repeat' call
      var inductionVariable_1 = 0;
      if (inductionVariable_1 < count)
        do {
          var index = inductionVariable_1;
          inductionVariable_1 = inductionVariable_1 + 1 | 0;
          var tmp_10 = imul(chunk, 10);
          var _unary__edvuaz_0 = position_1;
          position_1 = subtract(_unary__edvuaz_0, get_ONE());
          chunk = tmp_10 + result$digitAt(runs, _unary__edvuaz_0) | 0;
        }
         while (inductionVariable_1 < count);
      binary.xr(count === 9 ? 1000000000 : Companion_getInstance_3().oy_1[count], chunk);
    }
    if (increment) {
      binary.xr(1, 1);
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$42 = divide(appendZeros, fromInt(9));
    // Inline function 'kotlin.repeat' call
    var times = convertToInt(tmp$ret$42);
    var inductionVariable_2 = 0;
    if (inductionVariable_2 < times)
      do {
        var index_0 = inductionVariable_2;
        inductionVariable_2 = inductionVariable_2 + 1 | 0;
        binary.xr(1000000000, 0);
      }
       while (inductionVariable_2 < times);
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$45 = modulo(appendZeros, fromInt(9));
    if (!equalsLong(tmp$ret$45, new Long(0, 0))) {
      var tmp_11 = Companion_getInstance_3().oy_1;
      // Inline function 'kotlin.Long.rem' call
      var tmp$ret$46 = modulo(appendZeros, fromInt(9));
      binary.xr(tmp_11[convertToInt(tmp$ret$46)], 0);
    }
    resultScale = add(resultScale, appendZeros);
    // Inline function 'kotlin.check' call
    if (!(compare(new Long(-2147483648, -1), resultScale) <= 0 ? compare(resultScale, new Long(2147483647, 0)) <= 0 : false)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    if (compare(binary.bs(), new Long(2147483647, 0)) > 0) {
      var tmp0_10 = add(subtract(trailingZeros, trim), appendZeros);
      var tmp0_11 = resultScale;
      // Inline function 'kotlin.Long.minus' call
      var other_5 = -2147483648;
      // Inline function 'kotlin.comparisons.minOf' call
      var b_9 = subtract(tmp0_11, fromInt(other_5));
      var rescue = compare(tmp0_10, b_9) <= 0 ? tmp0_10 : b_9;
      if (compare(rescue, new Long(0, 0)) <= 0)
        throw ArithmeticException_init_$Create$('BigInteger overflow');
      // Inline function 'kotlin.Long.div' call
      var tmp$ret$50 = divide(rescue, fromInt(9));
      // Inline function 'kotlin.repeat' call
      var times_0 = convertToInt(tmp$ret$50);
      var inductionVariable_3 = 0;
      if (inductionVariable_3 < times_0)
        do {
          var index_1 = inductionVariable_3;
          inductionVariable_3 = inductionVariable_3 + 1 | 0;
          // Inline function 'kotlin.check' call
          if (!(binary.wx(1000000000) === 0)) {
            throw IllegalStateException_init_$Create$('Check failed.');
          }
        }
         while (inductionVariable_3 < times_0);
      // Inline function 'kotlin.Long.rem' call
      var tmp$ret$54 = modulo(rescue, fromInt(9));
      if (!equalsLong(tmp$ret$54, new Long(0, 0))) {
        var tmp_12 = Companion_getInstance_3().oy_1;
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$55 = modulo(rescue, fromInt(9));
        // Inline function 'kotlin.check' call
        if (!(binary.wx(tmp_12[convertToInt(tmp$ret$55)]) === 0)) {
          throw IllegalStateException_init_$Create$('Check failed.');
        }
      }
      resultScale = subtract(resultScale, rescue);
    }
    return BigDecimal_init_$Create$_0(binary.cs(sign), convertToInt(resultScale));
  };
  function trim_0($this) {
    while ($this.xy_1 > 0 && $this.wy_1.y($this.xy_1 - 1 | 0) === 0) {
      $this.xy_1 = $this.xy_1 - 1 | 0;
    }
  }
  function decimalChunks_1($this, coefficient) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = new Long(646456993, 0);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(8));
    var tmp$ret$1 = divide(this_1, fromInt(9));
    var chunks = new DecimalWords_1(convertToInt(tmp$ret$1));
    var divisor = Companion_getInstance_1().fk(new Long(1000000000, 0));
    var value = coefficient;
    while (!(value.ui() === 0)) {
      var qr = value.wk(divisor);
      chunks.xw(qr[1].kq());
      value = qr[0];
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!!(chunks.xy_1 === 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    return chunks;
  }
  function binaryCoefficient_0($this, decimal) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = new Long(2147483647, 0);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(30));
    var tmp$ret$2 = add(this_2, fromInt(1));
    var binary = new Cells_1(convertToInt(tmp$ret$2));
    var size = 0;
    var inductionVariable = decimal.xy_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var carry = fromInt(decimal.y(i));
        var j = 0;
        while (j < size) {
          var tmp0 = fromInt(binary.y(j));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$3 = multiply(tmp0, fromInt(other));
          var part = add(tmp$ret$3, carry);
          binary.ww(j, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
          j = j + 1 | 0;
        }
        if (!equalsLong(carry, new Long(0, 0))) {
          var _unary__edvuaz = size;
          size = _unary__edvuaz + 1 | 0;
          binary.ww(_unary__edvuaz, convertToInt(carry));
        }
        if (!(size === 0)) {
          var tmp0_0 = new Long(30, 0);
          // Inline function 'kotlin.Long.times' call
          var other_0 = size - 1 | 0;
          // Inline function 'kotlin.Long.plus' call
          var this_3 = multiply(tmp0_0, fromInt(other_0));
          var tmp0_1 = add(this_3, fromInt(32));
          // Inline function 'kotlin.countLeadingZeroBits' call
          var this_4 = binary.y(size - 1 | 0);
          // Inline function 'kotlin.Long.minus' call
          var other_1 = clz32(this_4);
          var bits = subtract(tmp0_1, fromInt(other_1));
          if (compare(bits, new Long(2147483647, 0)) > 0)
            throw ArithmeticException_init_$Create$('BigInteger overflow');
        }
      }
       while (0 <= inductionVariable);
    // Inline function 'kotlin.check' call
    if (!!(size === 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tmp0_2 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_5 = multiply(tmp0_2, fromInt(other_2));
    var tmp0_3 = add(this_5, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_6 = binary.y(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_6);
    var bits_0 = subtract(tmp0_3, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_7 = add(bits_0, fromInt(7));
    var tmp$ret$14 = divide(this_7, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$14));
    var inductionVariable_0 = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_8 = new Long(8, 0);
        var bit = multiply(this_8, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$16 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$16);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$17 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$17);
        var value = shiftRightUnsigned(fromInt(binary.y(word)), offset);
        if (offset > 22 && (word + 1 | 0) < size)
          value = bitwiseOr(value, shiftLeft(fromInt(binary.y(word + 1 | 0)), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last);
    return BigInteger_init_$Create$_6(1, bytes);
  }
  function Cells_1(limit) {
    this.yy_1 = limit;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.zy_1 = ArrayList_init_$Create$();
  }
  protoOf(Cells_1).y = function (index) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.yy_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return this.zy_1.y(index / 8192 | 0)[index % 8192 | 0];
  };
  protoOf(Cells_1).ww = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.yy_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var page = index / 8192 | 0;
    while (this.zy_1.z() <= page) {
      this.zy_1.w(new Int32Array(8192));
    }
    this.zy_1.y(page)[index % 8192 | 0] = value;
  };
  function DecimalWords_1(capacity) {
    this.wy_1 = new Cells_1(capacity);
    this.xy_1 = 0;
  }
  protoOf(DecimalWords_1).y = function (index) {
    return this.wy_1.y(index);
  };
  protoOf(DecimalWords_1).xw = function (value) {
    this.wy_1.ww(this.xy_1, value);
    this.xy_1 = this.xy_1 + 1 | 0;
  };
  protoOf(DecimalWords_1).az = function (other) {
    var inductionVariable = 0;
    var last = other.xy_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.wy_1.ww(i, other.y(i));
      }
       while (inductionVariable < last);
    this.xy_1 = other.xy_1;
  };
  protoOf(DecimalWords_1).xr = function (multiplier, addition) {
    var carry = fromInt(addition);
    var inductionVariable = 0;
    var last = this.xy_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(this.wy_1.y(i));
        var tmp$ret$0 = multiply(this_0, fromInt(multiplier));
        var part = add(tmp$ret$0, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$1 = modulo(part, fromInt(other));
        this.wy_1.ww(i, convertToInt(tmp$ret$1));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < last);
    while (!equalsLong(carry, new Long(0, 0))) {
      var tmp0 = carry;
      // Inline function 'kotlin.Long.rem' call
      var other_1 = 1000000000;
      var tmp$ret$3 = modulo(tmp0, fromInt(other_1));
      this.xw(convertToInt(tmp$ret$3));
      var tmp0_0 = carry;
      // Inline function 'kotlin.Long.div' call
      var other_2 = 1000000000;
      carry = divide(tmp0_0, fromInt(other_2));
    }
    trim_0(this);
  };
  protoOf(DecimalWords_1).bz = function (other) {
    if (!(this.xy_1 === other.xy_1))
      return compareTo(this.xy_1, other.xy_1);
    var inductionVariable = this.xy_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var compared = compareTo(this.wy_1.y(i), other.y(i));
        if (!(compared === 0))
          return compared;
      }
       while (0 <= inductionVariable);
    return 0;
  };
  protoOf(DecimalWords_1).cz = function (other) {
    var borrow = 0;
    var inductionVariable = 0;
    var last = this.xy_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var value = (this.wy_1.y(i) - (i < other.xy_1 ? other.y(i) : 0) | 0) - borrow | 0;
        borrow = value < 0 ? 1 : 0;
        if (value < 0)
          value = value + 1000000000 | 0;
        this.wy_1.ww(i, value);
      }
       while (inductionVariable < last);
    // Inline function 'kotlin.check' call
    if (!(borrow === 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    trim_0(this);
  };
  protoOf(DecimalWords_1).vw = function () {
    var remainder = new Long(0, 0);
    var inductionVariable = this.xy_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.wy_1.y(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(10));
        this.wy_1.ww(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(10));
      }
       while (0 <= inductionVariable);
    trim_0(this);
    return convertToInt(remainder);
  };
  function normalized$digit(position, digits, topDigits, top, input) {
    var _unary__edvuaz = position._v;
    position._v = add(_unary__edvuaz, get_ONE());
    var at = _unary__edvuaz;
    if (compare(at, digits) >= 0)
      return 0;
    if (compare(at, fromInt(topDigits._v)) < 0)
      return (top / DecimalSquareRoot579_getInstance().tp_1[(topDigits._v - 1 | 0) - convertToInt(at) | 0] | 0) % 10 | 0;
    // Inline function 'kotlin.Long.minus' call
    var other = topDigits._v;
    var tail = subtract(at, fromInt(other));
    var tmp = input.xy_1 - 2 | 0;
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(tail, fromInt(9));
    var chunk = tmp - convertToInt(tmp$ret$1) | 0;
    var tmp_0 = input.y(chunk);
    var tmp_1 = DecimalSquareRoot579_getInstance().tp_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(tail, fromInt(9));
    return (tmp_0 / tmp_1[8 - convertToInt(tmp$ret$2) | 0] | 0) % 10 | 0;
  }
  function DecimalSquareRoot579() {
    DecimalSquareRoot579_instance = this;
    this.rp_1 = 1000000000;
    this.sp_1 = 8192;
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.tp_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalSquareRoot579).wp = function (digits, shift, scale) {
    return (compare(new Long(1, 0), shift) <= 0 ? compare(shift, new Long(646456992, 0)) <= 0 : false) && (compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false) && compare(multiply(new Long(4, 0), add(fromInt(digits), shift)), new Long(2147483647, 0)) <= 0;
  };
  protoOf(DecimalSquareRoot579).up = function (precision) {
    return precision > 646456993;
  };
  protoOf(DecimalSquareRoot579).vp = function (coefficient, shift, precision, scale, preferred, mode) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(shift, new Long(0, 0)) > 0 && precision > 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(precision);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(11));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(9));
    var tmp$ret$5 = add(this_2, fromInt(1));
    var capacity = convertToInt(tmp$ret$5);
    var input = decimalChunks_1(this, coefficient);
    var top = input.y(input.xy_1 - 1 | 0);
    var topDigits = {_v: 1};
    while (topDigits._v < 9 && top >= this.tp_1[topDigits._v]) {
      topDigits._v = topDigits._v + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = input.xy_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = topDigits._v;
    var digits = add(tmp0_0, fromInt(other_0));
    var total = add(digits, shift);
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_3 = add(total, fromInt(1));
    var tmp$ret$9 = divide(this_3, fromInt(2));
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!equalsLong(tmp$ret$9, fromInt(precision))) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    var position = {_v: new Long(0, 0)};
    var root = new DecimalWords_1(capacity);
    var remainder = new DecimalWords_1(capacity);
    var trial = new DecimalWords_1(capacity);
    var allNines = true;
    var first = true;
    while (compare(position._v, total) < 0) {
      var pair = first && !equalsLong(modulo(total, new Long(2, 0)), new Long(0, 0)) ? normalized$digit(position, digits, topDigits, top, input) : imul(10, normalized$digit(position, digits, topDigits, top, input)) + normalized$digit(position, digits, topDigits, top, input) | 0;
      first = false;
      remainder.xr(100, pair);
      var d = 9;
      $l$loop: while (true) {
        trial.az(root);
        trial.xr(20, d);
        trial.xr(d, 0);
        if (trial.bz(remainder) <= 0)
          break $l$loop;
        d = d - 1 | 0;
      }
      remainder.cz(trial);
      root.xr(10, d);
      if (!(d === 9))
        allNines = false;
    }
    var inexact = !(remainder.xy_1 === 0);
    if (inexact && mode.equals(RoundingMode_UNNECESSARY_getInstance()))
      throw ArithmeticException_init_$Create$('Rounding necessary');
    var halfAbove = remainder.bz(root) > 0;
    var tmp;
    if (inexact) {
      var tmp_0;
      switch (mode.l2_1) {
        case 0:
        case 2:
          tmp_0 = true;
          break;
        case 1:
        case 3:
          tmp_0 = false;
          break;
        case 4:
        case 5:
        case 6:
          tmp_0 = halfAbove;
          break;
        case 7:
          tmp_0 = false;
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    var increment = tmp;
    var finalScale = scale;
    if (increment) {
      root.xr(1, 1);
      if (allNines) {
        // Inline function 'kotlin.check' call
        if (!(root.vw() === 0)) {
          throw IllegalStateException_init_$Create$('Check failed.');
        }
        var _unary__edvuaz = finalScale;
        finalScale = subtract(_unary__edvuaz, get_ONE());
      }
    }
    while (!inexact && compare(finalScale, fromInt(preferred)) > 0 && (root.y(0) % 10 | 0) === 0) {
      // Inline function 'kotlin.check' call
      if (!(root.vw() === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var _unary__edvuaz_0 = finalScale;
      finalScale = subtract(_unary__edvuaz_0, get_ONE());
    }
    if (!(compare(new Long(-2147483648, -1), finalScale) <= 0 ? compare(finalScale, new Long(2147483647, 0)) <= 0 : false))
      throw ArithmeticException_init_$Create$(compare(finalScale, new Long(0, 0)) < 0 ? 'Overflow' : 'Underflow');
    return to(binaryCoefficient_0(this, root), convertToInt(finalScale));
  };
  var DecimalSquareRoot579_instance;
  function DecimalSquareRoot579_getInstance() {
    if (DecimalSquareRoot579_instance == null)
      new DecimalSquareRoot579();
    return DecimalSquareRoot579_instance;
  }
  function decimal($this, words, scratch) {
    // Inline function 'kotlin.collections.isEmpty' call
    if (words.length === 0)
      return new Digits(0);
    var inductionVariable = 0;
    var last = words.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        scratch.ww(i, words[i]);
      }
       while (inductionVariable <= last);
    var size = words.length;
    var tmp0 = new Long(646456993, 0);
    var tmp0_0 = new Long(10, 0);
    // Inline function 'kotlin.Long.times' call
    var other = words.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(tmp0_0, fromInt(other));
    var bound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bound, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = divide(this_0, fromInt(9));
    var tmp$ret$5 = add(this_1, fromInt(1));
    var result = new Digits(convertToInt(tmp$ret$5));
    while (size > 0) {
      var remainder = new Long(0, 0);
      var inductionVariable_0 = size - 1 | 0;
      if (0 <= inductionVariable_0)
        do {
          var i_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + -1 | 0;
          var tmp0_1 = shiftLeft(remainder, 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = scratch.y(i_0);
          var part = add(tmp0_1, fromInt(other_0));
          // Inline function 'kotlin.Long.div' call
          var other_1 = 1000000000;
          var tmp$ret$7 = divide(part, fromInt(other_1));
          scratch.ww(i_0, convertToInt(tmp$ret$7));
          // Inline function 'kotlin.Long.rem' call
          var other_2 = 1000000000;
          remainder = modulo(part, fromInt(other_2));
        }
         while (0 <= inductionVariable_0);
      result.ww(result.gz_1, convertToInt(remainder));
      result.gz_1 = result.gz_1 + 1 | 0;
      while (size > 0 && scratch.y(size - 1 | 0) === 0) {
        size = size - 1 | 0;
      }
    }
    return result;
  }
  function aligned($this, value, raise) {
    if (value.gz_1 === 0)
      return new View(value, new Long(0, 0));
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$0 = modulo(raise, fromInt(9));
    var factor = $this.zt_1[convertToInt(tmp$ret$0)];
    var carry = new Long(0, 0);
    var oldSize = value.gz_1;
    var inductionVariable = 0;
    if (inductionVariable < oldSize)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(value.y(i));
        var tmp$ret$1 = multiply(this_0, fromInt(factor));
        var part = add(tmp$ret$1, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$2 = modulo(part, fromInt(other));
        value.ww(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < oldSize);
    if (!equalsLong(carry, new Long(0, 0))) {
      value.ww(oldSize, convertToInt(carry));
      value.gz_1 = value.gz_1 + 1 | 0;
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$4 = divide(raise, fromInt(9));
    return new View(value, tmp$ret$4);
  }
  function View(value, offset) {
    this.hz_1 = value;
    this.iz_1 = offset;
  }
  protoOf(View).jz = function () {
    var tmp;
    if (this.hz_1.gz_1 === 0) {
      tmp = new Long(0, 0);
    } else {
      var tmp0 = this.iz_1;
      // Inline function 'kotlin.Long.plus' call
      var other = this.hz_1.gz_1;
      tmp = add(tmp0, fromInt(other));
    }
    return tmp;
  };
  protoOf(View).vf = function (at) {
    return !(this.hz_1.gz_1 === 0) && compare(at, this.iz_1) >= 0 && compare(at, this.jz()) < 0;
  };
  protoOf(View).kz = function (at) {
    return this.vf(at) ? this.hz_1.y(convertToInt(subtract(at, this.iz_1))) : 0;
  };
  protoOf(View).lz = function (at, limit) {
    var tmp;
    if (!(this.hz_1.gz_1 === 0) && compare(at, this.iz_1) < 0) {
      // Inline function 'kotlin.comparisons.minOf' call
      var a = this.iz_1;
      tmp = compare(a, limit) <= 0 ? a : limit;
    } else {
      tmp = limit;
    }
    return tmp;
  };
  protoOf(View).sw = function () {
    return this.hz_1.gz_1 === 0 ? new Long(0, 0) : add(multiply(new Long(9, 0), this.iz_1), this.hz_1.sw());
  };
  function compare_0($this, a, b) {
    var order = a.sw().t2(b.sw());
    if (!(order === 0))
      return order;
    var tmp0 = a.jz();
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_0 = b.jz();
    var at = compare(tmp0, b_0) >= 0 ? tmp0 : b_0;
    while (compare(at, new Long(0, 0)) > 0) {
      var _unary__edvuaz = at;
      at = subtract(_unary__edvuaz, get_ONE());
      var cell = compareTo(a.kz(at), b.kz(at));
      if (!(cell === 0))
        return cell;
    }
    return 0;
  }
  function publish_0($this, decimal, sign, scale) {
    if (compare(decimal.sw(), new Long(646456993, 0)) > 0)
      return null;
    var tmp0 = new Long(2147483647, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(new Long(4, 0), decimal.sw());
    var bound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bound, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = divide(this_0, fromInt(30));
    var tmp$ret$3 = add(this_1, fromInt(1));
    var binary = new Cells_2(convertToInt(tmp$ret$3));
    var size = 0;
    var inductionVariable = decimal.gz_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var carry = fromInt(decimal.y(i));
        var j = 0;
        while (j < size) {
          var tmp0_0 = fromInt(binary.y(j));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$4 = multiply(tmp0_0, fromInt(other));
          var part = add(tmp$ret$4, carry);
          binary.ww(j, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
          j = j + 1 | 0;
        }
        if (!equalsLong(carry, new Long(0, 0))) {
          var _unary__edvuaz = size;
          size = _unary__edvuaz + 1 | 0;
          binary.ww(_unary__edvuaz, convertToInt(carry));
        }
        var tmp0_1 = new Long(30, 0);
        // Inline function 'kotlin.Long.times' call
        var other_0 = size - 1 | 0;
        // Inline function 'kotlin.Long.plus' call
        var this_2 = multiply(tmp0_1, fromInt(other_0));
        var tmp0_2 = add(this_2, fromInt(32));
        // Inline function 'kotlin.countLeadingZeroBits' call
        var this_3 = binary.y(size - 1 | 0);
        // Inline function 'kotlin.Long.minus' call
        var other_1 = clz32(this_3);
        var bits = subtract(tmp0_2, fromInt(other_1));
        if (compare(bits, new Long(2147483647, 0)) > 0)
          return null;
      }
       while (0 <= inductionVariable);
    var tmp0_3 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_4 = multiply(tmp0_3, fromInt(other_2));
    var tmp0_4 = add(this_4, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_5 = binary.y(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_5);
    var bits_0 = subtract(tmp0_4, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_6 = add(bits_0, fromInt(7));
    var tmp$ret$14 = divide(this_6, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$14));
    var inductionVariable_0 = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_7 = new Long(8, 0);
        var bit = multiply(this_7, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$16 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$16);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$17 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$17);
        var value = shiftRightUnsigned(fromInt(binary.y(word)), offset);
        if (offset > 22 && (word + 1 | 0) < size)
          value = bitwiseOr(value, shiftLeft(fromInt(binary.y(word + 1 | 0)), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last);
    return to(BigInteger_init_$Create$_6(sign, bytes), scale);
  }
  function Cells_2(capacity) {
    this.dz_1 = capacity;
    var tmp = this;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(this.dz_1);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(8192));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = divide(this_2, fromInt(8192));
    // Inline function 'kotlin.arrayOfNulls' call
    var size = convertToInt(tmp$ret$2);
    tmp.ez_1 = Array(size);
  }
  protoOf(Cells_2).y = function (index) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.dz_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tmp0_safe_receiver = this.ez_1[index / 8192 | 0];
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver[index % 8192 | 0];
    return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  };
  protoOf(Cells_2).ww = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.dz_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var slot = index / 8192 | 0;
    var page = this.ez_1[slot];
    if (page == null) {
      if (value === 0)
        return Unit_instance;
      // Inline function 'kotlin.Long.times' call
      var this_0 = fromInt(slot);
      var start = multiply(this_0, fromInt(8192));
      var tmp0 = new Long(8192, 0);
      // Inline function 'kotlin.comparisons.minOf' call
      var b = subtract(fromInt(this.dz_1), start);
      var tmp$ret$2 = compare(tmp0, b) <= 0 ? tmp0 : b;
      page = new Int32Array(convertToInt(tmp$ret$2));
      this.ez_1[slot] = page;
    }
    page[index % 8192 | 0] = value;
  };
  protoOf(Cells_2).mz = function (end) {
    var start = new Long(0, 0);
    var indexedObject = this.ez_1;
    var inductionVariable = 0;
    var last = indexedObject.length;
    $l$loop: while (inductionVariable < last) {
      var page = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (compare(start, fromInt(end)) >= 0)
        break $l$loop;
      if (!(page == null)) {
        var tmp0 = fromInt(page.length);
        // Inline function 'kotlin.comparisons.minOf' call
        var b = subtract(fromInt(end), start);
        var tmp$ret$0 = compare(tmp0, b) <= 0 ? tmp0 : b;
        var count = convertToInt(tmp$ret$0);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < count)
          do {
            var i = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            if (!(page[i] === 0))
              return true;
          }
           while (inductionVariable_0 < count);
      }
      // Inline function 'kotlin.Long.plus' call
      var this_0 = start;
      start = add(this_0, fromInt(8192));
    }
    return false;
  };
  function Digits(capacity) {
    this.fz_1 = new Cells_2(capacity);
    this.gz_1 = 0;
  }
  protoOf(Digits).y = function (index) {
    return this.fz_1.y(index);
  };
  protoOf(Digits).ww = function (index, value) {
    this.fz_1.ww(index, value);
  };
  protoOf(Digits).nz = function (start, end, value) {
    var inductionVariable = start;
    if (inductionVariable < end)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.fz_1.ww(i, value);
      }
       while (inductionVariable < end);
  };
  protoOf(Digits).tx = function () {
    while (this.gz_1 > 0 && this.fz_1.y(this.gz_1 - 1 | 0) === 0) {
      this.gz_1 = this.gz_1 - 1 | 0;
    }
  };
  protoOf(Digits).sw = function () {
    // Inline function 'kotlin.check' call
    if (!(this.gz_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var width = 1;
    while (width < 9 && this.fz_1.y(this.gz_1 - 1 | 0) >= DecimalSum585_getInstance().zt_1[width]) {
      width = width + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.gz_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = width;
    return add(tmp0_0, fromInt(other_0));
  };
  protoOf(Digits).mz = function (end) {
    return this.fz_1.mz(end);
  };
  protoOf(Digits).oz = function (whole, divisor) {
    var result = new Digits((this.gz_1 - whole | 0) + 1 | 0);
    var remainder = new Long(0, 0);
    var inductionVariable = this.gz_1 - 1 | 0;
    if (whole <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.fz_1.y(i);
        var part = add(tmp0_0, fromInt(other_0));
        var tmp = i - whole | 0;
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(divisor));
        result.ww(tmp, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(divisor));
      }
       while (!(i === whole));
    result.gz_1 = this.gz_1 - whole | 0;
    result.tx();
    return result;
  };
  protoOf(Digits).cx = function () {
    var at = 0;
    while (at < this.gz_1 && this.fz_1.y(at) === 999999999) {
      this.fz_1.ww(at, 0);
      at = at + 1 | 0;
    }
    this.fz_1.ww(at, at === this.gz_1 ? 1 : this.fz_1.y(at) + 1 | 0);
    if (at === this.gz_1) {
      this.gz_1 = this.gz_1 + 1 | 0;
    }
  };
  protoOf(Digits).vw = function () {
    var remainder = new Long(0, 0);
    var inductionVariable = this.gz_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.fz_1.y(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(10));
        this.fz_1.ww(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(10));
      }
       while (0 <= inductionVariable);
    this.tx();
    return convertToInt(remainder);
  };
  function DecimalSum585() {
    DecimalSum585_instance = this;
    this.wt_1 = 1000000000;
    this.xt_1 = 8192;
    this.yt_1 = new Long(646456993, 0);
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.zt_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalSum585).au = function (leftSign, left, leftScale, rightSign, right, rightScale, context) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!((-1 <= leftSign ? leftSign <= 1 : false) && (-1 <= rightSign ? rightSign <= 1 : false))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    var tmp_0 = leftSign === 0;
    // Inline function 'kotlin.collections.isEmpty' call
    if (tmp_0 === (left.length === 0)) {
      var tmp_1 = rightSign === 0;
      // Inline function 'kotlin.collections.isEmpty' call
      tmp = tmp_1 === (right.length === 0);
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    // Inline function 'kotlin.comparisons.maxOf' call
    var scale = Math.max(leftScale, rightScale);
    var tmp1_elvis_lhs = context == null ? null : context.ol_1;
    var precision = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    var tmp0 = left.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = right.length;
    var tmp$ret$9 = Math.max(tmp0, b);
    var scratch = new Cells_2(tmp$ret$9);
    var a = decimal(this, left, scratch);
    var b_0 = decimal(this, right, scratch);
    var da = a.gz_1 === 0 ? 0 : convertToInt(a.sw());
    var db = b_0.gz_1 === 0 ? 0 : convertToInt(b_0.sw());
    if (!certifiedDecimalSumSpan585(da, db, leftScale, rightScale, precision))
      return null;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(scale);
    var tmp$ret$10 = subtract(this_0, fromInt(leftScale));
    var av = aligned(this, a, tmp$ret$10);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(scale);
    var tmp$ret$11 = subtract(this_1, fromInt(rightScale));
    var bv = aligned(this, b_0, tmp$ret$11);
    var order = compare_0(this, av, bv);
    if (!(leftSign === rightSign) && order === 0 || (leftSign === 0 && rightSign === 0))
      return to(Companion_getInstance_1().yj_1, scale);
    var subtract_0 = !(leftSign === 0) && !(rightSign === 0) && !(leftSign === rightSign);
    var high = subtract_0 && order < 0 ? bv : av;
    var low = subtract_0 && order < 0 ? av : bv;
    var sign = leftSign === 0 || (subtract_0 && order < 0) ? rightSign : leftSign;
    var tmp0_0 = high.jz();
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_1 = low.jz();
    var end = compare(tmp0_0, b_1) >= 0 ? tmp0_0 : b_1;
    var result = new Digits(convertToInt(add(end, new Long(1, 0))));
    var at = new Long(0, 0);
    var carry = 0;
    $l$loop: while (compare(at, end) < 0) {
      if (!high.vf(at) && !low.vf(at)) {
        var tmp0_1 = high.lz(at, end);
        // Inline function 'kotlin.comparisons.minOf' call
        var b_2 = low.lz(at, end);
        var next = compare(tmp0_1, b_2) <= 0 ? tmp0_1 : b_2;
        // Inline function 'kotlin.check' call
        if (!(compare(next, at) > 0)) {
          throw IllegalStateException_init_$Create$('Check failed.');
        }
        if (subtract_0) {
          if (!(carry === 0)) {
            result.nz(convertToInt(at), convertToInt(next), 999999999);
          }
        } else if (!(carry === 0)) {
          result.ww(convertToInt(at), 1);
          carry = 0;
        }
        at = next;
        continue $l$loop;
      }
      var h = high.kz(at);
      var l = low.kz(at);
      if (subtract_0) {
        // Inline function 'kotlin.Long.minus' call
        var this_2 = fromInt(h);
        var tmp0_2 = subtract(this_2, fromInt(l));
        // Inline function 'kotlin.Long.minus' call
        var other = carry;
        var part = subtract(tmp0_2, fromInt(other));
        var tmp_2 = convertToInt(at);
        var tmp_3;
        if (compare(part, new Long(0, 0)) < 0) {
          // Inline function 'kotlin.Long.plus' call
          var other_0 = 1000000000;
          tmp_3 = add(part, fromInt(other_0));
        } else {
          tmp_3 = part;
        }
        result.ww(tmp_2, convertToInt(tmp_3));
        carry = compare(part, new Long(0, 0)) < 0 ? 1 : 0;
      } else {
        // Inline function 'kotlin.Long.plus' call
        var this_3 = fromInt(h);
        var tmp0_3 = add(this_3, fromInt(l));
        // Inline function 'kotlin.Long.plus' call
        var other_1 = carry;
        var part_0 = add(tmp0_3, fromInt(other_1));
        var tmp_4 = convertToInt(at);
        // Inline function 'kotlin.Long.rem' call
        var other_2 = 1000000000;
        var tmp$ret$20 = modulo(part_0, fromInt(other_2));
        result.ww(tmp_4, convertToInt(tmp$ret$20));
        // Inline function 'kotlin.Long.div' call
        var other_3 = 1000000000;
        var tmp$ret$21 = divide(part_0, fromInt(other_3));
        carry = convertToInt(tmp$ret$21);
      }
      var _unary__edvuaz = at;
      at = add(_unary__edvuaz, get_ONE());
    }
    if (subtract_0) {
      // Inline function 'kotlin.check' call
      if (!(carry === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
    } else if (!(carry === 0)) {
      result.ww(convertToInt(end), carry);
    }
    result.gz_1 = convertToInt(end) + (!subtract_0 && !(carry === 0) ? 1 : 0) | 0;
    result.tx();
    if (result.gz_1 === 0)
      return to(Companion_getInstance_1().yj_1, scale);
    var digits = result.sw();
    if (precision === 0 || compare(digits, fromInt(precision)) <= 0)
      return publish_0(this, result, sign, scale);
    if (compare(fromInt(precision), new Long(646456993, 0)) > 0)
      return null;
    // Inline function 'kotlin.Long.minus' call
    var drop = subtract(digits, fromInt(precision));
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$24 = divide(drop, fromInt(9));
    var whole = convertToInt(tmp$ret$24);
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$25 = modulo(drop, fromInt(9));
    var tail = convertToInt(tmp$ret$25);
    var guardCell = tail === 0 ? whole - 1 | 0 : whole;
    var guardPlace = tail === 0 ? 8 : tail - 1 | 0;
    var guard = (result.y(guardCell) / this.zt_1[guardPlace] | 0) % 10 | 0;
    var sticky = !((result.y(guardCell) % this.zt_1[guardPlace] | 0) === 0) || result.mz(guardCell);
    var inexact = !(guard === 0) || sticky;
    // Inline function 'kotlin.checkNotNull' call
    var tmp$ret$27;
    $l$block: {
      // Inline function 'kotlin.checkNotNull' call
      if (context == null) {
        var message_1 = 'Required value was null.';
        throw IllegalStateException_init_$Create$(toString_0(message_1));
      } else {
        tmp$ret$27 = context;
        break $l$block;
      }
    }
    var mode = tmp$ret$27.pl_1;
    if (inexact && mode.equals(RoundingMode_UNNECESSARY_getInstance()))
      return null;
    var quotient = result.oz(whole, this.zt_1[tail]);
    var half = guard === 5 && sticky ? 1 : compareTo(guard, 5);
    var tmp_5;
    if (inexact) {
      var tmp_6;
      switch (mode.l2_1) {
        case 0:
          tmp_6 = true;
          break;
        case 1:
          tmp_6 = false;
          break;
        case 2:
          tmp_6 = sign > 0;
          break;
        case 3:
          tmp_6 = sign < 0;
          break;
        case 4:
          tmp_6 = half >= 0;
          break;
        case 5:
          tmp_6 = half > 0;
          break;
        case 6:
          tmp_6 = half > 0 || (half === 0 && !((quotient.y(0) % 2 | 0) === 0));
          break;
        case 7:
          tmp_6 = false;
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
      tmp_5 = tmp_6;
    } else {
      tmp_5 = false;
    }
    var increment = tmp_5;
    if (increment) {
      quotient.cx();
    }
    var finalScale = subtract(fromInt(scale), drop);
    if (compare(quotient.sw(), fromInt(precision)) > 0) {
      // Inline function 'kotlin.check' call
      if (!(quotient.vw() === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var _unary__edvuaz_0 = finalScale;
      finalScale = subtract(_unary__edvuaz_0, get_ONE());
    }
    if (!(compare(new Long(-2147483648, -1), finalScale) <= 0 ? compare(finalScale, new Long(2147483647, 0)) <= 0 : false))
      return null;
    return publish_0(this, quotient, sign, convertToInt(finalScale));
  };
  var DecimalSum585_instance;
  function DecimalSum585_getInstance() {
    if (DecimalSum585_instance == null)
      new DecimalSum585();
    return DecimalSum585_instance;
  }
  function materializedDecimalSum585(leftSign, rightSign, leftBits, rightBits, leftScale, rightScale) {
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$0 = Math.max(leftScale, rightScale);
    var scale = fromInt(tmp$ret$0);
    var limit = !(leftSign === 0) && leftSign === rightSign ? new Long(2147483646, 0) : new Long(2147483647, 0);
    return materializedDecimalSum585$supported(scale, limit, leftSign, leftBits, leftScale) && materializedDecimalSum585$supported(scale, limit, rightSign, rightBits, rightScale);
  }
  function certifiedDecimalSumSpan585(leftDigits, rightDigits, leftScale, rightScale, precision) {
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$0 = Math.max(leftScale, rightScale);
    var scale = fromInt(tmp$ret$0);
    var tmp;
    if (leftDigits === 0) {
      tmp = new Long(0, 0);
    } else {
      // Inline function 'kotlin.Long.minus' call
      var this_0 = add(fromInt(leftDigits), scale);
      tmp = subtract(this_0, fromInt(leftScale));
    }
    var left = tmp;
    var tmp_0;
    if (rightDigits === 0) {
      tmp_0 = new Long(0, 0);
    } else {
      // Inline function 'kotlin.Long.minus' call
      var this_1 = add(fromInt(rightDigits), scale);
      tmp_0 = subtract(this_1, fromInt(rightScale));
    }
    var right = tmp_0;
    // Inline function 'kotlin.comparisons.maxOf' call
    var largest = compare(left, right) >= 0 ? left : right;
    return precision === 0 || precision > 646456993 ? compare(largest, new Long(646456994, 0)) <= 0 : compare(largest, new Long(1292913989, 0)) <= 0;
  }
  function materializedDecimalSum585$supported(scale, limit, sign, bits, sourceScale) {
    if (sign === 0)
      return true;
    // Inline function 'kotlin.Long.minus' call
    var raise = subtract(scale, fromInt(sourceScale));
    return (compare(new Long(0, 0), raise) <= 0 ? compare(raise, new Long(646456992, 0)) <= 0 : false) && compare(add(fromInt(bits), multiply(new Long(4, 0), raise)), limit) <= 0;
  }
  function Lexical(sign, scale, first, digits, guard, sticky) {
    this.pz_1 = sign;
    this.qz_1 = scale;
    this.rz_1 = first;
    this.sz_1 = digits;
    this.tz_1 = guard;
    this.uz_1 = sticky;
  }
  function scan($this, input, precision) {
    if (input.tr_1 === 0)
      throw NumberFormatException_init_$Create$('Empty BigDecimal');
    var i = 0;
    var sign = 1;
    if (input.b(i) === _Char___init__impl__6a9atx(45) || input.b(i) === _Char___init__impl__6a9atx(43)) {
      if (input.b(i) === _Char___init__impl__6a9atx(45))
        sign = -1;
      i = i + 1 | 0;
    }
    var seenDigit = false;
    var point = false;
    var fraction = new Long(0, 0);
    var first = -1;
    var digits = new Long(0, 0);
    var guard = 0;
    var sticky = false;
    var guardOrdinal = add(fromInt(precision), new Long(1, 0));
    $l$loop: while (i < input.tr_1 && !(input.b(i) === _Char___init__impl__6a9atx(101)) && !(input.b(i) === _Char___init__impl__6a9atx(69))) {
      var at = i;
      var _unary__edvuaz = i;
      i = _unary__edvuaz + 1 | 0;
      var c = input.b(_unary__edvuaz);
      if (c === _Char___init__impl__6a9atx(46) && !point) {
        point = true;
        continue $l$loop;
      }
      var tmp0_elvis_lhs = numericDigit537(c, 10);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        throw NumberFormatException_init_$Create$('Invalid decimal digit');
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var digit = tmp;
      seenDigit = true;
      if (point) {
        var _unary__edvuaz_0 = fraction;
        fraction = add(_unary__edvuaz_0, get_ONE());
      }
      if (first < 0 && !(digit === 0))
        first = at;
      if (first >= 0) {
        var _unary__edvuaz_1 = digits;
        digits = add(_unary__edvuaz_1, get_ONE());
        if (precision > 0) {
          if (equalsLong(digits, guardOrdinal))
            guard = digit;
          else if (compare(digits, guardOrdinal) > 0 && !(digit === 0))
            sticky = true;
        }
      }
    }
    if (!seenDigit)
      throw NumberFormatException_init_$Create$('No digits');
    var exponent = new Long(0, 0);
    if (i < input.tr_1) {
      i = i + 1 | 0;
      var exponentSign = 1;
      if (i < input.tr_1 && (input.b(i) === _Char___init__impl__6a9atx(43) || input.b(i) === _Char___init__impl__6a9atx(45))) {
        if (input.b(i) === _Char___init__impl__6a9atx(45))
          exponentSign = -1;
        i = i + 1 | 0;
      }
      if (i === input.tr_1)
        throw NumberFormatException_init_$Create$('No exponent digits');
      while (i < input.tr_1) {
        var _unary__edvuaz_2 = i;
        i = _unary__edvuaz_2 + 1 | 0;
        var tmp1_elvis_lhs = numericDigit537(input.b(_unary__edvuaz_2), 10);
        var tmp_0;
        if (tmp1_elvis_lhs == null) {
          throw NumberFormatException_init_$Create$('Invalid exponent');
        } else {
          tmp_0 = tmp1_elvis_lhs;
        }
        var digit_0 = tmp_0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = exponent;
        // Inline function 'kotlin.Long.plus' call
        var this_1 = multiply(this_0, fromInt(10));
        exponent = add(this_1, fromInt(digit_0));
        var tmp_1 = exponent;
        // Inline function 'kotlin.Long.plus' call
        var this_2 = new Long(2147483647, 0);
        var tmp$ret$2 = add(this_2, fromInt(1));
        if (compare(tmp_1, add(tmp$ret$2, fraction)) > 0)
          throw NumberFormatException_init_$Create$('Exponent overflow');
      }
      var tmp0 = exponent;
      // Inline function 'kotlin.Long.times' call
      var other = exponentSign;
      exponent = multiply(tmp0, fromInt(other));
    }
    var scale = subtract(fraction, exponent);
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false))
      throw NumberFormatException_init_$Create$('Scale out of range');
    return new Lexical(sign, convertToInt(scale), first, digits, guard, sticky);
  }
  function parse_2($this, input, context) {
    var lexical = scan($this, input, context.ol_1);
    if (equalsLong(lexical.sz_1, new Long(0, 0)))
      return BigDecimal_init_$Create$_0(Companion_getInstance_1().yj_1, lexical.qz_1);
    var kept = retainedDecimalText588(lexical.sz_1, context.ol_1);
    if (compare(kept, new Long(646456993, 0)) > 0) {
      overflow($this);
    }
    if (context.ol_1 === 0)
      return Companion_getInstance_1().lt(input, lexical.rz_1, convertToInt(kept), lexical.pz_1, lexical.qz_1);
    var drop = subtract(lexical.sz_1, kept);
    var scale = roundingScale($this, subtract(fromInt(lexical.qz_1), drop));
    var inexact = !(lexical.tz_1 === 0) || lexical.uz_1;
    if (compare(drop, new Long(0, 0)) > 0 && inexact && context.pl_1.equals(RoundingMode_UNNECESSARY_getInstance()))
      throw ArithmeticException_init_$Create$('Rounding necessary');
    var prefix_0 = prefix($this, input, lexical.rz_1, convertToInt(kept));
    if (compare(drop, new Long(0, 0)) > 0 && inexact) {
      var half = lexical.tz_1 === 5 && lexical.uz_1 ? 1 : compareTo(lexical.tz_1, 5);
      var tmp;
      switch (context.pl_1.l2_1) {
        case 0:
          tmp = true;
          break;
        case 1:
          tmp = false;
          break;
        case 2:
          tmp = lexical.pz_1 > 0;
          break;
        case 3:
          tmp = lexical.pz_1 < 0;
          break;
        case 4:
          tmp = half >= 0;
          break;
        case 5:
          tmp = half > 0;
          break;
        case 6:
          tmp = half > 0 || (half === 0 && !((prefix_0.y(0) % 2 | 0) === 0));
          break;
        case 7:
          tmp = false;
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
      var increment = tmp;
      if (increment) {
        prefix_0.cx();
      }
    }
    if (compare(prefix_0.sw(), kept) > 0) {
      // Inline function 'kotlin.check' call
      if (!(prefix_0.vw() === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      // Inline function 'kotlin.Long.minus' call
      var this_0 = fromInt(scale);
      var tmp$ret$1 = subtract(this_0, fromInt(1));
      scale = roundingScale($this, tmp$ret$1);
    }
    return publishDecimal529($this, prefix_0, lexical.pz_1, scale);
  }
  function roundingScale($this, scale) {
    var narrowed = convertToInt(scale);
    if (!equalsLong(fromInt(narrowed), scale))
      throw ArithmeticException_init_$Create$(narrowed > 0 ? 'Underflow' : 'Overflow');
    return narrowed;
  }
  function overflow($this) {
    throw ArithmeticException_init_$Create$('BigInteger overflow');
  }
  function prefix($this, input, first, kept) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(kept);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(9));
    var tmp$ret$2 = add(this_2, fromInt(1));
    var result = new Digits_0(convertToInt(tmp$ret$2));
    var i = first;
    var consumed = 0;
    var block = 0;
    var inBlock = 0;
    $l$loop: while (consumed < kept) {
      var _unary__edvuaz = i;
      i = _unary__edvuaz + 1 | 0;
      var c = input.b(_unary__edvuaz);
      if (c === _Char___init__impl__6a9atx(46))
        continue $l$loop;
      var tmp = imul(block, 10);
      // Inline function 'kotlin.checkNotNull' call
      var tmp0 = numericDigit537(c, 10);
      var tmp$ret$4;
      $l$block: {
        // Inline function 'kotlin.checkNotNull' call
        if (tmp0 == null) {
          var message = 'Required value was null.';
          throw IllegalStateException_init_$Create$(toString_0(message));
        } else {
          tmp$ret$4 = tmp0;
          break $l$block;
        }
      }
      block = tmp + tmp$ret$4 | 0;
      consumed = consumed + 1 | 0;
      inBlock = inBlock + 1 | 0;
      if (inBlock === 9) {
        var _unary__edvuaz_0 = result.wz_1;
        result.wz_1 = _unary__edvuaz_0 + 1 | 0;
        result.ww(_unary__edvuaz_0, block);
        block = 0;
        inBlock = 0;
      }
    }
    var low = 0;
    var high = result.wz_1 - 1 | 0;
    while (low < high) {
      var cell = result.y(low);
      var _unary__edvuaz_1 = low;
      low = _unary__edvuaz_1 + 1 | 0;
      result.ww(_unary__edvuaz_1, result.y(high));
      var _unary__edvuaz_2 = high;
      high = _unary__edvuaz_2 - 1 | 0;
      result.ww(_unary__edvuaz_2, cell);
    }
    if (inBlock > 0) {
      var factor = $this.fj_1[inBlock];
      var carry = fromInt(block);
      var inductionVariable = 0;
      var last = result.wz_1;
      if (inductionVariable < last)
        do {
          var at = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          // Inline function 'kotlin.Long.times' call
          var this_3 = fromInt(result.y(at));
          var tmp$ret$6 = multiply(this_3, fromInt(factor));
          var part = add(tmp$ret$6, carry);
          // Inline function 'kotlin.Long.rem' call
          var other = 1000000000;
          var tmp$ret$7 = modulo(part, fromInt(other));
          result.ww(at, convertToInt(tmp$ret$7));
          // Inline function 'kotlin.Long.div' call
          var other_0 = 1000000000;
          carry = divide(part, fromInt(other_0));
        }
         while (inductionVariable < last);
      if (!equalsLong(carry, new Long(0, 0))) {
        var _unary__edvuaz_3 = result.wz_1;
        result.wz_1 = _unary__edvuaz_3 + 1 | 0;
        result.ww(_unary__edvuaz_3, convertToInt(carry));
      }
    }
    // Inline function 'kotlin.check' call
    if (!(result.wz_1 > 0 && !(result.y(result.wz_1 - 1 | 0) === 0))) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return result;
  }
  function Cells_3(capacity) {
    this.xz_1 = capacity;
    var tmp = this;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(this.xz_1);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(8192));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = divide(this_2, fromInt(8192));
    // Inline function 'kotlin.arrayOfNulls' call
    var size = convertToInt(tmp$ret$2);
    tmp.yz_1 = Array(size);
  }
  protoOf(Cells_3).y = function (index) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.xz_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tmp0_safe_receiver = this.yz_1[index / 8192 | 0];
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver[index % 8192 | 0];
    return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  };
  protoOf(Cells_3).ww = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.xz_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var slot = index / 8192 | 0;
    var page = this.yz_1[slot];
    if (page == null) {
      if (value === 0)
        return Unit_instance;
      // Inline function 'kotlin.comparisons.minOf' call
      var b = this.xz_1 - imul(slot, 8192) | 0;
      var tmp$ret$1 = Math.min(8192, b);
      page = new Int32Array(tmp$ret$1);
      this.yz_1[slot] = page;
    }
    page[index % 8192 | 0] = value;
  };
  function Digits_0(capacity) {
    this.vz_1 = new Cells_3(capacity);
    this.wz_1 = 0;
  }
  protoOf(Digits_0).y = function (index) {
    return this.vz_1.y(index);
  };
  protoOf(Digits_0).ww = function (index, value) {
    this.vz_1.ww(index, value);
  };
  protoOf(Digits_0).sw = function () {
    var top = this.vz_1.y(this.wz_1 - 1 | 0);
    var count = 0;
    do {
      count = count + 1 | 0;
      top = top / 10 | 0;
    }
     while (!(top === 0));
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.wz_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = count;
    return add(tmp0_0, fromInt(other_0));
  };
  protoOf(Digits_0).cx = function () {
    var i = 0;
    while (i < this.wz_1 && this.vz_1.y(i) === 999999999) {
      this.vz_1.ww(i, 0);
      i = i + 1 | 0;
    }
    if (i === this.wz_1) {
      this.vz_1.ww(i, 1);
      this.wz_1 = this.wz_1 + 1 | 0;
    } else {
      this.vz_1.ww(i, this.vz_1.y(i) + 1 | 0);
    }
  };
  protoOf(Digits_0).vw = function () {
    var remainder = new Long(0, 0);
    var inductionVariable = this.wz_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.vz_1.y(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(10));
        this.vz_1.ww(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(10));
      }
       while (0 <= inductionVariable);
    while (this.wz_1 > 0 && this.vz_1.y(this.wz_1 - 1 | 0) === 0) {
      this.wz_1 = this.wz_1 - 1 | 0;
    }
    // Inline function 'kotlin.check' call
    if (!(this.wz_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return convertToInt(remainder);
  };
  function publishDecimal529($this, decimal, sign, scale) {
    if (decimal.wz_1 <= 3) {
      var negative = new Long(0, 0);
      var compact = true;
      var inductionVariable = decimal.wz_1 - 1 | 0;
      if (0 <= inductionVariable)
        $l$loop_0: do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + -1 | 0;
          var block = decimal.y(index);
          var tmp = negative;
          var tmp0 = new Long(0, -2147483648);
          // Inline function 'kotlin.Long.div' call
          var other = 1000000000;
          var tmp$ret$0 = divide(tmp0, fromInt(other));
          if (compare(tmp, tmp$ret$0) < 0) {
            compact = false;
            break $l$loop_0;
          }
          var tmp0_0 = negative;
          // Inline function 'kotlin.Long.times' call
          var other_0 = 1000000000;
          var product = multiply(tmp0_0, fromInt(other_0));
          // Inline function 'kotlin.Long.plus' call
          var this_0 = new Long(0, -2147483648);
          var tmp$ret$2 = add(this_0, fromInt(block));
          if (compare(product, tmp$ret$2) < 0) {
            compact = false;
            break $l$loop_0;
          }
          // Inline function 'kotlin.Long.minus' call
          negative = subtract(product, fromInt(block));
        }
         while (0 <= inductionVariable);
      if (compact && (sign < 0 || !equalsLong(negative, new Long(0, -2147483648))))
        return Companion_getInstance().fn(sign < 0 ? negative : negate(negative), scale);
    }
    return BigDecimal_init_$Create$_0(publish_1($this, decimal, sign), scale);
  }
  function publish_1($this, decimal, sign) {
    var tmp0 = new Long(2147483647, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(new Long(4, 0), decimal.sw());
    var bound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bound, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = divide(this_0, fromInt(30));
    var tmp$ret$3 = add(this_1, fromInt(1));
    var binary = new Cells_3(convertToInt(tmp$ret$3));
    var size = 0;
    var inductionVariable = decimal.wz_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var carry = fromInt(decimal.y(i));
        var j = 0;
        while (j < size) {
          var tmp0_0 = fromInt(binary.y(j));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$4 = multiply(tmp0_0, fromInt(other));
          var part = add(tmp$ret$4, carry);
          binary.ww(j, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
          j = j + 1 | 0;
        }
        if (!equalsLong(carry, new Long(0, 0))) {
          var _unary__edvuaz = size;
          size = _unary__edvuaz + 1 | 0;
          binary.ww(_unary__edvuaz, convertToInt(carry));
        }
        var tmp0_1 = new Long(30, 0);
        // Inline function 'kotlin.Long.times' call
        var other_0 = size - 1 | 0;
        // Inline function 'kotlin.Long.plus' call
        var this_2 = multiply(tmp0_1, fromInt(other_0));
        var tmp0_2 = add(this_2, fromInt(32));
        // Inline function 'kotlin.countLeadingZeroBits' call
        var this_3 = binary.y(size - 1 | 0);
        // Inline function 'kotlin.Long.minus' call
        var other_1 = clz32(this_3);
        var bits = subtract(tmp0_2, fromInt(other_1));
        if (compare(bits, new Long(2147483647, 0)) > 0) {
          overflow($this);
        }
      }
       while (0 <= inductionVariable);
    var tmp0_3 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_4 = multiply(tmp0_3, fromInt(other_2));
    var tmp0_4 = add(this_4, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_5 = binary.y(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_5);
    var bits_0 = subtract(tmp0_4, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_6 = add(bits_0, fromInt(7));
    var tmp$ret$14 = divide(this_6, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$14));
    var inductionVariable_0 = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_7 = new Long(8, 0);
        var bit = multiply(this_7, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$16 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$16);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$17 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$17);
        var value = shiftRightUnsigned(fromInt(binary.y(word)), offset);
        if (offset > 22 && (word + 1 | 0) < size)
          value = bitwiseOr(value, shiftLeft(fromInt(binary.y(word + 1 | 0)), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last);
    return BigInteger_init_$Create$_6(sign, bytes);
  }
  function DecimalText588() {
    DecimalText588_instance = this;
    this.cj_1 = new Long(646456993, 0);
    this.dj_1 = 1000000000;
    this.ej_1 = 8192;
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.fj_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalText588).gj = function (value, context) {
    return parse_2(this, Companion_instance_6.pr(value), context);
  };
  protoOf(DecimalText588).in = function (value, offset, length, context) {
    return parse_2(this, Companion_instance_6.ws(value, offset, length), context);
  };
  protoOf(DecimalText588).nn = function (value, offset, length, maxInputChars, context) {
    return parse_2(this, Companion_instance_6.ws(value, offset, length).ct(maxInputChars), context);
  };
  protoOf(DecimalText588).qn = function (value, offset, length, maxInputChars, context) {
    return parse_2(this, Companion_instance_6.zs(value, offset, length).ct(maxInputChars), context);
  };
  protoOf(DecimalText588).il = function (value, offset, length, context) {
    return parse_2(this, Companion_instance_6.zs(value, offset, length), context);
  };
  var DecimalText588_instance;
  function DecimalText588_getInstance() {
    if (DecimalText588_instance == null)
      new DecimalText588();
    return DecimalText588_instance;
  }
  function retainedDecimalText588(digits, precision) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(digits, new Long(0, 0)) >= 0 && precision >= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    if (precision === 0) {
      tmp = digits;
    } else {
      // Inline function 'kotlin.comparisons.minOf' call
      var b = fromInt(precision);
      tmp = compare(digits, b) <= 0 ? digits : b;
    }
    return tmp;
  }
  function decimalDoubleString(value) {
    if (!isFinite(value))
      throw NumberFormatException_init_$Create$('Infinite or NaN');
    if (value === 0.0)
      return '0.0';
    var magnitude = value < 0 ? -value : value;
    var stripped = shortestDoubleDecimal(magnitude).zo();
    var tmp0 = fromInt(stripped.ql());
    // Inline function 'kotlin.Long.minus' call
    var other = stripped.vn();
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    var exponent = subtract(this_0, fromInt(1));
    // Inline function 'kotlin.ranges.contains' call
    var this_1 = numberRangeToNumber(-3, 6);
    if (contains(isInterface(this_1, ClosedRange) ? this_1 : THROW_CCE(), exponent)) {
      var plain = stripped.cm();
      var text = contains_0(plain, _Char___init__impl__6a9atx(46)) ? plain : plain + '.0';
      return (value < 0 ? '-' : '') + text;
    }
    var digits = stripped.un().xk().toString();
    // Inline function 'kotlin.text.plus' call
    var this_2 = charCodeAt(digits, 0);
    var mantissa = toString(this_2) + '.' + (digits.length === 1 ? '0' : substring(digits, 1));
    return (value < 0 ? '-' : '') + mantissa + 'E' + exponent.toString();
  }
  function shortestDoubleDecimal(magnitude) {
    var exact = BigDecimal_init_$Create$_14(magnitude);
    var exactDigits = exact.un().toString();
    var exponent = (exactDigits.length - exact.vn() | 0) - 1 | 0;
    var bits = toBits(magnitude);
    // Inline function 'kotlin.Long.minus' call
    // Inline function 'kotlin.fromBits' call
    var bits_0 = subtract(bits, fromInt(1));
    var tmp$ret$1 = doubleFromBits(bits_0);
    var previous = BigDecimal_init_$Create$_14(tmp$ret$1);
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.fromBits' call
    var bits_1 = add(bits, fromInt(1));
    var next = doubleFromBits(bits_1);
    var successor = isFinite(next) ? BigDecimal_init_$Create$_14(next) : null;
    var includesMidpoints = equalsLong(bitwiseAnd(bits, new Long(1, 0)), new Long(0, 0));
    var tmp0 = exact.vn();
    var tmp2 = previous.vn();
    var tmp1_elvis_lhs = successor == null ? null : successor.vn();
    // Inline function 'kotlin.comparisons.maxOf' call
    var c = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    var tmp0_0 = Math.max(tmp0, tmp2, c);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = 16 - exponent | 0;
    var commonScale = Math.max(tmp0_0, b) + 1 | 0;
    var exactCoefficient = exact.rl(commonScale).un();
    var previousCoefficient = previous.rl(commonScale).un();
    var lowerCoefficient = exactCoefficient.al(previousCoefficient).wl(1);
    var tmp;
    if (!(successor == null)) {
      tmp = exactCoefficient.al(successor.rl(commonScale).un()).wl(1);
    } else {
      tmp = exactCoefficient.al(exactCoefficient.yk(previousCoefficient).wl(1));
    }
    var upperCoefficient = tmp;
    // Inline function 'kotlin.collections.buildList' call
    // Inline function 'kotlin.collections.buildListInternal' call
    // Inline function 'kotlin.apply' call
    var this_0 = ArrayList_init_$Create$();
    var unit = Companion_getInstance_1().bk_1.gk((commonScale + exponent | 0) - 16 | 0);
    // Inline function 'kotlin.repeat' call
    var inductionVariable = 0;
    if (inductionVariable < 17)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this_0.w(unit);
        unit = unit.hk(Companion_getInstance_1().bk_1);
      }
       while (inductionVariable < 17);
    var units = this_0.s4();
    var inductionVariable_0 = 2;
    if (inductionVariable_0 <= 17)
      do {
        var digits = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        var minimum = Companion_getInstance_1().bk_1.gk(digits - 1 | 0);
        var maximum = minimum.hk(Companion_getInstance_1().bk_1).yk(Companion_getInstance_1().zj_1);
        var best = null;
        var bestDistance = null;
        var offsets = digits === 2 ? numberRangeToNumber(-1, 1) : numberRangeToNumber(0, 0);
        var inductionVariable_1 = offsets.kf_1;
        var last = offsets.lf_1;
        if (inductionVariable_1 <= last)
          do {
            var offset = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var scale = ((digits - 1 | 0) - exponent | 0) - offset | 0;
            var unit_0 = units.y((17 - digits | 0) + offset | 0);
            var length = digits - offset | 0;
            var floor = BigInteger_init_$Create$_2(padEnd(take(exactDigits, length), length, _Char___init__impl__6a9atx(48)));
            var _iterator__ex2g4s = listOf([floor, floor.al(Companion_getInstance_1().zj_1)]).o();
            $l$loop: while (_iterator__ex2g4s.p()) {
              var coefficient = _iterator__ex2g4s.q();
              var bounded = coefficient.zk(minimum) < 0 ? minimum : coefficient.zk(maximum) > 0 ? maximum : coefficient;
              var aligned = bounded.hk(unit_0);
              var lowerComparison = aligned.zk(lowerCoefficient);
              var upperComparison = aligned.zk(upperCoefficient);
              if (lowerComparison < 0 || upperComparison > 0 || (!includesMidpoints && (lowerComparison === 0 || upperComparison === 0)))
                continue $l$loop;
              var decimal = BigDecimal_init_$Create$_0(bounded, scale).zo();
              var distance = exactCoefficient.yk(aligned).xk();
              var tmp2_safe_receiver = bestDistance;
              var tmp_0;
              if (tmp2_safe_receiver == null) {
                tmp_0 = null;
              } else {
                // Inline function 'kotlin.let' call
                tmp_0 = distance.zk(tmp2_safe_receiver);
              }
              var tmp3_elvis_lhs = tmp_0;
              var comparison = tmp3_elvis_lhs == null ? -1 : tmp3_elvis_lhs;
              if (comparison < 0 || (comparison === 0 && !decimal.un().bl(0))) {
                best = decimal;
                bestDistance = distance;
              }
            }
          }
           while (!(offset === last));
        if (!(best == null))
          return best;
      }
       while (inductionVariable_0 <= 17);
    // Inline function 'kotlin.error' call
    var message = 'No seventeen-digit round-trip decimal';
    throw IllegalStateException_init_$Create$(toString_0(message));
  }
  function Decimals() {
  }
  protoOf(Decimals).zz = function (value) {
    return BigDecimal_init_$Create$_14(value);
  };
  protoOf(Decimals).a10 = function (value, context) {
    return BigDecimal_init_$Create$_15(value, context);
  };
  protoOf(Decimals).b10 = function (value) {
    return Companion_getInstance().gn(value);
  };
  protoOf(Decimals).c10 = function (value, context) {
    var canonical = Companion_getInstance().gn(value);
    return BigDecimal_init_$Create$_3(canonical.un(), canonical.vn(), context);
  };
  protoOf(Decimals).d10 = function (text) {
    return toBigDecimalOrNull(text);
  };
  protoOf(Decimals).e10 = function (text, context) {
    return toBigDecimalOrNull_0(text, context);
  };
  var Decimals_instance;
  function Decimals_getInstance() {
    return Decimals_instance;
  }
  function divideExact(_this__u8e3s4, divisor) {
    return _this__u8e3s4.go(divisor);
  }
  function roundToPrecision(_this__u8e3s4, precision, mode) {
    return _this__u8e3s4.rk(new MathContext(precision, mode));
  }
  function roundToScale(_this__u8e3s4, scale, mode) {
    return _this__u8e3s4.ro(scale, mode);
  }
  function Value(value) {
    this.f10_1 = value;
  }
  protoOf(Value).toString = function () {
    return 'Value(value=' + toString_1(this.f10_1) + ')';
  };
  protoOf(Value).hashCode = function () {
    return this.f10_1 == null ? 0 : hashCode(this.f10_1);
  };
  protoOf(Value).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Value))
      return false;
    if (!equals(this.f10_1, other.f10_1))
      return false;
    return true;
  };
  function Failure(cause) {
    this.g10_1 = cause;
  }
  protoOf(Failure).toString = function () {
    return 'Failure(cause=' + this.g10_1.toString() + ')';
  };
  protoOf(Failure).hashCode = function () {
    return hashCode(this.g10_1);
  };
  protoOf(Failure).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Failure))
      return false;
    if (!equals(this.g10_1, other.g10_1))
      return false;
    return true;
  };
  function toLongExactResult(_this__u8e3s4) {
    // Inline function 'io.heapy.krogu.math.exactConversion' call
    var tmp;
    try {
      var tmp$ret$1 = _this__u8e3s4.xm();
      tmp = new Value(tmp$ret$1);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var failure = $p;
        tmp_0 = new Failure(failure);
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function toBigIntegerExactResult(_this__u8e3s4) {
    // Inline function 'io.heapy.krogu.math.exactConversion' call
    var tmp;
    try {
      var tmp$ret$1 = _this__u8e3s4.jq();
      tmp = new Value(tmp$ret$1);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var failure = $p;
        tmp_0 = new Failure(failure);
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function toIntExactResult(_this__u8e3s4) {
    // Inline function 'io.heapy.krogu.math.exactConversion' call
    var tmp;
    try {
      var tmp$ret$1 = _this__u8e3s4.nq();
      tmp = new Value(tmp$ret$1);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var failure = $p;
        tmp_0 = new Failure(failure);
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function toLongExactResult_0(_this__u8e3s4) {
    // Inline function 'io.heapy.krogu.math.exactConversion' call
    var tmp;
    try {
      var tmp$ret$1 = _this__u8e3s4.xm();
      tmp = new Value(tmp$ret$1);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var failure = $p;
        tmp_0 = new Failure(failure);
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function toIntExactResult_0(_this__u8e3s4) {
    // Inline function 'io.heapy.krogu.math.exactConversion' call
    var tmp;
    try {
      var tmp$ret$1 = _this__u8e3s4.nq();
      tmp = new Value(tmp$ret$1);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var failure = $p;
        tmp_0 = new Failure(failure);
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function QuotientRemainder(quotient, remainder) {
    this.h10_1 = quotient;
    this.i10_1 = remainder;
  }
  protoOf(QuotientRemainder).toString = function () {
    return 'QuotientRemainder(quotient=' + toString_1(this.h10_1) + ', remainder=' + toString_1(this.i10_1) + ')';
  };
  protoOf(QuotientRemainder).hashCode = function () {
    var result = this.h10_1 == null ? 0 : hashCode(this.h10_1);
    result = imul(result, 31) + (this.i10_1 == null ? 0 : hashCode(this.i10_1)) | 0;
    return result;
  };
  protoOf(QuotientRemainder).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof QuotientRemainder))
      return false;
    if (!equals(this.h10_1, other.h10_1))
      return false;
    if (!equals(this.i10_1, other.i10_1))
      return false;
    return true;
  };
  function quotientAndRemainder(_this__u8e3s4, divisor) {
    // Inline function 'kotlin.let' call
    var it = _this__u8e3s4.wk(divisor);
    return new QuotientRemainder(it[0], it[1]);
  }
  function quotientAndRemainder_0(_this__u8e3s4, divisor) {
    // Inline function 'kotlin.let' call
    var it = _this__u8e3s4.vo(divisor);
    return new QuotientRemainder(it[0], it[1]);
  }
  function quotientAndRemainder_1(_this__u8e3s4, divisor, context) {
    // Inline function 'kotlin.let' call
    var it = _this__u8e3s4.wo(divisor, context);
    return new QuotientRemainder(it[0], it[1]);
  }
  function decimalFloatString(value) {
    var raw = toBits_0(value);
    var bits = raw & 2147483647;
    if (bits >= 2139095040)
      throw NumberFormatException_init_$Create$('Infinite or NaN');
    if (bits === 0)
      return '0.0';
    var selected = selectFloatDecimal(bits);
    var digits = selected.un().toString();
    var exponent = (digits.length - selected.vn() | 0) - 1 | 0;
    var tmp;
    if (-3 <= exponent ? exponent <= 6 : false) {
      var plain = selected.cm();
      tmp = contains_0(plain, _Char___init__impl__6a9atx(46)) ? plain : plain + '.0';
    } else {
      var fraction = digits.length === 1 ? '0' : substring(digits, 1);
      // Inline function 'kotlin.text.plus' call
      var this_0 = charCodeAt(digits, 0);
      tmp = toString(this_0) + '.' + fraction + 'E' + exponent;
    }
    var unsigned = tmp;
    return raw < 0 ? '-' + unsigned : unsigned;
  }
  function selectFloatDecimal(bits) {
    var factor = Companion_getInstance_1().fk(new Long(5, 0)).gk(150);
    var center = floatLatticeInteger(bits);
    var exact = center.ik(1).hk(factor);
    var lower = center.al(floatLatticeInteger(bits - 1 | 0)).hk(factor);
    var upper = center.al(floatLatticeInteger(bits + 1 | 0)).hk(factor);
    var closed = (bits & 1) === 0;
    var exactDigits = exact.toString();
    var exponent = exactDigits.length - 151 | 0;
    // Inline function 'kotlin.collections.buildList' call
    // Inline function 'kotlin.collections.buildListInternal' call
    // Inline function 'kotlin.apply' call
    var this_0 = ArrayList_init_$Create$();
    var unit = Companion_getInstance_1().bk_1.gk((150 + exponent | 0) - 8 | 0);
    // Inline function 'kotlin.repeat' call
    var inductionVariable = 0;
    if (inductionVariable < 9)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this_0.w(unit);
        unit = unit.hk(Companion_getInstance_1().bk_1);
      }
       while (inductionVariable < 9);
    var units = this_0.s4();
    var inductionVariable_0 = 2;
    if (inductionVariable_0 <= 9)
      do {
        var budget = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        var first = Companion_getInstance_1().bk_1.gk(budget - 1 | 0);
        var last = first.hk(Companion_getInstance_1().bk_1).yk(Companion_getInstance_1().zj_1);
        var chosen = null;
        var distance = null;
        var progression = budget === 2 ? numberRangeToNumber(-1, 1) : numberRangeToNumber(0, 0);
        var inductionVariable_1 = progression.kf_1;
        var last_0 = progression.lf_1;
        if (inductionVariable_1 <= last_0)
          do {
            var offset = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var scale = ((budget - 1 | 0) - exponent | 0) - offset | 0;
            var unit_0 = units.y((9 - budget | 0) + offset | 0);
            var prefixLength = budget - offset | 0;
            var floor = BigInteger_init_$Create$_2(padEnd(take(exactDigits, prefixLength), prefixLength, _Char___init__impl__6a9atx(48)));
            var _iterator__ex2g4s = listOf([floor, floor.al(Companion_getInstance_1().zj_1)]).o();
            $l$loop: while (_iterator__ex2g4s.p()) {
              var unbounded = _iterator__ex2g4s.q();
              var coefficient = unbounded.zk(first) < 0 ? first : unbounded.zk(last) > 0 ? last : unbounded;
              var aligned = coefficient.hk(unit_0);
              var low = aligned.zk(lower);
              var high = aligned.zk(upper);
              if (low < 0 || high > 0 || (!closed && (low === 0 || high === 0)))
                continue $l$loop;
              var candidate = BigDecimal_init_$Create$_0(coefficient, scale).zo();
              var delta = exact.yk(aligned).xk();
              var tmp0_safe_receiver = distance;
              var tmp;
              if (tmp0_safe_receiver == null) {
                tmp = null;
              } else {
                // Inline function 'kotlin.let' call
                tmp = delta.zk(tmp0_safe_receiver);
              }
              var tmp1_elvis_lhs = tmp;
              var order = tmp1_elvis_lhs == null ? -1 : tmp1_elvis_lhs;
              if (order < 0 || (order === 0 && !candidate.un().bl(0))) {
                chosen = candidate;
                distance = delta;
              }
            }
          }
           while (!(offset === last_0));
        if (!(chosen == null))
          return chosen;
      }
       while (inductionVariable_0 <= 9);
    // Inline function 'kotlin.error' call
    var message = 'No nine-digit binary32 round-trip decimal';
    throw IllegalStateException_init_$Create$(toString_0(message));
  }
  function floatLatticeInteger(bits) {
    var field = bits >>> 23 | 0;
    var fraction = bits & 8388607;
    var significand = field === 0 ? fraction : fraction + 8388608 | 0;
    return Companion_getInstance_1().fk(fromInt(significand)).ik(field === 0 ? 0 : field - 1 | 0);
  }
  function MagnitudeLimits() {
    this.yr_1 = 30;
    this.zr_1 = 268435456;
  }
  protoOf(MagnitudeLimits).is = function (byteCount, extraCarryBit) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(byteCount >= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (byteCount > 268435456)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(byteCount);
    var tmp0 = multiply(this_0, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var other = extraCarryBit ? 1 : 0;
    var bits = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(bits, fromInt(30));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$7 = divide(this_2, fromInt(30));
    return convertToInt(tmp$ret$7);
  };
  protoOf(MagnitudeLimits).fs = function (wordCount, highWord) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(wordCount > 0 && (1 <= highWord ? highWord < 1073741824 : false))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(wordCount);
    // Inline function 'kotlin.Long.times' call
    var this_1 = subtract(this_0, fromInt(1));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = multiply(this_1, fromInt(30));
    var tmp0 = add(this_2, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    // Inline function 'kotlin.Long.minus' call
    var other = clz32(highWord);
    var bits = subtract(tmp0, fromInt(other));
    if (compare(bits, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    return convertToInt(bits);
  };
  protoOf(MagnitudeLimits).as = function (significantDigits, radix) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(significantDigits > 0 && (2 <= radix ? radix <= 36 : false))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.countLeadingZeroBits' call
    var bitsPerDigit = 31 - clz32(radix) | 0;
    var tmp = new Long(1, 0);
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(significantDigits);
    // Inline function 'kotlin.Long.times' call
    var this_1 = subtract(this_0, fromInt(1));
    var tmp$ret$5 = multiply(this_1, fromInt(bitsPerDigit));
    var minimumBits = add(tmp, tmp$ret$5);
    return compare(minimumBits, new Long(2147483647, 0)) > 0;
  };
  protoOf(MagnitudeLimits).ps = function (bitLength) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(bitLength);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(1));
    var tmp$ret$1 = divide(this_1, fromInt(2));
    return convertToInt(tmp$ret$1);
  };
  var MagnitudeLimits_instance;
  function MagnitudeLimits_getInstance() {
    return MagnitudeLimits_instance;
  }
  function copiedChildInputs539$copies(a, ao, al, b, bo, bl) {
    var left = copyOfRange(a, ao, ao + al | 0);
    var right = a === b && ao === bo && al === bl ? left : copyOfRange(b, bo, bo + bl | 0);
    return to(left, right);
  }
  function multiplyRange539($this, a, ao, al, b, bo, bl, policy) {
    var out = new Int32Array(checkedOutput539($this, al, bl));
    var arena = new Arena($this.m10(al, bl, policy.j10_1));
    product($this, a, ao, al, b, bo, bl, out, 0, arena, policy.j10_1, policy.k10_1);
    return out;
  }
  function checkedOutput539($this, a, b) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(a);
    var size = add(this_0, fromInt(b));
    if (compare(size, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    return convertToInt(size);
  }
  function ParallelFrame539(a, b, policy) {
    this.n10_1 = a;
    this.o10_1 = b;
    this.p10_1 = policy;
    var tmp = this;
    var tmp0 = this.n10_1.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_0 = this.o10_1.length;
    tmp.q10_1 = Math.max(tmp0, b_0) / 2 | 0;
    var tmp_0 = this;
    var tmp0_0 = this.n10_1.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b_1 = this.q10_1;
    tmp_0.r10_1 = Math.min(tmp0_0, b_1);
    var tmp_1 = this;
    var tmp0_1 = this.o10_1.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b_2 = this.q10_1;
    tmp_1.s10_1 = Math.min(tmp0_1, b_2);
    this.t10_1 = this.n10_1.length - this.r10_1 | 0;
    this.u10_1 = this.o10_1.length - this.s10_1 | 0;
    var tmp_2 = this;
    var tmp0_2 = this.r10_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_3 = this.t10_1;
    var tmp$ret$3 = Math.max(tmp0_2, b_3);
    tmp_2.v10_1 = new Int32Array(tmp$ret$3 + 1 | 0);
    this.w10_1 = sum(MagnitudeMultiplication_getInstance(), this.n10_1, 0, this.r10_1, this.r10_1, this.t10_1, this.v10_1, 0, this.v10_1.length);
    var tmp_3 = this;
    var tmp_4;
    if (this.n10_1 === this.o10_1) {
      tmp_4 = this.v10_1;
    } else {
      var tmp0_3 = this.s10_1;
      // Inline function 'kotlin.comparisons.maxOf' call
      var b_4 = this.u10_1;
      var tmp$ret$4 = Math.max(tmp0_3, b_4);
      tmp_4 = new Int32Array(tmp$ret$4 + 1 | 0);
    }
    tmp_3.x10_1 = tmp_4;
    this.y10_1 = this.n10_1 === this.o10_1 ? this.w10_1 : sum(MagnitudeMultiplication_getInstance(), this.o10_1, 0, this.s10_1, this.s10_1, this.u10_1, this.x10_1, 0, this.x10_1.length);
  }
  protoOf(ParallelFrame539).z10 = function (index) {
    var tmp;
    switch (index) {
      case 0:
        tmp = multiplyRange539(MagnitudeMultiplication_getInstance(), this.n10_1, 0, this.r10_1, this.o10_1, 0, this.s10_1, this.p10_1);
        break;
      case 1:
        tmp = multiplyRange539(MagnitudeMultiplication_getInstance(), this.n10_1, this.r10_1, this.t10_1, this.o10_1, this.s10_1, this.u10_1, this.p10_1);
        break;
      case 2:
        tmp = multiplyRange539(MagnitudeMultiplication_getInstance(), this.v10_1, 0, this.w10_1, this.x10_1, 0, this.y10_1, this.p10_1);
        break;
      default:
        throw IllegalArgumentException_init_$Create$('Child index');
    }
    return tmp;
  };
  protoOf(ParallelFrame539).a11 = function (index) {
    var tmp;
    switch (index) {
      case 0:
        tmp = copiedChildInputs539$copies(this.n10_1, 0, this.r10_1, this.o10_1, 0, this.s10_1);
        break;
      case 1:
        tmp = copiedChildInputs539$copies(this.n10_1, this.r10_1, this.t10_1, this.o10_1, this.s10_1, this.u10_1);
        break;
      case 2:
        tmp = copiedChildInputs539$copies(this.v10_1, 0, this.w10_1, this.x10_1, 0, this.y10_1);
        break;
      default:
        throw IllegalArgumentException_init_$Create$('Child index');
    }
    return tmp;
  };
  protoOf(ParallelFrame539).b11 = function (low, high, middle) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(low.length === (this.r10_1 + this.s10_1 | 0) && high.length === (this.t10_1 + this.u10_1 | 0) && middle.length === (this.w10_1 + this.y10_1 | 0))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(!(low === high) && !(low === middle) && !(high === middle))) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    var out = new Int32Array(checkedOutput539(MagnitudeMultiplication_getInstance(), this.n10_1.length, this.o10_1.length));
    // Inline function 'kotlin.collections.copyInto' call
    var endIndex = low.length;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp = low;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp, out, 0, 0, endIndex);
    // Inline function 'kotlin.collections.copyInto' call
    var destinationOffset = imul(2, this.q10_1);
    var endIndex_0 = high.length;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_0 = high;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp_0, out, destinationOffset, 0, endIndex_0);
    subtract_0(MagnitudeMultiplication_getInstance(), middle, 0, middle.length, low, 0, low.length);
    subtract_0(MagnitudeMultiplication_getInstance(), middle, 0, middle.length, high, 0, high.length);
    addAt(MagnitudeMultiplication_getInstance(), out, this.q10_1, middle, 0, trimmed(MagnitudeMultiplication_getInstance(), middle, 0, middle.length));
    return out;
  };
  function Arena(size) {
    this.c11_1 = new Int32Array(size);
    this.d11_1 = 0;
  }
  protoOf(Arena).e11 = function (size) {
    var offset = this.d11_1;
    // Inline function 'kotlin.check' call
    if (!(size <= (this.c11_1.length - offset | 0))) {
      var message = 'Multiplication scratch bound';
      throw IllegalStateException_init_$Create$(toString_0(message));
    }
    this.d11_1 = this.d11_1 + size | 0;
    return offset;
  };
  function product($this, a, ao, al, b, bo, bl, out, oo, arena, threshold, squareThreshold) {
    fill(out, 0, oo, (oo + al | 0) + bl | 0);
    if (al === 0 || bl === 0)
      return Unit_instance;
    // Inline function 'kotlin.comparisons.minOf' call
    var small = Math.min(al, bl);
    // Inline function 'kotlin.comparisons.maxOf' call
    var large = Math.max(al, bl);
    if (small < threshold) {
      if (a === b && ao === bo && al === bl && al >= squareThreshold) {
        square($this, a, ao, al, out, oo);
      } else {
        school($this, a, ao, al, b, bo, bl, out, oo);
      }
      return Unit_instance;
    }
    var mark = arena.d11_1;
    var tmp = fromInt(large);
    // Inline function 'kotlin.Long.times' call
    var this_0 = new Long(2, 0);
    var tmp$ret$2 = multiply(this_0, fromInt(small));
    if (compare(tmp, tmp$ret$2) > 0) {
      var longer = al >= bl ? a : b;
      var lo = al >= bl ? ao : bo;
      var shorter = al >= bl ? b : a;
      var so = al >= bl ? bo : ao;
      var temp = arena.e11(imul(2, small));
      var position = 0;
      while (position < large) {
        // Inline function 'kotlin.comparisons.minOf' call
        var b_0 = large - position | 0;
        var length = Math.min(small, b_0);
        product($this, longer, lo + position | 0, length, shorter, so, small, arena.c11_1, temp, arena, threshold, squareThreshold);
        addAt($this, out, oo + position | 0, arena.c11_1, temp, length + small | 0);
        position = position + length | 0;
      }
      arena.d11_1 = mark;
      return Unit_instance;
    }
    var split = large / 2 | 0;
    // Inline function 'kotlin.comparisons.minOf' call
    var aLow = Math.min(al, split);
    // Inline function 'kotlin.comparisons.minOf' call
    var bLow = Math.min(bl, split);
    var aHigh = al - aLow | 0;
    var bHigh = bl - bLow | 0;
    product($this, a, ao, aLow, b, bo, bLow, out, oo, arena, threshold, squareThreshold);
    if (aHigh > 0 && bHigh > 0) {
      product($this, a, ao + aLow | 0, aHigh, b, bo + bLow | 0, bHigh, out, oo + imul(2, split) | 0, arena, threshold, squareThreshold);
    }
    // Inline function 'kotlin.comparisons.maxOf' call
    var ac = Math.max(aLow, aHigh) + 1 | 0;
    // Inline function 'kotlin.comparisons.maxOf' call
    var bc = Math.max(bLow, bHigh) + 1 | 0;
    var sumA = arena.e11(ac);
    var sumB = arena.e11(bc);
    var middle = arena.e11(ac + bc | 0);
    var aLength = sum($this, a, ao, aLow, ao + aLow | 0, aHigh, arena.c11_1, sumA, ac);
    var bLength = sum($this, b, bo, bLow, bo + bLow | 0, bHigh, arena.c11_1, sumB, bc);
    product($this, arena.c11_1, sumA, aLength, arena.c11_1, sumB, bLength, arena.c11_1, middle, arena, threshold, squareThreshold);
    var middleLength = aLength + bLength | 0;
    subtract_0($this, arena.c11_1, middle, middleLength, out, oo, aLow + bLow | 0);
    if (aHigh > 0 && bHigh > 0) {
      subtract_0($this, arena.c11_1, middle, middleLength, out, oo + imul(2, split) | 0, aHigh + bHigh | 0);
    }
    addAt($this, out, oo + split | 0, arena.c11_1, middle, trimmed($this, arena.c11_1, middle, middleLength));
    arena.d11_1 = mark;
  }
  function school($this, a, ao, al, b, bo, bl, out, oo) {
    var inductionVariable = 0;
    if (inductionVariable < al)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp2 = a[ao + i | 0];
        // Inline function 'io.heapy.krogu.math.MagnitudeMultiplication.schoolRow' call
        var oo_0 = oo + i | 0;
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < bl)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp0 = fromInt(tmp2);
            // Inline function 'kotlin.Long.times' call
            var other = b[bo + j | 0];
            var tmp0_0 = multiply(tmp0, fromInt(other));
            // Inline function 'kotlin.Long.plus' call
            var other_0 = out[oo_0 + j | 0];
            var tmp$ret$2 = add(tmp0_0, fromInt(other_0));
            var value = add(tmp$ret$2, carry);
            out[oo_0 + j | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
            carry = shiftRightUnsigned(value, 30);
          }
           while (inductionVariable_0 < bl);
        out[oo_0 + bl | 0] = convertToInt(carry);
      }
       while (inductionVariable < al);
  }
  function square($this, a, offset, length, out, oo) {
    var inductionVariable = 0;
    if (inductionVariable < length)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var word = fromInt(a[offset + i | 0]);
        var tmp0 = multiply(word, word);
        // Inline function 'kotlin.Long.plus' call
        var other = out[oo + imul(2, i) | 0];
        var diagonal = add(tmp0, fromInt(other));
        out[oo + imul(2, i) | 0] = convertToInt(bitwiseAnd(diagonal, new Long(1073741823, 0)));
        var carry = shiftRightUnsigned(diagonal, 30);
        var inductionVariable_0 = i + 1 | 0;
        if (inductionVariable_0 < length)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp0_0 = multiply(new Long(2, 0), word);
            // Inline function 'kotlin.Long.times' call
            var other_0 = a[offset + j | 0];
            var tmp0_1 = multiply(tmp0_0, fromInt(other_0));
            // Inline function 'kotlin.Long.plus' call
            var other_1 = out[(oo + i | 0) + j | 0];
            var tmp$ret$2 = add(tmp0_1, fromInt(other_1));
            var value = add(tmp$ret$2, carry);
            out[(oo + i | 0) + j | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
            carry = shiftRightUnsigned(value, 30);
          }
           while (inductionVariable_0 < length);
        var index = (oo + i | 0) + length | 0;
        while (!equalsLong(carry, new Long(0, 0))) {
          var value_0 = add(fromInt(out[index]), carry);
          var _unary__edvuaz = index;
          index = _unary__edvuaz + 1 | 0;
          out[_unary__edvuaz] = convertToInt(bitwiseAnd(value_0, new Long(1073741823, 0)));
          carry = shiftRightUnsigned(value_0, 30);
        }
      }
       while (inductionVariable < length);
  }
  function sum($this, a, low, lowLength, high, highLength, out, offset, capacity) {
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = capacity - 1 | 0;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var value = add(add(i < lowLength ? fromInt(a[low + i | 0]) : new Long(0, 0), i < highLength ? fromInt(a[high + i | 0]) : new Long(0, 0)), carry);
        out[offset + i | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(value, 30);
      }
       while (inductionVariable < last);
    out[(offset + capacity | 0) - 1 | 0] = convertToInt(carry);
    return trimmed($this, out, offset, capacity);
  }
  function subtract_0($this, out, offset, length, b, bo, bl) {
    var borrow = new Long(0, 0);
    var inductionVariable = 0;
    if (inductionVariable < length)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var value = subtract(subtract(fromInt(out[offset + i | 0]), i < bl ? fromInt(b[bo + i | 0]) : new Long(0, 0)), borrow);
        out[offset + i | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
        borrow = compare(value, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
      }
       while (inductionVariable < length);
    // Inline function 'kotlin.check' call
    if (!equalsLong(borrow, new Long(0, 0))) {
      var message = 'Negative Karatsuba cross product';
      throw IllegalStateException_init_$Create$(toString_0(message));
    }
  }
  function addAt($this, out, offset, b, bo, length) {
    var carry = new Long(0, 0);
    var i = 0;
    while (i < length || !equalsLong(carry, new Long(0, 0))) {
      var value = add(add(fromInt(out[offset + i | 0]), i < length ? fromInt(b[bo + i | 0]) : new Long(0, 0)), carry);
      out[offset + i | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
      carry = shiftRightUnsigned(value, 30);
      i = i + 1 | 0;
    }
  }
  function trimmed($this, a, offset, length) {
    var size = length;
    while (size > 0 && a[(offset + size | 0) - 1 | 0] === 0) {
      size = size - 1 | 0;
    }
    return size;
  }
  function MagnitudeMultiplication() {
    MagnitudeMultiplication_instance = this;
    this.nt_1 = 64;
    this.ot_1 = 16;
    this.pt_1 = 384;
    this.qt_1 = 30;
    this.rt_1 = new Long(1073741823, 0);
  }
  protoOf(MagnitudeMultiplication).st = function (left, right) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(left);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(right));
    var tmp$ret$1 = subtract(this_1, fromInt(1));
    if (compare(tmp$ret$1, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
  };
  protoOf(MagnitudeMultiplication).ut = function (a, b) {
    return this.f11(a, b, 384);
  };
  protoOf(MagnitudeMultiplication).f11 = function (a, b, squareEntryThreshold) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(squareEntryThreshold >= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (a.length >= 16 && a.length < squareEntryThreshold && a === b) {
      var out = new Int32Array(a.length + b.length | 0);
      square(this, a, 0, a.length, out, 0);
      return out;
    }
    return this.g11(a, b);
  };
  protoOf(MagnitudeMultiplication).h11 = function (a, b, threshold, squareThreshold) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(threshold >= 4 && squareThreshold >= 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var out = new Int32Array(a.length + b.length | 0);
    var tmp0 = a.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b_0 = b.length;
    if (Math.min(tmp0, b_0) < threshold) {
      if (a.length >= squareThreshold && a === b) {
        square(this, a, 0, a.length, out, 0);
      } else {
        school(this, a, 0, a.length, b, 0, b.length, out, 0);
      }
    } else {
      var arena = new Arena(this.m10(a.length, b.length, threshold));
      product(this, a, 0, a.length, b, 0, b.length, out, 0, arena, threshold, squareThreshold);
    }
    return out;
  };
  protoOf(MagnitudeMultiplication).g11 = function (a, b, threshold, squareThreshold, $super) {
    threshold = threshold === VOID ? 64 : threshold;
    squareThreshold = squareThreshold === VOID ? 16 : squareThreshold;
    return $super === VOID ? this.h11(a, b, threshold, squareThreshold) : $super.h11.call(this, a, b, threshold, squareThreshold);
  };
  protoOf(MagnitudeMultiplication).i11 = function (a, b, policy) {
    if (a.length >= policy.k10_1 && a.length < policy.l10_1 && a === b) {
      var out = new Int32Array(checkedOutput539(this, a.length, b.length));
      square(this, a, 0, a.length, out, 0);
      return out;
    }
    return this.h11(a, b, policy.j10_1, policy.k10_1);
  };
  protoOf(MagnitudeMultiplication).j11 = function (a, b, policy) {
    checkedOutput539(this, a.length, b.length);
    var tmp0 = a.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b_0 = b.length;
    var small = Math.min(tmp0, b_0);
    var tmp;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_1 = policy.j10_1;
    if (small < Math.max(4, b_1)) {
      tmp = true;
    } else {
      var tmp0_0 = a.length;
      // Inline function 'kotlin.comparisons.maxOf' call
      var b_2 = b.length;
      var tmp$ret$2 = Math.max(tmp0_0, b_2);
      var tmp_0 = fromInt(tmp$ret$2);
      // Inline function 'kotlin.Long.times' call
      var this_0 = new Long(2, 0);
      var tmp$ret$3 = multiply(this_0, fromInt(small));
      tmp = compare(tmp_0, tmp$ret$3) > 0;
    }
    if (tmp)
      return null;
    return new ParallelFrame539(a, b, policy);
  };
  protoOf(MagnitudeMultiplication).m10 = function (a, b, threshold) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(a >= 0 && b >= 0 && threshold >= 4)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.comparisons.minOf' call
    var small = Math.min(a, b);
    if (small < threshold)
      return 0;
    var tmp;
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$4 = Math.max(a, b);
    var tmp_0 = fromInt(tmp$ret$4);
    // Inline function 'kotlin.Long.times' call
    var this_0 = new Long(2, 0);
    var tmp$ret$5 = multiply(this_0, fromInt(small));
    if (compare(tmp_0, tmp$ret$5) > 0) {
      tmp = small;
    } else {
      // Inline function 'kotlin.comparisons.maxOf' call
      tmp = Math.max(a, b);
    }
    var size = tmp;
    var tmp_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$7 = Math.max(a, b);
    var tmp_2 = fromInt(tmp$ret$7);
    // Inline function 'kotlin.Long.times' call
    var this_1 = new Long(2, 0);
    var tmp$ret$8 = multiply(this_1, fromInt(small));
    if (compare(tmp_2, tmp$ret$8) > 0) {
      // Inline function 'kotlin.Long.times' call
      var this_2 = new Long(2, 0);
      tmp_1 = multiply(this_2, fromInt(small));
    } else {
      tmp_1 = new Long(0, 0);
    }
    var total = tmp_1;
    while (size >= threshold) {
      // Inline function 'kotlin.Long.plus' call
      var this_3 = fromInt(size);
      // Inline function 'kotlin.Long.div' call
      var this_4 = add(this_3, fromInt(1));
      // Inline function 'kotlin.Long.plus' call
      var this_5 = divide(this_4, fromInt(2));
      var tmp$ret$12 = add(this_5, fromInt(1));
      size = convertToInt(tmp$ret$12);
      var tmp_3 = total;
      var tmp0 = new Long(4, 0);
      // Inline function 'kotlin.Long.times' call
      var other = size;
      var tmp$ret$13 = multiply(tmp0, fromInt(other));
      total = add(tmp_3, tmp$ret$13);
    }
    if (compare(total, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    return convertToInt(total);
  };
  protoOf(MagnitudeMultiplication).tt = function (word, borrowedWide) {
    var out = new Int32Array(borrowedWide.length + 1 | 0);
    // Inline function 'io.heapy.krogu.math.MagnitudeMultiplication.schoolRow' call
    var bl = borrowedWide.length;
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    if (inductionVariable < bl)
      do {
        var j = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = fromInt(word);
        // Inline function 'kotlin.Long.times' call
        var other = borrowedWide[0 + j | 0];
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = out[0 + j | 0];
        var tmp$ret$2 = add(tmp0_0, fromInt(other_0));
        var value = add(tmp$ret$2, carry);
        out[0 + j | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(value, 30);
      }
       while (inductionVariable < bl);
    out[0 + bl | 0] = convertToInt(carry);
    return out;
  };
  var MagnitudeMultiplication_instance;
  function MagnitudeMultiplication_getInstance() {
    if (MagnitudeMultiplication_instance == null)
      new MagnitudeMultiplication();
    return MagnitudeMultiplication_instance;
  }
  function parse_3($this, value) {
    var separator = indexOf(value, _Char___init__impl__6a9atx(32));
    if (!startsWith(value, 'precision=') || separator <= 10 || !startsWith_0(value, 'roundingMode=', separator + 1 | 0)) {
      parse$badFormat();
    }
    var index = 10;
    var negative = charCodeAt(value, index) === _Char___init__impl__6a9atx(45);
    if (negative || charCodeAt(value, index) === _Char___init__impl__6a9atx(43)) {
      index = index + 1 | 0;
    }
    if (index === separator) {
      parse$badFormat();
    }
    var limit = negative ? new Long(-2147483648, 0) : new Long(2147483647, 0);
    var magnitude = new Long(0, 0);
    while (index < separator) {
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      var tmp0_elvis_lhs = digitToIntOrNull(charCodeAt(value, _unary__edvuaz), 10);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        parse$badFormat();
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var digit = tmp;
      // Inline function 'kotlin.Long.times' call
      var this_0 = magnitude;
      // Inline function 'kotlin.Long.plus' call
      var this_1 = multiply(this_0, fromInt(10));
      magnitude = add(this_1, fromInt(digit));
      if (compare(magnitude, limit) > 0) {
        parse$badFormat();
      }
    }
    var tmp_0;
    try {
      tmp_0 = valueOf(substring(value, separator + 14 | 0));
    } catch ($p) {
      var tmp_1;
      if ($p instanceof IllegalArgumentException) {
        var _unused_var__etf5q3 = $p;
        parse$badFormat();
      } else {
        throw $p;
      }
      tmp_0 = tmp_1;
    }
    var rounding = tmp_0;
    var precision = convertToInt(negative ? negate(magnitude) : magnitude);
    return to(precision, rounding);
  }
  function parse$badFormat() {
    throw IllegalArgumentException_init_$Create$('bad string format');
  }
  function MathContext_init_$Init$(setPrecision, $this) {
    MathContext.call($this, setPrecision, RoundingMode_HALF_UP_getInstance());
    return $this;
  }
  function MathContext_init_$Create$(setPrecision) {
    return MathContext_init_$Init$(setPrecision, objectCreate(protoOf(MathContext)));
  }
  function MathContext_init_$Init$_0(parsed, $this) {
    MathContext.call($this, parsed.dd_1, parsed.ed_1);
    return $this;
  }
  function MathContext_init_$Init$_1(value, $this) {
    MathContext_init_$Init$_0(parse_3(Companion_getInstance_4(), value), $this);
    return $this;
  }
  function MathContext_init_$Create$_0(value) {
    return MathContext_init_$Init$_1(value, objectCreate(protoOf(MathContext)));
  }
  function Companion_4() {
    Companion_instance_5 = this;
    this.xi_1 = new Long(527827455, 1299129800);
    this.yi_1 = new MathContext(0, RoundingMode_HALF_UP_getInstance());
    this.zi_1 = new MathContext(7, RoundingMode_HALF_EVEN_getInstance());
    this.aj_1 = new MathContext(16, RoundingMode_HALF_EVEN_getInstance());
    this.bj_1 = new MathContext(34, RoundingMode_HALF_EVEN_getInstance());
  }
  var Companion_instance_5;
  function Companion_getInstance_4() {
    if (Companion_instance_5 == null)
      new Companion_4();
    return Companion_instance_5;
  }
  function MathContext(precision, roundingMode) {
    Companion_getInstance_4();
    this.ol_1 = precision;
    // Inline function 'kotlin.require' call
    if (!(this.ol_1 >= 0)) {
      var message = 'Digits < 0';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    this.pl_1 = roundingMode;
  }
  protoOf(MathContext).k11 = function () {
    return this.ol_1;
  };
  protoOf(MathContext).l11 = function () {
    return this.pl_1;
  };
  protoOf(MathContext).equals = function (other) {
    var tmp;
    var tmp_0;
    if (other instanceof MathContext) {
      tmp_0 = this.ol_1 === other.ol_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.pl_1.equals(other.pl_1);
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(MathContext).hashCode = function () {
    return this.ol_1 + imul(this.pl_1.hashCode(), 59) | 0;
  };
  protoOf(MathContext).toString = function () {
    return 'precision=' + this.ol_1 + ' roundingMode=' + this.pl_1.toString();
  };
  function MultiplicationPolicy539(karatsuba, squareLeaf, wholeSquareEntry) {
    this.j10_1 = karatsuba;
    this.k10_1 = squareLeaf;
    this.l10_1 = wholeSquareEntry;
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(this.j10_1 >= 4 && this.k10_1 >= 1 && this.l10_1 >= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
  }
  protoOf(MultiplicationPolicy539).toString = function () {
    return 'MultiplicationPolicy539(karatsuba=' + this.j10_1 + ', squareLeaf=' + this.k10_1 + ', wholeSquareEntry=' + this.l10_1 + ')';
  };
  protoOf(MultiplicationPolicy539).hashCode = function () {
    var result = this.j10_1;
    result = imul(result, 31) + this.k10_1 | 0;
    result = imul(result, 31) + this.l10_1 | 0;
    return result;
  };
  protoOf(MultiplicationPolicy539).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof MultiplicationPolicy539))
      return false;
    if (!(this.j10_1 === other.j10_1))
      return false;
    if (!(this.k10_1 === other.k10_1))
      return false;
    if (!(this.l10_1 === other.l10_1))
      return false;
    return true;
  };
  function toKroguByte(_this__u8e3s4) {
    var tmp;
    if (_this__u8e3s4 instanceof BigInteger) {
      tmp = _this__u8e3s4.lq();
    } else {
      if (_this__u8e3s4 instanceof BigDecimal) {
        tmp = _this__u8e3s4.lq();
      } else {
        tmp = numberToByte(_this__u8e3s4);
      }
    }
    return tmp;
  }
  function toKroguShort(_this__u8e3s4) {
    var tmp;
    if (_this__u8e3s4 instanceof BigInteger) {
      tmp = _this__u8e3s4.mq();
    } else {
      if (_this__u8e3s4 instanceof BigDecimal) {
        tmp = _this__u8e3s4.mq();
      } else {
        tmp = numberToShort(_this__u8e3s4);
      }
    }
    return tmp;
  }
  function toKroguInt(_this__u8e3s4) {
    var tmp;
    if (_this__u8e3s4 instanceof BigInteger) {
      tmp = _this__u8e3s4.kq();
    } else {
      if (_this__u8e3s4 instanceof BigDecimal) {
        tmp = _this__u8e3s4.kq();
      } else {
        tmp = numberToInt(_this__u8e3s4);
      }
    }
    return tmp;
  }
  function toKroguLong(_this__u8e3s4) {
    var tmp;
    if (_this__u8e3s4 instanceof BigInteger) {
      tmp = _this__u8e3s4.um();
    } else {
      if (_this__u8e3s4 instanceof BigDecimal) {
        tmp = _this__u8e3s4.um();
      } else {
        tmp = numberToLong(_this__u8e3s4);
      }
    }
    return tmp;
  }
  function toKroguFloat(_this__u8e3s4) {
    var tmp;
    if (_this__u8e3s4 instanceof BigInteger) {
      tmp = _this__u8e3s4.ym();
    } else {
      if (_this__u8e3s4 instanceof BigDecimal) {
        tmp = _this__u8e3s4.ym();
      } else {
        tmp = numberToDouble(_this__u8e3s4);
      }
    }
    return tmp;
  }
  function toKroguDouble(_this__u8e3s4) {
    var tmp;
    if (_this__u8e3s4 instanceof BigInteger) {
      tmp = _this__u8e3s4.qq();
    } else {
      if (_this__u8e3s4 instanceof BigDecimal) {
        tmp = _this__u8e3s4.qq();
      } else {
        tmp = numberToDouble(_this__u8e3s4);
      }
    }
    return tmp;
  }
  function toBigDecimal(_this__u8e3s4, mathContext) {
    var canonical = Companion_getInstance().gn(_this__u8e3s4);
    return BigDecimal_init_$Create$_3(canonical.un(), canonical.vn(), mathContext);
  }
  function toBigDecimal_0(_this__u8e3s4) {
    return Companion_getInstance().gn(_this__u8e3s4);
  }
  function toBigDecimal_1(_this__u8e3s4, mathContext) {
    return BigDecimal_init_$Create$_9(decimalFloatString(_this__u8e3s4), mathContext);
  }
  function toBigInteger(_this__u8e3s4) {
    return Companion_getInstance_1().fk(fromInt(_this__u8e3s4));
  }
  function toBigInteger_0(_this__u8e3s4) {
    return Companion_getInstance_1().fk(_this__u8e3s4);
  }
  function toBigInteger_1(_this__u8e3s4) {
    var tmp = Companion_getInstance_1();
    // Inline function 'kotlin.UInt.toLong' call
    // Inline function 'kotlin.uintToLong' call
    var value = _UInt___get_data__impl__f0vqqw(_this__u8e3s4);
    var tmp$ret$0 = bitwiseAnd(fromInt(value), new Long(-1, 0));
    return tmp.fk(tmp$ret$0);
  }
  function toBigInteger_2(_this__u8e3s4) {
    return BigInteger_init_$Create$_2(ULong__toString_impl_f9au7k(_this__u8e3s4));
  }
  function toBigDecimal_2(_this__u8e3s4) {
    return BigDecimal_init_$Create$_4(_this__u8e3s4);
  }
  function toBigDecimal_3(_this__u8e3s4, mathContext) {
    return BigDecimal_init_$Create$_6(_this__u8e3s4, mathContext);
  }
  function toBigDecimal_4(_this__u8e3s4) {
    return BigDecimal_init_$Create$_5(_this__u8e3s4);
  }
  function toBigDecimal_5(_this__u8e3s4, mathContext) {
    return BigDecimal_init_$Create$_7(_this__u8e3s4, mathContext);
  }
  function toBigDecimal_6(_this__u8e3s4) {
    return BigDecimal_init_$Create$_1(_this__u8e3s4);
  }
  function toBigDecimal_7(_this__u8e3s4, scale, mathContext) {
    scale = scale === VOID ? 0 : scale;
    mathContext = mathContext === VOID ? Companion_getInstance_4().yi_1 : mathContext;
    return BigDecimal_init_$Create$_3(_this__u8e3s4, scale, mathContext);
  }
  function toBigDecimal_8(_this__u8e3s4) {
    return BigDecimal_init_$Create$_8(decimalFloatString(_this__u8e3s4));
  }
  function get_ZERO_BLOCK537() {
    _init_properties_NumericOutput537_kt__qgqdrp();
    return ZERO_BLOCK537;
  }
  var ZERO_BLOCK537;
  var static_init_called_0;
  function static_init_0() {
    if (static_init_called_0)
      return Unit_instance;
    static_init_called_0 = true;
    DecimalTextFormat_CANONICAL_instance = new DecimalTextFormat('CANONICAL', 0);
    DecimalTextFormat_PLAIN_instance = new DecimalTextFormat('PLAIN', 1);
    DecimalTextFormat_ENGINEERING_instance = new DecimalTextFormat('ENGINEERING', 2);
  }
  var DecimalTextFormat_CANONICAL_instance;
  var DecimalTextFormat_PLAIN_instance;
  var DecimalTextFormat_ENGINEERING_instance;
  function values_0() {
    static_init_0();
    return [DecimalTextFormat_CANONICAL_getInstance(), DecimalTextFormat_PLAIN_getInstance(), DecimalTextFormat_ENGINEERING_getInstance()];
  }
  function get_entries_0() {
    static_init_0();
    if ($ENTRIES_0 == null)
      $ENTRIES_0 = enumEntries(values_0());
    return $ENTRIES_0;
  }
  var $ENTRIES_0;
  function DecimalTextFormat(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function RadixDigits537(chunks, size, radix, width) {
    this.et_1 = chunks;
    this.ft_1 = size;
    this.gt_1 = radix;
    this.ht_1 = width;
    this.it_1 = (this.ft_1 === 1 && this.et_1[0] === 0);
    var tmp = this;
    // Inline function 'kotlin.run' call
    var rest = this.et_1[this.ft_1 - 1 | 0];
    var count = 1;
    while (rest >= this.gt_1) {
      rest = rest / this.gt_1 | 0;
      count = count + 1 | 0;
    }
    tmp.jt_1 = count;
    var tmp_0 = this;
    var tmp0 = fromInt(this.ft_1 - 1 | 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.ht_1;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = this.jt_1;
    tmp_0.kt_1 = add(tmp0_0, fromInt(other_0));
  }
  protoOf(RadixDigits537).m11 = function (sink, start, end) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!((compare(new Long(0, 0), start) <= 0 ? compare(start, end) <= 0 : false) && compare(end, this.kt_1) <= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var buffer = charArray(this.ht_1);
    var powerOfTwo = (this.gt_1 & (this.gt_1 - 1 | 0)) === 0;
    var shift = countTrailingZeroBits_0(this.gt_1);
    var cursor = new Long(0, 0);
    var inductionVariable = this.ft_1 - 1 | 0;
    if (0 <= inductionVariable)
      $l$loop: do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var count = index === (this.ft_1 - 1 | 0) ? this.jt_1 : this.ht_1;
        // Inline function 'kotlin.Long.plus' call
        var this_0 = cursor;
        var after = add(this_0, fromInt(count));
        if (compare(after, start) > 0 && compare(cursor, end) < 0) {
          var rest = this.et_1[index];
          if (powerOfTwo) {
            var inductionVariable_0 = count - 1 | 0;
            if (0 <= inductionVariable_0)
              do {
                var digit = inductionVariable_0;
                inductionVariable_0 = inductionVariable_0 + -1 | 0;
                buffer[digit] = charCodeAt('0123456789abcdefghijklmnopqrstuvwxyz', rest & (this.gt_1 - 1 | 0));
                rest = rest >>> shift | 0;
              }
               while (0 <= inductionVariable_0);
          } else {
            var inductionVariable_1 = count - 1 | 0;
            if (0 <= inductionVariable_1)
              do {
                var digit_0 = inductionVariable_1;
                inductionVariable_1 = inductionVariable_1 + -1 | 0;
                buffer[digit_0] = charCodeAt('0123456789abcdefghijklmnopqrstuvwxyz', rest % this.gt_1 | 0);
                rest = rest / this.gt_1 | 0;
              }
               while (0 <= inductionVariable_1);
          }
          var tmp0 = new Long(0, 0);
          // Inline function 'kotlin.comparisons.maxOf' call
          var b = subtract(start, cursor);
          var tmp$ret$4 = compare(tmp0, b) >= 0 ? tmp0 : b;
          var tmp = convertToInt(tmp$ret$4);
          var tmp0_0 = fromInt(count);
          // Inline function 'kotlin.comparisons.minOf' call
          var b_0 = subtract(end, cursor);
          var tmp$ret$5 = compare(tmp0_0, b_0) <= 0 ? tmp0_0 : b_0;
          sink.n11(buffer, tmp, convertToInt(tmp$ret$5));
        }
        cursor = after;
      }
       while (compare(cursor, end) < 0 && 0 <= inductionVariable);
  };
  protoOf(RadixDigits537).jv = function (sink, start, end, $super) {
    start = start === VOID ? new Long(0, 0) : start;
    end = end === VOID ? this.kt_1 : end;
    var tmp;
    if ($super === VOID) {
      this.m11(sink, start, end);
      tmp = Unit_instance;
    } else {
      tmp = $super.m11.call(this, sink, start, end);
    }
    return tmp;
  };
  function ArraySink537(destination, offset) {
    this.fq_1 = destination;
    this.gq_1 = offset;
  }
  protoOf(ArraySink537).iv = function (value) {
    var _unary__edvuaz = this.gq_1;
    this.gq_1 = _unary__edvuaz + 1 | 0;
    this.fq_1[_unary__edvuaz] = value;
  };
  protoOf(ArraySink537).hq = function (value, start, end) {
    if (typeof value === 'string') {
      toCharArray(value, this.fq_1, this.gq_1, start, end);
      this.gq_1 = this.gq_1 + (end - start | 0) | 0;
    } else {
      var inductionVariable = start;
      if (inductionVariable < end)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var _unary__edvuaz = this.gq_1;
          this.gq_1 = _unary__edvuaz + 1 | 0;
          this.fq_1[_unary__edvuaz] = charSequenceGet(value, index);
        }
         while (inductionVariable < end);
    }
  };
  protoOf(ArraySink537).n11 = function (value, start, end) {
    var tmp2 = this.fq_1;
    // Inline function 'kotlin.collections.copyInto' call
    var destinationOffset = this.gq_1;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp = value;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp, tmp2, destinationOffset, start, end);
    this.gq_1 = this.gq_1 + (end - start | 0) | 0;
  };
  function AppendableSink537(destination) {
    this.hv_1 = destination;
  }
  protoOf(AppendableSink537).iv = function (value) {
    this.hv_1.n(value);
  };
  protoOf(AppendableSink537).hq = function (value, start, end) {
    this.hv_1.ia(value, start, end);
  };
  protoOf(AppendableSink537).n11 = function (value, start, end) {
    var tmp = this.hv_1;
    if (tmp instanceof StringBuilder)
      this.hv_1.pa(value, start, end);
    else {
      characters.call(this, value, start, end);
    }
  };
  function checkTextLimit537(length, maxChars) {
    _init_properties_NumericOutput537_kt__qgqdrp();
    // Inline function 'kotlin.require' call
    if (!(maxChars == null || compare(maxChars, new Long(0, 0)) >= 0)) {
      var message = 'maxChars must be nonnegative';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (!(maxChars == null) && compare(length, maxChars) > 0)
      throw ArithmeticException_init_$Create$('Output character limit exceeded');
  }
  function DecimalLayout537(digits, scale, negative, format) {
    this.hm_1 = digits;
    this.im_1 = scale;
    this.jm_1 = negative;
    var tmp = this;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(this.hm_1.kt_1, fromInt(this.im_1));
    tmp.km_1 = subtract(this_0, fromInt(1));
    this.lm_1 = format.equals(DecimalTextFormat_PLAIN_getInstance()) || (this.im_1 >= 0 && compare(this.km_1, new Long(-6, -1)) >= 0);
    this.mm_1 = (!this.lm_1 && format.equals(DecimalTextFormat_ENGINEERING_getInstance()));
    var tmp_0 = this;
    // Inline function 'kotlin.Long.rem' call
    var this_1 = this.km_1;
    // Inline function 'kotlin.Long.plus' call
    var this_2 = modulo(this_1, fromInt(3));
    // Inline function 'kotlin.Long.rem' call
    var this_3 = add(this_2, fromInt(3));
    var tmp$ret$3 = modulo(this_3, fromInt(3));
    tmp_0.nm_1 = convertToInt(tmp$ret$3);
    this.om_1 = this.mm_1 ? this.nm_1 + 1 | 0 : 1;
    this.pm_1 = this.mm_1 && this.hm_1.it_1 ? (3 - this.nm_1 | 0) % 3 | 0 : 0;
    var tmp_1 = this;
    var tmp_2;
    if (this.mm_1) {
      var tmp0 = this.km_1;
      // Inline function 'kotlin.Long.minus' call
      var other = this.nm_1;
      var tmp0_0 = subtract(tmp0, fromInt(other));
      // Inline function 'kotlin.Long.plus' call
      var other_0 = this.hm_1.it_1 && !(this.nm_1 === 0) ? 3 : 0;
      tmp_2 = add(tmp0_0, fromInt(other_0));
    } else {
      tmp_2 = this.km_1;
    }
    tmp_1.qm_1 = tmp_2;
    this.rm_1 = this.lm_1 || (this.mm_1 && equalsLong(this.qm_1, new Long(0, 0))) ? '' : 'E' + (compare(this.qm_1, new Long(0, 0)) >= 0 ? '+' : '') + this.qm_1.toString();
    var tmp_3 = this;
    var tmp_4 = this.jm_1 ? new Long(1, 0) : new Long(0, 0);
    var tmp_5;
    if (this.lm_1 && this.im_1 < 0 && this.hm_1.it_1) {
      tmp_5 = new Long(1, 0);
    } else if (this.lm_1 && this.im_1 <= 0) {
      tmp_5 = subtract(this.hm_1.kt_1, fromInt(this.im_1));
    } else if (this.lm_1 && compare(fromInt(this.im_1), this.hm_1.kt_1) < 0) {
      // Inline function 'kotlin.Long.plus' call
      var this_4 = this.hm_1.kt_1;
      tmp_5 = add(this_4, fromInt(1));
    } else if (this.lm_1) {
      // Inline function 'kotlin.Long.plus' call
      var this_5 = fromInt(this.im_1);
      tmp_5 = add(this_5, fromInt(2));
    } else if (this.mm_1 && this.hm_1.it_1) {
      var tmp0_1 = new Long(1, 0);
      // Inline function 'kotlin.Long.plus' call
      var other_1 = this.pm_1 === 0 ? 0 : this.pm_1 + 1 | 0;
      tmp_5 = add(tmp0_1, fromInt(other_1));
    } else {
      var tmp0_2 = this.hm_1.kt_1;
      // Inline function 'kotlin.comparisons.maxOf' call
      var b = fromInt(this.om_1);
      var tmp0_3 = compare(tmp0_2, b) >= 0 ? tmp0_2 : b;
      // Inline function 'kotlin.Long.plus' call
      var other_2 = compare(this.hm_1.kt_1, fromInt(this.om_1)) > 0 ? 1 : 0;
      tmp_5 = add(tmp0_3, fromInt(other_2));
    }
    var tmp0_4 = add(tmp_4, tmp_5);
    // Inline function 'kotlin.Long.plus' call
    var other_3 = this.rm_1.length;
    tmp_3.sm_1 = add(tmp0_4, fromInt(other_3));
  }
  protoOf(DecimalLayout537).cq = function (sink) {
    if (this.jm_1) {
      sink.iv(_Char___init__impl__6a9atx(45));
    }
    if (this.lm_1 && this.im_1 < 0 && this.hm_1.it_1) {
      sink.iv(_Char___init__impl__6a9atx(48));
    } else if (this.lm_1 && this.im_1 <= 0) {
      this.hm_1.jv(sink);
      sink.p11(negate(fromInt(this.im_1)));
    } else if (this.lm_1 && compare(fromInt(this.im_1), this.hm_1.kt_1) < 0) {
      var tmp0 = this.hm_1.kt_1;
      // Inline function 'kotlin.Long.minus' call
      var other = this.im_1;
      var split = subtract(tmp0, fromInt(other));
      this.hm_1.m11(sink, new Long(0, 0), split);
      sink.iv(_Char___init__impl__6a9atx(46));
      this.hm_1.jv(sink, split);
    } else if (this.lm_1) {
      sink.o11('0.');
      sink.p11(subtract(fromInt(this.im_1), this.hm_1.kt_1));
      this.hm_1.jv(sink);
    } else if (this.mm_1 && this.hm_1.it_1) {
      sink.iv(_Char___init__impl__6a9atx(48));
      if (!(this.pm_1 === 0)) {
        sink.iv(_Char___init__impl__6a9atx(46));
        sink.p11(fromInt(this.pm_1));
      }
    } else if (compare(this.hm_1.kt_1, fromInt(this.om_1)) <= 0) {
      this.hm_1.jv(sink);
      sink.p11(subtract(numberToLong(this.om_1), this.hm_1.kt_1));
    } else {
      this.hm_1.m11(sink, new Long(0, 0), fromInt(this.om_1));
      sink.iv(_Char___init__impl__6a9atx(46));
      this.hm_1.jv(sink, fromInt(this.om_1));
    }
    sink.o11(this.rm_1);
  };
  function checkTextBuffer537(destination, offset, length) {
    _init_properties_NumericOutput537_kt__qgqdrp();
    if (offset < 0 || length < 0 || offset > (destination.length - length | 0))
      throw IndexOutOfBoundsException_init_$Create$('Bad output character range');
  }
  function NumericSink537() {
  }
  function DecimalTextFormat_CANONICAL_getInstance() {
    static_init_0();
    return DecimalTextFormat_CANONICAL_instance;
  }
  function DecimalTextFormat_PLAIN_getInstance() {
    static_init_0();
    return DecimalTextFormat_PLAIN_instance;
  }
  function DecimalTextFormat_ENGINEERING_getInstance() {
    static_init_0();
    return DecimalTextFormat_ENGINEERING_instance;
  }
  var properties_initialized_NumericOutput537_kt_otjohf;
  function _init_properties_NumericOutput537_kt__qgqdrp() {
    if (!properties_initialized_NumericOutput537_kt_otjohf) {
      properties_initialized_NumericOutput537_kt_otjohf = true;
      ZERO_BLOCK537 = repeat('0', 256);
    }
  }
  function checkRange($this, size, offset, length) {
    if (offset < 0 || length < 0 || offset > (size - length | 0))
      throw NumberFormatException_init_$Create$('Bad character range');
  }
  function Companion_5() {
  }
  protoOf(Companion_5).ws = function (value, offset, length) {
    checkRange(this, charSequenceLength(value), offset, length);
    return new NumericText537(value, null, offset, length);
  };
  protoOf(Companion_5).pr = function (value, offset, length, $super) {
    offset = offset === VOID ? 0 : offset;
    length = length === VOID ? charSequenceLength(value) : length;
    return $super === VOID ? this.ws(value, offset, length) : $super.ws.call(this, value, offset, length);
  };
  protoOf(Companion_5).zs = function (value, offset, length) {
    checkRange(this, value.length, offset, length);
    return new NumericText537(null, value, offset, length);
  };
  var Companion_instance_6;
  function Companion_getInstance_5() {
    return Companion_instance_6;
  }
  function NumericText537(text, characters, offset, length) {
    this.qr_1 = text;
    this.rr_1 = characters;
    this.sr_1 = offset;
    this.tr_1 = length;
  }
  protoOf(NumericText537).b = function (index) {
    var tmp0_safe_receiver = this.qr_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : charSequenceGet(tmp0_safe_receiver, this.sr_1 + index | 0);
    var tmp;
    var tmp_0 = tmp1_elvis_lhs;
    if ((tmp_0 == null ? null : new Char(tmp_0)) == null) {
      tmp = ensureNotNull(this.rr_1)[this.sr_1 + index | 0];
    } else {
      tmp = tmp1_elvis_lhs;
    }
    return tmp;
  };
  protoOf(NumericText537).hs = function (start, end) {
    // Inline function 'kotlin.text.buildString' call
    var capacity = end - start | 0;
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder_init_$Create$(capacity);
    var inductionVariable = start;
    if (inductionVariable < end)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this_0.n(this.b(index));
      }
       while (inductionVariable < end);
    return this_0.toString();
  };
  protoOf(NumericText537).ct = function (maxInputChars) {
    // Inline function 'kotlin.require' call
    if (!(maxInputChars >= 0)) {
      var message = 'maxInputChars must be nonnegative';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (this.tr_1 > maxInputChars)
      throw ArithmeticException_init_$Create$('Input character limit exceeded');
    return this;
  };
  function numericDigit537(character, radix) {
    var tmp;
    if (_Char___init__impl__6a9atx(48) <= character ? character <= _Char___init__impl__6a9atx(57) : false) {
      // Inline function 'kotlin.code' call
      var tmp_0 = Char__toInt_impl_vasixd(character);
      // Inline function 'kotlin.code' call
      var this_0 = _Char___init__impl__6a9atx(48);
      tmp = tmp_0 - Char__toInt_impl_vasixd(this_0) | 0;
    } else if (_Char___init__impl__6a9atx(97) <= character ? character <= _Char___init__impl__6a9atx(122) : false) {
      // Inline function 'kotlin.code' call
      var tmp_1 = Char__toInt_impl_vasixd(character);
      // Inline function 'kotlin.code' call
      var this_1 = _Char___init__impl__6a9atx(97);
      tmp = (tmp_1 - Char__toInt_impl_vasixd(this_1) | 0) + 10 | 0;
    } else if (_Char___init__impl__6a9atx(65) <= character ? character <= _Char___init__impl__6a9atx(90) : false) {
      // Inline function 'kotlin.code' call
      var tmp_2 = Char__toInt_impl_vasixd(character);
      // Inline function 'kotlin.code' call
      var this_2 = _Char___init__impl__6a9atx(65);
      tmp = (tmp_2 - Char__toInt_impl_vasixd(this_2) | 0) + 10 | 0;
    } else {
      return digitToIntOrNull(character, radix);
    }
    var ascii = tmp;
    // Inline function 'kotlin.takeIf' call
    var tmp_3;
    if (ascii < radix) {
      tmp_3 = ascii;
    } else {
      tmp_3 = null;
    }
    return tmp_3;
  }
  function div(_this__u8e3s4, other) {
    return _this__u8e3s4.ho(other, RoundingMode_HALF_EVEN_getInstance());
  }
  function unaryMinus(_this__u8e3s4) {
    return _this__u8e3s4.jk();
  }
  function times(_this__u8e3s4, other) {
    return _this__u8e3s4.hk(other);
  }
  function plus(_this__u8e3s4, other) {
    return _this__u8e3s4.al(other);
  }
  function minus(_this__u8e3s4, other) {
    return _this__u8e3s4.yk(other);
  }
  function div_0(_this__u8e3s4, other) {
    return _this__u8e3s4.ul(other);
  }
  function rem(_this__u8e3s4, other) {
    return _this__u8e3s4.xl(other);
  }
  function unaryPlus(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  function plus_0(_this__u8e3s4, other) {
    return _this__u8e3s4.zn(other);
  }
  function minus_0(_this__u8e3s4, other) {
    return _this__u8e3s4.bo(other);
  }
  function times_0(_this__u8e3s4, other) {
    return _this__u8e3s4.do(other);
  }
  function rem_0(_this__u8e3s4, other) {
    return _this__u8e3s4.xo(other);
  }
  function unaryMinus_0(_this__u8e3s4) {
    return _this__u8e3s4.jk();
  }
  function unaryPlus_0(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  function inc(_this__u8e3s4) {
    return _this__u8e3s4.al(Companion_getInstance_1().zj_1);
  }
  function dec(_this__u8e3s4) {
    return _this__u8e3s4.yk(Companion_getInstance_1().zj_1);
  }
  function inc_0(_this__u8e3s4) {
    return _this__u8e3s4.zn(Companion_getInstance().jj_1);
  }
  function dec_0(_this__u8e3s4) {
    return _this__u8e3s4.bo(Companion_getInstance().jj_1);
  }
  function inv(_this__u8e3s4) {
    return _this__u8e3s4.uu();
  }
  function shl(_this__u8e3s4, n) {
    return _this__u8e3s4.ik(n);
  }
  function shr(_this__u8e3s4, n) {
    return _this__u8e3s4.wl(n);
  }
  function and(_this__u8e3s4, other) {
    return _this__u8e3s4.vu(other);
  }
  function or(_this__u8e3s4, other) {
    return _this__u8e3s4.wu(other);
  }
  function xor(_this__u8e3s4, other) {
    return _this__u8e3s4.xu(other);
  }
  function rounds($this, certainty) {
    var tmp;
    if (compare(certainty, new Long(0, 0)) <= 0) {
      tmp = 0;
    } else {
      // Inline function 'kotlin.Long.plus' call
      // Inline function 'kotlin.Long.div' call
      var this_0 = add(certainty, fromInt(1));
      var tmp$ret$1 = divide(this_0, fromInt(2));
      tmp = convertToInt(tmp$ret$1);
    }
    return tmp;
  }
  function PrimalityCertainty() {
  }
  protoOf(PrimalityCertainty).av = function (certainty) {
    return rounds(this, fromInt(certainty));
  };
  protoOf(PrimalityCertainty).nr = function (bitLength, certainty) {
    if (certainty <= 0)
      return 0;
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_0 = bitLength - 1 | 0;
    var selectionBits = 32 - clz32(this_0) | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_1 = fromInt(certainty);
    var tmp$ret$1 = add(this_1, fromInt(selectionBits));
    return rounds(this, tmp$ret$1);
  };
  protoOf(PrimalityCertainty).cv = function (candidateIndexBits) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = new Long(50, 0);
    return add(this_0, fromInt(candidateIndexBits));
  };
  var PrimalityCertainty_instance;
  function PrimalityCertainty_getInstance() {
    return PrimalityCertainty_instance;
  }
  function PrimeSearchLimits() {
    this.lr_1 = 500000000;
  }
  protoOf(PrimeSearchLimits).mr = function (bitLength) {
    if (bitLength > 500000000)
      throw ArithmeticException_init_$Create$('Probable prime size exceeds supported range');
  };
  var PrimeSearchLimits_instance;
  function PrimeSearchLimits_getInstance() {
    return PrimeSearchLimits_instance;
  }
  function BigInteger_0(bitLength, certainty, rnd) {
    return Companion_getInstance_1().ss(bitLength, certainty, rnd);
  }
  function BigInteger_1(numBits, rnd) {
    return Companion_getInstance_1().rs(numBits, rnd);
  }
  var static_init_called_1;
  function static_init_1() {
    if (static_init_called_1)
      return Unit_instance;
    static_init_called_1 = true;
    RoundingMode_UP_instance = new RoundingMode('UP', 0);
    RoundingMode_DOWN_instance = new RoundingMode('DOWN', 1);
    RoundingMode_CEILING_instance = new RoundingMode('CEILING', 2);
    RoundingMode_FLOOR_instance = new RoundingMode('FLOOR', 3);
    RoundingMode_HALF_UP_instance = new RoundingMode('HALF_UP', 4);
    RoundingMode_HALF_DOWN_instance = new RoundingMode('HALF_DOWN', 5);
    RoundingMode_HALF_EVEN_instance = new RoundingMode('HALF_EVEN', 6);
    RoundingMode_UNNECESSARY_instance = new RoundingMode('UNNECESSARY', 7);
    if (Companion_instance_7 == null) {
      Companion_instance;
      new Companion_6();
    }
  }
  var RoundingMode_UP_instance;
  var RoundingMode_DOWN_instance;
  var RoundingMode_CEILING_instance;
  var RoundingMode_FLOOR_instance;
  var RoundingMode_HALF_UP_instance;
  var RoundingMode_HALF_DOWN_instance;
  var RoundingMode_HALF_EVEN_instance;
  var RoundingMode_UNNECESSARY_instance;
  function Companion_6() {
  }
  protoOf(Companion_6).ko = function (rm) {
    var tmp0_elvis_lhs = getOrNull(get_entries_1(), rm);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('Invalid rounding mode');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_7;
  function Companion_getInstance_6() {
    return Companion_instance_7;
  }
  function values_1() {
    static_init_1();
    return [RoundingMode_UP_getInstance(), RoundingMode_DOWN_getInstance(), RoundingMode_CEILING_getInstance(), RoundingMode_FLOOR_getInstance(), RoundingMode_HALF_UP_getInstance(), RoundingMode_HALF_DOWN_getInstance(), RoundingMode_HALF_EVEN_getInstance(), RoundingMode_UNNECESSARY_getInstance()];
  }
  function valueOf(value) {
    static_init_1();
    switch (value) {
      case 'UP':
        return RoundingMode_UP_getInstance();
      case 'DOWN':
        return RoundingMode_DOWN_getInstance();
      case 'CEILING':
        return RoundingMode_CEILING_getInstance();
      case 'FLOOR':
        return RoundingMode_FLOOR_getInstance();
      case 'HALF_UP':
        return RoundingMode_HALF_UP_getInstance();
      case 'HALF_DOWN':
        return RoundingMode_HALF_DOWN_getInstance();
      case 'HALF_EVEN':
        return RoundingMode_HALF_EVEN_getInstance();
      case 'UNNECESSARY':
        return RoundingMode_UNNECESSARY_getInstance();
      default:
        THROW_IAE('No enum constant io.heapy.krogu.math.RoundingMode.' + value);
        break;
    }
  }
  function get_entries_1() {
    static_init_1();
    if ($ENTRIES_1 == null)
      $ENTRIES_1 = enumEntries(values_1());
    return $ENTRIES_1;
  }
  var $ENTRIES_1;
  function RoundingMode(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function RoundingMode_UP_getInstance() {
    static_init_1();
    return RoundingMode_UP_instance;
  }
  function RoundingMode_DOWN_getInstance() {
    static_init_1();
    return RoundingMode_DOWN_instance;
  }
  function RoundingMode_CEILING_getInstance() {
    static_init_1();
    return RoundingMode_CEILING_instance;
  }
  function RoundingMode_FLOOR_getInstance() {
    static_init_1();
    return RoundingMode_FLOOR_instance;
  }
  function RoundingMode_HALF_UP_getInstance() {
    static_init_1();
    return RoundingMode_HALF_UP_instance;
  }
  function RoundingMode_HALF_DOWN_getInstance() {
    static_init_1();
    return RoundingMode_HALF_DOWN_instance;
  }
  function RoundingMode_HALF_EVEN_getInstance() {
    static_init_1();
    return RoundingMode_HALF_EVEN_instance;
  }
  function RoundingMode_UNNECESSARY_getInstance() {
    static_init_1();
    return RoundingMode_UNNECESSARY_instance;
  }
  function toBigInteger_3(_this__u8e3s4, radix) {
    // Inline function 'kotlin.require' call
    if (!(2 <= radix ? radix <= 36 : false)) {
      var message = 'radix ' + radix + ' was not in valid range 2..36';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    return BigInteger_init_$Create$_3(_this__u8e3s4, radix);
  }
  function toBigIntegerOrNull(_this__u8e3s4, radix) {
    // Inline function 'kotlin.require' call
    if (!(2 <= radix ? radix <= 36 : false)) {
      var message = 'radix ' + radix + ' was not in valid range 2..36';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    try {
      tmp = BigInteger_init_$Create$_3(_this__u8e3s4, radix);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof NumberFormatException) {
        var _unused_var__etf5q3 = $p;
        tmp_0 = null;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function toBigDecimal_9(_this__u8e3s4) {
    return BigDecimal_init_$Create$_8(_this__u8e3s4);
  }
  function toBigDecimalOrNull(_this__u8e3s4) {
    var tmp;
    try {
      tmp = BigDecimal_init_$Create$_8(_this__u8e3s4);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof NumberFormatException) {
        var _unused_var__etf5q3 = $p;
        tmp_0 = null;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function toBigInteger_4(_this__u8e3s4) {
    return BigInteger_init_$Create$_2(_this__u8e3s4);
  }
  function toBigIntegerOrNull_0(_this__u8e3s4) {
    return toBigIntegerOrNull(_this__u8e3s4, 10);
  }
  function toBigDecimal_10(_this__u8e3s4, mathContext) {
    return BigDecimal_init_$Create$_9(_this__u8e3s4, mathContext);
  }
  function toBigDecimalOrNull_0(_this__u8e3s4, mathContext) {
    var tmp;
    try {
      tmp = BigDecimal_init_$Create$_9(_this__u8e3s4, mathContext);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof NumberFormatException) {
        var _unused_var__etf5q3 = $p;
        tmp_0 = null;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function plainStringTooLarge() {
    throw Error_init_$Create$('too large to fit in a String');
  }
  function arrayIndexFailure(index, length) {
    throw new ArrayIndexOutOfBoundsException('Index ' + index + ' out of bounds for length ' + length);
  }
  function emptyPowMagnitude() {
    arrayIndexFailure(0, 0);
  }
  function ArrayIndexOutOfBoundsException(message) {
    IndexOutOfBoundsException_init_$Init$(message, this);
    captureStack(this, ArrayIndexOutOfBoundsException);
  }
  //region block: post-declaration
  protoOf(ArraySink537).o11 = text$default;
  protoOf(ArraySink537).p11 = zeros;
  protoOf(AppendableSink537).o11 = text$default;
  protoOf(AppendableSink537).p11 = zeros;
  //endregion
  //region block: init
  Companion_instance_1 = new Companion_0();
  Companion_instance_3 = new Companion_2();
  Decimals_instance = new Decimals();
  MagnitudeLimits_instance = new MagnitudeLimits();
  Companion_instance_6 = new Companion_5();
  PrimalityCertainty_instance = new PrimalityCertainty();
  PrimeSearchLimits_instance = new PrimeSearchLimits();
  Companion_instance_7 = new Companion_6();
  //endregion
  //region block: exports
  _.$_$ = _.$_$ || {};
  _.$_$.a = DecimalRounding_EACH_STEP_getInstance;
  _.$_$.b = DecimalRounding_FINAL_RESULT_getInstance;
  _.$_$.c = DecimalTextFormat_CANONICAL_getInstance;
  _.$_$.d = DecimalTextFormat_ENGINEERING_getInstance;
  _.$_$.e = DecimalTextFormat_PLAIN_getInstance;
  _.$_$.f = RoundingMode_CEILING_getInstance;
  _.$_$.g = RoundingMode_DOWN_getInstance;
  _.$_$.h = RoundingMode_FLOOR_getInstance;
  _.$_$.i = RoundingMode_HALF_DOWN_getInstance;
  _.$_$.j = RoundingMode_HALF_EVEN_getInstance;
  _.$_$.k = RoundingMode_HALF_UP_getInstance;
  _.$_$.l = RoundingMode_UNNECESSARY_getInstance;
  _.$_$.m = RoundingMode_UP_getInstance;
  _.$_$.n = Companion_getInstance;
  _.$_$.o = Companion_getInstance_1;
  _.$_$.p = CompactInteger529_getInstance;
  _.$_$.q = DecimalDivision581_getInstance;
  _.$_$.r = DecimalPower593_getInstance;
  _.$_$.s = DecimalProduct580_getInstance;
  _.$_$.t = DecimalSquareRoot579_getInstance;
  _.$_$.u = DecimalSum585_getInstance;
  _.$_$.v = DecimalText588_getInstance;
  _.$_$.w = Decimals_instance;
  _.$_$.x = MagnitudeLimits_instance;
  _.$_$.y = MagnitudeMultiplication_getInstance;
  _.$_$.z = Companion_getInstance_4;
  _.$_$.a1 = PrimalityCertainty_instance;
  _.$_$.b1 = PrimeSearchLimits_instance;
  _.$_$.c1 = Companion_instance_7;
  _.$_$.d1 = BigDecimal_init_$Create$_2;
  _.$_$.e1 = BigDecimal_init_$Init$_12;
  _.$_$.f1 = BigDecimal_init_$Create$_10;
  _.$_$.g1 = BigDecimal_init_$Init$_13;
  _.$_$.h1 = BigDecimal_init_$Create$_11;
  _.$_$.i1 = BigDecimal_init_$Create$_15;
  _.$_$.j1 = BigDecimal_init_$Init$_6;
  _.$_$.k1 = BigDecimal_init_$Create$_4;
  _.$_$.l1 = BigDecimal_init_$Init$_0;
  _.$_$.m1 = BigDecimal_init_$Create$_0;
  _.$_$.n1 = BigDecimal_init_$Create$_1;
  _.$_$.o1 = BigDecimal_init_$Init$_10;
  _.$_$.p1 = BigDecimal_init_$Create$_8;
  _.$_$.q1 = BigDecimal_init_$Create$_7;
  _.$_$.r1 = BigDecimal_init_$Create$_6;
  _.$_$.s1 = BigDecimal_init_$Init$_7;
  _.$_$.t1 = BigDecimal_init_$Create$_5;
  _.$_$.u1 = BigDecimal_init_$Create$_12;
  _.$_$.v1 = BigDecimal_init_$Create$_14;
  _.$_$.w1 = BigDecimal_init_$Create$_3;
  _.$_$.x1 = BigDecimal_init_$Create$_9;
  _.$_$.y1 = BigDecimal_init_$Create$_13;
  _.$_$.z1 = BigInteger_init_$Create$_3;
  _.$_$.a2 = BigInteger_init_$Create$_4;
  _.$_$.b2 = BigInteger_init_$Init$_2;
  _.$_$.c2 = BigInteger_init_$Create$_2;
  _.$_$.d2 = BigInteger_init_$Init$_6;
  _.$_$.e2 = BigInteger_init_$Create$_6;
  _.$_$.f2 = BigInteger_init_$Create$_7;
  _.$_$.g2 = BigInteger_init_$Create$_5;
  _.$_$.h2 = MathContext_init_$Create$;
  _.$_$.i2 = MathContext_init_$Create$_0;
  _.$_$.j2 = AppendableSink537;
  _.$_$.k2 = ArraySink537;
  _.$_$.l2 = BigDecimal;
  _.$_$.m2 = BigInteger_0;
  _.$_$.n2 = BigInteger_1;
  _.$_$.o2 = BigInteger;
  _.$_$.p2 = DecimalAccumulator;
  _.$_$.q2 = DecimalKey;
  _.$_$.r2 = get_entries;
  _.$_$.s2 = get_entries_0;
  _.$_$.t2 = Failure;
  _.$_$.u2 = Value;
  _.$_$.v2 = MathContext;
  _.$_$.w2 = MultiplicationPolicy539;
  _.$_$.x2 = QuotientRemainder;
  _.$_$.y2 = RadixDigits537;
  _.$_$.z2 = get_entries_1;
  _.$_$.a3 = valueOf;
  _.$_$.b3 = values_1;
  _.$_$.c3 = and;
  _.$_$.d3 = certifiedDecimalSumSpan585;
  _.$_$.e3 = decimalDoubleString;
  _.$_$.f3 = dec;
  _.$_$.g3 = dec_0;
  _.$_$.h3 = divideExact;
  _.$_$.i3 = div;
  _.$_$.j3 = div_0;
  _.$_$.k3 = dotProduct;
  _.$_$.l3 = fma;
  _.$_$.m3 = inc_0;
  _.$_$.n3 = inc;
  _.$_$.o3 = inv;
  _.$_$.p3 = get_lowestSetBit;
  _.$_$.q3 = materializedDecimalDivision581;
  _.$_$.r3 = materializedDecimalSum585;
  _.$_$.s3 = minus_0;
  _.$_$.t3 = minus;
  _.$_$.u3 = needsRawDecimalProduct580;
  _.$_$.v3 = numericallyEquals;
  _.$_$.w3 = or;
  _.$_$.x3 = plus_0;
  _.$_$.y3 = plus;
  _.$_$.z3 = quotientAndRemainder;
  _.$_$.a4 = quotientAndRemainder_1;
  _.$_$.b4 = quotientAndRemainder_0;
  _.$_$.c4 = rem;
  _.$_$.d4 = rem_0;
  _.$_$.e4 = retainedDecimalText588;
  _.$_$.f4 = roundToPrecision;
  _.$_$.g4 = roundToScale;
  _.$_$.h4 = shl;
  _.$_$.i4 = shr;
  _.$_$.j4 = sumDecimals;
  _.$_$.k4 = times_0;
  _.$_$.l4 = times;
  _.$_$.m4 = toBigDecimalOrNull_0;
  _.$_$.n4 = toBigDecimalOrNull;
  _.$_$.o4 = toBigDecimal_9;
  _.$_$.p4 = toBigDecimal_7;
  _.$_$.q4 = toBigDecimal_0;
  _.$_$.r4 = toBigDecimal_2;
  _.$_$.s4 = toBigDecimal_3;
  _.$_$.t4 = toBigDecimal_6;
  _.$_$.u4 = toBigDecimal_8;
  _.$_$.v4 = toBigDecimal_10;
  _.$_$.w4 = toBigDecimal_4;
  _.$_$.x4 = toBigDecimal_5;
  _.$_$.y4 = toBigDecimal_1;
  _.$_$.z4 = toBigDecimal;
  _.$_$.a5 = toBigIntegerExactResult;
  _.$_$.b5 = toBigIntegerOrNull;
  _.$_$.c5 = toBigIntegerOrNull_0;
  _.$_$.d5 = toBigInteger_3;
  _.$_$.e5 = toBigInteger_4;
  _.$_$.f5 = toBigInteger;
  _.$_$.g5 = toBigInteger_0;
  _.$_$.h5 = toBigInteger_2;
  _.$_$.i5 = toBigInteger_1;
  _.$_$.j5 = toDecimalKey;
  _.$_$.k5 = toIntExactResult_0;
  _.$_$.l5 = toIntExactResult;
  _.$_$.m5 = toKroguByte;
  _.$_$.n5 = toKroguDouble;
  _.$_$.o5 = toKroguFloat;
  _.$_$.p5 = toKroguInt;
  _.$_$.q5 = toKroguLong;
  _.$_$.r5 = toKroguShort;
  _.$_$.s5 = toLongExactResult;
  _.$_$.t5 = toLongExactResult_0;
  _.$_$.u5 = unaryMinus_0;
  _.$_$.v5 = unaryMinus;
  _.$_$.w5 = unaryPlus;
  _.$_$.x5 = unaryPlus_0;
  _.$_$.y5 = xor;
  //endregion
  return _;
}));

//# sourceMappingURL=krogu-math.js.map
