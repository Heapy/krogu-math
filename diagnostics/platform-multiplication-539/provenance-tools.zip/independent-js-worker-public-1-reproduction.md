# JS105 worker independent raw audit reproduction

Checks actual105 same-parent cases and recomputes all per-process/pooled statistics. Fastest serial includes actual public multiply. No historical partial rows are read. Public full correctness is supplied by source-bound untimed Node BigInt and Kotlin mode2 checks; hashes are an additional consistency witness, not a universal correctness proof.

```sh
python3 - <<'PY'
from pathlib import Path
import json,csv,re,hashlib,statistics as st,math
p=Path('.codex-work/539');kind='js';d=p/f'calibration-{kind}-worker-public-1';sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
s=json.loads((p/f'calibration-{kind}-worker-public-1-summary.json').read_text());pre=json.loads((p/'worker-public-full-prelaunch-batch.json').read_text());groups=[g for g in pre['groups'] if g['platform']==kind]
assert s['checker_exit']==0 and s['fork_exits']==[0,0,0] and s['cases']==105 and s['WORKER']==2205 and s['PUBLICRESULT']==315
assert all(sha(p/f)==h for f,h in s['files'].items()) and sha(p/s['csv'])==s['csv_sha256']
ids=[f'{n}/{shape}/{v}' for n in [256,1024,4096,8192,16384] for shape in ['distinct','square','ratio2'] for v in ['kernel','frame','public','empty','copy','worker1','worker2']]
capture=Path(groups[0]['argv'][1]);script=capture.read_text();literal=script.split('host.writeText("""\n',1)[1].split('\n""".trimIndent())',1)[0].strip('\n');expectedHost=hashlib.sha256(literal.encode()).hexdigest()
assert sha(capture)==pre['capture_script_sha256']
identities=[];forks={};publicHashes={};resources=[];versions=set()
for i,g in enumerate(groups):
 folder=Path(g['argv'][6]);a=g['argv'];lines=(folder/'raw.log').read_text().splitlines();text='\n'.join(lines);order='reverse' if i==1 else 'forward'
 assert (folder/'raw.log.exit').read_text().strip()=='0' and not (folder/'stderr.log').read_text()
 binding=dict(l.split('=',1) for l in (folder/'binding.txt').read_text().splitlines() if '=' in l and not l.startswith('argv='))
 assert binding['source_sha256']==pre['capture_script_sha256'] and binding['manifest_sha256']==g['manifest_sha256'] and binding['root_manifest_sha256']==g['root_manifest_sha256']
 assert binding['node_sha256']=='1ee75375e33b94fc34b3b19aede049e11dae90efb63b374dc96d6bdace70c4b8'
 assert binding['host_sha256']==sha(folder/'owned-host.mjs')==expectedHost and binding['root_directory']==a[10]
 assert (folder/'binding.txt').read_text().split('argv=',1)[1].splitlines()==[a[2],'--max-old-space-size=512',str(folder/'owned-host.mjs'),str(Path(a[3])/a[4]),kind,order,'7',a[10]]
 header=next(l for l in lines if l.startswith('# worker539 '));m=re.fullmatch(r'# worker539 kind='+kind+r' node=v24.16.0 processors=(\d+) order=(forward|reverse) samples=7 pid=(\d+) start_ms=(\d+)',header);assert m
 cpus,actualOrder,pid,start=m.groups();assert int(cpus)>2 and actualOrder==order and int(pid)>0 and int(start)>0;identities.append((pid,start))
 versions.add(next(l for l in lines if l.startswith('# v8=')))
 assert '# CPU=whole_process heap=parent_realm_only RSS=whole_process_including_workers_and_reference_preparation allocation=NA' in lines
 assert not any(l.startswith('INELIGIBLE_WORKER539,') for l in lines)
 checks=[l.split(',') for l in lines if l.startswith('CHECKWORKER539,')];assert len(checks)==105 and all(len(x)==3 and x[2]=='PASS' for x in checks)
 assert [x[1] for x in checks]==(list(reversed(ids)) if i==1 else ids)
 assert lines.count('PASS_WORKER539')==1 and re.search(r'^\s*1 passing \(',text,re.M)
 root=Path(a[10]);entry=(root/'entry.txt').read_text().strip()
 assert f'ROOTORIGIN539,{root/entry},{root/"mocha/node_modules/mocha/index.js"}' in lines
 cache={}
 for phase in ['before-register','after-register','after-campaign']:
  ls=[l for l in lines if l.startswith('ROOTCACHE539,'+phase+',')];assert len(ls)==1;z=ls[0].split(',');assert len(z)==4 and int(z[2])>0 and z[3]=='owned';cache[phase]=int(z[2])
 def record(marker):
  ls=[l.split(',') for l in lines if l.startswith(marker+',')];assert len(ls)==1;return ls[0]
 mod=record('MODULE539');rootmod=record('ROOTMODULE539');startup=record('STARTUP539');pool=record('POOL_RESOURCE539')
 assert mod[1]=='parent_import_ms' and rootmod[1]=='parent_load_register_ms'
 assert all(math.isfinite(float(x)) and float(x)>=0 for x in [mod[2],rootmod[2]]) and int(startup[1])==int(pool[3])==2 and int(startup[2])>=0
 pub=[l.split(',') for l in lines if l.startswith('PUBLICRESULT539,')];assert len(pub)==105
 pubids={x for x in ids if x.endswith('/public')}
 assert {x[1] for x in pub}==pubids
 for name in pubids:
  rr=[r for r in pub if r[1]==name];assert len(rr)==7 and {int(r[2]) for r in rr}==set(range(7));values={int(r[3]) for r in rr};assert len(values)==1 and all(-(2**31)<=x<2**31 for x in values);publicHashes.setdefault(name,set()).update(values)
 rows=[l.split(',') for l in lines if l.startswith('WORKER539,')];assert len(rows)==735;data={}
 for row in rows:
  assert len(row)==9;_,name,sample,count,wall,cpu,heap,rss,maxrss=row
  sample,count,wall,cpu,heap,rss,maxrss=map(int,[sample,count,wall,cpu,heap,rss,maxrss])
  assert name in ids and sample in range(7) and 1<=count<=1048576 and count&(count-1)==0 and 0<wall<=60_000_000_000 and min(cpu,heap,rss,maxrss)>=0
  data.setdefault(name,[]).append(dict(sample=sample,count=count,wall=wall,cpu=cpu,heap=heap,rss=rss,maxrss=maxrss))
 assert set(data)==set(ids)
 for name,rr in data.items():assert len(rr)==7 and {r['sample'] for r in rr}==set(range(7)) and len({r['count'] for r in rr})==1
 forks[i]=data;resources.append(dict(fork=i,header_timestamp_scope='Date.now campaign-header timestamp, not process creation instant',tiny_import_ms=float(mod[2]),root_load_registration_ms=float(rootmod[2]),pool_startup_ns=int(startup[2]),rss_before_pool_B=int(pool[1]),rss_after_pool_B=int(pool[2]),workers=2,cache_counts=cache))
assert len(set(identities))==3 and len({x[0] for x in identities})==3 and len(versions)==1 and all(len(v)==1 for v in publicHashes.values())
result=[]
for name in sorted(ids):
 rr=[forks[i][name] for i in range(3)];wall=[st.median(x['wall']/x['count'] for x in rows) for rows in rr];cpu=[st.median(x['cpu']/x['count'] for x in rows) for rows in rr]
 result.append(dict(case=name,wall_median_ns=st.median(wall),wall_min_process_median_ns=min(wall),wall_max_process_median_ns=max(wall),cpu_median_ns=st.median(cpu),parent_heap_max_bytes=max(x['heap'] for rows in rr for x in rows),whole_process_rss_max_bytes=max(x['rss'] for rows in rr for x in rows),cumulative_process_highwater_max_kib=max(x['maxrss'] for rows in rr for x in rows),fork_wall_ns=wall,fork_CPU_ns=cpu))
owner=list(csv.DictReader((p/s['csv']).open()));assert len(owner)==105
for a,b in zip(owner,result):
 assert a['case']==b['case']
 for key in ['wall_median_ns','wall_min_process_median_ns','wall_max_process_median_ns','cpu_median_ns','parent_heap_max_bytes','whole_process_rss_max_bytes','cumulative_process_highwater_max_kib']:
  assert math.isclose(float(a[key]),b[key],rel_tol=1e-14,abs_tol=1e-9),(a['case'],key,a[key],b[key])
by={r['case']:r for r in result};comparisons=[]
for size in [256,1024,4096,8192,16384]:
 for shape in ['distinct','square','ratio2']:
  prefix=f'{size}/{shape}/';serial=[min(['kernel','frame','public'],key=lambda v:by[prefix+v]['fork_wall_ns'][i]) for i in range(3)]
  for worker in ['worker1','worker2']:
   r=by[prefix+worker];base=[by[prefix+serial[i]] for i in range(3)];rat=[r['fork_wall_ns'][i]/base[i]['fork_wall_ns'][i] for i in range(3)]
   comparisons.append(dict(case=prefix+worker,serial_comparator_per_fork=serial,paired_wall_ratios=rat,median_paired_wall_ratio=st.median(rat),all3_faster=max(rat)<1,all3_slower=min(rat)>1,frozen_parallel_latency_margin=st.median(rat)<=.8 and max(rat)<=.9,paired_processCPU_ratios=[r['fork_CPU_ns'][i]/base[i]['fork_CPU_ns'][i] for i in range(3)]))
table=[]
for shape in ['distinct','square','ratio2']:
 for worker in ['worker1','worker2']:
  pts=sorted([x for x in comparisons if x['case'].endswith('/'+shape+'/'+worker)],key=lambda x:int(x['case'].split('/')[0]));table.append(dict(shape=shape,worker=worker,qualifying_sizes=[int(x['case'].split('/')[0]) for x in pts if x['frozen_parallel_latency_margin']],two_adjacent_sizes=[[int(a['case'].split('/')[0]),int(b['case'].split('/')[0])] for a,b in zip(pts,pts[1:]) if a['frozen_parallel_latency_margin'] and b['frozen_parallel_latency_margin']]))
source=Path(pre['source_manifest']);assert sha(source)==pre['source_manifest_sha256'];sr=source.read_text().splitlines();assert len(sr)==379
for l in sr:h,f=l.split('\t');assert sha(Path(f))==h
assert sha(capture)==pre['capture_script_sha256'] and sha(capture.parent/'check-worker-transport-539.main.kts')==pre['checker_script_sha256']
r={'status':'INDEPENDENT_COMPLETE_WORKER105_RAW_STATS_BINDING_PASS_NOT_ADOPTED','source':s['source'],'kind':kind,'fork_handles':s['fork_handles'],'checker_handle':s['checker_handle'],'cases':105,'WORKER':2205,'PUBLICRESULT':315,'CHECK_per_fork':105,'fresh_process_identities':identities,'V8':list(versions),'source_files_verified':379,'all_owner_CSV_statistics_exact':True,'public_hashes_per_case_fork_sample_stable':True,'generated_host_sha256':expectedHost,'per_case':result,'worker_vs_faster_actual_serial':comparisons,'frozen_latency_eligibility':table,'module_pool_resource_controls':resources,'all3_faster_workers':sum(x['all3_faster'] for x in comparisons),'all3_slower_workers':sum(x['all3_slower'] for x in comparisons),'scope':['Freshsameparent105cases; fastestactualkernel/frame/publicperfork, old98636partialneverread/pooled','ActualNodeBigIntfulluntimedoracleinhost; publiclatestresultverifiedviaKotlinmode2withPUBLICRESULTaftercounters','CPUwholeprocessincludesworkers;allocationNA. ParentheaponlyandwholeprocessRSS/highwaterincludeidlepool/rootMocha/preparedreferences/priorcases; notexactworkerownedmemory/peroppeak','Tinyimport/rootloadregistration/poolstartupseparate; warmreusedpooloperationincludesbridge/copy/post/join/recombine; awaitedteardownoutsideROWSbutchildexit0afterit. No percallcold/amortizationclaim','Frozen20/10/twoadjacentparallelrulelatencyeligibilityonly; resource/publicfrontendcontract/selectedguards/fullcorrectnessstillrequired; NodeharnessnotpublicAPIcompatibility/adoptionproof','Generatedhost/script/root/tiny/runtimeclosurefromapprovedfreshbindingsplusallactualrawbinding/controlguardPASS; no bulk module/runtime rehash duringcurrentotherplatformtiming']}
(p/f'independent-{kind}-worker-public-1-raw-audit.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS',kind,105,2205,315,'ALL3workersfaster/slower',r['all3_faster_workers'],r['all3_slower_workers']);print('ELIGIBILITY',table)
for x in comparisons:
 if int(x['case'].split('/')[0])>=8192:print(x['case'],'wall',[round(v,3) for v in x['paired_wall_ratios']],'CPU',[round(v,3) for v in x['paired_processCPU_ratios']])
PY
```
