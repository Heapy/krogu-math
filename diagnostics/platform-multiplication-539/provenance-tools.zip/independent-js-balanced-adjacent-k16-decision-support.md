# Bounded JS K16 extension — independent decision support

Actual source43f2cd6,33 cases/693 TIME/99 CHECK: independent raw/stat/binding PASS. New untimed public Node BigInt oracle covers this era only.

|Words|K16/K32 three fork ratios|K32/K64 three fork ratios|
|---:|---|---|
|16|0.860/0.792/0.826|1.122/1.138/1.292|
|31|0.755/0.609/0.855|0.919/0.771/1.259|
|32|1.046/0.755/1.026|0.836/0.903/1.111|
|63|0.788/0.492/0.893|0.461/0.694/0.720|
|64|0.911/1.172/0.854|0.808/0.705/1.118|
|128|0.849/0.504/1.023|0.757/0.764/0.946|
|256|0.674/0.844/0.778|1.148/0.729/0.670|
|512|1.202/0.975/0.900|0.936/0.617/0.836|
|1024|0.919/0.830/0.938|0.829/0.994/0.887|
|4096|1.254/1.076/1.227|0.944/0.838/0.827|
|8192|0.943/0.989/1.272|0.759/0.849/0.654|

Recommend K32 for the proposed physical-distinct balanced route rather than blanket K16: K16 is inconsistent and loses all three4096 pairs. At16/31, K32 and K64 use the same school arithmetic; those differences are noise controls. At32/63 K16/K32 recurse while K64 stays school; larger sizes can change recursive leaves.

The single preregistered adjacent extension is complete. No automatic K8 search, no serial20/10 gate and no global-optimum claim. Alias and unbalanced policies must remain unchanged unless separately validated. Production dispatch, branch boundaries, final public guards and required correctness remain; this is not adoption. Allocation is NA; coarse heap and whole-process RSS are not per-value ownership/peak.
