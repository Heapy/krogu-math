#!/usr/bin/env kotlinr
// Task-owned JVM-only launch infrastructure; no numerical implementation.
import java.io.File
import java.security.MessageDigest
import java.time.Instant
import java.util.concurrent.TimeUnit

require(args.size == 9) { "artifactTree manifestSHA sourceTSV sourceSHA java javaSHA mode runtimeId newOutput" }
fun sha(f: File): String = MessageDigest.getInstance("SHA-256").digest(f.readBytes()).joinToString("") { "%02x".format(it) }
val tree = File(args[0]).canonicalFile.also { require(it.isDirectory) }
val source = File(args[2]).canonicalFile
val java = File(args[4]).canonicalFile.also { require(it.isFile && it.canExecute()) }
val mode = args[6].also { require(it in listOf("kernel-small", "kernel-medium", "kernel-large", "cost", "public-small", "square-control")) }
val runtimeId = args[7].also { require(it.isNotBlank() && !it.contains('\n')) }
val output = File(args[8]).canonicalFile
val taskRoot = File("/Users/yoda/dev/pet/krogu-math/.codex-work/539").canonicalFile
require(output.toPath().startsWith(taskRoot.toPath()) && !output.exists())
val manifest = File(tree, "manifest.sha256")
check(sha(manifest) == args[1] && sha(source) == args[3] && sha(java) == args[5])
val launcher = File(taskRoot, "run-jvm-calibration.main.kts")
val launcherSha = sha(launcher)
fun parse(file: File): List<Pair<String, String>> = file.readLines().map { line ->
    val fields = line.split('\t'); require(fields.size == 2 && fields[0].matches(Regex("[a-f0-9]{64}")))
    fields[0] to fields[1]
}.also { require(it.isNotEmpty() && it.map { p -> p.second }.toSet().size == it.size) }
val artifacts = parse(manifest).map { (hash, name) ->
    require(!File(name).isAbsolute && name.split('/').none { it == ".." || it == "." })
    val file = File(tree, name).canonicalFile
    require(file.toPath().startsWith(tree.toPath()) && file.isFile)
    hash to file
}
val sources = parse(source).map { (hash, name) ->
    val file = File(name).canonicalFile; require(file.isFile && file.toPath().startsWith(taskRoot.toPath()))
    hash to file
}
fun verify() {
    check(sha(manifest) == args[1] && sha(source) == args[3] && sha(java) == args[5] && sha(launcher) == launcherSha)
    for ((hash, file) in artifacts + sources) check(sha(file) == hash) { "Changed bound input: $file" }
    check(tree.walkTopDown().filter { it.isFile }.map { it.canonicalFile }.toSet() == artifacts.map { it.second }.toSet() + manifest)
}
verify()
val classpath = File(tree, "classpath.txt").readLines().map { name ->
    require(!File(name).isAbsolute)
    File(tree, name).canonicalFile.also { check(it in artifacts.map { p -> p.second }) }.path
}.joinToString(File.pathSeparator)
check(output.mkdirs())
fun clean(builder: ProcessBuilder) {
    builder.environment().clear()
    builder.environment()["LANG"] = "C"
    builder.environment()["TZ"] = "UTC"
}
fun execute(command: List<String>, log: File, seconds: Long) {
    File(log.path + ".argv.txt").writeText(command.joinToString("\n", postfix = "\n"))
    val builder = ProcessBuilder(command).redirectErrorStream(true).redirectOutput(log)
    clean(builder)
    val child = builder.start()
    var completed = false
    var failure: Throwable? = null
    try {
        File(log.path + ".identity.txt").writeText("pid=${child.pid()} start=${child.toHandle().info().startInstant().orElse(null)}\n")
        completed = child.waitFor(seconds, TimeUnit.SECONDS)
        check(completed) { "Deadline: $log" }
        check(child.exitValue() == 0) { "Child failed: $log exit=${child.exitValue()}" }
    } catch (caught: Throwable) {
        failure = caught
        throw caught
    } finally {
        if (!completed || child.isAlive) {
            var cleanupFailure: Throwable? = null
            fun record(caught: Throwable) {
                if (cleanupFailure == null) cleanupFailure = caught else cleanupFailure!!.addSuppressed(caught)
            }
            val descendants = try { child.toHandle().descendants().toList() }
                catch (caught: Throwable) { record(caught); emptyList() }
            for (handle in descendants.asReversed() + child.toHandle()) {
                try { handle.destroyForcibly() } catch (caught: Throwable) { record(caught) }
            }
            val until = System.nanoTime() + TimeUnit.SECONDS.toNanos(10)
            val capturedInterrupt = Thread.interrupted()
            var interrupted = capturedInterrupt || failure is InterruptedException
            for (handle in descendants + child.toHandle()) {
                while (handle.isAlive && System.nanoTime() < until) {
                    try { handle.onExit().get(maxOf(1L, until - System.nanoTime()), TimeUnit.NANOSECONDS); break }
                    catch (_: InterruptedException) { interrupted = true }
                    catch (_: java.util.concurrent.TimeoutException) { break }
                    catch (caught: Throwable) { record(caught); break }
                }
            }
            val survivors = descendants.filter { it.isAlive }.map { it.pid() }
            if (child.isAlive || survivors.isNotEmpty())
                record(IllegalStateException("Owned cleanup survivors=$survivors rootAlive=${child.isAlive}"))
            if (interrupted) Thread.currentThread().interrupt()
            if (cleanupFailure != null) {
                if (failure != null) failure.addSuppressed(cleanupFailure!!) else throw cleanupFailure!!
            }
        }
    }
}

execute(listOf(java.path, "-XshowSettings:properties", "-version"), File(output, "runtime.log"), 10)
val runtime = File(output, "runtime.log").readText()
check("java.runtime.version = 25.0.4+9-LTS" in runtime && "java.vendor = BellSoft" in runtime)
File(output, "binding-before.txt").writeText("timestamp=${Instant.now()}\nlauncher_sha256=$launcherSha\nsource_manifest_sha256=${args[3]}\nartifact_manifest_sha256=${args[1]}\njava_sha256=${args[5]}\nruntime_id=$runtimeId\n")
// Launch/wait budget30min; hashing/compilation of this launcher and bounded cleanup are extra.
val deadline = System.nanoTime() + TimeUnit.MINUTES.toNanos(30)
for (fork in 0..2) {
    verify()
    val order = if (fork == 1) "reverse" else "forward"
    val log = File(output, "fork$fork.log")
    val command = listOf("/usr/bin/time", "-l", java.path, "-Xms256m", "-Xmx512m", "-XX:+UseG1GC",
        "-Dkrogu539.main=" + File(tree, "main.jar").path,
        "-Dkrogu539.probe=" + File(tree, "probe.jar").path,
        "-cp", classpath, "CalibrationLaunch539", "$mode,$order,7,20")
    val seconds = minOf(600L, TimeUnit.NANOSECONDS.toSeconds(deadline - System.nanoTime()))
    check(seconds > 0)
    execute(command, log, seconds)
    val identity = log.readLines().single { it.startsWith("# OWN539 ") }
    val pid = Regex("pid=([0-9]+)").find(identity)!!.groupValues[1]
    val start = Regex("start_epoch_ms=([0-9]+)").find(identity)!!.groupValues[1]
    File(log.path + ".exit").writeText("0\n")
    File(log.path + ".binding").writeText("source_manifest_sha256=${args[3]}\nartifact_manifest_sha256=${args[1]}\nruntime_id=$runtimeId\npid=$pid\nstart_epoch_ms=$start\n")
    verify()
    println("COMPLETE JVM $mode fork=$fork order=$order")
}
File(output, "EXECUTED_NOT_YET_METRICS_VALIDATED").writeText("Three fresh children exit0; strict checker and independent raw audit pending. RSS includes reference preparation/runtime.\n")
println("PASS bound execution; not calibration or policy acceptance")
