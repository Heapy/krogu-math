# Final Native public serial retention — actual2087

Source3f0e1fb8; independentraw PASSa957621d. All45 FIRST/1260warm, source/runtime/nativehashes/CSVstatistics/identities and45INPUT+360outside-counterWorker-IDequalities+45NONE_STARTED validated. Currentpublicparallel is compileddirectvirtualmultiply, not the historicalcandidate Worker route.

| Words / shape | Parallel/publicmultiply ratios F/R/F | Parallel/fastest kernel-frame-public ratios F/R/F | CPU ratios vs same fastest comparator F/R/F | Parallel median ms | FIRST ms F/R/F |
|---|---|---|---|---:|---|
| 256/distinct | 1.010/1.115/0.892 | 1.017/1.115/1.004 | 1.021/1.135/1.009 | 0.024 | 0.024/0.031/0.028 |
| 256/square | 0.974/0.992/1.161 | 1.356/1.472/1.586 | 1.331/1.441/1.555 | 0.032 | 0.026/0.031/0.029 |
| 256/ratio2 | 0.985/0.938/1.141 | 1.007/1.036/1.141 | 1.007/1.026/1.150 | 0.056 | 0.050/0.060/0.069 |
| 1024/distinct | 1.039/0.793/1.154 | 1.055/0.937/1.188 | 1.046/0.935/1.188 | 0.239 | 0.205/0.231/0.350 |
| 1024/square | 1.206/1.048/0.976 | 1.429/1.168/1.005 | 1.427/1.172/1.008 | 0.306 | 0.204/0.231/0.386 |
| 1024/ratio2 | 0.791/0.958/1.111 | 0.793/1.014/1.115 | 0.797/1.014/1.098 | 0.519 | 0.736/0.433/0.664 |
| 4096/distinct | 0.990/0.974/1.004 | 0.990/0.996/1.006 | 0.984/0.996/1.005 | 1.879 | 2.336/1.849/3.251 |
| 4096/square | 1.022/1.005/0.888 | 1.023/1.051/0.897 | 1.025/1.046/0.897 | 1.948 | 1.925/1.949/2.426 |
| 4096/ratio2 | 1.000/1.013/1.423 | 1.000/1.041/1.423 | 1.002/1.043/1.424 | 4.061 | 3.941/3.925/6.132 |
| 8192/distinct | 1.009/0.973/0.490 | 1.014/1.006/0.580 | 1.011/1.003/0.563 | 5.705 | 5.649/5.611/12.672 |
| 8192/square | 1.015/1.027/1.018 | 1.015/1.027/1.018 | 1.018/1.020/1.024 | 5.859 | 5.753/5.795/6.154 |
| 8192/ratio2 | 1.006/0.991/1.394 | 1.006/0.996/1.497 | 1.006/0.989/1.487 | 12.130 | 12.287/11.835/14.461 |
| 16384/distinct | 1.039/0.949/1.020 | 1.043/1.107/1.075 | 1.041/1.113/1.084 | 21.574 | 17.186/17.789/27.915 |
| 16384/square | 1.019/1.141/1.002 | 1.019/1.205/1.128 | 1.016/1.205/1.128 | 24.026 | 20.234/20.756/24.335 |
| 16384/ratio2 | 0.845/1.052/1.450 | 1.004/1.052/1.685 | 1.007/1.052/1.668 | 43.174 | 46.148/49.642/61.410 |

FIRST ranges0.024–61.410ms acrossallpoints. It is first public serial call after untimedinput/oracle andbaselineWorker.current observation, not workeractivation/pristineVM/matchedfirstspeedup. Completedwholechild maxRSS19,873,792–21,463,040bytes andfootprint13,074,864–14,664,112bytes includeallroutes/checks/exit, notperroute/owned memory. AllocationNA andlastGCheapcoarse remain.

Execution/contract/absence disposition: PASS. KeepNative explicitparallel API on directvirtualserial fallback. Same selectedscalarpolicy physicalequal-lengthnonaliasK32, othersK64, leaf16/wholeentry384. EightendpointWorker-ID equality witnesses perpoint plusterminal equality are no-new-worker observations, not tracinginsidearithmetic orproof ofhistoricalcleanup. The compiled19instruction/48byteframe directcall proof independently removes the refused activeprefix; these measurements alone do notprove absence oftransientworker use.

Performance disposition: describe these serial public comparisons only. Largeadverse/mixed ratios retained, no backendgain orparallel20/10adoption assertion from serialroutes. Historicalactive aa9 nine eligible wins, fullpercallWorkerlife, CPU1.003–2.093 andtwo mixedsmallflags remain originalsourcecandidate evidence. Currentretention removes identifiedchangedcompactprefix statically; it doesnotmeasure a newsmall28, repairordinary30, waiveoldflags asnoise orproveisolatedlatencyrecovery. No furthernumericrerun/sourcefix proposed bythisreview.

Final stablefourtargetfullcorrectness/source/artifactpackaging remain separate. EarlierJVM acceptedtimings andJS/Wasm declinedconsumer/actualpublic observations keeporiginalartifact IDs andboundedunchanged-executable applicability, without pretending currentwholeJAR/JSdebugmap byteidentity.
