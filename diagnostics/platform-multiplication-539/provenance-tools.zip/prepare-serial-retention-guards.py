from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
old=json.loads((p/'fused-compact-three-guards-prelaunch.json').read_text());build=json.loads((p/'serial-retention-artifacts.json').read_text());source=p/'serial-retention-source.tsv';groups=[]
for g in old['groups'][1:]:
 target='js' if g['platform']=='JS' else 'wasmJs'; info=build['roots'][target];a=g['argv']; previous={a[4]:info['tree'],a[5]:info['manifest_sha256'],a[6]:str(source),a[7]:sha(source),a[-1]:a[-1].replace('paired-small-4','paired-small-5')}
 for key in ['argv','post_checker_argv']:g[key]=[previous.get(x,x.replace('paired-small-4-summary','paired-small-5-summary')) for x in g[key]]
 assert not Path(g['argv'][-1]).exists();groups.append(g)
plan={'source':build['source'],'source_files':405,'source_manifest':str(source),'source_manifest_sha256':sha(source),'build_summary':str(p/'serial-retention-artifacts.json'),'build_summary_sha256':sha(p/'serial-retention-artifacts.json'),'focused_summary':str(p/'serial-retention-focused-1-results/summary.json'),'payload_bindings':str(p/'serial-retention-payload-bindings.json'),'groups':groups,'scope':'Final planned JS/Wasm direct-serial retained-route paired28; all historical flags preserved, no repeat-until-green or inferred ordinary511 recovery.'}
(p/'serial-retention-two-guards-prelaunch.json').write_text(json.dumps(plan,indent=2)+'\n')
