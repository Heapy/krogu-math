# Independent Native square control raw audit

Recorded-data analysis only.

```bash
python3 - <<'PY'
from pathlib import Path
import json,csv,re,hashlib,statistics as st,math
p=Path('.codex-work/539');platform='native';kind='Native';mode='square-control'
d=p/f'calibration-{platform}-{mode}-1';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
summary=json.loads((p/f'calibration-{platform}-{mode}-1-summary.json').read_text());batch=json.loads((p/'native-selected-prelaunch-batch.json').read_text());pre=next(x for x in batch['groups'] if x['mode']==mode);tree=p/'artifacts/native-release-841a8b8';manifest_sha=sha(tree/'manifest.sha256')
policies=list(dict.fromkeys([(x,16,384) for x in [32,64,128,256]]+[(64,x,384) for x in [4,8,16,32]]+[(64,16,x) for x in [0,128,256,384,512,1024]]))
if mode.startswith('kernel-'):
 ids=[]
 for n in {'kernel-small':[8,16,31,32,63,64],'kernel-medium':[96,128,192,256,383,384,512],'kernel-large':[1024,4096,8192]}[mode]:
  for shape in ['distinct','square','ratio2','ratio4']:
   ids += [f'kernel/{n}/{shape}/k{k}-s{s}-e{e}' for k,s,e in policies if shape=='square' or (s,e)==(16,384)]
   if n>=64 and shape!='ratio4':ids += [f'frame-serial/{n}/{shape}']
elif mode=='square-control':ids=[f'square-control/{n}/e{e}' for n in [128,192,256,384,512,1024] for e in [0,384,1024,2147483647]]
elif mode=='cost':ids=['cost/'+x for x in ['signed-long-256','unsigned-long-256','int-carry-256','allocate-256-words','allocate-4096-words']]
else:ids=[f'{method}/{bits}/{shape}' for bits in [1,30,63,64,127,511,1023] for shape in ['distinct','square'] for method in ['public','parallel-public']]
assert len(set(ids))==len(ids)
assert summary['exit']==summary['checker_exit']==0
assert sha(p/f'calibration-{platform}-{mode}-1.csv')==summary['csv_sha256']
for r in summary['raw']:assert sha(d/f"fork{r['fork']}.log")==r['sha256']
groups_by_fork={};identities=[];hashes={};envelopes=[];cache_counts=[]
for fork in range(3):
 f=d/f'fork{fork}.log';text=f.read_text();lines=text.splitlines();order='reverse' if fork==1 else 'forward'
 assert Path(str(f)+'.exit').read_text().strip()=='0'
 binding=dict(x.split('=',1) for x in Path(str(f)+'.binding').read_text().splitlines());assert binding['source_manifest_sha256']==pre['argv'][5] and binding['artifact_manifest_sha256']==manifest_sha
 ni=Path(str(f)+'.native-identity.txt').read_text().strip();m=re.fullmatch(r'pid=(\d+) start_epoch_ms=(\d+) executable=(.+)',ni);assert m
 pid,start,exe=m.groups();assert int(pid)>0 and int(start)>0 and exe==pre['argv'][6];assert binding['pid']==pid and binding['start_epoch_ms']==start;identities.append((pid,start))
 header=next(x for x in lines if x.startswith('# calibration539 '));assert re.fullmatch(r'# calibration539 platform=Native MACOSX ARM64 processors=\d+ mode='+mode+' order='+order+' cases='+str(len(ids)),header)
 assert '[==========] Running 1 tests from 105 test cases.' in lines and '[  PASSED  ] 1 tests.' in lines
 checks=[x.split(',') for x in lines if x.startswith('CHECK539,')];assert all(x[2]=='PASS' for x in checks);assert [x[1] for x in checks]==(list(reversed(ids)) if fork==1 else ids)
 assert lines.count(f'PASS539,{len(ids)},7')==1
 reps=[x.split(',') for x in lines if x.startswith('REP539,')]
 if mode=='public-small':
  assert len(reps)==28 and {x[1] for x in reps}==set(ids)
  for _,name,value in reps:
   method,bits,shape=name.split('/');bits=int(bits);v=(1<<(bits-1))+(0 if bits==1 else 1);assert int(value)==(v*v if shape=='square' else v*(v+2))
 else:assert not reps
 argv=Path(str(f)+'.argv.txt').read_text().splitlines();assert argv==['/usr/bin/time','-l',pre['argv'][6],'--ktest_filter=io.heapy.krogu.math.MultiplicationCalibration539.optionalCampaign']
 rows=list(csv.reader(x for x in lines if x.startswith('TIME539,')));assert len(rows)==len(ids)*7;groups={}
 for row in rows:
  assert len(row)==9;_,name,sample,count,wall,cpu,allocated,heap,digest=row
  sample,count,wall,cpu,digest=map(int,[sample,count,wall,cpu,digest]);assert name in ids and sample in range(7) and 1<=count<=8388608 and count&(count-1)==0 and 0<wall<=60_000_000_000 and cpu>=0 and -(2**31)<=digest<2**31
  assert allocated=='NA'
  if kind=='Wasm':assert heap=='NA';heap=None
  elif kind=='Native' and heap=='NA':heap=None
  else:heap=int(heap);assert heap>=0
  groups.setdefault(name,[]).append(dict(sample=sample,count=count,wall=wall,cpu=cpu,heap=heap,digest=digest))
 assert set(groups)==set(ids)
 for name,g in groups.items():
  assert len(g)==7 and {x['sample'] for x in g}==set(range(7)) and len({x['count'] for x in g})==1 and len({x['digest'] for x in g})==1
  hashes.setdefault(name,set()).update(x['digest'] for x in g)
 groups_by_fork[fork]=groups
 rss=re.search(r'^\s*(\d+)\s+maximum resident set size$',text,re.M);peak=re.search(r'^\s*(\d+)\s+peak memory footprint$',text,re.M);assert rss and peak;envelopes.append(dict(fork=fork,whole_process_rss_bytes=int(rss[1]),whole_process_peak_footprint_bytes=int(peak[1])))
assert len(set(identities))==3
fullring={name:all(groups_by_fork[i][name][0]['count']>=64 for i in range(3)) for name in ids};assert all(len(hashes[name])==1 for name in ids if fullring[name])
result=[]
for name in sorted(ids):
 gs=[groups_by_fork[i][name] for i in range(3)];wall=[st.median(x['wall']/x['count'] for x in g) for g in gs];cpu=[st.median(x['cpu']/x['count'] for x in g) for g in gs];heaps=[x['heap'] for g in gs for x in g if x['heap'] is not None]
 result.append(dict(case=name,wall_median_ns=st.median(wall),wall_min_process_median_ns=min(wall),wall_max_process_median_ns=max(wall),cpu_median_ns=st.median(cpu),caller_allocated_median_bytes=None,coarse_heap_max_bytes=max(heaps) if heaps else None,fork_wall_ns=wall,fork_cpu_ns=cpu))
owner=list(csv.DictReader((p/f'calibration-{platform}-{mode}-1.csv').open()));assert len(owner)==len(ids)
for a,b in zip(owner,result):
 assert a['case']==b['case']
 for k in ['wall_median_ns','wall_min_process_median_ns','wall_max_process_median_ns','cpu_median_ns','caller_allocated_median_bytes','coarse_heap_max_bytes']:
  if b[k] is None:assert a[k]=='NA'
  else:assert math.isclose(float(a[k]),b[k],rel_tol=1e-14,abs_tol=1e-9),(a['case'],k,a[k],b[k])
byid={x['case']:x for x in result};comparisons=[]
if mode.startswith('kernel-') or mode=='square-control':
 for r in result:
  parts=r['case'].split('/');base=('kernel/'+parts[1]+'/'+parts[2]+'/k64-s16-e384') if mode.startswith('kernel-') else ('square-control/'+parts[1]+'/e384');b=byid[base]
  ratios=[x/y for x,y in zip(r['fork_wall_ns'],b['fork_wall_ns'])]
  if fullring[r['case']] and fullring[base]:assert hashes[r['case']]==hashes[base]
  comparisons.append(dict(case=r['case'],same_operand_baseline=base,paired_ratios=ratios,median_ratio=st.median(ratios),all3_slower=min(ratios)>1,all3_faster=max(ratios)<1))
for h,f in [x.split('\t') for x in Path(pre['argv'][4]).read_text().splitlines()]:assert sha(Path(f))==h
assert all(sha(Path(f))==h for f,h in batch['runtime_files'].items())
assert all(sha(tree/f)==h for h,f in [x.split('\t') for x in (tree/'manifest.sha256').read_text().splitlines()])
r={'status':'INDEPENDENT_NODE_COMMON_RAW_BINDING_STATS_PASS_NOT_ADOPTED','platform':kind,'mode':mode,'handle':summary['handle'],'source':summary['source'],'cases':len(ids),'TIME':len(ids)*21,'CHECK_per_process':len(ids),'REP_per_process':28 if mode=='public-small' else 0,'source_files_verified':389,'fresh_process_identities':identities,'all_owner_CSV_stats_exact':True,'cache_origin_controls':cache_counts,'per_case':result,'relative_to_current_policy':comparisons,'whole_process_envelopes':envelopes,'cases_without_proven_fullring_measured_batches':[k for k,v in fullring.items() if not v],'scope':'ThreefreshF/R/F NativeRelease test processes; exactoneoptionaltest confirmed; Nativefullforcedschoolchecks (externaloraclehookstub, noJDK/Nodeclaim); completecase CHECKs distinctfrom64slot escapingringdigests. AllocationNA isnotzero; JScoarseheapUsed isnotpeak orownedretention, WasmheapNA. RSSwholeprocess includesMocha/registration/reference/runtime. Parameter-labelled differences mayselectidenticalarithmetic; no causalpolicy/threshold/parallel/publicadoption fromsubset. Publicmode iscurrentroute baseline, not afteradoptionguard.'}
(p/f'independent-{platform}-{mode}-1-raw-audit.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS',kind,mode,'TIME',len(ids)*21,'cases',len(ids),'NAallocation/CSV/identities/closure/sourcebound')
print('All3slower/faster default-relative',sum(x['all3_slower'] for x in comparisons),sum(x['all3_faster'] for x in comparisons),'sub64',sum(not v for v in fullring.values()))
PY
```
