Native 15583: raw PASS; guard investigation pending. Measured source 2d74; historical baseline 841a8b8.

| API / bits / shape | Three paired ratios | Three deltas (ns) | Consistency |
|---|---|---|---|
| parallel-public/1023/distinct | 1.318 / 0.991 / 1.285 | +517.794 / -11.556 / +296.270 | mixed |
| parallel-public/127/square | 1.259 / 1.893 / 1.004 | +31.554 / +55.007 / +0.410 | all three slower |
| parallel-public/30/distinct | 3.881 / 1.825 / 1.152 | +62.006 / +12.646 / +2.537 | all three slower |
| parallel-public/30/square | 1.209 / 1.824 / 1.130 | +5.634 / +12.589 / +1.970 | all three slower |
| parallel-public/511/square | 1.189 / 1.277 / 1.079 | +64.480 / +47.152 / +21.010 | all three slower |
| parallel-public/63/distinct | 1.135 / 1.843 / 1.328 | +15.692 / +54.975 / +21.193 | all three slower |
| parallel-public/63/square | 1.485 / 1.863 / 1.718 | +41.911 / +49.132 / +40.883 | all three slower |
| parallel-public/64/square | 1.677 / 1.323 / 1.061 | +64.820 / +15.962 / +4.791 | all three slower |
| public/1/square | 1.398 / 1.305 / 0.871 | +9.148 / +7.079 / -2.713 | mixed |
| public/1023/distinct | 1.137 / 1.543 / 1.169 | +256.010 / +641.158 / +199.989 | all three slower |
| public/1023/square | 1.410 / 1.142 / 1.448 | +325.974 / +97.968 / +224.435 | all three slower |
| public/127/distinct | 1.220 / 1.389 / 0.978 | +25.959 / +23.276 / -2.318 | mixed |
| public/30/distinct | 1.975 / 1.589 / 0.938 | +17.926 / +9.953 / -1.059 | mixed |
| public/30/square | 1.512 / 1.935 / 1.238 | +10.521 / +12.558 / +3.269 | all three slower |
| public/63/distinct | 1.635 / 1.842 / 1.321 | +67.207 / +54.087 / +20.509 | all three slower |
| public/63/square | 1.535 / 1.883 / 1.771 | +44.210 / +48.430 / +41.823 | all three slower |
| public/64/distinct | 1.185 / 1.781 / 1.709 | +15.844 / +38.610 / +38.021 | all three slower |
| public/64/square | 1.122 / 1.562 / 1.342 | +15.641 / +26.632 / +21.140 | all three slower |

All flags remain actionable investigation signals. Compact-fit controls never reach selected policy; 1023-bit distinct magnitudes activate K32, while 1023-bit alias magnitudes retain whole-square arithmetic. A min<32 shortcut alone cannot close the complete observed scope. Source-equivalent arithmetic does not prove identical optimized Native lowering.

Exact paths, source identities, per-case mapping and limits: `independent-native-small-guard-cause-scope.json`.
