from pathlib import Path
import subprocess,json,datetime,os,sys
p=Path(__file__).resolve().parent;plan=json.loads(Path(sys.argv[1]).read_text());g=next(g for g in plan['groups'] if g.get('name')==sys.argv[2]);output=Path(g['argv'][-1]);assert not output.exists();assert output.parent==p
s={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Shared unisolated host, snapshot only. Known icu4k Gradle unrelated/untouched; no continuous quiet claim.','ps':subprocess.check_output(['ps','-Ao','pid,ppid,%cpu,etime,comm'],text=True)};(p/(output.name+'-host-before.json')).write_text(json.dumps(s,indent=2)+'\n');print('\n'.join(sorted(s['ps'].splitlines()[1:],key=lambda x:float(x.split()[2]),reverse=True)[:5]),flush=True)
env=dict(os.environ)
for k in ['JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS','KOTLIN_RUNNER','KROGU539_ARGS']:env.pop(k,None)
env['JAVA_HOME']='/Users/yoda/.sdkman/candidates/java/25.0.4-librca'
(p/(output.name+'-invocation.json')).write_text(json.dumps({'argv':g['argv'],'cwd':g['cwd'],'source':plan['source'],'scope':'Exact prebound group; host snapshot outside controller. Terminal result separate.'},indent=2)+'\n')
with (p/(output.name+'-controller.log')).open('w') as log:r=subprocess.run(g['argv'],cwd=g['cwd'],env=env,stdout=log,stderr=subprocess.STDOUT)
print('CONTROLLER_EXIT',r.returncode,flush=True);raise SystemExit(r.returncode)
