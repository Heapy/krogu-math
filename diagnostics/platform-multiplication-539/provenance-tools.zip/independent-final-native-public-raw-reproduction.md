# Native final actual public raw audit reproduction

Run from repository root. This reads frozen raw/counters/CSV and writes the independent audit; no numerical execution.

```sh
python3 - <<'PY'
from pathlib import Path
import json,csv,re,hashlib,statistics as st
r=Path('.codex-work/539');d=r/'actual-public-native-route-final-1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();props=lambda p:dict(l.split('=',1) for l in p.read_text().splitlines() if '=' in l);pre=json.loads((r/'native-final-three-groups-prelaunch.json').read_text());g=next(z for z in pre['groups'] if z['name']=='final-actual-public');a=g['argv'];b=props(d/'binding-before.txt');assert b['source_manifest_sha256']==a[5] and b['artifact_manifest_sha256']==a[3] and b['executable_sha256']==a[7] and b['launcher_sha256']==g['launcher_sha256'] and b['executable_path']==a[6];assert sha(Path(a[6]))==a[7] and (d/'COMPLETE').is_file()
sizes=[256,1024,4096,8192,16384];shapes=['distinct','square','ratio2'];records=[];first=[];per={};identities=[];resources=[];rawbindings=[]
for f in range(3):
 for size in sizes:
  for shape in shapes:
   point=f'{size}/{shape}';order='reverse' if f==1 else 'forward';log=d/f'fork{f}-{size}-{shape}.log';t=log.read_text();ls=t.splitlines();bb=props(Path(str(log)+'.binding'));assert bb['source_manifest_sha256']==a[5] and bb['artifact_manifest_sha256']==a[3] and bb['runtime_id']==a[9] and bb['log_sha256']==sha(log) and bb['order']==order and bb['profile']==f'native-public-frontend,{size},{shape},{order}' and Path(str(log)+'.exit').read_text()=='0\n'
   ident=Path(str(log)+'.native-identity.txt').read_text().strip();m=re.fullmatch(r'pid=(\d+) start_epoch_ms=(\d+) executable=(.+)',ident);assert m and int(m[1])>0 and int(m[2])>0 and m[3]==a[6];identities.append((int(m[1]),int(m[2])));selector='io.heapy.krogu.math.NativePublicFrontendCalibration539.optionalPublicRoute';assert Path(str(log)+'.argv.txt').read_text().splitlines()==['/usr/bin/time','-l',a[6],'--ktest_filter='+selector]
   assert ls.count('[ RUN      ] '+selector)==1 and sum(x.startswith('[       OK ] '+selector+' (') for x in ls)==1 and ls.count('[  PASSED  ] 1 tests.')==1 and not any(x.startswith('[  FAILED  ]') for x in ls) and ls.count('PASS_PUBLICNATIVE539,'+point)==1
   ff=[x.split(',') for x in ls if x.startswith('FIRSTNATIVE539')];assert len(ff)==1 and len(ff[0])==4 and ff[0][1]==point and int(ff[0][2])>0 and int(ff[0][3])>=0;first.append(dict(fork=f,point=point,firstNs=int(ff[0][2]),cpuNs=int(ff[0][3])))
   k=32 if shape=='distinct' else 64;variants=[f'kernel-k{k}-s16-e384',f'frame-k{k}-s16-e384','serial','parallel'];expected=variants[::-1] if f==1 else variants;assert [x for x in ls if x.startswith('INVENTORYNATIVE539')]==['INVENTORYNATIVE539,'+point+','+';'.join(expected)]
   raw=[x.split(',') for x in ls if x.startswith('PUBLICNATIVE539')];assert len(raw)==28 and [(x[1].rsplit('/',1)[1],int(x[2])) for x in raw]==[(v,j) for v in expected for j in range(7)]
   groups={v:[] for v in variants}
   for x in raw:
    assert len(x)==9 and x[1].startswith(point+'/');v=x[1].rsplit('/',1)[1];sample,count,wall,cpu=map(int,x[2:6]);assert wall>0 and cpu>=0 and 1<=count<=8388608 and count&(count-1)==0 and x[6]=='NA';heap=None if x[7]=='NA' else int(x[7]);assert heap is None or heap>=0;z=dict(fork=f,point=point,variant=v,sample=sample,count=count,elapsedNs=wall,cpuNs=cpu,allocationBytes=None,lastGCHeapBytes=heap,resultHash=int(x[8]));records.append(z);groups[v].append(z)
   for v,z in groups.items():
    assert len({x['count'] for x in z})==len({x['resultHash'] for x in z})==1;ns=[x['elapsedNs']/x['count'] for x in z];per[f,point,v]=dict(wallNs=st.median(ns),minNs=min(ns),maxNs=max(ns),cpuNs=st.median(x['cpuNs']/x['count'] for x in z))
   assert groups[variants[0]][0]['resultHash']==groups[variants[1]][0]['resultHash'] and groups['serial'][0]['resultHash']==groups['parallel'][0]['resultHash'];assert ls.index(','.join(ff[0]))<ls.index(','.join(raw[0]))
   rss=int(re.search(r'^\s*(\d+)\s+maximum resident set size$',t,re.M)[1]);foot=int(re.search(r'^\s*(\d+)\s+peak memory footprint$',t,re.M)[1]);assert rss>0 and foot>0;resources.append(dict(fork=f,point=point,rss=rss,footprint=foot));rawbindings.append(dict(log=log.name,sha256=sha(log),binding_sha256=sha(Path(str(log)+'.binding')),pid=int(m[1]),start_epoch_ms=int(m[2])))
assert len(identities)==len(set(identities))==45 and len(records)==1260 and len(first)==45
for size in sizes:
 for shape in shapes:
  p=f'{size}/{shape}';k=32 if shape=='distinct' else 64
  for v in [f'kernel-k{k}-s16-e384',f'frame-k{k}-s16-e384','serial','parallel']:assert len({x['resultHash'] for x in records if x['point']==p and x['variant']==v})==1
csvrows=list(csv.DictReader((d/'strict-results/warm.csv').open()));assert len(csvrows)==len(records)
for x,z in zip(csvrows,records):
 for key,v in z.items():assert x[key]==('NA' if v is None else str(v))
for x in csv.DictReader((d/'strict-results/per-fork.csv').open()):
 z=per[int(x['fork']),x['point'],x['variant']]
 for column,key in [('medianNs','wallNs'),('minNs','minNs'),('maxNs','maxNs'),('medianCpuNsPerOp','cpuNs')]:assert float(x[column])==z[key]
for x in csv.DictReader((d/'strict-results/first.csv').open()):
 z=next(t for t in first if t['fork']==int(x['fork']) and t['point']==x['point']);assert int(x['firstNs'])==z['firstNs'] and int(x['cpuNs'])==z['cpuNs']
for x in csv.DictReader((d/'strict-results/first-summary.csv').open()):
 z=[t['firstNs'] for t in first if t['point']==x['point']];assert float(x['medianFirstNs'])==st.median(z) and int(x['minFirstNs'])==min(z) and int(x['maxFirstNs'])==max(z)
for x in csv.DictReader((d/'strict-results/whole-process-resources.csv').open()):
 z=next(t for t in resources if t['fork']==int(x['fork']) and t['point']==x['point']);assert int(x['wholeChildMaxRSSBytes'])==z['rss'] and int(x['wholeChildPeakFootprintBytes'])==z['footprint']
for x in csv.DictReader((d/'strict-results/pooled.csv').open()):
 z=[t for t in records if t['point']==x['point'] and t['variant']==x['variant']];ns=[t['elapsedNs']/t['count'] for t in z];assert float(x['pooledMedianNs'])==st.median(ns) and float(x['minNs'])==min(ns) and float(x['maxNs'])==max(ns) and int(x['minBatchNs'])==min(t['elapsedNs'] for t in z) and int(x['maxBatchNs'])==max(t['elapsedNs'] for t in z) and int(x['cappedSamples'])==sum(t['count']==8388608 for t in z)
comparisons=[]
for size in sizes:
 for shape in shapes:
  p=f'{size}/{shape}';k=32 if shape=='distinct' else 64;variants=[f'kernel-k{k}-s16-e384',f'frame-k{k}-s16-e384','serial'];chosen=[min(variants,key=lambda v:per[f,p,v]['wallNs']) for f in range(3)];par=[per[f,p,'parallel'] for f in range(3)];rat=[par[f]['wallNs']/per[f,p,chosen[f]]['wallNs'] for f in range(3)];cpu=[par[f]['cpuNs']/per[f,p,chosen[f]]['cpuNs'] for f in range(3)];comparisons.append(dict(point=p,eligible_physical=size>=4096,fastest_variants=chosen,wall_ratios=rat,cpu_ratios=cpu,latency_margin_pass=st.median(rat)<=.80 and max(rat)<=.90,parallel_fork_wall_ns=[z['wallNs'] for z in par],fastest_fork_wall_ns=[per[f,p,chosen[f]]['wallNs'] for f in range(3)],parallel_fork_cpu_ns=[z['cpuNs'] for z in par],fastest_fork_cpu_ns=[per[f,p,chosen[f]]['cpuNs'] for f in range(3)],parallel_over_publicserial_wall=[par[f]['wallNs']/per[f,p,'serial']['wallNs'] for f in range(3)]))
for x in csv.DictReader((d/'strict-results/paired-all-comparators.csv').open()):
 p=x['point'];c=x['comparator'];z=next(t for t in comparisons if t['point']==p);rat=z['wall_ratios'] if c=='fastest-matched-serial' else [per[f,p,'parallel']['wallNs']/per[f,p,c]['wallNs'] for f in range(3)];assert all(float(x[f'fork{f}ratio'])==rat[f] for f in range(3)) and float(x['medianPairedRatio'])==st.median(rat) and float(x['maxPairedRatio'])==max(rat)
for h,p in (x.split('\t') for x in Path(a[4]).read_text().splitlines()):assert sha(Path(p))==h
out={'status':'PASS_INDEPENDENT_ACTUAL_NATIVE_PUBLIC_RAW_STATS_LIFETIME_NO_AUTOMATIC_ADOPTION','handle':50930,'source':pre['source'],'source_manifest_sha256':a[5],'executable_sha256':a[7],'FIRST':45,'WARM':1260,'actual_identities':identities,'raw_bindings':rawbindings,'first':first,'resources':resources,'comparisons':comparisons,'scope':'Selectedcurrentdistinct32/other64,entry384/leaf16; parallelchildren64. Samepoint fastestactualcurrentkernel/frame/publicserial comparator,7samples and3freshF/R/F, allnativeoutput/input/sourceboundchecks/NA/counts/CSV preserved. For eligible>=4096words nativeWorker lifecycle peroperation start/copy/localwork/join/termination, no reusedpool. Everyactualbackenddecline/failurecontract remains separate from sourceeligiblefixture normalruns; no externalJDK/Nodeoracle onNative. FIRSTfirstpublicactivationattempt afteruntimedschool/BIprep, not matchedfirstspeedup. AllocationNA/lastGCheapcoarse; wholechildRSS/footprint includesallroutes/checks/exit, notperroute/peropownedmemory. Mixedsmallguardflags handledseparately.'};p=r/'independent-actual-public-native-route-final-1-raw-audit.json';p.write_text(json.dumps(out,indent=2)+'\n');print('PASS',sha(p));print('eligiblepasses',sum(x['eligible_physical'] and x['latency_margin_pass'] for x in comparisons));print('CPUratiorange',min(v for x in comparisons if x['eligible_physical'] for v in x['cpu_ratios']),max(v for x in comparisons if x['eligible_physical'] for v in x['cpu_ratios']));print('RSSrange',min(z['rss'] for z in resources),max(z['rss'] for z in resources),'footrange',min(z['footprint'] for z in resources),max(z['footprint'] for z in resources));print('FIRSTeligiblems',min(x['firstNs'] for x in first if int(x['point'].split('/')[0])>=4096)/1e6,max(x['firstNs'] for x in first if int(x['point'].split('/')[0])>=4096)/1e6)
for x in comparisons:print(x['point'],','.join(f'{v:.3f}' for v in x['wall_ratios']),'CPU',','.join(f'{v:.3f}' for v in x['cpu_ratios']),x['latency_margin_pass'])
PY
```
