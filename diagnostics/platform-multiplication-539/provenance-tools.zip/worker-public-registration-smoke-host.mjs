import { Worker, MessageChannel, receiveMessageOnPort, isMainThread } from 'node:worker_threads';
import { availableParallelism } from 'node:os';
import { pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const [entry, kind, order, samplesText, rootDirectoryArg] = process.argv.slice(2);
const samples = Number(samplesText);
const entryURL = pathToFileURL(entry).href;
if (process.version !== 'v24.16.0') throw Error('Pinned Node v24.16.0 required');
const started = performance.now();
await import(entryURL);
if (typeof globalThis.__krogu539Invoke !== 'function') throw Error('Private diagnostic callback not registered');
const originalTinyInvoke=globalThis.__krogu539Invoke;
console.log('MODULE539,parent_import_ms,' + (performance.now() - started));
const rootDirectory=fs.realpathSync(rootDirectoryArg);
const rootRequire=createRequire(path.join(rootDirectory,'mocha','package.json'));
function rootPath(relative) {
  if(path.isAbsolute(relative)||relative.split('/').some(p=>p===''||p==='.'||p==='..')) throw Error('Invalid parent artifact path');
  const resolved=fs.realpathSync(path.join(rootDirectory,relative));
  if(!resolved.startsWith(rootDirectory+path.sep)) throw Error('Parent origin outside bound tree');
  return resolved;
}
function verifyRootCache(phase) {
  let count=0;
  for(const filename of Object.keys(rootRequire.cache)) {
    const real=fs.realpathSync(filename);
    if(!real.startsWith(rootDirectory+path.sep) && !real.startsWith(fs.realpathSync(path.dirname(entry))+path.sep)) throw Error('Parent CJS outside both bound closures: '+real);
    count++;
  }
  console.log('ROOTCACHE539,'+phase+','+count+',owned');
}
const rootStarted=performance.now();
const rootEntry=rootPath(fs.readFileSync(rootPath('entry.txt'),'utf8').trim());
const mochaEntry=rootPath('mocha/node_modules/mocha/index.js');
const Mocha=rootRequire(mochaEntry);
const mocha=new Mocha({ui:'bdd',reporter:'dot',timeout:0,grep:/MultiplicationCalibration539.*optionalCampaign/});
mocha.addFile(rootEntry);
await mocha.loadFilesAsync();
if(kind==='wasm') {
  const module=await import(pathToFileURL(rootEntry).href);
  if(typeof module.startUnitTests!=='function') throw Error('Missing parent Wasm startUnitTests');
  if(globalThis.kotlinTest===undefined) globalThis.kotlinTest={adapterTransformer:adapter=>adapter};
  module.startUnitTests();
}
const selected=[];
mocha.suite.eachTest(test=>{
  if(!/MultiplicationCalibration539.*optionalCampaign/.test(test.fullTitle())) return;
  selected.push(test.fullTitle());
  for(let suite=test.parent;suite!==undefined&&suite!==null;suite=suite.parent) {
    for(const name of ['_beforeAll','_beforeEach','_afterEach','_afterAll']) {
      if(!Array.isArray(suite[name])||suite[name].length!==0) throw Error('Parent registration must have no inherited hooks: '+name);
    }
  }
});
if(selected.length!==1) throw Error('Expected one parent registration test');
verifyRootCache('before-register');
await new Promise((resolve,reject)=>{
  const runner=mocha.run(failures=>{
    const stats=runner.stats;
    if(failures!==0||stats.tests!==1||stats.passes!==1||stats.pending!==0) reject(Error('Parent registration test failed'));
    else resolve();
  });
});
verifyRootCache('after-register');
if(globalThis.__krogu539Invoke!==originalTinyInvoke) throw Error('Root replaced tiny callback');
if(typeof globalThis.__krogu539PublicInvoke!=='function') throw Error('Missing parent public callback');
console.log('ROOTMODULE539,parent_load_register_ms,'+(performance.now()-rootStarted));
console.log('ROOTORIGIN539,'+rootEntry+','+mochaEntry);

console.log('# PUBLICSMOKE539 pid='+process.pid+' start_ms='+Date.now());
function reference(words) { let n=0n; for(let i=words.length-1;i>=0;i--) n=(n<<30n)+BigInt(words[i]); return n; }
function words(value) { const out=[]; do {out.push(Number(value&0x3fffffffn));value>>=30n;}while(value!==0n);return Int32Array.from(out); }
for(const same of [false,true]) {
  const a=Int32Array.from({length:256},(_,i)=>(i*104729+31)&0x3fffffff);
  const b=same?a:a.slice();
  globalThis.__krogu539PublicRequest={inputs:[a,b,words(reference(a)*reference(b)),Int32Array.from([64,16,384])],same};
  globalThis.__krogu539PublicInvoke(0);globalThis.__krogu539PublicRequest=null;
  globalThis.__krogu539PublicInvoke(1);globalThis.__krogu539PublicInvoke(2);
  if(!Number.isInteger(globalThis.__krogu539PublicHash))throw Error('Missing verified public hash');
  console.log('PUBLICSMOKE539,'+(same?'square':'distinct')+','+globalThis.__krogu539PublicHash);
  globalThis.__krogu539PublicInvoke(3);
}
verifyRootCache('after-smoke');
if(globalThis.__krogu539Invoke!==originalTinyInvoke)throw Error('Root replaced tiny callback');
console.log('PASS_WORKER_PUBLIC_REGISTRATION539');
