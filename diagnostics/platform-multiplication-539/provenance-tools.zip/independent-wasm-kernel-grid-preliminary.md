# Preliminary complete Wasm417 serial grid — not adoption

All417 kernel configurations independently audited:384 forced policies and33 serial-frame controls,8757 TIME rows. JSON retains every actual three-fork ratio, adjacent measured-size consistency, adverse and source-activity classification. This adapts the existing JVM/JS grid analysis, with no new run or new serial acceptance threshold. Frozen20%/10% margin remains PARALLEL-only.

| Candidate / shape | Actual evidence | Contra / interpretation |
|---|---|---|
| K32 / distinct | Medium96=.981/.899/.920;128=.893/.943/.961;192=.921/.825/.928;383=.928/.759/.952;384=.925/.832/.920;512=.945/.807/.998 all3lower |32/63 activepoints all3adverse;256mixed. Large1024=.966/.888/1.067,4096=.977/.956/.981,8192=.983/1.907/1.021. Only4096all3lower; no broad/larger-size benefit or JS-like consistency |
| K32 / ratio2 |96,192,383 all3lower |512=1.016/1.088/1.020 all3adverse;1024=1.018/.886/1.045,4096=.986/1.883/.896,8192=.994/1.035/1.105 mixed. No monotone threshold |
| K32 / ratio4 |192=.932/.841/.968,383=.946/.832/.919 and1024=.977/.905/.793 all3lower |32/63/64 all3adverse;256=1.008/1.209/1.030 all3adverse.4096=1.000/.984/1.255 and8192=1.004/.978/1.105 mixed. Displayed1.000 is rounded; exactratio inJSON |
| Entry128 / square |383=.925/.558/.823 all3lower on activewhole-square→recursive difference |128=1.257/1.391/1.189 all3adverse on sameactivechange;192/256mixed.384/512 observations selectidenticalrecursionasdefault andcannotproveentrybenefit. Large1024=1.007/.892/1.092,4096=1.020/1.256/.949,8192=.998/.627/1.272 mixed on identicalarithmetic |
| Leaf8 / square | Some isolated/mixed lower observations retained inJSON | Below384 bothwhole-square whereeligible: no causal leaf8 attribution. Large1024=1.026/.891/.864,4096=.999/1.456/1.055,8192=.994/1.157/1.018 allmixed; actualrecursivealiasleafactivityrequiredbeforecausalclaim |

Large subset has25all3adverse configurations andonly2all3lower versus default (includingframecomparators): K32ratio4/1024 andK32distinct/4096. Allotherlargecandidate observations aremixed/equal/adverse. This is descriptive consistency, not an automaticreject threshold or final chosen policy. Resourcecosts and selectedpublicroute remain separate.

Source activity is essential: nonalias inputs belowbothKthresholds useidenticalschoolarithmetic; whole-square dispatcher bypassesK; entry-onlyvariants at1024/4096/8192 alluseidenticalK64/leaf16recursionasdefault. Timingdifferences on these duplicatepaths are run/JIT/hostvariabilitycontrols, not causal entry tuning. Recursive leaf length/sum alias behavior is not reconstructed from policy labels.

No final Wasm choice. Existing square24/cost5/public28 controls are stillpending, asare finalselected-route checks andpublicbefore/afterguard. JS policy signals do not transfer automatically. Allocation andheap areNA, notzero; RSSincludeswholeprocess/runtime/reference setup.65largeconfigurations haveasub64measured batch: stablewithin-case samples do notisolatecrossforkringdigests; completeuntimedCHECKsremain arithmeticproof. Failed49545registrationrun and56556registration-onlysmokeareseparatefromacceptednumericdata.

## Separate square controls accepted (24 cases /504 TIME)

Active e0recursion/defaultwhole-square at128=1.196/.936/1.076 and256=.997/.242/1.086 aremixed;192=1.073/1.086/1.574 all3adverse. This does not reproduce JS medium-square consistency. Purewhole-square at1024(MAXentry) is all3adverse1.481/1.408/1.120; at384/512 itismixed, includinge1024/384=1.080/5.074/.984. The5.074pairisretained, notaveragedawayorassignedacause.

Onlyonecontrolall3loweris e1024/1024=.989/.979/.870; strictsize<entrymeansbothdefaultande1024useidenticalrecursivearithmetic at1024, soitisnotcausalentrybenefit. Identicalwhole-square e1024/default192stillshows1.013/1.003/1.631 all3adverse, andidenticalrecursive e0/default384shows1.011/1.110/1.001 all3adverse: duplicate-pathvariationisrealandlimits thresholdattribution. All24controlstats/threeforkratiosretained;4sub64ringcases,allocandheapNA. Cost/public/finalselected-routeguardremainpending; nopolicyadoption.
