'use strict';
// Task-owned Linux transport/observation only. Numerical code is unchanged in two artifact trees.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process'),os=require('node:os');
const {setTimeout:delay,setImmediate:yieldNow}=require('node:timers/promises');
const check=(v,m)=>{if(!v)throw Error(m)};
const payload=fs.realpathSync(__dirname),output='/home/kokoko/.local/share/krogu-math/perf/runs/539-js-small-aa9-remote-1';
check(process.argv.length===2 && process.platform==='linux' && process.arch==='x64' && process.version==='v24.16.0' && os.hostname()==='claws','Pinned host/runtime/arguments');
check(payload==='/home/kokoko/.local/share/krogu-math/perf/artifacts/539-js-small-aa9-remote-1','Pinned payload root');
check(process.execPath==='/home/kokoko/.local/share/krogu-math/perf/toolchains/node-v24.16.0-linux-x64/bin/node','Owned pinned runtime path');
check(!process.env.NODE_OPTIONS && !process.env.NODE_PATH && process.execArgv.length===0,'No ambient Node flags/preloads');
check(!fs.existsSync(output),'Never overwrite an earlier attempt');fs.mkdirSync(output,{mode:0o700});
const files=new Map(),fds=new Map();let phase={phase:'PREFLIGHT',fork:-1,label:'none'},failure=null,interval=null;
function append(name,value,cap=4*1024*1024){let record=fds.get(name);if(!record){record={fd:fs.openSync(path.join(output,name),'wx',0o600),bytes:0};fds.set(name,record)}const b=Buffer.from(value);check(record.bytes+b.length<=cap,'Output cap:'+name);let off=0;while(off<b.length){const n=fs.writeSync(record.fd,b,off,b.length-off);check(n>0,'Short write');off+=n}record.bytes+=b.length}
function json(name,value,cap){append(name,JSON.stringify(value)+'\n',cap)}
function event(type,extra={}){json('events.jsonl',{wall_utc:new Date().toISOString(),mono_ns:process.hrtime.bigint().toString(),type,...phase,...extra})}
function shaText(text){return crypto.createHash('sha256').update(text).digest('hex')}
async function shaFile(file){const fd=fs.openSync(file,'r'),h=crypto.createHash('sha256'),b=Buffer.allocUnsafe(1024*1024);try{let n,k=0;while((n=fs.readSync(fd,b,0,b.length,null))>0){h.update(b.subarray(0,n));if(++k%8===0)await yieldNow()}return h.digest('hex')}finally{fs.closeSync(fd)}}
function walk(root,prefix=''){return fs.readdirSync(path.join(root,prefix)).sort().flatMap(n=>{const rel=prefix?prefix+'/'+n:n;const s=fs.lstatSync(path.join(root,rel));check(!s.isSymbolicLink(),'Symlink refused');return s.isDirectory()?walk(root,rel):[rel]})}
const sourceSHA='d9b87a77f258deeb173c2aee4b506ef93e9ce6faaf63c32779d755c31e3626ef';
const roots=['baseline','current'].map(label=>path.join(payload,label));const manifestSHAs=['65f31030ec367c26e68cf62dc92a4083888fc6a464cff8ec5df92a82f8f9623a','a0feefcc0c9738beae46b453238b41ba5e8280faa5cc104059ddba055df49e51'];
async function verify(){
 check(await shaFile(process.execPath)===runtimeSHA,'Changed Node executable');
 for(const [i,root] of roots.entries()){
  const text=fs.readFileSync(path.join(root,'manifest.sha256'),'utf8'),rows=text.trimEnd().split('\n').map(l=>l.split('\t'));
  if(manifestSHAs.length===2)check(shaText(text)===manifestSHAs[i],'Changed runtime manifest');
  const names=[];for(const [h,n] of rows){check(/^[a-f0-9]{64}$/.test(h)&&n&&!path.isAbsolute(n)&&n.split('/').every(p=>p&&p!=='.'&&p!=='..'),'Member schema');names.push(n);check(await shaFile(path.join(root,n))===h,'Changed artifact:'+n)}
  check(new Set(names).size===names.length&&JSON.stringify(walk(root))===JSON.stringify([...names,'manifest.sha256'].sort()),'Exact runtime inventory');
 }
 check(await shaFile(path.join(payload,'remote-controller.cjs'))===controllerSHA,'Changed controller');
}
const runtimeSHA=crypto.createHash('sha256').update(fs.readFileSync(process.execPath)).digest('hex');
const controllerSHA=crypto.createHash('sha256').update(fs.readFileSync(path.join(payload,'remote-controller.cjs'))).digest('hex');
const hz=Number(cp.execFileSync('/usr/bin/getconf',['CLK_TCK'],{encoding:'utf8',env:{LANG:'C',TZ:'UTC'},timeout:2000,maxBuffer:1024}).trim());check(Number.isInteger(hz)&&hz>0&&hz<=10000,'CLK_TCK');
const bootID=fs.readFileSync('/proc/sys/kernel/random/boot_id','utf8').trim();check(/^[a-f0-9-]{36}$/.test(bootID),'Boot identity');
function proc(pid){const text=fs.readFileSync('/proc/'+pid+'/stat','utf8');const at=text.lastIndexOf(')');check(at>0,'proc stat boundary');const f=text.slice(at+2).trim().split(/\s+/);check(f.length>=22,'proc stat schema');return{pid:Number(pid),ppid:Number(f[1]),state:f[0],start:f[19],cpu:(BigInt(f[11])+BigInt(f[12])).toString()}}
const own=proc(process.pid),tracked=new Map();let previous=null,sampleID=0,active=null;
function snapshot(){
 const begin=process.hrtime.bigint(),before={...phase};const records=new Map();let unavailable=0;
 for(const pid of fs.readdirSync('/proc').filter(n=>/^[0-9]+$/.test(n))){try{const p=proc(pid);records.set(p.pid,p)}catch(e){if(['ENOENT','ESRCH','EACCES','EPERM'].includes(e.code)){unavailable++;continue}throw e}}
 check(records.get(own.pid)?.start===own.start,'Observer PID/start lost');
 const owned=new Set([own.pid]);for(;;){const size=owned.size;for(const p of records.values())if(p.pid!==own.pid&&owned.has(p.ppid))owned.add(p.pid);if(size===owned.size)break}
 if(active){const childRoot=records.get(active.pid);if(childRoot?.start===active.start){const childOwned=new Set([active.pid]);for(;;){const n=childOwned.size;for(const p of records.values())if(childOwned.has(p.ppid))childOwned.add(p.pid);if(n===childOwned.size)break}for(const id of childOwned)tracked.set(id,records.get(id).start)}}
 const ticks=fs.readFileSync('/proc/stat','utf8').split('\n')[0].trim().split(/\s+/);check(ticks[0]==='cpu'&&ticks.length>=9,'System CPU schema');const system=ticks.slice(1,9).map(BigInt);
 let ext=0n,observedOwned=0n,missing=unavailable,reset=0;const end=process.hrtime.bigint();let fraction=null;
 if(previous){for(const p of records.values()){const old=previous.records.get(p.pid);if(old&&old.start===p.start&&BigInt(p.cpu)>=BigInt(old.cpu)){const d=BigInt(p.cpu)-BigInt(old.cpu);if(owned.has(p.pid))observedOwned+=d;else ext+=d}else{if(old&&old.start===p.start)reset++;if(!owned.has(p.pid))missing++}}for(const p of previous.records.values())if(!records.has(p.pid)&&!previous.owned.has(p.pid))missing++;
  const ds=system.map((v,i)=>v-previous.system[i]);if(ds.every(v=>v>=0n)){const total=ds.reduce((a,b)=>a+b,0n);if(total>0n)fraction=Number(total-ds[3]-ds[4])/Number(total)}
 }
 const intervalNs=previous?end-previous.end:null;
 json('cpu-processes.jsonl',{sample:sampleID,wall_utc:new Date().toISOString(),mono_begin_ns:begin.toString(),mono_end_ns:end.toString(),records:[...records.values()].map(p=>({...p,owned_ancestry:owned.has(p.pid)}))},512*1024*1024);
 const metrics={sample:sampleID++,wall_utc:new Date().toISOString(),mono_begin_ns:begin.toString(),mono_end_ns:end.toString(),interval_start_ns:previous?.end.toString()??null,interval_ns:intervalNs?.toString()??null,phase_before:before,phase_after:{...phase},external_matched_ticks:ext.toString(),owned_matched_ticks:observedOwned.toString(),external_observed_cores:intervalNs?Number(ext)*1e9/hz/Number(intervalNs):null,counter_incomplete_count:missing,counter_reset_count:reset,system_ticks_first8:system.map(String),system_busy_fraction:fraction,loadavg:fs.readFileSync('/proc/loadavg','utf8').trim(),owned_child_resource:null};
 if(active){try{const p=proc(active.pid);if(p.start===active.start){const status=fs.readFileSync('/proc/'+active.pid+'/status','utf8');const value=k=>{const m=status.match(new RegExp('^'+k+':\\s+(\\d+) kB$','m'));return m?Number(m[1])*1024:null};metrics.owned_child_resource={pid:active.pid,start_ticks:active.start,VmRSS_bytes:value('VmRSS'),VmHWM_bytes:value('VmHWM'),scope:'sampled_kernel_process_value_not_completed_peak_or_retained'}}}catch(e){if(!['ENOENT','ESRCH'].includes(e.code))throw e}}
 json('cpu-samples.jsonl',metrics,8*1024*1024);if(previous)check(intervalNs<=5_000_000_000n,'CPU timeline gap above5s');previous={records,owned,system,end};
}
function sameLive(pid,start){try{const p=proc(pid);return p.start===start&&!['Z','X'].includes(p.state)}catch(e){if(['ENOENT','ESRCH'].includes(e.code))return false;throw e}}
async function stopOwned(child){if(child.exitCode===null&&child.signalCode===null&&active?.start===null)child.kill('SIGKILL');const root=active;const ids=[...tracked];if(root&&root.start!==null&&!ids.some(([p])=>p===root.pid))ids.push([root.pid,root.start]);for(const [pid,start]of ids)if(pid!==own.pid&&sameLive(pid,start)){try{process.kill(pid,'SIGKILL')}catch(e){if(e.code!=='ESRCH')throw e}}const until=Date.now()+10000;while(Date.now()<until&&ids.some(([p,s])=>sameLive(p,s))){await delay(25)}check(ids.every(([p,s])=>!sameLive(p,s)),'Owned cleanup survivors')}
async function runChild(fork,index){
 const label=index===0?'baseline':'current',root=roots[index],order=fork===1?'reverse':'forward',log=path.join(output,`fork${fork}-${label}.log`);
 if(failure)throw failure;phase={phase:'CHILD',fork,label};tracked.clear();active=null;
 const argv=['--expose-gc',path.join(root,'node-calibration-host.cjs'),path.join(root,'probe/krogu-math-test.js'),path.join(root,'mocha/node_modules/mocha/index.js'),'JS'];
 fs.writeFileSync(log+'.argv.txt',[process.execPath,...argv].join('\n')+'\n',{flag:'wx',mode:0o600});
 const fd=fs.openSync(log,'wx',0o600);let child=null,closed=false,primary=null,spawnError=null;let done;
 try{
  child=cp.spawn(process.execPath,argv,{cwd:root,env:{LANG:'C',TZ:'UTC',KROGU539_ARGS:`public-small,${order},7,20`},stdio:['ignore',fd,fd]});
  done=new Promise(resolve=>{child.once('error',e=>{spawnError=e});child.once('close',(code,signal)=>{closed=true;resolve({code,signal})})});
  if(Number.isInteger(child.pid)){active={pid:child.pid,start:null};const p=proc(child.pid);active={pid:p.pid,start:p.start};tracked.set(p.pid,p.start);event('CHILD_START',{pid:p.pid,start_ticks:p.start,log:path.basename(log)})}
  const until=Math.min(deadline,Date.now()+600000);let result=null;
  while(!closed&&Date.now()<until){if(failure)throw failure;check(fs.fstatSync(fd).size<=8*1024*1024,'Child output stop threshold');result=await Promise.race([done,delay(100).then(()=>null)])}
  check(closed,'Child deadline');result=await done;if(spawnError)throw spawnError;check(result.code===0&&result.signal===null,'Child failure:'+JSON.stringify(result));if(failure)throw failure;
  fs.fsyncSync(fd);fs.closeSync(fd);files.set(log,true);
  const lines=fs.readFileSync(log,'utf8').split(/\r?\n/),ownLines=lines.filter(l=>l.startsWith('# OWN539 '));check(ownLines.length===1,'Actual Node identity');const identity=ownLines[0];const pid=Number(identity.match(/\bpid=([0-9]+)/)?.[1]),start=Number(identity.match(/\bstart_epoch_ms=([0-9]+)/)?.[1]);check(pid===child.pid&&start>0&&identity.includes('node=v24.16.0 kind=JS'),'Child identity binding');
  check(lines.filter(l=>l.startsWith('TIME539,')).length===196&&lines.filter(l=>l.startsWith('REP539,')).length===28,'Complete raw counts');
  fs.writeFileSync(log+'.exit','0\n',{flag:'wx',mode:0o600});fs.writeFileSync(log+'.binding',`label=${label}\nsource_manifest_sha256=${sourceSHA}\nartifact_manifest_sha256=${manifestSHAs[index]}\nruntime_id=Kotlin2.4.21/Node24.16.0/Linux-x64/claws\npid=${pid}\nstart_epoch_ms=${start}\nlog_sha256=${await shaFile(log)}\nprofile=public-small,${order},7,20\nidentity=${identity}\n`,{flag:'wx',mode:0o600});event('CHILD_TERMINAL',{pid,start_epoch_ms:start,log:path.basename(log),exit:0});
 }catch(e){primary=e;throw e}finally{
  if(child&&(!closed||primary)){try{await stopOwned(child);if(done)await Promise.race([done,delay(10000).then(()=>{throw Error('Child close fence')})])}catch(e){if(primary)primary.cause??=e;else throw e}}
  if(!files.has(log))try{fs.closeSync(fd)}catch(e){if(primary)primary.cause??=e;else throw e}active=null;phase={phase:'BETWEEN_CHILDREN',fork,label};
 }
}
for(const signal of ['SIGINT','SIGTERM','SIGHUP'])process.on(signal,()=>{failure??=Error('Controller received '+signal);try{event('SIGNAL',{signal})}catch(e){failure.cause??=e}});
let deadline;
(async()=>{
 let primary=null;
 try{
  await verify();
  fs.writeFileSync(path.join(output,'binding-before.txt'),`source_manifest_sha256=${sourceSHA}\nbaseline_manifest=${manifestSHAs[0]}\ncurrent_manifest=${manifestSHAs[1]}\nruntime_id=Kotlin2.4.21/Node24.16.0/Linux-x64/claws\nnode_sha256=${runtimeSHA}\ncontroller_sha256=${controllerSHA}\n`,{flag:'wx',mode:0o600});
  json('host.jsonl',{host:os.hostname(),release:os.release(),arch:process.arch,node:process.version,node_executable:process.execPath,node_sha256:runtimeSHA,driver_pid:own.pid,driver_start_ticks:own.start,boot_id:bootID,CLK_TCK:hz,available_parallelism:os.availableParallelism(),memory_total_bytes:os.totalmem(),memory_free_bytes:os.freemem(),maps:'Generated probe maps omitted; same exact numerical JS; Node flags clean/no enable-source-maps',admission:'No new threshold/admission gate; one fixed remote diagnostic, all load retained',peak_memory:'NA completed peak; /proc sampled VmHWM separately scoped'});
  snapshot();interval=setInterval(()=>{if(failure)return;try{snapshot()}catch(e){failure=e}},1000);
  event('PRE_OBSERVATION_START');const preEnd=Date.now()+15000;while(Date.now()<preEnd){if(failure)throw failure;await delay(Math.min(100,preEnd-Date.now()))}if(failure)throw failure;event('PRE_OBSERVATION_END');
  deadline=Date.now()+30*60*1000;
  for(let fork=0;fork<3;fork++){phase={phase:'PAIR',fork,label:'pair'};event('PAIR_START');for(const index of fork===1?[1,0]:[0,1]){check(Date.now()<deadline,'Campaign deadline');await verify();await runChild(fork,index)}event('PAIR_END')}
  phase={phase:'POSTFLIGHT',fork:-1,label:'none'};await verify();if(failure)throw failure;snapshot();event('OBSERVATION_END');
 }catch(e){primary=e;try{fs.writeFileSync(path.join(output,'FAILED'),String(e.stack||e)+'\n',{flag:'wx',mode:0o600})}catch(w){e.cause??=w}throw e}
 finally{if(interval)clearInterval(interval);let closeFailure=null;for(const v of fds.values()){try{fs.fsyncSync(v.fd);fs.closeSync(v.fd)}catch(e){closeFailure??=e}}if(closeFailure){if(primary)primary.cause??=closeFailure;else throw closeFailure}}
 fs.writeFileSync(path.join(output,'EXECUTED_NOT_YET_GUARD_VALIDATED'),'Six fresh alternating children complete;1176TIME/168REP; no performance verdict. Strict local checker and independent CPU/raw audit pending.\n',{flag:'wx',mode:0o600});
})().catch(e=>{console.error(e.stack||String(e));process.exitCode=3});
