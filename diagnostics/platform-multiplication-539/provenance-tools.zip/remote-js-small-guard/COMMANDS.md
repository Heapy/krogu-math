Future commands only. NONE have been executed. Explicit user authorization must first cover the exact final archive SHA/bytes/file list, private code export to claws, owned pinned Node installation, this single remote full28 diagnostic and result return. The previous export refusal remains in force until that authorization.

Local package location:

    /Users/yoda/dev/pet/krogu-math/.codex-work/539/remote-js-small-guard/539-js-small-aa9-remote-1.tar

After approval only, first create NEW fixed artifact directory (fail if already present), mode700, under /home/kokoko/.local/share/krogu-math/perf/artifacts. Transfer that exact archive to its parent as 539-js-small-aa9-remote-1.tar. Use SSH options -o BatchMode=yes -o ControlMaster=no -o ControlPath=none, alias claws. Check the approved archive SHA and bytes remotely before extraction. Inspect tar -tf against tar-members.txt; no absolute/.. members. The archive is locally generated from this exact allowlist, not supplied by an external party. Extract with tar --no-same-owner --no-same-permissions -xf into the new700 artifact directory. There must be no existing tree to overwrite. The SHA value comes from archive.sha256; do not substitute another payload.

The exact future upload is:

    scp -o BatchMode=yes -o ControlMaster=no -o ControlPath=none .codex-work/539/remote-js-small-guard/539-js-small-aa9-remote-1.tar claws:/home/kokoko/.local/share/krogu-math/perf/artifacts/539-js-small-aa9-remote-1.tar

After verified extraction, run install-node-after-approval.sh from the payload using /bin/sh. This downloads only https://nodejs.org/download/release/v24.16.0/node-v24.16.0-linux-x64.tar.xz (31428548 bytes, SHA d804845d34eddc21dc1092b519d643ef40b1f58ec5dec5c22b1f4bd8fabde6c9). Existing installation paths cause a failure, never overwrite. It uses existing curl, sha256sum and tar; if unavailable, report unsupported and do not install system packages. The official checksum URL is in node-runtime.json. Preserve failed install staging for review.

One execution only:

    env -i LANG=C TZ=UTC /home/kokoko/.local/share/krogu-math/perf/toolchains/node-v24.16.0-linux-x64/bin/node /home/kokoko/.local/share/krogu-math/perf/artifacts/539-js-small-aa9-remote-1/remote-controller.cjs

The output directory must not exist:

    /home/kokoko/.local/share/krogu-math/perf/runs/539-js-small-aa9-remote-1

Preserve all output even on failure. After terminal, create a NEW uncompressed result TAR with /usr/bin/tar -cf from that exact owned directory, write its sha256sum and byte count, and return the TAR plus those two values using SCP. Do not include unrelated perf directories. Do not rerun if a timeout, monitor failure, adverse result or other failure occurs. Local verification of returned TAR SHA, extraction of only allowlisted relative regular files into a NEW local directory and retained raw are required before checker use. The six logs and their argv/binding/exit, binding-before.txt, events.jsonl, cpu-processes.jsonl, cpu-samples.jsonl, host.jsonl and terminal success/FAILED are the result inventory (partial runs may omit later child files).

Run the unchanged strict helper locally (not copied to claws):

    python3 .codex-work/539/check-public-paired-guard.py RETURNED_RUN_DIRECTORY JS d9b87a77f258deeb173c2aee4b506ef93e9ce6faaf63c32779d755c31e3626ef 65f31030ec367c26e68cf62dc92a4083888fc6a464cff8ec5df92a82f8f9623a a0feefcc0c9738beae46b453238b41ba5e8280faa5cc104059ddba055df49e51 NEW_LOCAL_OUTPUT_PREFIX

Pinned helper SHA cbde6eeb0920c65952817ca374d5b2562139daebe249b8c166c13766b20db32d. Independent review additionally recomputes Linux CPU timeline, matched identity/interval/child windows and full artifact/source/Node bindings. No source build or benchmark on claws is authorized by this document itself.
