#!/usr/bin/env kotlinr
// LOCAL ONLY. No network, SSH or benchmark. Run only in an owner-agreed quiet window.
import java.nio.file.Files
import java.nio.file.Path
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

require(args.size == 1) { "Usage: kotlinr package-local.main.kts ABSOLUTE_PREPARATION_DIRECTORY" }
val base = Path.of(args[0]).toRealPath()
val payload = base.resolve("payload").toRealPath()
val ledger = base.resolve("export-files.tsv")
fun hash(p: Path): String {
    val d = MessageDigest.getInstance("SHA-256")
    Files.newInputStream(p).use { input -> val b = ByteArray(1024 * 1024); while (true) { val n=input.read(b); if(n<0)break; d.update(b,0,n) } }
    return d.digest().joinToString("") { "%02x".format(it) }
}
val rows = Files.readAllLines(ledger).map { it.split('\t').also { v -> require(v.size==3) } }
val names = rows.map { it[2] }
require(names.size == names.toSet().size)
for ((sha, bytes, name) in rows) {
    require(sha.matches(Regex("[0-9a-f]{64}")))
    require(name.isNotBlank() && !name.startsWith("/") && name.split('/').all { it.isNotEmpty() && it!="." && it!=".." } && name.none { it=='\n'||it=='\r' })
    val file=payload.resolve(name)
    require(!Files.isSymbolicLink(file) && file.toRealPath().startsWith(payload))
    require(Files.size(file)==bytes.toLong() && hash(file)==sha) { "Payload mismatch: $name" }
}
val actual=Files.walk(payload).use { s -> s.filter { Files.isRegularFile(it) }.map { payload.relativize(it).toString() }.sorted().toList() }
require(actual==names.sorted()) { "Exact inventory mismatch" }
val list=base.resolve("tar-members.txt")
require(Files.readString(list)==names.joinToString("\n",postfix="\n")) { "Archive member list mismatch" }
val archive=base.resolve("539-js-small-aa9-remote-1.tar")
require(!Files.exists(archive)) { "Never overwrite a prepared archive" }
val builder=ProcessBuilder("/usr/bin/tar","-cf",archive.toString(),"-C",payload.toString(),"-T",list.toString()).inheritIO()
builder.environment()["COPYFILE_DISABLE"]="1"
val child=builder.start()
try {
    require(child.waitFor(120,TimeUnit.SECONDS) && child.exitValue()==0) { "Archive failure; preserve partial archive" }
} finally {
    if(child.isAlive) { child.destroyForcibly(); require(child.waitFor(10,TimeUnit.SECONDS)) }
}
Files.writeString(base.resolve("archive.sha256"),hash(archive)+"  "+archive.fileName+"\n",java.nio.file.StandardOpenOption.CREATE_NEW)
Files.writeString(base.resolve("archive.bytes"),Files.size(archive).toString()+"\n",java.nio.file.StandardOpenOption.CREATE_NEW)
println("LOCAL archive prepared. This script did not transfer data or authorize export.")
