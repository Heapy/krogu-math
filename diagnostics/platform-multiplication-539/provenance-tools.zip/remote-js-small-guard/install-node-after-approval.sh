#!/bin/sh
# FUTURE ONLY: explicit user authorization must cover this installation and exact private payload.
set -eu
umask 077
root=/home/kokoko/.local/share/krogu-math/perf/toolchains
mkdir -p "$root"
dest="$root/node-v24.16.0-linux-x64"
test ! -e "$dest"
staging=$(mktemp -d "$root/.node24.16.0-install.XXXXXXXX")
# Preserve failed staging for inspection; never touch other paths.
curl --fail --location --proto '=https' --tlsv1.2 https://nodejs.org/download/release/v24.16.0/node-v24.16.0-linux-x64.tar.xz -o "$staging/node.tar.xz"
printf '%s  %s\n' d804845d34eddc21dc1092b519d643ef40b1f58ec5dec5c22b1f4bd8fabde6c9 "$staging/node.tar.xz" | sha256sum --check --strict
tar -xJf "$staging/node.tar.xz" -C "$staging"
test "$("$staging/node-v24.16.0-linux-x64/bin/node" --version)" = v24.16.0
mv "$staging/node-v24.16.0-linux-x64" "$dest"
sha256sum "$dest/bin/node" > "$root/node-v24.16.0-linux-x64.bin.sha256"
# Delete only the exact owned downloaded file and then empty staging directory.
rm "$staging/node.tar.xz"
rmdir "$staging"
