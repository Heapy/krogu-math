#!/bin/sh
# Reviewable FUTURE COMMANDS. DO NOT EXECUTE before explicit user authorization.
set -eu
archive=.codex-work/539/remote-js-small-guard/539-js-small-aa9-remote-1.tar
# Must match explicit approval, not a newly generated archive.
test "$(stat -f %z "$archive")" = 144430080
printf '%s  %s\n' 6786e343c02848fe6341c87f79f1a3dc9d711aaf5d01c854e29241acb9d77373 "$archive" | shasum -a 256 -c -
scp -o BatchMode=yes -o ControlMaster=no -o ControlPath=none "$archive" claws:/home/kokoko/.local/share/krogu-math/perf/artifacts/539-js-small-aa9-remote-1.tar
ssh -o BatchMode=yes -o ControlMaster=no -o ControlPath=none claws /bin/sh <<'REMOTE'
set -eu
umask 077
base=/home/kokoko/.local/share/krogu-math/perf
archive="$base/artifacts/539-js-small-aa9-remote-1.tar"
dest="$base/artifacts/539-js-small-aa9-remote-1"
test "$(wc -c < "$archive")" = 144430080
printf '%s  %s\n' 6786e343c02848fe6341c87f79f1a3dc9d711aaf5d01c854e29241acb9d77373 "$archive" | sha256sum --check --strict
test ! -e "$dest"
mkdir -m 700 "$dest"
# Exact SHA identifies locally verified 2018 regular members, no links/absolute/parent paths.
tar --no-same-owner --no-same-permissions -xf "$archive" -C "$dest"
/bin/sh "$dest/install-node-after-approval.sh"
# Single invocation; capture failure but still retain and return all partial outputs.
status=0
env -i LANG=C TZ=UTC "$base/toolchains/node-v24.16.0-linux-x64/bin/node" "$dest/remote-controller.cjs" || status=$?
result="$base/runs/539-js-small-aa9-remote-1-results.tar"
test ! -e "$result"
tar -cf "$result" -C "$base/runs/539-js-small-aa9-remote-1" .
sha256sum "$result" > "$result.sha256"
wc -c < "$result" > "$result.bytes"
printf 'Controller terminal status: %s\n' "$status"
# Nonzero controller status is retained in FAILED; never retry here.
REMOTE
# Return only this owned diagnostic output, never arbitrary remote perf files.
# Local destination must be newly created before these three downloads.
localout=.codex-work/539/remote-js-small-guard/returned
test ! -e "$localout"
mkdir -m 700 "$localout"
for suffix in '' .sha256 .bytes; do
 scp -o BatchMode=yes -o ControlMaster=no -o ControlPath=none "claws:/home/kokoko/.local/share/krogu-math/perf/runs/539-js-small-aa9-remote-1-results.tar$suffix" "$localout/"
done
# Verify returned bytes/SHA before safe regular-only extraction and the exact local strict-check command in COMMANDS.md.
