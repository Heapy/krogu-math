# Current JVM75 lifetime decision support — conditional, not adoption

Only fresh92699:75 same-fork routes/1575 PAR,90 full-cold SETUP,45 payload rows. Historical60-case campaign is not read or mixed. Uses the same existing decision-table method; actual public `multiply` is now in the faster matched serial comparator set alongside kernel/frame. Across45 operand/fork comparisons the fastest route is public16, frame19, kernel10; use the fastest actual route per fork rather than pooled route selection.

The unchanged PARALLEL rule is median ratio≤0.80 and every fork≤0.90, with two adjacent measured sizes for a candidate lifetime/shape/worker count. It is never a scalar-policy gate. These are latency eligibility observations, not adoption.

| Shape / workers | Reused pool qualifying sizes | Fresh pool qualifying sizes |
|---|---|---|
|distinct /worker1|256,1024,8192,16384|4096,8192,16384|
|distinct /worker2|1024,4096,8192,16384|4096,8192,16384|
|square /worker1|1024,4096,16384|8192,16384|
|square /worker2|1024,4096,8192,16384|4096,8192,16384|
|ratio2 /worker1|1024,4096,8192,16384|4096,8192,16384|
|ratio2 /worker2|1024,4096,8192,16384|4096,8192,16384|

Distinct/worker1 has two separated reused qualifying pairs256→1024 and8192→16384, with4096 failing the margin; square/worker1 has1024→4096 plus isolated16384, not an all-larger guarantee. Fresh results have one observation per case per process, versus seven steady samples. Full-cold includes actual constructor→firstproduct→shutdown→await; it is not cold whole-JVM. No subtraction, lifetime break-even or hypothetical amortization is inferred.

| Example | Steady ratios / fastest serial route | Resource interpretation |
|---|---|---|
|256/distinct/worker1|0.715/0.854/0.783; comparator frame,public,public|CPU 1.144/1.330/1.267; allocation ΔB 242.281/5643.953/5639.953; fresh wall 132.996/7.126/120.893|
|256/distinct/worker2|1.249/1.086/1.567; comparator frame,public,public|CPU 2.084/1.808/2.318; allocation ΔB 506.531/5887.750/5877.969; fresh wall 10.474/10.778/17.232|
|1024/distinct/worker2|0.585/0.476/0.467; comparator public,frame,kernel|CPU 1.467/1.168/1.161; allocation ΔB 24453.125/517.375/24501.750; fresh wall 1.474/2.572/1.307|
|4096/distinct/worker2|0.349/0.362/0.454; comparator public,public,public|CPU 1.000/1.036/1.304; allocation ΔB 98270.000/98265.000/98266.000; fresh wall 0.414/0.495/0.565|
|16384/ratio2/worker2|0.513/0.492/0.673; comparator public,kernel,kernel|CPU 1.021/0.983/1.417; allocation ΔB 459136.000/459200.000/459200.000; fresh wall 0.510/0.773/0.605|

Both256/distinct/worker2 and256/square/worker2 are slower in every paired fork;27/30 worker cases are faster in all3, with remaining mixed/adverse preserved in JSON. A latency win still carries resource cost:4096 distinct/worker2 adds about98.3kB/op versus the actual public comparator in all forks;16384 ratio2/worker2 adds about459kB/op and its third CPU ratio is1.417. Approximate all-thread allocation includes background/runtime costs. Caller-only allocation is not substituted. Pool-peak sums and whole-process RSS include pre-existing heap/runtime/reference preparation, not an exact per-operation retained graph.

## Existing conditions still needed before adoption

1. Select/review actual public parallel frontend and bounded lifetime. These rows are private word-array candidates versus public serial; their advantage does not include any not-yet-written public parallel materialization/dispatch/publication cost. Charge actual first-call/startup or per-call lifetime, and preserve scalar/compact paths.
2. Make explicit bounded CPU/allocation/peak/startup tradeoff judgment; latency margin alone is not approval. Preserve all failed/mixed points and resource ranges.
3. Complete other target candidate evidence and final per-platform policy decision; no JVM threshold is silently transferred.
4. Perform the already-required selected route/branch/alias/sign/zero/compact/subtype/result-identity/failure-interrupt-resource checks around actual boundaries, final both-API matched public-small guard (>15% AND >5ns investigation trigger), focused/full composed correctness and independent acceptance.

No new universal gate or numerical run was added. Full latest-result/input checks occur outside counters; latest actual BI escapes without timed conversion. Public hash and IntArray content hashes are different schemes and are not asserted equal.
