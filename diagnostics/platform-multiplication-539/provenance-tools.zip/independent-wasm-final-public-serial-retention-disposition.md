# Wasm final public serial retention — actual19329

Source aa9ca6b9. Independent actual raw PASS14d79b54. Both APIs invoke the current K64/16/384 serial arithmetic. Each latency/CPU cell is the median of the three process medians; paired F/R/F directions remain visible. Ratios are parallelMultiply/multiply, not backend speedups.

| Words / shape | multiply wall ms | parallelMultiply wall ms | Wall ratios F/R/F | multiply CPU ms | parallelMultiply CPU ms | CPU ratios F/R/F | FIRST ms F/R/F |
|---|---:|---:|---|---:|---:|---|---|
| 256/distinct | 0.045 | 0.047 | 0.999/1.054/1.060 | 0.045 | 0.047 | 0.999/1.055/1.058 | 0.358/0.391/0.380 |
| 256/square | 0.037 | 0.035 | 1.025/0.994/0.910 | 0.037 | 0.035 | 1.023/0.997/0.901 | 0.651/0.709/0.738 |
| 256/ratio2 | 0.102 | 0.094 | 0.996/0.908/0.952 | 0.102 | 0.094 | 0.996/0.904/0.947 | 0.464/0.482/0.505 |
| 1024/distinct | 0.453 | 0.420 | 0.999/0.926/0.953 | 0.453 | 0.423 | 0.999/0.932/0.946 | 1.363/1.486/1.489 |
| 1024/square | 0.416 | 0.403 | 1.000/0.970/0.960 | 0.416 | 0.406 | 1.002/0.976/0.959 | 1.555/1.881/1.728 |
| 1024/ratio2 | 0.870 | 0.862 | 1.019/1.041/0.991 | 0.872 | 0.863 | 1.019/1.042/0.989 | 2.268/2.480/2.517 |
| 4096/distinct | 4.894 | 4.909 | 0.867/1.032/1.048 | 4.899 | 4.910 | 0.872/1.028/1.048 | 6.011/6.725/6.775 |
| 4096/square | 4.793 | 4.587 | 0.977/0.930/0.968 | 4.794 | 4.588 | 0.986/0.926/0.977 | 6.532/7.424/6.938 |
| 4096/ratio2 | 9.275 | 9.473 | 1.021/1.080/1.007 | 9.274 | 9.475 | 1.022/1.079/1.006 | 9.235/14.183/10.095 |
| 8192/distinct | 17.232 | 18.637 | 0.806/1.082/0.995 | 17.198 | 18.764 | 0.805/1.091/0.994 | 18.954/26.179/16.056 |
| 8192/square | 18.426 | 18.580 | 1.008/1.008/1.006 | 18.436 | 18.586 | 1.007/1.008/1.006 | 23.629/22.158/17.441 |
| 8192/ratio2 | 34.647 | 29.839 | 0.861/1.011/1.009 | 34.864 | 29.844 | 0.856/1.015/1.005 | 34.707/42.212/29.851 |
| 16384/distinct | 63.369 | 59.754 | 0.943/0.891/0.873 | 63.368 | 59.762 | 0.943/1.058/0.873 | 48.931/62.462/50.389 |
| 16384/square | 53.788 | 55.852 | 1.038/0.901/0.999 | 53.791 | 55.857 | 1.038/0.901/0.987 | 60.947/83.345/53.755 |
| 16384/ratio2 | 109.099 | 119.744 | 1.098/0.999/1.100 | 82.665 | 119.691 | 1.448/0.983/1.099 | 111.434/172.604/80.279 |

All45 children have exact15points/threefreshF/R/F,45 FIRST/1260warm, declared both operand lengths/alias, full-result/native-representation checks and bound origins/runtime/source. Each has eight outside-counter registry-absence/empty-private-namespace observations and terminal parent namespace inspection. Together with bound compiled direct virtual fallback, this is actual serial-decline evidence; no worker activation, startup or historical cleanup proof is claimed. Ratio2 right operand is twice the listed words.

FIRST0.358–172.604ms measures the first public call after prepared inputs, not pristine VM, backend activation or matched first-call speedup. After-run process maxRSS207,814,656–398,475,264bytes includes all routes/fixture/initialization through that snapshot; not a completed-lifetime or per-route/owned memory price. Allocation and Wasm heap remain NA. Process CPU may include runtime work; no cause is assigned to wall/CPU divergence or all3 adverse observations.

Disposition: accept actual arithmetic/contract/absence evidence and retain intentional Wasm serial fallback. No parallel candidate adoption or controlled speed recovery is inferred from these same-process comparisons. Current smallguard25695 qualified PASS with zero flags remains separate: ordinary511distinct still all3slower1.112/1.128/1.042, parallel511distinct1.098/1.131/1.061, below the literal flag threshold. Earlier stable material511flags remain published, not relabelled noise/repaired. No additional Wasm rerun or microfix is supported by the current evidence.

Historical worker105 and resource/lifetime comparisons remain source-labelled with refusal rationale. Final publicationconsumer/targetcontracts/fullcorrectness and JS unresolved smallguard are separate obligations.
