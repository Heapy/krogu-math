# Native bounded K16 neighbor decision support

K32 is the defensible conservative candidate for physically distinct, equal-length operands. The measured K16 neighbor does not support lowering further. This is scalar calibration evidence, not parallel adoption.

| words | K16/K32 fork ratios | K32/K64 fork ratios |
|---:|---|---|
| 16 | 1.283 / 1.304 / 1.280 | 1.022 / 0.981 / 1.008 |
| 31 | 1.093 / 1.082 / 1.135 | 1.045 / 1.015 / 1.001 |
| 32 | 1.162 / 1.146 / 1.141 | 0.946 / 1.007 / 0.959 |
| 63 | 1.154 / 1.128 / 1.127 | 0.775 / 0.780 / 0.787 |
| 64 | 1.141 / 1.162 / 1.130 | 0.924 / 0.935 / 0.936 |
| 128 | 1.157 / 1.148 / 1.150 | 0.917 / 0.907 / 0.938 |
| 256 | 1.004 / 1.044 / 1.116 | 0.848 / 0.888 / 0.963 |
| 512 | 0.644 / 1.133 / 1.143 | 1.075 / 0.948 / 0.934 |
| 1024 | 1.239 / 0.949 / 1.152 | 0.957 / 1.038 / 0.951 |
| 4096 | 1.280 / 1.409 / 1.163 | 1.032 / 0.953 / 0.952 |
| 8192 | 1.211 / 1.173 / 1.143 | 0.966 / 0.970 / 1.001 |

At16/31 K32 and K64 select the same school path. Active K32 wins all three pairs at63/64/128/256; larger results are mixed and remain disclosed. Prior417 Native active-family evidence supports this scoped choice, without treating cross-campaign ratios as causal stage speedups.

Retain K64 for physical aliases/unbalanced operands. Square-entry128 is a separate candidate supported by accepted Native square controls (192/256 lower,128 mixed), requiring actual selected-route controls and fixture rebind.

One bounded neighbor extension is complete. No automatic K8, global optimum claim or scalar20/10 gate. Allocation remainsNA; lastGC is coarse historical global state, whole-child RSS is not per-operation retention. Final policy/source tests, actual public route data, paired small guard and full correctness remain pending.
