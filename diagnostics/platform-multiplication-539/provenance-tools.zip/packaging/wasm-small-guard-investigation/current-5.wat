 (func $io.heapy.krogu.math.BigInteger.multiplyPowerOfTwo (param $<this> (ref null $io.heapy.krogu.math.BigInteger)) (param $value (ref null $io.heapy.krogu.math.BigInteger)) (param $bits i32) (result (ref null $io.heapy.krogu.math.BigInteger))
  (local $words (ref null $kotlin.IntArray))
  (local $~tmp0 i64)
  (local $~tmp2 i32)
  (local $~this i64)
  (local $~other i32)
  (local $modulus (ref null $io.heapy.krogu.math.BigInteger))
  (local $a (ref null $io.heapy.krogu.math.BigInteger))
  (local $~tmp (ref null $io.heapy.krogu.math.BigInteger))
  (local $b (ref null $io.heapy.krogu.math.BigInteger))
  (local $~tmp_12 (ref null $io.heapy.krogu.math.BigInteger))
  (local.set $words
   (call $io.heapy.krogu.math.BigInteger.materializeMagnitude
    (local.get $<this>)
   )
  )
  (local.set $~tmp0
   (call $kotlin.Int__toLong-impl
    (call $io.heapy.krogu.math.BigInteger.magnitudeBits
     (local.get $<this>)
    )
   )
  )
  (local.set $~tmp2
   (call $io.heapy.krogu.math.BigInteger.magnitudeBits
    (local.get $value)
   )
  )
  (if
   (i64.le_s
    (block $block (result i64)
     (nop)
     (local.set $~this
      (local.get $~tmp0)
     )
     (local.set $~other
      (local.get $~tmp2)
     )
     (br $block
      (i64.add
       (local.get $~this)
       (call $kotlin.Int__toLong-impl
        (local.get $~other)
       )
      )
     )
    )
    (i64.const 2147483647)
   )
   (then
    (return
     (call $io.heapy.krogu.math.BigInteger.moduloPowerOfTwo
      (call_ref $_1060
       (local.get $<this>)
       (local.get $value)
       (struct.get $<classVTable>_1066 $multiply
        (struct.get $io.heapy.krogu.math.BigInteger $vtable
         (local.get $<this>)
        )
       )
      )
      (local.get $bits)
     )
    )
   )
  )
  (local.set $modulus
   (call $io.heapy.krogu.math.BigInteger.shiftLeftValue
    (struct.get $io.heapy.krogu.math.Companion_1113 $ONE
     (call $io.heapy.krogu.math.Companion_getInstance_2655)
    )
    (local.get $bits)
   )
  )
  (local.set $a
   (call_ref $_1060
    (local.tee $~tmp
     (call $io.heapy.krogu.math.BigInteger.<init>_2661
      (ref.null none)
      (i32.const 1)
      (local.get $words)
     )
    )
    (local.get $modulus)
    (struct.get $<classVTable>_1066 $mod
     (struct.get $io.heapy.krogu.math.BigInteger $vtable
      (local.get $~tmp)
     )
    )
   )
  )
  (local.set $b
   (call_ref $_1060
    (local.tee $~tmp_12
     (call $io.heapy.krogu.math.BigInteger.<init>_2661
      (ref.null none)
      (i32.const 1)
      (call $io.heapy.krogu.math.BigInteger.materializeMagnitude
       (local.get $value)
      )
     )
    )
    (local.get $modulus)
    (struct.get $<classVTable>_1066 $mod
     (struct.get $io.heapy.krogu.math.BigInteger $vtable
      (local.get $~tmp_12)
     )
    )
   )
  )
  (return
   (call $io.heapy.krogu.math.BigInteger.multiplyModuloBounded
    (local.get $a)
    (local.get $b)
    (local.get $modulus)
   )
  )
 )
