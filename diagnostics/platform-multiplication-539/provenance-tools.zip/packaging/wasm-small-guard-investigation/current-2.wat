 (func $io.heapy.krogu.math.BigInteger.parallelMagnitudeSize539 (param $<this> (ref null $io.heapy.krogu.math.BigInteger)) (result i32)
  (local $~tmp1_elvis_lhs (ref null $kotlin.Int))
  (local $~tmp0_safe_receiver (ref null $kotlin.IntArray))
  (return
   (if (result i32)
    (ref.is_null
     (local.tee $~tmp1_elvis_lhs
      (if (result (ref null $kotlin.Int))
       (ref.is_null
        (local.tee $~tmp0_safe_receiver
         (struct.get $io.heapy.krogu.math.BigInteger $wideWords
          (local.get $<this>)
         )
        )
       )
       (then
        (ref.null none)
       )
       (else
        (struct.new $kotlin.Int
         (global.get $<classVTable>_1807)
         (global.get $<classITable>_2425)
         (global.get $kotlin.Int_rtti)
         (i32.const 0)
         (call $kotlin.IntArray.<get-size>
          (local.get $~tmp0_safe_receiver)
         )
        )
       )
      )
     )
    )
    (then
     (i32.const 0)
    )
    (else
     (struct.get $kotlin.Int $value
      (local.get $~tmp1_elvis_lhs)
     )
    )
   )
  )
 )
