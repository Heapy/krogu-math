 (func $io.heapy.krogu.math.BigInteger.multiply (type $_1060) (param $<this> (ref null $kotlin.Any)) (param $value (ref null $io.heapy.krogu.math.BigInteger)) (result (ref null $io.heapy.krogu.math.BigInteger))
  (local $~tmp0_<this> (ref null $io.heapy.krogu.math.BigInteger))
  (local $a i64)
  (local $b i64)
  (local $result i64)
  (local $scalar i64)
  (local $word i32)
  (local $~tmp0 i64)
  (local $~this i64)
  (local $~tmp1 (ref null $kotlin.IntArray))
  (local $scalar_11 i64)
  (local $word_12 i32)
  (local $~tmp0_13 i64)
  (local $~this_14 i64)
  (local $~tmp2 (ref null $kotlin.IntArray))
  (local $words (ref null $kotlin.IntArray))
  (local $valueWords (ref null $kotlin.IntArray))
  (if
   (if (result i32)
    (i32.eq
     (struct.get $io.heapy.krogu.math.BigInteger $sign
      (local.tee $~tmp0_<this>
       (ref.cast (ref null $io.heapy.krogu.math.BigInteger)
        (local.get $<this>)
       )
      )
     )
     (i32.const 0)
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.eq
      (struct.get $io.heapy.krogu.math.BigInteger $sign
       (local.get $value)
      )
      (i32.const 0)
     )
    )
   )
   (then
    (return
     (struct.get $io.heapy.krogu.math.Companion_1113 $ZERO
      (call $io.heapy.krogu.math.Companion_getInstance_2655)
     )
    )
   )
  )
  (if
   (if (result i32)
    (i32.eq
     (struct.get $io.heapy.krogu.math.BigInteger $representation
      (local.get $~tmp0_<this>)
     )
     (i32.const 1)
    )
    (then
     (i32.eq
      (struct.get $io.heapy.krogu.math.BigInteger $representation
       (local.get $value)
      )
      (i32.const 1)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (local.set $a
     (call $io.heapy.krogu.math.BigInteger.compactStoredValue529
      (local.get $~tmp0_<this>)
     )
    )
    (local.set $b
     (call $io.heapy.krogu.math.BigInteger.compactStoredValue529
      (local.get $value)
     )
    )
    (local.set $result
     (i64.mul
      (local.get $a)
      (local.get $b)
     )
    )
    (if
     (call $io.heapy.krogu.math.CompactInteger529.multiplyFits
      (call $io.heapy.krogu.math.CompactInteger529_getInstance)
      (local.get $a)
      (local.get $b)
      (local.get $result)
     )
     (then
      (return
       (call $io.heapy.krogu.math.Companion.compactResult529
        (call $io.heapy.krogu.math.Companion_getInstance_2655)
        (local.get $result)
       )
      )
     )
    )
   )
  )
  (if
   (if (result i32)
    (if (result i32)
     (i32.eq
      (struct.get $io.heapy.krogu.math.BigInteger $representation
       (local.get $~tmp0_<this>)
      )
      (i32.const 1)
     )
     (then
      (i32.eq
       (struct.get $io.heapy.krogu.math.BigInteger $representation
        (local.get $value)
       )
       (i32.const 2)
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (i32.le_s
      (call $io.heapy.krogu.math.BigInteger.magnitudeBits
       (local.get $~tmp0_<this>)
      )
      (i32.const 30)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (call $io.heapy.krogu.math.MagnitudeMultiplication.checkBitLengths
     (global.get $io.heapy.krogu.math.MagnitudeMultiplication_instance)
     (call $io.heapy.krogu.math.BigInteger.magnitudeBits
      (local.get $~tmp0_<this>)
     )
     (call $io.heapy.krogu.math.BigInteger.magnitudeBits
      (local.get $value)
     )
    )
    (local.set $word
     (call $kotlin.Long__toInt-impl
      (if (result i64)
       (i64.lt_s
        (local.tee $scalar
         (call $io.heapy.krogu.math.BigInteger.compactStoredValue529
          (local.get $~tmp0_<this>)
         )
        )
        (i64.const 0)
       )
       (then
        (local.set $~tmp0
         (local.get $scalar)
        )
        (block $block (result i64)
         (nop)
         (local.set $~this
          (local.get $~tmp0)
         )
         (br $block
          (i64.sub
           (i64.const 0)
           (local.get $~this)
          )
         )
        )
       )
       (else
        (local.get $scalar)
       )
      )
     )
    )
    (return
     (call $io.heapy.krogu.math.Companion.normalized
      (call $io.heapy.krogu.math.Companion_getInstance_2655)
      (i32.mul
       (struct.get $io.heapy.krogu.math.BigInteger $sign
        (local.get $~tmp0_<this>)
       )
       (struct.get $io.heapy.krogu.math.BigInteger $sign
        (local.get $value)
       )
      )
      (call $io.heapy.krogu.math.MagnitudeMultiplication.multiplyWord529
       (global.get $io.heapy.krogu.math.MagnitudeMultiplication_instance)
       (local.get $word)
       (if (result (ref null $kotlin.IntArray))
        (ref.is_null
         (local.tee $~tmp1
          (struct.get $io.heapy.krogu.math.BigInteger $wideWords
           (local.get $value)
          )
         )
        )
        (then
         (call $kotlin.wasm.internal.THROW_NPE)
         (unreachable)
        )
        (else
         (local.get $~tmp1)
        )
       )
      )
     )
    )
   )
  )
  (if
   (if (result i32)
    (if (result i32)
     (i32.eq
      (struct.get $io.heapy.krogu.math.BigInteger $representation
       (local.get $~tmp0_<this>)
      )
      (i32.const 2)
     )
     (then
      (i32.eq
       (struct.get $io.heapy.krogu.math.BigInteger $representation
        (local.get $value)
       )
       (i32.const 1)
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (i32.le_s
      (call $io.heapy.krogu.math.BigInteger.magnitudeBits
       (local.get $value)
      )
      (i32.const 30)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (call $io.heapy.krogu.math.MagnitudeMultiplication.checkBitLengths
     (global.get $io.heapy.krogu.math.MagnitudeMultiplication_instance)
     (call $io.heapy.krogu.math.BigInteger.magnitudeBits
      (local.get $~tmp0_<this>)
     )
     (call $io.heapy.krogu.math.BigInteger.magnitudeBits
      (local.get $value)
     )
    )
    (local.set $word_12
     (call $kotlin.Long__toInt-impl
      (if (result i64)
       (i64.lt_s
        (local.tee $scalar_11
         (call $io.heapy.krogu.math.BigInteger.compactStoredValue529
          (local.get $value)
         )
        )
        (i64.const 0)
       )
       (then
        (local.set $~tmp0_13
         (local.get $scalar_11)
        )
        (block $block1 (result i64)
         (nop)
         (local.set $~this_14
          (local.get $~tmp0_13)
         )
         (br $block1
          (i64.sub
           (i64.const 0)
           (local.get $~this_14)
          )
         )
        )
       )
       (else
        (local.get $scalar_11)
       )
      )
     )
    )
    (return
     (call $io.heapy.krogu.math.Companion.normalized
      (call $io.heapy.krogu.math.Companion_getInstance_2655)
      (i32.mul
       (struct.get $io.heapy.krogu.math.BigInteger $sign
        (local.get $~tmp0_<this>)
       )
       (struct.get $io.heapy.krogu.math.BigInteger $sign
        (local.get $value)
       )
      )
      (call $io.heapy.krogu.math.MagnitudeMultiplication.multiplyWord529
       (global.get $io.heapy.krogu.math.MagnitudeMultiplication_instance)
       (local.get $word_12)
       (if (result (ref null $kotlin.IntArray))
        (ref.is_null
         (local.tee $~tmp2
          (struct.get $io.heapy.krogu.math.BigInteger $wideWords
           (local.get $~tmp0_<this>)
          )
         )
        )
        (then
         (call $kotlin.wasm.internal.THROW_NPE)
         (unreachable)
        )
        (else
         (local.get $~tmp2)
        )
       )
      )
     )
    )
   )
  )
  (local.set $words
   (call $io.heapy.krogu.math.BigInteger.materializeMagnitude
    (local.get $~tmp0_<this>)
   )
  )
  (local.set $valueWords
   (if (result (ref null $kotlin.IntArray))
    (ref.eq
     (local.get $value)
     (local.get $~tmp0_<this>)
    )
    (then
     (local.get $words)
    )
    (else
     (call $io.heapy.krogu.math.BigInteger.materializeMagnitude
      (local.get $value)
     )
    )
   )
  )
  (call $io.heapy.krogu.math.MagnitudeMultiplication.checkBitLengths
   (global.get $io.heapy.krogu.math.MagnitudeMultiplication_instance)
   (call $io.heapy.krogu.math.BigInteger.magnitudeBits
    (local.get $~tmp0_<this>)
   )
   (call $io.heapy.krogu.math.BigInteger.magnitudeBits
    (local.get $value)
   )
  )
  (return
   (call $io.heapy.krogu.math.Companion.normalized
    (call $io.heapy.krogu.math.Companion_getInstance_2655)
    (i32.mul
     (struct.get $io.heapy.krogu.math.BigInteger $sign
      (local.get $~tmp0_<this>)
     )
     (struct.get $io.heapy.krogu.math.BigInteger $sign
      (local.get $value)
     )
    )
    (call $io.heapy.krogu.math.MagnitudeMultiplication.multiplyAdaptive
     (global.get $io.heapy.krogu.math.MagnitudeMultiplication_instance)
     (local.get $words)
     (local.get $valueWords)
    )
   )
  )
 )
