  protoOf(MagnitudeMultiplication).ut = function (a, b) {
    return multiplyAdaptiveJs539(this, a, b);
  };
