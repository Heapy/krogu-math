 (func $2162 (type $970) (param $0 i32) (result i64)
  (call $3437
   (local.get $0)
   (i32.const 6)
  )
 )
