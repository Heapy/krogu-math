 (func $io.heapy.krogu.math.BigInteger.multiplyMod (param $<this> (ref null $io.heapy.krogu.math.BigInteger)) (param $value (ref null $io.heapy.krogu.math.BigInteger)) (param $m (ref null $io.heapy.krogu.math.BigInteger)) (result (ref null $io.heapy.krogu.math.BigInteger))
  (local $~tmp0 i64)
  (local $~tmp2 i32)
  (local $~this i64)
  (local $~other i32)
  (local $~tmp (ref null $io.heapy.krogu.math.BigInteger))
  (local.set $~tmp0
   (call $kotlin.Int__toLong-impl
    (call $io.heapy.krogu.math.BigInteger.magnitudeBits
     (local.get $<this>)
    )
   )
  )
  (local.set $~tmp2
   (call $io.heapy.krogu.math.BigInteger.magnitudeBits
    (local.get $value)
   )
  )
  (return
   (if (result (ref null $io.heapy.krogu.math.BigInteger))
    (i64.le_s
     (block $block (result i64)
      (nop)
      (local.set $~this
       (local.get $~tmp0)
      )
      (local.set $~other
       (local.get $~tmp2)
      )
      (br $block
       (i64.add
        (local.get $~this)
        (call $kotlin.Int__toLong-impl
         (local.get $~other)
        )
       )
      )
     )
     (i64.const 2147483647)
    )
    (then
     (call_ref $_1060
      (local.tee $~tmp
       (call_ref $_1060
        (local.get $<this>)
        (local.get $value)
        (struct.get $<classVTable>_1066 $multiply
         (struct.get $io.heapy.krogu.math.BigInteger $vtable
          (local.get $<this>)
         )
        )
       )
      )
      (local.get $m)
      (struct.get $<classVTable>_1066 $mod
       (struct.get $io.heapy.krogu.math.BigInteger $vtable
        (local.get $~tmp)
       )
      )
     )
    )
    (else
     (call $io.heapy.krogu.math.BigInteger.multiplyModuloBounded
      (local.get $<this>)
      (local.get $value)
      (local.get $m)
     )
    )
   )
  )
 )
