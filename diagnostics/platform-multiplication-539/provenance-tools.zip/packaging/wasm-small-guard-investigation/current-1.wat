 (func $io.heapy.krogu.math.BigInteger.parallelMultiply (type $_1060) (param $<this> (ref null $kotlin.Any)) (param $value (ref null $io.heapy.krogu.math.BigInteger)) (result (ref null $io.heapy.krogu.math.BigInteger))
  (local $~tmp0_<this> (ref null $io.heapy.krogu.math.BigInteger))
  (if
   (i32.eqz
    (call $io.heapy.krogu.math.BigInteger.hasParallelMagnitude539
     (local.tee $~tmp0_<this>
      (ref.cast (ref null $io.heapy.krogu.math.BigInteger)
       (local.get $<this>)
      )
     )
     (local.get $value)
    )
   )
   (then
    (return
     (call_ref $_1060
      (local.get $~tmp0_<this>)
      (local.get $value)
      (struct.get $<classVTable>_1066 $multiply
       (struct.get $io.heapy.krogu.math.BigInteger $vtable
        (local.get $~tmp0_<this>)
       )
      )
     )
    )
   )
  )
  (return
   (call $io.heapy.krogu.math.BigInteger.parallelMultiplyLarge539
    (local.get $~tmp0_<this>)
    (local.get $value)
   )
  )
 )
