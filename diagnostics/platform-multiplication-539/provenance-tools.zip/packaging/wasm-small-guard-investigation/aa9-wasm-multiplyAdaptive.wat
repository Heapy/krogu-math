 (func $io.heapy.krogu.math.MagnitudeMultiplication.multiplyAdaptive (param $<this> (ref null $io.heapy.krogu.math.MagnitudeMultiplication)) (param $a (ref null $kotlin.IntArray)) (param $b (ref null $kotlin.IntArray)) (result (ref null $kotlin.IntArray))
  (local $out (ref null $kotlin.IntArray))
  (if
   (i32.const 1)
   (then
    (return
     (call $io.heapy.krogu.math.MagnitudeMultiplication.multiplyWithSquareEntry
      (local.get $<this>)
      (local.get $a)
      (local.get $b)
      (i32.const 384)
     )
    )
   )
  )
  (if
   (if (result i32)
    (if (result i32)
     (ref.eq
      (local.get $a)
      (local.get $b)
     )
     (then
      (i32.ge_s
       (call $kotlin.IntArray.<get-size>
        (local.get $a)
       )
       (i32.const 16)
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (i32.lt_s
      (call $kotlin.IntArray.<get-size>
       (local.get $a)
      )
      (call $io.heapy.krogu.math.MagnitudeMultiplication.selectedSquareEntry539
       (local.get $<this>)
      )
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (local.set $out
     (call $kotlin.IntArray.<init>
      (ref.null none)
      (i32.add
       (call $kotlin.IntArray.<get-size>
        (local.get $a)
       )
       (call $kotlin.IntArray.<get-size>
        (local.get $b)
       )
      )
     )
    )
    (call $io.heapy.krogu.math.MagnitudeMultiplication.square
     (local.get $<this>)
     (local.get $a)
     (i32.const 0)
     (call $kotlin.IntArray.<get-size>
      (local.get $a)
     )
     (local.get $out)
     (i32.const 0)
    )
    (return
     (local.get $out)
    )
   )
  )
  (return
   (call $io.heapy.krogu.math.MagnitudeMultiplication.multiply
    (local.get $<this>)
    (local.get $a)
    (local.get $b)
    (call $io.heapy.krogu.math.MagnitudeMultiplication.selectedKaratsuba539
     (local.get $<this>)
     (local.get $a)
     (local.get $b)
    )
    (i32.const 16)
   )
  )
 )
