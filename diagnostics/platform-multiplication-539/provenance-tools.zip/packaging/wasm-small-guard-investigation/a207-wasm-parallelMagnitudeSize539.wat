 (func $io.heapy.krogu.math.BigInteger.parallelMagnitudeSize539 (param $<this> (ref null $io.heapy.krogu.math.BigInteger)) (result i32)
  (local $words (ref null $kotlin.IntArray))
  (if
   (ref.is_null
    (local.tee $words
     (struct.get $io.heapy.krogu.math.BigInteger $wideWords
      (local.get $<this>)
     )
    )
   )
   (then
    (return
     (i32.const 0)
    )
   )
  )
  (return
   (call $kotlin.IntArray.<get-size>
    (local.get $words)
   )
  )
 )
