 (func $2181 (type $913) (result (ref null $2))
  (local $0 (ref null $2))
  (local $1 (ref null $2))
  (local $2 (ref null $2))
  (local $3 (ref null $2))
  (local $4 (ref $1348))
  (local $5 (ref null $1451))
  (local $6 (ref null $1367))
  (local $7 (ref null $1367))
  (local $8 (ref null $18))
  (local $9 (ref null $1009))
  (local $10 (ref $1367))
  (local $11 i32)
  (local $12 i32)
  (local.set $2
   (call_ref $1328
    (local.tee $0
     (if (result (ref null $2))
      (i32.gt_s
       (array.len
        (struct.get $1348 4
         (local.tee $4
          (struct.new $1348
           (global.get $global$0)
           (ref.null none)
           (global.get $global$22)
           (i32.const 0)
           (array.new_fixed $1340 6
            (struct.new $1009
             (global.get $global$19)
             (global.get $global$20)
             (global.get $global$28)
             (i32.const 0)
             (call $3430
              (i32.const 1406)
              (global.get $gimport$5)
             )
             (call $3430
              (i32.const 1664)
              (global.get $gimport$2008)
             )
             (call $3430
              (i32.const 4155)
              (global.get $gimport$6949)
             )
            )
            (struct.new $1009
             (global.get $global$19)
             (global.get $global$20)
             (global.get $global$28)
             (i32.const 0)
             (call $3430
              (i32.const 1664)
              (global.get $gimport$2008)
             )
             (call $3430
              (i32.const 1406)
              (global.get $gimport$5)
             )
             (call $3430
              (i32.const 1664)
              (global.get $gimport$2008)
             )
            )
            (struct.new $1009
             (global.get $global$19)
             (global.get $global$20)
             (global.get $global$28)
             (i32.const 0)
             (call $3430
              (i32.const 4027)
              (global.get $gimport$4713)
             )
             (call $3430
              (i32.const 1664)
              (global.get $gimport$2008)
             )
             (call $3430
              (i32.const 4156)
              (global.get $gimport$4491)
             )
            )
            (struct.new $1009
             (global.get $global$19)
             (global.get $global$20)
             (global.get $global$28)
             (i32.const 0)
             (call $3430
              (i32.const 4133)
              (global.get $gimport$5699)
             )
             (call $3430
              (i32.const 1580)
              (global.get $gimport$126)
             )
             (call $3430
              (i32.const 1411)
              (global.get $gimport$22)
             )
            )
            (struct.new $1009
             (global.get $global$19)
             (global.get $global$20)
             (global.get $global$28)
             (i32.const 0)
             (call $3430
              (i32.const 1576)
              (global.get $gimport$103)
             )
             (call $3430
              (i32.const 1406)
              (global.get $gimport$5)
             )
             (call $3430
              (i32.const 1576)
              (global.get $gimport$103)
             )
            )
            (struct.new $1009
             (global.get $global$19)
             (global.get $global$20)
             (global.get $global$28)
             (i32.const 0)
             (call $3430
              (i32.const 1576)
              (global.get $gimport$103)
             )
             (call $3430
              (i32.const 1576)
              (global.get $gimport$103)
             )
             (call $3430
              (i32.const 1406)
              (global.get $gimport$5)
             )
            )
           )
          )
         )
        )
       )
       (i32.const 0)
      )
      (then
       (struct.new $1349
        (global.get $global$7)
        (global.get $global$6)
        (global.get $global$365)
        (i32.const 0)
        (local.get $4)
       )
      )
      (else
       (global.get $global$5)
      )
     )
    )
    (struct.get $1458 3
     (struct.get $1464 2
      (struct.get $9 0
       (struct.get $2 0
        (local.get $0)
       )
      )
     )
    )
   )
  )
  (block $block1
   (block $block
    (loop $label2
     (if
      (call_ref $1354
       (local.get $2)
       (struct.get $1451 1
        (local.tee $5
         (struct.get $1464 6
          (struct.get $9 0
           (struct.get $2 0
            (local.get $2)
           )
          )
         )
        )
       )
      )
      (then
       (br_if $block
        (i32.eqz
         (if (result i32)
          (ref.is_null
           (local.tee $0
            (struct.get $1009 4
             (local.tee $9
              (if (result (ref null $1009))
               (if (result i32)
                (ref.is_null
                 (local.tee $0
                  (call_ref $1328
                   (local.get $2)
                   (struct.get $1451 0
                    (local.get $5)
                   )
                  )
                 )
                )
                (then
                 (i32.const 0)
                )
                (else
                 (ref.test (ref $1009)
                  (local.get $0)
                 )
                )
               )
               (then
                (ref.cast (ref null $1009)
                 (local.get $0)
                )
               )
               (else
                (call $831
                 (local.get $0)
                 (struct.new $1352
                  (global.get $global$3)
                  (global.get $global$4)
                  (global.get $global$23)
                  (i32.const 0)
                  (global.get $global$28)
                 )
                 (i32.const 0)
                )
                (unreachable)
               )
              )
             )
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (ref.test (ref $1367)
            (local.get $0)
           )
          )
         )
        )
       )
       (local.set $6
        (ref.cast (ref null $1367)
         (local.get $0)
        )
       )
       (br_if $block
        (i32.eqz
         (if (result i32)
          (ref.is_null
           (local.tee $0
            (struct.get $1009 5
             (local.get $9)
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (ref.test (ref $1367)
            (local.get $0)
           )
          )
         )
        )
       )
       (local.set $10
        (ref.cast (ref $1367)
         (local.get $0)
        )
       )
       (br_if $block
        (i32.eqz
         (if (result i32)
          (ref.is_null
           (local.tee $0
            (struct.get $1009 6
             (local.get $9)
            )
           )
          )
          (then
           (i32.const 0)
          )
          (else
           (ref.test (ref $1367)
            (local.get $0)
           )
          )
         )
        )
       )
       (local.set $7
        (ref.cast (ref null $1367)
         (local.get $0)
        )
       )
       (local.set $0
        (call_ref $1328
         (local.tee $0
          (if (result (ref null $2))
           (i32.gt_s
            (array.len
             (struct.get $1348 4
              (local.tee $4
               (struct.new $1348
                (global.get $global$0)
                (ref.null none)
                (global.get $global$22)
                (i32.const 0)
                (array.new_fixed $1340 3
                 (struct.new $1346
                  (global.get $global$1)
                  (global.get $global$2)
                  (global.get $global$109)
                  (i32.const 0)
                  (i32.const -2147483648)
                 )
                 (struct.new $1346
                  (global.get $global$1)
                  (global.get $global$2)
                  (global.get $global$109)
                  (i32.const 0)
                  (i32.const 0)
                 )
                 (struct.new $1346
                  (global.get $global$1)
                  (global.get $global$2)
                  (global.get $global$109)
                  (i32.const 0)
                  (i32.const 2147483647)
                 )
                )
               )
              )
             )
            )
            (i32.const 0)
           )
           (then
            (struct.new $1349
             (global.get $global$7)
             (global.get $global$6)
             (global.get $global$365)
             (i32.const 0)
             (local.get $4)
            )
           )
           (else
            (global.get $global$5)
           )
          )
         )
         (struct.get $1458 3
          (struct.get $1464 2
           (struct.get $9 0
            (struct.get $2 0
             (local.get $0)
            )
           )
          )
         )
        )
       )
       (loop $label1
        (if
         (call_ref $1354
          (local.get $0)
          (struct.get $1451 1
           (local.tee $5
            (struct.get $1464 6
             (struct.get $9 0
              (struct.get $2 0
               (local.get $0)
              )
             )
            )
           )
          )
         )
         (then
          (local.set $11
           (if (result i32)
            (if (result i32)
             (ref.is_null
              (local.tee $1
               (call_ref $1328
                (local.get $0)
                (struct.get $1451 0
                 (local.get $5)
                )
               )
              )
             )
             (then
              (i32.const 0)
             )
             (else
              (ref.test (ref $1346)
               (local.get $1)
              )
             )
            )
            (then
             (struct.get $1346 4
              (ref.cast (ref $1346)
               (local.get $1)
              )
             )
            )
            (else
             (call $831
              (local.get $1)
              (struct.new $1352
               (global.get $global$3)
               (global.get $global$4)
               (global.get $global$23)
               (i32.const 0)
               (global.get $global$109)
              )
              (i32.const 0)
             )
             (unreachable)
            )
           )
          )
          (local.set $1
           (call_ref $1328
            (local.tee $1
             (if (result (ref null $2))
              (i32.gt_s
               (array.len
                (struct.get $1348 4
                 (local.tee $4
                  (struct.new $1348
                   (global.get $global$0)
                   (ref.null none)
                   (global.get $global$22)
                   (i32.const 0)
                   (array.new_fixed $1340 2
                    (struct.new $1346
                     (global.get $global$1)
                     (global.get $global$2)
                     (global.get $global$109)
                     (i32.const 0)
                     (i32.const 1)
                    )
                    (struct.new $1346
                     (global.get $global$1)
                     (global.get $global$2)
                     (global.get $global$109)
                     (i32.const 0)
                     (i32.const -1)
                    )
                   )
                  )
                 )
                )
               )
               (i32.const 0)
              )
              (then
               (struct.new $1349
                (global.get $global$7)
                (global.get $global$6)
                (global.get $global$365)
                (i32.const 0)
                (local.get $4)
               )
              )
              (else
               (global.get $global$5)
              )
             )
            )
            (struct.get $1458 3
             (struct.get $1464 2
              (struct.get $9 0
               (struct.get $2 0
                (local.get $1)
               )
              )
             )
            )
           )
          )
          (loop $label
           (if
            (call_ref $1354
             (local.get $1)
             (struct.get $1451 1
              (local.tee $5
               (struct.get $1464 6
                (struct.get $9 0
                 (struct.get $2 0
                  (local.get $1)
                 )
                )
               )
              )
             )
            )
            (then
             (local.set $8
              (call_ref $808
               (local.tee $8
                (call $1035
                 (ref.null none)
                 (call $1182
                  (ref.null none)
                  (if (result (ref null $1367))
                   (i32.lt_s
                    (local.tee $12
                     (if (result i32)
                      (if (result i32)
                       (ref.is_null
                        (local.tee $3
                         (call_ref $1328
                          (local.get $1)
                          (struct.get $1451 0
                           (local.get $5)
                          )
                         )
                        )
                       )
                       (then
                        (i32.const 0)
                       )
                       (else
                        (ref.test (ref $1346)
                         (local.get $3)
                        )
                       )
                      )
                      (then
                       (struct.get $1346 4
                        (ref.cast (ref $1346)
                         (local.get $3)
                        )
                       )
                      )
                      (else
                       (call $831
                        (local.get $3)
                        (struct.new $1352
                         (global.get $global$3)
                         (global.get $global$4)
                         (global.get $global$23)
                         (i32.const 0)
                         (global.get $global$109)
                        )
                        (i32.const 0)
                       )
                       (unreachable)
                      )
                     )
                    )
                    (i32.const 0)
                   )
                   (then
                    (call $839
                     (call $3430
                      (i32.const 1069)
                      (global.get $gimport$491)
                     )
                     (local.get $6)
                    )
                   )
                   (else
                    (local.get $6)
                   )
                  )
                 )
                 (local.get $11)
                )
               )
               (call $1035
                (ref.null none)
                (call $1182
                 (ref.null none)
                 (local.get $10)
                )
                (local.get $11)
               )
               (call $1487
                (ref.null none)
                (i32.const 34)
                (call $1557)
               )
               (struct.get $48 27
                (struct.get $18 0
                 (local.get $8)
                )
               )
              )
             )
             (call $1565
              (call $1048
               (ref.null none)
               (if (result (ref null $1367))
                (i32.lt_s
                 (local.get $12)
                 (i32.const 0)
                )
                (then
                 (call $839
                  (call $3430
                   (i32.const 1069)
                   (global.get $gimport$491)
                  )
                  (local.get $7)
                 )
                )
                (else
                 (local.get $7)
                )
               )
              )
              (local.get $8)
              (call $839
               (call $839
                (call $839
                 (call $839
                  (call $839
                   (call $839
                    (local.get $6)
                    (call $3430
                     (i32.const 1574)
                     (global.get $gimport$916)
                    )
                   )
                   (local.get $10)
                  )
                  (call $3430
                   (i32.const 1574)
                   (global.get $gimport$916)
                  )
                 )
                 (struct.new $1346
                  (global.get $global$1)
                  (global.get $global$2)
                  (global.get $global$109)
                  (i32.const 0)
                  (local.get $11)
                 )
                )
                (call $3430
                 (i32.const 1574)
                 (global.get $gimport$916)
                )
               )
               (struct.new $1346
                (global.get $global$1)
                (global.get $global$2)
                (global.get $global$109)
                (i32.const 0)
                (local.get $12)
               )
              )
             )
             (br $label)
            )
           )
          )
          (br $label1)
         )
        )
       )
       (br $label2)
      )
     )
    )
    (br $block1)
   )
   (call $831
    (local.get $0)
    (struct.new $1352
     (global.get $global$3)
     (global.get $global$4)
     (global.get $global$23)
     (i32.const 0)
     (global.get $global$24)
    )
    (i32.const 0)
   )
   (unreachable)
  )
  (global.get $global$10)
 )
