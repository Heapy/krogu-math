  protoOf(MagnitudeMultiplication).h11 = function (a, b, squareEntryThreshold) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(squareEntryThreshold >= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (a.length >= 16 && a.length < squareEntryThreshold && a === b) {
      var out = new Int32Array(a.length + b.length | 0);
      square(this, a, 0, a.length, out, 0);
      return out;
    }
    return this.j11(a, b);
  };
