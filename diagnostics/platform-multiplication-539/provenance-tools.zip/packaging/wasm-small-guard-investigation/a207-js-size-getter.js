  function parallelMagnitudeSize539($this) {
    var words = $this.si_1;
    if (words == null)
      return 0;
    return words.length;
  }
