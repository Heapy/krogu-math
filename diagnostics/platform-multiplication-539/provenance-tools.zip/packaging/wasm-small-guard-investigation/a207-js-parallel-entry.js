  protoOf(BigInteger).vt = function (value) {
    if (this.si_1 == null || !hasParallelMagnitude539(this, value))
      return this.hk(value);
    return parallelMultiplyLarge539(this, value);
  };
