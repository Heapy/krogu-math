  function multiplyAdaptiveJs539($this, a, b) {
    if (a.length >= 16 && a.length < 128 && a === b) {
      var out = new Int32Array(a.length + b.length | 0);
      square($this, a, 0, a.length, out, 0);
      return out;
    }
    var out_0 = new Int32Array(a.length + b.length | 0);
    var tmp0 = a.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b_0 = b.length;
    var small = Math.min(tmp0, b_0);
    if (small < 32) {
      school($this, a, 0, a.length, b, 0, b.length, out_0, 0);
      return out_0;
    }
    var threshold = !(a === b) && a.length === b.length ? 32 : 64;
    if (small < threshold) {
      school($this, a, 0, a.length, b, 0, b.length, out_0, 0);
    } else {
      var arena = new Arena($this.j10(a.length, b.length, threshold));
      product($this, a, 0, a.length, b, 0, b.length, out_0, 0, arena, threshold, 16);
    }
    return out_0;
  }
