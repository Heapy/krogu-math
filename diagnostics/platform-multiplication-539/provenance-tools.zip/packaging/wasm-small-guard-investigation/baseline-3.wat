 (func $2257 (type $372) (param $0 (ref $1367)) (param $1 i32) (param $2 (ref null $18)) (param $3 (ref $1367))
  (local $4 (ref $48))
  (local $5 (ref null $19))
  (call $1565
   (local.get $0)
   (call_ref $1353
    (local.tee $5
     (call_ref $846
      (local.get $2)
      (struct.get $48 10
       (local.tee $4
        (struct.get $18 0
         (local.get $2)
        )
       )
      )
     )
    )
    (struct.get $47 3
     (struct.get $19 0
      (local.get $5)
     )
    )
   )
   (local.get $3)
  )
  (call $1565
   (struct.new $1346
    (global.get $global$1)
    (global.get $global$2)
    (global.get $global$109)
    (i32.const 0)
    (local.get $1)
   )
   (struct.new $1346
    (global.get $global$1)
    (global.get $global$2)
    (global.get $global$109)
    (i32.const 0)
    (call_ref $1354
     (local.get $2)
     (struct.get $48 11
      (local.get $4)
     )
    )
   )
   (local.get $3)
  )
 )
