# Bounded own Wasm small-guard lowering investigation

No production source, build or runtime was changed. Raw guard statistics remain the independent `77dffec6` cause/scope artifact; this investigation does not re-audit or clear any of its six flags. Inputs are the actual07910 baseline and2d74 current optimized-build artifact trees named in the JSON below. Both build logs contain Binaryen optimization tasks; no missing-optimization cause is asserted.

## Concrete reachable changed fallback

`current-1.wat` is the named actual `BigInteger.parallelMultiply`: it calls `hasParallelMagnitude539` before virtual multiply fallback. `current-3.wat` calls the size helper on the first operand and short-circuits if its size is below4096. `current-2.wat` is the actual size helper: null wide storage returns0, but nonnull storage constructs `struct.new $kotlin.Int` around the array-size result (lines18–28) and then unboxes it (lines37–39). Thus the measured wide small fallback reaches a boxed-Int allocation for the first operand before rejecting it. The compact1square route returns0 without that box; it still has the new helper/branch work. No worker is activated by these tiny routes. This is a reachable Wasm GC construction instruction, not a measurement of surviving V8 heap allocation; engine elimination or its latency contribution has not been observed.

The narrow staged candidate in sibling `wasm-primitive-size-fix` replaces only `wideWords?.size ?: 0` with an explicit stored-reference local/null-check and primitive size return. This addresses the demonstrated source/lowering boundary. Compiler removal, actual performance recovery and JVM/non-JVM compiled binding are not yet proved. It is not an explanation or repair of the ordinary controls.

## Ordinary controls: bounded conclusion and limits

`current-8.wat` (`multiplyAdaptive`) immediately takes a constant-true branch to the historical `multiplyWithSquareEntry(...,384)` on Wasm. The later selected-policy branch is unreachable. `current-9.wat` retains the alias/size whole-square selection. The ordinary compact1square route bypasses this magnitude dispatch; ordinary511square is an18-word physical alias and takes the historical whole-square path with leaf16/entry384. The current ordinary method is extracted in `current-0.wat`; no selected JS32 policy is reachable on these controls.

Baseline has no name section. A bounded source-map candidate extraction and a normalized-symbol structural match attempt did not establish reliable exact baseline function identities/equivalence. Their candidate files and empty match result are retained as UNVALIDATED mapping attempts, never as arithmetic or emitted equivalence evidence. No claim is made that anonymous function IDs guessed from source-map offsets identify multiply. The inspection stops at this gap rather than expanding into general reverse engineering.

There is no demonstrated new ordinary-control call/allocation boundary in this bounded comparison, and no supported ordinary-path candidate fix. Effective source/policy equality alone does not prove equal V8 optimized machine code. JIT/code-layout/host-noise explanations remain hypotheses, not causes; the all-three adverse511square result remains visible.

## Sufficient next action within existing gates

First compile the private primitive-size correction at the owner's safe boundary and inspect that same named helper for removal of nullable-Int construction. Use the already-required current-source Wasm paired-small guard as the single finite runtime diagnostic: inspect unchanged `public/1/square` and `public/511/square` alongside changed `parallel-public/511/distinct` (all original28 cases remain unfiltered). This reuses the existing fixture/process pairing and requires no debug rebuild, new input grid or new acceptance threshold. Retain every fork and the existing15% AND5ns flag. If ordinary flags remain, report that scoped residual; causal completeness itself is not an added acceptance gate. Do not transfer the JS-only fix to Wasm automatically or clear flags using guessed noise.
