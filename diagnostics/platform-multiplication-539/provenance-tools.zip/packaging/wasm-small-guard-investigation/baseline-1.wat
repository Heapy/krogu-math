 (func $2255 (type $793) (param $0 (ref null $18)) (param $1 i32) (param $2 (ref null $809)) (result (ref null $18))
  (call $852
   (struct.get $386 11
    (ref.cast (ref $386)
     (local.get $0)
    )
   )
  )
  (unreachable)
 )
