 (func $2179 (type $913) (result (ref null $2))
  (local $0 (ref null $2))
  (local $1 (ref null $2))
  (local $2 (ref null $2))
  (local $3 (ref null $2))
  (local $4 (ref null $2))
  (local $5 (ref null $18))
  (local $6 (ref $1348))
  (local $7 (ref null $1451))
  (local $8 (ref null $19))
  (local $9 (ref null $19))
  (local $10 (ref $47))
  (local $11 (ref null $1319))
  (local $12 (ref null $48))
  (local $13 (ref $48))
  (local $14 i32)
  (local $15 i32)
  (local $16 i32)
  (local $17 i32)
  (local.set $3
   (call_ref $1328
    (local.tee $3
     (if (result (ref null $2))
      (i32.gt_s
       (array.len
        (struct.get $1348 4
         (local.tee $6
          (struct.new $1348
           (global.get $global$0)
           (ref.null none)
           (global.get $global$22)
           (i32.const 0)
           (array.new_fixed $1340 10
            (struct.new $1346
             (global.get $global$1)
             (global.get $global$2)
             (global.get $global$109)
             (i32.const 0)
             (i32.const 0)
            )
            (struct.new $1346
             (global.get $global$1)
             (global.get $global$2)
             (global.get $global$109)
             (i32.const 0)
             (i32.const 1)
            )
            (struct.new $1346
             (global.get $global$1)
             (global.get $global$2)
             (global.get $global$109)
             (i32.const 0)
             (i32.const 18)
            )
            (struct.new $1346
             (global.get $global$1)
             (global.get $global$2)
             (global.get $global$109)
             (i32.const 0)
             (i32.const 19)
            )
            (struct.new $1346
             (global.get $global$1)
             (global.get $global$2)
             (global.get $global$109)
             (i32.const 0)
             (i32.const 33)
            )
            (struct.new $1346
             (global.get $global$1)
             (global.get $global$2)
             (global.get $global$109)
             (i32.const 0)
             (i32.const 34)
            )
            (struct.new $1346
             (global.get $global$1)
             (global.get $global$2)
             (global.get $global$109)
             (i32.const 0)
             (i32.const 127)
            )
            (struct.new $1346
             (global.get $global$1)
             (global.get $global$2)
             (global.get $global$109)
             (i32.const 0)
             (i32.const 128)
            )
            (struct.new $1346
             (global.get $global$1)
             (global.get $global$2)
             (global.get $global$109)
             (i32.const 0)
             (i32.const 129)
            )
            (struct.new $1346
             (global.get $global$1)
             (global.get $global$2)
             (global.get $global$109)
             (i32.const 0)
             (i32.const 256)
            )
           )
          )
         )
        )
       )
       (i32.const 0)
      )
      (then
       (struct.new $1349
        (global.get $global$7)
        (global.get $global$6)
        (global.get $global$365)
        (i32.const 0)
        (local.get $6)
       )
      )
      (else
       (global.get $global$5)
      )
     )
    )
    (struct.get $1458 3
     (struct.get $1464 2
      (struct.get $9 0
       (struct.get $2 0
        (local.get $3)
       )
      )
     )
    )
   )
  )
  (loop $label4
   (if
    (call_ref $1354
     (local.get $3)
     (struct.get $1451 1
      (local.tee $7
       (struct.get $1464 6
        (struct.get $9 0
         (struct.get $2 0
          (local.get $3)
         )
        )
       )
      )
     )
    )
    (then
     (local.set $14
      (if (result i32)
       (if (result i32)
        (ref.is_null
         (local.tee $1
          (call_ref $1328
           (local.get $3)
           (struct.get $1451 0
            (local.get $7)
           )
          )
         )
        )
        (then
         (i32.const 0)
        )
        (else
         (ref.test (ref $1346)
          (local.get $1)
         )
        )
       )
       (then
        (struct.get $1346 4
         (ref.cast (ref $1346)
          (local.get $1)
         )
        )
       )
       (else
        (call $831
         (local.get $1)
         (struct.new $1352
          (global.get $global$3)
          (global.get $global$4)
          (global.get $global$23)
          (i32.const 0)
          (global.get $global$109)
         )
         (i32.const 0)
        )
        (unreachable)
       )
      )
     )
     (local.set $1
      (call_ref $1328
       (local.tee $1
        (if (result (ref null $2))
         (i32.gt_s
          (array.len
           (struct.get $1348 4
            (local.tee $6
             (struct.new $1348
              (global.get $global$0)
              (ref.null none)
              (global.get $global$22)
              (i32.const 0)
              (array.new_fixed $1340 3
               (struct.new $1319
                (global.get $global$13)
                (global.get $global$14)
                (global.get $global$26)
                (i32.const 0)
                (call_ref $847
                 (local.tee $9
                  (call $1182
                   (ref.null none)
                   (call $839
                    (call $3430
                     (i32.const 1406)
                     (global.get $gimport$5)
                    )
                    (call $977
                     (call $3430
                      (i32.const 1112)
                      (global.get $gimport$0)
                     )
                     (local.get $14)
                    )
                   )
                  )
                 )
                 (struct.get $1391 1
                  (call $1172)
                 )
                 (struct.get $47 14
                  (local.tee $10
                   (struct.get $19 0
                    (local.get $9)
                   )
                  )
                 )
                )
                (struct.new $1346
                 (global.get $global$1)
                 (global.get $global$2)
                 (global.get $global$109)
                 (i32.const 0)
                 (select
                  (i32.const 1)
                  (local.get $14)
                  (i32.le_s
                   (local.get $14)
                   (i32.const 1)
                  )
                 )
                )
               )
               (struct.new $1319
                (global.get $global$13)
                (global.get $global$14)
                (global.get $global$26)
                (i32.const 0)
                (local.get $9)
                (struct.new $1346
                 (global.get $global$1)
                 (global.get $global$2)
                 (global.get $global$109)
                 (i32.const 0)
                 (local.tee $15
                  (i32.add
                   (local.get $14)
                   (i32.const 1)
                  )
                 )
                )
               )
               (struct.new $1319
                (global.get $global$13)
                (global.get $global$14)
                (global.get $global$26)
                (i32.const 0)
                (call_ref $847
                 (local.get $9)
                 (struct.get $1391 1
                  (call $1172)
                 )
                 (struct.get $47 13
                  (local.get $10)
                 )
                )
                (struct.new $1346
                 (global.get $global$1)
                 (global.get $global$2)
                 (global.get $global$109)
                 (i32.const 0)
                 (local.get $15)
                )
               )
              )
             )
            )
           )
          )
          (i32.const 0)
         )
         (then
          (struct.new $1349
           (global.get $global$7)
           (global.get $global$6)
           (global.get $global$365)
           (i32.const 0)
           (local.get $6)
          )
         )
         (else
          (global.get $global$5)
         )
        )
       )
       (struct.get $1458 3
        (struct.get $1464 2
         (struct.get $9 0
          (struct.get $2 0
           (local.get $1)
          )
         )
        )
       )
      )
     )
     (loop $label3
      (if
       (call_ref $1354
        (local.get $1)
        (struct.get $1451 1
         (local.tee $7
          (struct.get $1464 6
           (struct.get $9 0
            (struct.get $2 0
             (local.get $1)
            )
           )
          )
         )
        )
       )
       (then
        (local.set $8
         (if (result (ref null $19))
          (if (result i32)
           (ref.is_null
            (local.tee $0
             (struct.get $1319 4
              (local.tee $11
               (if (result (ref null $1319))
                (if (result i32)
                 (ref.is_null
                  (local.tee $0
                   (call_ref $1328
                    (local.get $1)
                    (struct.get $1451 0
                     (local.get $7)
                    )
                   )
                  )
                 )
                 (then
                  (i32.const 0)
                 )
                 (else
                  (ref.test (ref $1319)
                   (local.get $0)
                  )
                 )
                )
                (then
                 (ref.cast (ref null $1319)
                  (local.get $0)
                 )
                )
                (else
                 (call $831
                  (local.get $0)
                  (struct.new $1352
                   (global.get $global$3)
                   (global.get $global$4)
                   (global.get $global$23)
                   (i32.const 0)
                   (global.get $global$26)
                  )
                  (i32.const 0)
                 )
                 (unreachable)
                )
               )
              )
             )
            )
           )
           (then
            (i32.const 0)
           )
           (else
            (ref.test (ref $19)
             (local.get $0)
            )
           )
          )
          (then
           (ref.cast (ref null $19)
            (local.get $0)
           )
          )
          (else
           (call $831
            (local.get $0)
            (struct.new $1352
             (global.get $global$3)
             (global.get $global$4)
             (global.get $global$23)
             (i32.const 0)
             (global.get $global$112)
            )
            (i32.const 0)
           )
           (unreachable)
          )
         )
        )
        (local.set $16
         (if (result i32)
          (if (result i32)
           (ref.is_null
            (local.tee $0
             (struct.get $1319 5
              (local.get $11)
             )
            )
           )
           (then
            (i32.const 0)
           )
           (else
            (ref.test (ref $1346)
             (local.get $0)
            )
           )
          )
          (then
           (struct.get $1346 4
            (ref.cast (ref $1346)
             (local.get $0)
            )
           )
          )
          (else
           (call $831
            (local.get $0)
            (struct.new $1352
             (global.get $global$3)
             (global.get $global$4)
             (global.get $global$23)
             (i32.const 0)
             (global.get $global$109)
            )
            (i32.const 0)
           )
           (unreachable)
          )
         )
        )
        (local.set $0
         (call_ref $1328
          (local.tee $0
           (if (result (ref null $2))
            (i32.gt_s
             (array.len
              (struct.get $1348 4
               (local.tee $6
                (struct.new $1348
                 (global.get $global$0)
                 (ref.null none)
                 (global.get $global$22)
                 (i32.const 0)
                 (array.new_fixed $1340 2
                  (local.get $8)
                  (call_ref $846
                   (local.get $8)
                   (struct.get $47 12
                    (struct.get $19 0
                     (local.get $8)
                    )
                   )
                  )
                 )
                )
               )
              )
             )
             (i32.const 0)
            )
            (then
             (struct.new $1349
              (global.get $global$7)
              (global.get $global$6)
              (global.get $global$365)
              (i32.const 0)
              (local.get $6)
             )
            )
            (else
             (global.get $global$5)
            )
           )
          )
          (struct.get $1458 3
           (struct.get $1464 2
            (struct.get $9 0
             (struct.get $2 0
              (local.get $0)
             )
            )
           )
          )
         )
        )
        (loop $label2
         (if
          (call_ref $1354
           (local.get $0)
           (struct.get $1451 1
            (local.tee $7
             (struct.get $1464 6
              (struct.get $9 0
               (struct.get $2 0
                (local.get $0)
               )
              )
             )
            )
           )
          )
          (then
           (local.set $8
            (if (result (ref null $19))
             (if (result i32)
              (ref.is_null
               (local.tee $2
                (call_ref $1328
                 (local.get $0)
                 (struct.get $1451 0
                  (local.get $7)
                 )
                )
               )
              )
              (then
               (i32.const 0)
              )
              (else
               (ref.test (ref $19)
                (local.get $2)
               )
              )
             )
             (then
              (ref.cast (ref null $19)
               (local.get $2)
              )
             )
             (else
              (call $831
               (local.get $2)
               (struct.new $1352
                (global.get $global$3)
                (global.get $global$4)
                (global.get $global$23)
                (i32.const 0)
                (global.get $global$112)
               )
               (i32.const 0)
              )
              (unreachable)
             )
            )
           )
           (local.set $2
            (call_ref $1328
             (local.tee $2
              (if (result (ref null $2))
               (i32.gt_s
                (array.len
                 (struct.get $1348 4
                  (local.tee $6
                   (struct.new $1348
                    (global.get $global$0)
                    (ref.null none)
                    (global.get $global$22)
                    (i32.const 0)
                    (array.new_fixed $1340 3
                     (struct.new $1346
                      (global.get $global$1)
                      (global.get $global$2)
                      (global.get $global$109)
                      (i32.const 0)
                      (i32.const -2147483648)
                     )
                     (struct.new $1346
                      (global.get $global$1)
                      (global.get $global$2)
                      (global.get $global$109)
                      (i32.const 0)
                      (i32.const 0)
                     )
                     (struct.new $1346
                      (global.get $global$1)
                      (global.get $global$2)
                      (global.get $global$109)
                      (i32.const 0)
                      (i32.const 2147483647)
                     )
                    )
                   )
                  )
                 )
                )
                (i32.const 0)
               )
               (then
                (struct.new $1349
                 (global.get $global$7)
                 (global.get $global$6)
                 (global.get $global$365)
                 (i32.const 0)
                 (local.get $6)
                )
               )
               (else
                (global.get $global$5)
               )
              )
             )
             (struct.get $1458 3
              (struct.get $1464 2
               (struct.get $9 0
                (struct.get $2 0
                 (local.get $2)
                )
               )
              )
             )
            )
           )
           (loop $label1
            (if
             (call_ref $1354
              (local.get $2)
              (struct.get $1451 1
               (local.tee $7
                (struct.get $1464 6
                 (struct.get $9 0
                  (struct.get $2 0
                   (local.get $2)
                  )
                 )
                )
               )
              )
             )
             (then
              (local.set $5
               (call $1035
                (ref.null none)
                (local.get $8)
                (local.tee $17
                 (if (result i32)
                  (if (result i32)
                   (ref.is_null
                    (local.tee $4
                     (call_ref $1328
                      (local.get $2)
                      (struct.get $1451 0
                       (local.get $7)
                      )
                     )
                    )
                   )
                   (then
                    (i32.const 0)
                   )
                   (else
                    (ref.test (ref $1346)
                     (local.get $4)
                    )
                   )
                  )
                  (then
                   (struct.get $1346 4
                    (ref.cast (ref $1346)
                     (local.get $4)
                    )
                   )
                  )
                  (else
                   (call $831
                    (local.get $4)
                    (struct.new $1352
                     (global.get $global$3)
                     (global.get $global$4)
                     (global.get $global$23)
                     (i32.const 0)
                     (global.get $global$109)
                    )
                    (i32.const 0)
                   )
                   (unreachable)
                  )
                 )
                )
               )
              )
              (local.set $15
               (i32.const 0)
              )
              (loop $label
               (local.set $15
                (i32.add
                 (local.get $15)
                 (i32.const 1)
                )
               )
               (call $1565
                (struct.new $1346
                 (global.get $global$1)
                 (global.get $global$2)
                 (global.get $global$109)
                 (i32.const 0)
                 (local.get $16)
                )
                (struct.new $1346
                 (global.get $global$1)
                 (global.get $global$2)
                 (global.get $global$109)
                 (i32.const 0)
                 (call_ref $1354
                  (local.get $5)
                  (struct.get $48 12
                   (local.tee $12
                    (struct.get $18 0
                     (local.get $5)
                    )
                   )
                  )
                 )
                )
                (ref.null none)
               )
               (br_if $label
                (i32.lt_s
                 (local.get $15)
                 (i32.const 3)
                )
               )
              )
              (call $1565
               (struct.new $1346
                (global.get $global$1)
                (global.get $global$2)
                (global.get $global$109)
                (i32.const 0)
                (local.get $17)
               )
               (struct.new $1346
                (global.get $global$1)
                (global.get $global$2)
                (global.get $global$109)
                (i32.const 0)
                (call_ref $1354
                 (local.get $5)
                 (struct.get $48 11
                  (local.tee $13
                   (ref.as_non_null
                    (local.get $12)
                   )
                  )
                 )
                )
               )
               (ref.null none)
              )
              (call $1565
               (local.get $8)
               (call_ref $846
                (local.get $5)
                (struct.get $48 10
                 (local.get $13)
                )
               )
               (ref.null none)
              )
              (br $label1)
             )
            )
           )
           (br $label2)
          )
         )
        )
        (br $label3)
       )
      )
     )
     (call $1565
      (local.get $9)
      (call_ref $846
       (local.tee $5
        (call_ref $807
         (local.tee $5
          (struct.get $1392 1
           (call $1032)
          )
         )
         (local.get $14)
         (struct.get $48 34
          (struct.get $18 0
           (local.get $5)
          )
         )
        )
       )
       (struct.get $48 10
        (struct.get $18 0
         (local.get $5)
        )
       )
      )
      (ref.null none)
     )
     (call $1565
      (struct.new $1346
       (global.get $global$1)
       (global.get $global$2)
       (global.get $global$109)
       (i32.const 0)
       (local.get $14)
      )
      (struct.new $1346
       (global.get $global$1)
       (global.get $global$2)
       (global.get $global$109)
       (i32.const 0)
       (call_ref $1354
        (local.get $5)
        (struct.get $48 11
         (struct.get $18 0
          (local.get $5)
         )
        )
       )
      )
      (ref.null none)
     )
     (call $1565
      (struct.get $1392 1
       (call $1032)
      )
      (call_ref $798
       (local.get $5)
       (i32.const 0)
       (call $1557)
       (struct.get $48 36
        (struct.get $18 0
         (local.get $5)
        )
       )
      )
      (ref.null none)
     )
     (br $label4)
    )
   )
  )
  (global.get $global$10)
 )
