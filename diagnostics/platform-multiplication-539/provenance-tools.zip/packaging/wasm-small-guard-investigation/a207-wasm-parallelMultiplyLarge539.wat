 (func $io.heapy.krogu.math.BigInteger.parallelMultiplyLarge539 (param $<this> (ref null $io.heapy.krogu.math.BigInteger)) (param $value (ref null $io.heapy.krogu.math.BigInteger)) (result (ref null $io.heapy.krogu.math.BigInteger))
  (local $leftWords (ref null $kotlin.IntArray))
  (local $~tmp0_elvis_lhs (ref null $kotlin.IntArray))
  (local $rightWords (ref null $kotlin.IntArray))
  (local $~tmp1_elvis_lhs (ref null $kotlin.IntArray))
  (local $~tmp (ref null $kotlin.Any))
  (local $~tmp_7 (ref null $kotlin.Any))
  (local $product (ref null $kotlin.IntArray))
  (local $~tmp2_elvis_lhs (ref null $kotlin.IntArray))
  (local.set $leftWords
   (if (result (ref null $kotlin.IntArray))
    (ref.is_null
     (local.tee $~tmp0_elvis_lhs
      (struct.get $io.heapy.krogu.math.BigInteger $wideWords
       (local.get $<this>)
      )
     )
    )
    (then
     (return
      (call_ref $_1060
       (local.get $<this>)
       (local.get $value)
       (struct.get $<classVTable>_1066 $multiply
        (struct.get $io.heapy.krogu.math.BigInteger $vtable
         (local.get $<this>)
        )
       )
      )
     )
    )
    (else
     (local.get $~tmp0_elvis_lhs)
    )
   )
  )
  (local.set $rightWords
   (if (result (ref null $kotlin.IntArray))
    (ref.is_null
     (local.tee $~tmp1_elvis_lhs
      (struct.get $io.heapy.krogu.math.BigInteger $wideWords
       (local.get $value)
      )
     )
    )
    (then
     (return
      (call_ref $_1060
       (local.get $<this>)
       (local.get $value)
       (struct.get $<classVTable>_1066 $multiply
        (struct.get $io.heapy.krogu.math.BigInteger $vtable
         (local.get $<this>)
        )
       )
      )
     )
    )
    (else
     (local.get $~tmp1_elvis_lhs)
    )
   )
  )
  (if
   (i32.eqz
    (call $io.heapy.krogu.math.canParallelMultiply539
     (call $kotlin.IntArray.<get-size>
      (local.get $leftWords)
     )
     (call $kotlin.IntArray.<get-size>
      (local.get $rightWords)
     )
    )
   )
   (then
    (return
     (call_ref $_1060
      (local.get $<this>)
      (local.get $value)
      (struct.get $<classVTable>_1066 $multiply
       (struct.get $io.heapy.krogu.math.BigInteger $vtable
        (local.get $<this>)
       )
      )
     )
    )
   )
  )
  (if
   (if (result i32)
    (i32.eqz
     (call_ref $_9
      (local.tee $~tmp
       (call $kotlin.wasm.internal.getKClassFromExpression
        (local.get $<this>)
       )
      )
      (struct.new $kotlin.wasm.internal.KClassImpl
       (global.get $<classVTable>_1854)
       (global.get $<classITable>_2443)
       (global.get $kotlin.wasm.internal.KClassImpl_rtti)
       (i32.const 0)
       (global.get $io.heapy.krogu.math.BigInteger_rtti)
      )
      (struct.get $<classITable>_2616 $equals
       (ref.cast (ref $<classITable>_2616)
        (call $kotlin.wasm.internal.getInterfaceVTable
         (local.get $~tmp)
         (i64.const 6362707103299592704)
        )
       )
      )
     )
    )
    (then
     (i32.const 1)
    )
    (else
     (i32.eqz
      (call_ref $_9
       (local.tee $~tmp_7
        (call $kotlin.wasm.internal.getKClassFromExpression
         (local.get $value)
        )
       )
       (struct.new $kotlin.wasm.internal.KClassImpl
        (global.get $<classVTable>_1854)
        (global.get $<classITable>_2443)
        (global.get $kotlin.wasm.internal.KClassImpl_rtti)
        (i32.const 0)
        (global.get $io.heapy.krogu.math.BigInteger_rtti)
       )
       (struct.get $<classITable>_2616 $equals
        (ref.cast (ref $<classITable>_2616)
         (call $kotlin.wasm.internal.getInterfaceVTable
          (local.get $~tmp_7)
          (i64.const 6362707103299592704)
         )
        )
       )
      )
     )
    )
   )
   (then
    (return
     (call_ref $_1060
      (local.get $<this>)
      (local.get $value)
      (struct.get $<classVTable>_1066 $multiply
       (struct.get $io.heapy.krogu.math.BigInteger $vtable
        (local.get $<this>)
       )
      )
     )
    )
   )
  )
  (call $io.heapy.krogu.math.MagnitudeMultiplication.checkBitLengths
   (global.get $io.heapy.krogu.math.MagnitudeMultiplication_instance)
   (call $io.heapy.krogu.math.BigInteger.magnitudeBits
    (local.get $<this>)
   )
   (call $io.heapy.krogu.math.BigInteger.magnitudeBits
    (local.get $value)
   )
  )
  (local.set $product
   (if (result (ref null $kotlin.IntArray))
    (ref.is_null
     (local.tee $~tmp2_elvis_lhs
      (call $io.heapy.krogu.math.parallelMagnitude539
       (local.get $leftWords)
       (if (result (ref null $kotlin.IntArray))
        (ref.eq
         (local.get $value)
         (local.get $<this>)
        )
        (then
         (local.get $leftWords)
        )
        (else
         (local.get $rightWords)
        )
       )
      )
     )
    )
    (then
     (return
      (call_ref $_1060
       (local.get $<this>)
       (local.get $value)
       (struct.get $<classVTable>_1066 $multiply
        (struct.get $io.heapy.krogu.math.BigInteger $vtable
         (local.get $<this>)
        )
       )
      )
     )
    )
    (else
     (local.get $~tmp2_elvis_lhs)
    )
   )
  )
  (return
   (call $io.heapy.krogu.math.Companion.normalized
    (call $io.heapy.krogu.math.Companion_getInstance_2655)
    (i32.mul
     (struct.get $io.heapy.krogu.math.BigInteger $sign
      (local.get $<this>)
     )
     (struct.get $io.heapy.krogu.math.BigInteger $sign
      (local.get $value)
     )
    )
    (local.get $product)
   )
  )
 )
