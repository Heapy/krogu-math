 (func $io.heapy.krogu.math.BigInteger.multiplyModuloBounded (param $<this> (ref null $io.heapy.krogu.math.BigInteger)) (param $value (ref null $io.heapy.krogu.math.BigInteger)) (param $m (ref null $io.heapy.krogu.math.BigInteger)) (result (ref null $io.heapy.krogu.math.BigInteger))
  (local $~tmp0 i32)
  (local $~value i32)
  (local $~tmp0_5 i32)
  (local $~value_6 i32)
  (local $message (ref null $kotlin.Any))
  (local $result (ref null $io.heapy.krogu.math.BigInteger))
  (local $addend (ref null $io.heapy.krogu.math.BigInteger))
  (local $bits i32)
  (local $~inductionVariable i32)
  (local $i i32)
  (local.set $~tmp0
   (if (result i32)
    (if (result i32)
     (if (result i32)
      (if (result i32)
       (i32.ge_s
        (struct.get $io.heapy.krogu.math.BigInteger $sign
         (local.get $<this>)
        )
        (i32.const 0)
       )
       (then
        (i32.ge_s
         (struct.get $io.heapy.krogu.math.BigInteger $sign
          (local.get $value)
         )
         (i32.const 0)
        )
       )
       (else
        (i32.const 0)
       )
      )
      (then
       (i32.gt_s
        (struct.get $io.heapy.krogu.math.BigInteger $sign
         (local.get $m)
        )
        (i32.const 0)
       )
      )
      (else
       (i32.const 0)
      )
     )
     (then
      (i32.lt_s
       (call_ref $_1062
        (local.get $<this>)
        (local.get $m)
        (struct.get $<classVTable>_1066 $compareTo
         (struct.get $io.heapy.krogu.math.BigInteger $vtable
          (local.get $<this>)
         )
        )
       )
       (i32.const 0)
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (i32.lt_s
      (call_ref $_1062
       (local.get $value)
       (local.get $m)
       (struct.get $<classVTable>_1066 $compareTo
        (struct.get $io.heapy.krogu.math.BigInteger $vtable
         (local.get $value)
        )
       )
      )
      (i32.const 0)
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
  (drop
   (block $block2 (result (ref null $kotlin.Unit))
    (nop)
    (local.set $~tmp0_5
     (local.tee $~value
      (local.get $~tmp0)
     )
    )
    (drop
     (block $block1 (result (ref null $kotlin.Unit))
      (nop)
      (if
       (i32.eqz
        (local.tee $~value_6
         (local.get $~tmp0_5)
        )
       )
       (then
        (local.set $message
         (block $block (result (ref null $kotlin.Any))
          (nop)
          (br $block
           (call $_stringLiteralJsString
            (i32.const 720)
            (global.get $gimport$648)
           )
          )
         )
        )
        (call $kotlin.wasm.internal.throwValue
         (call $kotlin.IllegalArgumentException.<init>_2209
          (ref.null none)
          (call_ref $_7
           (local.get $message)
           (struct.get $<classVTable> $toString
            (struct.get $kotlin.Any $vtable
             (local.get $message)
            )
           )
          )
         )
        )
        (unreachable)
       )
      )
      (br $block1
       (call $kotlin.Unit_getInstance)
      )
     )
    )
    (br $block2
     (call $kotlin.Unit_getInstance)
    )
   )
  )
  (local.set $result
   (struct.get $io.heapy.krogu.math.Companion_1113 $ZERO
    (call $io.heapy.krogu.math.Companion_getInstance_2655)
   )
  )
  (local.set $addend
   (local.get $<this>)
  )
  (local.set $bits
   (call $io.heapy.krogu.math.BigInteger.magnitudeBits
    (local.get $value)
   )
  )
  (if
   (i32.lt_s
    (local.tee $~inductionVariable
     (i32.const 0)
    )
    (local.get $bits)
   )
   (then
    (loop $label
     (block
      (local.set $i
       (local.get $~inductionVariable)
      )
      (local.set $~inductionVariable
       (i32.add
        (local.get $~inductionVariable)
        (i32.const 1)
       )
      )
      (if
       (call_ref $_5
        (local.get $value)
        (local.get $i)
        (struct.get $<classVTable>_1066 $testBit
         (struct.get $io.heapy.krogu.math.BigInteger $vtable
          (local.get $value)
         )
        )
       )
       (then
        (local.set $result
         (call $io.heapy.krogu.math.addResidues
          (local.get $m)
          (local.get $result)
          (local.get $addend)
         )
        )
       )
      )
      (if
       (i32.lt_s
        (i32.add
         (local.get $i)
         (i32.const 1)
        )
        (local.get $bits)
       )
       (then
        (local.set $addend
         (call $io.heapy.krogu.math.addResidues
          (local.get $m)
          (local.get $addend)
          (local.get $addend)
         )
        )
       )
      )
     )
     (br_if $label
      (i32.lt_s
       (local.get $~inductionVariable)
       (local.get $bits)
      )
     )
    )
   )
  )
  (return
   (local.get $result)
  )
 )
