 (func $io.heapy.krogu.math.MagnitudeMultiplication.multiply$default (param $<this> (ref null $io.heapy.krogu.math.MagnitudeMultiplication)) (param $a (ref null $kotlin.IntArray)) (param $b (ref null $kotlin.IntArray)) (param $threshold (ref null $kotlin.Int)) (param $squareThreshold (ref null $kotlin.Int)) (param $$mask0 i32) (param $$handler (ref null $kotlin.Any)) (result (ref null $kotlin.IntArray))
  (if
   (i32.eqz
    (i32.eq
     (i32.and
      (local.get $$mask0)
      (i32.const 4)
     )
     (i32.const 0)
    )
   )
   (then
    (local.set $threshold
     (struct.new $kotlin.Int
      (global.get $<classVTable>_1808)
      (global.get $<classITable>_2426)
      (global.get $kotlin.Int_rtti)
      (i32.const 0)
      (i32.const 64)
     )
    )
   )
  )
  (if
   (i32.eqz
    (i32.eq
     (i32.and
      (local.get $$mask0)
      (i32.const 8)
     )
     (i32.const 0)
    )
   )
   (then
    (local.set $squareThreshold
     (struct.new $kotlin.Int
      (global.get $<classVTable>_1808)
      (global.get $<classITable>_2426)
      (global.get $kotlin.Int_rtti)
      (i32.const 0)
      (i32.const 16)
     )
    )
   )
  )
  (return
   (call $io.heapy.krogu.math.MagnitudeMultiplication.multiply
    (local.get $<this>)
    (local.get $a)
    (local.get $b)
    (struct.get $kotlin.Int $value
     (local.get $threshold)
    )
    (struct.get $kotlin.Int $value
     (local.get $squareThreshold)
    )
   )
  )
 )
