  protoOf(BigInteger).vt = function (value) {
    return this.hk(value);
  };
