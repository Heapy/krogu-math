 (func $io.heapy.krogu.math.BigInteger.hasParallelMagnitude539 (param $<this> (ref null $io.heapy.krogu.math.BigInteger)) (param $value (ref null $io.heapy.krogu.math.BigInteger)) (result i32)
  (return
   (if (result i32)
    (i32.ge_s
     (call $io.heapy.krogu.math.BigInteger.parallelMagnitudeSize539
      (local.get $<this>)
     )
     (i32.const 4096)
    )
    (then
     (i32.ge_s
      (call $io.heapy.krogu.math.BigInteger.parallelMagnitudeSize539
       (local.get $value)
      )
      (i32.const 4096)
     )
    )
    (else
     (i32.const 0)
    )
   )
  )
 )
