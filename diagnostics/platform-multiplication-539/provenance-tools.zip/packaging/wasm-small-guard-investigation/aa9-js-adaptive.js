  protoOf(MagnitudeMultiplication).ut = function (a, b) {
    if (false)
      return multiplyAdaptiveJs539(this, a, b);
    if (true && true)
      return this.h11(a, b, 384);
    if (a === b && a.length >= 16 && a.length < this.g11()) {
      var out = new Int32Array(a.length + b.length | 0);
      square(this, a, 0, a.length, out, 0);
      return out;
    }
    return this.i11(a, b, this.f11(a, b), 16);
  };
