  protoOf(MagnitudeMultiplication).j11 = function (a, b, threshold, squareThreshold, $super) {
    threshold = threshold === VOID ? 64 : threshold;
    squareThreshold = squareThreshold === VOID ? 16 : squareThreshold;
    return $super === VOID ? this.i11(a, b, threshold, squareThreshold) : $super.i11.call(this, a, b, threshold, squareThreshold);
  };
