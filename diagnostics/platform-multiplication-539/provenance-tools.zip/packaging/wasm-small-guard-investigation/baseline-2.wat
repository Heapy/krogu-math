 (func $2256 (type $412) (result (ref $411))
  (struct.new $411
   (call $29
    (call $615
     (i32.const 2147483637)
     (i32.const 2147483647)
    )
   )
  )
 )
