 (func $2180 (type $913) (result (ref null $2))
  (local $0 (ref $306))
  (local $1 (ref null $5))
  (local $2 (ref $909))
  (local $3 i32)
  (drop
   (call $1048
    (local.tee $0
     (struct.new $306
      (global.get $global$1578)
      (global.get $global$2033)
      (global.get $global$2357)
      (i32.const 0)
      (i32.const 0)
      (i32.const 0)
      (i32.const 0)
      (i32.const 0)
      (ref.null none)
      (i32.const 0)
      (ref.null none)
      (i32.const 0)
      (local.tee $2
       (call $928
        (call $3430
         (i32.const 4154)
         (global.get $gimport$15632)
        )
       )
      )
     )
    )
    (call $3430
     (i32.const 4152)
     (global.get $gimport$15631)
    )
   )
  )
  (struct.set $306 11
   (local.get $0)
   (i32.const 0)
  )
  (loop $label
   (local.set $3
    (i32.add
     (local.get $3)
     (i32.const 1)
    )
   )
   (call $1565
    (struct.new $1346
     (global.get $global$1)
     (global.get $global$2)
     (global.get $global$109)
     (i32.const 0)
     (i32.const 33)
    )
    (struct.new $1346
     (global.get $global$1)
     (global.get $global$2)
     (global.get $global$109)
     (i32.const 0)
     (call $2178
      (local.get $0)
     )
    )
    (ref.null none)
   )
   (br_if $label
    (i32.lt_s
     (local.get $3)
     (i32.const 3)
    )
   )
  )
  (struct.set $306 11
   (local.get $0)
   (i32.const 1)
  )
  (call $1570
   (local.get $2)
   (try (result (ref null $909))
    (do
     (drop
      (call $1067
       (local.get $0)
       (call $1488
        (i32.const 7)
       )
      )
     )
     (ref.null none)
    )
    (catch $eimport$0
     (if (result (ref null $909))
      (ref.test (ref $909)
       (local.tee $1
        (call $851
         (pop externref)
        )
       )
      )
      (then
       (ref.cast (ref null $909)
        (local.get $1)
       )
      )
      (else
       (call $852
        (local.get $1)
       )
       (unreachable)
      )
     )
    )
   )
   (ref.null none)
  )
  (global.get $global$10)
 )
