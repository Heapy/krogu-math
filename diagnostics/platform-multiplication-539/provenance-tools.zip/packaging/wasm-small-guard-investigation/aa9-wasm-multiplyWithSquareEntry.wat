 (func $io.heapy.krogu.math.MagnitudeMultiplication.multiplyWithSquareEntry (param $<this> (ref null $io.heapy.krogu.math.MagnitudeMultiplication)) (param $a (ref null $kotlin.IntArray)) (param $b (ref null $kotlin.IntArray)) (param $squareEntryThreshold i32) (result (ref null $kotlin.IntArray))
  (local $~tmp0 i32)
  (local $~value i32)
  (local $~tmp0_6 i32)
  (local $~value_7 i32)
  (local $message (ref null $kotlin.Any))
  (local $out (ref null $kotlin.IntArray))
  (local.set $~tmp0
   (i32.ge_s
    (local.get $squareEntryThreshold)
    (i32.const 0)
   )
  )
  (drop
   (block $block2 (result (ref null $kotlin.Unit))
    (nop)
    (local.set $~tmp0_6
     (local.tee $~value
      (local.get $~tmp0)
     )
    )
    (drop
     (block $block1 (result (ref null $kotlin.Unit))
      (nop)
      (if
       (i32.eqz
        (local.tee $~value_7
         (local.get $~tmp0_6)
        )
       )
       (then
        (local.set $message
         (block $block (result (ref null $kotlin.Any))
          (nop)
          (br $block
           (call $_stringLiteralJsString
            (i32.const 720)
            (global.get $gimport$648)
           )
          )
         )
        )
        (call $kotlin.wasm.internal.throwValue
         (call $kotlin.IllegalArgumentException.<init>_2209
          (ref.null none)
          (call_ref $_7
           (local.get $message)
           (struct.get $<classVTable> $toString
            (struct.get $kotlin.Any $vtable
             (local.get $message)
            )
           )
          )
         )
        )
        (unreachable)
       )
      )
      (br $block1
       (call $kotlin.Unit_getInstance)
      )
     )
    )
    (br $block2
     (call $kotlin.Unit_getInstance)
    )
   )
  )
  (if
   (if (result i32)
    (if (result i32)
     (i32.ge_s
      (call $kotlin.IntArray.<get-size>
       (local.get $a)
      )
      (i32.const 16)
     )
     (then
      (i32.lt_s
       (call $kotlin.IntArray.<get-size>
        (local.get $a)
       )
       (local.get $squareEntryThreshold)
      )
     )
     (else
      (i32.const 0)
     )
    )
    (then
     (ref.eq
      (local.get $a)
      (local.get $b)
     )
    )
    (else
     (i32.const 0)
    )
   )
   (then
    (local.set $out
     (call $kotlin.IntArray.<init>
      (ref.null none)
      (i32.add
       (call $kotlin.IntArray.<get-size>
        (local.get $a)
       )
       (call $kotlin.IntArray.<get-size>
        (local.get $b)
       )
      )
     )
    )
    (call $io.heapy.krogu.math.MagnitudeMultiplication.square
     (local.get $<this>)
     (local.get $a)
     (i32.const 0)
     (call $kotlin.IntArray.<get-size>
      (local.get $a)
     )
     (local.get $out)
     (i32.const 0)
    )
    (return
     (local.get $out)
    )
   )
  )
  (return
   (call $io.heapy.krogu.math.MagnitudeMultiplication.multiply$default
    (local.get $<this>)
    (local.get $a)
    (local.get $b)
    (ref.null none)
    (ref.null none)
    (i32.const 12)
    (ref.null none)
   )
  )
 )
