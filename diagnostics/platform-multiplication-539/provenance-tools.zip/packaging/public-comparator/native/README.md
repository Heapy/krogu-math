# Native actual public serial comparator — staged only

External three-file patch against3fb57160, not applied/compiled/run. Owner536 agreed the optional result-check interface. `git apply --check` succeeds on that exact frozen tree. JVM patch remains separately staged; this patch does not modify it. No worker/module/public production route is changed.

## Exact operations and timing

Adds `native-parallel/SIZE/SHAPE/public` for the exact existing five sizes256/1024/4096/8192/16384 and three shapes distinct/square/ratio2. Uses the SAME +31 generated limb arrays and all-MASK ratio2 array as current Native scheduler. Public operands and forced-school expected product are linearly packed to big-endian bytes and ordinary BigInteger(sign,bytes) OUTSIDE timing. The alias case reuses the SAME BigInteger; distinct-equal constructs a separate wide object.

Timed closure contains ONLY publicA.multiply(publicB). The existing common Any ring escapes its actual BigInteger result, with no result conversion/normalization inside wall/CPU/allocation brackets. Existing Native worker routes still charge full per-call Worker startup/joins/termination/recombination. Existing kernel/frame comparators, schedules, warmup/batch caps and reversed ordering are unchanged.

Calibration539Case gains an optional verifyLastResult callback, null by default. It runs AFTER captured wall/CPU/allocation counters and before the existing digest/heap output; only this new public case supplies one. It checks the actual last escaped product against full prepared school-product BigInteger, and both public/limb inputs against original snapshots. `ring[(count-1)&63]` is the last assignment for every positive batch count, including partial rings; no unoverwritten-slot digest is used for this result check. It is last-result observability and input preservation, NOT retained-earlier-output immutability or a full retained graph. Existing untimed verifier also checks before warming. Constructor/byte packing and equality/toByteArray checks are never part of the numeric timed closure.

The checker adds only15 public IDs. It retains exact CPU-based worker eligibility, all previous60 routes, full inventory/fork/sample/source/artifact/runtime assertions and explicit NA allocation/coarse heap scopes. No JDK benchmark or extra numerical scenario is introduced. The byte pack has <=37 live accumulator bits; buffers are exactceil(30n/8), high-endian, input limbs validated. Existing accepted public unsigned-byte constructor correctness remains the construction contract.

## Inventory and required actual rerun

On a processor-eligible host, native-parallel becomes75 cases: five sizes ×three shapes ×five variants(kernel/frame/public/worker1/worker2), seven samples and three fresh F/R/F processes =1,575 TIME rows;15 public cases add315 samples over historical1,260. On constrained hosts worker rows remain explicitly ineligible; the strict checker computes the real inventory. No worker count override.

After independent source review and completion of all live frozen series, owner applies in an authorized source window, rebuilds the actual Native RELEASE diagnostic executable, and freezes fresh source/artifact/runtime/launcher bindings. Run the WHOLE75-case native-parallel group in three NEW fresh forward/reverse/forward processes so public/kernel/frame/worker observations are same-fork. Never append15 public timings from other processes to old60 and call them paired. Preserve old60-case artifacts/raw/checks as historical source-bound prototype measurements. Final selected-policy/wrapper small guards and unfiltered correctness remain the previously mapped obligations; this patch alone is not final adoption, and it does not impose a repeat of unrelated unchanged common grids.

Existing future selector stays:

`KROGU539_ARGS=native-parallel,forward|reverse,7,20 calibration539.kexe --ktest_filter=io.heapy.krogu.math.MultiplicationCalibration539.optionalCampaign`

Use the already-reviewed `run-native-common.main.kts` with NEW artifact tree/manifest/source manifest/executable SHA/runtimeId/output (same nine arguments, mode native-parallel). Existing checker selector remains:

`check-portable-multiplication-539.main.kts 7 native-parallel Native SOURCE_SHA ARTIFACT_SHA NEW.csv fork0.log fork1.log fork2.log`

All placeholders must be actual new bindings; no executable/commands are claimed built/run. If chosen final serial policy differs from current64/16/384, compare the actual chosen artifact/policy before adoption. Any public parallel frontend added later must separately include its real materialization/dispatch/scheduling costs; private candidate versus public serial does not measure a not-yet-written public parallel route.

## Non-JVM scope boundary

This is Native only, shared optional verifier default-null elsewhere. It does NOT give JS/Wasm's narrow unpublished kernel module a public BigInteger API. JS/Wasm same-process public-root companion design remains pending; no separate-process timing is relabelled paired. No new library/backend/dependency introduced.
