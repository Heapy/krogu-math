# 539 actual public serial comparator — external JVM patch, NOT APPLIED

Source-only staged against3fb57160eb4b9f35a3ad4f241fcb067f3157c371; `git apply --check` PASS. No source/harness worktree edit, compiler/build/measurement was performed. Owner536 requested this minimal JVM same-fork interface after confirming the gap. Existing source/harness and live98636 remain untouched.

## Existing gap and scope

Existing ParallelCalibration539JvmMain measures only kernel/frame/worker1/worker2 for256/1024/4096/8192/16384 ×distinct/square/ratio2. Common public-small stops at1023bits, uses different polynomial inputs, and is not this comparator. Native uses the same large size/shape grid but no public multiply. JS/Wasm unpublished worker module compiles only the common magnitude kernel/policy, not root BigInteger, so it cannot silently stand in for a public API measurement. There is currently NO existing exact selector for this public-large operation.

This two-file patch adds `/public` to existing JVM variant loop/checker and keeps all old kernel/frame/worker variants and raw rows. The public comparator calls publicA.multiply(publicB) on prepared ordinary BigIntegers. All values come from the EXACT existing +31 deterministic base2^30 arrays; square preserves reference alias, distinct preserves separate equal objects, ratio2 preserves wide all-MASK operand. Untimed public inputs/expected are built before setup/measurement using an explicit linear unsigned-byte pack and public BigInteger(sign,bytes). The bit reservoir has at most37 live bits; byte order is high-endian and exact, with expected output checked outside counters. Existing forced-school/publicJDK checks remain; no JDK timing/workload added.

Observer return/escape type changes from IntArray to Any so native public result allocation and publication remain inside its operation, WITHOUT converting that result to words/bytes/text inside timing. All routes use the same observer/escape and warm/adaptive/sample procedure. Full result checks after each sample handle actual IntArray or BigInteger; public/array input snapshots are compared outside wall/CPU/allocation brackets. Any.hashCode/contentHashCode is outside timing. Object observability remains the existing last-result volatile escape with no timed normalization. Earlier returned results are not held and rechecked after later calls; this is NOT an output-immutability or retained-output ownership proof. Input snapshots and current full-result checks have their narrower scopes.

Output inventory becomes75 CHECK/PAR cases on fully eligible JVM:5sizes×3shapes×5variants,7samples×3freshforks=1,575PAR rows. SETUP remains30/fork(90total), PAYLOAD15/fork(45total). Exactly15 public cases are added; no unrelated scenario is added. Expected eligible subsets remain CPU-aware. Same existing launcher orders forward/reverse/forward in fresh JVMs; the added comparator is measured IN THE SAME PROCESS as worker/kernel/frame, never combined numerically with old prototype forks as if paired. Preserve old60-case1,260 data as historicalsource-era evidence, not overwrite it.

## Future invocation / outputs (not run)

After independent patch review and owner-approved quiet/source window, apply/rebuild/freeze ONLY through owner536. Pin new main/probe/stdlib and source manifest, preserving old artifacts. Existing entry selector and args stay:

`io.heapy.krogu.math.ParallelCalibration539JvmMain forward|reverse 7 MAIN.jar MAIN_SHA PROBE.jar PROBE_SHA`

Existing external run-jvm-parallel.main.kts still accepts:

`artifactTree manifestSHA sourceTSV sourceSHA java javaSHA jvm-parallel runtimeId NEW_OUTPUT`

It creates fork0/1/2 logs and provenance using F/R/F; use a NEW group name. Updated existing checker selector stays:

`check-parallel-calibration-539.main.kts 7 MAIN_SHA PROBE_SHA NEW.csv fork0.log fork1.log fork2.log`

Rows remain PAR539/CHECKPAR539/SETUP539/PAYLOAD539 and existing CSV metric columns; public IDs end `/public`. Full new source/runtime/artifact binding and independent aggregate review remain mandatory. No invented actual hashes or commands claimed executed. If final platform policy changes from64/16/384, prepare actual comparator against that accepted source/policy before interpreting ratios; this patch is not a decision to freeze current policy.

## Explicit unresolved non-JVM public comparator

Native could add a public case to its existing native-parallel common harness with the same prepared values and Any result support. JS/Wasm cannot invoke root public BigInteger from the narrow worker module without a new explicit module/library source-closure design; a root-probe public-large companion can measure identical values, but separate processes do NOT automatically satisfy frozen same-fork comparison. Owner must choose actual final public-route measurement or an independently proven equivalent public serial cost/route before adoption, as already required. This JVM patch does not claim to close those platform gaps or justify a new build/backend.

This is a minimal reviewable candidate patch, not SOURCE PASS/compiler/runtime/semantic or adoption acceptance. No source change may be made while existing jobs are live. Full selected frontend materialization/scheduling/lifecycle cost remains subject to the frozen actual-route protocol; prototype worker rows plus public comparator alone do not certify a not-yet-written public parallel frontend.
