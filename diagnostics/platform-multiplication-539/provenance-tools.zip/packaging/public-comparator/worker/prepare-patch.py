from pathlib import Path
import hashlib,difflib,json,subprocess
w=Path('.codex-work/539/worktree');r=Path('.codex-work/539/packaging/public-comparator/worker');changes=[]
def changed(p,b):
 a=(w/p).read_text() if (w/p).exists() else '';assert a!=b,p;changes.append((p,a,b))
p='src/commonTest/kotlin/io/heapy/krogu/math/MultiplicationCalibration539.kt';s=(w/p).read_text().replace('''        MultiplicationCampaign539.run(arguments)''','''        if (arguments == "worker-public-register") {
            PublicWorkerComparator539.register()
            return
        }
        MultiplicationCampaign539.run(arguments)''');changed(p,s)
p='src/commonTest/kotlin/io/heapy/krogu/math/PublicWorkerComparator539.kt'
changed(p,'''package io.heapy.krogu.math

internal expect fun registerPublic539(handler: (Int) -> Unit)
internal expect fun publicInput539(index: Int): IntArray
internal expect fun publicSame539(): Boolean
internal expect fun publicHash539(value: Int)

/** Parent-only root-library comparator. No worker-module classes/objects cross this boundary. */
internal object PublicWorkerComparator539 {
    private class Prepared(val a: BigInteger, val b: BigInteger, val expected: BigInteger,
        val originalA: ByteArray, val originalB: ByteArray)
    private var prepared: Prepared? = null
    private var escaped: BigInteger? = null
    fun register() = registerPublic539(::invoke)
    private fun invoke(mode: Int) {
        when (mode) {
            0 -> { // Preparation and host-to-root bridge copying are UNT​​IMED.
                val a = publicInput539(0); val b = publicInput539(1)
                val expected = publicInput539(2); val policy = publicInput539(3)
                require(a.size <= 65536 && b.size <= 65536 && expected.size <= 131074)
                check(policy.contentEquals(intArrayOf(MagnitudeMultiplication.KARATSUBA_THRESHOLD,
                    MagnitudeMultiplication.SQUARE_THRESHOLD, MagnitudeMultiplication.SQUARE_ENTRY_THRESHOLD))) {
                    "Public root and forced kernel policy differ; compare actual selected policy"
                }
                val x = number(a)
                val y = if (publicSame539()) { check(a.contentEquals(b)); x } else number(b)
                prepared = Prepared(x, y, number(expected), x.toByteArray(), y.toByteArray())
                escaped = null
            }
            1 -> { // Entire timed callback: actual public multiply + actual result retention.
                val values = checkNotNull(prepared)
                escaped = values.a.multiply(values.b)
            }
            2 -> { // Full latest-result and public-input checks; OUTSIDE counters.
                val values = checkNotNull(prepared)
                val result = checkNotNull(escaped)
                check(result == values.expected)
                check(values.a.toByteArray().contentEquals(values.originalA))
                check(values.b.toByteArray().contentEquals(values.originalB))
                publicHash539(result.hashCode())
            }
            3 -> { prepared = null; escaped = null }
            else -> error("Unknown public comparator mode")
        }
    }
    private fun number(words: IntArray): BigInteger {
        val bytes = ByteArray(((words.size.toLong() * 30 + 7) / 8).toInt())
        var accumulator = 0L; var bits = 0; var destination = bytes.lastIndex
        for (word in words) {
            require(word in 0..0x3fffffff)
            accumulator = accumulator or (word.toLong() shl bits)
            bits += 30 // <=37 live bits; public construction outside timing.
            while (bits >= 8) {
                bytes[destination--] = accumulator.toByte()
                accumulator = accumulator ushr 8; bits -= 8
            }
        }
        if (bits != 0) bytes[destination--] = accumulator.toByte()
        check(destination == -1)
        return BigInteger(1, bytes)
    }
}
'''.replace('UNT​​IMED','UNTIMED'))
p='src/jsTest/kotlin/io/heapy/krogu/math/Calibration539Platform.kt';s=(w/p).read_text()+'''
internal actual fun registerPublic539(handler: (Int) -> Unit) { js("globalThis.__krogu539PublicInvoke = handler") }
internal actual fun publicInput539(index: Int): IntArray =
    (js("globalThis.__krogu539PublicRequest.inputs[index]") as Any).unsafeCast<IntArray>()
internal actual fun publicSame539(): Boolean = js("globalThis.__krogu539PublicRequest.same") as Boolean
internal actual fun publicHash539(value: Int) { js("globalThis.__krogu539PublicHash = value") }
''';s=s.replace('package io.heapy.krogu.math\n','package io.heapy.krogu.math\nimport kotlin.js.unsafeCast\n');changed(p,s)
p='src/wasmJsTest/kotlin/io/heapy/krogu/math/Calibration539Platform.kt';s=(w/p).read_text()+'''
internal actual fun registerPublic539(handler: (Int) -> Unit): Unit = js("globalThis.__krogu539PublicInvoke = handler")
internal actual fun publicInput539(index: Int): IntArray =
    IntArray(publicLength539(index).also { require(it in 0..131074) }) { publicWord539(index, it) }
private fun publicLength539(side: Int): Int = js("globalThis.__krogu539PublicRequest.inputs[side].length")
private fun publicWord539(side: Int, index: Int): Int = js("globalThis.__krogu539PublicRequest.inputs[side][index]")
internal actual fun publicSame539(): Boolean = js("globalThis.__krogu539PublicRequest.same")
internal actual fun publicHash539(value: Int): Unit = js("globalThis.__krogu539PublicHash = value")
''';changed(p,s)
for platform in ['jvmTest','nativeTest']:
 p=f'src/{platform}/kotlin/io/heapy/krogu/math/Calibration539Platform.kt';s=(w/p).read_text()+'''
internal actual fun registerPublic539(handler: (Int) -> Unit): Unit = error("Node parent-only public comparator")
internal actual fun publicInput539(index: Int): IntArray = error("Node parent-only public comparator")
internal actual fun publicSame539(): Boolean = error("Node parent-only public comparator")
internal actual fun publicHash539(value: Int): Unit = error("Node parent-only public comparator")
''';changed(p,s)
patch=''
for path,a,b in changes:
 target=r/'kotlin'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(b)
 patch+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+path if a else '/dev/null',tofile='b/'+path))
(r/'kotlin-companion.patch').write_text(patch)
m={'status':'STAGED_ONLY_UNAPPLIED_UNCOMPILED_UNRUN','base':subprocess.check_output(['git','-C',str(w),'rev-parse','HEAD'],text=True).strip(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'files':[{'path':p,'before_sha256':hashlib.sha256(a.encode()).hexdigest() if a else None,'staged_sha256':hashlib.sha256(b.encode()).hexdigest()} for p,a,b in changes],'callback':'__krogu539PublicInvoke(Int)->Unit:0prepare,1multiplyretain,2verifyhash,3clear','expected_host_group':{'cases':105,'fresh_forks':3,'samples':7,'WORKER_rows':2205}}
(r/'kotlin-manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2))
