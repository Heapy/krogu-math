# Worker same-process public comparator — staged implementation

Not applied, compiled or run. Six Kotlin diagnostic files staged in kotlin/ and kotlin-companion.patch; worker536 separately owns staged host/controller/checker glue, no overlapping edits. Frozen shared3fb tree remains unchanged. No new numerical module, production code, dependency, backend or child BigInteger import.

## Concrete parent companion API

Existing root test probe is loaded ONLY in the parent Node process through its existing bounded/source-bound Mocha closure. Select exactly MultiplicationCalibration539.optionalCampaign with KROGU539_ARGS=worker-public-register; await its one successful registration test outside counters, restoring the prior argument afterward. No calibration batch runs during registration. The callback name __krogu539PublicInvoke is deliberately distinct from the tiny module's __krogu539Invoke. Child source must still import ONLY original tiny entry; capture/prove this section byte-equivalent.

Request global __krogu539PublicRequest:

- inputs[0] = exact existing parent a typed words; inputs[1] = b; inputs[2] = independent public NodeBigInt oracle product converted to base2^30 words OUTSIDE timing; inputs[3] = Int32Array([K,leaf,entry]).
- same=true iff square alias; common root preparation checks equal words and reuses the SAME BigInteger instance. distinct uses a separate ordinary wide BigInteger; ratio2 uses exact existing all-MASK input. Same+31 generator and five sizes256/1024/4096/8192/16384 throughout.

Callback opcodes (all return Unit, no cross-module numerical object):

| Opcode | Actual work | Timing |
| --- | --- | --- |
|0|Read/copy word inputs; validate bounds/limbs; check policy equals root Magnitude defaults; construct ordinary public BI operands/expected using linear unsigned byte pack; retain snapshots|Preparation only, before variants/counters|
|1|Read prepared values; call actual root public a.multiply(b); retain actual BigInteger in root module global|Whole callback INCLUDED in timed public operation; NO bytes/words/text/hash conversion|
|2|Compare actual latest result to expected, compare both input byte snapshots, compute/publish scalar __krogu539PublicHash|After captured wall/CPU counters, before raw sample memory/output|
|3|Clear retained prepared/result state|Outside samples, finally|

The parent public operation's JavaScript return can be a Unit/null sentinel because DCE escape is the retained actual BigInteger INSIDE root module, consumed by opcode2. Latest result only; no claim to retain/check every earlier output. Existing nonpublic variants continue their current typed-array escaping/checks. Public prepare/verify bridge copies are outside numeric counters; scalar callback invocation overhead remains inside the actual public route.

## Source / module isolation

Tiny private kernel executable and actual root-library probe are separately compiled instances of the SAME root production MagnitudeMultiplication/MultiplicationPolicy source paths. No library dependency is added to the tiny module and no class is copied/redeclared in either compilation; no instance or typed BI crosses their boundary. Root BigInteger references its own compiled kernel. That intentional two-instance source equivalence MUST be bound by both source/artifact manifests and exact policy check before interpreting paired results; a shared filename is not sufficient. Root production source must be the actual source claimed (and actual selected policy if later changed), not a rewritten comparator algorithm.

Bind full parent root/test/Mocha dependency closure and tiny module tree SEPARATELY, including actual entrypoint/Node/source paths. Loaded CJS realpaths must remain inside one of those explicit immutable trees; ESM/Wasm dependencies remain in the hashed closure. Preserve existing origin/SHA guards. Root load must not replace tiny callback. No global arbitrary source search, dependency downloads or foreign implementation access is needed.

## Fresh measured inventory and startup scope

With full CPU eligibility, existing90 rows-per-case inventory becomes105 (five sizes ×three shapes ×kernel/frame/public/empty/copy/worker1/worker2). Seven samples in three fresh F/R/F parent processes produce2,205 WORKER rows. Original failed90 attempt98636 (86CHECK/598WORKER,600s timeout) is historical/failed evidence, never paired with separately collected15 public rows. One coherent fresh105 campaign is required after actual probe/host/checker build+binding. The independently reviewed1200s child budget correction is a separate preserved method delta, not permission to discard adverse rows or loop retries.

Parent tiny import retains existing MODULE539 boundary. Additional root probe/Mocha import plus exact registration is reported separately, outside steady/public preparation and BEFORE pool startup. Existing STARTUP539 still clocks creation+ready of tiny-only children, including child tiny imports. Pool remains reused; final awaited teardown outside steady/startup rows. Root module code/static caches/test-registration and per-shape public prepared operands increase parent memory/context for ALL variants: disclose this, capture fresh resource metadata, and do not reuse old90 resource numbers as the new process. Public verify may allocate byte snapshots after timing, so sampled heap/RSS includes that work; exact allocation remains NA.

Remaining actual obligations: finite independent source review of Kotlin+host/checker coherent patch; owner applies only in safe source window; fresh root JS/Wasm probe builds and complete module/dependency/source binding; actual single-registration/public callback interoperability; same-process complete105 F/R/F validation, all adverse/NA/results; actual policy/public parallel frontend decision and already-mapped final guards/correctness. No task/measurement/adoption acceptance follows from this preparation.
