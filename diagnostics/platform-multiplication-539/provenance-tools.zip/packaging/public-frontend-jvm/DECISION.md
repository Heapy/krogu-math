# JVM public parallel frontend candidate — NOT ADOPTED

External patch only against07910edf6d5687f1d89dbe3369c4546f648feed2; six staged files/manifest, apply-check PASS. No frozen tree edit, build, numerical check, calibration or adoption occurred. Source/harness owner536 agreed the interface; independent contract/concurrency review527 requested. Current JS105 remains untouched. Regular multiply body is byte-unchanged. The existing scheduler receives only the narrowly reviewed accepted-child terminal-fence correction described below.

## Actual evidence used and candidate choice

Only current fresh JVM75 dataset92699 is used: independent-jvm-parallel-public-1-raw-audit.json and independent-jvm-parallel-public-lifetime-decision-support.md/.json. Historical60 forks are not mixed. Fastest serial comparator is chosen PER FORK among actual public multiply, kernel and frame. The predeclared parallel median<=0.80/everyfork<=0.90/twoadjacent rule remains the eligibility rule, not automatic adoption.

Propose TWO workers, threshold min magnitude4096 base2^30 words and balanced family max<=2min. Worker2 qualifies in reused and full-cold prototype data for4096/8192/16384 on distinct/square/ratio2. Warm1024 qualifies, but its distinct full-cold ratios1.474/2.572/1.307 and the low256 adverse cases argue against an early initial public threshold.4096 and8192 supply adjacent anchors;16384 continues the measured benefit. Threshold is a conservative candidate, not a claim that a lazy public first call costs the same as full constructor/product/shutdown/await SETUP. Actual first-call cost remains to be measured.

No exact-size whitelist:4097,6145 and other intermediate sizes follow the same bounded balanced Karatsuba family and are covered by algorithm/contract reasoning plus boundary fixtures. Ratio2 is the measured eligibility edge, not an excuse to route qualitatively different highly-unbalanced inputs. Belowthreshold or ratio>2 remains the original virtual serial multiply. Beyondlargestmeasured16384 is an ordinary range-threshold extrapolation, not a universal performance claim; actual capacity/resource premises and final-route decision remain explicit. Base/radix and regular multiply policy are not changed.

## Lifetime and resource tradeoff

Use ONE lazy ParallelCandidate539(2) per defining classloader, reusing its reviewed fixed2-worker ThreadPoolExecutor, queuecapacity2, daemon threads,30s core-thread idle timeout and shared nonblocking Semaphore2. No executor framework, per-invocation pool, shutdown hook or automatic OOM retry is added. Repeated calls can reuse real threads; first initialization/threadstartup and restart after idle timeout are real costs, not erased by reporting warm steady time. Static ownership is not a process-global limit across independent classloaders. Existing gate bounds this implementation's active extra workers, not application/unrelated threads or external OS quotas.

A cheap actual processor/ForkJoin/preinterrupted check precedes lazy access and is rechecked immediately at backendentry. The existing candidate still applies nested/permit/rejection/failure/interruption guards and joins all accepted readers before combination/fallback/return. CPU quota changes cannot be atomically controlled by a library; the recheck is best-effort entry eligibility, not global CPU governance.

The explicit API spends resources for latency:4096/distinct/worker2 steady ratios0.349/0.362/0.454 versus actualpublic all3, CPU1.000/1.036/1.304 and about98.3kB extra approximate all-thread bytes/op.16384/ratio2/worker2 ratios0.513/0.492/0.673 include CPU1.021/0.983/1.417 and approximately459kB extra allocation. These are prototype observations, not final frontend metrics. Pool peaks/RSS include runtime/reference/pre-existing heap, not exact retained size. Finalactualpublic measurements must charge wrapper/materialization/publication, first-call/lifetime/idle boundaries and resource scopes before any adoption decision.

## Public contract and concrete patch

- BigInteger.parallelMultiply first reads physical immutable wide storage only. Compact/zero/short/unbalanced cases call virtual multiply(value). Both exact ordinary class guards precede range/backend use; custom receiver overrides retain dispatch, and custom operand behavior stays on the complete prior virtual multiply path.
- For eligible ordinary wide operands, supported bit-length guard precedes worker launch/lazy initialization. Borrow wide arrays once (no compact wrappers/copies); same receiver/operand and already-shared immutable magnitude aliases remain aliases. Sign publication uses existing normalized, preserving fresh nonzero results and existing overflow semantics. Arithmetic failure/OOM propagates; no speculative serial retry.
- Non-JVM actual eligibility is false and backend null, preserving serial dispatch. No JVM threshold is adopted on other platforms.
- Existing scheduler/executor implementation is reused, with the required terminal-fence repair: It releases child frames/output slots and restores interruption after joining accepted work; rejection fallback only happens after joins, and child/caller Throwable identity is propagated. A global lazy owner does not retain invocation arrays through its default childOperation after these clear paths.

## Targeted tests staged, not run

PublicParallelFrontend539JvmTest has five methods:

1. Threshold4095/4096/4097, equal distinct/samealias and ratio2±1, all sign combinations, fullpublicJDK values, input byte preservation, freshresult/zero identities.
2. Custom receiver virtual multiply marker atzero/compact/wide; poison virtual metadata/bytes must not be probed. Truthful custom operand falls back to the old behavior.
3. Preinterrupted and ForkJoin fallback keep results/interrupt flag; concurrent actual public callers return full expected products.
4. Reflected null rejection matches regular multiply; continuous-family eligibility atintermediate4097×6145 and unbalanced decline, no exact benchmark-size whitelist.
5. Actual ThreadLocal.initialValue synthetic OOM fails BEFORE childOperation; actual remove() faults exercise restoration, including preservation of an earlier arithmetic marker. A bounded daemon caller Future must terminate, failed-prefix child operations stay atzero, other operations execute atmostonce, and another2worker call observes all3children to prove permit reuse rather than silent fallback. No actual exhaustion or later-operation-only duplicate witness.

Existing reviewed scheduler tests remain the precise deterministic rejection, permit-contention, nested and during-join interruption schedules. These new tests complement that scope, not pretend concurrent numeric results alone prove every scheduling branch. All tests and new expect/actual files are UNCOMPILED.

## Required next work, already in539 scope

Independent source review may request concrete proportional corrections. Owner applies only after frozen measurement window closes. Then actualcompile/focused contracts and a fresh source-bound publicparallel-vs-publicmultiply route campaign must measure first/warm/resource behavior including this frontend/lifetime, not inherit privateword-array75 metrics. Retain all source eras/adverse data. Final BOTH-API28smallguards, applicable selected-policy checks and unfiltered4target composition are still required. No new universal JDK parity/allsize latency gate or assumption of automatic adoption.

## Required accepted-child terminal fence correction

Independent reviewer527 found a reachable prefix OOM in existing Child.run: nested.get() preceded the old try/finally. A fresh worker may allocate its ThreadLocalMap there; failure could skip done.countDown and hold the parent join/permits forever. The candidate patch now covers get/set/operation within the catch; a contextCaptured flag becomes true only after successful get. Outermost cleanup clears frame, attempts captured-state restoration under its own catch, preserves the first Throwable without suppression allocation, and always reaches innermost latch countdown even if restoration throws. No arithmetic or context-acquisition retry occurs. The internal optional workerContext539 constructor parameter defaults to the same existing nested ThreadLocal and precedes the last childOperation function parameter, preserving existing trailing-lambda call shapes. It permits deterministic actual get/remove fault tests without a new executor framework. Regular parent arithmetic/scheduling is unchanged; final actual public performance remains required. This is a real liveness repair, not a hypothetical new all-failure theorem or adoption waiver.
