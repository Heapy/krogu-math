# Documentation staged for explicit JS/Wasm serial retention

Only this external bundle changed. Before bytes are exacta207 except BigInteger, whose prospective before bytes are the staged reviewed JS/Wasm decline overlay bound in manifest. No shared source mutation. Apply once after final source stabilization and rebind to owner's actual commit; no standalone docs-triggered performance replay.

The current public description now separates JVM/Native candidate worker routes from direct JS/Wasm virtual serial fallback and historical Node implementation/delivery/lifecycle proofs. Existing CPU/memory/failure/fallback constraints are preserved. It explicitly avoids ordinaryWasm511 recovery, current Node activation and new runtimePASS claims. FIRST public call is distinct from backend activation, which is absent under decline. KDoc remains comment-only; existing backend executable code is untouched. Entire original platform draft body remains verbatim after the historical heading. Previousa32 and2d74 staged docs/history are retained.

Exact wording review is required for this source-decision change; no numeric/source audit or new acceptance gate is requested. Final artifact/source manifest and pending runtime/correctness/guard decisions remain owner obligations.

Native serial-retention update: the coherent six-file patch is now based on aa9.
It includes the narrative-only subset; apply the coherent patch once, not both.
Only KDoc/comments change in the two Kotlin source files, with executable tokens
verified equal. Both historical document suffixes remain byte-identical.
`git apply --check` passed against the owner's aa9 worktree without mutation.
The owner will compose the independent Native flag delta and apply these docs
before final full correctness. No performance campaign is repeated just for KDoc.
The final Native large-route wins/resource costs and unresolved small-path risk
are retained together; this document does not certify final performance clearance.
