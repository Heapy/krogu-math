# Platform multiplication and parallel candidate (539)

## Current candidate dispatch — JS/Wasm serial retention

The current source decision retains historical K64/leaf16/whole-square entry384
for JS/Wasm serial multiplication and direct virtual `multiply(value)` from their
public `parallelMultiply`, before physical eligibility helpers or worker backend.
This rejects the selected production candidates; it does not claim that ordinary
Wasm511distinct was repaired or that the retained routes already passed new
runtime comparisons/guards. Historical Node measurements cannot establish final
activation or speedup for deliberately declined public routes.

JVM/Native keep synchronous public parallel candidates for large balanced
ordinary values: shorter side at least4096 base-2^30 limbs, length ratio at most2
and more than two available processors, with exact ordinary-class gates and
borrowed immutable magnitudes. Custom subclasses and declined eligibility retain
virtual multiply. Ordinary multiply does not create workers. Native physically
equal-length nonalias serial operands select K32; aliases/unbalanced cases K64,
leaf16/whole-square entry384. JVM retains64/16/384. Actual parallel children remain
explicit K64/16. No selector is an input limit or public promise of parallelism.

- **JVM:** one lazy library-owned two-worker daemon pool per defining classloader,
  queue capacity 2 and 30-second idle thread timeout. Shared nonblocking permits
  bound active helper work within that classloader. Nested calls, ForkJoinPool
  context, pre-interrupted callers and insufficient CPU fall back. Accepted tasks
  are joined on failure/interruption before references/permits are released;
  interruption is restored. First initialization/startup is distinct from reuse.
- **Native:** no retained worker pool. Each eligible call creates up to two owned
  Workers, joins every accepted result and requests/awaits termination before
  releasing its shared two-worker permit reservation. Nested/busy/CPU-limited
  calls decline before accepted work. First and repeated-call measurements both
  include Worker creation, copies, local work, joins and termination.

Arithmetic failures after accepted JVM/Native work, including allocation failure,
are not silently retried as a fresh serial product. Their existing joined failure
behavior and supported numeric range/sign/alias/input contracts remain unchanged.
Parallel resource costs must remain explicit: copies, runtime/pool state, thread
stacks, output/scratch and lifecycle costs are not inferred from latency alone.

Both retained JS/Wasm public APIs still require current-source numeric/subclass
contracts, matched final public comparisons and small guards. Their FIRST means
first public call, not first backend activation: no backend activation occurs on
the declined route. Current comparison witnesses check registry absence and empty
owned temp scope; they are not historical worker termination/cleanup proofs or
proof of measured gains. All current source/artifact/runtime and final acceptance
claims must be read from source-bound evidence; this page does not announce a
completed adoption or regression-recovery verdict.

### Historical Node candidate and consumer evidence

The implementation, worker diagnostics, raw samples, failed attempts and resource
proofs remain retained with their original source eras. Actual earlier Node24.16
independent-consumer runs demonstrated candidate packaging/two workers and natural
SHORT/IDLE retirement. Those are historical candidate proofs, not current public
activation. The following original lifecycle description remains applicable to
that retained candidate implementation, not to the final declined API route:

- **Node JS/Wasm:** production KLIB embeds a complete compiler-produced private
  worker closure, so it does not import/reexecute the consumer application or
  require manual worker-asset installation. The first eligible call decodes that
  payload into a private 0700 directory and 0600 files under the OS temporary root.
  One payload-bound generation per isolate owns at most two reusable workers;
  a busy or incompatible live generation declines instead of spawning another.
  Actual Node 24.16.0 independent-consumer delivery checks cover both targets;
  other versions are not established by that evidence. Missing real Node/builtin/
  shared-memory capabilities retain serial operation; browser execution has not
  been established. Calls synchronously block their calling thread while joining
  worker results; Node permission/filesystem denial can decline before arithmetic
  acceptance. Successful calls unref idle workers/ports and a 30-second idle timer.
  Files are removed only after owned worker termination settles. Natural process
  exit also starts bounded asynchronous retirement through `beforeExit`, with a
  cleanup-only referenced timer of at most 20seconds. Cleanup failure retains a
  broken generation and can make natural exit nonzero; arbitrary files are never
  deleted. Explicit `process.exit`, fatal exit and SIGKILL skip this natural-exit
  guarantee. They are not claimed to clean temporary files.

Node child errors cross the worker boundary as backend errors, not promises of
cross-runtime exception-object identity. Failed generations are quarantined and
asynchronously retired; no arithmetic retry is introduced. Original resource,
normal-exit and explicit/fatal/SIGKILL limitations above remain part of the
historical evidence and are not rewritten into current serial-route cleanup.

## Historical pre-execution preparation (retained verbatim)

Everything below is the original source-only preparation. Its UNRUN/serial-only
and unadopted statements refer to that earlier era, not to current acceptance.

Status: source preparation, not compiled or measured. No platform threshold or
parallel execution has been adopted. Public `parallelMultiply` still calls the
virtual `multiply` route and the accepted532 constants remain 64/16/384.

Final calibration must use the accepted537 + accepted529 + current main source
composition. Changing the representation may change small-operation cost and
materialization, so today's parent is not a valid final performance baseline.

## Prepared experiment

`MultiplicationPolicy539` separates recursive entry, square leaf and whole-square
entry. The opt-in common-test `MultiplicationCalibration539` is dormant without
an explicit configuration. Its kernel modes sweep one policy dimension around
64/16/384, with distinct operands, self squares, 1:2 and 1:4 shapes. Every forced
result is checked against independent school multiplication before warmup;
JVM additionally checks public JDK products. Inputs and policies are prepared
outside timing. Forward/reverse forks, identical 200 ms prewarming, adaptive
bounded batches and seven default samples are required. Original adverse samples
must remain available; thresholds are conservative choices, not exact optima.

`cost` measures signed Long, unsigned Long, Int carry and array allocation costs
separately. These diagnostics do not prove that another limb radix is faster.
The implementation remains common Kotlin base2^30. A radix or intrinsic/backend
change would need a separate explicit architecture proposal and end-to-end proof.

`public-small` is a paired same-harness guard on the final composed public path.
The wrapper must compare case identities, exact output representations, per-fork
ranges, allocations where observable and declared per-case regression margins.
No averaging may hide a small-case regression.

Time rows distinguish wall time, supported process CPU, caller-thread allocation
and a coarse live-heap sample. Caller allocation excludes worker allocation.
Native last-GC heap is not invocation residency; Wasm host heap is not an owned
WasmGC graph. External whole-process RSS/high-water and scoped JVM pool peaks
must be reported with their preparation/runtime overhead, not as exact scratch
size. Array ownership and arena upper bounds supply a separate logical payload
accounting. No unsupported metric is silently converted to zero.

## JVM candidate and ownership

The common top-level frame owns only sums and borrows immutable operand views.
Three child products each own distinct output and scratch. Combine runs exactly
once after all children are terminal; it mutates only the middle child. A fair
scheduling comparison uses the SAME frame serially and in parallel, alongside
the existing serial adaptive kernel, so tree/allocation differences are visible.
Memory accounting includes sums, three kept child outputs, final output, live
child arenas, scheduler objects and input views; it must not claim a memory win.

`ParallelCandidate539` is an unadopted JVM scheduler. A shared nonblocking gate
bounds additional active workers to two across instances. Parent and child
nested invocations, enclosing ForkJoinPool tasks, unavailable processor budget
and pre-interrupted callers fall back synchronously. Queue capacity is two;
workers are daemon threads with a 30-second idle timeout. Multiple experimental
instances may retain idle threads, so the gate does not bound all idle thread
objects or unrelated application load. Any adopted route would use a single
library-owned scheduler with a measured size threshold.

Executor acceptance follows `Executor.execute`: returning accepts the task;
throwing rejects it. Accepted task owner slots are preallocated and recorded
without allocation after submission. Rejection joins earlier children before
synchronous fallback. Child or caller arithmetic failures, including OOM, are
propagated without retry only after all accepted children finish. Interruption
is remembered while joining and restored before return. References and permits
are released in finally. Four source tests exercise nested/processor/interrupt
entry, partial rejection, interruption during join, global exhaustion and child
failure. Their shared global gate assumes sequential test-method execution.

JS/Wasm have no adopted worker transport; serialization/copy/startup costs and
runtime threading support must be evaluated rather than assume JVM behavior.
Native diagnostic concurrency now has a separately documented invocation-owned
Worker design, with explicit source opt-ins in nativeTest only. No production
Native opt-in, intrinsic backend or scheduling route is introduced.
An unavailable or unprofitable parallel route retains the public synchronous
fallback, but that conclusion requires target evidence and a recorded decision.

## Execution and evidence gates still required

All current source and tests are UNRUN. Final source/artifact manifests, exact
runtime/toolchain identities and fresh build logs are mandatory before any
performance claim. One numerical campaign per host; local correctness and
remote performance may overlap only under coordinator authorization.

The read-only `claws` audit found Linux x86_64 KVM, Ryzen7700X (8 cores/16 threads),
26 GiB RAM and BellSoft25.0.4+9-LTS at an explicit SDK path. User-owned0700 scratch
is `/home/kokoko/.local/share/krogu-math/perf`. Only a symlink to the existing JDK
was staged. No remote numerical work or compiler ran. Transfer only manifest
listed immutable artifacts/probes/runtime dependencies, with bounded disk use;
verify hashes remotely, clear ambient options/environment and own timeout/process
cleanup. Node/Kotlin/Native toolchain installation is not implied by this audit.

## Draft parallel observation entry

`ParallelCalibration539JvmMain` compares kernel, serial frame and one/two-worker
candidates on256/1024/4096/8192/16384 words, distinct/self/1:2 shapes. Reversed
forks reverse sizes, shapes and variants. Independent school and public JDK
checks run before observations. Every sampled result is compared in full outside
timing. A fresh executor + first product + shutdown observation is separate from
steady reused-pool samples. It is pool-start cost after oracle preparation, not
cold JVM startup. Executor termination is awaited outside the observation and
before another pool/configuration, so previous shutdown cannot leak into the
next observation. Actual processor-budget ineligibility is printed explicitly.

The JDK21+ [all-thread allocation counter](https://docs.oracle.com/en/java/javase/25/docs/api/jdk.management/com/sun/management/ThreadMXBean.html#getTotalThreadAllocatedBytes())
includes worker allocations and approximate runtime/background allocation;
values are not exact invocation-exclusive allocation. Whole-process CPU includes
GC/JIT work. Reset heap-pool peaks summed across pools are a conservative upper
bound (peaks need not coincide), not isolated scratch residency. The common
frame separately reports a conservative word-payload bound including sums,
three child outputs, final output and all three child arenas. Borrowed input
payload, object headers and scheduler/task objects are excluded from that
logical word count and must remain visible in allocation/RSS observations.

This entry binds exact kernel/policy/scheduler and probe code origins and hashes
before/after. Strict checker source is prepared; an actual owning launcher must still bind
accepted source/build provenance, JVM flags and source/artifact metadata, bounded
per-process/campaign deadlines, raw partial output and owned cleanup. It is
UNRUN and does not replace final small public guards or composed correctness.


The worker capture driver and strict three-fork checkers are now source-prepared
in scripts/measure-worker-transport-539.main.kts, check-worker-transport-539.main.kts
and check-portable-multiplication-539.main.kts. They are UNCOMPILED/UNRUN. The
portable checker requires explicit owning-launcher exit/source/artifact/runtime/
PID sidecars; it does not prove their truth independently. All scripts preserve
per-case ranges and use terminal statuses and exact inventories, not a lone PASS
line. Final matched fresh-build source manifests and actual process ownership
must be supplied by the serialized execution campaign.
