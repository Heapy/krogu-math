# Finite public parallel docs correction — unapplied

Base: df733c0cb929488ce52d25dcde6db9f06f7fc204, source405. Owner536 confirmed no concurrent documentation edits; he owns later application after the df733 source-bound campaigns finish and before final validation. This directory alone is owned by backlog_coordinator. No shared file changed, no build/runtime. `git apply --check` on the frozen worktree passes.

Concrete stale statements and minimal correction:

- `docs/platform-multiplication-539.md:3–8` currently says source preparation/uncompiled/unmeasured and public serial-only/default64. Lines53–58 call the JVM scheduler unadopted with a hypothetical future single public instance; lines70–76 deny any production Node/Native route; later UNRUN assertions are draft history. Add one current-source/lifecycle section, then explicitly mark the entire original draft historical and retain its bytes. No final adoption or gain is asserted.
- `src/jvmMain/.../ParallelCandidate539.kt:15–16` says public route is unchanged. Correct only that KDoc: the same scheduler now backs the lazy public instance. Public method body, signatures and every executable statement remain identical.
- `src/commonMain/.../BigInteger.kt:181–195` has no public method KDoc despite nontrivial platform resources. Add a concise exact/synchronous/fallback/resource KDoc without promising parallel execution or performance.
- `README.md:401–405` gives only synchronous result and a broad old simple-algorithm description. Replace that paragraph with current adaptive/public platform behavior and a link to existing platform documentation; resource and final-acceptance limits are explicit.
- `docs/integer-multiplication.md:3–13` is accepted historical task532 evidence, but “no parallel executor” reads as current. Qualify it as task532 and link the current platform source status. All old numerical tables/claims remain unchanged.

Historical proof ledgers `docs/integer-arithmetic-544-proof.md:4–10,87–89` and `docs/integer-public-contract-549-ledger.md:3–11,59` already bind old source/snapshot explicitly. Do not rewrite their old delegating implementation as new evidence; they remain historical. Other audit/verifier reports and patch snapshots are untouched.

Source support for the added text (paths relative to worktree):

| Claim | Exact source/evidence |
|---|---|
| exact ordinary class gates, physical wide/shape checks before backend, borrowed magnitude once, virtual fallback, normalized signed result | `src/commonMain/.../BigInteger.kt:181–195` |
| current min4096/ratio<=2/CPU>2; JVM FJP/preinterrupt fallback | `src/jvmMain/.../ParallelMultiply539.kt:6–11,23–28`; `src/nonJvmMain/.../ParallelMultiply539.kt:3–6` |
| one JVM lazy instance per classloader; queue2/daemon/30s idle; accepted joins/interruption handling | `src/jvmMain/.../ParallelMultiply539.kt:14–20`; `ParallelCandidate539.kt:118–140,152–163` |
| Node original-source embedded worker payload, capability guard, one isolate generation, private0700/0600 files, bounded identity | `src/jsMain/.../NodeParallel539.kt:24–50,108–138`; same reviewed transport in Wasm actual |
| idle unref/30s; beforeExit retirement20s; files only after worker terminal; broken generation retained on failed cleanup | `NodeParallel539.kt:59–109,199–208`; independent natural-exit lifecycle and four-run consumer delivery audit |
| Node join blocks caller, no arithmetic retry, async quarantine; backend error rather than child exception-object identity | `NodeParallel539.kt:171–208`; `src/nonJvmMain/.../ParallelMultiply539.kt:13–42` |
| Native invocation-owned2 workers, global permits/nested/CPU, all accepted joins and termination before release, no pool | `src/nativeMain/.../NativeParallelMultiply539.kt:3–11`; `NativeParallelEngine539.kt:12–17,42–62,105–135` |
| JS/Native physically equal-length nonalias K32, other K64; JS entry128/Native384; explicit parallel child64 | `src/commonMain/.../MagnitudeMultiplication.kt:17–31`; `src/nonJvmMain/.../ParallelMultiply539.kt:16`; `NativeParallelMultiply539.kt:10–11` |
| actual Node24.16 consumer delivery, not performance/adoption | `.codex-work/539/independent-node-consumer-delivery-1-actual-audit.json` (four terminal runs; SHORT/IDLE each target) |

Application/revalidation: owner applies after the live source freeze ends, reviews exact diff and refreshes documentation/source manifests. The two production-source hunks are comments only, with explicit byte-preservation checks for every old executable statement; there is no public signature/ABI change. Do not relabel previously compiled artifacts as if they compiled new comments. Preserve measured-era sources and record this documentation-only delta in final source/artifact provenance. No extra timing run is requested solely for comments; existing final validation obligations remain unchanged.
