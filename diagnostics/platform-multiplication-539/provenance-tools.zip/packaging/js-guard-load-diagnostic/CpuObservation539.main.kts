// Imported source only. No numerical implementation or foreign process arguments.
import java.io.File
import java.io.PrintWriter
import java.lang.management.ManagementFactory
import java.math.BigDecimal
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

class CpuObservation539(private val output: File) : AutoCloseable {
    data class Context(val phase: String, val fork: Int = -1, val label: String = "none", val pid: Long = -1)
    data class ProcessRow(val pid: Long, val ppid: Long, val start: String, val cpu: Long, val state: String)
    data class Sample(val id: Int, val start: Long, val intervalStart: Long, val end: Long, val externalCores: Double?, val hostLoad: Double?, val counterComplete: Boolean)
    private val context = AtomicReference(Context("STARTING"))
    private val failure = AtomicReference<Throwable?>(null)
    private val ownPid = ProcessHandle.current().pid()
    private val ownStart = ProcessHandle.current().info().startInstant().orElseThrow().truncatedTo(java.time.temporal.ChronoUnit.SECONDS).toString()
    private val os = ManagementFactory.getOperatingSystemMXBean() as com.sun.management.OperatingSystemMXBean
    private val samples = mutableListOf<Sample>()
    private val processFile = File(output, "cpu-processes.tsv")
    private val sampleFile = File(output, "cpu-samples.tsv")
    private val eventFile = File(output, "cpu-events.tsv")
    private val processes: PrintWriter = processFile.printWriter()
    private val summary: PrintWriter = sampleFile.printWriter()
    private val events: PrintWriter = eventFile.printWriter()
    @Volatile private var stopping = false
    @Volatile private var closed = false
    private val worker = Thread({ loop() }, "539-readonly-cpu-observer").also { it.isDaemon = true }

    init {
        require(System.getProperty("os.name").contains("Mac", ignoreCase = true))
        processes.println("sample\twall_utc\tmono_start_ns\tmono_end_ns\tpid\tppid\tstart_utc_seconds\tcpu_total_ns\towned_ancestry\tstate")
        summary.println("sample\twall_utc\tmono_start_ns\tmono_end_ns\tinterval_start_ns\tinterval_ns\tphase_before\tphase_after\tfork_before\tlabel_before\troot_pid_before\tprocess_count\tmatched_count\tnew_or_reset_count\tended_count\texternal_unmatched_count\treset_count\tcounter_complete\tobserved_external_cpu_ns\tobserved_owned_cpu_ns\tobserved_external_cores\thost_cpu_fraction\tload_average")
        events.println("wall_utc\tmono_ns\tevent\tphase\tfork\tlabel\troot_pid\tdetail")
        flushChecked()
    }
    fun start() { worker.start(); mark("OBSERVER_START", Context("PREFLIGHT"), "controller_pid=$ownPid;controller_start_utc_seconds=$ownStart") }
    @Synchronized fun mark(event: String, next: Context, detail: String = "") {
        require(listOf(event,next.phase,next.label,detail).none { '\n' in it || '\r' in it || '\t' in it })
        context.set(next)
        events.println("${Instant.now()}\t${System.nanoTime()}\t$event\t${next.phase}\t${next.fork}\t${next.label}\t${next.pid}\t$detail")
        events.flush(); check(!events.checkError()) { "CPU event writer failed" }
    }
    fun healthy() { failure.get()?.let { throw IllegalStateException("CPU observation failed", it) } }
    private fun flushChecked() {
        for (writer in listOf(processes,summary,events)) { writer.flush(); check(!writer.checkError()) { "CPU observation output failed" } }
        check(processFile.length() <= 128L*1024*1024 && sampleFile.length() <= 4L*1024*1024 && eventFile.length() <= 1024L*1024) { "CPU observation output bound" }
    }
    private fun cpuNs(value: String): Long {
        val split = value.split('-'); require(split.size in 1..2)
        val daySeconds = if(split.size == 2) split[0].toLong()*86400L else 0L
        val fields = split.last().split(':'); require(fields.size in 2..3)
        val seconds = BigDecimal(fields.last()) + BigDecimal(fields[fields.lastIndex-1]).multiply(BigDecimal(60)) +
            if(fields.size == 3) BigDecimal(fields[0]).multiply(BigDecimal(3600)) else BigDecimal.ZERO
        return (seconds + BigDecimal(daySeconds)).multiply(BigDecimal(1000000000)).longValueExact().also { require(it >= 0) }
    }
    private fun snapshot(id: Int): List<ProcessRow> {
        // Only scalar scheduler metadata. No comm/command/argv/environment fields.
        val file = File.createTempFile("cpu-ps-$id-", ".tmp", output)
        var child: Process? = null
        var success = false
        try {
            val builder = ProcessBuilder("/bin/ps", "-axo", "pid=,ppid=,time=,lstart=,stat=").redirectErrorStream(true).redirectOutput(file)
            builder.environment().clear(); builder.environment().putAll(mapOf("LANG" to "C", "LC_ALL" to "C", "TZ" to "UTC"))
            child = builder.start()
            check(child.waitFor(2, TimeUnit.SECONDS)) { "CPU snapshot deadline" }
            check(child.exitValue() == 0 && file.length() in 1..4L*1024*1024) { "CPU snapshot failed or too large" }
            val format = DateTimeFormatter.ofPattern("EEE MMM d HH:mm:ss yyyy", Locale.US)
            val result = file.readLines().map { line ->
                val f = line.trim().split(Regex("\\s+")); require(f.size == 9) { "Unexpected scalar ps schema" }
                val stamp = LocalDateTime.parse(f.subList(3,8).joinToString(" "), format).toInstant(ZoneOffset.UTC).toString()
                ProcessRow(f[0].toLong(),f[1].toLong(),stamp,cpuNs(f[2]),f[8]).also { require(it.pid >= 0 && it.ppid >= 0) }
            }
            require(result.isNotEmpty() && result.size <= 32768 && result.map { it.pid }.distinct().size == result.size)
            success = true
            return result
        } finally {
            if(child?.isAlive == true) { child.destroyForcibly(); check(child.waitFor(2,TimeUnit.SECONDS)) { "Owned ps cleanup failed" } }
            if(success) check(file.delete()) { "Owned snapshot temp cleanup failed" }
        }
    }
    private fun loop() {
        var previous = emptyMap<Pair<Long,String>,ProcessRow>()
        var previousEnd = 0L
        var previousOwned = emptySet<Pair<Long,String>>()
        var id = 0
        try {
            while(!stopping) {
                val start = System.nanoTime(); val before = context.get()
                val rows = snapshot(id); val end = System.nanoTime(); val after = context.get(); val wall = Instant.now()
                check(rows.singleOrNull { it.pid == ownPid }?.start == ownStart) { "Controller PID/start identity unavailable" }
                val owned = mutableSetOf(ownPid)
                while(true) { val count=owned.size; rows.filter { it.pid != ownPid && it.ppid in owned }.forEach { owned.add(it.pid) }; if(count == owned.size) break }
                val current = rows.associateBy { it.pid to it.start }
                var external = 0L; var own = 0L; var matched = 0; var fresh = 0; var externalUnmatched = 0; var reset = 0
                for(row in rows) {
                    val old = previous[row.pid to row.start]
                    if(old != null && row.cpu >= old.cpu) {
                        val delta = row.cpu-old.cpu; if(row.pid in owned) own += delta else external += delta; matched++
                    } else { fresh++; if(old != null && row.cpu < old.cpu) reset++; if(row.pid !in owned) externalUnmatched++ }
                    processes.println("$id\t$wall\t$start\t$end\t${row.pid}\t${row.ppid}\t${row.start}\t${row.cpu}\t${row.pid in owned}\t${row.state}")
                }
                val interval = if(previousEnd == 0L) 0L else end-previousEnd
                val externalCores = if(interval > 0) external.toDouble()/interval else null
                val host = os.cpuLoad.takeIf { it.isFinite() && it in 0.0..1.0 }
                val ended = previous.keys.filter { it !in current }
                externalUnmatched += ended.count { it !in previousOwned }
                val counterComplete = previousEnd != 0L && externalUnmatched == 0 && reset == 0
                val sample = Sample(id,start,previousEnd,end,externalCores,host,counterComplete)
                summary.println(listOf(id,wall,start,end,previousEnd,interval,before.phase,after.phase,before.fork,before.label,before.pid,rows.size,matched,fresh,ended.size,externalUnmatched,reset,counterComplete,external,own,externalCores ?: "NA",host ?: "NA",os.systemLoadAverage).joinToString("\t"))
                synchronized(samples) { samples.add(sample) }
                flushChecked()
                if(previousEnd != 0L) check(interval <= TimeUnit.SECONDS.toNanos(5)) { "CPU observation gap above5seconds" }
                previous = current; previousOwned = rows.filter { it.pid in owned }.map { it.pid to it.start }.toSet(); previousEnd = end; id++
                val left = TimeUnit.SECONDS.toNanos(1)-(System.nanoTime()-start)
                if(left > 0) TimeUnit.NANOSECONDS.sleep(left)
            }
        } catch(error: Throwable) { if(!stopping) failure.compareAndSet(null,error) }
    }
    fun admit(): Boolean {
        val start = System.nanoTime(); mark("ADMISSION_START",Context("ADMISSION"),"one15second_observation_with20second_deadline")
        val deadline = start + TimeUnit.SECONDS.toNanos(20)
        try {
            while(System.nanoTime() < deadline) {
                healthy()
                val available = synchronized(samples) { samples.filter { it.intervalStart >= start } }
                if(available.size >= 15 && available.last().end-available.first().intervalStart >= TimeUnit.SECONDS.toNanos(15)) {
                    val observed = available.toList()
                    val determinate = observed.all { it.counterComplete && it.externalCores != null && it.hostLoad != null }
                    val admitted = determinate && observed.all { it.externalCores!! <= 0.50 && it.hostLoad!! <= 0.20 }
                    mark(if(admitted) "ADMITTED" else if(determinate) "UNSUITABLE_NO_NUMERIC_RUN" else "INDETERMINATE_NO_NUMERIC_RUN",Context("ADMISSION_COMPLETE"),
                        "samples=${observed.first().id}..${observed.last().id};interval_start_ns=${observed.first().intervalStart};interval_end_ns=${observed.last().end};external_core_bound=0.50;host_fraction_bound=0.20")
                    return admitted
                }
                Thread.sleep(25)
            }
            mark("INDETERMINATE_NO_NUMERIC_RUN",Context("ADMISSION_COMPLETE"),"bounded_observation_deadline")
            return false
        } catch(error: Throwable) {
            try { mark("INDETERMINATE_NO_NUMERIC_RUN",Context("ADMISSION_FAILED"),"observer_or_tool_failure") } catch(markFailure: Throwable) { error.addSuppressed(markFailure) }
            throw error
        }
    }
    fun finishAndClose() {
        val boundary=System.nanoTime(); mark("OBSERVATION_END_REQUEST",Context("FINISHING"))
        val until=boundary+TimeUnit.SECONDS.toNanos(4)
        while(synchronized(samples) { samples.lastOrNull()?.end ?: 0L } < boundary && System.nanoTime()<until) { healthy(); Thread.sleep(25) }
        check(synchronized(samples) { samples.lastOrNull()?.end ?: 0L } >= boundary) { "No final CPU sample beyond child window" }
        close(); healthy()
    }
    override fun close() {
        if(closed)return
        stopping=true
        var interrupted=Thread.interrupted()
        var closeFailure: Throwable? = null
        fun record(error: Throwable) {
            if(closeFailure == null) closeFailure=error else closeFailure!!.addSuppressed(error)
        }
        try {
            val deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(5)
            while(worker.isAlive && System.nanoTime()<deadline) {
                try { worker.join(maxOf(1L,TimeUnit.NANOSECONDS.toMillis(deadline-System.nanoTime()))) }
                catch (_: InterruptedException) { interrupted=true }
                catch (error: Throwable) { record(error); break }
            }
            if(worker.isAlive) record(IllegalStateException("CPU observer did not stop"))
            for(writer in listOf(processes,summary,events)) {
                try { writer.flush(); check(!writer.checkError()) { "CPU writer flush failed" } }
                catch(error: Throwable) { record(error) }
                finally {
                    try { writer.close(); check(!writer.checkError()) { "CPU writer close failed" } }
                    catch(error: Throwable) { record(error) }
                }
            }
            closed=true
            closeFailure?.let { throw it }
        } finally {
            if(interrupted) Thread.currentThread().interrupt()
        }
    }
}
