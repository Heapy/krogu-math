# Fused JS adaptive basecases — external source candidate

Exact basecd231a59. One production file changed. Removing the new private helper and reversing the one adaptive-entry replacement reconstructs the entire previous file byte-for-byte. The old8a3f/cd231 artifacts and raw guard results are retained; this patch does not reclassify them.

## Equivalence partition

- JS aliases16..127: current selected whole-square entry128 selects square immediately. New helper uses the same size/alias predicates, same exact output allocation, square arguments and return. This includes16/31/32/63/64/127 boundaries.
- JS aliases below16: new whole-square check rejects; min<32 school uses the same output size and original school arguments. Zero-length arrays also remain school with identical output extent.
- JS aliases128+: first check rejects; min>=32 and alias selectK64. min<threshold cannot hold (128>=64); original scratchWords/Arena/product with leaf16 are used. No new small alias square rule is introduced.
- JS physical nonaliases with min<32, including unequal lengths and either operand order: new first whole-square condition can never pass; new school branch uses existing output extent and original full borrowed views. Current K32 orK64 both choose school below32, so all products/output lengths/input preservation remain identical.
- JS equal-length physical nonaliases32+: first check rejects; threshold32; original Arena/scratchWords/product and leaf16 are used.
- JS unequal lengths with min32..63: threshold64 and school, as current. Unequal min64+ uses existing K64 Arena/product, including its unchanged blocked unbalanced route.
- Non-JS: useJs policy flag is false, so the new private helper is not reached; all remaining adaptive statements and all original functions are byte-identical. Source scope alone does not prove compiler artifact identity.

The JS adaptive entry now directly calls one helper, without the extra top-level a.length<32 predicate observed in response4b0414cf. The helper places selected alias/equal-length work AFTER the whole-square and small-school basecases. Its32 comparison replaces the existing school/basecase comparison for tiny values rather than adding another check before the historical helper. It duplicates only a dispatch shell and calls original school/square/product code; no policy allocation or new arithmetic solver exists. JS entry128 is the already-accepted selected policy, not a newly calibrated threshold.

All forced/configured methods and the scalar school-row kernel remain exact. No BigInteger entry/backend/magnitude materialization/sign/subtype/error/worker/resource contract changes. Existing small boundary test covers1/15/16/31/32/33, alias/nonalias/unbalanced bothroles and existing platform oracle; selectedProducts/public sign tests cover127/128/129/383/384 and immutability. No mirror test or new runtime gate is added.

This eliminates one concrete emitted-source layout difference in tiny ordinary paths but is NOT proof of V8 code generation/inlining or measured causality/recovery. Preserve all old per-fork adverse cells. Compile/source review and the existing affected current guard, not a full grid or threshold search, establish its eventual disposition.
