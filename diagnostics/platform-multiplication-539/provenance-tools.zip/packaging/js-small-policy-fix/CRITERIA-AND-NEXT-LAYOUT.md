# Frozen small guard interpretation and finite next JS layout

This is a proposal only, not a staged production patch or performance result. Shared source/campaigns remain untouched. Existing8a3f patch and its review remain historical; response4b0414cf does not isolate patch causality.

## Exact criteria, unchanged

Fresh tracker local539 body, retained in `criteria-tracker539-snapshot.json`:

> Приёмка: воспроизводимые измерения по платформам, решение о порогах, CPU/latency/peak-memory tradeoffs и отсутствие регрессии маленьких задач.

Frozen `.codex-work/539/independent-preflight-adoption-protocol.json`, `small_guard.flag`:

> median(candidate_ns_i/baseline_ns_i)>1.15 AND median(candidate_ns_i-baseline_ns_i)>5ns

The same artifact, `small_guard.meaning`, verbatim:

> Material-regression investigation trigger, not a universal parity theorem. Preserve every fork/range/allocation row; isolated adverse pairs are disclosed, repeated evidence examined. No averaging across cases/APIs. No unresolved credible material small-path regression in an adopted final route. No rerun solely to improve appearance.

The numeric flag is therefore an investigation trigger, not an explicit requirement for zero flagged rows. It requires a per-case evidence-based disposition; disclosure alone does not establish absence of regression. A credible material small-path regression cannot remain unresolved in an adopted route. Fixing/rejecting the affected implementation or demonstrating why the particular detector result is not an established material regression are possible dispositions; blanket noisy-host assertions, averaging cases or rerunning for attractive flags are not. This interpretation is unchanged by current results and adds no gate.

## Reachable source difference and bounded layout proposal

Actual response `independent-js-small-guard3-response.json` records persistent ordinary64distinct and127square flags and shows current tiny JS entry has an extra `a.length<32` check before the old helper. That is a concrete emitted path difference, not proof that it causes the full latency delta or any observed V8 optimization decision. Active35-word K32 public1023distinct is a separate contrast.

Proposed minimal scope: change only JS adaptive entry into a private fused historical-basecase dispatcher. JVM/Wasm/Native keep the existing branch body; forced `multiply`, `multiplyWithSquareEntry`, configured calibration routes and worker kernels remain exact. No public BigInteger/JVM entry/backend or field changes.

The JS `multiplyAdaptive` entry would make one direct call to this private dispatcher, just as the historical JS entry made one direct call to its historical helper; there is no new top-level tiny length predicate. Use the existing selected-policy boundary32, not a newly tuned threshold. Pseudocode (private method of the existing object):

```kotlin
private fun multiplyAdaptiveJs539(a: IntArray, b: IntArray): IntArray {
    // The historical whole-square checks come first; JS's already-selected entry is128.
    if (a.size >= SQUARE_THRESHOLD && a.size < 128 && a === b) {
        val out = IntArray(a.size + b.size)
        square(a, 0, a.size, out, 0)
        return out
    }
    val out = IntArray(a.size + b.size)
    val small = minOf(a.size, b.size)
    // Reuse the existing multiply school/basecase comparison before any selected work.
    if (small < 32) {
        school(a, 0, a.size, b, 0, b.size, out, 0)
        return out
    }
    // Only inputs that escape those historical basecases pay selected-policy work.
    val threshold = if (a !== b && a.size == b.size) 32 else KARATSUBA_THRESHOLD
    if (small < threshold) {
        school(a, 0, a.size, b, 0, b.size, out, 0)
    } else {
        val arena = Arena(scratchWords(a.size, b.size, threshold))
        product(a, 0, a.size, b, 0, b.size, out, 0, arena, threshold, SQUARE_THRESHOLD)
    }
    return out
}
```

For3/5-word tiny nonaliases the existing whole-square first check rejects at16, then the existing multiply basecase comparison (now using the already-supported lower32 boundary) selects school; no selected alias/equal-length predicate is evaluated. Physical aliases16..127 return from whole square first. Below16 aliases use school. Equal distinct32+ reaches existing K32 recursion; unequal min32..63 stays school/K64; unequal min64+ and aliases128+ retain K64/product/leaf16, with the existing blocking ratio behavior inside product. Output allocation and original school/square/product bodies are reused. Forced/configured paths are not redirected into this dispatcher. No policy object allocation is added.

This duplicates only a small JS dispatch shell, not an arithmetic kernel; a private helper is needed to avoid adding mode checks to forced/configured routes. It removes the specifically identified extra tiny entry guard and moves selected work after basecases, but does not promise literal baseline byte equality, no V8 inlining/layout change, or speed recovery. Tiny whole-entry direct call shape, static branch/body structure and selected32/alias/128 boundaries must be reviewed on an actual patch before application; actual existing affected verification remains source-bound. No new finite-grid replay, threshold search or acceptance criterion is requested here.
