# JS small-policy dispatch — external, unapplied

Base: `2d74b6467c449084d6c528cc26398c2ac93b0a3b`. No shared source, build or measurement changed. Existing policy flags are compile-time constants: JS true; JVM/Wasm/Native false. This is a source-scoped claim, not proof of emitted code identity.

The inserted branch executes before selected alias/length/policy helpers only when the JS flag is true and either physical input length is below 32. It calls the exact existing historical entry384 helper. It creates no policy object and changes no fields, public API, worker backend, range checks or arithmetic implementation.

| Input family below the new boundary | Existing selected route | Historical early route | Why same kernel |
|---|---|---|---|
| distinct equal lengths <32 | K32/leaf16 | K64/leaf16, entry384 | both shorter than Karatsuba threshold; school |
| physical alias <16 | ordinary K64 | historical K64/entry384 | both school |
| physical alias 16..31 | whole square, JS entry128 | whole square, entry384 | both entries above actual size; same square leaf16 |
| unequal lengths, either side <32 | K64/leaf16 | K64/leaf16, entry384 | physicalalias impossible; same school path even with long other input |
| both lengths >=32 | original body | original body | inserted condition false; selected32/entry128/unbalanced logic unchanged |

All original production bytes after the inserted branch remain exact. BigInteger thin wrapper and JVM scheduler/backend are not in this patch. The added small common test checks 1/15/16/31/32/33, alias versus distinct equal and unequal lengths, both operand roles, full-school product/existing untimed platform oracle and immutable borrowed inputs. The exact32/33 cases protect the non-bypassed boundary.

Reported ordinary and parallel small-guard flags motivated the branch; source reachability and redundant dispatch are concrete, but emitted-code recovery and performance causality remain unproven until owner executes the already-required affected verification. This does not request a new performance gate or full finite-grid replay. Preserve original flagged raw and source eras.
