// Untimed task-owned Mocha selector/identity wrapper; numerical code stays in the built Kotlin probe.
const fs = require('node:fs');
const path = require('node:path');
const {pathToFileURL} = require('node:url');
const {performance} = require('node:perf_hooks');
(async () => {
  const [rootArg, entryArg, mochaArg, kind, payloadIdentity] = process.argv.slice(2);
  if(process.argv.length!==7 || !['JS','Wasm'].includes(kind) || process.version!=='v24.16.0' || !/^[a-f0-9]{64}$/.test(payloadIdentity)) throw Error('pinned args/runtime');
  const root=fs.realpathSync(rootArg);
  const self=fs.realpathSync(__filename);
  const os=require('node:os');
  console.log('# HOSTCONTEXT539 '+JSON.stringify({platform:process.platform,arch:process.arch,release:os.release(),cpus:os.availableParallelism(),totalmem:os.totalmem(),freemem:os.freemem(),loadavg:os.loadavg(),cwd:process.cwd()}));
  const entry=fs.realpathSync(entryArg), mochaPath=fs.realpathSync(mochaArg);
  for(const file of [entry,mochaPath]) if(!file.startsWith(root+path.sep)) throw Error('Input outside owned artifact tree');
  function verifyCache(phase) {
    let count=0;
    for(const filename of Object.keys(require.cache)) {
      const real=fs.realpathSync(filename);
      if(real!==self && !real.startsWith(root+path.sep)) throw Error('Loaded CommonJS file outside immutable tree: '+real);
      count++;
    }
    console.log('# CACHEORIGIN539 phase='+phase+' files='+count+' owned=true');
  }
  console.log('# OWN539 pid='+process.pid+' start_epoch_ms='+Math.trunc(performance.timeOrigin)+' node='+process.version+' kind='+kind+' flags='+JSON.stringify(process.execArgv));
  console.log('# ORIGIN539 entry='+entry+' mocha='+mochaPath);
  const Mocha=require(mochaPath);
  const mocha=new Mocha({ui:'bdd',reporter:'dot',timeout:0,grep:/NodePublicFrontendCalibration539.*optionalPublicRoute/});
  mocha.addFile(entry);
  await mocha.loadFilesAsync();
  if(kind==='Wasm') {
    const wasm=await import(pathToFileURL(entry).href);
    if(typeof wasm.startUnitTests!=='function') throw Error('Missing generated Wasm startUnitTests export');
    if(globalThis.kotlinTest===undefined) globalThis.kotlinTest={adapterTransformer:adapter=>adapter};
    wasm.startUnitTests();
  }
  verifyCache('before-run');
  const selected=[];
  mocha.suite.eachTest(test=>{if(/NodePublicFrontendCalibration539.*optionalPublicRoute/.test(test.fullTitle()))selected.push(test.fullTitle());});
  if(selected.length!==1) throw Error('Expected exactly one optionalPublicRoute');
  mocha.suite.eachTest(test=>{ if(/NodePublicFrontendCalibration539.*optionalPublicRoute/.test(test.fullTitle())) {
    for(let suite=test.parent;suite;suite=suite.parent) for(const key of ['_beforeAll','_beforeEach','_afterAll','_afterEach'])
      if(!Array.isArray(suite[key]) || suite[key].length!==0) throw Error('Unexpected selected-suite hook '+key);
  }});
  console.log('# REGISTERED539 selected='+selected.length+' name='+JSON.stringify(selected[0]));
  if(process[Symbol.for('io.heapy.krogu.node-parallel-539.v1')]!==undefined) throw Error('Production backend already initialized before FIRST');
  console.log('# PUBLICBACKEND_BEFORE539 absent=true');
  const key=Symbol.for('io.heapy.krogu.node-parallel-539.v1');
  const profile=/^node-public-serial-retention,(256|1024|4096|8192|16384),(distinct|square|ratio2),(forward|reverse)$/.exec(process.env.KROGU539_ARGS||'');
  if(!profile) throw Error('Exact serial-retention profile required');
  const point=profile[1]+'/'+profile[2];
  const tempRoot=fs.realpathSync(process.env.KROGU539_TEMP_ROOT||'');
  if(fs.lstatSync(process.env.KROGU539_TEMP_ROOT).isSymbolicLink() || fs.realpathSync(os.tmpdir())!==tempRoot || fs.readdirSync(tempRoot).length!==0) throw Error('Owned empty temp scope required');
  const rawWrite=process.stdout.write;
  const emit=line=>Reflect.apply(rawWrite,process.stdout,[line+'\n']);
  let firstSeen=false,nextSample=0,lastCount=null,absenceVerified=false;
  function verifyAbsence(phase) {
    const owner=process[key], files=fs.readdirSync(tempRoot);
    if(owner!==undefined || files.length!==0) {
      emit('# PUBLICSERIAL_FAILURE539 '+JSON.stringify({point,phase,ownerPresent:owner!==undefined,state:owner&&owner.state,sequence:owner&&owner.sequence,files}));
      throw Error('Declined public route created owner or temp resources');
    }
  }
  verifyAbsence('before-first');
  emit('# DECLINE_TEMP539 root='+tempRoot+' empty=true');
  function observeLine(line) {
    if(line.startsWith('FIRSTNODE539,')) {
      const c=line.split(',');if(c.length!==4 || c[1]!==point || firstSeen)throw Error('FIRST witness inventory');
      verifyAbsence('first');
      emit(['PUBLICSERIALDECLINE539',point,'first',-1,1,kind,true,true].join(','));firstSeen=true;
    } else if(line.startsWith('PUBLICNODE539,')) {
      const c=line.split(',');if(c.length!==9 || !c[1].startsWith(point+'/'))throw Error('Warm witness point');
      if(c[1]===point+'/parallel') {
        const sample=Number(c[2]),count=Number(c[3]);
        if(!firstSeen || sample!==nextSample || sample>6 || !Number.isSafeInteger(count) || count<1 || count>8388608 || (count&(count-1))!==0 || (lastCount!==null && count!==lastCount))throw Error('Parallel witness sample/count');
        verifyAbsence('parallel-'+sample);
        emit(['PUBLICSERIALDECLINE539',point,'parallel',sample,count,kind,true,true].join(','));lastCount=count;nextSample++;
      }
    }
  }
  let fragment='';
  process.stdout.write=function(chunk,encoding,callback) {
    const accepted=Reflect.apply(rawWrite,this,arguments);
    try {
      fragment+=typeof chunk==='string'?chunk:Buffer.from(chunk).toString(typeof encoding==='string'?encoding:'utf8');
      if(fragment.length>65536)throw Error('Bounded stdout witness line exceeded');
      let newline;
      while((newline=fragment.indexOf('\n'))>=0) {
        const line=fragment.slice(0,newline).replace(/\r$/,'');fragment=fragment.slice(newline+1);observeLine(line);
      }
    } catch(error) {process.exitCode=3;throw error;}
    return accepted;
  };
  const runner=mocha.run((failures)=> {
    process.stdout.write=rawWrite;
    const stats=runner.stats;
    console.log('# SELECTED539 tests='+stats.tests+' passes='+stats.passes+' failures='+stats.failures+' pending='+stats.pending);
    try {
      verifyCache('after-run');
      if(failures!==0 || stats.tests!==1 || stats.passes!==1 || stats.failures!==0 || stats.pending!==0 || !firstSeen || nextSample!==7)throw Error('Exact test/decline witness completion missing');
      verifyAbsence('after-run');absenceVerified=true;
      emit('# PUBLICSERIAL_POST539 point='+point+' registry_absent=true temp_empty=true');
      emit('PUBLICSERIALRESOURCE539,'+point+',NONE_STARTED,true,true');
      console.log('# RESOURCE539 '+JSON.stringify({cpu:process.cpuUsage(),memory:process.memoryUsage(),resource:process.resourceUsage()}));
    } catch(error) {process.exitCode=3;console.error(error.stack||String(error));}
  });
  process.once('exit',()=>{
    if(!absenceVerified || process[key]!==undefined || fs.readdirSync(tempRoot).length!==0) {
      process.exitCode=3;
      try {fs.writeSync(2,'Missing serial-decline absence witness\n');}catch(_){}
    }
  });
})().catch(error=>{ console.error(error.stack||String(error)); process.exitCode=3; });
