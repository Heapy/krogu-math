# Final Node JS/Wasm public serial-retention comparison

External staged method only, UNCOMPILED/UNRUN for the declined source. Owner536 owns shared application, immutable artifact assembly, build/run and final reports. Source patch and common fixture are in sibling `js-serial-retention`. Exact active host/checker/launcher/README/manifest are retained under `history/active-before-js-wasm-decline`; their raw1470JS/1260Wasm activation campaigns keep original source/method identities and are not relabelled final retention.

## Future exact invocation and artifact binding

```
kotlinr run-node-public.main.kts TREE TREE_MANIFEST_SHA SOURCE_TSV SOURCE_SHA \
  NODE NODE_SHA PAYLOAD_TSV PAYLOAD_SHA PAYLOAD_IDENTITY JS_OR_Wasm RUNTIME_ID NEW_OUTPUT
kotlinr check-node-public.main.kts NEW_OUTPUT
```

The launcher uses its existing fixed external scriptRoot `.codex-work/539/packaging/node-public-controller`; do not invoke an unbound copied script. Pinned Node24.16.0, exact root/Mocha runtime closure, sourceTSV, compiler-generated original worker payload/source/equality ledger and producer runtime/build identities remain required before/after children. Payload binding is provenance of the retained implementation, not proof the declined public route activates it. The actual current compiler/source commit must replace the future input labels; no acceptance Boolean is added.

TREE is an immutable exact file inventory with tab-separated SHA256/path `manifest.sha256`, platform.txt (`JS` or `Wasm`), entry.txt and complete Mocha closure. SOURCE_TSV/PAYLOAD_TSV are nonempty unique absolute-path TSV bindings under task539. `payload-identity.properties` fields remain identity,kind,protocol=krogu539.v1,producerCommit,generatedSource,workerEntry,producerBuildLedger,payloadEqualityLedger; all named files must be bound. Source/original worker closure code remains independent own arithmetic; no foreign implementation is imported.

## Current finite corpus and counters

Both targets: sizes256/1024/4096/8192/16384 ×distinct/square/ratio2,45 fresh point processes F/R/F,45 FIRST and1260 warm rows (four routes ×seven samples per point). Mode is explicitly `node-public-serial-retention,size,shape,forward|reverse`. Kernel/frame K64/16/384, actual public multiply and actual public parallelMultiply use identical prepared arrays/BigIntegers and physical alias; ratio2's second input is twice as long. No conversions in numeric operations; full result/input checks and actual NodeBigInt oracle are untimed. Latest native result escapes unchanged. Inputs, warmup200ms, adaptive20ms/countcap8388608, three training batches, seven samples and route order are unchanged. JS no longer has two redundant default64 controls; old1470 rows remain historical.

FIRST is first PUBLIC call, not first backend activation or worker startup; neither backend is activated in the retained production route. No matched first-serial speedup is inferred. Allocation NA; Wasm heap NA. CPU/resource snapshots preserve their process scope. maxRSS is high-water through after-run snapshot, not complete lifetime/per-operation peak or retained memory. Comparisons retain all per-fork ranges, absolute cells and adverse ratios against every matched serial comparator; absence of a registry is not evidence of an improvement.

## Explicit decline witnesses and process ownership

No CPU<=2 unsupported branch: every CPU count must satisfy numeric/public contracts and declined-resource expectations. The host selects exactly one test with no ancestor hooks and requires production registry absence before FIRST, after FIRST, after each of seven parallel rows, after-run and at exit. Each near-call observation is outside counters and checks a fresh controller-owned private empty temp namespace used by TMPDIR/TMP/TEMP. Source-bound emitted direct-fallback proof separately establishes that production cannot accept worker work. Endpoint emptiness alone is not advertised as proof of all transient allocations or hidden activity.

Launcher creates each per-child temp container mode0700 outside timing, records its exact path in binding, and checks it remains empty after terminal; strict checker independently verifies the same path/empty state. Empty observer containers remain task-local evidence. No worker started/retired/files-cleaned-up result is manufactured; host emits explicit PUBLICSERIALDECLINE539 and NONE_STARTED resource rows. No worker monkeypatch, forced quarantine/termination, observer keepalive or production initialization is introduced. Old real-worker/retirement/consumer proofs stay historical.

Clean child environment retains LANG/TZ, exact profile and owned temp scope; cwd is immutable root and argv only--expose-gc plus host inputs. Admission budget JS60minutes/Wasm30minutes, each child600seconds, owned bounded cleanup10seconds,4MiB polled log limit and all failure preservation remain unchanged. Total projections are uncertain; old40621 was a witness failure, not timeout. Process identity/start/argv/runtime/source/artifact and logSHA are strict; a nonzero/partial/unsupported result cannot become COMPLETE. Checker outputs checked/flushed CSVs and COMPLETE only after all45 strict children. Independent raw review, final resource/retention decision, paired28 guards and full correctness remain separate existing obligations; no universal recovery/adoption claim.
