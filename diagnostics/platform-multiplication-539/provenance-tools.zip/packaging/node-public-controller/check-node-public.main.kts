#!/usr/bin/env kotlinr
// Independent strict inventory/statistics pass; does not execute any numerical code.
import java.io.File
import java.security.MessageDigest
import java.util.Properties
require(args.size==1) { "completedCampaignDirectory" }
val root=File(args[0]).canonicalFile
fun props(file:File)=Properties().also { p->file.inputStream().use(p::load) }
fun sha(file:File)=MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString("") { "%02x".format(it) }
val meta=props(File(root,"campaign.properties"))
fun m(key:String)=checkNotNull(meta.getProperty(key))
val kind=m("kind").also { check(it in listOf("JS","Wasm")) }
check(File(root,"EXECUTED_NOT_YET_METRICS_VALIDATED").isFile)
check(File(root,"runtime.log").readText().trim()=="v24.16.0")
check(m("node-public-host.cjs.sha256")==sha(File(m("host"))))
check(m("check-node-public.main.kts.sha256")==sha(File(File(m("host")).parentFile,"check-node-public.main.kts")))
val sizes=listOf(256,1024,4096,8192,16384)
val shapes=listOf("distinct","square","ratio2")
fun variants(shape:String):List<String> = listOf("kernel-k64-s16-e384","frame-k64-s16-e384","serial","parallel")
data class Row(val fork:Int,val point:String,val variant:String,val sample:Int,val count:Long,val elapsed:Long,val cpu:Long?,val heap:Long?,val hash:Int) { val ns:Double get()=elapsed.toDouble()/count }
data class First(val fork:Int,val point:String,val ns:Long,val cpu:Long?)
fun optional(value:String):Long?=if(value=="NA")null else value.toLong().also { check(it>=0) }
val rows=mutableListOf<Row>();val first=mutableListOf<First>();val identities=mutableSetOf<String>()
val expectedLogs=mutableSetOf<String>()
for(fork in 0..2)for(size in sizes)for(shape in shapes) {
    val point="$size/$shape";val order=if(fork==1)"reverse" else "forward"
    val log=File(root,"fork$fork-$size-$shape.log");expectedLogs+=log.name
    val lines=log.readLines();val binding=props(File(log.path+".binding"))
    fun b(key:String)=checkNotNull(binding.getProperty(key))
    check(b("fork")==fork.toString() && b("size")==size.toString() && b("shape")==shape && b("order")==order)
    for(key in listOf("sourceSHA","treeManifestSHA","payloadManifestSHA","payloadIdentity"))check(b(key)==m(key))
    check(b("logSHA")==sha(log) && File(log.path+".exit").readText()=="0\n")
    check(File(log.path+".profile").readText()=="node-public-serial-retention,$size,$shape,$order\n")
    val expectedArgv=listOf(m("node"),"--expose-gc",m("host"),m("cwd"),m("entry"),m("mocha"),kind,m("payloadIdentity"))
    check(File(log.path+".argv.txt").readLines()==expectedArgv)
    val own=lines.single { it.startsWith("# OWN539 ") }
    check(own=="# OWN539 pid=${b("pid")} start_epoch_ms=${b("start_epoch_ms")} node=v24.16.0 kind=$kind flags=[\"--expose-gc\"]")
    check(b("pid").toLong()>0 && b("start_epoch_ms").toLong()>0)
    check(identities.add(b("pid")+"/"+b("start_epoch_ms")))
    val osIdentity=File(log.path+".identity.txt").readText()
    check(osIdentity.startsWith("pid=${b("pid")} start=") && "null" !in osIdentity)
    check(lines.count { it=="# ORIGIN539 entry=${m("entry")} mocha=${m("mocha")}" }==1)
    check(lines.count { it.startsWith("# REGISTERED539 selected=1 name=") }==1)
    check(lines.count { it=="# SELECTED539 tests=1 passes=1 failures=0 pending=0" }==1)
    check(lines.count { it=="PASS_PUBLICNODE539,$point" }==1)
    check(lines.count { it.startsWith("# HOSTCONTEXT539 ") }==1 && lines.count { it.startsWith("# RESOURCE539 ") }==1)
    check(lines.count { it.startsWith("# CACHEORIGIN539 phase=before-run ") }==1 && lines.count { it.startsWith("# CACHEORIGIN539 phase=after-run ") }==1)
    check(lines.count { it=="# PUBLICBACKEND_BEFORE539 absent=true" }==1)
    check(lines.count { it=="INPUTNODE539,$point,$size,${if(shape=="ratio2")2*size else size},${shape=="square"}" }==1)
    val f=lines.single { it.startsWith("FIRSTNODE539,") }.split(',')
    check(f.size==4 && f[1]==point)
    first+=First(fork,point,f[2].toLong().also { check(it>0) },optional(f[3]))
    val expectedVariants=variants(shape).let { if(fork==1)it.reversed() else it }
    check(lines.single { it.startsWith("INVENTORYNODE539,") }=="INVENTORYNODE539,$point,${expectedVariants.joinToString(";")}")
    val actual=lines.filter { it.startsWith("PUBLICNODE539,") }.map { line->
        val c=line.split(',');check(c.size==9 && c[1].startsWith("$point/"))
        val v=c[1].removePrefix("$point/");check(v in expectedVariants)
        Row(fork,point,v,c[2].toInt(),c[3].toLong(),c[4].toLong(),optional(c[5]),optional(c[7]),c[8].toInt()).also {
            check((kind!="Wasm" || c[7]=="NA") && c[6]=="NA" && it.sample in 0..6 && it.elapsed>0 && it.count in 1L..8388608L && (it.count and (it.count-1))==0L && it.ns.isFinite())
        }
    }
    check(actual.map { it.variant to it.sample }==expectedVariants.flatMap { v->(0..6).map { v to it } })
    for(group in actual.groupBy { it.variant }.values)check(group.map { it.count }.distinct().size==1 && group.map { it.hash }.distinct().size==1)
    // FIRST precedes every warmed route; does not certify pristine whole-runtime coldness.
    check(lines.indexOfFirst { it.startsWith("FIRSTNODE539,") }<lines.indexOfFirst { it.startsWith("PUBLICNODE539,") })
    // Explicit decline: no worker activation or cleanup is claimed.
    val tempRoot=File(b("tempRoot")).canonicalFile
    check(tempRoot==File(root,"fork$fork-$size-$shape-tmp").canonicalFile)
    check(tempRoot.isDirectory && !java.nio.file.Files.isSymbolicLink(tempRoot.toPath()) && tempRoot.listFiles()!!.isEmpty())
    check(lines.count { it=="# DECLINE_TEMP539 root=$tempRoot empty=true" }==1)
    val near=lines.filter { it.startsWith("PUBLICSERIALDECLINE539,") }.map { it.split(',') }
    check(near.size==8 && near.all { it.size==8 && it[1]==point && it[5]==kind && it[6]=="true" && it[7]=="true" })
    val parallelRows=actual.filter { it.variant=="parallel" }
    for((index,c)in near.withIndex()) {
        val firstWitness=index==0;val sample=if(firstWitness)-1 else index-1
        val count=if(firstWitness)1L else parallelRows[sample].count
        check(c[2]==if(firstWitness)"first" else "parallel")
        check(c[3]==sample.toString() && c[4]==count.toString())
        val rawPrefix=if(firstWitness)"FIRSTNODE539,$point," else "PUBLICNODE539,$point/parallel,$sample,"
        val rawPosition=lines.indexOfFirst { it.startsWith(rawPrefix) }
        val witnessPosition=lines.indexOf(c.joinToString(","))
        check(rawPosition>=0 && witnessPosition>rawPosition)
        val nextRaw=lines.withIndex().firstOrNull { it.index>rawPosition && it.value.startsWith("PUBLICNODE539,") }?.index
        check(nextRaw==null || witnessPosition<nextRaw)
    }
    check(lines.count { it=="# PUBLICSERIAL_POST539 point=$point registry_absent=true temp_empty=true" }==1)
    check(lines.count { it=="PUBLICSERIALRESOURCE539,$point,NONE_STARTED,true,true" }==1)
    check(lines.none { it.startsWith("PUBLICBACKENDNEAR539,") || it.startsWith("PUBLICBACKENDCLEANUP539,") || it.startsWith("# PUBLICSERIAL_FAILURE539 ") })
    rows+=actual
}
check(root.listFiles()!!.filter { it.name.matches(Regex("fork[0-9]+-.*\\.log")) }.map { it.name }.toSet()==expectedLogs)
check(first.size==45 && rows.size==1260)
for(group in rows.groupBy { it.point+"/"+it.variant }.values)check(group.map { it.hash }.distinct().size==1)
// Native output hashes need not match across IntArray and BigInteger representations.
for((_,group) in rows.groupBy { it.fork to it.point }) {
    check(group.filter { it.variant.startsWith("kernel") || it.variant.startsWith("frame") }.map { it.hash }.distinct().size==1)
    check(group.filter { it.variant in listOf("serial","parallel") }.map { it.hash }.distinct().size==1)
}
fun median(v:List<Double>):Double { val s=v.sorted();return if(s.size%2==1)s[s.size/2] else(s[s.size/2-1]+s[s.size/2])/2 }
fun writeCsv(file:File,body:(java.io.PrintWriter)->Unit) {
    val writer=file.printWriter()
    try { body(writer);writer.flush();check(!writer.checkError()) { "CSV flush failed: $file" } }
    finally { writer.close() }
    check(!writer.checkError()) { "CSV close failed: $file" }
}
val target=File(root,"strict-results").also { check(!it.exists());check(it.mkdir()) }
writeCsv(File(target,"warm.csv")) { out->out.println("fork,point,variant,sample,count,elapsedNs,cpuNs,allocationBytes,coarseHeapBytes,resultHash");for(r in rows)out.println("${r.fork},${r.point},${r.variant},${r.sample},${r.count},${r.elapsed},${r.cpu?:"NA"},NA,${r.heap?:"NA"},${r.hash}") }
writeCsv(File(target,"first.csv")) { out->out.println("fork,point,firstNs,cpuNs");for(f in first)out.println("${f.fork},${f.point},${f.ns},${f.cpu?:"NA"}") }
val medians=rows.groupBy { Triple(it.fork,it.point,it.variant) }.mapValues { (_,g)->median(g.map { it.ns }) }
writeCsv(File(target,"per-fork.csv")) { out->out.println("fork,point,variant,medianNs,minNs,maxNs,medianCpuNsPerOp");for((key,g)in rows.groupBy { Triple(it.fork,it.point,it.variant) })out.println("${key.first},${key.second},${key.third},${medians.getValue(key)},${g.minOf { it.ns }},${g.maxOf { it.ns }},${g.mapNotNull { r->r.cpu?.toDouble()?.div(r.count) }.let { if(it.size==g.size)median(it).toString() else "NA" }}") }
writeCsv(File(target,"paired-all-comparators.csv")) { out->
    out.println("point,comparator,fork0ratio,fork1ratio,fork2ratio,medianPairedRatio,maxPairedRatio")
    for(size in sizes)for(shape in shapes)for(v in variants(shape).filter { it!="parallel" }+"fastest-matched-serial") {
        val point="$size/$shape"
        val ratios=(0..2).map { fork->
            val denominator=if(v=="fastest-matched-serial")variants(shape).filter { it!="parallel" }.minOf { medians.getValue(Triple(fork,point,it)) } else medians.getValue(Triple(fork,point,v))
            medians.getValue(Triple(fork,point,"parallel"))/denominator
        }
        out.println("$point,$v,${ratios.joinToString(",")},${median(ratios)},${ratios.max()}")
    }
}
writeCsv(File(target,"pooled.csv")) { out->
    out.println("point,variant,pooledMedianNs,minNs,maxNs,minBatchNs,maxBatchNs,cappedSamples")
    for((key,g)in rows.groupBy { it.point to it.variant })out.println("${key.first},${key.second},${median(g.map { it.ns })},${g.minOf { it.ns }},${g.maxOf { it.ns }},${g.minOf { it.elapsed }},${g.maxOf { it.elapsed }},${g.count { it.count==8388608L }}")
}
writeCsv(File(target,"first-summary.csv")) { out->
    out.println("point,medianFirstNs,minFirstNs,maxFirstNs")
    for((point,g)in first.groupBy { it.point })out.println("$point,${median(g.map { it.ns.toDouble() })},${g.minOf { it.ns }},${g.maxOf { it.ns }}")
}
File(target,"SCOPE.txt").writeText("PASS strict45FIRST/1260warm/45fresh identities, explicit JS/Wasm production serial retention. FIRST is first public serial call, not worker startup/activation or matched first-serial speedup. Four current K64/16/384 kernel/frame/publicserial/publicparallel routes; historical JS1470 rows are not relabelled. All per-fork adverse/CPU rows retained; allocation NA, WasmheapNA. Eight outside-counter registry-absence/owned-empty-temp snapshots and terminal parent temp inspection required; no worker started/cleaned-up assertion is inferred from arithmetic alone. Compiled direct fallback is a separate source/artifact proof. RESOURCE maxRSS is through after-run snapshot, not whole completed lifetime/per-operation peak/retained memory. Observer may affect between-sample state; no adoption/recovery verdict.\n")
File(root,"COMPLETE").writeText("Strict inventory/statistics PASS; independent raw review/adoption/resource decisions remain.\n")
println("PASS $kind 45FIRST/${rows.size}warm; all adverse retained")
