# Actual Node public first/warm controller — SOURCE ONLY

Ownership: backlog_coordinator owns this external directory only. Owner536 owns application, immutable artifact assembly, actual bindings/build/run. No numerical implementation or fixture change here. Existing fixture2169 and current source14e1fa5 remain separate provenance; historical worker105 is not final public frontend evidence.

Future commands (substitute actual SHA-bound files after final build, not guessed values):

```sh
kotlinr /Users/yoda/dev/pet/krogu-math/.codex-work/539/packaging/node-public-controller/run-node-public.main.kts TREE TREE_MANIFEST_SHA SOURCE_TSV SOURCE_SHA NODE NODE_SHA PAYLOAD_TSV PAYLOAD_SHA PAYLOAD_IDENTITY JS RUNTIME_ID NEW_OUTPUT
kotlinr /Users/yoda/dev/pet/krogu-math/.codex-work/539/packaging/node-public-controller/check-node-public.main.kts NEW_OUTPUT
```

Run separately with `Wasm` and its independently built immutable tree/payload. No build/download/run has been performed for these new scripts. Only after independent source review may owner execute them. The same pinned Kotlin2.4.21/JDK25 script infrastructure and Node24.16.0 apply. No additional scalar performance gate.

## Inputs and actual build provenance

`TREE/manifest.sha256`: existing strict TSV `sha256<TAB>relative/path`, no manifest self-entry. Exact whole root tree includes platform.txt (`JS` or `Wasm`), entry.txt (relative generated root test entry), and `mocha/node_modules/mocha/index.js` with its complete linked closure. No symlinks/unindexed files. The external host is separately self-bound; it permits CommonJS modules only from the exact immutable root plus itself. Wasm uses generated startUnitTests registration. One selected optionalPublicRoute, no selected ancestor hooks, no diagnostic worker modules/imports. Immediately before running that test, production registry absence is asserted as the backend-cold witness.

SOURCE_TSV and PAYLOAD_TSV are nonempty unique-path SHA256/absolute-path TSVs inside task539. Source TSV binds the current compiled source closure including production public frontend, fixture and actual selected policy. Payload TSV binds generated embedded source, every original producer worker closure file, producer build/runtime/compiler/source manifests and actual compiler-file-to-embedded-payload equality ledger. Include one `payload-identity.properties` (sample below). These are future actual build inputs, not acceptance booleans. Controller verifies all hashes before/after each child; host requires the observed production owner identity equals the descriptor on eligible points. Owner must provide the complete producer closure and honest compiled-era proof; a filename alone cannot prove compiler provenance.

```
protocol=krogu539.v1
kind=JS
identity=<actual generated payload identity>
producerCommit=<actual 40hex composed commit>
generatedSource=/absolute/task539/path/to/actual/generated/NodeWorkerPayload539.kt
workerEntry=/absolute/task539/path/to/actual/compiler/entry.js
producerBuildLedger=/absolute/task539/path/to/actual/build-ledger.json
payloadEqualityLedger=/absolute/task539/path/to/actual/payload-byte-equality.json
```

Each named file must itself be included in source/payload TSV. Wasm uses kind=Wasm and actual generated .mjs entry. No worker assets are manually installed by this controller: production payload materialization remains inside the timed first public call. Published-KLIB delivery proof is the separate reviewed nine-file consumer fixture, not this root-test campaign.

## Exact execution and timing

Five sizes256/1024/4096/8192/16384 × distinct/square/ratio2; three fresh point processes in F/R/F route order (point order reversed in middle fork).45 processes and45 FIRST rows per target. JS1470 warm rows; Wasm1260. Four base routes selected kernel/frame/public serial/public parallel. JS distinct additionally includes64/16/384 kernel/frame controls (210 rows). Same originating prepared input words/public values and alias relation; latest native result escapes unchanged. All numerical preparation/conversions/full oracle/input checks remain in the reviewed Kotlin fixture outside its counters. No host numerical code.

FIRST is the first PUBLIC call/activation attempt and includes any backend activation/filesystem/decode/import/startup/bridge taken by that call; it is not direct proof that this first return accepted a worker job; it follows school/BI/oracle preparation and is not pristine whole-runtime/JIT coldness or a paired first-serial speedup. Warm native results remain native; retained latest output only. Selected current JS32/entry128 is compared against public serial and explicit default64 controls. Actual production child policy remains bound independently. No historical07910 reuse.

Clean child env LANG/TZ plus exact KROGU539_ARGS; cwd immutable root; argv includes only --expose-gc. Host logs Node identity/start/CPU eligibility/OS/load/memory, registration/origin/cache checks, observed actual worker generation/thread IDs and after-run process resourceUsage. The resource snapshot occurs before production beforeExit retirement: maxRSS is the high-water through that snapshot, not the complete lifetime peak including later termination; memoryUsage is an after-run process sample. >2 CPUs required for route eligibility; unsupported causes explicit nonzero failure, never a partial COMPLETE. Exact terminal child exit includes production beforeExit retirement; child timeout600s and campaign admission budget60min for JS /30min for Wasm retain prior completed raw children on failure. Owned ProcessBuilder terminal fence/descendant cleanup follows reviewed launcher; redirects go to an OS-owned file, child terminal closes the producer FD before parsing. Log supervisor checks4MiB every250ms (not a hard instantaneous disk cap); excess aborts and bounded owned cleanup, raw partial retained.

## Strict outputs and limits

Standalone checker validates45 distinct PID/start pairs, exact command/profile/origin/source/tree/payload/log bindings, one FIRST/PASS/selected test per point, exact route order and seven samples, power-of-two count1..8388608, positive finite wall time, nonnegative available CPU/heap, allocation explicitly NA, stable hashes within each native representation. It never compares IntArray hash with BigInteger hash as an oracle. Full mathematical oracles remain untimed Kotlin checks. No earlier-result immutability claim.

`strict-results/`: all warm/first raw cells, per-fork ranges/medians/CPU, pooled ranges and cap/batch-duration counts, first ranges, all per-fork public-parallel ratios against every serial comparator and fastest same-fork matched serial (including explicit default64 controls). No adverse is filtered and no automatic adoption verdict. Coarse parent heap and after-run memoryUsage are process samples. process.resourceUsage maxRSS is high-water through the after-run snapshot before beforeExit retirement; it is neither the entire completed-process lifetime peak nor per-operation retained memory/peak. Any future external full-lifetime observer must be reported separately. CPU/resource/lifecycle judgments remain existing frozen adoption obligations. COMPLETE is written only after strict checks and output writers close; independent raw audit and policy/guards/full acceptance remain separate.
