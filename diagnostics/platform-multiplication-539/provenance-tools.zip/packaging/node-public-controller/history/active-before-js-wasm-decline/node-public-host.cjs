// Untimed task-owned Mocha selector/identity wrapper; numerical code stays in the built Kotlin probe.
const fs = require('node:fs');
const path = require('node:path');
const {pathToFileURL} = require('node:url');
const {performance} = require('node:perf_hooks');
(async () => {
  const [rootArg, entryArg, mochaArg, kind, payloadIdentity] = process.argv.slice(2);
  if(process.argv.length!==7 || !['JS','Wasm'].includes(kind) || process.version!=='v24.16.0' || !/^[a-f0-9]{64}$/.test(payloadIdentity)) throw Error('pinned args/runtime');
  const root=fs.realpathSync(rootArg);
  const self=fs.realpathSync(__filename);
  const os=require('node:os');
  if(os.availableParallelism()<=2) throw Error('UNSUPPORTED: actual public worker route requires >2 processors');
  console.log('# HOSTCONTEXT539 '+JSON.stringify({platform:process.platform,arch:process.arch,release:os.release(),cpus:os.availableParallelism(),totalmem:os.totalmem(),freemem:os.freemem(),loadavg:os.loadavg(),cwd:process.cwd()}));
  const entry=fs.realpathSync(entryArg), mochaPath=fs.realpathSync(mochaArg);
  for(const file of [entry,mochaPath]) if(!file.startsWith(root+path.sep)) throw Error('Input outside owned artifact tree');
  function verifyCache(phase) {
    let count=0;
    for(const filename of Object.keys(require.cache)) {
      const real=fs.realpathSync(filename);
      if(real!==self && !real.startsWith(root+path.sep)) throw Error('Loaded CommonJS file outside immutable tree: '+real);
      count++;
    }
    console.log('# CACHEORIGIN539 phase='+phase+' files='+count+' owned=true');
  }
  console.log('# OWN539 pid='+process.pid+' start_epoch_ms='+Math.trunc(performance.timeOrigin)+' node='+process.version+' kind='+kind+' flags='+JSON.stringify(process.execArgv));
  console.log('# ORIGIN539 entry='+entry+' mocha='+mochaPath);
  const Mocha=require(mochaPath);
  const mocha=new Mocha({ui:'bdd',reporter:'dot',timeout:0,grep:/NodePublicFrontendCalibration539.*optionalPublicRoute/});
  mocha.addFile(entry);
  await mocha.loadFilesAsync();
  if(kind==='Wasm') {
    const wasm=await import(pathToFileURL(entry).href);
    if(typeof wasm.startUnitTests!=='function') throw Error('Missing generated Wasm startUnitTests export');
    if(globalThis.kotlinTest===undefined) globalThis.kotlinTest={adapterTransformer:adapter=>adapter};
    wasm.startUnitTests();
  }
  verifyCache('before-run');
  const selected=[];
  mocha.suite.eachTest(test=>{if(/NodePublicFrontendCalibration539.*optionalPublicRoute/.test(test.fullTitle()))selected.push(test.fullTitle());});
  if(selected.length!==1) throw Error('Expected exactly one optionalPublicRoute');
  mocha.suite.eachTest(test=>{ if(/NodePublicFrontendCalibration539.*optionalPublicRoute/.test(test.fullTitle())) {
    for(let suite=test.parent;suite;suite=suite.parent) for(const key of ['_beforeAll','_beforeEach','_afterAll','_afterEach'])
      if(!Array.isArray(suite[key]) || suite[key].length!==0) throw Error('Unexpected selected-suite hook '+key);
  }});
  console.log('# REGISTERED539 selected='+selected.length+' name='+JSON.stringify(selected[0]));
  if(process[Symbol.for('io.heapy.krogu.node-parallel-539.v1')]!==undefined) throw Error('Production backend already initialized before FIRST');
  console.log('# PUBLICBACKEND_BEFORE539 absent=true');
  const protocol='io.heapy.krogu.node-parallel-539.v1';
  const key=Symbol.for(protocol);
  const profile=/^node-public-frontend,(256|1024|4096|8192|16384),(distinct|square|ratio2),(forward|reverse)$/.exec(process.env.KROGU539_ARGS||'');
  if(!profile) throw Error('Exact public profile required');
  const point=profile[1]+'/'+profile[2], eligible=Number(profile[1])>=4096;
  const rawWrite=process.stdout.write;
  const emit=line=>Reflect.apply(rawWrite,process.stdout,[line+'\n']);
  let captured=null, workers=null, originalThreadIds=null, capturedPaths=null, generation='NONE';
  let firstSeen=false,nextSample=0,lastSequence=0,lastCount=null,cleanupVerified=false;
  function diagnostic(phase) {
    const owner=process[key];
    return {phase,point,eligible,captured:captured!==null,sameGeneration:owner===captured,
      ownerPresent:owner!==undefined,state:owner&&owner.state,identity:owner&&owner.identity,
      generation,capturedState:captured&&captured.state,capturedIdentity:captured&&captured.identity,
      capturedCleanupFailed:captured&&captured.cleanupFailed,capturedWorkerIds:workers&&workers.map(worker=>worker.threadId),
      sequence:owner&&owner.sequence,cleanupFailed:owner&&owner.cleanupFailed,
      directory:owner&&owner.directory,slots:owner&&Array.isArray(owner.slots)?owner.slots.map(slot=>slot&&{
        threadId:slot.worker&&slot.worker.threadId,pending:slot.pending,
        status:slot.status instanceof Int32Array?Atomics.load(slot.status,0):null}):null};
  }
  function fail(error,phase) {
    process.exitCode=3;
    try {emit('# PUBLICBACKEND_FAILURE539 '+JSON.stringify(diagnostic(phase)));} catch(_) {}
    console.error(error.stack||String(error));
  }
  function capture(phase,sample,count) {
    const owner=process[key];
    let sequence=0,threads=[0,0],pending=[0,0],status=[0,0],state='ABSENT';
    if(eligible) {
      const Worker=require('node:worker_threads').Worker;
      if(!owner || owner.protocol!==protocol || owner.identity!==payloadIdentity || owner.state!=='IDLE' ||
          !Array.isArray(owner.slots) || owner.slots.length!==2 || !Number.isSafeInteger(owner.sequence) || owner.sequence<2)
        throw Error('Near-call production generation/identity missing');
      for(let i=0;i<2;i++) {
        const slot=owner.slots[i];
        if(!slot || !(slot.worker instanceof Worker) || slot.worker.threadId<=0 || slot.pending!==0 ||
            !(slot.status instanceof Int32Array) || Atomics.load(slot.status,0)!==1)
          throw Error('Near-call actual worker/terminal slot missing');
        threads[i]=slot.worker.threadId;pending[i]=slot.pending;status[i]=Atomics.load(slot.status,0);
      }
      if(threads[0]===threads[1])throw Error('Distinct worker ownership missing');
      if(captured===null) {
        if(phase!=='first' || typeof owner.directory!=='string' || !Array.isArray(owner.files) || owner.files.length<1 || owner.files.length>32)throw Error('First generation paths missing');
        captured=owner;workers=owner.slots.map(slot=>slot.worker);originalThreadIds=threads.slice();
        capturedPaths=[owner.directory,...owner.files];
        if(capturedPaths.some(file=>typeof file!=='string' || !path.isAbsolute(file)) || new Set(capturedPaths).size!==capturedPaths.length)throw Error('Generation path identity');
        generation=require('node:crypto').createHash('sha256').update(owner.directory).digest('hex');
      } else if(owner!==captured || owner.slots.some((slot,i)=>slot.worker!==workers[i]))throw Error('Near-call generation replaced');
      sequence=owner.sequence;state=owner.state;
      // FIRST is exactly one call; later seven rows follow the same isolated
      // public operation. Verification and this observer submit no jobs.
      if(phase==='first' && sequence!==2)throw Error('First accepted job count');
      if(phase==='parallel' && (sample===0?sequence<lastSequence+2*count:sequence!==lastSequence+2*count))throw Error('Measured public accepted-job progression');
      lastSequence=sequence;
    } else if(owner!==undefined)throw Error('Unexpected backend below threshold');
    emit(['PUBLICBACKENDNEAR539',point,phase,sample,count,payloadIdentity,generation,state,sequence,...threads,...pending,...status].join(','));
  }
  function observeLine(line) {
    if(line.startsWith('FIRSTNODE539,')) {
      const c=line.split(',');if(c.length!==4 || c[1]!==point || firstSeen)throw Error('FIRST witness inventory');
      capture('first',-1,1);firstSeen=true;
    } else if(line.startsWith('PUBLICNODE539,')) {
      const c=line.split(',');if(c.length!==9 || !c[1].startsWith(point+'/'))throw Error('Warm witness point');
      if(c[1]===point+'/parallel') {
        const sample=Number(c[2]),count=Number(c[3]);
        if(!firstSeen || sample!==nextSample || sample>6 || !Number.isSafeInteger(count) || count<1 || count>8388608 || (count&(count-1))!==0 || (lastCount!==null && count!==lastCount))throw Error('Parallel witness sample/count');
        capture('parallel',sample,count);lastCount=count;nextSample++;
      }
    }
  }
  let fragment='';
  process.stdout.write=function(chunk,encoding,callback) {
    const accepted=Reflect.apply(rawWrite,this,arguments);
    try {
      fragment+=typeof chunk==='string'?chunk:Buffer.from(chunk).toString(typeof encoding==='string'?encoding:'utf8');
      if(fragment.length>65536)throw Error('Bounded stdout witness line exceeded');
      let newline;
      while((newline=fragment.indexOf('\n'))>=0) {
        const line=fragment.slice(0,newline).replace(/\r$/,'');fragment=fragment.slice(newline+1);
        observeLine(line);
      }
    } catch(error) {fail(error,'near-call');throw error;}
    return accepted;
  };
  function verifyCleanup() {
    if(process[key]!==undefined)throw Error('Generation registry not released after retirement');
    let token='NA';
    if(eligible) {
      if(!captured || captured.state!=='CLOSING' || captured.cleanupFailed || captured.directory!==null || captured.files.length!==0 ||
          captured.slots.some(slot=>!slot || slot.worker!==null || slot.port!==null || slot.childPort!==null) ||
          workers.some(worker=>worker.threadId!==-1) || capturedPaths.some(file=>fs.existsSync(file)))throw Error('Exact captured generation terminal cleanup missing');
      token=Buffer.from(capturedPaths.join('\0'),'utf8').toString('base64');
    }
    cleanupVerified=true;
    emit(['PUBLICBACKENDCLEANUP539',point,payloadIdentity,generation,...(originalThreadIds||[0,0]),true,true,true,true,token].join(','));
  }
  function awaitRetirement() {
    if(!captured || !captured.retirement || typeof captured.retirement.then!=='function')throw Error('Production retirement promise missing');
    captured.retirement.then(()=>{try {verifyCleanup();}catch(error){fail(error,'retirement');}}).catch(error=>fail(error,'retirement-promise'));
  }
  const runner=mocha.run((failures)=> {
    process.stdout.write=rawWrite;
    const stats=runner.stats;
    console.log('# SELECTED539 tests='+stats.tests+' passes='+stats.passes+' failures='+stats.failures+' pending='+stats.pending);
    try {
      verifyCache('after-run');
      if(failures!==0 || stats.tests!==1 || stats.passes!==1 || stats.failures!==0 || stats.pending!==0 || !firstSeen || nextSample!==7)throw Error('Exact test/near-route witness completion missing');
      // Idle retirement can legitimately precede this callback after long serial
      // controls. Capture its actual state; never infer old40621's cause from it.
      emit('# PUBLICBACKEND_POST539 '+JSON.stringify(diagnostic('after-run')));
      const owner=process[key];
      if(eligible) {
        if(owner!==undefined && owner!==captured)throw Error('Post-run generation replaced');
        if(captured.cleanupFailed || !['IDLE','CLOSING'].includes(captured.state))throw Error('Post-run generation broken');
        if(owner===undefined || captured.state==='CLOSING')awaitRetirement();
        else {
          if(!process.listeners('beforeExit').includes(captured.beforeExit))throw Error('Production natural-retirement listener missing');
          // Production registered first. It alone starts retirement and owns the
          // bounded referenced cleanup timer; this observer creates no keepalive,
          // does not ref workers, and never invokes quarantine/termination itself.
          process.once('beforeExit',()=>{try {awaitRetirement();}catch(error){fail(error,'natural-exit');}});
        }
      } else {if(owner!==undefined)throw Error('Unexpected below-threshold owner');verifyCleanup();}
      console.log('# RESOURCE539 '+JSON.stringify({cpu:process.cpuUsage(),memory:process.memoryUsage(),resource:process.resourceUsage()}));
    } catch(error) {fail(error,'after-run');}
  });
  process.once('exit',()=>{
    if(!cleanupVerified) {
      process.exitCode=3;
      try {fs.writeSync(2,'Missing actual generation cleanup witness\n');}catch(_){}
    }
  });
})().catch(error=>{ console.error(error.stack||String(error)); process.exitCode=3; });
