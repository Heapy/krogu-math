#!/usr/bin/env kotlinr
// Independent strict inventory/statistics pass; does not execute any numerical code.
import java.io.File
import java.security.MessageDigest
import java.util.Properties
require(args.size==1) { "completedCampaignDirectory" }
val root=File(args[0]).canonicalFile
fun props(file:File)=Properties().also { p->file.inputStream().use(p::load) }
fun sha(file:File)=MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString("") { "%02x".format(it) }
val meta=props(File(root,"campaign.properties"))
fun m(key:String)=checkNotNull(meta.getProperty(key))
val kind=m("kind").also { check(it in listOf("JS","Wasm")) }
check(File(root,"EXECUTED_NOT_YET_METRICS_VALIDATED").isFile)
check(File(root,"runtime.log").readText().trim()=="v24.16.0")
check(m("node-public-host.cjs.sha256")==sha(File(m("host"))))
check(m("check-node-public.main.kts.sha256")==sha(File(File(m("host")).parentFile,"check-node-public.main.kts")))
val sizes=listOf(256,1024,4096,8192,16384)
val shapes=listOf("distinct","square","ratio2")
fun variants(shape:String):List<String> {
    val k=if(kind=="JS" && shape=="distinct")32 else 64
    val e=if(kind=="JS")128 else 384
    return listOf("kernel-k$k-s16-e$e","frame-k$k-s16-e$e","serial","parallel")+
        if(kind=="JS" && shape=="distinct")listOf("kernel-default-k64-s16-e384","frame-default-k64-s16-e384") else emptyList()
}
data class Row(val fork:Int,val point:String,val variant:String,val sample:Int,val count:Long,val elapsed:Long,val cpu:Long?,val heap:Long?,val hash:Int) { val ns:Double get()=elapsed.toDouble()/count }
data class First(val fork:Int,val point:String,val ns:Long,val cpu:Long?)
fun optional(value:String):Long?=if(value=="NA")null else value.toLong().also { check(it>=0) }
val rows=mutableListOf<Row>();val first=mutableListOf<First>();val identities=mutableSetOf<String>()
val expectedLogs=mutableSetOf<String>()
for(fork in 0..2)for(size in sizes)for(shape in shapes) {
    val point="$size/$shape";val order=if(fork==1)"reverse" else "forward"
    val log=File(root,"fork$fork-$size-$shape.log");expectedLogs+=log.name
    val lines=log.readLines();val binding=props(File(log.path+".binding"))
    fun b(key:String)=checkNotNull(binding.getProperty(key))
    check(b("fork")==fork.toString() && b("size")==size.toString() && b("shape")==shape && b("order")==order)
    for(key in listOf("sourceSHA","treeManifestSHA","payloadManifestSHA","payloadIdentity"))check(b(key)==m(key))
    check(b("logSHA")==sha(log) && File(log.path+".exit").readText()=="0\n")
    check(File(log.path+".profile").readText()=="node-public-frontend,$size,$shape,$order\n")
    val expectedArgv=listOf(m("node"),"--expose-gc",m("host"),m("cwd"),m("entry"),m("mocha"),kind,m("payloadIdentity"))
    check(File(log.path+".argv.txt").readLines()==expectedArgv)
    val own=lines.single { it.startsWith("# OWN539 ") }
    check(own=="# OWN539 pid=${b("pid")} start_epoch_ms=${b("start_epoch_ms")} node=v24.16.0 kind=$kind flags=[\"--expose-gc\"]")
    check(b("pid").toLong()>0 && b("start_epoch_ms").toLong()>0)
    check(identities.add(b("pid")+"/"+b("start_epoch_ms")))
    val osIdentity=File(log.path+".identity.txt").readText()
    check(osIdentity.startsWith("pid=${b("pid")} start=") && "null" !in osIdentity)
    check(lines.count { it=="# ORIGIN539 entry=${m("entry")} mocha=${m("mocha")}" }==1)
    check(lines.count { it.startsWith("# REGISTERED539 selected=1 name=") }==1)
    check(lines.count { it=="# SELECTED539 tests=1 passes=1 failures=0 pending=0" }==1)
    check(lines.count { it=="PASS_PUBLICNODE539,$point" }==1)
    check(lines.count { it.startsWith("# HOSTCONTEXT539 ") }==1 && lines.count { it.startsWith("# RESOURCE539 ") }==1)
    check(lines.count { it.startsWith("# CACHEORIGIN539 phase=before-run ") }==1 && lines.count { it.startsWith("# CACHEORIGIN539 phase=after-run ") }==1)
    check(lines.count { it=="# PUBLICBACKEND_BEFORE539 absent=true" }==1)
    val f=lines.single { it.startsWith("FIRSTNODE539,") }.split(',')
    check(f.size==4 && f[1]==point)
    first+=First(fork,point,f[2].toLong().also { check(it>0) },optional(f[3]))
    val expectedVariants=variants(shape).let { if(fork==1)it.reversed() else it }
    check(lines.single { it.startsWith("INVENTORYNODE539,") }=="INVENTORYNODE539,$point,${expectedVariants.joinToString(";")}")
    val actual=lines.filter { it.startsWith("PUBLICNODE539,") }.map { line->
        val c=line.split(',');check(c.size==9 && c[1].startsWith("$point/"))
        val v=c[1].removePrefix("$point/");check(v in expectedVariants)
        Row(fork,point,v,c[2].toInt(),c[3].toLong(),c[4].toLong(),optional(c[5]),optional(c[7]),c[8].toInt()).also {
            check((kind!="Wasm" || c[7]=="NA") && c[6]=="NA" && it.sample in 0..6 && it.elapsed>0 && it.count in 1L..8388608L && (it.count and (it.count-1))==0L && it.ns.isFinite())
        }
    }
    check(actual.map { it.variant to it.sample }==expectedVariants.flatMap { v->(0..6).map { v to it } })
    for(group in actual.groupBy { it.variant }.values)check(group.map { it.count }.distinct().size==1 && group.map { it.hash }.distinct().size==1)
    // FIRST precedes every warmed route; does not certify pristine whole-runtime coldness.
    check(lines.indexOfFirst { it.startsWith("FIRSTNODE539,") }<lines.indexOfFirst { it.startsWith("PUBLICNODE539,") })
    // Read actual state beside the operation's own print, not after long serial
    // controls where a legitimate idle timer may already have retired workers.
    val near=lines.filter { it.startsWith("PUBLICBACKENDNEAR539,") }.map { it.split(',') }
    check(near.size==8 && near.all { it.size==15 && it[1]==point && it[5]==m("payloadIdentity") })
    val parallelRows=actual.filter { it.variant=="parallel" }
    val generation=near.first()[6]
    val workerIds=near.first().let { listOf(it[9].toLong(),it[10].toLong()) }
    for((index,c)in near.withIndex()) {
        val firstWitness=index==0;val sample=if(firstWitness)-1 else index-1
        val count=if(firstWitness)1L else parallelRows[sample].count
        check(c[2]==if(firstWitness)"first" else "parallel")
        check(c[3]==sample.toString() && c[4]==count.toString() && c[6]==generation)
        val rawPrefix=if(firstWitness)"FIRSTNODE539,$point," else "PUBLICNODE539,$point/parallel,$sample,"
        val rawPosition=lines.indexOfFirst { it.startsWith(rawPrefix) }
        val witnessPosition=lines.indexOf(c.joinToString(","))
        check(rawPosition>=0 && witnessPosition>rawPosition)
        val nextRaw=lines.withIndex().firstOrNull { it.index>rawPosition && it.value.startsWith("PUBLICNODE539,") }?.index
        check(nextRaw==null || witnessPosition<nextRaw)
        if(size>=4096) {
            check(generation.matches(Regex("[a-f0-9]{64}")) && c[7]=="IDLE")
            check(workerIds.all { it>0 } && workerIds.distinct().size==2 && listOf(c[9].toLong(),c[10].toLong())==workerIds)
            check(c[11]=="0" && c[12]=="0" && c[13]=="1" && c[14]=="1")
            val sequence=c[8].toLong();check(sequence>=2)
            if(firstWitness)check(sequence==2L)
            else {
                val previous=near[index-1][8].toLong()
                if(sample==0)check(sequence>=previous+2L*count) else check(sequence==previous+2L*count)
            }
        } else check(c[6]=="NONE" && c[7]=="ABSENT" && c.subList(8,15).all { it=="0" })
    }
    val post=lines.single { it.startsWith("# PUBLICBACKEND_POST539 ") }
    check(post.contains("\"point\":\"$point\"") && post.contains("\"generation\":\"$generation\""))
    val cleanup=lines.single { it.startsWith("PUBLICBACKENDCLEANUP539,") }.split(',')
    check(cleanup.size==11 && cleanup[1]==point && cleanup[2]==m("payloadIdentity") && cleanup[3]==generation)
    check(listOf(cleanup[4].toLong(),cleanup[5].toLong())==workerIds && cleanup.subList(6,10).all { it=="true" })
    if(size>=4096) {
        val decoded=java.util.Base64.getDecoder().decode(cleanup[10])
        check(java.util.Base64.getEncoder().encodeToString(decoded)==cleanup[10])
        val text=decoded.toString(Charsets.UTF_8);check(text.toByteArray(Charsets.UTF_8).contentEquals(decoded))
        val paths=text.split('\u0000');check(paths.size in 2..33 && paths.distinct().size==paths.size)
        val directory=File(paths.first());check(directory.isAbsolute && directory.name.matches(Regex("krogu-node539-[A-Za-z0-9]+")))
        for(name in paths.drop(1)) {
            val file=File(name);check(file.isAbsolute && file.parentFile.canonicalFile==directory.canonicalFile)
            check(file.name !in listOf(".","..") && file.name.matches(Regex("[A-Za-z0-9_.-]+")))
        }
        // This is a read-only post-child confirmation of the exact captured paths,
        // not a cleanup action or inference from a successful arithmetic result.
        check(paths.none { File(it).exists() })
    } else check(cleanup[10]=="NA")
    rows+=actual
}
check(root.listFiles()!!.filter { it.name.matches(Regex("fork[0-9]+-.*\\.log")) }.map { it.name }.toSet()==expectedLogs)
check(first.size==45 && rows.size==if(kind=="JS")1470 else 1260)
for(group in rows.groupBy { it.point+"/"+it.variant }.values)check(group.map { it.hash }.distinct().size==1)
// Native output hashes need not match across IntArray and BigInteger representations.
for((_,group) in rows.groupBy { it.fork to it.point }) {
    check(group.filter { it.variant.startsWith("kernel") || it.variant.startsWith("frame") }.map { it.hash }.distinct().size==1)
    check(group.filter { it.variant in listOf("serial","parallel") }.map { it.hash }.distinct().size==1)
}
fun median(v:List<Double>):Double { val s=v.sorted();return if(s.size%2==1)s[s.size/2] else(s[s.size/2-1]+s[s.size/2])/2 }
fun writeCsv(file:File,body:(java.io.PrintWriter)->Unit) {
    val writer=file.printWriter()
    try { body(writer);writer.flush();check(!writer.checkError()) { "CSV flush failed: $file" } }
    finally { writer.close() }
    check(!writer.checkError()) { "CSV close failed: $file" }
}
val target=File(root,"strict-results").also { check(!it.exists());check(it.mkdir()) }
writeCsv(File(target,"warm.csv")) { out->out.println("fork,point,variant,sample,count,elapsedNs,cpuNs,allocationBytes,coarseHeapBytes,resultHash");for(r in rows)out.println("${r.fork},${r.point},${r.variant},${r.sample},${r.count},${r.elapsed},${r.cpu?:"NA"},NA,${r.heap?:"NA"},${r.hash}") }
writeCsv(File(target,"first.csv")) { out->out.println("fork,point,firstNs,cpuNs");for(f in first)out.println("${f.fork},${f.point},${f.ns},${f.cpu?:"NA"}") }
val medians=rows.groupBy { Triple(it.fork,it.point,it.variant) }.mapValues { (_,g)->median(g.map { it.ns }) }
writeCsv(File(target,"per-fork.csv")) { out->out.println("fork,point,variant,medianNs,minNs,maxNs,medianCpuNsPerOp");for((key,g)in rows.groupBy { Triple(it.fork,it.point,it.variant) })out.println("${key.first},${key.second},${key.third},${medians.getValue(key)},${g.minOf { it.ns }},${g.maxOf { it.ns }},${g.mapNotNull { r->r.cpu?.toDouble()?.div(r.count) }.let { if(it.size==g.size)median(it).toString() else "NA" }}") }
writeCsv(File(target,"paired-all-comparators.csv")) { out->
    out.println("point,comparator,fork0ratio,fork1ratio,fork2ratio,medianPairedRatio,maxPairedRatio")
    for(size in sizes)for(shape in shapes)for(v in variants(shape).filter { it!="parallel" }+"fastest-matched-serial") {
        val point="$size/$shape"
        val ratios=(0..2).map { fork->
            val denominator=if(v=="fastest-matched-serial")variants(shape).filter { it!="parallel" }.minOf { medians.getValue(Triple(fork,point,it)) } else medians.getValue(Triple(fork,point,v))
            medians.getValue(Triple(fork,point,"parallel"))/denominator
        }
        out.println("$point,$v,${ratios.joinToString(",")},${median(ratios)},${ratios.max()}")
    }
}
writeCsv(File(target,"pooled.csv")) { out->
    out.println("point,variant,pooledMedianNs,minNs,maxNs,minBatchNs,maxBatchNs,cappedSamples")
    for((key,g)in rows.groupBy { it.point to it.variant })out.println("${key.first},${key.second},${median(g.map { it.ns })},${g.minOf { it.ns }},${g.maxOf { it.ns }},${g.minOf { it.elapsed }},${g.maxOf { it.elapsed }},${g.count { it.count==8388608L }}")
}
writeCsv(File(target,"first-summary.csv")) { out->
    out.println("point,medianFirstNs,minFirstNs,maxFirstNs")
    for((point,g)in first.groupBy { it.point })out.println("$point,${median(g.map { it.ns.toDouble() })},${g.minOf { it.ns }},${g.maxOf { it.ns }}")
}
File(target,"SCOPE.txt").writeText("PASS strict45FIRST/${rows.size}warm/45fresh identities. No adoption verdict. All per-fork ratios retained including adverse. FIRST is the first PUBLIC call/activation attempt after school/BI/oracle preparation, not direct first-accepted-worker-return proof or matched first-serial speedup. Allocation NA. Heap/memoryUsage are coarse after-run process samples. Resource maxRSS is high-water through the after-run snapshot BEFORE beforeExit retirement, not the entire completed-process lifetime peak or per-operation retained/peak; any external full-lifetime observer is separate. Near-FIRST and seven measured parallel snapshots prove same generation, two actual worker IDs, pending/ready state and accepted-job progression; exact captured-generation retirement/terminal workers/path absence is separately required. Observer is outside counters and does not force retirement or keep the process alive, but may affect between-sample GC/runtime state. Last escaped result only; no earlier-output immutability claim.\n")
File(root,"COMPLETE").writeText("Strict inventory/statistics PASS; independent raw review/adoption/resource decisions remain.\n")
println("PASS $kind 45FIRST/${rows.size}warm; all adverse retained")
