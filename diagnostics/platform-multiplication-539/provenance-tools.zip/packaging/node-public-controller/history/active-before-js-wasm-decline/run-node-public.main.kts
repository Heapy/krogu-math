#!/usr/bin/env kotlinr
// Future executable controller; no numerical implementation or downloaded dependencies.
import java.io.File
import java.nio.file.Files
import java.security.MessageDigest
import java.time.Instant
import java.util.Properties
import java.util.concurrent.TimeUnit

require(args.size == 12) { "tree treeManifestSHA sourceTSV sourceSHA node nodeSHA payloadTSV payloadSHA payloadIdentity JS|Wasm runtimeId NEWoutput" }
fun sha(file: File): String = MessageDigest.getInstance("SHA-256").let { digest ->
    file.inputStream().buffered().use { input -> val bytes = ByteArray(65536); while (true) { val n=input.read(bytes); if(n<0)break; digest.update(bytes,0,n) } }
    digest.digest().joinToString("") { "%02x".format(it) }
}
val taskRoot=File("/Users/yoda/dev/pet/krogu-math/.codex-work/539").canonicalFile
val scriptRoot=File(taskRoot,"packaging/node-public-controller")
val launcher=File(scriptRoot,"run-node-public.main.kts")
val host=File(scriptRoot,"node-public-host.cjs")
val checker=File(scriptRoot,"check-node-public.main.kts")
val selfBindings=listOf(launcher,host,checker).map { it to sha(it) }
val tree=File(args[0]).canonicalFile.also { require(it.isDirectory) }
val manifest=File(tree,"manifest.sha256")
val source=File(args[2]).canonicalFile
val node=File(args[4]).canonicalFile.also { require(it.isFile && it.canExecute()) }
val payload=File(args[6]).canonicalFile
val payloadIdentity=args[8].also { require(it.matches(Regex("[a-f0-9]{64}"))) }
val kind=args[9].also { require(it in listOf("JS","Wasm")) }
val runtimeId=args[10].also { require(it.isNotBlank() && '\n' !in it && '=' !in it) }
val output=File(args[11]).canonicalFile.also { require(it.toPath().startsWith(taskRoot.toPath()) && !it.exists()) }
fun parse(file: File): List<Pair<String,String>> = file.readLines().map { line ->
    val f=line.split('\t'); require(f.size==2 && f[0].matches(Regex("[a-f0-9]{64}")) && f[1].isNotBlank()); f[0] to f[1]
}.also { require(it.isNotEmpty() && it.map { p->p.second }.distinct().size==it.size) }
fun relative(name:String):File {
    require(!File(name).isAbsolute && name.split('/').none { it in listOf(".","..","") })
    val raw=File(tree,name); require(!Files.isSymbolicLink(raw.toPath()))
    return raw.canonicalFile.also { require(it.toPath().startsWith(tree.toPath()) && it.isFile) }
}
val artifacts=parse(manifest).map { (hash,name)->hash to relative(name) }
val inputs=(parse(source)+parse(payload)).map { (hash,name)->
    val raw=File(name); require(raw.isAbsolute && !Files.isSymbolicLink(raw.toPath()))
    hash to raw.canonicalFile.also { require(it.isFile && it.toPath().startsWith(taskRoot.toPath())) }
}
// Owner supplies this SHA-bound build descriptor after the actual producer build.
val descriptorFile=inputs.map { it.second }.filter { it.name=="payload-identity.properties" }.single()
val descriptor=Properties().also { p->descriptorFile.inputStream().use(p::load) }
check(descriptor.getProperty("identity")==payloadIdentity && descriptor.getProperty("kind")==kind)
check(descriptor.getProperty("protocol")=="krogu539.v1")
check(descriptor.getProperty("producerCommit").matches(Regex("[a-f0-9]{40}")))
for(key in listOf("generatedSource","workerEntry","producerBuildLedger","payloadEqualityLedger")) {
    val f=File(checkNotNull(descriptor.getProperty(key))).canonicalFile
    check(f in inputs.map { it.second }) { "Descriptor input must be included in payload/source manifest: $key" }
}
fun verify() {
    check(sha(manifest)==args[1] && sha(source)==args[3] && sha(node)==args[5] && sha(payload)==args[7])
    for((file,hash) in selfBindings)check(sha(file)==hash)
    for((hash,file) in artifacts+inputs)check(sha(file)==hash) { "Changed bound input: $file" }
    val actual=tree.walkTopDown().onEnter { check(!Files.isSymbolicLink(it.toPath())); true }.filter { it.isFile }.map { check(!Files.isSymbolicLink(it.toPath())); it.canonicalFile }.toSet()
    check(actual==artifacts.map { it.second }.toSet()+manifest)
}
verify()
check(File(tree,"platform.txt").readText().trim()==kind)
fun owned(name:String)=relative(name).also { check(it in artifacts.map { p->p.second }) }
val entry=owned(File(tree,"entry.txt").readText().trim())
val mocha=owned("mocha/node_modules/mocha/index.js")
check(output.mkdirs())
descriptorFile.copyTo(File(output,"payload-identity.properties"))
var currentProfile:String?=null
fun clean(builder:ProcessBuilder) {
    builder.environment().clear(); builder.environment()["LANG"]="C"; builder.environment()["TZ"]="UTC"
    currentProfile?.let { builder.environment()["KROGU539_ARGS"]=it }
    builder.directory(tree)
}
fun execute(command: List<String>, log: File, seconds: Long) {
    File(log.path + ".argv.txt").writeText(command.joinToString("\n", postfix = "\n"))
    val builder = ProcessBuilder(command).redirectErrorStream(true).redirectOutput(log)
    clean(builder)
    val child = builder.start()
    var completed = false
    var failure: Throwable? = null
    try {
        File(log.path + ".identity.txt").writeText("pid=${child.pid()} start=${child.toHandle().info().startInstant().orElse(null)}\n")
        val end=System.nanoTime()+TimeUnit.SECONDS.toNanos(seconds)
        while (true) {
            check(log.length()<=4L*1024*1024) { "Owned child log exceeds4MiB: $log" }
            if(child.waitFor(250,TimeUnit.MILLISECONDS)) { completed=true; break }
            check(System.nanoTime()<end) { "Deadline: $log" }
        }
        check(completed) { "Deadline: $log" }
        check(log.length()<=4L*1024*1024) { "Owned child output limit: $log" }
        check(child.exitValue() == 0) { "Child failed: $log exit=${child.exitValue()}" }
    } catch (caught: Throwable) {
        failure = caught
        throw caught
    } finally {
        if (!completed || child.isAlive) {
            var cleanupFailure: Throwable? = null
            fun record(caught: Throwable) {
                if (cleanupFailure == null) cleanupFailure = caught else cleanupFailure!!.addSuppressed(caught)
            }
            val descendants = try { child.toHandle().descendants().toList() }
                catch (caught: Throwable) { record(caught); emptyList() }
            for (handle in descendants.asReversed() + child.toHandle()) {
                try { handle.destroyForcibly() } catch (caught: Throwable) { record(caught) }
            }
            val until = System.nanoTime() + TimeUnit.SECONDS.toNanos(10)
            val capturedInterrupt = Thread.interrupted()
            var interrupted = capturedInterrupt || failure is InterruptedException
            for (handle in descendants + child.toHandle()) {
                while (handle.isAlive && System.nanoTime() < until) {
                    try { handle.onExit().get(maxOf(1L, until - System.nanoTime()), TimeUnit.NANOSECONDS); break }
                    catch (_: InterruptedException) { interrupted = true }
                    catch (_: java.util.concurrent.TimeoutException) { break }
                    catch (caught: Throwable) { record(caught); break }
                }
            }
            val survivors = descendants.filter { it.isAlive }.map { it.pid() }
            if (child.isAlive || survivors.isNotEmpty())
                record(IllegalStateException("Owned cleanup survivors=$survivors rootAlive=${child.isAlive}"))
            if (interrupted) Thread.currentThread().interrupt()
            if (cleanupFailure != null) {
                if (failure != null) failure.addSuppressed(cleanupFailure!!) else throw cleanupFailure!!
            }
        }
    }
}

execute(listOf(node.path,"--version"),File(output,"runtime.log"),10)
check(File(output,"runtime.log").readText().trim()=="v24.16.0")
File(output,"campaign.properties").writeText("kind=$kind\nnode=$node\nhost=$host\nruntimeId=$runtimeId\nsourceSHA=${args[3]}\ntreeManifestSHA=${args[1]}\npayloadManifestSHA=${args[7]}\npayloadIdentity=$payloadIdentity\nnodeSHA=${args[5]}\nentry=$entry\nmocha=$mocha\ncwd=$tree\nstarted=${Instant.now()}\n"+selfBindings.joinToString("") { (f,h)->"${f.name}.sha256=$h\n" })
val sizes=listOf(256,1024,4096,8192,16384)
val shapes=listOf("distinct","square","ratio2")
val points=sizes.flatMap { n->shapes.map { n to it } }
val deadline=System.nanoTime()+TimeUnit.MINUTES.toNanos(if(kind=="JS")60L else 30L)
val identities=mutableSetOf<String>()
for(fork in 0..2) {
    val order=if(fork==1)"reverse" else "forward"
    val ordered=if(fork==1)points.reversed() else points
    for((size,shape) in ordered) {
        verify()
        currentProfile="node-public-frontend,$size,$shape,$order"
        val log=File(output,"fork$fork-$size-$shape.log")
        File(log.path+".profile").writeText(currentProfile+"\n")
        val command=listOf(node.path,"--expose-gc",host.path,tree.path,entry.path,mocha.path,kind,payloadIdentity)
        val seconds=minOf(600L,TimeUnit.NANOSECONDS.toSeconds(deadline-System.nanoTime()))
        check(seconds>0) { "Campaign admission deadline; preserve completed children" }
        execute(command,log,seconds)
        val lines=log.readLines()
        check(lines.count { it=="PASS_PUBLICNODE539,$size/$shape" }==1)
        check(lines.count { it=="# SELECTED539 tests=1 passes=1 failures=0 pending=0" }==1)
        val own=lines.single { it.startsWith("# OWN539 ") }
        val pid=Regex("pid=([0-9]+)").find(own)!!.groupValues[1]
        val start=Regex("start_epoch_ms=([0-9]+)").find(own)!!.groupValues[1]
        check(identities.add("$pid/$start"))
        File(log.path+".binding").writeText("fork=$fork\nsize=$size\nshape=$shape\norder=$order\npid=$pid\nstart_epoch_ms=$start\nsourceSHA=${args[3]}\ntreeManifestSHA=${args[1]}\npayloadManifestSHA=${args[7]}\npayloadIdentity=$payloadIdentity\nlogSHA=${sha(log)}\n")
        verify()
        File(log.path+".exit").writeText("0\n")
        println("COMPLETE_CHILD $kind fork=$fork $size/$shape")
    }
}
File(output,"EXECUTED_NOT_YET_METRICS_VALIDATED").writeText("45 fresh point children exit0. Strict standalone checker and independent audit required; not adoption.\n")
println("PASS execution only:45 fresh points; run strict checker")
