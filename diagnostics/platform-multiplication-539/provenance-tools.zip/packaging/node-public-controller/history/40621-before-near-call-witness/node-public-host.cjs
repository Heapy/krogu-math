// Untimed task-owned Mocha selector/identity wrapper; numerical code stays in the built Kotlin probe.
const fs = require('node:fs');
const path = require('node:path');
const {pathToFileURL} = require('node:url');
const {performance} = require('node:perf_hooks');
(async () => {
  const [rootArg, entryArg, mochaArg, kind, payloadIdentity] = process.argv.slice(2);
  if(process.argv.length!==7 || !['JS','Wasm'].includes(kind) || process.version!=='v24.16.0' || !/^[a-f0-9]{64}$/.test(payloadIdentity)) throw Error('pinned args/runtime');
  const root=fs.realpathSync(rootArg);
  const self=fs.realpathSync(__filename);
  const os=require('node:os');
  if(os.availableParallelism()<=2) throw Error('UNSUPPORTED: actual public worker route requires >2 processors');
  console.log('# HOSTCONTEXT539 '+JSON.stringify({platform:process.platform,arch:process.arch,release:os.release(),cpus:os.availableParallelism(),totalmem:os.totalmem(),freemem:os.freemem(),loadavg:os.loadavg(),cwd:process.cwd()}));
  const entry=fs.realpathSync(entryArg), mochaPath=fs.realpathSync(mochaArg);
  for(const file of [entry,mochaPath]) if(!file.startsWith(root+path.sep)) throw Error('Input outside owned artifact tree');
  function verifyCache(phase) {
    let count=0;
    for(const filename of Object.keys(require.cache)) {
      const real=fs.realpathSync(filename);
      if(real!==self && !real.startsWith(root+path.sep)) throw Error('Loaded CommonJS file outside immutable tree: '+real);
      count++;
    }
    console.log('# CACHEORIGIN539 phase='+phase+' files='+count+' owned=true');
  }
  console.log('# OWN539 pid='+process.pid+' start_epoch_ms='+Math.trunc(performance.timeOrigin)+' node='+process.version+' kind='+kind+' flags='+JSON.stringify(process.execArgv));
  console.log('# ORIGIN539 entry='+entry+' mocha='+mochaPath);
  const Mocha=require(mochaPath);
  const mocha=new Mocha({ui:'bdd',reporter:'dot',timeout:0,grep:/NodePublicFrontendCalibration539.*optionalPublicRoute/});
  mocha.addFile(entry);
  await mocha.loadFilesAsync();
  if(kind==='Wasm') {
    const wasm=await import(pathToFileURL(entry).href);
    if(typeof wasm.startUnitTests!=='function') throw Error('Missing generated Wasm startUnitTests export');
    if(globalThis.kotlinTest===undefined) globalThis.kotlinTest={adapterTransformer:adapter=>adapter};
    wasm.startUnitTests();
  }
  verifyCache('before-run');
  const selected=[];
  mocha.suite.eachTest(test=>{if(/NodePublicFrontendCalibration539.*optionalPublicRoute/.test(test.fullTitle()))selected.push(test.fullTitle());});
  if(selected.length!==1) throw Error('Expected exactly one optionalPublicRoute');
  mocha.suite.eachTest(test=>{ if(/NodePublicFrontendCalibration539.*optionalPublicRoute/.test(test.fullTitle())) {
    for(let suite=test.parent;suite;suite=suite.parent) for(const key of ['_beforeAll','_beforeEach','_afterAll','_afterEach'])
      if(!Array.isArray(suite[key]) || suite[key].length!==0) throw Error('Unexpected selected-suite hook '+key);
  }});
  console.log('# REGISTERED539 selected='+selected.length+' name='+JSON.stringify(selected[0]));
  if(process[Symbol.for('io.heapy.krogu.node-parallel-539.v1')]!==undefined) throw Error('Production backend already initialized before FIRST');
  console.log('# PUBLICBACKEND_BEFORE539 absent=true');
  const runner=mocha.run((failures)=> {
    const stats=runner.stats;
    console.log('# SELECTED539 tests='+stats.tests+' passes='+stats.passes+' failures='+stats.failures+' pending='+stats.pending);
    try {
      verifyCache('after-run');
      const owner=process[Symbol.for('io.heapy.krogu.node-parallel-539.v1')];
      const size=Number(process.env.KROGU539_ARGS.split(',')[1]);
      if(size>=4096) {
        if(!owner || owner.identity!==payloadIdentity || owner.state!=='IDLE' || owner.slots.length!==2 || owner.sequence<2 || owner.slots.some(s=>!s || s.worker.threadId<=0)) throw Error('Actual production worker route/identity missing');
        console.log('# PUBLICBACKEND539 '+JSON.stringify({identity:owner.identity,state:owner.state,sequence:owner.sequence,threads:owner.slots.map(s=>s.worker.threadId)}));
      } else if(owner) throw Error('Unexpected backend initialization below threshold');
      console.log('# RESOURCE539 '+JSON.stringify({cpu:process.cpuUsage(),memory:process.memoryUsage(),resource:process.resourceUsage()}));
      if(failures!==0 || stats.tests!==1 || stats.passes!==1 || stats.failures!==0 || stats.pending!==0) process.exitCode=3;
    } catch(error) { console.error(error.stack||String(error)); process.exitCode=3; }
  });
})().catch(error=>{ console.error(error.stack||String(error)); process.exitCode=3; });
