# JS bounded adjacent K16 extension — external diagnostic patch

UNAPPLIED / UNCOMPILED / UNRUN. Owner536 confirmed no competing implementation and agreed mode/interface plus minimal public Node oracle correction. No frozen tree, production arithmetic or policy changed; current9727 measurements untouched. git apply --check succeeds on the tracked three-file patch against07910edf and separately on external launcher allowlist patch; neither is applied.

## Exact approved finite scope

Selector: `js-balanced-adjacent-k16,forward|reverse,7,20`. Both common builder and strict checker reject non-JS use; external portable launcher also checks its bound platform.txt is JS. Separate builder avoids old kernels(mode) fallback/frame generation.

Sizes exactly16,31,32,63,64,128,256,512,1024,4096,8192. Three policies exactlyK16/K32/current64, leaf16/entry384. IDs exactly `kernel/SIZE/distinct/kK-s16-e384`:33 unique cases,3freshF/R/F processes ×7samples =693TIME rows. Manifest IDs are checked byte-for-byte against the accepted preparation JSON; no ratio2/4/alias/frame or extra K8/K4 cases.

Inputs are EXACT original common generator `a[i]=((i*104729+size*31+1)&0x3fffffff)`, b=a.copyOf, with explicit physical nonalias/equal-length check. They are NOT the worker generator+31. Operands, originals, policies and forced-school expected arrays are constructed outside timing. New public Node BigInt verifier checks school expected outside counters. Each policy full product and original inputs are checked before warmup and through the existing optional last-result verifier AFTER wall/CPU/allocation brackets. No result conversion/checking/formatting inside numeric timed closure. Ring/warmup/adaptive count/train/7samples/provenance/budgets unchanged; only the new mode's check callback is used.

## Concrete oracle-promise correction

Current JS Calibration539Platform.calibration539Verify is an empty platform stub; historical common campaigns therefore have common forced-school checks, NOT this additional public Node oracle. Worker transport has its own public BigInt oracle but it does not retroactively cover common root grids. The new staged JS actual uses ONLY public Node BigInt constructor/shift/add/multiply to verify the expected full product, outside counters; constructor calls avoid BigInt-literal/compiler-flag assumptions. Fresh new-mode cases get that actual oracle after compilation/runtime validation. Preserve old source eras and school-only scope; no relabel or blanket417-case repeat is requested.

## Future commands and outputs (NOT EXECUTED)

After owner safe-window application/review/fresh root JS probe build, freeze actual artifact tree, complete root/Mocha/runtime closure, source TSV and Node hashes. Copy the staged launcher change to the actual owned .codex-work/539/run-portable-common.main.kts before running it, so unchanged self-path binding hashes the actual executing script. Do not execute the staging copy under a misleading old self-path.

Existing launcher argument shape remains:

`kotlinr .codex-work/539/run-portable-common.main.kts ARTIFACT_TREE ARTIFACT_MANIFEST_SHA SOURCE_TSV SOURCE_SHA PINNED_NODE NODE_SHA js-balanced-adjacent-k16 RUNTIME_ID NEW_OUTPUT`

This uses KROGU539_ARGS with new selector on the same one optionalCampaign test, and produces three new source-bound F/R/F fork logs/bindings/exits. Existing deadlines stay600s/child,30minute launch/wait campaign, bounded cleanup. Never overwrite old groups or combine separately collected K policies as same-fork.

Updated existing checker:

`kotlinr scripts/check-portable-multiplication-539.main.kts 7 js-balanced-adjacent-k16 JS SOURCE_SHA ARTIFACT_SHA NEW.csv fork0.log fork1.log fork2.log`

Expected exact33CHECK×3 and693TIME plus existing PASS/identity/order/metric assertions. Retain every sample, adverse process ratio, countcap/duration, partial-ring limitation, CPU/parentheap/wholeRSS scope and allocationNA. Last escaped result is checked via actual overwritten slot `(count-1)&63`; digest of an incompletely overwritten64slot ring is still NOT an isolated product proof. Coarse heap may include verifier/copy work outside counters; never label it exact per-op retention.

## Decision boundary remains unchanged

This one extension compares the already-selected edge against adjacentK16 and currentK64; serial tuning has no20%/10%parallel gate. If K16 remains best tested edge, report uncertainty, causal policy activity and observed resource/adverse/public-guard evidence. No automatic descent or global optimum claim. Production choice remains pending. Actual changed dispatch may apply only to physically distinct equal-length magnitude arrays if that remains chosen; alias/shared-array opposite-sign views and ratio2/4 must provably retain their measured policy, or controls must be explicitly refrozen before any broader wiring. Existing public guards and final correctness remain required.
