# Bounded delivery alternative after the actual KLIB packaging finding

UNIMPLEMENTED design boundary, not source/runtime acceptance. Supersedes root-reentry and sibling-sidecar assumptions in INTERFACE-LIFETIME-PROPOSAL. The draft staged/node-parallel-539.cjs is NOT apply-ready: its root import must be replaced; no claim of a coherent final patch.

## Exact observed existing artifact sizes

See existing-tiny-closure-byte-inventory.json, stat-only observations of existing7821935 artifacts. JS nonmap closure69,662B = main31,209 +stdlib37,887 +DOM compat566. Total including maps116,513B. Wasm nonmap19,693B = wasm11,412 +entry3,245 +import object4,024 +builtins1,012; total including map27,997B. These are existing diagnostic executable bytes, not final optimized production worker size or runtime resident memory. Base64 of each file needs4*ceil(bytes/3) characters; generation must compute exact final closure, not estimate its eventual compiler/KLIB/consumer growth from these old bytes.

## Why direct root import is rejected, independently of speed

A Maven KMP library publishes KLIBs for later consumer linking. There is no own stable standalone public-root JS/Wasm artifact in current build.gradle. __filename/import.meta.url can name a consumer executable/bundle. Reimporting it in worker may execute arbitrary application initialization/main, and reserved library exports need not survive consumer linkage/DCE as assumed. A build-local copied .cjs sidecar is not automatically delivered beside that consumer's root. This is a concrete bootstrap-contract incompatibility of that implementation, not evidence against all Node parallelism.

## Correct bounded self-contained option

Introduce one private production worker build module (not a new arithmetic backend, not a public dependency). It compiles original MagnitudeMultiplication.kt and MultiplicationPolicy539.kt directly with the required platform-policy actuals, plus its own minimal worker entry. It MUST NOT depend on root KLIB. Use explicit child policy captured by caller; worker invokes existing recursive kernel, not a handwritten JS split/recombine. This preserves an acyclic graph:

worker own original sources → JS/Wasm executable links → validated payload generator → root jsMain/wasmJsMain generated Kotlin → root KLIB.

Generator consumes only whitelisted compiler outputs; embeds complete closure bytes with exact paths/sizes/SHA and protocol/compiler/source/policy identity. It excludes source maps. Root source selection must not include generator output in worker module, and worker inputs exclude root build outputs: no compile cycle. Generated Kotlin is a lazily reached platform-specific payload; strings still affect consumer code/package/linking even if pool never starts. Exporting a bridge from consumer root becomes unnecessary. Existing diagnostic callbacks/modules are not production dependencies.

On first eligible Node call, production host decodes validated payload into an owned mkdtemp directory (0700), writes fixed basename paths exclusively with0600, verifies bytes/SHA, and loads only that internal entry. Worker async import can finish while calling thread synchronously waits on shared status. This intentionally uses Node filesystem; unsupported permission/runtime declines only BEFORE work acceptance, without changing mathematical fallback. Other I/O/startup failures need a reviewed explicit classification rather than blanket catch-OOM-and-recompute. No consumer manual installation and no import of application root. Wasm .mjs relative imports and node:fs/import.meta loader work unchanged from files; no compiler-generated numerical/glue rewriting or custom Wasm import-object reconstruction.

Worker entry/host adapter register through private MessagePorts/workerData; no global diagnostic callbacks, Mocha or public root ABI addition. Originating Kotlin owns ParallelFrame split, caller child and combine; the host merely transports two copied child jobs. Every generation is pinned to one platform/payload/protocol/policy identity, bounding imported-module retention. A mismatched live generation declines without spawning another pool. No unbounded module cache or per-BigInteger pools.

The versioned per-isolate scheduler owns at most2workers. STARTING reservation precedes fallible payload/port/thread setup; owned temp paths registered before write; BUSY precedes fallible task setup. No new generation until previous termination promises have all settled and its owned tempfiles are removed. Normal completion publishes jobID/policy/result/failure only after worker job references are cleared; originating module joins accepted jobs. Fatal failures quarantine and never retry accepted arithmetic. After idle timeout worker/port ref-unref and asynchronous teardown follow the existing reviewed lifetime design. Failed cleanup keeps a closed/broken generation rather than silently creating another and leaking workers/files. Process termination may leave private tempfiles after crash; ordinary asynchronous cleanup must be implemented and the limitation disclosed.

## Concrete additional costs/limits to evaluate, not reasons to pre-reject

- Duplicate compiled stdlib/kernel per worker and per-isolate runtime initialization, and enlarged published KLIB/consumer outputs. Historical file bytes above do not quantify resulting RAM/peak.
- One independent worker compilation per platform before root compilation; generated-source reproducibility and package/license/source identity provenance.
- Base64 decode/SHA verification/private-file creation/import/Wasm compile/init on cold activation; steady filesystem use can be zero, but idle restart pays cold again.
- Node builtin getBuiltinModule capability (pinned24.16 supports), fs/tempdir permissions and worker resource permission. Non-Node and unsupported capabilities retain preacceptance serial fallback.
- Actual first/warm/restart, public input/result copies, CPU/resources and small guards remain to measure. Favorable historical warm105 evidence remains; no rejection or adoption is inferred from absent final implementation or static byte sizes alone.

## Finite source boundary before code expansion

Owner/reviewer must agree to the independent private worker module + generated embedded payload + controlled temporary files. If the library's delivery/runtime policy excludes worker payload duplication, filesystem materialization or this build pipeline, that is an explicit architecture/distribution decision with scoped consequences; it must not be disguised as measured lack of Node benefit. A separate opt-in Node artifact is another public packaging/API decision, not automatically within today's KLIB. No further exploratory alternatives or broad framework are needed to select between these finite choices.
