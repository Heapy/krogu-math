'use strict';
// Untimed future contract fixtures only. Not executed during staging.
const fs=require('node:fs'), vm=require('node:vm'), crypto=require('node:crypto'), assert=require('node:assert/strict');
const source=fs.readFileSync(require('node:path').join(__dirname,'node-parallel-539.cjs'),'utf8');
const acquire=vm.runInThisContext('(function(){'+source+';return acquire539;})()');
const key=Symbol.for('io.heapy.krogu.node-parallel-539.v1');
const originalBeforeExitListeners=process.listenerCount('beforeExit');
function payload(body) {
 const bytes=Buffer.from(body);
 return JSON.stringify({protocol:'krogu539.v1',kind:'js',identity:crypto.createHash('sha256').update(bytes).digest('hex'),entry:'fixture.cjs',files:[{name:'fixture.cjs',base64:bytes.toString('base64'),sha256:crypto.createHash('sha256').update(bytes).digest('hex')}]});
}
const normal=payload("const d=process.getBuiltinModule('worker_threads').workerData;d.invoke=()=>{d.result=d.request.a.slice()};");
const failure=payload("const d=process.getBuiltinModule('worker_threads').workerData;d.invoke=()=>{throw Error('accepted-marker')};");
async function finish() {
 const owner=process[key];
 if(!owner) return;
 const directory=owner.directory;
 owner.quarantine();
 const end=Date.now()+5000;
 while(process[key]===owner && Date.now()<end) await new Promise(resolve=>setTimeout(resolve,5));
 assert.notEqual(process[key],owner,'termination/cleanup remained quarantined unexpectedly');
 if(directory) assert.equal(fs.existsSync(directory),false);
 assert.equal(process.listenerCount('beforeExit'),originalBeforeExitListeners,'generation listener leaked');
}
(async()=>{
 if(require('node:os').availableParallelism()<=2) {console.log('NA,transport-contract,CPU<=2');return;}
 let lease;
 try {
  lease=acquire(normal);assert(lease);
  const owner=process[key];assert.equal(owner.slots.length,2);
  assert.equal(process.listenerCount('beforeExit'),originalBeforeExitListeners+1);
  const a=Int32Array.of(7,8),b=Int32Array.of(9,10);
  lease.submit(0,a,b,false,64,16);
  assert.equal(a.byteLength,0);assert.equal(b.byteLength,0); // These are private copies.
  assert.deepEqual(Array.from(lease.join(0)),[7,8]);
  lease.release(false);lease=null;
  assert.equal(owner.state,'IDLE');
  for(const slot of owner.slots) assert.equal(slot.port.hasRef(),false);
  assert.equal(acquire(failure),null,'mismatched live generation must not add workers');
 } finally {if(lease) lease.release(true);await finish();}
 try {
  lease=acquire(failure);assert(lease);
  lease.submit(0,Int32Array.of(1),Int32Array.of(1),false,64,16);
  assert.throws(()=>lease.join(0),/accepted-marker/);
 } finally {if(lease) lease.release(true);lease=null;await finish();}
 const original=fs.mkdtempSync;
 try {
  fs.mkdtempSync=()=>{const error=Error('denied');error.code='EACCES';throw error;};
  assert.equal(acquire(normal),null,'known filesystem capability denial can decline before arithmetic');
 } finally {fs.mkdtempSync=original;await finish();}
 const marker=Error('synthetic-prefix-allocation-failure');
 try {
  fs.mkdtempSync=()=>{throw marker;};
  assert.throws(()=>acquire(normal),error=>error===marker,'unknown allocation/setup failure identity must be preserved');
 } finally {fs.mkdtempSync=original;await finish();}
 console.log('PASS,transport-contract');
})().catch(error=>{console.error(error);process.exitCode=1;});
