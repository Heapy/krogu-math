# Package verifier

`verify-package.main.kts` is a read-only metadata/evidence verifier for task539.
It reuses the accepted529 index/member/hash/Git-blob schema. It does not run code
from artifacts, extract ZIPs, decide performance acceptance or change the tracker.
This new tool is Kotlin scripting; no new Python or shell script was added.
Its source has not yet been compiled or executed. Dependency resolution, archive
hashing and source/Git checks must wait for the owner-agreed window after3267.

It checks exact canonical inventory; streamed bytes/SHA; the independent
`evidence-index.json` and `evidence.sha256` binding without self-hash recursion;
every indexed ZIP against its indexed `.entries.json` ledger; safe names,
duplicate entries and regular member modes; optional external retained reference;
and optionally the exact tested source manifest and committed Git blobs.
ZIP/ZIP64 central directory modes are checked because Java ZipFile omits Unix
attributes. Links/special files, multipart/encrypted ZIPs and unindexed members
are rejected. Evidence is read and hashed, never loaded as numerical code.

Schema:

- `evidence-index.json`: `{ "task":"local:539", "status":"...", "entries":[{"path":"...","bytes":123,"sha256":"..."}] }`.
- SHA ledger covers each payload plus the index; the ledger itself is not recursively hashed by its index.
- `sample.zip` has an indexed `sample.entries.json` with the same entries shape.
  `--archive sample.zip=other.entries.json` supports a different indexed ledger name.
- `retained-evidence.json` follows529: task, `project_relative_root`, `index_sha256`,
  `sha_ledger_sha256`, entries. Supply `--project-root` for the real external
  project root, independent of a source worktree. Retained package index/SHA/ZIP
  members are checked, not silently assumed available from a fresh Git checkout.
- Recovery `file-map.json` entries contain safe original `path`, `blob`, bytes
  and SHA. Each blob must be `blobs/<sha256>`. The verifier matches each logical
  original file against already hash-verified ZIP members without rereading
  their contents, and checks no stored blob is omitted from the map. It does not
  materialize recovered files. Actual filesystem reconstruction remains a
  separately scoped consumer of this exact mapping, if needed.
- The tested source JSON has `files:{"relative/path":"sha256"}`. All listed
  source/build/harness files are checked, not only the src subtree.

Future canonical verification (do not run during the owner's heavy job):

    kotlinr .codex-work/539/packaging/verify-package.main.kts \
      .codex-work/539/worktree/diagnostics/platform-multiplication-539 \
      --project-root /Users/yoda/dev/pet/krogu-math \
      --recovery-map file-map.json=retained:measured-artifacts.zip

Add `--tested-source EXACT_FULL_SOURCE_JSON --source-root .codex-work/539/worktree`
after the final full manifest exists. After the evidence commit add
`--repo .codex-work/539/worktree --git-ref FULL_40_HEX_COMMIT` to compare both
canonical payload/index/SHA blobs and the tested source blobs to committed bytes.
Redirect stdout only to an external audit file, never into the verified package.

The output is always `PACKAGE_BINDINGS_PASS_NOT_TASK_ACCEPTANCE`, with the
package's declared status preserved. `INCOMPLETE_JS_SMALL_UNRESOLVED` is a valid
and necessary honest report state while that issue remains. Technical byte
validation cannot turn it into task acceptance, prove a gain, clear a small
regression, authorize a remote export or change any source-era scope.
