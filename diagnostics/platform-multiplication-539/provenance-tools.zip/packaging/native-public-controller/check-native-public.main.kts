#!/usr/bin/env kotlinr
// Strict Native public first/full-lifecycle result checker. No numerical execution.
import java.io.File
import java.security.MessageDigest
import java.util.Properties
require(args.size==1) { "completedNativePublicCampaign" }
val root=File(args[0]).canonicalFile
fun props(file:File)=Properties().also { p->file.inputStream().use(p::load) }
fun sha(file:File):String=MessageDigest.getInstance("SHA-256").let { digest->
    file.inputStream().buffered().use { input->val bytes=ByteArray(65536);while(true){val n=input.read(bytes);if(n<0)break;digest.update(bytes,0,n)} }
    digest.digest().joinToString("") { "%02x".format(it) }
}
val before=props(File(root,"binding-before.txt"))
fun b(key:String)=checkNotNull(before.getProperty(key))
for(key in listOf("launcher_sha256","source_manifest_sha256","artifact_manifest_sha256","executable_sha256"))check(b(key).matches(Regex("[a-f0-9]{64}")))
check(b("runtime_id").isNotBlank())
for((pathKey,hashKey)in listOf("source_manifest_path" to "source_manifest_sha256","artifact_manifest_path" to "artifact_manifest_sha256")) {
    val file=File(b(pathKey)).canonicalFile;check(file.isFile && sha(file)==b(hashKey))
}
check(File(b("cwd")).isDirectory)
check(File(root,"EXECUTED_NOT_YET_METRICS_VALIDATED").isFile)
val sizes=listOf(256,1024,4096,8192,16384)
val shapes=listOf("distinct","square","ratio2")
// Current actual fixture asserts this exact selected policy. A later policy needs explicit source/inventory rebind.
fun variants(shape:String):List<String> {
    val k=if(shape=="distinct")32 else 64
    return listOf("kernel-k$k-s16-e384","frame-k$k-s16-e384","serial","parallel")
}
val selector="io.heapy.krogu.math.NativePublicFrontendCalibration539.optionalPublicRoute"
data class Row(val fork:Int,val point:String,val variant:String,val sample:Int,val count:Long,val elapsed:Long,val cpu:Long?,val heap:Long?,val hash:Int) {val ns:Double get()=elapsed.toDouble()/count}
data class First(val fork:Int,val point:String,val ns:Long,val cpu:Long?)
data class Resource(val fork:Int,val point:String,val rssBytes:Long,val footprintBytes:Long?)
fun optional(value:String):Long?=if(value=="NA")null else value.toLong().also { check(it>=0) }
val rows=mutableListOf<Row>();val first=mutableListOf<First>();val resources=mutableListOf<Resource>()
val identities=mutableSetOf<String>();val wrappers=mutableSetOf<String>();val expectedLogs=mutableSetOf<String>()
var executable:File?=null
for(fork in 0..2)for(size in sizes)for(shape in shapes) {
    val point="$size/$shape";val order=if(fork==1)"reverse" else "forward"
    val log=File(root,"fork$fork-$size-$shape.log");expectedLogs+=log.name
    val lines=log.readLines();val binding=props(File(log.path+".binding"))
    for(key in listOf("source_manifest_sha256","artifact_manifest_sha256","runtime_id"))check(binding.getProperty(key)==b(key))
    check(File(log.path+".exit").readText()=="0\n")
    check(binding.getProperty("log_sha256")==sha(log))
    check(binding.getProperty("profile")=="native-public-frontend,$size,$shape,$order" && binding.getProperty("order")==order)
    val identity=File(log.path+".native-identity.txt").readText().trim()
    val matched=checkNotNull(Regex("pid=([0-9]+) start_epoch_ms=([0-9]+) executable=(.+)").matchEntire(identity))
    check(matched.groupValues[1].toLong()>0 && matched.groupValues[2].toLong()>0)
    check(identities.add(matched.groupValues[1]+"/"+matched.groupValues[2]))
    val path=File(matched.groupValues[3]).canonicalFile
    check(path==File(b("executable_path")).canonicalFile)
    if(executable==null)executable=path else check(executable==path)
    val argv=File(log.path+".argv.txt").readLines()
    check(argv==listOf("/usr/bin/time","-l",path.path,"--ktest_filter=$selector"))
    val wrapper=File(log.path+".identity.txt").readText().trim()
    val wm=checkNotNull(Regex("pid=([0-9]+) start=(.+)").matchEntire(wrapper))
    check(wm.groupValues[1].toLong()>0 && wm.groupValues[2]!="null" && wrappers.add(wrapper))
    check(lines.count { it=="[ RUN      ] $selector" }==1)
    check(lines.count { it.startsWith("[       OK ] $selector (") }==1)
    check(lines.count { it=="[  PASSED  ] 1 tests." }==1)
    check(lines.none { it.startsWith("[  FAILED  ]") })
    check(lines.count { it=="PASS_PUBLICNATIVE539,$point" }==1)
    val f=lines.single { it.startsWith("FIRSTNATIVE539,") }.split(',')
    check(f.size==4 && f[1]==point)
    first+=First(fork,point,f[2].toLong().also { check(it>0) },optional(f[3]))
    val expectedVariants=variants(shape).let { if(order=="reverse")it.reversed() else it }
    check(lines.single { it.startsWith("INVENTORYNATIVE539,") }=="INVENTORYNATIVE539,$point,${expectedVariants.joinToString(";")}")
    val actual=lines.filter { it.startsWith("PUBLICNATIVE539,") }.map { line->
        val c=line.split(',');check(c.size==9 && c[1].startsWith("$point/"))
        val variant=c[1].removePrefix("$point/");check(variant in variants(shape))
        Row(fork,point,variant,c[2].toInt(),c[3].toLong(),c[4].toLong(),optional(c[5]),optional(c[7]),c[8].toInt()).also {
            check(c[6]=="NA" && it.sample in 0..6 && it.elapsed>0 && it.count in 1L..8388608L && (it.count and (it.count-1))==0L && it.ns.isFinite())
        }
    }
    check(actual.map { it.variant to it.sample }==expectedVariants.flatMap { v->(0..6).map { v to it } })
    for(group in actual.groupBy { it.variant }.values)check(group.map { it.count }.distinct().size==1 && group.map { it.hash }.distinct().size==1)
    check(lines.indexOfFirst { it.startsWith("FIRSTNATIVE539,") }<lines.indexOfFirst { it.startsWith("PUBLICNATIVE539,") })
    val rss=lines.mapNotNull { Regex("\\s*([0-9]+)\\s+maximum resident set size").matchEntire(it)?.groupValues?.get(1)?.toLong() }.single()
    val footprint=lines.mapNotNull { Regex("\\s*([0-9]+)\\s+peak memory footprint").matchEntire(it)?.groupValues?.get(1)?.toLong() }.singleOrNull()
    check(rss>0 && (footprint==null || footprint>0))
    resources+=Resource(fork,point,rss,footprint)
    rows+=actual
}
check(root.listFiles()!!.filter { it.name.matches(Regex("fork[0-9]+-.*\\.log")) }.map { it.name }.toSet()==expectedLogs)
check(first.size==45 && rows.size==1260 && resources.size==45)
check(sha(checkNotNull(executable))==b("executable_sha256"))
for(group in rows.groupBy { it.point+"/"+it.variant }.values)check(group.map { it.hash }.distinct().size==1)
for(group in rows.groupBy { it.fork to it.point }.values) {
    check(group.filter { it.variant.startsWith("kernel") || it.variant.startsWith("frame") }.map { it.hash }.distinct().size==1)
    check(group.filter { it.variant in listOf("serial","parallel") }.map { it.hash }.distinct().size==1)
}
fun median(v:List<Double>):Double {val s=v.sorted();return if(s.size%2==1)s[s.size/2] else(s[s.size/2-1]+s[s.size/2])/2}
fun writeCsv(file:File,body:(java.io.PrintWriter)->Unit) {
    val writer=file.printWriter()
    try { body(writer);writer.flush();check(!writer.checkError()) { "CSV flush failed:$file" } }finally {writer.close()}
    check(!writer.checkError()) { "CSV close failed:$file" }
}
val target=File(root,"strict-results").also { check(!it.exists());check(it.mkdir()) }
writeCsv(File(target,"warm.csv")) { out->out.println("fork,point,variant,sample,count,elapsedNs,cpuNs,allocationBytes,lastGCHeapBytes,resultHash");for(r in rows)out.println("${r.fork},${r.point},${r.variant},${r.sample},${r.count},${r.elapsed},${r.cpu?:"NA"},NA,${r.heap?:"NA"},${r.hash}") }
writeCsv(File(target,"first.csv")) { out->out.println("fork,point,firstNs,cpuNs");for(f in first)out.println("${f.fork},${f.point},${f.ns},${f.cpu?:"NA"}") }
val medians=rows.groupBy { Triple(it.fork,it.point,it.variant) }.mapValues { (_,g)->median(g.map { it.ns }) }
writeCsv(File(target,"per-fork.csv")) { out->
    out.println("fork,point,variant,medianNs,minNs,maxNs,medianCpuNsPerOp")
    for((key,g)in rows.groupBy { Triple(it.fork,it.point,it.variant) }) {
        val cpu=g.mapNotNull { r->r.cpu?.toDouble()?.div(r.count) }
        out.println("${key.first},${key.second},${key.third},${medians.getValue(key)},${g.minOf { it.ns }},${g.maxOf { it.ns }},${if(cpu.size==g.size)median(cpu).toString() else "NA"}")
    }
}
writeCsv(File(target,"paired-all-comparators.csv")) { out->
    out.println("point,comparator,fork0ratio,fork1ratio,fork2ratio,medianPairedRatio,maxPairedRatio")
    for(size in sizes)for(shape in shapes)for(v in variants(shape).filter { it!="parallel" }+"fastest-matched-serial") {
        val point="$size/$shape"
        val ratios=(0..2).map { fork->
            val denominator=if(v=="fastest-matched-serial")variants(shape).filter { it!="parallel" }.minOf { medians.getValue(Triple(fork,point,it)) } else medians.getValue(Triple(fork,point,v))
            medians.getValue(Triple(fork,point,"parallel"))/denominator
        }
        out.println("$point,$v,${ratios.joinToString(",")},${median(ratios)},${ratios.max()}")
    }
}
writeCsv(File(target,"pooled.csv")) { out->
    out.println("point,variant,pooledMedianNs,minNs,maxNs,minBatchNs,maxBatchNs,cappedSamples")
    for((key,g)in rows.groupBy { it.point to it.variant })out.println("${key.first},${key.second},${median(g.map { it.ns })},${g.minOf { it.ns }},${g.maxOf { it.ns }},${g.minOf { it.elapsed }},${g.maxOf { it.elapsed }},${g.count { it.count==8388608L }}")
}
writeCsv(File(target,"first-summary.csv")) { out->out.println("point,medianFirstNs,minFirstNs,maxFirstNs");for((point,g)in first.groupBy { it.point })out.println("$point,${median(g.map { it.ns.toDouble() })},${g.minOf { it.ns }},${g.maxOf { it.ns }}") }
writeCsv(File(target,"whole-process-resources.csv")) { out->out.println("fork,point,wholeChildMaxRSSBytes,wholeChildPeakFootprintBytes");for(r in resources)out.println("${r.fork},${r.point},${r.rssBytes},${r.footprintBytes?:"NA"}") }
File(target,"SCOPE.txt").writeText("45FIRST/1260warm/45fresh identity PASS; no adoption verdict. FIRST is first PUBLIC call/activation attempt after school/oracle/BI preparation; not pristine whole-runtime coldness or matched first-serial speedup. EVERY public parallel operation pays Worker start/copy/localwork/accepted-child joins/termination/permit release; repeated rows never mean pool reuse. Allocation NA; last-GC heap sample is coarse historical GC state, not per-op retained/peak. Darwin time-l RSS/footprint cover whole completed child including preparation/allroutes/shutdown; not per-route peak. Latest native result only; no earlier-result immutability claim. All per-fork comparator ratios/adverse retained.\n")
File(root,"COMPLETE").writeText("Strict Native45FIRST/1260warm PASS; independent raw/adoption/resource review remains.\n")
println("PASS Native45FIRST/1260warm; all adverse retained")
