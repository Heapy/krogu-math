# Native actual public first/full-lifecycle campaign — SOURCE ONLY

No duplicate launcher. Owner536's existing `.codex-work/539/run-native-public.main.kts` is reused in place; he owns that file and actual assembly/build/run. This directory contains only backlog_coordinator's strict checker and preparation manifest. No shared source changes, dependency downloads, builds, or measurements have been run here. The manifest binds this preparation's actual fixture bytes and launcher bytes; it is not a future executable/build/runtime claim.

Future commands (substitute actual bindings after a successful composed Release build):

```sh
kotlinr /Users/yoda/dev/pet/krogu-math/.codex-work/539/run-native-public.main.kts TREE TREE_MANIFEST_SHA SOURCE_TSV SOURCE_SHA EXECUTABLE EXECUTABLE_SHA native-public-frontend RUNTIME_ID NEW_OUTPUT
kotlinr /Users/yoda/dev/pet/krogu-math/.codex-work/539/packaging/native-public-controller/check-native-public.main.kts NEW_OUTPUT
```

Reuse the reviewed539 standalone launcher model: exact artifact-tree manifest, original source TSV, executable SHA, self SHA, clean environment LANG/TZ+profile, selected Native test filter, observed actual executable PID/start independently of `/usr/bin/time`, bounded600s children/30min campaign admission and owned descendant/root termination on failure. Canonical input paths, actual inherited cwd and per-log profile/order/log SHA are retained. Existing launcher review is independent527's scope; this directory does not replace or duplicate it. Compiler/JDK/KotlinNative2.4.21/runtime/linked-library/source closure provenance belongs to the actual immutable build manifest and owner prelaunch ledger; runtimeId alone cannot prove it. Bind `/usr/bin/time`/macOS runtime identity in that ledger. Future fresh Native Release source/binary cannot be inferred from the earlier historical prototype75.

## Inventory derived from actual fixture

`src/nativeTest/kotlin/io/heapy/krogu/math/NativePublicFrontendCalibration539.kt`, selector `io.heapy.krogu.math.NativePublicFrontendCalibration539.optionalPublicRoute`, mode `native-public-frontend`:

- Sizes256/1024/4096/8192/16384 × distinct/square/ratio2 =15 points.
- Three **fresh point processes** each: forward/reverse/forward route order. The launcher retains the same point order in each fork; only route order reverses in the middle fork. No separate processes are presented as paired routes.
- Actual originating arrays/public operands and physical alias: a[i]=(i*104729+31)&MASK; distinct copy; square same object; ratio2 double-length MASK. Preparation, forced-school full expected result, conversions and input snapshots occur before counters; checks of full output/inputs happen after counters. Native calibration539Verify itself is a no-op, so this fixture's product reference is forced-school, not an invented independent Node/JDK oracle. Targeted public contract tests independently cover polynomial identities/boundaries/failures.
- Four routes in the **same fresh point process**: current configured kernel and serial frame (distinct K32/16/384, square/ratio2 K64/16/384), actual adaptive public `multiply`, actual public `parallelMultiply`. Eligible actual parallel children remain explicit K64/16; the generic raw route label is `parallel`, never `parallel32`. Below the public eligibility threshold this same public call falls back to current serial policy. Native native-result types escape unchanged. No timed byte conversion.
- Exactly45 FIRST and1260 warm rows (15×3×4×7). Warm-up200ms, adaptive20ms target, count powers-of-two1..8388608, three training batches and seven measured samples are unchanged fixture semantics.

The df733c0 fixture asserts selected K32 for physical distinct equal-length arrays and K64 for square/ratio2, with leaf16/entry384. Kernel and frame both execute that captured selected policy; public serial uses current adaptive policy. The separate public parallel engine remains explicit K64/16. Generic `serial`/`parallel` labels do not claim a different kernel policy. Any later policy change requires explicit fixture/label/checker source rebind; historical K64-only preparation is retained in history/pre-df733c0-k64-source-only and no old numerical evidence is relabelled. There is no exact-size eligibility whitelist: public candidate eligibility is the reviewed continuous balanced4096+ family/ratio<=2/CPU>2 with preacceptance fallback. Small points therefore remain real public serial-fallback observations; actual execution eligibility must be recorded by the actual host/contract evidence, not inferred from a FIRST row alone.

## FIRST, lifetime, resources and failures

FIRST means this fresh process's **first public call/activation attempt after untimed school/oracle/BI preparation**. It is not pristine process/JIT/allocator coldness, an independently instrumented first-accepted-child proof, or a paired first-serial speedup. Native uses no reused pool. Every eligible `parallelMultiply` operation in FIRST and repeated rows includes Worker creation, copies/local child, accepted-child joins, termination and permit release. Repeated rows warm arithmetic/runtime state; they never amortize Worker lifecycle out of the operation. Existing scheduler/lifecycle source and targeted join/permit/error tests remain separate proofs.

CPU is process clock when available, including Worker threads; caller allocation is NA. Native heap is last-GC total: a coarse sample potentially from an earlier collection, not per-operation live/retained/peak memory. Darwin `/usr/bin/time -l` maximum RSS and optional peak footprint cover the entire completed child, including preparation, all four routes, checks and final shutdown. They cannot be attributed to one route/operation. CPU/resource tradeoffs remain explicit adoption decisions; latency qualification alone is not adoption. No new performance threshold is introduced.

On nonzero exit, timeout, failed checks or missing resource/binding evidence there is no strict COMPLETE. Existing launcher owns cleanup and preserves partial logs/identities; checker never kills/restarts/retries. Native arithmetic failures are not retried by the production frontend. The collector reads existing raw files only after terminal, with no new numerical execution.

## Checker and output contract

Strict checker verifies45 unique actual Native PID/start pairs, separate wrapper identities, exact executable/filter/time argv, profile/order/source/artifact/runtime/log bindings, exact selected test RUN/OK/PASSED, one FIRST/PASS, exact four ordered groups×seven samples, count bounds/power-of-two/count stability, finite positive time and available nonnegative CPU/heap, allocation NA, stable result hashes within each native representation. IntArray hashes are compared only with other array routes; BigInteger hashes only between public routes. The latest result is observed; earlier-result immutability is not claimed.

`strict-results/`: raw warm/first cells, per-fork latency/ranges/CPU, pooled medians/ranges/batch durations/count caps, first distributions, all three pair ratios against every comparator plus fastest-matched-serial, and whole-child resource rows. All adverse observations remain. CSV writes explicitly check flush and close errors before COMPLETE. Strict inventory/stats PASS is not independent raw audit, selected-policy/public-route performance acceptance, resource approval, final paired28 public guard or full correctness acceptance. Those remain the existing539 obligations, without any additional gate.
