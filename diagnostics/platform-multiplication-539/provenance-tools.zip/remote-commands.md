# claws infrastructure (no numerical runs executed)

Remote root: `/home/kokoko/.local/share/krogu-math/perf`, owner kokoko, mode0700.
Existing BellSoft JDK25.0.4+9-LTS is symlinked from `toolchains/java-25.0.4-librca`.
Local raw audit: `claws-capabilities.txt`, `claws-java-staging.txt`.
These are observed binary hashes, not a reconstructed vendor archive signature.
No new JVM/Kotlin/Node distribution was installed or downloaded.

Always keep normal known-host verification (explicit strict mode verified):

```console
ssh -o BatchMode=yes -o ConnectTimeout=10 -o StrictHostKeyChecking=yes -o ControlMaster=no -o ControlPath=none claws ...
```

Disable connection multiplexing because its default socket path is outside the
local writable sandbox. This does not disable host-key checks or authentication.

A future authorized campaign must:

1. Freeze exact accepted source revisions and before/after source hashes, build
   locally with the pinned toolchain, and retain build logs. Both compared
   artifacts must contain the same accepted537/current-main basis for529 work.
2. List only actual needed JARs, compiled probe/adapter classes and explicit JVM
   runtime dependencies in a transfer manifest. No whole workspace, home, SSH
   files, Gradle caches, environment dump or credentials. Bound total campaign
   files to512MiB unless a concrete need is agreed with the coordinator.
3. Create a distinct task/campaign subdirectory below artifacts/runs. Verify
   uploaded bytes against full SHA256 before execution, plus pinned JDK runtime
   identity from the Java staging ledger. Never overwrite a different artifact
   under an existing hash-labelled name.
4. Use an explicit clean child environment, absolute Java path and arguments,
   fixed heap/GC flags, locale/TZ and only project-owned output paths. Do not
   inherit JAVA_TOOL_OPTIONS/JDK_JAVA_OPTIONS/_JAVA_OPTIONS or ambient secrets.
5. Retain exact argv/runtime/CPU topology/affinity/load, artifact origins and
   before/after hashes. Alternate fresh fork order. Use one heavy campaign per
   host, bounded wall deadline and owned process-group cleanup with survivors
   reported. GNUtimeout9.7 and taskset are available. Do not kill unrelated jobs.
6. Retrieve raw evidence and its SHA manifest, then coordinate normal cleanup of
   known owned temporary payload. Keep sufficient durable evidence for recovery.

The host is KVM: CPU steal/noisy neighbors are not controlled. Affinity can fix
logical CPU placement but cannot guarantee exclusive physical cores or host
load. No claims about platform-optimal thresholds follow from this audit.

535/597 coordinator received paths and full JDK hashes. Remote numeric execution
has not been started by this worker; setup is ready for the first source-approved
535/597 campaign. Node v24.16.0 Linuxx64 would match local records, but is not yet
installed and is unnecessary for the immediate Java-entry pipeline.
