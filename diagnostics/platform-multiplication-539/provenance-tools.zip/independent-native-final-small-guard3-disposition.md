# Native final paired small guard — actual67446



Independent raw PASSef4fe17a; two literal investigation flags. All28/raw/historical18flags retained. Ratios are current/baseline; absolute deltas ns. Neither flag is all-three-slower.



| Case | Trigger | Wall ratios F/R/F | Wall delta ns F/R/F | CPU ratios F/R/F | CPU delta ns F/R/F |
|---|---|---|---|---|---|
|parallel-public/63/distinct|True|1.160/0.762/2.391|11.256/-26.260/100.238|1.189/0.763/2.184|15.272/-31.616/98.076|
|public/63/distinct|False|1.020/1.001/1.473|1.402/0.069/33.103|1.035/1.012/1.480|2.819/1.469/39.135|
|public/30/distinct|True|1.570/1.276/0.934|7.772/6.171/-0.998|1.630/1.248/0.933|9.743/6.378/-1.140|
|parallel-public/30/distinct|False|1.485/1.135/0.985|7.762/3.495/-0.243|1.494/1.096/1.044|9.130/2.825/0.830|
|public/30/square|False|1.465/0.936/1.303|6.385/-1.559/4.456|1.486/0.961/1.367|7.561/-1.106/6.108|
|parallel-public/30/square|False|1.164/0.845/1.363|2.553/-4.015/6.434|1.180/0.869/1.364|3.144/-3.850/7.445|
|public/1023/square|False|0.592/1.208/0.958|-332.732/123.360/-20.173|0.604/1.178/0.961|-353.470/118.134/-19.714|
|parallel-public/1023/square|False|0.754/1.179/0.921|-198.428/114.684/-37.843|0.740/1.168/0.925|-231.506/117.279/-38.132|
|public/1023/distinct|False|0.748/1.485/1.005|-323.093/453.035/5.006|0.741/1.522/1.030|-354.279/521.698/29.358|
|parallel-public/1023/distinct|False|0.783/1.295/1.049|-319.570/323.891/44.009|0.805/1.354/1.066|-301.422/401.489/61.584|



**parallel-public/63/distinct**: Flagged mixed. Compactreceiver falls directly to virtual multiply before physicalhelpers/backend. Product overflows compact arithmetic into3word school; Native selected32metadata may be reached but noK32recursion/Arena. Sameinput ordinary ratios1.020/1.001/1.473 versus parallel1.160/.762/2.391 do not isolate a common scalar or addedwrappercause. CPU follows broad directions; no runtimecause observed.

**public/30/distinct**: Flagged mixed. Product fits compactLong and bypasses adaptive magnitude entirely. Compact arithmetic source unchanged; historical boundedNativeAOTnormalization showed samecompact operation skeleton, but not finalbinaryidentity/latencyproof. Parallel sameinput also first2slower/lastfaster, belowflag becausemedianratio1.135/delta3.495. No selectedK32 cause can explain ordinary30.

**public/30/square**: Preregistered unchangedcompactcontrol unflagged. Ratios1.465/.936/1.303; medianabsolute4.456ns belowfrozen5ns, not zerooverheadproof. Parallel samecontrolmixed/unflagged.

**public/1023/square**: Preregistered alias35word unchangedwhole-squareentry384 unflagged, wall.592/1.208/.958; parallel.754/1.179/.921. Oldall3materialflag no longer observed in thisset, not isolatedrecovery ornoiseproof.

**public/1023/distinct**: Preregistered changed35word physicaldistinctK32 vsold64school contrast unflagged/mixed .748/1.485/1.005. Reversepairadverse+453ns retained; neither universalbenefit nor controlledregression demonstrated. Parallel .783/1.295/1.049 also mixed; allbelow4096word backend admission.



The one preregistered Native28 diagnostic is complete and consumed. Accept execution/math/provenance/statistics; preserve both triggerflags and reversepair/controls. Do not certify absence of materialsmallpathregression or automatically adopt Nativefrontend from thisguard. No sourcefix is supported by these data, no additional run proposed. Actualpublic45FIRST/1260warm pending50930 supplies separate eligible-route/resource/lifetime evidence for final engineering disposition; it cannot erase these smallflags.

FinalNative adoption, if selected, must explicitly qualify these investigated unresolved smallpath observations rather than relabel strict arithmeticPASS as performancePASS. No blanketnoise waiver ornewscalar20/10rule.
