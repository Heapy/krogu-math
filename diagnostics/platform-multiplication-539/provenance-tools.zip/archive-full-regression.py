from pathlib import Path
import sys,hashlib,json,xml.etree.ElementTree as E,shutil
p=Path(sys.argv[1]).resolve();log=p/sys.argv[2];source=p/sys.argv[3];out=p/sys.argv[4];commit=sys.argv[5];handle=int(sys.argv[6]);out.mkdir(exist_ok=False);since=log.stat().st_birthtime
assert 'BUILD SUCCESSFUL' in log.read_text();entries=[];counts={}
for target in ['jvmTest','jsNodeTest','wasmJsNodeTest','macosArm64Test']:
 fs=sorted(f for f in (p/'worktree/build/test-results'/target).glob('*.xml') if f.stat().st_mtime>=since);assert fs,target;totals={k:0 for k in ['tests','failures','errors','skipped']};(out/target).mkdir()
 for f in fs:
  a=E.parse(f).getroot().attrib
  for k in totals:totals[k]+=int(a.get(k,0))
  dest=out/target/f.name;shutil.copy2(f,dest);entries.append({'path':str(dest),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
 assert all(totals[k]==0 for k in ['failures','errors','skipped']),totals
 counts[target]={'suites':len(fs),**totals}
lines=source.read_text().splitlines()
for r in lines:
 sha,path=r.split('\t');assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==sha,path
s={'status':'PASS','handle':handle,'exit_code':0,'source_commit':commit,'source_files':len(lines),'source_manifest':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'unfiltered':True,'counts':counts,'total_tests':sum(v['tests'] for v in counts.values()),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'xml':entries,'scope':'Actual unfiltered fourtarget correctness. Source and XML era explicit; no performance/adoption or natural cleanup inference.'};(out/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='xml'},indent=2))
