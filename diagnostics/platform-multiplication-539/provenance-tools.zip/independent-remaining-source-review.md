# Independent remaining-source review (539)

Source review PASS, with runtime/empirical acceptance pending. Reviewed frozen af1729f99a845ec390a2b8edba38944b6f11f036 against prior reviewed 0c3a20d761d7bdca6c9855e546abfea8fe5d2642; all 23 entries of remaining-source-review.json (SHA 60ccdecfed6a45bd6e38b26b347271350423d8ba2b332936ecb11d0370a5d9cb) were checked. Four subsequent Native/JVM hardening file deltas were reviewed separately before compilation.

Concrete findings fixed by owner:

- Nullable generic Worker/Future registration can box/allocate after native resource creation or accepted work. Local nonnullable handles now clean up the unregistered worker or consume the accepted Future before prior-owner cleanup. Primary failure identity is retained. Deterministic second-worker pre-store faults cover both boundaries and verify active workers/global permit recovery.
- JVM parallel logs previously lacked fresh-process identity. Probe now emits PID/start epoch and checker requires three unique positive identities.

The Native termination Future.result blocking join follows the official requestTermination contract: https://kotlinlang.org/api/core/kotlin-stdlib/kotlin.native.concurrent/-worker/request-termination.html . Active-worker equality remains an actual-runtime witness, not an assumed test result.

Reviewed ownership and bounded failure: common immutable borrowed input frame, child-owned scratch/output, join-before-combine, native invocation-owned workers, bounded global permits/nesting fallback, Node accepted-job draining and copied transfer buffers, SharedArrayBuffer status with synchronous MessagePort reads, owned process deadline cleanup. The unpublished JS/Wasm module compiles the exact original common kernel source paths; Wasm array copying is included rather than hidden. JVM setup/shutdown observation excludes awaited termination, explicitly documented; steady observations await old pool shutdown before next configuration.

Reviewed diagnostics: policy sweep/inventory including pure-square controls, both public methods' small guards, full forced-school comparisons on all common kernel/square targets, with external JDK expected-product validation on JVM only, setup outside counters, global result escape, warmup, exact samples and origins, fresh fork/sidecar requirements, CPU/allocation/heap/RSS semantics. Whole-process high water includes setup/runtime and idle worker pools; Native last-GC and JS parent heap are coarse observations; Wasm heap unsupported is NA. Logical payload excludes borrowed inputs/headers/scheduler and is not transport allocation or physical RSS.

No source blocker remains after fixes. This does not certify compilation, correctness tests, threshold optimality, actual worker portability, small-input performance, or adoption. Final accepted 537/529/597 composition, fresh source/artifact provenance, actual platform campaigns and measured adoption decisions remain required. No numerical jobs were launched by this review.

Final freeze independently verified: clean HEAD 72e1aa88fa078abbcf3844a0b746f6410d109b7b; all 23 entries match refreshed manifest SHA e21d84f5f5edc70024f85405823691bf4355ddb0a2ac2db09b08671ebaef55fd. Native proposal now documents guarded local handles at registration failures.

## Oracle scope clarification (source audit; no retrospective execution)

Historical JS/Wasm/Native `calibration539Verify` hooks are no-op. Their common kernel/square CHECKs compare full variant results against forced-school products; they did not execute Node BigInt/JDK validation. JVM kernel/square expected-product groups do execute the public JDK oracle outside timing. Private Node worker hosts execute actual public BigInt oracles, a different corpus. Public-small uses multiplication-free shifted/add polynomial expectations with offline exact REP auditing; primitive cost CHECK markers are not product-oracle checks. This clarification changes no raw rows/statistics or historical source/artifact identity. See independent-oracle-scope-requirement-review.json.
