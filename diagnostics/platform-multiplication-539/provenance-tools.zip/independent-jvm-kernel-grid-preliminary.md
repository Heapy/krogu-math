# Preliminary complete JVM kernel grid — not adoption

All417 configurations independently audited:384 forced-policy configurations and33 serial-frame controls. Source7821935; accepted529 parentc9415d55. Three fresh F/R/F processes per mode, seven samples per process. JSON companion retains every point, fork ratio, caller allocation and input-audit SHA. No new measurement or protocol change.

Ratios below are candidate/default64/16/384 within the same process, then median of three paired ratios. Adjacent means adjacent measured grid sizes; it does not establish monotonicity between them.

| Candidate / shape | Repeated evidence | Contra / cost | Remaining condition |
|---|---|---|---|
| K128, distinct (inactive-K control at8/16) | All3 lower observed times at adjacent8/16, ratios0.939/0.997; same school arithmetic below both K thresholds | No causal K128 gain at8/16; all3 adverse at31,96,128,192,384,1024,4096; ratio2.030 at128 withK256 reinforces no general higher-K gain | No useful threshold inferred; preserve public-small guard and complete controls |
| K32, square (inactive-K control at128/192) | Adjacent128/192 all3 lower times,0.992/0.963; both select identical whole-square path, K unused | Not causal K32 benefit;512 all3 slower1.148 is a separate active-recursion case | Small observed serial gain; pure-square control, allocation/ranges and final selected-route checks required |
| whole-square entry128, square | Adjacent256/383 all3 faster,0.891/0.851 | At384 both entries use the same recursive path yet entry128-labelled point is1.166; a variability control, not causal regression from entry128 | Separate square controls and final policy decision; no threshold from this pair |
| entry512, square (inactive-entry control at4096/8192) | Adjacent4096/8192 observed ratios0.755/0.829, but both e512/e384 select identical K64/leaf16 recursion | Against faster observed serial kernel/frame, fork ratios4096=0.765/1.005/0.827,8192=1.008/1.159/1.131;384/512 mixed/adverse; same caller allocation at8192 | These are duplicate-arithmetic/noise controls, not evidence for choosing entry512; actual active-entry square controls remain relevant |
| square leaf8, square (recursive activity must be verified) | Adjacent4096/8192 observed ratios0.875/0.769; whether leaf8 versus16 changes actual recursion leaves must be established before causal attribution | Faster-serial ratios4096=1.089/1.140/0.881,8192=1.052/1.123/0.931;32 and384 all3 slower | No general leaf replacement or parallel adoption; square controls and final public route remain |
| entry0, square (inactive-entry control at8192) |8192 isolated0.797, but both entries select the same recursive arithmetic |64 all3 slower1.557; allocation1096 versus528B/op. Against faster serial at8192 ratios1.051/1.114/0.986 | No causal8192 entry0 gain; no extension justified by this inactive control alone |
| K32, ratio4 |63 and96 individually all3 faster,0.722/0.862 |64 between them is mixed1.064;32/256/384/1024 all3 slower;63 allocation2640 versus1280B/op | Not adjacent support or a monotone threshold; keep allocation tradeoff and public guards |

**Serial tuning has no newly imposed20%/10% gate.** Its decision retains the existing calibration method: actual paired consistency, practical observed gain, allocation/resource tradeoffs, square controls and final selected-policy/public guards. The frozen20%median/10%everypair/two-adjacent rule applies ONLY to actual PARALLEL adoption including lifecycle cost.

For descriptive context, applying those numbers to these serial candidates yields no two adjacent points against the faster observed kernel/frame comparator. That is neither a rejection criterion for scalar thresholds/square leaves nor evidence about the unmeasured worker route. Actual parallel candidates and the public serial comparator where distinct remain to be measured and judged under their own frozen rule.

Source activity matters: whole-square selection bypasses K entirely; entry values above/below the actual size can select the same path. Parameter-labelled timing differences on identical arithmetic are controls for run/JIT/host variation, not proof the parameter caused them. In particular this report does not recommend entry512 from large-size observations.

The grid does not yet include separate24 square-control,5 cost,28 public-small,60 JVMparallel lifecycle/resource observations, or final selected-policy guards. Those remain existing planned work. The same complete required scope on JS/Wasm/Native remains unchanged. Current defaults are the control; this report adopts no new policy, threshold, global optimum or cross-platform result.

Per-operation caller allocation is distinct from scratch payload or retained size. Coarse heap and whole-process RSS include setup/reference/runtime. Ring checksums for measured batches below64 do not isolate a single result; full untimed school/JDK checks remain the arithmetic evidence, as recorded in each raw audit.
