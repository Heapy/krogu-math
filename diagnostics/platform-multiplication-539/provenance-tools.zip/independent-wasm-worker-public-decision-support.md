# Wasm105 private worker decision support — not public adoption

Fresh07910edf source:68594/6738/29558,strict45211 and independent raw/statistics/binding PASS.105 cases/2205 WORKER/315 PUBLICRESULT/105 CHECKperfork. All105 case process medians/ranges,30worker comparisons and module/pool controls are in the audit JSON. JS observations and historical partials are not pooled.

Fastest actual same-fork serial comparator includes public multiply:public33/45operand-fork points,kernel8,frame4. Frozen PARALLEL screen is median wall ratio≤.80 and every fork≤.90 plus two adjacent measured sizes; no scalar tuning gate or automatic adoption.

| Shape/workers | Qualifying measured sizes | Adjacent support |
|---|---|---|
|distinct/worker1|||
|distinct/worker2|4096,8192,16384|4096→8192,8192→16384|
|square/worker1|4096,16384||
|square/worker2|4096,8192,16384|4096→8192,8192→16384|
|ratio2/worker1|4096,8192,16384|4096→8192,8192→16384|
|ratio2/worker2|4096,8192,16384|4096→8192,8192→16384|

Worker2 has consistent latency eligibility4096→8192→16384 for allthree shapes. Worker1 ratio2 also does; worker1 distinct has no qualifying point, and square4096/16384 are isolated because8192 fails. Only17/30worker cases are faster in every fork;6 are slower in every fork and7 mixed. The six robust adverse cases are all256word shapes/workercounts:distinct/worker2 ratios1.605/1.624/6.452, square/worker2 1.715/1.687/1.778, ratio2/worker2 1.352/1.259/1.136; all worker1 counterparts are also slower. No cause is assigned to the6.452 outlier.

| Actual worker2 point | Wall / fastest same-fork serial | ProcessCPU / same comparator |
|---|---|---|
|4096/distinct/worker2|0.488/0.424/0.672 (public,public,public)|1.244/1.118/1.470|
|8192/square/worker2|0.625/0.415/0.660 (kernel,public,kernel)|1.411/1.134/1.586|
|8192/ratio2/worker2|0.539/0.533/0.517 (public,frame,public)|1.031/1.025/0.974|
|16384/distinct/worker2|0.447/0.382/0.419 (kernel,public,public)|1.234/1.078/1.134|
|16384/ratio2/worker2|0.553/0.550/0.630 (public,public,public)|1.075/1.071/1.207|

CPU is whole-process including child workers, not caller-only. For8192 square/worker2 CPU ratios1.411/1.134/1.586 accompany wall.625/.415/.660; for16384ratio2/worker2 CPU1.075/1.071/1.207 accompanies wall.553/.550/.630. Latency improvement does not establish CPU/energy or memory improvement. Allocation remainsNA.

## Actual lifetime/resource boundaries

- Tiny parent module import2.803/1.282/2.157ms; root-library+Mocha load/registration140.833/100.524/189.927ms. The latter is diagnostic registration setup, not a measured standalone public library first invocation.
- Two-worker ready startup35.553/28.684/47.721ms lies outside steady rows. RSS before/after pool168.788→191.037MB,168.952→191.152MB,169.476→193.020MB is a raw global startup contrast, not exact retained worker bytes.
- Warm reused rows include actual Wasm per-word bridge/copy, postMessage/transfer, worker common kernel, wait/join/recombine; parent public comparator includes callback dispatch and actual BI result publication retained in Kotlin.
- Awaited termination is outside WORKER rows. Child exit0 occurs after cleanup, so termination completed, but no elapsed teardown or per-invocation create/terminate measurement exists. No amortization or break-even count is invented.
- HeapUsed is parent-isolate Node memory only, with no independently established exact WasmGC coverage; it excludes isolated child heaps as an owned metric. RSS/maxRSS includes root/Mocha/reference/idleworkers/priorcases. Maximum sampled RSS1,038,811,136B and cumulative highwater1,014,464KiB are whole-process observations, not per-op peak or owned memory. Public verification happens before memory sampling, outside timing/CPU counters.

## Existing bounded-extension decision

A hypothetical reused worker2 policy starting conservatively at4096 is an interior measured threshold with adjacent4096/8192 and8192/16384 support, and measured lower1024 does not qualify. Existing criteria do not force another size merely to locate an exact mathematical crossover; a narrower desired threshold would require its own preregistered bounded neighbor check. No extension is presently necessary just to support the observed4096candidate.

Worker1 square cannot use isolated upper-edge16384 as a threshold claim:8192 fails and no larger neighbor is measured. If that particular family is actually selected, existing bounded adjacent extension/two-adjacent policy requires a finite neighbor/control before adoption; there is no reason to launch it merely because an isolated point exists. Worker1 distinct offers no latency-eligible selection to extend. This is a conditional remaining-scope decision, not rejection of all possible transports or a new universal gate.

No public Wasm/Node frontend is adopted. The private diagnostic module/harness does not prove browser/target-wide synchronous public API compatibility, global scheduler resource ownership, real public frontend materialization/dispatch/lifecycle cost, exception contracts or final public-small guards. Those existing choices/controls and Native evidence remain separate. No reviewer runtime/source changes were made.
