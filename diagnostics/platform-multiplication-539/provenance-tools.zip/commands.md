# Current execution ledger

Actual accepted529 parent: `c9415d55fe8d9a743266e75709cf95738011d311`.
Composed source: `c41f8d93088ca818b523b4daaa29f3049b8ba612`.
Commands and outcomes: focused-jvm-invocation.json / focused-jvm-1-summary.json
(61339,7PASS+JAR) and focused-other-invocation.json / focused-other-1-summary.json
(21677,JS3/Wasm3PASS; Native compile opt-in failure). Initial JVM kernel-small74535 executed147cases/3087TIME, strict46612 PASS;
medium189 handle1102 is live. No threshold/adoption accepted.
Native-only retry26974:6PASS under reviewed7821935; native-retry-source-before.json
and focused-native-2-summary.json bind the annotation-only fix.
Opt-in discovery40778 and build12573 terminal0; immutable21 artifacts bound.
First kernel-small strictPASS; remainingcommon modes exactargv frozen in
jvm-remaining-common-prelaunch-batch.json; different parallel lifecycle separately reviewed.

Frozen criteria: independent-preflight-adoption-protocol.json, unchanged.

## Historical command preparation and governing protocol

# 539 execution preparation — UNRUN

Do not execute before the coordinator grants this host's slot. Final calibration
requires accepted537 + accepted529 + current main. Current source parent781d961
is not the final measurement basis. Refresh all source/artifact manifests after
composition and peer review. One heavy job per host; no SSH during another owner’s
remote series without explicit coordination.

## Fresh build and source binding

Record exact git HEAD/status, the full production/test/diagnostic source SHA
manifest BEFORE and AFTER each fresh build, raw build logs and toolchain versions.
Use the exact BellSoft25.0.4+9-LTS JAVA_HOME and Kotlin2.4.21. `jvmTest` does NOT
replace explicit `jvmJar` when freezing the library artifact. Package the exact
compiled JVM test probe classes and needed Kotlin runtime JARs separately; bind
their code origins and SHA, not a stale build/libs file. Record argv/flags and
clear ambient Java/Kotlin runner injection options.

Native requires the opt-in calibration539 RELEASE test binary. The property
`multiplication539=true` also includes the unpublished JS/Wasm diagnostic module.
This build type is ordinary optimized Kotlin/Native, not a new backend or custom
compiler experiment. Resolve actual task/output names from the final Gradle task
model before running; don't relabel an existing DEBUG test as RELEASE evidence.

Portable common test entry: `MultiplicationCalibration539.optionalCampaign`.
On JVM direct fork entry is `io.heapy.krogu.math.MultiplicationCalibration539JvmMain`
with one argument, for example `kernel-small,forward,7,20`. JS/Wasm/Native receive
that same configuration via ONLY the explicit `KROGU539_ARGS` variable; select
only the calibration test in the test executable/runner. Native adds mode
`native-parallel`; it creates/joins/terminates owned workers per timed invocation.
Do not accidentally benchmark the entire unfiltered unit suite's process memory.

Each portable raw fork log needs sidecars produced by the owning launcher:

```text
<log>.exit: exact numeric process exit status after terminal
<log>.binding:
source_manifest_sha256=<full compiled-source manifest digest>
artifact_manifest_sha256=<exact linked artifact tree/runtime dependency digest>
runtime_id=<explicit pinned version/platform/build-type/flags identity>
pid=<actual child PID>
start_epoch_ms=<actual launch timestamp>
```

Capture actual terminal status, retain partial raw output on timeout, verify all
artifacts and sources again after the process. The checker validates these fields;
it does not manufacture source equivalence or prove a forged sidecar truthful.
Use three fresh processes, order forward/reverse/forward (or reversed counterpart).
Bound each process and whole campaign; broad school-reference preparation may be
slow and is outside timing. A deadline hit is incomplete evidence, not a PASS.

```console
kotlinr scripts/check-portable-multiplication-539.main.kts 7 kernel-small JVM SOURCE_MANIFEST_SHA ARTIFACT_MANIFEST_SHA new.csv fork1.log fork2.log fork3.log
```

Use the actual digests, not the literal placeholders above. The source-bound
baseline/candidate must share accepted537/currentmain except the evaluated539
policy route, or for529 comparisons except529 itself. Pair public-small exact
REP rows and compare every case; do not aggregate away individual regressions.

## JVM parallel experiment

Direct entry: `io.heapy.krogu.math.ParallelCalibration539JvmMain`, six arguments:
`forward|reverse samples main.jar mainSHA probe.jar probeSHA`. Use the normal
processor count, not the deterministic source-test override. The same kernel and
frame comparisons, separate fresh-pool observation, approximate all-thread
allocation, process CPU and pool-peak upper bound are emitted. Add whole-process
RSS externally, with reference preparation/runtime overhead explicit.

```console
kotlinr scripts/check-parallel-calibration-539.main.kts 7 MAIN_SHA PROBE_SHA new.csv fork1.log fork2.log fork3.log
```

## JS/Wasm worker experiment

Build the optional unpublished module with production executable optimization.
Package ONLY one linked JS or Wasm tree, inventory every file with full SHA256
(`hash  relative/path`), and exclude unrelated output/caches. The driver compiles
the SAME original kernel/policy source paths directly and has no library dependency.
Root-library public-small guards remain separate: the module is not evidence of
compact529 frontend costs by itself.

```console
kotlinr scripts/measure-worker-transport-539.main.kts NODE ARTIFACT_DIRECTORY ENTRY_RELATIVE SHA_MANIFEST NEW_OUTPUT js forward 7
kotlinr scripts/check-worker-transport-539.main.kts 7 js MANIFEST_SHA NODE_SHA CAPTURE_SCRIPT_SHA aggregate.csv fork1 fork2 fork3
```

Repeat for Wasm using its own tree/manifest and `wasm` label. Node must bev24.16.0;
Linux and Darwin binaries have different exact SHA values. The host callback is
private to this module, no public-library API. Worker inputs are exclusive copies;
only those copies may be transferred. The original caller arrays are compared in
full after each case. Shared atomic state and synchronous MessagePort reads do not
need parent event-loop callbacks while blocked. Deadline/failure aborts the owned
campaign and terminates its pool; it must not continue with abandoned readers.

HeapUsed is parent realm only; RSS/highwater include all workers, reference
preparation and earlier cases. These are NOT exact per-operation/owned-object
sizes. Use separate scoped fresh processes if a final memory decision needs to
attribute a difference to one policy; do not interpret cumulative highwater as a
per-case memory reduction. Wasm copies and per-word bridge cost belong to this
candidate, not a universal lower bound for all possible transports.

No threshold or public parallel route is adopted by any checker. Final source
review, explicit target decision, small guards, four-target focused/full checks
and measured CPU/latency/memory tradeoffs remain task acceptance gates.
