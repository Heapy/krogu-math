# Independent medium-kernel raw audit reproduction

Reanalyses retained outputs only; no benchmark launched.

```sh
python3 - <<'PY'
from pathlib import Path
import json,csv,re,hashlib,statistics as st,math
p=Path('.codex-work/539');d=p/'calibration-jvm-kernel-medium-1';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
summary=json.loads((p/'calibration-jvm-kernel-medium-1-summary.json').read_text());pre=json.loads((p/'jvm-kernel-medium-1-prelaunch.json').read_text())
assert summary['exit']==summary['checker_exit']==0
assert all(sha(p/f)==h for f,h in summary['files'].items())
assert sha(p/summary['csv'])==summary['csv_sha256']
policies=list(dict.fromkeys([(x,16,384) for x in [32,64,128,256]]+[(64,x,384) for x in [4,8,16,32]]+[(64,16,x) for x in [0,128,256,384,512,1024]]))
ids=[]
for n in [96,128,192,256,383,384,512]:
 for shape in ['distinct','square','ratio2','ratio4']:
  ids += [f'kernel/{n}/{shape}/k{k}-s{s}-e{e}' for k,s,e in policies if shape=='square' or (s,e)==(16,384)]
  if n>=64 and shape!='ratio4':ids += [f'frame-serial/{n}/{shape}']
assert len(ids)==189 and len(set(ids))==189
allrows={};identities=[];hashes={};envelopes=[];tree=Path(pre['argv'][2])
for i in range(3):
 f=d/f'fork{i}.log';lines=f.read_text().splitlines();binding=dict(x.split('=',1) for x in Path(str(f)+'.binding').read_text().splitlines())
 assert Path(str(f)+'.exit').read_text().strip()=='0'
 assert binding['source_manifest_sha256']==pre['argv'][5] and binding['artifact_manifest_sha256']==pre['argv'][3]
 identity=re.search(r'# OWN539 pid=(\d+) start_epoch_ms=(\d+) max_heap=(\d+) flags=(.+)',f.read_text());pid,start,heap,flags=identity.groups()
 assert int(pid)>0 and int(start)>0 and int(heap)==536870912
 assert binding['pid']==pid and binding['start_epoch_ms']==start
 assert '-Xms256m' in flags and '-Xmx512m' in flags and '-XX:+UseG1GC' in flags
 identities.append((pid,start));order='reverse' if i==1 else 'forward'
 header=next(x for x in lines if x.startswith('# calibration539 '));assert f'mode=kernel-medium order={order} cases=189' in header and 'JVM BellSoft 25.0.4+9-LTS aarch64' in header
 for cls,j in [('MagnitudeMultiplication','main.jar'),('MultiplicationPolicy539','main.jar'),('MultiplicationCalibration539JvmMain','probe.jar'),('MultiplicationCampaign539','probe.jar')]:assert f'# ORIGIN539 {cls}={tree/j}' in lines
 checks=[x.split(',')[1] for x in lines if x.startswith('CHECK539,')];assert checks==(list(reversed(ids)) if i==1 else ids)
 assert lines.count('PASS539,189,7')==1
 argv=Path(str(f)+'.argv.txt').read_text().splitlines();assert argv[-1]==f'kernel-medium,{order},7,20' and argv[:2]==['/usr/bin/time','-l']
 rows=list(csv.reader(x for x in lines if x.startswith('TIME539,')));assert len(rows)==1323
 group={}
 for row in rows:
  assert len(row)==9;_,name,sample,count,wall,cpu,allocation,coarse,digest=row
  assert name in ids and 0<=int(sample)<7 and 0<int(wall)<=60_000_000_000
  count=int(count);assert count>0 and count<=8388608 and count&(count-1)==0
  assert all(int(x)>=0 for x in [cpu,allocation,coarse]);assert -(2**31)<=int(digest)<2**31
  group.setdefault(name,[]).append({'sample':int(sample),'count':count,'wall':int(wall),'cpu':int(cpu),'allocation':int(allocation),'heap':int(coarse),'digest':int(digest)})
 assert set(group)==set(ids)
 for name,rr in group.items():
  assert len(rr)==7 and {r['sample'] for r in rr}==set(range(7)) and len({r['count'] for r in rr})==1
  assert len({r['digest'] for r in rr})==1
  hashes.setdefault(name,set()).update(r['digest'] for r in rr)
 allrows[i]=group
 rss=re.search(r'^\s*(\d+)\s+maximum resident set size$',f.read_text(),re.M);peak=re.search(r'^\s*(\d+)\s+peak memory footprint$',f.read_text(),re.M)
 assert rss and peak
 envelopes.append({'fork':i,'whole_process_rss_bytes':int(rss[1]),'whole_process_peak_footprint_bytes':int(peak[1])})
assert len(set(identities))==3 and all(len(v)==1 for v in hashes.values())
result=[]
for name in sorted(ids):
 groups=[allrows[i][name] for i in range(3)]
 wall=[st.median(r['wall']/r['count'] for r in rr) for rr in groups]
 cpu=[st.median(r['cpu']/r['count'] for r in rr) for rr in groups]
 alloc=[st.median(r['allocation']/r['count'] for r in rr) for rr in groups]
 result.append({'case':name,'wall_median_ns':st.median(wall),'wall_min_process_median_ns':min(wall),'wall_max_process_median_ns':max(wall),'cpu_median_ns':st.median(cpu),'caller_allocated_median_bytes':st.median(alloc),'coarse_heap_max_bytes':max(r['heap'] for rr in groups for r in rr),'fork_wall_ns':wall,'fork_cpu_ns':cpu,'fork_allocated_bytes':alloc})
csvrows=list(csv.DictReader((p/summary['csv']).open()));assert len(csvrows)==189
for own,r in zip(csvrows,result):
 assert own['case']==r['case']
 for k in ['wall_median_ns','wall_min_process_median_ns','wall_max_process_median_ns','cpu_median_ns','caller_allocated_median_bytes','coarse_heap_max_bytes']:assert math.isclose(float(own[k]),r[k],rel_tol=1e-14,abs_tol=1e-9),(k,r['case'],own[k],r[k])
byid={r['case']:r for r in result};comparisons=[]
for r in result:
 parts=r['case'].split('/');base='kernel/'+parts[1]+'/'+parts[2]+'/k64-s16-e384';b=byid[base]
 ratios=[x/y for x,y in zip(r['fork_wall_ns'],b['fork_wall_ns'])];alloc=[x-y for x,y in zip(r['fork_allocated_bytes'],b['fork_allocated_bytes'])]
 assert hashes[r['case']]==hashes[base],r['case']
 comparisons.append({'case':r['case'],'same_operand_baseline':base,'paired_ratios':ratios,'median_ratio':st.median(ratios),'fork_allocated_delta_bytes':alloc,'all3_slower':all(x>1 for x in ratios),'all3_faster':all(x<1 for x in ratios)})
for h,f in [line.split('\t') for line in Path(pre['argv'][4]).read_text().splitlines()]:assert sha(Path(f))==h
assert all(sha(Path(f))==h for f,h in pre['runtime_files'].items())
for h,f in [line.split('\t') for line in (tree/'manifest.sha256').read_text().splitlines()]:assert sha(tree/f)==h
r={'status':'INDEPENDENT_INITIAL_JVM_MEDIUM_RAW_BINDING_STATS_PASS_NOT_ADOPTED','handle':summary['handle'],'source':summary['source'],'cases':189,'TIME':3969,'CHECK_per_process':189,'fresh_process_identities':identities,'source_files_verified':378,'all_owner_csv_statistics_exact':True,'all_case_sample_and_cross_process_digest_consistency':True,'all_same_operand_policy_and_frame_digests_equal':True,'process_envelopes':envelopes,'per_case':result,'relative_to_current64_16_384_policy':comparisons,'scope':'Initial189 kernel-medium policies/frame comparisons only. Same-process paired ratios compare prepared identical operands; not fresh baseline/candidate frontend runs. Full othermodes/platforms/parallel/startup/resource/selectedpolicy/publicguards still pending. Caller allocation excludesworker threads; coarse heap and wholeprocessRSS include setup/reference/runtime. No threshold/optimality/adoption claim.'}
(p/'independent-jvm-kernel-medium-1-raw-audit.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS3969TIME/189exactCSV,3freshPID/digests/source/artifacts')
print('RELATIVE default all3slower',[(x['case'],round(x['median_ratio'],3)) for x in comparisons if x['all3_slower']])
PY
```
