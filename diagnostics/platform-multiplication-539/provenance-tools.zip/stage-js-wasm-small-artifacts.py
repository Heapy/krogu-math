from pathlib import Path
import json,hashlib,shutil,base64,re,zipfile
p=Path(__file__).resolve().parent;wt=p/'worktree';commit='cd231a59c65ef3261f9379e106b436e17114b946'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def manifest(tree):
 f=tree/'manifest.sha256'
 if f.exists():f.unlink()
 f.write_text(''.join(sha(x)+'\t'+str(x.relative_to(tree))+'\n' for x in sorted(tree.rglob('*')) if x.is_file()));return sha(f)
source=p/'js-wasm-small-source.tsv'
for line in source.read_text().splitlines():
 h,path=line.split('\t');assert sha(Path(path))==h,path
log=p/'js-wasm-small-production-build-1.log';assert 'BUILD SUCCESSFUL' in log.read_text()
summary={'source':commit,'handle':86702,'exit_code':0,'focused_handle':71151,'source_files_post_match':405,'source_manifest_sha256':sha(source),'log_sha256':sha(log),'roots':{}}
for target in ['js','wasmJs']:
 old=p/f'artifacts/root-{target}-thin-2d74b64';new=p/f'artifacts/root-{target}-small-cd231a5';shutil.copytree(old,new)
 shutil.rmtree(new/'probe');producer=wt/f'build/compileSync/{target}/test/testProductionExecutable/kotlin';shutil.copytree(producer,new/'probe')
 actual={str(f.relative_to(producer)):sha(f) for f in producer.rglob('*') if f.is_file()};copied={str(f.relative_to(new/'probe')):sha(f) for f in (new/'probe').rglob('*') if f.is_file()};assert actual==copied
 summary['roots'][target]={'tree':str(new),'manifest_sha256':manifest(new),'probe_producer':str(producer),'all_probe_files_equal_producer':True,'files':len([f for f in new.rglob('*') if f.is_file()])-1}
jvm=p/'artifacts/jvm-small-cd231a5';shutil.copytree(p/'artifacts/jvm-js-small-f918115',jvm)
producer=wt/'build/libs/krogu-math-jvm-0.1.0-SNAPSHOT.jar';shutil.copy2(producer,jvm/'main.jar')
classes={}
for root in [wt/'build/classes/kotlin/jvm/test',wt/'build/classes/java/jvmTest']:
 if root.exists():
  for f in root.rglob('*'):
   if f.is_file():
    name=str(f.relative_to(root));assert name not in classes or classes[name]==f.read_bytes();classes[name]=f.read_bytes()
with zipfile.ZipFile(jvm/'probe.jar','w',zipfile.ZIP_DEFLATED) as z:
 for name,b in sorted(classes.items()):z.writestr(name,b)
summary['jvm']={'tree':str(jvm),'main_producer':str(producer),'main_sha256':sha(producer),'main_equal_actual71151_producer':sha(producer)==sha(jvm/'main.jar'),'probe_entries':len(classes),'probe_class_entries':sum(k.endswith('.class') for k in classes),'manifest_sha256':manifest(jvm),'probe_compiler_roots':[str(wt/'build/classes/kotlin/jvm/test'),str(wt/'build/classes/java/jvmTest')]}
ledger=p/'js-wasm-small-artifacts.json';assert not ledger.exists();ledger.write_text(json.dumps(summary,indent=2)+'\n')
payloads=[]
for target,kind in [('js','JS'),('wasmJs','Wasm')]:
 tree=p/f'artifacts/node-payload-{target}-cd231a5';tree.mkdir();producer=wt/f'nodeWorker539/build/compileSync/{target}/main/productionExecutable/kotlin';shutil.copytree(producer,tree/'compiler')
 generated=wt/f'nodeWorker539/build/generated/payload/{target}/io/heapy/krogu/math/EmbeddedNodeWorker539.kt';shutil.copy2(generated,tree/generated.name)
 body=generated.read_text().split('(): String = ',1)[1];literals=re.findall(r'"(?:\\.|[^"\\])*"',body);payload=json.loads(''.join(json.loads(s.replace('\\$','$')) for s in literals));assert payload['protocol']=='krogu539.v1'
 expected={x['name']:base64.b64decode(x['base64'],validate=True) for x in payload['files']};nonmaps={f.name:f.read_bytes() for f in producer.iterdir() if f.is_file() and not f.name.endswith('.map')};assert expected==nonmaps;assert payload['identity']==hashlib.sha256(b''.join(nonmaps[k] for k in sorted(nonmaps))).hexdigest()
 for x in payload['files']:assert x['sha256']==hashlib.sha256(expected[x['name']]).hexdigest()
 old=p/f'artifacts/node-payload-{target}-2d74b64';assert generated.read_bytes()==(old/generated.name).read_bytes(),'Unexpected worker payload change'
 files=[{'path':str(f.relative_to(tree)),'bytes':f.stat().st_size,'sha256':sha(f),'equal_producer':f.read_bytes()==(producer/f.name).read_bytes()} for f in sorted((tree/'compiler').iterdir()) if f.is_file()];assert all(x['equal_producer'] for x in files)
 equality={'source':commit,'platform':kind,'identity':payload['identity'],'entry':payload['entry'],'decoded_nonmap_bytes':sum(map(len,expected.values())),'all_actual_compiler_payload_bytes_equal':True,'generated_source_sha256':sha(generated),'original_compiler_root':str(producer),'copied_compiler_files':files,'byte_equal_historical_2d74_and_consumer033_payload':True,'scope':'Current producer/generated/copy equality, possibly UP-TO-DATE. Scoped unchanged payload/transport/packaging carryforward; not a new consumer execution claim.'};(tree/'payload-byte-equality.json').write_text(json.dumps(equality,indent=2)+'\n')
 props=tree/'payload-identity.properties';props.write_text(f"protocol=krogu539.v1\nkind={kind}\nidentity={payload['identity']}\nproducerCommit={commit}\ngeneratedSource={tree/generated.name}\nworkerEntry={tree/'compiler'/payload['entry']}\nproducerBuildLedger={ledger}\npayloadEqualityLedger={tree/'payload-byte-equality.json'}\n")
 tsv=p/f'node-payload-{target}-cd231a5.tsv';tsv.write_text(''.join(sha(f)+'\t'+str(f)+'\n' for f in sorted(tree.rglob('*')) if f.is_file())+sha(ledger)+'\t'+str(ledger)+'\n');payloads.append({'platform':kind,'payload_manifest':str(tsv),'payload_manifest_sha256':sha(tsv),'identity':payload['identity'],'decoded_nonmap_bytes':sum(map(len,expected.values())),'properties_sha256':sha(props)})
(p/'js-wasm-small-payload-bindings.json').write_text(json.dumps({'source':commit,'payloads':payloads},indent=2)+'\n');print(json.dumps(summary,indent=2))
