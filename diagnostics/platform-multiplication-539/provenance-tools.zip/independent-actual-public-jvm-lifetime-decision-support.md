# Actual JVM frontend lifetime decision support

All eight actual eligible points pass frozen reused-pool latency margin against the fastest same-fork kernel/frame/public serial route, with two adjacent measured sizes per shape. This is latency eligibility, not adoption.

| point | parallel / fastest serial, forks0/1/2 | process CPU ratios | approximate allocation delta, B |
|---|---|---|---|
| 256/distinct | 1.067 / 1.166 / 1.001 | 1.071 / 1.185 / 0.998 | 0 / 32 / 0 |
| 256/square | 1.291 / 1.244 / 1.416 | 1.281 / 1.242 / 1.393 | -8560 / -8560 / -8560 |
| 256/ratio2 | 1.194 / 1.305 / 0.996 | 1.182 / 1.287 / 0.996 | 0 / 0 / 0 |
| 1024/distinct | 1.145 / 1.017 / 1.034 | 1.021 / 1.017 / 1.027 | 32 / 0 / 0 |
| 1024/square | 1.098 / 1.083 / 1.295 | 1.103 / 1.080 / 1.300 | 32 / 32 / 32 |
| 1024/ratio2 | 1.013 / 1.086 / 1.008 | 1.056 / 1.091 / 1.004 | -3 / 0 / 0 |
| 4096/distinct | 0.440 / 0.412 / 0.506 | 1.236 / 1.182 / 1.432 | 98238 / 98316 / 98299 |
| 4096/square | 0.395 / 0.538 / 0.640 | 1.127 / 1.490 / 1.589 | 90080 / 90056 / 455 |
| 4096/ratio2 | 0.893 / 0.940 / 0.964 | 0.876 / 1.119 / 0.952 | 0 / 40 / 0 |
| 8192/distinct | 0.349 / 0.417 / 0.355 | 1.021 / 1.218 / 1.051 | 196654 / 406 / 196598 |
| 8192/square | 0.399 / 0.447 / 0.387 | 1.173 / 0.965 / 1.137 | 180206 / 180964 / 180186 |
| 8192/ratio2 | 0.629 / 0.565 / 0.754 | 1.254 / 1.159 / 1.485 | 395 / 114978 / 115072 |
| 16384/distinct | 0.432 / 0.475 / 0.413 | 1.255 / 1.237 / 1.132 | -84 / 393032 / 393000 |
| 16384/square | 0.378 / 0.391 / 0.339 | 1.295 / 1.047 / 1.005 | 308 / 360176 / 128 |
| 16384/ratio2 | 0.671 / 0.617 / 0.514 | 1.336 / 1.231 / 1.022 | 260 / 229596 / 229548 |

Distinct/square4096–16384 and ratio28192–16384 qualify; ratio2 size means longerside, so4096 remains serial min2048. Lower/adverse fallback observations stay visible.

FIRST is actual startup cost after JDK/input preparation, not matched fresh-lifetime speedup. Warm calls reuse the real bounded defining-classloader pool. CPU rises as high as1.589x; approximate live-thread allocation delta reaches393032B. Observer bookkeeping/terminated-thread limits apply. Wholechild RSS includes preparation/JDK/allroutes/runtime, not per-operation owned memory.

Known shared-host Java activity and later idle sample do not prove continuous quiet or identify a cause for individual results. Final paired public guard and resource tradeoff judgment remain; full2108 correctness is separately PASS.
