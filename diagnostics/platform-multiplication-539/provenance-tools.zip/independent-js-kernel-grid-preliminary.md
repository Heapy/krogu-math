# Preliminary JS serial policy grid — complete417 kernel cases, not a policy choice

Adapts the existing JVM grid analysis. Uses independently accepted small/medium/large-2 audits (417 configurations, 8757 TIME rows); JSON retains every forced-policy point, actual three fork ratios, paired median, adjacent measured-size observations and activity classification. No new measurement. Large-2 completed all81 configurations; aborted large-1 remains separate partial evidence.

Ratios are candidate/default64/16/384 within each fresh process, in F/R/F order. Adjacent means adjacent measured sizes, not all integer sizes or monotonic behavior. **The20%/10% margin is PARALLEL-only and is not a serial gate here.**

| Candidate / shape | Actual three-fork evidence | Contra / activity / remaining condition |
|---|---|---|
| K32 / distinct | All3 faster at every measured point32–512:32=.798/.748/.464;96=.679/.802/.664;256=.822/.839/.814;512=.798/.851/.840 | K changes recursion at32+ relative to64;8/16/31 remain identical school arithmetic. Strong provisional serial candidate, not a final threshold: selected-route controls and both-API public guard pending; large extension below accepted |
| K32 / ratio2 |32/63/64/96/128/192 and383/384 all3 faster;383=.854/.796/.806,384=.835/.824/.807 |256=.875/1.254/.601 and512=1.075/.738/.859 are mixed. No universal unbalanced win or monotone threshold |
| K32 / ratio4 |32=.649/.694/.797,128=.867/.890/.851,383=.807/.834/.782,512=.841/.885/.941 |192=.526/1.194/.821 and256=.923/1.220/.949 mixed.16 all3 adverse1.323/1.384/1.059 despite same school arithmetic;31 lower timings also inactive-K control. Distinguish active recursion from variability |
| K128 / distinct | Active cases64=1.385/1.301/1.060;128=1.214/1.436/1.380;512=1.273/1.272/1.428, all adverse | Higher threshold not supported on these active points; retained JSON includes K256 and every mixed/adverse point. No rule inferred from inactive small sizes |
| Whole-square entry128 / square |128=.529/.654/.541;192=.556/.471/.484;256=.449/.350/.460;383=.607/.360/.295; all3 faster | Default whole-square versus candidate recursion differs here. At384 and512 both use same recursion, yet ratios=.939/1.224/1.027 and.969/1.003/1.169: explicit variability controls. Separate square24 controls required; large grid extension below is accepted |
| Whole-square entry0 / square |64=.818/.887/.901;128=.559/.545/.541;256=.409/.458/.458;383=.415/.364/.359 | Entry0/128 at128+ below384 select the same K64/leaf16 recursion; differences between their observed timings are not a causal entry0-vs128 effect. At384/512 default already recursive; no causal entry0 benefit there |
| Square leaf8 / square |64=.999/.995/.840;96=.900/.778/.903;192=.784/.491/.834;256=.958/.804/.850 | All these use identical whole-square arithmetic, so no causal leaf8 gain.63 all3 slower1.138/1.049/1.075 on same path.384=.987/1.091/1.078 and512=.948/.981/1.068 mixed; actual recursive leaf activity must be established before attribution |

Entry512/1024 and leaf4/32 observations remain fully represented in JSON. When both configurations select whole-square, K is unused and changing an entry/leaf label without changing the selected arithmetic is a run/JIT/host variability control. Below both K thresholds, distinct/unbalanced paths are school arithmetic; above thresholds a changed K alters splitting/base decisions, but this analysis does not reconstruct value-dependent sum lengths or invent leaf counts.

No final JS scalar policy is selected. Remaining existing conditions: square24 controls, cost5 scope, public28 both-API baseline and eventual matched selected-route guards, allocation/resource limitations, and composed correctness. Other targets retain their full required grids. JS allocation is NA, not zero; heapUsed and whole-process RSS include unrelated lifetime state. Existing ring caveat remains: batches under64 do not isolate per-case cross-fork hashes; full untimed CHECKs supply arithmetic evidence.

## Accepted large-2 extension (81 cases,1701 TIME, independent PASS)

All81 CHECKs and567 TIME rows complete in each of three fresh processes under the reviewed1200s JS-large deadline. No partial rows from large-1 are pooled.22 configurations are slower in all3 pairs and19 faster relative to default (including serial-frame controls); all mixed/adverse points remain in JSON.

| Candidate / shape | Large three-fork ratios at1024;4096;8192 | Conditional conclusion |
|---|---|---|
| K32 / distinct |.836/.697/.885; .829/.870/.848; .899/.858/.866 | Extends all3 faster measured points32–8192 with active K recursion. Useful candidate for selected-policy controls, not final JS adoption |
| K32 / ratio2 |1.082/.788/.809; .926/1.192/.928; .921/.973/.857 | Mixed1024/4096, all3 faster8192 only; do not extend distinct-input consistency to all shapes |
| K32 / ratio4 |.788/.904/1.066; .809/.754/.874; .615/.877/.824 | Adjacent4096/8192 all3 faster, but1024 mixed and earlier192/256 mixed; full resource/public judgement remains |
| K32 / square |.769/.761/1.047;1.011/.841/.865;.871/.878/.863 | Only8192 all3 faster; cannot claim universal K32 square improvement |
| Entry128 / square |1.001/.890/.815;1.195/1.350/.990;.619/.691/.985 | All these select identical K64/leaf16 recursion as default.8192 observed win and4096 adverse pair are variability controls, not causal entry128 evidence |
| Entry512 / square |1.003/1.151/.796;1.031/1.880/.990;.616/.884/.987 | Same recursive arithmetic as entry384 at these sizes; no causal entry512 conclusion |
| Leaf8 / square |.732/.794/.960;1.262/.990/.974;.620/.606/.989 | Actual leaf activity still needs proof; mixed4096 interrupts adjacent consistency despite1024/8192 observed wins |

Allocation remainsNA. All81 large configurations have at least one measured batch below64; seven within-case sample digests are stable, but those rings do not certify isolated cross-fork results. The complete untimed CHECK inventory is the separate arithmetic proof. Runtime/loaded CJS containment, source378, artifact/runtime hashes, three actual process identities and all CSV wall/CPU/heap statistics independently match. Scalar selection still awaits square/public controls; the20/10 margin remains exclusively parallel.

## Separate square controls accepted (24 cases /504 TIME)

Recursion-only e0 versus current e384 at128=.506/.639/.551,192=.379/.521/.522,256=.374/.438/.430 reinforces the active medium-square recursion advantage observed in the policy grid. These are actual three fork ratios; no parallel margin is applied. The fixed whole-square MAX control is substantially slower than default recursion at384=2.088/2.511/2.372,512=3.171/2.886/2.964 and1024=3.546/6.452/4.465. e1024 is likewise slower at384 and512.

Controls also expose variability on identical arithmetic: MAX/e1024/default at128–256 all select whole-square; MAX128 still appears lower. e0/default at384 and512 both select K64/leaf16 recursion, yet observed e0 ratios=.839/.999/.911 and.603/.907/.998. Those differences cannot establish a causal e0 benefit. At1024 e1024 is already recursive (strict size<entry), matching default arithmetic; its mixed ratios remain variability evidence. Thus the useful conclusion is bounded active-route evidence favouring recursion over whole-square on measured medium sizes, not a claim that entry0 is universally optimal or that every same-path variation is a threshold effect.

All24 configurations have sub64 measured-batch ring limits; complete untimed CHECKs are the arithmetic proof. AllocationNA, exact process stats/closure/source bindings and all adverse remain in the separate audit. Final selected-policy/public guard and cost/public observations remain pending; no production policy is adopted.
