from pathlib import Path
import sys,json,re,hashlib,statistics,csv
p=Path(sys.argv[1]);out=Path(sys.argv[2]); assert not out.with_suffix('.json').exists()
med=statistics.median; variants=['kernel','frame','public','parallel']; points=[f'{s}/{h}' for s in [256,1024,4096,8192,16384] for h in ['distinct','square','ratio2']]
allrows={};first=[];identities=[];files=[]
for fork in range(3):
 for point in points:
  f=p/f'fork{fork}-{point.replace("/","-")}.log';text=f.read_text();lines=text.splitlines();assert Path(str(f)+'.exit').read_text().strip()=='0';assert lines.count('PASS_ACTUAL_PUBLIC539')==1
  identity=[x for x in lines if x.startswith('METAPUBLIC539,')];assert len(identity)==1;identities.append(identity[0]);
  rawfirst=[x.split(',') for x in lines if x.startswith('FIRSTPUBLIC539,')];assert len(rawfirst)==1;v=rawfirst[0];assert len(v)==5 and v[1]==point;first.append({'fork':fork,'point':point,'wall_ns':int(v[2]),'cpu_ns':int(v[3]),'allocation_bytes_approx':int(v[4])})
  activity=[x for x in lines if x.startswith('ACTIVITYPUBLIC539,')];assert len(activity)==1
  rows=[x.split(',') for x in lines if x.startswith('WARM_PUBLIC539,')];expected=[f'{point}/{v}' for v in (variants[::-1] if fork==1 else variants) for _ in range(7)];assert [r[1] for r in rows]==expected
  for var in variants:
   rs=[r for r in rows if r[1]==f'{point}/{var}'];assert len(rs)==7 and all(len(r)==7 for r in rs);assert [int(r[2]) for r in rs]==list(range(7));assert len({int(r[3]) for r in rs})==1
   ns=[int(r[4])/int(r[3]) for r in rs];cpu=[int(r[5])/int(r[3]) for r in rs];alloc=[int(r[6])/int(r[3]) for r in rs];assert min(ns)>0
   allrows[fork,point,var]={'wall_median_ns':med(ns),'wall_min_ns':min(ns),'wall_max_ns':max(ns),'cpu_median_ns':med(cpu),'allocation_median_bytes_approx':med(alloc),'count':int(rs[0][3]),'samples_wall_ns':ns,'activity':activity[0]}
  files.append({'path':str(f),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
assert len(set(identities))==45
summary=[]
for point in points:
 ratios=[];cpu_ratios=[];alloc_deltas=[]
 for fork in range(3):
  serial=min((allrows[fork,point,v] for v in variants[:3]),key=lambda r:r['wall_median_ns']);par=allrows[fork,point,'parallel'];ratios.append(par['wall_median_ns']/serial['wall_median_ns']);cpu_ratios.append(par['cpu_median_ns']/serial['cpu_median_ns']);alloc_deltas.append(par['allocation_median_bytes_approx']-serial['allocation_median_bytes_approx'])
 summary.append({'point':point,'parallel_vs_fastest_matched_serial_fork_ratios':ratios,'median_ratio':med(ratios),'all_pairs_10pct':max(ratios)<=.90,'median_20pct':med(ratios)<=.80,'cpu_ratios_same_wall_comparator':cpu_ratios,'allocation_delta_bytes_approx':alloc_deltas,'first_wall_ns':[r['wall_ns'] for r in first if r['point']==point]})
d={'status':'PASS_STRICT_OWNER_SUMMARY','FIRST':45,'WARM':1260,'point_summaries':summary,'first':first,'fork_stats':[{'fork':k[0],'point':k[1],'variant':k[2],**v} for k,v in allrows.items()],'files':files,'scope':'Current actual public frontend. FIRST activation after untimed arithmetic/JDK preparation, no matched FIRST serial speed claim. Warm route reuses defining-classloader pool. Live-thread allocation approximate including observer bookkeeping and may miss terminated threads; whole-process RSS not owned/per-operation peak. Shared unisolated host; see host-before snapshot. No automatic adoption.'}
out.with_suffix('.json').write_text(json.dumps(d,indent=2)+'\n')
with out.with_suffix('.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
print(json.dumps({'status':d['status'],'FIRST':45,'WARM':1260,'eligible_latency_points':[x['point'] for x in summary if x['all_pairs_10pct'] and x['median_20pct']]}))
