#!/usr/bin/env kotlinr
// External Native paired28 BOTH-APIs guard; no numerical implementation.
// Usage: kotlinr THIS baselineTree baselineManifestSHA currentTree currentManifestSHA sourceTSV sourceSHA runtimeId NEWoutput
// Then shared owner536 checker (not executed here): python3 check-public-paired-guard.py ROOT Native CURRENT_SOURCE_SHA BASELINE_MANIFEST_SHA CURRENT_MANIFEST_SHA NEW_OUTPUT_PREFIX
// Six A/B,B/A,A/B children; each28IDs x7samples and28REP. Flag percase only:
// median(current_i/baseline_i)>1.15 AND median(current_i-baseline_i)>5ns.
// Flags require investigation, not automatic parity/adoption; every adverse/raw/NA retained.
import java.io.File
import java.nio.file.Files
import java.security.MessageDigest
import java.time.Instant
import java.util.concurrent.TimeUnit
require(args.size==8) { "baselineTree baselineManifestSHA currentTree currentManifestSHA sourceTSV sourceSHA runtimeId NEWoutput" }
fun sha(f:File):String=MessageDigest.getInstance("SHA-256").let { digest->
    f.inputStream().buffered().use { input->val bytes=ByteArray(65536);while(true){val n=input.read(bytes);if(n<0)break;digest.update(bytes,0,n)} }
    digest.digest().joinToString("") { "%02x".format(it) }
}
val taskRoot=File("/Users/yoda/dev/pet/krogu-math/.codex-work/539").canonicalFile
val launcher=File(taskRoot,"run-native-public-paired-guard.main.kts")
val launcherSha=sha(launcher)
val helper=File(taskRoot,"check-public-paired-guard.py")
val helperSha=sha(helper)
val trees=listOf(File(args[0]).canonicalFile,File(args[2]).canonicalFile)
val manifestHashes=listOf(args[1],args[3])
val source=File(args[4]).canonicalFile
val runtimeId=args[6].also { require(it.isNotBlank() && '\n' !in it) }
val output=File(args[7]).canonicalFile
val cwd=File(".").canonicalFile
val time=File("/usr/bin/time").canonicalFile.also { require(it.isFile && it.canExecute()) }
val timeSha=sha(time)
require(output.toPath().startsWith(taskRoot.toPath()) && !output.exists())
fun parse(file:File):List<Pair<String,String>> = file.readLines().map { line->
    val f=line.split('\t');require(f.size==2 && f[0].matches(Regex("[a-f0-9]{64}")) && f[1].isNotBlank());f[0] to f[1]
}.also { require(it.isNotEmpty() && it.map { p->p.second }.distinct().size==it.size) }
val sources=parse(source).map { (hash,name)->
    val raw=File(name);require(raw.isAbsolute && !Files.isSymbolicLink(raw.toPath()))
    hash to raw.canonicalFile.also { require(it.isFile && it.toPath().startsWith(taskRoot.toPath())) }
}
val bound=trees.mapIndexed { index,tree->
    require(tree.isDirectory && !Files.isSymbolicLink(tree.toPath()))
    val manifest=File(tree,"manifest.sha256");check(sha(manifest)==manifestHashes[index])
    parse(manifest).map { (hash,name)->
        require(!File(name).isAbsolute && name.split('/').none { it in listOf(".","..","") })
        val raw=File(tree,name);require(!Files.isSymbolicLink(raw.toPath()))
        hash to raw.canonicalFile.also { require(it.isFile && it.toPath().startsWith(tree.toPath())) }
    }.also { require(it.map { p->p.second }.distinct().size==it.size) }
}
val executables=trees.mapIndexed { index,tree->File(tree,"calibration539.kexe").canonicalFile.also { f->check(f.canExecute() && f in bound[index].map { it.second }) } }
// Explicit historical pre-Native-public-hook/default64 baseline, never labelled final-source.
val baselineCommit="841a8b8e111856e05d524e1b653bb1a54a68ba5e"
val baselineExecutableSha="6d457e607eac78906374e11a52e15c0730a0f0a21868301c4ef8490ff22ebd33"
check(bound[0].single { it.second==executables[0] }.first==baselineExecutableSha)
val executableHashes=bound.mapIndexed { i,files->files.single { it.second==executables[i] }.first }
fun verify() {
    check(sha(launcher)==launcherSha && sha(helper)==helperSha && sha(source)==args[5] && sha(time)==timeSha)
    for((hash,file)in sources+bound.flatten())check(sha(file)==hash) { "Changed bound file:$file" }
    for((index,tree)in trees.withIndex()) {
        check(sha(File(tree,"manifest.sha256"))==manifestHashes[index])
        val actual=tree.walkTopDown().onEnter { check(!Files.isSymbolicLink(it.toPath()));true }.filter { it.isFile }.map { check(!Files.isSymbolicLink(it.toPath()));it.canonicalFile }.toSet()
        check(actual==bound[index].map { it.second }.toSet()+File(tree,"manifest.sha256"))
    }
}
verify();check(output.mkdirs())
var currentProfile:String?=null
fun clean(builder:ProcessBuilder) {
    builder.environment().clear();builder.environment()["LANG"]="C";builder.environment()["TZ"]="UTC"
    currentProfile?.let { builder.environment()["KROGU539_ARGS"]=it }
}
fun execute(command: List<String>, log: File, seconds: Long, executable: File) {
    File(log.path + ".argv.txt").writeText(command.joinToString("\n", postfix = "\n"))
    val builder = ProcessBuilder(command).directory(cwd).redirectErrorStream(true).redirectOutput(log)
    clean(builder)
    val child = builder.start()
    val childDeadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(seconds)
    var completed = false
    var failure: Throwable? = null
    try {
        File(log.path + ".identity.txt").writeText("pid=${child.pid()} start=${child.toHandle().info().startInstant().orElse(null)}\n")
        // Capture the actual owned executable identity, not merely /usr/bin/time.
        val identityDeadline = minOf(childDeadline, System.nanoTime() + TimeUnit.SECONDS.toNanos(5))
        var nativeIdentity: ProcessHandle? = null
        while (nativeIdentity == null && child.isAlive && System.nanoTime() < identityDeadline) {
            nativeIdentity = (child.toHandle().descendants().toList() + child.toHandle()).firstOrNull { handle ->
                handle.info().command().orElse(null)?.let { File(it).canonicalFile == executable } == true
            }
            if (nativeIdentity == null) Thread.sleep(10)
        }
        val native = checkNotNull(nativeIdentity) { "Owned Native executable identity not observed" }
        val start = native.info().startInstant().orElseThrow()
        File(log.path + ".native-identity.txt").writeText("pid=${native.pid()} start_epoch_ms=${start.toEpochMilli()} executable=$executable\n")
        completed = child.waitFor(maxOf(1L, childDeadline - System.nanoTime()), TimeUnit.NANOSECONDS)
        check(completed) { "Deadline: $log" }
        check(child.exitValue() == 0) { "Child failed: $log exit=${child.exitValue()}" }
    } catch (caught: Throwable) {
        failure = caught
        throw caught
    } finally {
        if (!completed || child.isAlive) {
            var cleanupFailure: Throwable? = null
            fun record(caught: Throwable) {
                if (cleanupFailure == null) cleanupFailure = caught else cleanupFailure!!.addSuppressed(caught)
            }
            val descendants = try { child.toHandle().descendants().toList() }
                catch (caught: Throwable) { record(caught); emptyList() }
            for (handle in descendants.asReversed() + child.toHandle()) {
                try { handle.destroyForcibly() } catch (caught: Throwable) { record(caught) }
            }
            val until = System.nanoTime() + TimeUnit.SECONDS.toNanos(10)
            val capturedInterrupt = Thread.interrupted()
            var interrupted = capturedInterrupt || failure is InterruptedException
            for (handle in descendants + child.toHandle()) {
                while (handle.isAlive && System.nanoTime() < until) {
                    try { handle.onExit().get(maxOf(1L, until - System.nanoTime()), TimeUnit.NANOSECONDS); break }
                    catch (_: InterruptedException) { interrupted = true }
                    catch (_: java.util.concurrent.TimeoutException) { break }
                    catch (caught: Throwable) { record(caught); break }
                }
            }
            val survivors = descendants.filter { it.isAlive }.map { it.pid() }
            if (child.isAlive || survivors.isNotEmpty())
                record(IllegalStateException("Owned cleanup survivors=$survivors rootAlive=${child.isAlive}"))
            if (interrupted) Thread.currentThread().interrupt()
            if (cleanupFailure != null) {
                if (failure != null) failure.addSuppressed(cleanupFailure!!) else throw cleanupFailure!!
            }
        }
    }
}

File(output,"binding-before.txt").writeText("timestamp=${Instant.now()}\nlauncher_sha256=$launcherSha\nchecker_path=$helper\nchecker_sha256=$helperSha\nsource_manifest_path=$source\nsource_manifest_sha256=${args[5]}\nbaseline_manifest_path=${File(trees[0],"manifest.sha256")}\nbaseline_manifest=${args[1]}\ncurrent_manifest_path=${File(trees[1],"manifest.sha256")}\ncurrent_manifest=${args[3]}\nbaseline_source_commit=$baselineCommit\nbaseline_executable_sha256=$baselineExecutableSha\ncurrent_executable_sha256=${executableHashes[1]}\ntime_path=$time\ntime_sha256=$timeSha\ncwd=$cwd\nruntime_id=$runtimeId\n")
File(output,"SOURCE-ERA-SCOPE.txt").writeText("Baseline compiled841a8b8/pre-Native-public-hook/default64 is historical. Current source manifest binds the current-source validation/campaign, NOT the historical baseline compiled source. Immutable baseline executable SHA is pinned separately. Actual Release/compiler/runtime/OS linkage ledgers remain owner prelaunch bindings. Darwin time-l resources cover each whole child, not a case peak. Caller allocationNA and coarse last-GC sample remain explicit; partial64-ring digest does not replace full untimed polynomialREP/CHECK. No automatic guard/adoption acceptance.\n")
val deadline=System.nanoTime()+TimeUnit.MINUTES.toNanos(30)
val identities=mutableSetOf<String>()
for(fork in 0..2) {
    val order=if(fork==1)"reverse" else "forward"
    for(index in if(fork==1)listOf(1,0) else listOf(0,1)) {
        verify()
        val label=if(index==0)"baseline" else "current"
        val executable=executables[index]
        val log=File(output,"fork$fork-$label.log")
        currentProfile="public-small,$order,7,20"
        val command=listOf(time.path,"-l",executable.path,"--ktest_filter=io.heapy.krogu.math.MultiplicationCalibration539.optionalCampaign")
        val seconds=minOf(600L,TimeUnit.NANOSECONDS.toSeconds(deadline-System.nanoTime()));check(seconds>0)
        execute(command,log,seconds,executable)
        val lines=log.readLines()
        check(lines.count { it.startsWith("TIME539,") }==196 && lines.count { it.startsWith("REP539,") }==28)
        check(lines.count { it.startsWith("CHECK539,") }==28 && lines.count { it=="PASS539,28,7" }==1)
        val identity=File(log.path+".native-identity.txt").readText().trim()
        val parsed=checkNotNull(Regex("pid=([0-9]+) start_epoch_ms=([0-9]+) executable=(.+)").matchEntire(identity))
        val pid=parsed.groupValues[1];val start=parsed.groupValues[2]
        check(pid.toLong()>0 && start.toLong()>0 && File(parsed.groupValues[3]).canonicalFile==executable && identities.add("$pid/$start"))
        File(log.path+".binding").writeText("label=$label\nsource_manifest_sha256=${args[5]}\nartifact_manifest_sha256=${manifestHashes[index]}\nruntime_id=$runtimeId\npid=$pid\nstart_epoch_ms=$start\nlog_sha256=${sha(log)}\nprofile=$currentProfile\norder=$order\nexecutable_sha256=${executableHashes[index]}\n")
        verify()
        File(log.path+".exit").writeText("0\n")
        println("COMPLETE paired Native public28 fork=$fork label=$label order=$order")
    }
}
File(output,"EXECUTED_NOT_YET_GUARD_VALIDATED").writeText("Six fresh alternating children exit0;1176TIME/168REP. Strict shared helper and independent raw audit pending. Smallguard percase BOTH APIs medianratio>1.15 AND medianabsolutedelta>5ns triggers investigation; no row/adverse/NA filtered, no automatic parity or adoption verdict.\n")
File(output,"CHECKER-COMMAND.txt").writeText(listOf("python3",helper.path,output.path,"Native",args[5],args[1],args[3],File(output,"paired-guard").path).joinToString("\n",postfix="\n"))
println("PASS execution only; shared strict28case paired guard and independent audit remain")
