from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent;out=p/'packaging/native-serial-retention';tools=out/'tools';tools.mkdir(exist_ok=True)
s=(p/'run-native-public.main.kts').read_text().replace('run-native-public.main.kts','run-native-public-retained.main.kts').replace('native-public-frontend','native-public-serial-retention').replace('// Actual Native public frontend: fresh point processes, full per-operation Worker lifetime. No numerical implementation.','// Current Native public serial-retention: fresh point processes; no numerical implementation or Worker activation claim.')
needle='        check(lines.count { it == "PASS_PUBLICNATIVE539,$size/$shape" } == 1)';assert s.count(needle)==1
s=s.replace(needle,needle+'\n        check(lines.count { it.startsWith("INPUTNATIVE539,$size/$shape,") } == 1)\n        check(lines.count { it.startsWith("NATIVESERIALDECLINE539,$size/$shape,") } == 8)\n        check(lines.count { it.startsWith("NATIVESERIALRESOURCE539,$size/$shape,NONE_STARTED,") } == 1)')
(tools/'run-native-public-retained.main.kts').write_text(s)
s=(p/'packaging/native-public-controller/check-native-public.main.kts').read_text().replace('// Strict Native public first/full-lifecycle result checker. No numerical execution.','// Strict current Native public serial-retention checker. No numerical execution.').replace('native-public-frontend','native-public-serial-retention')
needle='    val f=lines.single { it.startsWith("FIRSTNATIVE539,") }.split(\',\')';assert s.count(needle)==1
extra='''    val input=lines.single { it.startsWith("INPUTNATIVE539,") }.split(',')
    check(input==listOf("INPUTNATIVE539",point,size.toString(),(if(shape=="ratio2")2*size else size).toString(),(shape=="square").toString()))
    val absence=lines.filter { it.startsWith("NATIVESERIALDECLINE539,") }.map { it.split(',') }
    check(absence.size==8 && absence.all { it.size==7 && it[1]==point && it[4]==it[5] && it[6]=="true" })
    check(absence.map { it[2] to it[3] }==listOf("first" to "-1")+(0..6).map { "parallel" to it.toString() })
    check(absence.map { it[4] }.distinct().size==1)
    val workerIds=if(absence.first()[4].isEmpty())emptyList() else absence.first()[4].split(';').map(String::toInt)
    check(workerIds.all { it>=0 } && workerIds==workerIds.distinct().sorted())
    val resource=lines.single { it.startsWith("NATIVESERIALRESOURCE539,") }.split(',')
    check(resource==listOf("NATIVESERIALRESOURCE539",point,"NONE_STARTED",absence.first()[4],"true"))
    check(lines.indexOfFirst { it.startsWith("FIRSTNATIVE539,") } < lines.indexOfFirst { it.startsWith("NATIVESERIALDECLINE539,") })
    check(lines.indexOfFirst { it.startsWith("NATIVESERIALDECLINE539,") } < lines.indexOfFirst { it.startsWith("PUBLICNATIVE539,") })
    check(lines.indexOfFirst { it.startsWith("NATIVESERIALRESOURCE539,") } > lines.indexOfLast { it.startsWith("PUBLICNATIVE539,") })
    for(sample in 0..6) {
        check(lines.indexOfFirst { it.startsWith("NATIVESERIALDECLINE539,$point,parallel,$sample,") } >
            lines.indexOfFirst { it.startsWith("PUBLICNATIVE539,$point/parallel,$sample,") })
    }
'''
s=s.replace(needle,extra+needle)
start=s.index('File(target,"SCOPE.txt").writeText(');end=s.index('\nFile(root,"COMPLETE")',start)
scope='45FIRST/1260warm/45fresh identities on current Native serial-retention route. FIRST is first PUBLIC serial call after untimed school/oracle/BI preparation and baseline Worker.current observation; not Worker activation or matched fresh speedup. Both operand word lengths and physical alias recorded. Eight outside-counter baseline Native Worker-ID equality observations per point plus terminal equality complement separately bound compiled direct-virtual fallback; these are no-new-worker observations, not active Worker cleanup or a trace inside arithmetic. Retained candidate per-call Worker lifecycle/9wins/resources remain in original aa9 artifacts and are not these serial rows. Allocation NA; last-GC heap is coarse historical/global, not per-op retained/peak. Darwin RSS/footprint cover whole completed process, not owned/per-route peak. Latest native result only. All comparator ratios/adverse preserved; no latency adoption verdict.'
s=s[:start]+'File(target,"SCOPE.txt").writeText('+json.dumps(scope+'\n')+')'+s[end:]
s=s.replace('println("PASS Native45FIRST/1260warm; all adverse retained")','println("PASS Native serial-retention45FIRST/1260warm; all adverse retained")')
(tools/'check-native-public-retained.main.kts').write_text(s)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
(out/'tools-manifest.json').write_text(json.dumps({'files':[{'staged':str(f.relative_to(out)),'future_path':str(p/f.name),'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(tools.iterdir())]},indent=2)+'\n')
