# JS105 private worker decision support — latency eligibility, not public adoption

Only fresh07910edf campaign93365/9727/3365:105cases,2205WORKER,315PUBLICRESULT and105CHECKperprocess. Strict49217 and independent raw/statistics/binding audit PASS. Historical98636deadlinepartial is excluded. JSON companion audit retains all105 per-case process medians/ranges,30 worker comparisons and every public hash/control/identity.

Comparator is the fastest actual kernel/frame/public serial process median for identical operands in each fork. Of45 operand/fork points, public16/frame16/kernel13 are fastest. Frozen PARALLEL latency eligibility is median ratio≤.80 and every fork≤.90 plus adjacent measured sizes. This is not a scalar tuning criterion or automatic adoption.

| Shape/workers | Qualifying measured sizes | Adjacent support |
|---|---|---|
|distinct/worker1|256||
|distinct/worker2|256,1024,4096,8192,16384|256→1024,1024→4096,4096→8192,8192→16384|
|square/worker1|256,1024,16384|256→1024|
|square/worker2|256,1024,4096,8192,16384|256→1024,1024→4096,4096→8192,8192→16384|
|ratio2/worker1|256,1024,4096,8192|256→1024,1024→4096,4096→8192|
|ratio2/worker2|256,1024,4096,8192,16384|256→1024,1024→4096,4096→8192,8192→16384|

Worker2 passes this latency screen for all15shape/size points, including256. Its lower threshold is NOT identified:256 is the smallest sampled size, not a proven crossover or public cutoff. Worker1 is not uniformly stable:1024distinct has a1.422 adverse pair,4096square1.006,16384distinct1.063,16384ratio2 has1.031/1.104. Total26/30workerpoints faster in every fork;4mixed,0slower in every fork. Allmixed points remain, and a failed margin is distinct from a regression.

| Actual worker2 point | Wall / fastest serial by fork | Process CPU / same comparator |
|---|---|---|
|256/distinct/worker2|0.558/0.389/0.521 (public,kernel,frame)|1.298/0.869/1.193|
|4096/distinct/worker2|0.406/0.602/0.455 (public,public,frame)|1.190/1.673/1.340|
|8192/square/worker2|0.441/0.548/0.481 (public,public,kernel)|1.284/1.551/1.430|
|16384/distinct/worker2|0.394/0.803/0.607 (frame,public,public)|1.131/1.643/1.741|
|16384/ratio2/worker2|0.672/0.601/0.757 (public,frame,kernel)|1.279/1.150/1.472|

CPU is whole-process, including worker threads. It is not caller CPU or an allocation proxy: faster wall time can consume more CPU (16384distinct/worker2 up to1.741×;8192square/worker2 up to1.551×). Across all worker points/pairs CPU ratios span.869–2.451. Allocation isNA, notzero. No memory or power optimum is inferred.

## Actual lifetime and memory boundaries

- Parent tiny-module import:2.508/4.452/3.022ms. Root public-library plus Mocha load/registration:243.040/400.451/407.531ms, separately reported. This root registration cost is diagnostic configuration load, not a measured standalone library first-call cost.
- Two-worker ready startup:30.964/61.907/41.575ms, outside WORKER rows. Raw process RSS before/after pool is301.302→322.847MB,301.154→323.715MB,301.384→324.026MB. These contrasts include runtime/allocator startup activity; not exact retained pool bytes.
- Rows measure actual warm reused pool and include bridge/copies/postMessage/child execution/join/recombination. Public comparator includes its public callback dispatch/multiply/result publication; it holds the actual BI inside Kotlin root state, not a converted result.
- Awaited worker termination is outside rows. Successful process exit is after cleanup, so teardown completed; no elapsed teardown number or per-call construct/terminate cost is inferred. No amortization/break-even call count is invented.
- Per-case heap is parent realm only, and is sampled after full public verification. It excludes isolated worker heaps; RSS/maxRSS includes both idle workers even on serial rows, root/Mocha/reference state and prior samples. Maximum sampled RSS681.247MB, cumulative process highwater670064KiB; neither is per-op peak or owned-memory graph.

## Conditional decision

These data support further consideration of a reused2-worker Node candidate with explicit lifetime/resource costs. They do not prove synchronous public-library compatibility, browser suitability, common JS/Wasm adoption, or performance of an unwritten public parallel frontend. Actual public materialization/dispatch/wrapper cost, selected boundaries/fallback/contracts, final both-API small guards and composed correctness remain existing acceptance work. Any chosen lower-bound threshold needs the already-required bounded-boundary judgment; latency screen alone is insufficient. Wasm and Native evidence remain separate. No new numerical run/source change was performed by reviewer.
