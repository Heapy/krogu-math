# Wasm retained public raw audit reproduction

Run from repository root. This is the same independent raw analysis as JS with only platform, raw directory and authoritative handle changed. It reads evidence and writes audit JSON; no numerical runtime is launched.

```sh
python3 - <<'PY'
from pathlib import Path
import json,csv,re,statistics as st,hashlib,datetime
r=Path('.codex-work/539');platform='Wasm';stem='actual-public-node-wasm-serial-retention-1';handle=19329;d=r/stem;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();props=lambda p:dict(l.split('=',1) for l in p.read_text().splitlines() if '=' in l);pre=json.loads((r/'serial-retention-two-public-prelaunch.json').read_text());g=next(x for x in pre['groups'] if x['platform']==platform);a=g['argv'];m=props(d/'campaign.properties');assert m['sourceSHA']==a[5] and m['treeManifestSHA']==a[3] and m['payloadManifestSHA']==a[9] and m['payloadIdentity']==a[10] and m['nodeSHA']==a[7] and m['kind']==platform
assert sha(Path(a[1]))==g['launcher_sha256'] and sha(Path(g['post_checker_argv'][1]))==g['post_checker_sha256'] and sha(Path(a[6]))==a[7]
assert (d/'runtime.log').read_text().strip()=='v24.16.0' and (d/'COMPLETE').is_file()
sizes=[256,1024,4096,8192,16384];shapes=['distinct','square','ratio2'];variants=['kernel-k64-s16-e384','frame-k64-s16-e384','serial','parallel'];rows=[];first=[];per={};identities=[];resources=[];bindings=[];timingwindows=[]
for f in range(3):
 for size in sizes:
  for shape in shapes:
   point=f'{size}/{shape}';order='reverse' if f==1 else 'forward';log=d/f'fork{f}-{size}-{shape}.log';ls=log.read_text().splitlines();b=props(Path(str(log)+'.binding'));assert b['fork']==str(f) and b['size']==str(size) and b['shape']==shape and b['order']==order and b['logSHA']==sha(log) and Path(str(log)+'.exit').read_text()=='0\n'
   for k in ['sourceSHA','treeManifestSHA','payloadManifestSHA','payloadIdentity']:assert b[k]==m[k]
   expectedargv=[m['node'],'--expose-gc',m['host'],m['cwd'],m['entry'],m['mocha'],platform];assert Path(str(log)+'.argv.txt').read_text().splitlines()==expectedargv+[m['payloadIdentity']]
   assert Path(str(log)+'.profile').read_text()==f'node-public-serial-retention,{size},{shape},{order}\n'
   own=f'# OWN539 pid={b["pid"]} start_epoch_ms={b["start_epoch_ms"]} node=v24.16.0 kind={platform} flags=["--expose-gc"]';assert ls.count(own)==1;pid,start=int(b['pid']),int(b['start_epoch_ms']);assert pid>0 and start>0;identities.append((pid,start));os=Path(str(log)+'.identity.txt').read_text();match=re.fullmatch(r'pid=(\d+) start=(.+)\n',os);assert match and int(match[1])==pid;dt=datetime.datetime.fromisoformat(match[2].replace('Z','+00:00'));assert abs(dt.timestamp()*1000-start)<1000
   assert ls.count(f'# ORIGIN539 entry={m["entry"]} mocha={m["mocha"]}')==1 and ls.count('# SELECTED539 tests=1 passes=1 failures=0 pending=0')==1
   for phase in ['before-run','after-run']:
    c=[x for x in ls if x.startswith('# CACHEORIGIN539 phase='+phase+' ')];assert len(c)==1 and c[0].endswith(' owned=true') and int(re.search(r'files=(\d+)',c[0])[1])>0
   assert sum(x.startswith('# REGISTERED539 selected=1 name=') for x in ls)==1 and ls.count('# PUBLICBACKEND_BEFORE539 absent=true')==1 and ls.count(f'PASS_PUBLICNODE539,{point}')==1
   assert [x for x in ls if x.startswith('INPUTNODE539')]==[f'INPUTNODE539,{point},{size},{2*size if shape=="ratio2" else size},{str(shape=="square").lower()}']
   ff=[x.split(',') for x in ls if x.startswith('FIRSTNODE539')];assert len(ff)==1 and len(ff[0])==4 and ff[0][1]==point;fn,cpu=int(ff[0][2]),int(ff[0][3]);assert fn>0 and cpu>=0;first.append(dict(fork=f,point=point,first_ns=fn,cpu_ns=cpu));expectedv=variants[::-1] if f==1 else variants
   assert [x for x in ls if x.startswith('INVENTORYNODE539')]==[f'INVENTORYNODE539,{point},'+';'.join(expectedv)]
   raw=[x.split(',') for x in ls if x.startswith('PUBLICNODE539')];assert len(raw)==28 and [(x[1].split('/')[-1],int(x[2])) for x in raw]==[(v,j) for v in expectedv for j in range(7)]
   groups={v:[] for v in variants}
   for x in raw:
    assert len(x)==9 and x[1].startswith(point+'/');v=x[1].split('/')[-1];sample,count,wall,cpu=map(int,x[2:6]);assert 0<=sample<7 and 1<=count<=8388608 and count&(count-1)==0 and wall>0 and cpu>=0 and x[6]=='NA';heap=None if x[7]=='NA' else int(x[7]);assert heap is None or heap>=0;assert platform!='Wasm' or heap is None;h=int(x[8]);z=dict(fork=f,point=point,variant=v,sample=sample,count=count,elapsedNs=wall,cpuNs=cpu,allocationBytes=None,coarseHeapBytes=heap,resultHash=h);rows.append(z);groups[v].append(z)
   for v,z in groups.items():
    assert len({x['count'] for x in z})==len({x['resultHash'] for x in z})==1
    per[f,point,v]=dict(wall_ns=st.median(x['elapsedNs']/x['count'] for x in z),min_ns=min(x['elapsedNs']/x['count'] for x in z),max_ns=max(x['elapsedNs']/x['count'] for x in z),cpu_ns=st.median(x['cpuNs']/x['count'] for x in z))
   assert groups[variants[0]][0]['resultHash']==groups[variants[1]][0]['resultHash'] and groups['serial'][0]['resultHash']==groups['parallel'][0]['resultHash']
   assert ls.index(','.join(ff[0]))<ls.index(','.join(raw[0]))
   temp=Path(b['tempRoot']);assert temp.resolve()==(d/f'fork{f}-{size}-{shape}-tmp').resolve() and temp.is_dir() and not temp.is_symlink() and not list(temp.iterdir())
   assert ls.count(f'# DECLINE_TEMP539 root={temp} empty=true')==1
   witness=[x.split(',') for x in ls if x.startswith('PUBLICSERIALDECLINE539')];assert len(witness)==8
   for j,x in enumerate(witness):
    sample=j-1;count=1 if j==0 else groups['parallel'][sample]['count'];assert x==['PUBLICSERIALDECLINE539',point,'first' if j==0 else 'parallel',str(sample),str(count),platform,'true','true']
    prefix=f'FIRSTNODE539,{point},' if j==0 else f'PUBLICNODE539,{point}/parallel,{sample},';at=next(k for k,l in enumerate(ls) if l.startswith(prefix));wi=ls.index(','.join(x));assert wi>at and not any(l.startswith('PUBLICNODE539,') for l in ls[at+1:wi])
   assert ls.count(f'# PUBLICSERIAL_POST539 point={point} registry_absent=true temp_empty=true')==1 and ls.count(f'PUBLICSERIALRESOURCE539,{point},NONE_STARTED,true,true')==1
   assert not any(x.startswith(('PUBLICBACKENDNEAR539,','PUBLICBACKENDCLEANUP539,','# PUBLICSERIAL_FAILURE539 ')) for x in ls)
   rr=[json.loads(x.removeprefix('# RESOURCE539 ')) for x in ls if x.startswith('# RESOURCE539 ')];assert len(rr)==1;resources.append(dict(fork=f,point=point,after_run=rr[0]));bindings.append(dict(log=log.name,sha256=sha(log),binding_sha256=sha(Path(str(log)+'.binding')),pid=pid,start_epoch_ms=start));timingwindows.append(start)
assert len(identities)==len(set(identities))==45 and len(rows)==1260 and len(first)==45
for point in [f'{s}/{h}' for s in sizes for h in shapes]:
 for v in variants:assert len({x['resultHash'] for x in rows if x['point']==point and x['variant']==v})==1
expectedchron=[dict((z['log'],z['start_epoch_ms']) for z in bindings)[f'fork{f}-{s}-{h}.log'] for f in range(3) for s in (sizes[::-1] if f==1 else sizes) for h in (shapes[::-1] if f==1 else shapes)];assert expectedchron==sorted(expectedchron)
csvrows=list(csv.DictReader((d/'strict-results/warm.csv').open()));assert len(csvrows)==1260
for x,z in zip(csvrows,rows):
 for key,value in z.items():assert x[key]==('NA' if value is None else str(value)),(key,x[key],value)
for x in csv.DictReader((d/'strict-results/per-fork.csv').open()):
 z=per[int(x['fork']),x['point'],x['variant']]
 for k,q in [('medianNs','wall_ns'),('minNs','min_ns'),('maxNs','max_ns'),('medianCpuNsPerOp','cpu_ns')]:assert float(x[k])==z[q]
comparison=[]
for s in sizes:
 for h in shapes:
  point=f'{s}/{h}';ser=[per[f,point,'serial'] for f in range(3)];par=[per[f,point,'parallel'] for f in range(3)];comparison.append(dict(point=point,serial_wall_fork_ns=[z['wall_ns'] for z in ser],parallel_wall_fork_ns=[z['wall_ns'] for z in par],parallel_over_serial_wall=[par[f]['wall_ns']/ser[f]['wall_ns'] for f in range(3)],serial_cpu_fork_ns=[z['cpu_ns'] for z in ser],parallel_cpu_fork_ns=[z['cpu_ns'] for z in par],parallel_over_serial_cpu=[par[f]['cpu_ns']/ser[f]['cpu_ns'] for f in range(3)],first_fork_ns=[next(z['first_ns'] for z in first if z['fork']==f and z['point']==point) for f in range(3)]))
for x in csv.DictReader((d/'strict-results/paired-all-comparators.csv').open()):
 p=x['point'];v=x['comparator'];rat=[per[f,p,'parallel']['wall_ns']/(min(per[f,p,w]['wall_ns'] for w in variants[:-1]) if v=='fastest-matched-serial' else per[f,p,v]['wall_ns']) for f in range(3)]
 assert all(float(x[f'fork{f}ratio'])==rat[f] for f in range(3)) and float(x['medianPairedRatio'])==st.median(rat) and float(x['maxPairedRatio'])==max(rat)
for line in Path(a[4]).read_text().splitlines():
 h,p=line.split('\t');assert sha(Path(p))==h
assert sha(Path(a[4]))==a[5]
out={'status':'PASS_INDEPENDENT_ACTUAL_RAW_STATS_SERIAL_RETENTION_NO_BACKEND_GAIN_OR_SMALL_GUARD_CLEARANCE','source':pre['source'],'source_manifest_sha256':a[5],'handle':handle,'FIRST':45,'WARM':1260,'fresh_identities':identities,'raw_bindings':bindings,'comparisons':comparison,'first':first,'resources':resources,'scope':'All28perchild warm rows/4routes64, exact both lengths and physicalalias, checks/fullresult consistency, counters/NA/nativehashes/CPU stats/CSV,8nearcallregistryabsent+tempempty witnesses and final45emptyownednamespaces. Origins/actualPID/start/argv/closures runtime/source prebound. Source generated directvirtualserial proof separate. No actual backend started, worker cleanup or gains inferred. FIRST firstpubliccall afterpreparedinputs, not startup/pristineVM/matchedfirstserial comparison. RESOURCE afterrun highwater/currentprocess fields not perrouteowned/completedlifetime. Six smallguard flags stay separate unresolved; no noise waiver.'}
p=r/('independent-'+stem+'-raw-audit.json');p.write_text(json.dumps(out,indent=2)+'\n');print('PASS',sha(p))
for x in comparison:print(x['point'],'wall',','.join(f'{v:.3f}' for v in x['parallel_over_serial_wall']),'CPU',','.join(f'{v:.3f}' for v in x['parallel_over_serial_cpu']))
print('first_ms',min(z['first_ns'] for z in first)/1e6,max(z['first_ns'] for z in first)/1e6,'RSSbytes',min(z['after_run']['resource']['maxRSS']*1024 for z in resources),max(z['after_run']['resource']['maxRSS']*1024 for z in resources))
PY
```
