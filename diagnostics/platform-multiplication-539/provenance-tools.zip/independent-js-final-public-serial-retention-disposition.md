# JS final public serial retention — actual24308

Source aa9ca6b9; independent raw PASS7e20ad12. Both APIs execute the current K64/16/384 serial arithmetic. Ratios below are `parallelMultiply/multiply` within the same fresh child and input; they are not worker speedups. Each cell median latency/CPU is the median of the three per-process seven-sample medians. All paired directions remain visible.

| Words / shape | multiply wall ms | parallelMultiply wall ms | Wall ratios F/R/F | multiply CPU ms | parallelMultiply CPU ms | CPU ratios F/R/F | FIRST ms F/R/F |
|---|---:|---:|---|---:|---:|---|---|
| 256/distinct | 3.618 | 3.219 | 0.998/0.577/0.987 | 3.705 | 3.263 | 0.988/0.575/1.005 | 5.559/6.141/7.626 |
| 256/square | 5.377 | 5.218 | 1.030/0.968/0.957 | 5.493 | 5.244 | 1.019/0.955/0.939 | 9.294/8.072/10.652 |
| 256/ratio2 | 4.670 | 5.016 | 1.108/1.149/0.984 | 4.689 | 5.050 | 1.114/1.148/0.983 | 7.164/9.326/10.078 |
| 1024/distinct | 22.160 | 21.065 | 1.035/0.952/0.951 | 23.334 | 21.110 | 0.970/0.979/0.905 | 39.023/24.621/30.751 |
| 1024/square | 21.490 | 21.383 | 1.218/1.011/0.995 | 21.782 | 21.435 | 1.178/1.034/0.984 | 35.879/24.075/32.730 |
| 1024/ratio2 | 61.825 | 55.674 | 1.123/1.057/0.883 | 57.290 | 55.766 | 1.213/1.078/0.880 | 71.261/73.203/55.725 |
| 4096/distinct | 255.909 | 250.893 | 0.980/0.986/0.999 | 255.930 | 250.851 | 0.980/0.987/1.002 | 323.962/175.947/271.999 |
| 4096/square | 166.357 | 165.325 | 0.967/0.996/0.780 | 166.372 | 165.447 | 0.967/0.997/0.780 | 238.117/174.336/311.497 |
| 4096/ratio2 | 337.151 | 337.755 | 1.002/1.001/1.001 | 337.159 | 337.763 | 1.002/1.001/1.001 | 348.036/356.048/350.274 |
| 8192/distinct | 501.443 | 507.759 | 1.005/0.612/1.181 | 501.439 | 506.357 | 1.005/0.610/1.180 | 493.923/494.666/488.359 |
| 8192/square | 512.004 | 516.388 | 1.269/1.003/1.007 | 512.177 | 516.452 | 1.269/1.003/1.006 | 503.492/507.614/967.199 |
| 8192/ratio2 | 1000.607 | 1159.179 | 0.995/1.225/1.158 | 1000.566 | 1141.248 | 0.995/1.225/1.141 | 1566.208/1952.468/991.958 |
| 16384/distinct | 1635.394 | 2499.756 | 1.638/0.814/1.592 | 1622.992 | 2427.291 | 1.603/0.809/1.591 | 1459.088/2611.508/2317.900 |
| 16384/square | 2337.207 | 2606.099 | 0.837/1.008/1.115 | 2334.304 | 2604.826 | 0.837/1.009/1.116 | 2424.233/1906.775/1950.316 |
| 16384/ratio2 | 4864.843 | 3338.220 | 0.661/0.616/0.980 | 4862.470 | 3337.829 | 0.666/0.617/0.984 | 4055.595/4728.638/4411.988 |

The 45 FIRST calls range5.559–4728.638ms. They measure the first public call after fixture preparation, not pristine-runtime latency, worker activation, matched first-serial speedup or startup. Distinct and square operands have equal word counts; ratio2 right operands contain twice the listed words.

All45 children report no production registry before execution, eight outside-counter absence/empty-private-temp observations, NONE_STARTED and post-run absence; the parent verifies each private namespace empty. Together with the separately bound compiled direct virtual fallback, this confirms intentional backend decline in this artifact. Endpoint absence alone is not represented as historical worker termination/cleanup proof.

After-run process maxRSS ranges312,262,656–399,966,208bytes. This high-water observation includes initialization/fixture/allroutes through the snapshot, not per-route or completed-lifetime peak. HeapUsed is a coarse whole-process JS snapshot; allocation is NA. No payload loading or worker memory price is attributed to the declined route.

Disposition: accept the execution/correctness/absence evidence and retain the decision to decline the JS parallel backend and selected scalar candidate. The substantial mixed public API ratios, even though both dispatch to serial arithmetic, establish no backend gain and no controlled cause. CPU broadly follows wall but includes runtime/JIT/GC; no source or runtime cause was observed. The low-CPU prelaunch snapshot does not demonstrate continuous isolation. Historical105 worker comparisons, active-era data and refusal rationale remain separately source-labelled.

This large-input comparison does not clear the six smallguard91477 flags. Final small-path performance clearance remains unresolved pending the one previously fixed observed full28 diagnostic; no additional rerun/microfix is proposed here. Other finaltarget contracts, publicationconsumer andfullcorrectness obligations remain separate.
