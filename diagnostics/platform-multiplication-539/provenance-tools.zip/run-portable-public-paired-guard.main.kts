#!/usr/bin/env kotlinr
// Paired JS/Wasm public28 guard; no numerical implementation.
import java.io.File
import java.security.MessageDigest
import java.time.Instant
import java.util.concurrent.TimeUnit
require(args.size == 10) { "baselineTree baselineManifest currentTree currentManifest sourceTSV sourceSHA node nodeSHA runtimeId newOutput" }
fun sha(f: File) = MessageDigest.getInstance("SHA-256").digest(f.readBytes()).joinToString("") { "%02x".format(it) }
val root = File("/Users/yoda/dev/pet/krogu-math/.codex-work/539").canonicalFile
val launcher = File(root, "run-portable-public-paired-guard.main.kts")
val launcherSha = sha(launcher)
val trees = listOf(File(args[0]).canonicalFile, File(args[2]).canonicalFile)
val manifestHashes = listOf(args[1], args[3])
val source = File(args[4]).canonicalFile
val node = File(args[6]).canonicalFile
val runtimeId = args[8]
val output = File(args[9]).canonicalFile
require(output.toPath().startsWith(root.toPath()) && !output.exists())
require(runtimeId.isNotBlank() && !runtimeId.contains('\n'))
fun rows(file: File) = file.readLines().map { line -> val f = line.split('\t'); require(f.size == 2 && f[0].matches(Regex("[a-f0-9]{64}"))); f[0] to f[1] }
val sources = rows(source).map { (h, n) -> h to File(n).canonicalFile.also { require(it.toPath().startsWith(root.toPath())) } }
val bound = trees.mapIndexed { index, tree ->
    val manifest = File(tree, "manifest.sha256"); check(sha(manifest) == manifestHashes[index])
    rows(manifest).map { (h, n) ->
        require(!File(n).isAbsolute && n.split('/').none { it == ".." || it == "." })
        h to File(tree, n).canonicalFile.also { require(it.toPath().startsWith(tree.toPath()) && it.isFile) }
    }.also { require(it.map { p -> p.second }.toSet().size == it.size) }
}
fun verify() {
    check(sha(launcher) == launcherSha && sha(source) == args[5] && sha(node) == args[7])
    for ((h, f) in sources + bound.flatten()) check(sha(f) == h) { "Changed: $f" }
    for ((i, tree) in trees.withIndex()) {
        val manifest = File(tree, "manifest.sha256"); check(sha(manifest) == manifestHashes[i])
        check(tree.walkTopDown().filter { it.isFile }.map { it.canonicalFile }.toSet() == bound[i].map { it.second }.toSet() + manifest)
    }
}
val kinds=trees.map { File(it,"platform.txt").readText().trim().also { k->require(k in listOf("JS","Wasm")) } }
check(kinds.distinct().size==1)
val kind=kinds.first()
fun owned(index:Int,name:String):File {
    require(!File(name).isAbsolute && name.split('/').none { it in listOf(".","..","") })
    return File(trees[index],name).canonicalFile.also { check(it in bound[index].map { p->p.second }) }
}
val entries=trees.mapIndexed { i,t->owned(i,File(t,"entry.txt").readText().trim()) }
val hosts=trees.indices.map { owned(it,"node-calibration-host.cjs") }
val mochas=trees.indices.map { owned(it,"mocha/node_modules/mocha/index.js") }
var currentProfile: String? = null
verify(); check(output.mkdirs())
fun clean(builder: ProcessBuilder) { builder.environment().clear(); builder.environment()["LANG"] = "C"; builder.environment()["TZ"] = "UTC"; currentProfile?.let { builder.environment()["KROGU539_ARGS"] = it } }
fun execute(command: List<String>, log: File, seconds: Long) {
    File(log.path + ".argv.txt").writeText(command.joinToString("\n", postfix = "\n"))
    val builder = ProcessBuilder(command).redirectErrorStream(true).redirectOutput(log)
    clean(builder)
    val child = builder.start()
    var completed = false
    var failure: Throwable? = null
    try {
        File(log.path + ".identity.txt").writeText("pid=${child.pid()} start=${child.toHandle().info().startInstant().orElse(null)}\n")
        completed = child.waitFor(seconds, TimeUnit.SECONDS)
        check(completed) { "Deadline: $log" }
        check(child.exitValue() == 0) { "Child failed: $log exit=${child.exitValue()}" }
    } catch (caught: Throwable) {
        failure = caught
        throw caught
    } finally {
        if (!completed || child.isAlive) {
            var cleanupFailure: Throwable? = null
            fun record(caught: Throwable) {
                if (cleanupFailure == null) cleanupFailure = caught else cleanupFailure!!.addSuppressed(caught)
            }
            val descendants = try { child.toHandle().descendants().toList() }
                catch (caught: Throwable) { record(caught); emptyList() }
            for (handle in descendants.asReversed() + child.toHandle()) {
                try { handle.destroyForcibly() } catch (caught: Throwable) { record(caught) }
            }
            val until = System.nanoTime() + TimeUnit.SECONDS.toNanos(10)
            val capturedInterrupt = Thread.interrupted()
            var interrupted = capturedInterrupt || failure is InterruptedException
            for (handle in descendants + child.toHandle()) {
                while (handle.isAlive && System.nanoTime() < until) {
                    try { handle.onExit().get(maxOf(1L, until - System.nanoTime()), TimeUnit.NANOSECONDS); break }
                    catch (_: InterruptedException) { interrupted = true }
                    catch (_: java.util.concurrent.TimeoutException) { break }
                    catch (caught: Throwable) { record(caught); break }
                }
            }
            val survivors = descendants.filter { it.isAlive }.map { it.pid() }
            if (child.isAlive || survivors.isNotEmpty())
                record(IllegalStateException("Owned cleanup survivors=$survivors rootAlive=${child.isAlive}"))
            if (interrupted) Thread.currentThread().interrupt()
            if (cleanupFailure != null) {
                if (failure != null) failure.addSuppressed(cleanupFailure!!) else throw cleanupFailure!!
            }
        }
    }
}

execute(listOf(node.path,"--version"),File(output,"runtime.log"),10)
check(File(output,"runtime.log").readText().trim()=="v24.16.0")
File(output, "binding-before.txt").writeText("launcher_sha256=$launcherSha\nsource_manifest_sha256=${args[5]}\nbaseline_manifest=${args[1]}\ncurrent_manifest=${args[3]}\nnode_sha256=${args[7]}\nruntime_id=$runtimeId\n")
val deadline = System.nanoTime() + TimeUnit.MINUTES.toNanos(30)
for (fork in 0..2) {
    val order = if (fork == 1) "reverse" else "forward"
    // Alternate A/B, B/A, A/B so each pair shares observation context.
    for (index in if (fork == 1) listOf(1, 0) else listOf(0, 1)) {
        verify()
        val tree = trees[index]; val label = if (index == 0) "baseline" else "current"
        val log = File(output, "fork$fork-$label.log")
        currentProfile="public-small,$order,7,20"
        val command=listOf("/usr/bin/time","-l",node.path,"--expose-gc",hosts[index].path,entries[index].path,mochas[index].path,kind)
        val seconds = minOf(600L, TimeUnit.NANOSECONDS.toSeconds(deadline - System.nanoTime())); check(seconds > 0)
        execute(command, log, seconds)
        val lines = log.readLines(); val identity = lines.single { it.startsWith("# OWN539 ") }
        val pid=Regex("pid=([0-9]+)").find(identity)!!.groupValues[1]
        val start=Regex("start_epoch_ms=([0-9]+)").find(identity)!!.groupValues[1]
        check(lines.count { it.startsWith("TIME539,") } == 196 && lines.count { it.startsWith("REP539,") } == 28)
        File(log.path + ".exit").writeText("0\n")
        File(log.path + ".binding").writeText("label=$label\nsource_manifest_sha256=${args[5]}\nartifact_manifest_sha256=${manifestHashes[index]}\nruntime_id=$runtimeId\npid=$pid\nstart_epoch_ms=$start\nlog_sha256=${sha(log)}\nprofile=$currentProfile\nidentity=$identity\n")
        verify(); println("COMPLETE paired public28 fork=$fork label=$label")
    }
}
File(output, "EXECUTED_NOT_YET_GUARD_VALIDATED").writeText("Six fresh alternating children complete;1176TIME/168REP; pairedcase15%AND5ns guard and independent audit pending. Historical baseline source era is bound in its immutable artifact metadata, not relabelled current.\n")
