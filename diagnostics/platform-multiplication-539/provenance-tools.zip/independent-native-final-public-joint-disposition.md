# Native final public route: joint latency/resource/small-path disposition

Source aa9ca6b9; actual50930 independentraw PASS382607e2. Four current routes are matched in each child: selectedkernel/frame (distinctK32, alias/ratio2K64), actualordinarymultiply, actualparallelMultiply(childK64). Ratios below compare parallel against the fastest measured matched serial route in that SAME process. Three process medians, all sample/adverse data retained.

| Words / shape | Wall ratios F/R/F | CPU ratios against same wall comparator F/R/F | Parallel median ms | Fastest serial median ms | Frozen parallel margin |
|---|---|---|---:|---:|---|
| 256/distinct | 1.146/1.044/0.893 | 1.153/1.034/0.896 | 0.027 | 0.024 | NO |
| 256/square | 1.259/1.352/1.045 | 1.232/1.320/1.032 | 0.037 | 0.028 | NO |
| 256/ratio2 | 1.051/1.229/1.084 | 1.052/1.213/1.086 | 0.065 | 0.053 | NO |
| 1024/distinct | 1.254/1.207/1.415 | 1.243/1.208/1.296 | 0.373 | 0.309 | NO |
| 1024/square | 0.859/0.821/1.166 | 0.854/0.814/1.167 | 0.260 | 0.317 | NO |
| 1024/ratio2 | 1.312/1.001/1.186 | 1.317/0.986/1.170 | 0.724 | 0.724 | NO |
| 4096/distinct | 0.394/0.622/0.516 | 1.115/1.610/1.404 | 1.368 | 2.650 | PASS |
| 4096/square | 0.448/0.389/0.417 | 1.260/1.003/1.177 | 1.211 | 2.907 | PASS |
| 4096/ratio2 | 0.738/0.593/0.591 | 1.444/1.174/1.174 | 3.608 | 6.102 | PASS |
| 8192/distinct | 0.380/0.444/0.514 | 1.108/1.264/1.421 | 4.874 | 9.779 | PASS |
| 8192/square | 0.383/0.394/0.542 | 1.119/1.126/1.447 | 4.035 | 10.232 | PASS |
| 8192/ratio2 | 0.530/0.596/0.717 | 1.027/1.177/1.130 | 13.507 | 22.663 | PASS |
| 16384/distinct | 0.541/0.873/0.423 | 1.583/2.093/1.219 | 13.961 | 20.788 | PASS |
| 16384/square | 0.436/0.431/0.465 | 1.295/1.206/1.379 | 11.307 | 24.330 | PASS |
| 16384/ratio2 | 0.529/0.675/0.551 | 1.054/1.335/1.071 | 33.193 | 60.258 | PASS |

**Large-route conclusion.** Allnine physically eligible points4096/8192/16384 × distinct/square/ratio2 pass the frozen20%median/10%everypair rule, with adjacent sizes in everyclass. Native ratio2 rightoperand is twice the listed words. Each operation includes actualproductionWorker lifecycle: create/copy/localwork/acceptedjoins/terminate/permitrelease. No reuse or startup amortization was invented. Lower256/1024 points are fallback controls and do not pass a paralleladoption claim.

**Resource judgment.** Eligible CPU ratio ranges1.003–2.093 against the same wall-fastest serial route. This trades additional CPU and boundedtwo-workers/percall threadcost for latency; at16384distinct the reversefork retains wallratio.873 andCPUratio2.093. Eligible FIRST0.983–53.551ms is firstpublicactivationattempt cost afteruntimedprepare, not matchedfirstspeedup/pristineVM. Wholecompletedchild maxRSS19,841,024–153,042,944bytes andfootprint13,091,248–146,588,560bytes include fixture/allroutes/exit. Neither identifies incrementalperoperation/backendlivepeak. AllocationNA/lastGCheapcoarse and no ownedmemory inference. These disclosed resource limits do not independently invalidate the large-route latency case.

**Small-path judgment.** The fixed finalNative28 still triggers mixed parallel63distinct (+11.256/−26.260/+100.238ns) andordinary30distinct (+7.772/+6.171/−.998ns). Ordinary30compact has the same152instruction/opcode-register prefix asbaseline/2d74 withrelocated data operands; no addedcompactarithmetic identified. Currentcompactparallel29instructionpath equals earlier2d74 skeleton. Againstbaseline it still has176byteframe/6registersave+restorepairs versus96bytes/3pairs; baselineinstead paysTLS/rootframework and41instructions. No addedallocation/backend/getter appears oncompactfallback. Thus no newaa9compactwork exists, but real prefixresource differences remain. Staticlowering does not establish netlatency magnitude or explain +100ns; Native isAOT, no JITcause asserted.

**Engineering recommendation.** Do not mark the currentNativeproductionparallel frontend finally accepted under the frozen no-unresolved-credible-material-smallpath-regression condition. Large-route latency eligibility and itsCPU/resource tradeoff are supported, but they cannot compensate for or erase the stillcredible compactfallback risk, where realchanged save/restoretraffic coincides with twoadverse materialpairs. Ordinarycompact control source/lowering equivalence reduces the evidence for an arithmeticregression, not all layout/runtime performance risk. This is a risk-based refusal of finalNativeparallel acceptance on currentevidence, not a zero-flags theorem and not a claim that the +100ns cause is proved. Retain scalarpolicy32evidence andallprototype/finalcomparisons separately. No newmeasurement orrefactor is proposed by thisreview; root/owner must record finalproductdisposition explicitly rather than relabel strictmathPASS as performanceclearance.

Allold18Nativeflags, the onepreregistered diagnostic andalllargepoints remain in evidence. Hostsnapshot reported externalJava21≈108%/Weather66%; no continuousisolation or causalnoise waiver. Fullcorrectness/publicationconsumer andotherplatformdecisions remain separate.
