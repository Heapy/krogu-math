from pathlib import Path
import zipfile,subprocess,re,json,hashlib
p=Path(__file__).resolve().parent;out=p/'serial-retention-jvm-semantic-comparison';out.mkdir();old=p/'artifacts/jvm-fused-compact-a2070e1/main.jar';new=p/'worktree/build/libs/krogu-math-jvm-0.1.0-SNAPSHOT.jar';javap='/Users/yoda/.sdkman/candidates/java/25.0.4-librca/bin/javap';sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
def dump(j,cls,verbose=False):return subprocess.check_output([javap,'-v' if verbose else '-c','-p','-classpath',str(j),cls],text=True)
def methods(t):
 starts=list(re.finditer(r'^  (?:public|private|protected|static).*\);?\s*$',t,re.M));return {m.group().strip():re.sub(r'#\d+','#CP',t[m.end():starts[i+1].start() if i+1<len(starts) else len(t)]) for i,m in enumerate(starts)}
def public_graph(s):
 ins=[]
 for line in s.splitlines():
  m=re.match(r'\s*(\d+):\s*(\S+)(.*)',line)
  if m and m[2]!='nop':ins.append((int(m[1]),m[2],m[3].strip()))
 indexes={offset:i for i,(offset,_,_) in enumerate(ins)};result=[]
 for _,op,arg in ins:
  if op.startswith('if') or op in {'goto','goto_w'}:
   m=re.match(r'(\d+)(.*)',arg);assert m;arg='TARGET_INSTRUCTION_'+str(indexes[int(m[1])])+m[2]
  result.append((op,arg))
 return result
za,zb=zipfile.ZipFile(old),zipfile.ZipFile(new);assert set(za.namelist())==set(zb.namelist());changed=[n for n in za.namelist() if za.read(n)!=zb.read(n)];reports=[]
for name in changed:
 assert name.endswith('.class'),name
 cls=name[:-6].replace('/','.');a,b=dump(old,cls),dump(new,cls);(out/(cls.rsplit('.',1)[-1]+'.old.javap.txt')).write_text(a);(out/(cls.rsplit('.',1)[-1]+'.current.javap.txt')).write_text(b);ma,mb=methods(a),methods(b);assert ma.keys()==mb.keys();delta=[k for k in ma if ma[k]!=mb[k]]
 if cls=='io.heapy.krogu.math.BigInteger':
  assert len(delta)==1 and ' parallelMultiply(' in delta[0],delta
  assert public_graph(ma[delta[0]])==public_graph(mb[delta[0]]);assert '33: areturn' in mb[delta[0]] and '6: nop' in mb[delta[0]]
  reports.append({'class':cls,'public_Code_bytes':34,'only_method_delta':delta[0],'public_instruction_and_branch_graph_equal_after_one_NOP_removed':True,'all_other_method_instruction_listings_equal':True,'NOP_origin':'Compile-time false retainSerialParallelMultiply539 on JVM; no actual flag read, predicate or backend call added.'})
 elif cls.endswith('.MultiplicationPlatform539Kt'):
  assert not delta
  normal=lambda s:'\n'.join(x for x in s.splitlines() if x.strip() and 'retainSerialParallelMultiply539' not in x)
  assert normal(a)==normal(b)
  verbose=dump(new,cls,True);(out/'MultiplicationPlatform539Kt.current.verbose.javap.txt').write_text(verbose)
  assert re.search(r'public static final boolean retainSerialParallelMultiply539;[\s\S]*?ConstantValue: int 0',verbose)
  assert 'Code:' not in b
  reports.append({'class':cls,'only_listing_addition':'public static final boolean retainSerialParallelMultiply539, ConstantValue int0','no_executable_class_initializer_or_methods':True})
 else:
  assert not delta,(cls,delta);reports.append({'class':cls,'all_method_instruction_listings_equal':True,'scope':'Changedclassbytes/debug/metadata are not claimed byte-identical; normalized CP ordinals only, instruction offsets retained.'})
s={'source':'aa9ca6b9cab6d177ba62b188aa72a0f0fad1e2fa','producer_handle':16033,'actual_main_producer':str(new),'actual_main_sha256':sha(new),'previous_actual_source':'a2070e1e1e7a5c455f25319cd623618714fad921','previous_main_sha256':sha(old),'entry_names_equal':True,'entries':len(za.namelist()),'byte_equal_entries':len(za.namelist())-len(changed),'changed_classes':reports,'scope':'Finite JVM engineering carryforward proposal: current34B <=35, all dynamic instructions/control flow same as accepted a20733B entry after inertNOP removed; coldbody/pool/arithmetic unchanged. Previous guard98393 and 2d74 large45/1260 stay in original artifacteras. No newnumericmargin/JIT/byteidentity claim. Current focused9 actual result recorded separately only after authoritative buildterminal.'};(out/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
