#!/usr/bin/env kotlinr

/** Unrun isolated JS/Wasm common-kernel worker experiment. No production backend. */
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import java.nio.file.Files

require(args.size == 10) { "node artifactDirectory entryRelative artifactSHA256Manifest newOutputDirectory js|wasm forward|reverse samples rootArtifactDirectory rootManifestSHA256" }
val node = File(args[0]).canonicalFile.also { require(it.isFile && it.canExecute()) }
val directory = File(args[1]).canonicalFile.also { require(it.isDirectory) }
val entryRelative = args[2].also { require(!it.startsWith('/') && it.split('/').none { p -> p in listOf("", ".", "..") }) }
val entry = File(directory, entryRelative).canonicalFile.also { require(it.isFile && it.toPath().startsWith(directory.toPath())) }
val manifest = File(args[3]).canonicalFile
val output = File(args[4]).canonicalFile.also { require(!it.exists()) }
val kind = args[5].also { require(it in listOf("js", "wasm")) }
val order = args[6].also { require(it in listOf("forward", "reverse")) }
val samples = args[7].toInt().also { require(it in 5..15) }
val rootDirectory = File(args[8]).canonicalFile.also { require(it.isDirectory) }
val rootManifestSha = args[9].also { require(it.matches(Regex("[a-f0-9]{64}"))) }
val rootManifest = File(rootDirectory, "manifest.sha256").also { require(it.isFile && !Files.isSymbolicLink(it.toPath())) }
fun sha(file: File): String = MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString("") { "%02x".format(it) }
val manifestLines = manifest.readLines()
val expected = manifestLines.associate { line ->
    require(line.matches(Regex("[a-f0-9]{64}  .+")))
    val relative = line.substring(66)
    require(!relative.startsWith('/') && relative.split('/').none { it in listOf("", ".", "..") })
    relative to line.substring(0, 64)
}
require(expected.isNotEmpty() && expected.size == manifestLines.size)
require(expected.keys.any { it.endsWith(".wasm") } == (kind == "wasm"))
val source = File("/Users/yoda/dev/pet/krogu-math/.codex-work/539/run-worker-public-registration-smoke.main.kts").canonicalFile.also { require(it.isFile) }
val rootExpected = rootManifest.readLines().associate { line ->
    val parts = line.split('\t'); require(parts.size == 2 && parts[0].matches(Regex("[a-f0-9]{64}")))
    val relative = parts[1]; require(!relative.startsWith('/') && relative.split('/').none { it in listOf("", ".", "..") })
    relative to parts[0]
}.also { require(it.isNotEmpty() && it.size == rootManifest.readLines().size) }
fun verifyRoot() {
    check(sha(rootManifest) == rootManifestSha)
    check(rootDirectory.walkTopDown().filter { it.isFile }.sumOf { it.length() } <= 512L * 1024 * 1024)
    val actual = rootDirectory.walkTopDown().onEnter { check(!Files.isSymbolicLink(it.toPath())); true }
        .filter { it.isFile && it != rootManifest }.associate { file ->
            check(!Files.isSymbolicLink(file.toPath()) && file.canonicalFile.toPath().startsWith(rootDirectory.toPath()))
            file.relativeTo(rootDirectory).invariantSeparatorsPath to sha(file)
        }
    check(actual == rootExpected) { "Parent root probe closure drift" }
}
verifyRoot()
val sourceSha = sha(source)
val nodeSha = sha(node)
val manifestSha = sha(manifest)
fun verify() {
    verifyRoot()
    check(sha(node) == nodeSha && sha(manifest) == manifestSha && sha(source) == sourceSha)
    val files = directory.walkTopDown().onEnter { check(!Files.isSymbolicLink(it.toPath())); true }.filter { it.isFile }.toList()
    check(files.sumOf { it.length() } <= 512L * 1024 * 1024) { "Owned artifact package exceeds512MiB" }
    val actual = files.associate { file ->
        check(!Files.isSymbolicLink(file.toPath()))
        check(file.canonicalFile.toPath().startsWith(directory.toPath()))
        file.relativeTo(directory).invariantSeparatorsPath to sha(file)
    }
    check(actual == expected) { "Artifact tree drift" }
}
verify()
require(output.mkdirs())
val host = File(output, "owned-host.mjs")
host.writeText("""
import { Worker, MessageChannel, receiveMessageOnPort, isMainThread } from 'node:worker_threads';
import { availableParallelism } from 'node:os';
import { pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const [entry, kind, order, samplesText, rootDirectoryArg] = process.argv.slice(2);
const samples = Number(samplesText);
const entryURL = pathToFileURL(entry).href;
if (process.version !== 'v24.16.0') throw Error('Pinned Node v24.16.0 required');
const started = performance.now();
await import(entryURL);
if (typeof globalThis.__krogu539Invoke !== 'function') throw Error('Private diagnostic callback not registered');
const originalTinyInvoke=globalThis.__krogu539Invoke;
console.log('MODULE539,parent_import_ms,' + (performance.now() - started));
const rootDirectory=fs.realpathSync(rootDirectoryArg);
const rootRequire=createRequire(path.join(rootDirectory,'mocha','package.json'));
function rootPath(relative) {
  if(path.isAbsolute(relative)||relative.split('/').some(p=>p===''||p==='.'||p==='..')) throw Error('Invalid parent artifact path');
  const resolved=fs.realpathSync(path.join(rootDirectory,relative));
  if(!resolved.startsWith(rootDirectory+path.sep)) throw Error('Parent origin outside bound tree');
  return resolved;
}
function verifyRootCache(phase) {
  let count=0;
  for(const filename of Object.keys(rootRequire.cache)) {
    const real=fs.realpathSync(filename);
    if(!real.startsWith(rootDirectory+path.sep) && !real.startsWith(fs.realpathSync(path.dirname(entry))+path.sep)) throw Error('Parent CJS outside both bound closures: '+real);
    count++;
  }
  console.log('ROOTCACHE539,'+phase+','+count+',owned');
}
const rootStarted=performance.now();
const rootEntry=rootPath(fs.readFileSync(rootPath('entry.txt'),'utf8').trim());
const mochaEntry=rootPath('mocha/node_modules/mocha/index.js');
const Mocha=rootRequire(mochaEntry);
const mocha=new Mocha({ui:'bdd',reporter:'dot',timeout:0,grep:/MultiplicationCalibration539.*optionalCampaign/});
mocha.addFile(rootEntry);
await mocha.loadFilesAsync();
if(kind==='wasm') {
  const module=await import(pathToFileURL(rootEntry).href);
  if(typeof module.startUnitTests!=='function') throw Error('Missing parent Wasm startUnitTests');
  if(globalThis.kotlinTest===undefined) globalThis.kotlinTest={adapterTransformer:adapter=>adapter};
  module.startUnitTests();
}
const selected=[];
mocha.suite.eachTest(test=>{
  if(!/MultiplicationCalibration539.*optionalCampaign/.test(test.fullTitle())) return;
  selected.push(test.fullTitle());
  for(let suite=test.parent;suite!==undefined&&suite!==null;suite=suite.parent) {
    for(const name of ['_beforeAll','_beforeEach','_afterEach','_afterAll']) {
      if(!Array.isArray(suite[name])||suite[name].length!==0) throw Error('Parent registration must have no inherited hooks: '+name);
    }
  }
});
if(selected.length!==1) throw Error('Expected one parent registration test');
verifyRootCache('before-register');
await new Promise((resolve,reject)=>{
  const runner=mocha.run(failures=>{
    const stats=runner.stats;
    if(failures!==0||stats.tests!==1||stats.passes!==1||stats.pending!==0) reject(Error('Parent registration test failed'));
    else resolve();
  });
});
verifyRootCache('after-register');
if(globalThis.__krogu539Invoke!==originalTinyInvoke) throw Error('Root replaced tiny callback');
if(typeof globalThis.__krogu539PublicInvoke!=='function') throw Error('Missing parent public callback');
console.log('ROOTMODULE539,parent_load_register_ms,'+(performance.now()-rootStarted));
console.log('ROOTORIGIN539,'+rootEntry+','+mochaEntry);

console.log('# PUBLICSMOKE539 pid='+process.pid+' start_ms='+Date.now());
function reference(words) { let n=0n; for(let i=words.length-1;i>=0;i--) n=(n<<30n)+BigInt(words[i]); return n; }
function words(value) { const out=[]; do {out.push(Number(value&0x3fffffffn));value>>=30n;}while(value!==0n);return Int32Array.from(out); }
for(const same of [false,true]) {
  const a=Int32Array.from({length:256},(_,i)=>(i*104729+31)&0x3fffffff);
  const b=same?a:a.slice();
  globalThis.__krogu539PublicRequest={inputs:[a,b,words(reference(a)*reference(b)),Int32Array.from([64,16,384])],same};
  globalThis.__krogu539PublicInvoke(0);globalThis.__krogu539PublicRequest=null;
  globalThis.__krogu539PublicInvoke(1);globalThis.__krogu539PublicInvoke(2);
  if(!Number.isInteger(globalThis.__krogu539PublicHash))throw Error('Missing verified public hash');
  console.log('PUBLICSMOKE539,'+(same?'square':'distinct')+','+globalThis.__krogu539PublicHash);
  globalThis.__krogu539PublicInvoke(3);
}
verifyRootCache('after-smoke');
if(globalThis.__krogu539Invoke!==originalTinyInvoke)throw Error('Root replaced tiny callback');
console.log('PASS_WORKER_PUBLIC_REGISTRATION539');

""".trimIndent())
val hostSha = sha(host)
val stdout = File(output, "raw.log")
val stderr = File(output, "stderr.log")
val command = listOf(node.path, "--max-old-space-size=512", host.path, entry.path, kind, order, samples.toString(), rootDirectory.path)
File(output, "binding.txt").writeText("node_sha256=$nodeSha\nmanifest_sha256=$manifestSha\nsource_sha256=$sourceSha\nhost_sha256=$hostSha\nroot_directory=${rootDirectory.path}\nroot_manifest_sha256=$rootManifestSha\nargv=" + command.joinToString("\n") + "\n")
val process = ProcessBuilder(command).also {
    it.environment().clear()
    it.environment().putAll(mapOf("TZ" to "UTC", "LANG" to "C", "LC_ALL" to "C", "KROGU539_ARGS" to "worker-public-register"))
}.redirectOutput(stdout).redirectError(stderr).start()
fun stopOwned(): Boolean {
    var interrupted = false
    val owned = process.toHandle().descendants().toList()
    owned.forEach { it.destroy() }; process.destroy()
    fun waitBounded() {
        val until = System.nanoTime() + TimeUnit.SECONDS.toNanos(5)
        while (process.isAlive && System.nanoTime() < until) {
            try { process.waitFor(50, TimeUnit.MILLISECONDS) }
            catch (_: InterruptedException) { interrupted = true }
        }
    }
    waitBounded()
    owned.filter { it.isAlive }.forEach { it.destroyForcibly() }
    if (process.isAlive) process.destroyForcibly()
    waitBounded()
    File(output, "survivors.txt").writeText((owned.filter { it.isAlive }.map { it.pid() } + if (process.isAlive) listOf(process.pid()) else emptyList()).joinToString("\n"))
    return interrupted
}
// JS full corpus exceeded600s in the retained first attempt; bounded launch/wait only, plus cleanup/hash overhead.
val campaignBudgetSeconds = 30L
val terminal = try { process.waitFor(campaignBudgetSeconds, TimeUnit.SECONDS) }
catch (problem: Throwable) {
    val interrupted = stopOwned() || problem is InterruptedException
    if (interrupted) Thread.currentThread().interrupt()
    throw problem
}
if (!terminal) {
    if (stopOwned()) Thread.currentThread().interrupt()
    error("Owned worker campaign timed out; partial output retained")
}
File(output, "raw.log.exit").writeText(process.exitValue().toString())
verify()
check(sha(host) == hostSha)
check(process.exitValue() == 0) { "Worker campaign failed; see retained logs" }
check(stdout.readLines().count { it == "PASS_WORKER_PUBLIC_REGISTRATION539" } == 1)
check(stdout.readLines().none { it.startsWith("WORKER539,") || it.startsWith("CHECKWORKER539,") })
println("CHECKED_WORKER_PUBLIC_REGISTRATION539_NOT_A_BENCHMARK")
