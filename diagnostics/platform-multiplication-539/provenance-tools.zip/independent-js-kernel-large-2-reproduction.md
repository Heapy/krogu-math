# JS large-2 independent raw audit reproduction

Uses the same accepted common auditor and exact 81-case inventory. The sole adapted execution binding is the reviewed JS-large budget launcher SHA; failed large-1 is never read as accepted evidence. All source, loaded-module closure, runtime, samples, complete checks and statistics are retained.

```sh
python3 - <<'PY'
from pathlib import Path
import json,csv,re,hashlib,statistics as st,math
p=Path('.codex-work/539');platform='js';kind='JS';mode='kernel-large'
d=p/f'calibration-{platform}-{mode}-2';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
summary=json.loads((p/f'calibration-{platform}-{mode}-2-summary.json').read_text());pre=json.loads((p/'js-kernel-small-1-prelaunch.json').read_text());tree=p/f'artifacts/common-{platform}-3fb5716';manifest_sha=sha(tree/'manifest.sha256')
pre['runtime_files'][str((p/'run-portable-common.main.kts').resolve())]='fb26933e10b07dd4ce36c0e03ef8faa1086e67fb4e5f72bda3c279e3631c4413'
assert json.loads((p/'js-kernel-large-2-prelaunch.json').read_text())['launcher_sha256']==pre['runtime_files'][str((p/'run-portable-common.main.kts').resolve())]
policies=list(dict.fromkeys([(x,16,384) for x in [32,64,128,256]]+[(64,x,384) for x in [4,8,16,32]]+[(64,16,x) for x in [0,128,256,384,512,1024]]))
if mode.startswith('kernel-'):
 ids=[]
 for n in {'kernel-small':[8,16,31,32,63,64],'kernel-medium':[96,128,192,256,383,384,512],'kernel-large':[1024,4096,8192]}[mode]:
  for shape in ['distinct','square','ratio2','ratio4']:
   ids += [f'kernel/{n}/{shape}/k{k}-s{s}-e{e}' for k,s,e in policies if shape=='square' or (s,e)==(16,384)]
   if n>=64 and shape!='ratio4':ids += [f'frame-serial/{n}/{shape}']
elif mode=='square-control':ids=[f'square-control/{n}/e{e}' for n in [128,192,256,384,512,1024] for e in [0,384,1024,2147483647]]
elif mode=='cost':ids=['cost/'+x for x in ['signed-long-256','unsigned-long-256','int-carry-256','allocate-256-words','allocate-4096-words']]
else:ids=[f'{method}/{bits}/{shape}' for bits in [1,30,63,64,127,511,1023] for shape in ['distinct','square'] for method in ['public','parallel-public']]
assert len(set(ids))==len(ids)
assert summary['exit']==summary['checker_exit']==0
assert all(sha(p/f)==h for f,h in summary['files'].items()) and sha(p/summary['csv'])==summary['csv_sha256']
groups_by_fork={};identities=[];hashes={};envelopes=[];cache_counts=[]
for fork in range(3):
 f=d/f'fork{fork}.log';text=f.read_text();lines=text.splitlines();order='reverse' if fork==1 else 'forward'
 assert Path(str(f)+'.exit').read_text().strip()=='0'
 binding=dict(x.split('=',1) for x in Path(str(f)+'.binding').read_text().splitlines());assert binding['source_manifest_sha256']==pre['argv'][5] and binding['artifact_manifest_sha256']==manifest_sha
 own=next(x for x in lines if x.startswith('# OWN539 '));m=re.fullmatch(r'# OWN539 pid=(\d+) start_epoch_ms=(\d+) node=v24.16.0 kind='+kind+r' flags=(.+)',own);assert m
 pid,start,flags=m.groups();assert int(pid)>0 and int(start)>0 and json.loads(flags)==['--expose-gc'];assert binding['pid']==pid and binding['start_epoch_ms']==start;identities.append((pid,start))
 assert f"# ORIGIN539 entry={tree.resolve()/(tree/'entry.txt').read_text().strip()} mocha={tree.resolve()/'mocha/node_modules/mocha/index.js'}" in lines
 for phase in ['before-run','after-run']:
  found=[x for x in lines if x.startswith('# CACHEORIGIN539 phase='+phase+' ')];assert len(found)==1 and found[0].endswith(' owned=true');count=int(re.search(r'files=(\d+)',found[0])[1]);assert count>0;cache_counts.append(dict(fork=fork,phase=phase,files=count))
 assert '# SELECTED539 tests=1 passes=1 failures=0 pending=0' in lines
 header=next(x for x in lines if x.startswith('# calibration539 '));assert header==f'# calibration539 platform={kind} Node v24.16.0 mode={mode} order={order} cases={len(ids)}'
 checks=[x.split(',') for x in lines if x.startswith('CHECK539,')];assert all(x[2]=='PASS' for x in checks);assert [x[1] for x in checks]==(list(reversed(ids)) if fork==1 else ids)
 assert lines.count(f'PASS539,{len(ids)},7')==1
 reps=[x.split(',') for x in lines if x.startswith('REP539,')]
 if mode=='public-small':
  assert len(reps)==28 and {x[1] for x in reps}==set(ids)
  for _,name,value in reps:
   method,bits,shape=name.split('/');bits=int(bits);v=(1<<(bits-1))+(0 if bits==1 else 1);assert int(value)==(v*v if shape=='square' else v*(v+2))
 else:assert not reps
 argv=Path(str(f)+'.argv.txt').read_text().splitlines();assert argv==['/usr/bin/time','-l',pre['argv'][6],'--expose-gc',str(tree.resolve()/'node-calibration-host.cjs'),str(tree.resolve()/(tree/'entry.txt').read_text().strip()),str(tree.resolve()/'mocha/node_modules/mocha/index.js'),kind]
 rows=list(csv.reader(x for x in lines if x.startswith('TIME539,')));assert len(rows)==len(ids)*7;groups={}
 for row in rows:
  assert len(row)==9;_,name,sample,count,wall,cpu,allocated,heap,digest=row
  sample,count,wall,cpu,digest=map(int,[sample,count,wall,cpu,digest]);assert name in ids and sample in range(7) and 1<=count<=8388608 and count&(count-1)==0 and 0<wall<=60_000_000_000 and cpu>=0 and -(2**31)<=digest<2**31
  assert allocated=='NA'
  if kind=='Wasm':assert heap=='NA';heap=None
  else:heap=int(heap);assert heap>=0
  groups.setdefault(name,[]).append(dict(sample=sample,count=count,wall=wall,cpu=cpu,heap=heap,digest=digest))
 assert set(groups)==set(ids)
 for name,g in groups.items():
  assert len(g)==7 and {x['sample'] for x in g}==set(range(7)) and len({x['count'] for x in g})==1 and len({x['digest'] for x in g})==1
  hashes.setdefault(name,set()).update(x['digest'] for x in g)
 groups_by_fork[fork]=groups
 rss=re.search(r'^\s*(\d+)\s+maximum resident set size$',text,re.M);peak=re.search(r'^\s*(\d+)\s+peak memory footprint$',text,re.M);assert rss and peak;envelopes.append(dict(fork=fork,whole_process_rss_bytes=int(rss[1]),whole_process_peak_footprint_bytes=int(peak[1])))
assert len(set(identities))==3
fullring={name:all(groups_by_fork[i][name][0]['count']>=64 for i in range(3)) for name in ids};assert all(len(hashes[name])==1 for name in ids if fullring[name])
result=[]
for name in sorted(ids):
 gs=[groups_by_fork[i][name] for i in range(3)];wall=[st.median(x['wall']/x['count'] for x in g) for g in gs];cpu=[st.median(x['cpu']/x['count'] for x in g) for g in gs];heaps=[x['heap'] for g in gs for x in g if x['heap'] is not None]
 result.append(dict(case=name,wall_median_ns=st.median(wall),wall_min_process_median_ns=min(wall),wall_max_process_median_ns=max(wall),cpu_median_ns=st.median(cpu),caller_allocated_median_bytes=None,coarse_heap_max_bytes=max(heaps) if heaps else None,fork_wall_ns=wall,fork_cpu_ns=cpu))
owner=list(csv.DictReader((p/summary['csv']).open()));assert len(owner)==len(ids)
for a,b in zip(owner,result):
 assert a['case']==b['case']
 for k in ['wall_median_ns','wall_min_process_median_ns','wall_max_process_median_ns','cpu_median_ns','caller_allocated_median_bytes','coarse_heap_max_bytes']:
  if b[k] is None:assert a[k]=='NA'
  else:assert math.isclose(float(a[k]),b[k],rel_tol=1e-14,abs_tol=1e-9),(a['case'],k,a[k],b[k])
byid={x['case']:x for x in result};comparisons=[]
if mode.startswith('kernel-') or mode=='square-control':
 for r in result:
  parts=r['case'].split('/');base=('kernel/'+parts[1]+'/'+parts[2]+'/k64-s16-e384') if mode.startswith('kernel-') else ('square-control/'+parts[1]+'/e384');b=byid[base]
  ratios=[x/y for x,y in zip(r['fork_wall_ns'],b['fork_wall_ns'])]
  if fullring[r['case']] and fullring[base]:assert hashes[r['case']]==hashes[base]
  comparisons.append(dict(case=r['case'],same_operand_baseline=base,paired_ratios=ratios,median_ratio=st.median(ratios),all3_slower=min(ratios)>1,all3_faster=max(ratios)<1))
for h,f in [x.split('\t') for x in Path(pre['argv'][4]).read_text().splitlines()]:assert sha(Path(f))==h
assert all(sha(Path(f))==h for f,h in pre['runtime_files'].items())
assert all(sha(tree/f)==h for h,f in [x.split('\t') for x in (tree/'manifest.sha256').read_text().splitlines()])
r={'status':'INDEPENDENT_NODE_COMMON_RAW_BINDING_STATS_PASS_NOT_ADOPTED','platform':kind,'mode':mode,'handle':summary['handle'],'source':summary['source'],'cases':len(ids),'TIME':len(ids)*21,'CHECK_per_process':len(ids),'REP_per_process':28 if mode=='public-small' else 0,'source_files_verified':378,'fresh_process_identities':identities,'all_owner_CSV_stats_exact':True,'cache_origin_controls':cache_counts,'per_case':result,'relative_to_current_policy':comparisons,'whole_process_envelopes':envelopes,'cases_without_proven_fullring_measured_batches':[k for k,v in fullring.items() if not v],'scope':'ThreefreshF/R/F processes; normalMocha hooks andexactoneoptionaltest confirmed; completecase CHECKs distinctfrom64slot escapingringdigests. AllocationNA isnotzero; JScoarseheapUsed isnotpeak orownedretention, WasmheapNA. RSSwholeprocess includesMocha/registration/reference/runtime. Parameter-labelled differences mayselectidenticalarithmetic; no causalpolicy/threshold/parallel/publicadoption fromsubset. Publicmode iscurrentroute baseline, not afteradoptionguard.'}
(p/f'independent-{platform}-{mode}-2-raw-audit.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS',kind,mode,'TIME',len(ids)*21,'cases',len(ids),'NAallocation/CSV/identities/closure/sourcebound')
print('All3slower/faster default-relative',sum(x['all3_slower'] for x in comparisons),sum(x['all3_faster'] for x in comparisons),'sub64',sum(not v for v in fullring.values()))
PY
```
