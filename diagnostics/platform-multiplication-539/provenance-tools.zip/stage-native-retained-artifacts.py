from pathlib import Path
import json,hashlib,shutil,subprocess,copy
p=Path(__file__).resolve().parent; w=p/'worktree'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
f=json.loads((p/'final-native-retention-freeze.json').read_text());source=Path(f['source_manifest'])
for line in source.read_text().splitlines():
 h,path=line.split('\t');assert sha(Path(path))==h,path
log=p/'native-retained-release-build-1.log';assert 'BUILD SUCCESSFUL' in log.read_text()
producer=w/'build/bin/macosArm64/calibration539ReleaseTest/calibration539.kexe'
tree=p/'artifacts'/('native-release-retained-'+f['source_commit'][:7]);tree.mkdir()
exe=tree/'calibration539.kexe';shutil.copy2(producer,exe);h=sha(exe);assert h==sha(producer)
m=tree/'manifest.sha256';m.write_text(h+'\tcalibration539.kexe\n')
runtime={cmd:subprocess.check_output([cmd,'-L',str(exe)] if cmd=='/usr/bin/otool' else [cmd,str(exe)] if cmd=='/usr/bin/file' else [cmd,'-a'] if cmd=='/usr/bin/uname' else [cmd],text=True) for cmd in ['/usr/bin/file','/usr/bin/otool','/usr/bin/sw_vers','/usr/bin/uname']}
b=dict(source=f['source_commit'],handle=14439,exit_code=0,source_files_post_match=405,source_manifest_sha256=sha(source),log_sha256=sha(log),producer=str(producer),executable=str(exe),executable_sha256=h,executable_bytes=exe.stat().st_size,tree=str(tree),manifest_sha256=sha(m),runtime=runtime,scope='Native public direct virtualserial; scalar distinct32/alias+unbalanced64/384/16 unchanged. Candidate engine retained; no newguard28.')
ledger=p/'native-retained-release-build-1-summary.json';ledger.write_text(json.dumps(b,indent=2)+'\n')
old=json.loads((p/'native-final-three-groups-prelaunch.json').read_text());groups=[]
for idx in [0,2]:
 g=copy.deepcopy(old['groups'][idx]);a=g['argv'];a[2:8]=[str(tree),sha(m),str(source),sha(source),str(exe),h]
 if idx==0:
  g['name']='retained-contracts11';a[-1]=str(p/'retained-native-contracts-1')
 else:
  g['name']='retained-public';a[1]=str(p/'run-native-public-retained.main.kts');a[8]='native-public-serial-retention';a[-1]=str(p/'actual-public-native-serial-retention-1')
  g['post_checker_argv']=[a[0],str(p/'check-native-public-retained.main.kts'),a[-1]];g['post_checker_sha256']=sha(Path(g['post_checker_argv'][1]))
 g['launcher_sha256']=sha(Path(a[1]));assert not Path(a[-1]).exists();groups.append(g)
(p/'native-retained-two-groups-prelaunch.json').write_text(json.dumps(dict(source=f['source_commit'],source_files=405,source_manifest=str(source),source_manifest_sha256=sha(source),build_summary=str(ledger),build_summary_sha256=sha(ledger),groups=groups),indent=2)+'\n');print(json.dumps(b,indent=2))
