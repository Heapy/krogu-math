# JS current paired guard independent reproduction

Read-only raw/statistical analysis; no numerical benchmark executed.

```bash
python3 - <<'PY'
from pathlib import Path
import json,csv,re,statistics as st,hashlib,math
r=Path('.codex-work/539');platform='JS';stem='actual-public-node-js-paired-small-2';handle=6872
d=r/stem;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=json.loads((r/(stem+'-summary.json')).read_text());pre=json.loads((r/'thin-public-remaining-six-prelaunch.json').read_text());g=next(x for x in pre['groups'] if x['name']=='portable-paired-'+platform);a=g['argv'];props=lambda p:dict(x.split('=',1) for x in p.read_text().splitlines() if '=' in x);before=props(d/'binding-before.txt');assert before['source_manifest_sha256']==a[7] and before['baseline_manifest']==a[3] and before['current_manifest']==a[5]
ids=[f'{api}/{bits}/{shape}' for bits in [1,30,63,64,127,511,1023] for shape in ['distinct','square'] for api in ['public','parallel-public']];records={};identities=[];resources=[];partial=[];digestfull={};rawbind=[]
assert (d/'runtime.log').read_text().strip()=='v24.16.0'
for fork in range(3):
 order='reverse' if fork==1 else 'forward';expected=ids[::-1] if fork==1 else ids
 for label,tree,mh in [('baseline',Path(a[2]),a[3]),('current',Path(a[4]),a[5])]:
  f=d/f'fork{fork}-{label}.log';t=f.read_text();ls=t.splitlines();assert Path(str(f)+'.exit').read_text()=='0\n';b=props(Path(str(f)+'.binding'));assert b['label']==label and b['source_manifest_sha256']==a[7] and b['artifact_manifest_sha256']==mh and b['log_sha256']==sha(f) and b['runtime_id']==before['runtime_id']==a[10] and b['profile']==f'public-small,{order},7,20'
  own=[x for x in ls if x.startswith('# OWN539 ')];assert len(own)==1 and b['identity']==own[0];m=re.fullmatch(r'# OWN539 pid=(\d+) start_epoch_ms=(\d+) node=v24.16.0 kind='+platform+r' flags=\["--expose-gc"\]',own[0]);assert m and int(m[1])>0 and int(m[2])>0 and b['pid']==m[1] and b['start_epoch_ms']==m[2];identities.append((int(m[1]),int(m[2])))
  entry=tree/(tree/'entry.txt').read_text().strip();mocha=tree/'mocha/node_modules/mocha/index.js';host=tree/'node-calibration-host.cjs';assert Path(str(f)+'.argv.txt').read_text().splitlines()==['/usr/bin/time','-l',a[8],'--expose-gc',str(host),str(entry),str(mocha),platform]
  assert ls.count(f'# ORIGIN539 entry={entry} mocha={mocha}')==1
  for phase in ['before-run','after-run']:
   line=[x for x in ls if x.startswith('# CACHEORIGIN539 phase='+phase+' ')];assert len(line)==1 and line[0].endswith(' owned=true') and int(re.search(r'files=(\d+)',line[0])[1])>0
  assert ls.count('# SELECTED539 tests=1 passes=1 failures=0 pending=0')==1;assert ls.count(f'# calibration539 platform={platform} Node v24.16.0 mode=public-small order={order} cases=28')==1;assert [x for x in ls if x.startswith('PASS539')]==['PASS539,28,7']
  assert [x.split(',') for x in ls if x.startswith('CHECK539')]==[['CHECK539',n,'PASS'] for n in expected]
  reps=[x.split(',') for x in ls if x.startswith('REP539')];assert len(reps)==28 and {x[1] for x in reps}==set(ids)
  for marker,n,v in reps:
   api,bits,shape=n.split('/');bits=int(bits);z=1 if bits==1 else (1<<(bits-1))+1;assert int(v)==z*(z if shape=='square' else z+2)
  groups={n:[] for n in ids};times=[x.split(',') for x in ls if x.startswith('TIME539')];assert len(times)==196 and [x[1] for x in times]==[n for n in expected for _ in range(7)]
  for x in times:
   assert len(x)==9;_,n,sample,count,wall,cpu,alloc,heap,digest=x;sample,count,wall,cpu=map(int,[sample,count,wall,cpu]);assert sample==len(groups[n]) and 0<=sample<7 and 1<=count<=8388608 and count&(count-1)==0 and wall>0 and cpu>=0 and alloc=='NA';heap=None if heap=='NA' else int(heap);assert heap is None or heap>=0;assert platform!='Wasm' or heap is None;int(digest);groups[n].append(dict(sample=sample,count=count,wall_ns=wall,cpu_ns=cpu,allocated_bytes=None,coarse_heap_bytes=heap,digest=digest))
  per={}
  for n,v in sorted(groups.items()):
   assert len(v)==7 and len({x['count'] for x in v})==len({x['digest'] for x in v})==1;per[n]=dict(wall_ns=st.median(x['wall_ns']/x['count'] for x in v),cpu_ns=st.median(x['cpu_ns']/x['count'] for x in v),caller_allocated_bytes=None,cpu_available_samples=7,allocation_available_samples=0,samples=v)
   if v[0]['count']>=64:digestfull.setdefault(n,set()).add(v[0]['digest'])
   else:partial.append(dict(fork=fork,label=label,case=n))
  records[f'{fork}/{label}']=dict(pid=int(m[1]),start_epoch_ms=int(m[2]),cases=per);rss=int(re.search(r'^\s*(\d+)\s+maximum resident set size$',t,re.M)[1]);resources.append(dict(fork=fork,label=label,rss_bytes=rss));rawbind.append(dict(fork=fork,label=label,log_sha256=sha(f),binding_sha256=sha(Path(str(f)+'.binding')),pid=int(m[1]),start_epoch_ms=int(m[2])))
assert len(set(identities))==6 and all(len(v)==1 for v in digestfull.values());assert records==s['forks'] and rawbind==s['raw_bindings'] and partial==s['partial_ring_scope']
chron=[records[f'{f}/{lab}']['start_epoch_ms'] for f in range(3) for lab in (['current','baseline'] if f==1 else ['baseline','current'])];assert chron==sorted(chron) and len(set(chron))==6
cases=[]
for n in sorted(ids):
 base=[records[f'{f}/baseline']['cases'][n]['wall_ns'] for f in range(3)];cur=[records[f'{f}/current']['cases'][n]['wall_ns'] for f in range(3)];rat=[x/y for x,y in zip(cur,base)];delta=[x-y for x,y in zip(cur,base)];cases.append(dict(case=n,baseline_fork_wall_ns=base,current_fork_wall_ns=cur,paired_ratios=rat,paired_deltas_ns=delta,median_paired_ratio=st.median(rat),median_paired_delta_ns=st.median(delta),investigate_15percent_AND_5ns=st.median(rat)>1.15 and st.median(delta)>5,all3_slower=min(rat)>1,all3_faster=max(rat)<1))
assert cases==s['cases'];flags=[x['case'] for x in cases if x['investigate_15percent_AND_5ns']];assert flags==s['guard_flags']
csvrows=list(csv.DictReader((r/(stem+'-summary.csv')).open()));assert len(csvrows)==28
for x,z in zip(csvrows,cases):
 assert x['case']==z['case'] and float(x['median_paired_ratio'])==z['median_paired_ratio'] and float(x['median_paired_delta_ns'])==z['median_paired_delta_ns'] and x['investigate_15percent_AND_5ns']==str(z['investigate_15percent_AND_5ns'])
 for i in range(3):assert float(x[f'pair{i}_ratio'])==z['paired_ratios'][i] and float(x[f'pair{i}_delta_ns'])==z['paired_deltas_ns'][i]
for line in Path(a[6]).read_text().splitlines():
 h,n=line.split('\t');assert sha(Path(n))==h
assert sha(Path(a[6]))==a[7] and sha(Path(a[8]))==a[9]
out={'status':'PASS_INDEPENDENT_PAIRED_RAW_STATS_INVESTIGATION_FLAGS_NOT_GUARD_CLEARANCE','platform':platform,'handle':handle,'source':pre['source'],'source_files_verified':405,'summary_sha256':sha(r/(stem+'-summary.json')),'TIME':1176,'REP':168,'CHECK':168,'fresh_pid_start':identities,'cases':cases,'guard_flags':flags,'whole_child_resources':resources,'partial_ring_scope':partial,'scope':'Independent28BOTHAPI offlinepolynomialREP/fullCHECK/exactorder/counts/originclosure/6freshruntimePID/CPU/NA/statistics allmatch. Historical07910baseline distinctfromcurrent2d74. Guardflagsnotnoisewaived orautomaticrejection; noactualworkerbackend atthese≤35limbinputs. Sourcebranchmappingseparate. AllocationNA notzero; JScoarseheap/WasmNA andwholechildRSS notperopownedmemory.'};p=r/('independent-'+stem+'-raw-audit.json');p.write_text(json.dumps(out,indent=2)+'\n');print('PASS',sha(p));print('flags',flags);print('all3slower',sum(x['all3_slower'] for x in cases),'all3faster',sum(x['all3_faster'] for x in cases))
PY
```

