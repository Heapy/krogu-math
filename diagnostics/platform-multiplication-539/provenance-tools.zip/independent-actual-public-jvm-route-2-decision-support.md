# Current JVM actual frontend decision support

Source2d74, actual45FIRST/1260warm. All8 eligible points pass frozen reused-pool latency margin and adjacent-size consistency. This is latency eligibility, not automatic resource/adoption acceptance.

| point | parallel / fastest serial (fork0/1/2) | CPU ratios | approximate allocation delta B |
|---|---|---|---|
| 256/distinct | 0.998 / 0.983 / 0.947 | 0.993 / 1.010 / 0.953 | 0 / 32 / 0 |
| 256/square | 1.226 / 1.573 / 1.285 | 1.223 / 1.630 / 1.301 | -8560 / -8560 / -8560 |
| 256/ratio2 | 0.997 / 0.866 / 1.025 | 0.998 / 0.920 / 1.023 | 0 / 32 / -3296 |
| 1024/distinct | 1.021 / 1.032 / 1.008 | 1.018 / 0.999 / 1.001 | 32 / 0 / 0 |
| 1024/square | 1.033 / 1.054 / 1.063 | 1.026 / 1.042 / 1.058 | -21880 / -21880 / -21880 |
| 1024/ratio2 | 0.992 / 1.029 / 1.078 | 0.986 / 1.029 / 1.074 | 0 / 0 / 32 |
| 4096/distinct | 0.362 / 0.343 / 0.731 | 1.023 / 0.989 / 1.974 | 98262 / 98304 / 98340 |
| 4096/square | 0.362 / 0.353 / 0.597 | 1.035 / 1.033 / 1.219 | 453 / 461 / 440 |
| 4096/ratio2 | 1.005 / 1.069 / 0.975 | 1.005 / 1.090 / 0.964 | 0 / 32 / -57184 |
| 8192/distinct | 0.351 / 0.343 / 0.413 | 1.030 / 1.004 / 1.130 | 447 / 196643 / 196549 |
| 8192/square | 0.349 / 0.352 / 0.464 | 1.022 / 1.040 / 1.341 | 180261 / 439 / 180157 |
| 8192/ratio2 | 0.516 / 0.533 / 0.536 | 1.013 / 1.075 / 1.065 | 114959 / 114975 / 114975 |
| 16384/distinct | 0.346 / 0.350 / 0.361 | 1.030 / 1.028 / 1.070 | 393046 / 393196 / 244 |
| 16384/square | 0.346 / 0.346 / 0.339 | 1.028 / 1.027 / 1.004 | 178 / 170 / 292 |
| 16384/ratio2 | 0.513 / 0.497 / 0.508 | 1.013 / 0.994 / 0.999 | 229744 / 229670 / 229548 |

Distinct/square4096–16384 and ratio28192–16384 qualify; JVM ratio2 has right=n/2, so4096 remains serial min2048. Node/Native shape convention differs. All15 points remain visible, including lower/fallback adverse.

Eligible FIRST11.46–37.65ms is actual startup cost after untimed preparation, without a matched serialFIRST baseline. Warm calls reuse actual classloader pool. CPU up1.974x on4096distinctfork2 and approximate allocation delta up393196B remain disclosed. Wholechild RSS spans JDK/preparation/allroutes/pool, not per-operation retained/peak memory.

Current paired28 guard has zeroflags and full2108 correctness PASS separately. Historical route1 and flagged guard1 remain bound todf733; no isolated stage-speedup/JIT causality claim. Final cross-platform and resource/lifecycle judgment remains pending.
