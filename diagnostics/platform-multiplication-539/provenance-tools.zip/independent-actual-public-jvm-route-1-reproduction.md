# Independent JVM actual-public raw audit reproduction

Read-only raw/statistical analysis; no benchmark is executed.

```bash
python3 - <<'PY'
from pathlib import Path
import hashlib,json,csv,re,statistics as st,math,ast
r=Path('.codex-work/539');d=r/'actual-public-jvm-route-1';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=json.loads((r/'actual-public-jvm-route-1-summary.json').read_text());pre=json.loads((r/'jvm-actual-public-selected-prelaunch.json').read_text())['groups'][0];a=pre['argv'];tree=Path(a[2]);binding=dict(x.split('=',1) for x in (d/'binding-before.txt').read_text().splitlines());assert binding['source_manifest_sha256']==a[5] and binding['artifact_manifest_sha256']==a[3] and binding['java_sha256']==a[7] and binding['launcher_sha256']==pre['launcher_sha256']
assert 'java.runtime.version = 25.0.4+9-LTS' in (d/'runtime.log').read_text() and 'java.vendor = BellSoft' in (d/'runtime.log').read_text()
points=[f'{n}/{h}' for n in [256,1024,4096,8192,16384] for h in ['distinct','square','ratio2']];variants=['kernel','frame','public','parallel'];rows={};first=[];identities=[];resources=[];allstats=[]
for fork in range(3):
 order='reverse' if fork==1 else 'forward'
 for point in points:
  size,shape=point.split('/');f=d/f'fork{fork}-{size}-{shape}.log';text=f.read_text();ls=text.splitlines();assert Path(str(f)+'.exit').read_text()=='0\n';owner=next(x for x in s['files'] if Path(x['path']).name==f.name);assert sha(f)==owner['sha256'] and f.stat().st_size==owner['bytes']
  b=dict(x.split('=',1) for x in Path(str(f)+'.binding').read_text().splitlines());assert b['source_manifest_sha256']==a[5] and b['artifact_manifest_sha256']==a[3] and b['runtime_id']==a[9]
  meta=next(x for x in ls if x.startswith('METAPUBLIC539,'));m=re.fullmatch(r'METAPUBLIC539,pid=(\d+),start=(\d+),flags=\[-Xms256m, -Xmx512m, -XX:\+UseG1GC\]',meta);assert m and int(m[1])>0 and int(m[2])>0 and b['identity']==meta;identities.append((int(m[1]),int(m[2])))
  argv=Path(str(f)+'.argv.txt').read_text().splitlines();assert argv==['/usr/bin/time','-l',a[6],'-Xms256m','-Xmx512m','-XX:+UseG1GC','-cp',':'.join(str(tree/n) for n in (tree/'classpath.txt').read_text().splitlines()),'ActualPublicRoute539',size,shape,order,'7',sha(tree/'main.jar'),sha(tree/'actual-public-harness.jar')]
  for cls,jar in [('ActualPublicRoute539','actual-public-harness.jar'),('io.heapy.krogu.math.BigInteger','main.jar'),('io.heapy.krogu.math.MagnitudeMultiplication','main.jar'),('io.heapy.krogu.math.MultiplicationPolicy539','main.jar')]:
   assert ls.count(f'ORIGINPUBLIC539,{cls},{tree/jar},{sha(tree/jar)}')==1
  activity=next(x for x in ls if x.startswith('ACTIVITYPUBLIC539,'));ac=re.fullmatch(r'ACTIVITYPUBLIC539,eligible=(true|false),owned_before=0,owned_after_first=(\d+)',activity);assert ac
  eligible=int(size)//(2 if shape=='ratio2' else 1)>=4096;assert (ac[1]=='true')==eligible;assert 1<=int(ac[2])<=2 if eligible else int(ac[2])==0
  fv=[x.split(',') for x in ls if x.startswith('FIRSTPUBLIC539,')];assert len(fv)==1 and len(fv[0])==5 and fv[0][1]==point;fw,fc,fa=map(int,fv[0][2:]);assert fw>0 and fc>=0 and fa>=0;first.append(dict(fork=fork,point=point,wall_ns=fw,cpu_ns=fc,allocation_bytes_approx=fa))
  raw=[x.split(',') for x in ls if x.startswith('WARM_PUBLIC539,')];assert [x[1] for x in raw]==[point+'/'+v for v in (variants[::-1] if fork==1 else variants) for _ in range(7)];assert ls.count('PASS_ACTUAL_PUBLIC539')==1
  for v in variants:
   rs=[x for x in raw if x[1]==point+'/'+v];assert all(len(x)==7 for x in rs) and [int(x[2]) for x in rs]==list(range(7));counts={int(x[3]) for x in rs};assert len(counts)==1;count=counts.pop();assert 1<=count<=1048576 and count&(count-1)==0;wall=[int(x[4])/count for x in rs];cpu=[int(x[5])/count for x in rs];alloc=[int(x[6])/count for x in rs];assert min(wall)>0 and min(cpu)>=0 and min(alloc)>=0
   z=dict(fork=fork,point=point,variant=v,wall_median_ns=st.median(wall),wall_min_ns=min(wall),wall_max_ns=max(wall),cpu_median_ns=st.median(cpu),allocation_median_bytes_approx=st.median(alloc),count=count,samples_wall_ns=wall,activity=activity);allstats.append(z);rows[fork,point,v]=z
  res=next(x for x in ls if x.startswith('RESOURCEPUBLIC539,'));rm=re.fullmatch(r'RESOURCEPUBLIC539,processors=(\d+),peak_threads_all=(\d+),live_threads_all=(\d+),heap_used=(\d+)',res);assert rm and int(rm[1])==14 and int(rm[2])>=int(rm[3])>0
  rss=int(re.search(r'^\s*(\d+)\s+maximum resident set size$',text,re.M)[1]);peak=int(re.search(r'^\s*(\d+)\s+peak memory footprint$',text,re.M)[1]);resources.append(dict(fork=fork,point=point,rss_bytes=rss,peak_footprint_bytes=peak,all_thread_peak=int(rm[2]),live_threads=int(rm[3]),coarse_heap_used=int(rm[4]),workers_after_first=int(ac[2]),eligible=eligible))
assert len(set(identities))==45 and s['FIRST']==len(first)==45 and s['WARM']==1260 and len(allstats)==180
assert allstats==s['fork_stats'] and first==s['first']
result=[];allcomparators=[]
for point in points:
 ratios=[];cp=[];ad=[];comps=[]
 for fork in range(3):
  serial=min(variants[:3],key=lambda v:rows[fork,point,v]['wall_median_ns']);base=rows[fork,point,serial];par=rows[fork,point,'parallel'];ratios.append(par['wall_median_ns']/base['wall_median_ns']);cp.append(par['cpu_median_ns']/base['cpu_median_ns']);ad.append(par['allocation_median_bytes_approx']-base['allocation_median_bytes_approx']);comps.append(serial)
 for v in variants[:3]:allcomparators.append(dict(point=point,comparator=v,ratios=[rows[f,point,'parallel']['wall_median_ns']/rows[f,point,v]['wall_median_ns'] for f in range(3)]))
 z=dict(point=point,parallel_vs_fastest_matched_serial_fork_ratios=ratios,median_ratio=st.median(ratios),all_pairs_10pct=max(ratios)<=.90,median_20pct=st.median(ratios)<=.80,cpu_ratios_same_wall_comparator=cp,allocation_delta_bytes_approx=ad,first_wall_ns=[x['wall_ns'] for x in first if x['point']==point]);assert z==next(x for x in s['point_summaries'] if x['point']==point);z['fastest_matched_serial_variants']=comps;z['eligible_first_activity']=all(x['eligible'] for x in resources if x['point']==point);result.append(z)
with (r/'actual-public-jvm-route-1-summary.csv').open() as f:
 cells=list(csv.DictReader(f))
for x,z in zip(cells,result):
 for key,value in x.items():
  if isinstance(z[key],list):assert ast.literal_eval(value)==z[key]
  elif isinstance(z[key],bool):assert value==str(z[key])
  elif isinstance(z[key],str):assert value==z[key]
  else:assert float(value)==z[key]
for line in Path(a[4]).read_text().splitlines():
 h,n=line.split('\t');assert sha(Path(n))==h
assert sha(Path(a[4]))==a[5] and sha(tree/'manifest.sha256')==a[3] and sha(Path(a[6]))==a[7]
eligible=[x['point'] for x in result if x['all_pairs_10pct'] and x['median_20pct'] and x['eligible_first_activity']]
out={'status':'PASS_INDEPENDENT_ACTUAL_JVM_FIRST_WARM_RAW_BINDING_STATS_NOT_ADOPTION','handle':85167,'source':'df733c0cb929488ce52d25dcde6db9f06f7fc204','source_files_verified':405,'summary_sha256':sha(r/'actual-public-jvm-route-1-summary.json'),'FIRST':45,'WARM':1260,'fresh_pid_start':identities,'per_fork_stats':allstats,'point_summaries':result,'all_comparator_ratios':allcomparators,'whole_process_resources':resources,'frozen_latency_screen_points':eligible,'scope':'Actual first public call after JDK/preparation, poolabsent andpositiveownedworkers oneligiblefirst return; no pairedFIRSTserialspeedup. Repeated rows reuse actual classloaderpool; no per-operation shutdown or inventedamortization. All-live-threadallocation approximation includesobserverbookkeeping/maymiss terminatedthreads; wholechildRSS/runtime/JDKallroutes notperopownedpeak. Sharedhost CPUload snapshot notcontinuousisolation/causeproof. Independent fullJDKoutput/inputchecks outsidecounters sourcebound, no printedcrossrepresentationdigest claim.'};p=r/'independent-actual-public-jvm-route-1-raw-audit.json';p.write_text(json.dumps(out,indent=2)+'\n');print('PASS',sha(p));print(json.dumps(result))
PY
```

