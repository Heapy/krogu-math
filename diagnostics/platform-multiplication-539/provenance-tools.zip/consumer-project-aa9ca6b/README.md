# Independent published-KLIB consumer — explicit serial-decline mode

External SOURCE ONLY, UNCOMPILED/UNRESOLVED/UNRUN for the new declined source. Exact historical active fixtures/controller/manifest are retained in `history/active-before-js-wasm-decline`; earlier real two-worker/six-job/SHORT/IDLE proofs remain source-labelled and are not relabelled current activation or cleanup evidence. No shared source/build/runtime changed by this preparation.

This standalone Kotlin2.4.21 consumer uses only actual isolated io.heapy.krogu:krogu-math GAV publication: JS CommonJS and Wasm ESM, no source/project/friend/test/diagnostic dependency or manual worker asset copy. Actual source/publication/consumer closure SHA binding remains required. Final production explicitly declines worker activation on BOTH targets before physical helpers. No CPU<=2 unsupported escape is allowed; all CPU counts must execute exact numeric contracts and resource absence checks.

The same real public three products (distinct, alias and opposite sign) are compared against independent shifted power-of-two polynomial identities, with original public input preservation. One application-main sentinel prevents worker/app entrypoint reentry. Four untimed observations (before arithmetic and after each public call) require the production registry absent and controller-owned temp namespace empty. The host repeats final absence and parent checks empty namespace after natural terminal0. These are explicit no-activation observations bound to compiled early fallback, not claims of worker retirement/cleanup or speed improvement. The consumer adds no observer keepalive;180s/5s owned failure cleanup remains a bound, not normal lifetime. Actual new publication/link/run proof is still pending.

## Future build commands — not executed

Use existing repo Gradle9.8.1 wrapper and BellSoft25.0.4+9-LTS via clean explicit JAVA_HOME/PATH. `publish-delivery.init.gradle.kts` adds an external task-owned Delivery539 repository through the existing Maven Publish plugin without editing producer source. Future producer command (not executed):

```
<producer>/gradlew --no-daemon --max-workers=1 --project-dir <producer> \
  --init-script <this-directory>/publish-delivery.init.gradle.kts \
  -Pdelivery539Repository=<new-isolated-Maven-directory> \
  publishKotlinMultiplatformPublicationToDelivery539Repository \
  publishJsPublicationToDelivery539Repository publishWasmJsPublicationToDelivery539Repository
```

This selects root metadata and the two actual consumer targets; it does not require unrelated Native/JVM publication. Task names follow existing KMP publication names and still require first actual Gradle configuration/build proof. Record actual command/exit and produce the complete actual publication ledger before consumer resolution.

Once those actual inputs exist, consumer command:

```
<repo>/gradlew --no-daemon --max-workers=1 --project-dir <this-directory> \
  -PkroguRepository=<isolated-Maven-directory> \
  -PkroguVersion=<exact-published-version> \
  -PkroguCommit=<actual-producer-40hex> \
  -PpublicationLedger=<external-publication-ledger.json> \
  -PpublicationLedgerSha256=<its-64hex> \
  verifyPublished539 jsProductionExecutableCompileSync wasmJsProductionExecutableCompileSync
```

Record actual Gradle/JDK/compiler identities, argv/exit, resolved metadata/classpath and file SHA, source pre/post freeze, and JS/Wasm linked output. No dependency resolution/download/build has happened in this preparation. Build descriptor requires actual supplied hashes; placeholders are not passing evidence. This is an independent consumer after source application, not a comparison measurement or accepted539 completion claim.

## Future declined runtime command

Create exact complete external runtime and isolated-publication ledgers as before, including all files/metadata/maps. SourceCommit and publicationLedgerSha256 must match the actual producer/consumer build chain. Pinned Node24.16.0 SHA and actual generated entry are required.

```
<pinned-node> check-delivery.cjs <same-node> <node-SHA> \
  <linked-root> <actual-entry-relative.js-or.mjs> <linked-ledger> <linked-SHA> \
  <isolated-repository> <publication-ledger> <publication-SHA> \
  <producer-commit> <js-or-wasm> declined <new-output>
```

Run one fresh declined consumer process per target; lifecycle mode must be exactly `declined`, not historical idle/short. Controller creates private mode0700 `production-temp` under owned output and passes TMPDIR/TMP/TEMP plus KROGU539_TEMP_ROOT. The app-init witness is outside that namespace. No assets are staged in it. Four exact SERIAL_DECLINE_DELIVERY539 observations plus NUMERIC_DELIVERY539,PASS, one app-init and DELIVERY539,PASS_SERIAL_DECLINED are mandatory; old POOL/IDLE/UNSUPPORTED output cannot pass. COMPLETE status is PASS_SERIAL_DECLINED only after0exit, flushed logs, unchanged complete ledgers and empty non-symlink temp container. Containers remain task-local evidence, not leaked production files.

Existing postspawn terminal fence,180s deadline/5s kill escalation,4MiB bounded persisted output, FD/error handling/fsync/close and exact pre/post publication/runtime inventories remain. Failures stay failed with partial logs; no assertion/unsupported path silently substitutes for proof. This fixture does not measure FIRST/warm/RSS or support a current backend activation claim; the separate45point comparison and historical active delivery/resource evidence keep their own scope.
