package delivery539

import io.heapy.krogu.math.BigInteger

internal expect fun markApplicationInit539()
internal expect fun inspectPool539()

fun main() {
    markApplicationInit539()
    inspectPool539()
    val n = 30 * 4095
    val power = BigInteger.ONE.shiftLeft(n)
    val a = power.add(BigInteger.valueOf(31))
    val b = power.add(BigInteger.valueOf(47))
    // Independent polynomial identities, no multiply/parallelMultiply in oracle.
    val product = BigInteger.ONE.shiftLeft(2 * n).add(BigInteger.valueOf(78).shiftLeft(n)).add(BigInteger.valueOf(1457))
    val square = BigInteger.ONE.shiftLeft(2 * n).add(BigInteger.valueOf(62).shiftLeft(n)).add(BigInteger.valueOf(961))
    val originalA = a.toString(16); val originalB = b.toString(16)
    check(a.parallelMultiply(b) == product)
    inspectPool539()
    check(a.parallelMultiply(a) == square)
    inspectPool539()
    check(a.negate().parallelMultiply(b) == product.negate())
    check(a.toString(16) == originalA && b.toString(16) == originalB)
    inspectPool539()
    println("NUMERIC_DELIVERY539,PASS")
}
