package delivery539
internal actual fun markApplicationInit539(): Unit = js("""(function(){
const w=process.getBuiltinModule('worker_threads');
if(!w.isMainThread || (w.workerData&&w.workerData.krogu539Role)) throw Error('Consumer application reentered in worker');
const key=Symbol.for('krogu539.consumer.application.init');
process[key]=(process[key]||0)+1;
if(process[key]!==1) throw Error('Repeated consumer application initialization');
const fs=process.getBuiltinModule('fs');
const target=process.env.KROGU539_APP_INIT_PATH;
if(!target) throw Error('Missing owned application-init witness');
fs.writeFileSync(target,String(process.pid)+'\n',{flag:'wx',mode:384});
console.log('APPINIT539,'+process.pid);
})()""")
internal actual fun inspectPool539(): Unit = js("""(function(){
const p=process, fs=p.getBuiltinModule('fs'), os=p.getBuiltinModule('os');
const root=p.env.KROGU539_TEMP_ROOT;
if(!root || fs.realpathSync(os.tmpdir())!==fs.realpathSync(root) || fs.lstatSync(root).isSymbolicLink()) throw Error('Owned temp namespace missing');
if(p[Symbol.for('io.heapy.krogu.node-parallel-539.v1')]!==undefined || fs.readdirSync(root).length!==0) throw Error('Intentional serial decline activated backend/resources');
const key=Symbol.for('krogu539.consumer.serialDeclineChecks');
p[key]=(p[key]||0)+1;
if(p[key]>4) throw Error('Unexpected decline observation count');
console.log('SERIAL_DECLINE_DELIVERY539,js,'+p[key]+',true,true');
})()""")
