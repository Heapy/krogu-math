# Independent public baseline output recomputation

No benchmark launched. Checks both API representations against independent exact integer products. This is the current-route baseline, not an after-adoption regression guard.

```sh
python3 - <<'PY'
from pathlib import Path
import json,csv,re,hashlib,statistics as st,math
p=Path('.codex-work/539');d=p/'calibration-jvm-public-small-1';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
summary=json.loads((p/'calibration-jvm-public-small-1-summary.json').read_text());pre=json.loads((p/'jvm-kernel-small-1-prelaunch.json').read_text())
assert summary['exit']==summary['checker_exit']==0
assert all(sha(p/f)==h for f,h in summary['files'].items())
assert sha(p/summary['csv'])==summary['csv_sha256']
ids=[f'{method}/{bits}/{shape}' for bits in [1,30,63,64,127,511,1023] for shape in ['distinct','square'] for method in ['public','parallel-public']]
assert len(ids)==28 and len(set(ids))==28
allrows={};identities=[];hashes={};envelopes=[];tree=Path(pre['argv'][2])
for i in range(3):
 f=d/f'fork{i}.log';lines=f.read_text().splitlines();binding=dict(x.split('=',1) for x in Path(str(f)+'.binding').read_text().splitlines())
 assert Path(str(f)+'.exit').read_text().strip()=='0'
 assert binding['source_manifest_sha256']==pre['argv'][5] and binding['artifact_manifest_sha256']==pre['argv'][3]
 identity=re.search(r'# OWN539 pid=(\d+) start_epoch_ms=(\d+) max_heap=(\d+) flags=(.+)',f.read_text());pid,start,heap,flags=identity.groups()
 assert int(pid)>0 and int(start)>0 and int(heap)==536870912
 assert binding['pid']==pid and binding['start_epoch_ms']==start
 assert '-Xms256m' in flags and '-Xmx512m' in flags and '-XX:+UseG1GC' in flags
 identities.append((pid,start));order='reverse' if i==1 else 'forward'
 header=next(x for x in lines if x.startswith('# calibration539 '));assert f'mode=public-small order={order} cases=28' in header and 'JVM BellSoft 25.0.4+9-LTS aarch64' in header
 for cls,j in [('MagnitudeMultiplication','main.jar'),('MultiplicationPolicy539','main.jar'),('MultiplicationCalibration539JvmMain','probe.jar'),('MultiplicationCampaign539','probe.jar')]:assert f'# ORIGIN539 {cls}={tree/j}' in lines
 reps=[x.split(',') for x in lines if x.startswith('REP539,')]
 assert len(reps)==28 and {x[1] for x in reps}==set(ids)
 for _,name,value in reps:
  method,bits,shape=name.split('/');bits=int(bits);v=(1<<(bits-1))+(0 if bits==1 else 1);expected=v*v if shape=='square' else v*(v+2);assert int(value)==expected
 checks=[x.split(',')[1] for x in lines if x.startswith('CHECK539,')];assert checks==(list(reversed(ids)) if i==1 else ids)
 assert lines.count('PASS539,28,7')==1
 argv=Path(str(f)+'.argv.txt').read_text().splitlines();assert argv[-1]==f'public-small,{order},7,20' and argv[:2]==['/usr/bin/time','-l']
 rows=list(csv.reader(x for x in lines if x.startswith('TIME539,')));assert len(rows)==196
 group={}
 for row in rows:
  assert len(row)==9;_,name,sample,count,wall,cpu,allocation,coarse,digest=row
  assert name in ids and 0<=int(sample)<7 and 0<int(wall)<=60_000_000_000
  count=int(count);assert count>0 and count<=8388608 and count&(count-1)==0
  assert all(int(x)>=0 for x in [cpu,allocation,coarse]);assert -(2**31)<=int(digest)<2**31
  group.setdefault(name,[]).append({'sample':int(sample),'count':count,'wall':int(wall),'cpu':int(cpu),'allocation':int(allocation),'heap':int(coarse),'digest':int(digest)})
 assert set(group)==set(ids)
 for name,rr in group.items():
  assert len(rr)==7 and {r['sample'] for r in rr}==set(range(7)) and len({r['count'] for r in rr})==1
  assert len({r['digest'] for r in rr})==1
  hashes.setdefault(name,set()).update(r['digest'] for r in rr)
 allrows[i]=group
 rss=re.search(r'^\s*(\d+)\s+maximum resident set size$',f.read_text(),re.M);peak=re.search(r'^\s*(\d+)\s+peak memory footprint$',f.read_text(),re.M)
 assert rss and peak
 envelopes.append({'fork':i,'whole_process_rss_bytes':int(rss[1]),'whole_process_peak_footprint_bytes':int(peak[1])})
assert len(set(identities))==3
fullring={name:all(allrows[i][name][0]['count']>=64 for i in range(3)) for name in ids}
assert all(len(hashes[name])==1 for name in ids if fullring[name])
result=[]
for name in sorted(ids):
 groups=[allrows[i][name] for i in range(3)]
 wall=[st.median(r['wall']/r['count'] for r in rr) for rr in groups]
 cpu=[st.median(r['cpu']/r['count'] for r in rr) for rr in groups]
 alloc=[st.median(r['allocation']/r['count'] for r in rr) for rr in groups]
 result.append({'case':name,'wall_median_ns':st.median(wall),'wall_min_process_median_ns':min(wall),'wall_max_process_median_ns':max(wall),'cpu_median_ns':st.median(cpu),'caller_allocated_median_bytes':st.median(alloc),'coarse_heap_max_bytes':max(r['heap'] for rr in groups for r in rr),'fork_wall_ns':wall,'fork_cpu_ns':cpu,'fork_allocated_bytes':alloc})
csvrows=list(csv.DictReader((p/summary['csv']).open()));assert len(csvrows)==28
for own,r in zip(csvrows,result):
 assert own['case']==r['case']
 for k in ['wall_median_ns','wall_min_process_median_ns','wall_max_process_median_ns','cpu_median_ns','caller_allocated_median_bytes','coarse_heap_max_bytes']:assert math.isclose(float(own[k]),r[k],rel_tol=1e-14,abs_tol=1e-9),(k,r['case'],own[k],r[k])
comparisons=[]
drift=[]
for h,f in [line.split('\t') for line in Path(pre['argv'][4]).read_text().splitlines()]:
 if sha(Path(f))!=h:drift.append((f,h))
assert len(drift)==1 and drift[0][0].endswith('/src/jvmTest/kotlin/io/heapy/krogu/math/ParallelCalibration539JvmMain.kt')
approved=json.loads((p/'independent-parallel-cold-await-source-review.json').read_text())
assert drift[0][1]==approved['before_sha256'] and sha(Path(drift[0][0]))==approved['after_sha256']
assert all(sha(Path(f))==h for f,h in pre['runtime_files'].items())
for h,f in [line.split('\t') for line in (tree/'manifest.sha256').read_text().splitlines()]:assert sha(tree/f)==h
r={'status':'INDEPENDENT_JVM_PUBLIC_BASELINE_RAW_BINDING_STATS_PASS_NOT_ADOPTED','handle':summary['handle'],'source':summary['source'],'cases':28,'TIME':588,'CHECK_per_process':28,'fresh_process_identities':identities,'source_files_historically_bound':378,'current_source_matches':377,'later_single_probe_instrumentation_delta':'Reviewed awaitinsideSETUP only, applied after commonterminal; historical manifest and original artifact remain intact','all_owner_csv_statistics_exact':True,'all_case_sample_digest_consistency':True,'cross_process_digest_equal_when_each_batch_overwrites_all64slots':True,'cases_not_proven_fullring_by_measured_batch':sorted(k for k,v in fullring.items() if not v),'same_operand_policy_and_frame_digests_equal_for_proven_fullring_batches':True,'process_envelopes':envelopes,'per_case':result,'relative_to_current64_16_384_policy':comparisons,'scope':'Initial28 public-small policies/frame comparisons only. Same-process paired ratios compare prepared identical operands; not fresh baseline/candidate frontend runs. Digest is a64slot escaped ring checksum, not an isolated result hash; count<64 may retain earliercase slots, so crosscase/fork digest equality is not asserted there. Publicsmallusesmultiplication-free shifted/addpolynomialexpectedproducts; bothAPIequalitychecksandindependentofflineexactREPvalues,notruntimeJDKproductoracle. Currentpublicroute baseline only, BOTH APIs28cases with independentREPvalues; not finalbeforeafterpublicadoptionguard. Parallel/resource/selectedpolicyfinalguards andotherplatforms remain pending. Caller allocation excludesworker threads; coarse heap and wholeprocessRSS include setup/reference/runtime. No threshold/optimality/adoption claim.'}
(p/'independent-jvm-public-small-1-raw-audit.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS588TIME/28exactCSV,3freshPID/digests/source/artifacts')
print('RELATIVE default all3slower',[(x['case'],round(x['median_ratio'],3)) for x in comparisons if x['all3_slower']])
PY
```
