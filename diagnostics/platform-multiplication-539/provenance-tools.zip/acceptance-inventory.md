# Current execution checkpoint — selected JS candidate

Current production candidate is `841a8b8e111856e05d524e1b653bb1a54a68ba5e`:
389 source hashes in `selected-js-source.tsv`. JS selects K32 only for physically
distinct equal-length magnitude arrays; aliases/unbalanced retain K64; leaf16
and whole-square entry128. JVM/Native/Wasm retain the exact old64/16/384 branch.
Source review PASS and targeted JS41795 actual6methods PASS (selected3+policy3),
zero failure/error/skip; actual final guards/full4targets remain pending.

Coherent frontend/failure-fence candidate43f2cd6 passed targeted JVM84552:
12methods (frontend5+policy3+scheduler4). This is not actual public-route cost
or full-suite acceptance. JS bounded adjacent proof7001/strict52289 completed
33cases/693TIME with independent raw PASS; K16 adverse4096 supports K32 rather
than blanketK16. One finite extension is complete, no global optimum/K8 claim.
Its new BigInt oracle does not relabel historical school-only checks.

Both current worker105 campaigns are independently accepted under historical
07910ed source379: JS2205WORKER/315PUBLICRESULT and Wasm2205/315. Reused Node pool,
startup/rootload separate and teardown outside rows; no public/per-call cold
adoption claim. Actual Node public implementation/lifetime/resource decision is
OPEN; self-contained KLIB-distributed original-source worker preparation is
external only. No consumer-root import or manual installation is accepted.

First coherent Native Release build43825 completed0 (7m11s) on841a8b8;
immutable executable SHA6d457e607eac78906374e11a52e15c0730a0f0a21868301c4ef8490ff22ebd33,
manifest e8d9e00ec24584a9940c10aad8e532bd0157bcccc6b4ff70d2ec55edfa006730.
Independent batch binding accepts all549 configurations/11529TIME:474common
plus75parallel (all60old routes+15actualpublic), seven modes. First147 group
is LIVE handle15652, fork0 complete147CHECK/1029TIME; final raw audit remains
pending. No Native performance result is inferred from compilation alone.
Earlier execution checkpoint below is historical and retains original source eras.

# Execution ledger (checkpoint 2026-10-16T23:25:47.073705+00:00)

Accepted parent is `c9415d55fe8d9a743266e75709cf95738011d311`. Initial composition
`c41f8d93` was independently source-reviewed. Focused correctness is 19 actual
methods: JVM7 (61339), JS3/Wasm3 (21677), Native6 (26974). The original Native
compile failure21677 and annotation-only7821935 correction remain preserved.
These are prerequisites, not final selected-route/full-suite acceptance.

Initial common calibration is independently accepted on all THREE completed
platforms: JVM474/9954 TIME, JS474/9954 TIME and Wasm474/9954 TIME. Every adverse
row/range, allocation NA and partial-ring checksum limitation remains. JSlarge1
26826 failed its600s deadline (81 CHECK/560 partial TIME); successful complete
large2 49107 is used instead. Wasm49545 selected0 tests/no numerical rows; its
bootstrap fix/registration smoke56556 and successful full small2 45975 are separate.
Initial common results are grid evidence, not final policy or final public guards.

Oracle scope: JVM kernel CHECK uses public JDK; historical JS/Wasm/Native common
`calibration539Verify` is a school-only stub, so common kernel/square CHECKs mean
full forced-school comparison. Worker-host checks use actual public Node BigInt.
Cost/public-small have their own stated witnesses, not universal school/JDK checks.
The staged JS K16 oracle is additive future validation, never a historical relabel.

JVM cold-await correction3fb5716 preserved all original common data. Old60-case
parallel17831 is historical. The coherent11-file public-comparator diagnostic
change is now frozen as `07910edf6d5687f1d89dbe3369c4546f648feed2`,379 SHA in
`public-comparator-source.tsv`; production arithmetic and tiny child modules did
not change. JVMbuild78181 and root JS/Wasmbuild90970 succeeded with immutable
fresh artifacts. JVM75 actual92699/strict53648/independent raw audit PASS:
1575 PAR,90 complete cold SETUP,45 PAYLOAD; actual public serial comparator is
matched in the same fresh F/R/F processes. Resource tradeoffs remain explicit;
prototype eligibility is not public adoption. Do not merge old60 with new15.

Parent-public runtime fixtures32074(JS)/44182(Wasm) each passed exactly one
registration test and two untimed distinct/alias fixtures, with zero worker pools
or timed rows. Root/Mocha and tiny closures are independently bound. JS worker
initial98636 failed600s at86 CHECK/598 TIME; its raw/cleanup/failure stays partial
and excluded. Full fresh worker105 uses reviewed JS1200s/Wasm600s budgets plus
bounded cleanup. First JS fork93365 completed105 CHECK/735 WORKER/105 PUBLICRESULT.
At this recorded checkpoint reverse fork9727 is live; no aggregate three-fork
acceptance is inferred. Remaining JS fork2, Wasm105 x3 and strict/audits are pending.
Reused pool, separate parent registration/startup and teardown outside rows are
explicit; these measurements are not per-invocation create/terminate costs.

Native has NOT executed its common/parallel campaign. First fresh Release build
and seven modes will cover common474 plus parallel75 with actual public comparator
(549 configurations/11529 TIME at3 x7). Do not perform old60 first and repeat it.
Native per-operation Worker start/join/termination differs from Node reused pools.

Pending implementation/decision scope is unchanged: per-platform serial policy;
public parallel adoption/refusal with actual lifecycle/resources/contracts;
actual selected-route fixtures, paired28 BOTH API final guards and full unfiltered
four-target correctness. Staged JVM frontend/failure-fence patch and JS33 K16
extension are SOURCE/preparation only, uncompiled/unrun/unapplied. The extension
has exact physical equal-length nonalias scope, one bounded neighbour campaign,
all adverse retained and no global-optimum claim. Current frozen source is not
changed while campaigns execute. Protocol `eb49f03d…` remains unchanged.

## Historical source preparation (retained verbatim)

# 539 requirement → planned evidence inventory

All entries below are SOURCE/PLAN, UNCOMPILED and UNRUN. No policy or performance
benefit is accepted. Current review base is source checkpoint0c3a20d followed by
source-only infrastructure commitf7b57a9; subsequent inventory-driven refinements
must be reviewed too. Final evidence requires accepted537 + accepted529 + current
main (including597) before fresh build/calibration/adoption.

| Requirement from full local539 | Probe / correctness path | Finite case inventory | Decision / unresolved acceptance |
| --- | --- | --- | --- |
| Tune JVM/JS/Wasm/Native multiplication | Common MultiplicationCampaign539 kernel profiles | Small147, medium189, large81 configurations per target; all12 self-square policies, only4 K policies on nonaliases where square options are unreachable; 16 sizes8..8192, distinct/self/1:2/1:4 | Initial grid, not universal optimum. Three fresh forward/reverse forks and7 samples; retain every adverse row/range. If best choice sits on grid edge or inconsistent margin, bounded adjacent extension before final choice; do not invent optimum. |
| Avoid medium-square penalty | square-control common mode | 6 sizes128/192/256/384/512/1024 ×4 entries0/384/1024/IntMAX =24, fixed K64/leaf16 | Pure-square comparator is explicit. Initial grid baseline only: if selected K/leaf changes, repeat targeted controls with actual final policy before freezing final artifact. No assumption that large recursion should apply to medium squares. |
| Long/unsigned/limb/allocation costs | cost common mode | 5 controls: signedLong256, unsignedLong256, Intcarry256, fresh arrays256/4096words | Includes boxedAny/ring overhead; not isolated instruction latency. Base2^30 remains fixed. No claim that another radix/backend wins. Any proposed radix change needs concrete design and end-to-end evidence. |
| No small-task regression | public-small mode, BOTH public methods | 7 widths1/30/63/64/127/511/1023 × distinct/self × multiply/parallelMultiply =28 | Independent shifted-add expected values and exact REP rows. Matched baseline/final candidate same accepted537/529/main; per-case latency/range/allocation guards. Proposed inherited532 guard: investigate >15% AND >5ns; reviewer must accept metric rule before use. Allocation regressions separately visible, no averaging. Final adopted wrapper must be rebuilt/retested. |
| Real bounded JVM concurrency where beneficial | ParallelCalibration539JvmMain | 5 sizes256/1024/4096/8192/16384 ×3 shapes ×kernel/frame/worker1/worker2 =60 eligible cases;30 distinct fresh-pool setup rows per fork | SAME frame serial vs parallel, plus existing kernel. Approx all-thread allocation/processCPU/poolpeak upperbound and external whole RSS. Startup separate from warmed steady. Actual processor eligibility, no forcedtestprocessor count. Select a conservative size threshold only with benefit margin/ranges + resource tradeoff. |
| Native real execution feasibility/cost | native-parallel common mode + nativeTest scheduler | Same5sizes ×3shapes ×4routes =60 max; worker start/queue/join/termination inside every operation | Invocation-owned Workers, explicit test-only opt-ins, global2-permit nonblocking gate/nested fallback. Actual Worker Outcome identity and termination/permit tests must pass under pinned2.4.21. API warning alone cannot reject performance; missing quota awareness/OS constraints recorded, no assumed globalCPUcontrol. |
| JS/Wasm actual transport + common-kernel candidates | Unpublished multiplication539 module + measure-worker-transport-539.main.kts | Same5sizes ×3shapes ×kernel/frame/empty/copy/worker1/worker2 =90 max per target, with module andpool startup controls | Exact SAME source paths, no librarydependency/copy/backend. Private owned child arrays transferred; originalcaller arrays preserved. Sharedstatus+syncport protocol; actual childcommonkernel and parentcommonrecombine. Wasm per-word copies candidate-specific. Empty/copy are transport controls, not proof that every possible transport is inferior. |
| CPU/latency/peak-memory tradeoffs | Per-target CPU, supportedallocation, logicalpayload, rawpoolcontrol and scoped RSS | All timed rows labelled; JVM freshpool30rows, JS/Wasm1poolresourcecontrol per fork | JVM all-thread allocation approximate; commoncaller allocation excludesworkers. Native coarse lastGCheap, Wasm heapNA. Node per-caseRSS includes idlepool even forserial; raw before/afterpoolRSS records fixedcost, cumulativehighwater includespriorcases/referenceprep. Final memory claims require scoped fresh policy processes if attribution is needed. No division into exact object size. |
| Common independent arithmetic | Same kernel included from original root source paths | Hash full compiled source + artifact tree; JVM publicJDK/Node publicBigInt used ONLY untimedoracles | No foreign numerical implementation source or runtime arithmetic delegation in measured route. No intrinsic/native arithmetic backend. |
| Preserve public contracts | Common/JVM/Native new tests + existing full suites; future frontend fixtures | Existing common3 ownership/carry/ratio tests, JVM4 scheduler schedules, Native3 crossworker/registration-fault tests; all4target full suite after finalcomposition | Current public dispatch untouched. Any adoption adds exact-class frontend preserving virtualmultiply/subtype/null/zero/sign/range behavior and once-per-operation compact materialization; must have branch fixtures and full regression. Prototype transport-error wrapping is NOT accepted public exception behavior. |
| Reproducibility / bounded resources | Three strict checker scripts + capture driver + owninglauncher metadata | JVM60, worker90, portable exactmode inventories; samples0..6 unique percase; source/artifact/runtime/PID/exits bound | Capture/checkers are not source equivalence by themselves. Freshbuild logs/sourcebefore-after, no stalejvmJar, codeorigins and fullSHA, sanitizedenv, perprocess+campaign deadlines, partiallogs and ownedsurvivors. Commands schema in commands.md. |

## Expected initial totals and finite scope

Per ordinary target the common profiles contain417 kernel +24 squarecontrol +5
cost +28 public configurations =474. Native adds up to60 ownedscheduler configs.
These are explicit bounded diagnostic datasets, not complete-domain arithmetic or
all possible CPUs. Three forks ×7 samples is9,954 common sample rows per ordinary
target, and11,214 for Native when both worker counts are eligible. JVM parallel adds
1,260 sample rows; each JS/Wasm worker campaign adds1,890. Counts must be recomputed
by strict scripts; this document's arithmetic is a planning check, not run evidence.

The one-dimensional grid deliberately does not time squareLeaf/wholeEntry variants
on nonalias inputs: the common kernel's alias+offset condition cannot select square
there. K values remain swept for all four shapes. This removes duplicate trees,
not adverse outcomes. A pure-square fixed comparator was added before runtime so
an avoided532-style medium regression cannot disappear inside a recursive grid.

Do not make final threshold claims from a single exploratory fork. A staged
campaign may use preliminary data to prune unchanged duplicate policies, but final
compared choices need repeated reversed-order evidence and final public guards.
No endless hunt for a precise mathematical crossover: use a preregistered practical
margin, stable process ranges and a conservative allocation-aware threshold. If a
boundary extension is necessary, freeze its exact inventory/source before running.

## Source readiness versus genuinely outstanding task work

Prepared: common policy/ownership tests, JVM/Native scheduler candidates, JS/Wasm
private linked module and synchronous host protocol, same-frame comparators,
strict JVM/portable/worker checkers, source/artifact/process binding schema and
Native RELEASE diagnostic binary configuration. All remain UNRUN.

Still required: independent review/fixes of newest source; final accepted-base
composition; actual fresh builds/toolchain/runtime validation; scheduler timeout/
failure/termination tests, actual module/array/callback interoperability; complete
inventories/controls/ranges; source-bound baseline/final candidate comparison;
selected-policy targeted repeats if the initial baseline differs; actual memory
coverage/scope validation; public-route implementation ONLY if benefit warrants;
newfrontend branch fixtures then focused/full4targets and finalsmallguards;
independent aggregate review, integration and evidence-preserving cleanup.

529 remains frozen. Preserve accepted535 compact ingestion observations and597
metadata-cache semantics when eventually composing529. Any cache field is part of
actual object graphs in BOTH matched post597baseline/candidate; do not reuse old
size claims or allocate an unscaledValue wrapper just to inspect compact/cache.

Independent source review: worker527 accepted Native nullable value-class registration guards and JVM freshPID hardening; finalcheap hashfreeze pending. This remains SOURCE PASS only, no compiler/runtime/threshold/adoption acceptance. Oldaf1729f contains originalownershipfinding retained inhistory; guardedfix followsseparately.

## Actual Node targeted retry 94407 — source 9038ab29

JS2 + Wasm2 actual targeted methods PASS (zero failures/errors/skips), BUILD SUCCESSFUL in 1m52s. All401 source hashes match node-factory-fixed-source.tsv after terminal. XML/log ledger: node-frontend-targeted-2/summary.json; independent audit: independent-node-frontend-targeted-2-audit.json. Failed80588 remains archived separately. These methods check products/sign/alias/input/subclass/small semantics; they do not assert backend registry activity. Independent KLIB delivery SHORT/IDLE and actual first/warm resources remain pending. Actual worker compiler closure/generated-source hashes are separately recorded in node-frontend-targeted-2/producer-payload-bindings.json.

## Actual independent KLIB consumer delivery — production0331887

Publication retry74895 and standalone consumer build25702 PASS. Four actual JS/Wasm SHORT/IDLE consumer processes PASS; independent-node-consumer-delivery-1-actual-audit.json SHA7d3af569 records actual public backend two-positive-thread predicate/six accepted jobs, one application initialization and exact owned temp paths absent after natural cleanup. No manual assets or producer source dependency. SHORT has no observer keepalive; IDLE observes natural30s retirement. This is untimed delivery/lifecycle proof, not performance/adoption/full correctness.

Native focused32182 stopped before runtime/Debug-link because new Native test activeWorkers calls lacked ExperimentalStdlibApi; zero methods executed. Failed log/oldfile preserved. Annotation-only successor acce0966 has405 source hashes; production bytes remain0331887. One Release build92528 now active for seven contract witnesses and33-caseK16; old549/11529 remains historical841 era.

## Current selected policy df733c0 — actual verification checkpoint

Historical live statements above describe their source eras. Release92528 completed; seven contracts and Native33/693 bounded neighbor calibration passed independently. The selected Native physical-distinct/equal-length K32 production policy retains K64 for alias/unbalanced inputs, leaf16 and entry384; selected JS remains distinct/equal K32 with entry128. JVM/Wasm retain64/16/384. Decision and uncertainty records are selected-policy-decisions.json, independent-selected-policy-decisions-review.json and independent-native-k16-host-quality-supplement.json. No scalar20/10 gate or global-optimum claim.

Current405-source df733c0 builds42371 and29518 completed; selected Native10 Release contract methods independently PASS (independent-selected-native-contracts-1-actual-audit.json). Unfiltered full78558 completed terminal0: JVM701, JS467, Wasm467, Native473 =2108 tests, no failures/errors/skips. Exact invocation: full-selected-regression-1-invocation.json; archived530 XML files and source/log binding: full-selected-regression-1/summary.json. Independent audit independent-full-selected-regression-1-audit.json PASS. This does not imply performance/adoption acceptance.

Actual public FIRST/warm campaigns and paired28 BOTH-API final guards remain pending until their own execution/audits. Current JVM FIRST/warm85167 is active on immutable df733 artifacts. Its host-before snapshot records unrelated icu4k Gradle daemon CPU237.9%; no continuous-quiet/host-isolation claim. All historical initial grids, partial failures, prototypes and source eras remain retained. Reviewed doc/KDoc patch stays external through these source-bound campaigns.

## Common thin public entry successor2d74b64

Historical JSactual40621 failed after12 successful point processes and a thirteenth numerical/Mocha PASS: postrun host worker-state witness rejected16384/distinct. Partial13FIRST/434warm are NOT accepted full performance evidence. Failure raw/controller/oldhost/checker hashes are preserved under actual-public-node-js-1-failure; no timeout and no numerical-failure assertion. FinalNode campaign awaits reviewed witness correction and newroot bindings.

Reviewed92311 common entry split is committed2d74b6467c449084d6c528cc26398c2ac93b0a3b,405-source thin-public-source.tsv. JVM build39006 PASS, actual compiled public wrapper26B (old137B), immutable main7a1c987e/probe827entries826classes. ActualJIT/inlining causal recovery is not established. Freshpairedguard5606 terminal0 strict1176TIME/168REP/168CHECK andZERO15%AND5nsflags; independent-actual-public-jvm-paired-small-2-raw-audit.json PASS3cbd41ae. Original guard1fourflags remain historical; no universality/continuous-host-isolation claim. Currentunfiltered affectedfourtarget full94133 is active; freshJS/Wasm/Native productionroot builds and finalactualpublic FIRST/warm remain pending. No417/75/105 numerical-grid replay solely for this common publicentry change.
