# JS balanced adjacent threshold preparation

PREPARATION ONLY — no source edits, build or execution.

The proposed extension is 33 cases / 693 TIME rows: 11 word sizes (16, 31, 32, 63, 64, 128, 256, 512, 1024, 4096, 8192), distinct balanced inputs and K16/K32/currentK64 with leaf16/entry384. Exact IDs, original common input generator, counters, process order and finite budgets are in the adjacent JSON.

The literal requirement asks for a bounded adjacent extension before final choice and forbids an endless optimum hunt; it does not prescribe recursive halving until a mathematical optimum. Stop after this frozen extension. If K16 is still the tested edge winner, report that boundary explicitly and decide from causal activity, all adverse/ranges, resources and actual public guards. Do not call it a global optimum, automatically add K8, or retain64 merely to avoid the comparison. Any unresolved decision needs a separate finite inventory, reviewed before execution.

This slice is sufficient only for a proposed balanced dispatch on physical magnitude arrays with equal lengths and `a !== b`. BigInteger object inequality alone is insufficient; opposite-sign/negate views may share wide storage. Selected-route fixtures must preserve alias and ratio2/4 K64 paths. A global threshold proposal must include ratio2/4 and alias/recursive square controls. Existing acceptance line47, actual selected-policy fixtures, paired28 BOTH API guards and final four-target correctness remain pending; the current frozen worker/Native campaigns run first.

Source clarification: historical root JS `calibration539Verify` has an empty external-oracle stub; its full checks use the forced-school result. The new staged diagnostic patch will add untimed public BigInt verification for the extension. Worker-host BigInt checks already execute. Historical common results are not relabelled as externally verified.
