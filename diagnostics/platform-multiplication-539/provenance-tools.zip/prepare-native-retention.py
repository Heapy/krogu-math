from pathlib import Path
import hashlib,json,difflib
p=Path(__file__).resolve().parent;w=p/'worktree';out=p/'packaging/native-serial-retention';overlay=out/'overlay';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();entries=[];patch=[]
paths=['src/nativeMain/kotlin/io/heapy/krogu/math/MultiplicationPlatform539.kt','src/nativeTest/kotlin/io/heapy/krogu/math/NativePublicFrontend539Test.kt','src/nativeTest/kotlin/io/heapy/krogu/math/NativePublicFrontendCalibration539.kt']
for rel in paths:
 f=w/rel;before=f.read_text();after=before
 if rel.endswith('MultiplicationPlatform539.kt'):
  needle='retainSerialParallelMultiply539: Boolean = false';assert after.count(needle)==1;after=after.replace(needle,'retainSerialParallelMultiply539: Boolean = true')
 elif rel.endswith('NativePublicFrontend539Test.kt'):
  after=after.replace('publicBoundariesSignsAliasAndWorkersTerminateBeforeReturn','publicSerialDeclinePreservesBoundariesSignsAliasAndWorkerAbsence')
  after=after.replace('        Worker.current\n','        Worker.current\n        assertTrue(retainSerialParallelMultiply539)\n',1)
  after=after.replace('        assertFalse(canParallelMultiply539(4095, 4096));','        // Retained candidate capability is independent from the current public serial decline.\n        assertFalse(canParallelMultiply539(4095, 4096));')
 else:
  after='@file:OptIn(kotlin.native.concurrent.ObsoleteWorkersApi::class, kotlin.ExperimentalStdlibApi::class)\n'+after
  after=after.replace('import kotlin.test.Test','import kotlin.native.concurrent.Worker\nimport kotlin.test.Test')
  after=after.replace('/** Actual Native public route: EVERY operation includes Worker start, join,\n * termination and permit release. Never a persistent-pool warm claim. */','/** Current Native public serial-retention route. The candidate engine and its\n * complete per-call Worker lifecycle measurements remain historical, not these rows. */')
  after=after.replace('native-public-frontend','native-public-serial-retention')
  needle='        val cpuBefore = calibration539CpuNs()'
  assert after.count(needle)==1
  extra='''        check(retainSerialParallelMultiply539) { "Current Native public route must decline before backend helpers" }
        Worker.current
        val baselineWorkers = Worker.activeWorkers.map { it.id }.sorted()
        fun verifySerialAbsence(phase: String, sample: Int) {
            val currentWorkers = Worker.activeWorkers.map { it.id }.sorted()
            check(currentWorkers == baselineWorkers) { "Current serial route changed Native Worker ownership" }
            println("NATIVESERIALDECLINE539,$size/$shape,$phase,$sample,${baselineWorkers.joinToString(";")},${currentWorkers.joinToString(";")},true")
        }
        println("INPUTNATIVE539,$size/$shape,${aWords.size},${bWords.size},${aWords === bWords}")
'''
  after=after.replace(needle,extra+needle)
  after=after.replace('        println("# first public/backend activation after untimed school/oracle/BI preparation; EVERY parallel row includes full Worker lifecycle; not pool reuse or pristine JIT")','        verifySerialAbsence("first", -1)\n        println("# first PUBLIC call after untimed school/oracle/BI preparation; current route directly declines to virtual serial multiply; no backend startup or fresh-speedup claim")')
  after=after.replace('        // Actual parallel children remain explicit64/16; current balanced distinct serial is32.','        // Current public parallel route is virtual serial; retained candidate children remain64/16 outside this fixture.')
  marker='                println("PUBLICNATIVE539,$size/$shape/$variant,$sample,$count,$elapsed,${if (before != null && after != null) after - before else "NA"},NA,${heap ?: "NA"},${if (escaped is IntArray) (escaped as IntArray).contentHashCode() else escaped!!.hashCode()}")'
  assert after.count(marker)==1;after=after.replace(marker,marker+'\n                if (variant == "parallel") verifySerialAbsence("parallel", sample)')
  after=after.replace('        println("PASS_PUBLICNATIVE539,$size/$shape")','        check(Worker.activeWorkers.map { it.id }.sorted() == baselineWorkers)\n        println("NATIVESERIALRESOURCE539,$size/$shape,NONE_STARTED,${baselineWorkers.joinToString(";")},true")\n        println("PASS_PUBLICNATIVE539,$size/$shape")')
 assert after!=before
 dest=overlay/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(after)
 entries.append({'path':rel,'before_sha256':sha(f),'after_sha256':sha(dest)})
 diff=list(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 patch.append('diff --git a/'+rel+' b/'+rel+'\n'+''.join(x if x.endswith('\n') else x+'\n\\ No newline at end of file\n' for x in diff))
(out/'native-serial-retention.patch').write_text(''.join(patch))
(out/'source-manifest.json').write_text(json.dumps({'base':'aa9ca6b9cab6d177ba62b188aa72a0f0fad1e2fa','files':entries,'scope':'NativeMain one constant only; NativeTest honest current decline/absence/input witnesses outside counters. No common/JVM/JS/Wasm source change, no engine/scalar/forced/kernel/policy/counter-loop change.'},indent=2)+'\n')
print(json.dumps(entries,indent=2))
