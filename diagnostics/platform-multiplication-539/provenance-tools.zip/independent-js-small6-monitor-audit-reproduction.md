# JS small6 actual monitor audit reproduction

Run from repository root. This recomputes recorded scalar process-counter ancestry/deltas/admission from raw TSVs only; it does not inspect foreign process contents or run numerical code.

```sh
python3 - <<'PY'
from pathlib import Path
import csv,json,hashlib,math
r=Path('.codex-work/539');d=r/'actual-public-node-js-paired-small-6';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();props=lambda p:dict(l.split('=',1) for l in p.read_text().splitlines() if '=' in l)
samples=list(csv.DictReader((d/'cpu-samples.tsv').open(),delimiter='\t'));processes=list(csv.DictReader((d/'cpu-processes.tsv').open(),delimiter='\t'));events=list(csv.DictReader((d/'cpu-events.tsv').open(),delimiter='\t'))
assert len(samples)==17 and [int(x['sample']) for x in samples]==list(range(17));assert [e['event'] for e in events]==['OBSERVER_START','CHILD_START','CHILD_TERMINAL','ADMISSION_START','INDETERMINATE_NO_NUMERIC_RUN','OBSERVATION_END_REQUEST']
ownpid=int(events[0]['detail'].split('controller_pid=')[1].split(';')[0]);ownstart=events[0]['detail'].split('controller_start_utc_seconds=')[1];prev={};prevowned=set();prevend=0;churn=[];owned=[]
for i,s in enumerate(samples):
 rows=[x for x in processes if int(x['sample'])==i];cur={(int(x['pid']),x['start_utc_seconds']):x for x in rows};assert len(cur)==len(rows)==int(s['process_count'])
 ctl=next(x for x in rows if int(x['pid'])==ownpid);assert ctl['start_utc_seconds']==ownstart
 own={ownpid}
 while True:
  old=len(own);own.update(int(x['pid']) for x in rows if int(x['ppid']) in own)
  if len(own)==old:break
 currentowned={k for k in cur if k[0] in own};assert {k for k,x in cur.items() if x['owned_ancestry']=='true'}==currentowned
 ext=cpuown=matched=fresh=externalunmatched=reset=0
 for k,x in cur.items():
  old=prev.get(k);cpu=int(x['cpu_total_ns']);assert cpu>=0
  if old is not None and cpu>=int(old['cpu_total_ns']):
   delta=cpu-int(old['cpu_total_ns']);matched+=1
   if k in currentowned:cpuown+=delta
   else:ext+=delta
  else:
   fresh+=1
   if old is not None and cpu<int(old['cpu_total_ns']):reset+=1
   if k not in currentowned:externalunmatched+=1
 ended=set(prev)-set(cur);externalunmatched+=len(ended-prevowned);interval=int(s['mono_end_ns'])-prevend if prevend else 0
 complete=bool(prevend) and externalunmatched==0 and reset==0
 for key,value in [('matched_count',matched),('new_or_reset_count',fresh),('ended_count',len(ended)),('external_unmatched_count',externalunmatched),('reset_count',reset),('observed_external_cpu_ns',ext),('observed_owned_cpu_ns',cpuown),('interval_start_ns',prevend),('interval_ns',interval)]:assert int(s[key])==value,(i,key)
 assert s['counter_complete']==str(complete).lower()
 if interval:assert math.isclose(float(s['observed_external_cores']),ext/interval,rel_tol=1e-15) and interval<=5_000_000_000
 else:assert s['observed_external_cores']=='NA'
 assert 0<=float(s['host_cpu_fraction'])<=1
 if i:
  newext=[{'pid':k[0],'ppid':int(x['ppid']),'start':k[1]} for k,x in cur.items() if k not in prev and k not in currentowned]
  endedext=[{'pid':k[0],'ppid':int(prev[k]['ppid']),'start':k[1]} for k in ended-prevowned]
  churn.append(dict(sample=i,new_external=newext,ended_external=endedext))
 owned.append(dict(sample=i,pids=sorted(own)))
 prev=cur;prevowned=currentowned;prevend=int(s['mono_end_ns'])
start=int(events[3]['mono_ns']);admit=int(events[4]['mono_ns']);endrequest=int(events[5]['mono_ns']);eligible=[s for s in samples if int(s['interval_start_ns'])>=start and int(s['mono_end_ns'])<admit];assert [int(s['sample']) for s in eligible]==list(range(1,16))
coverage=int(eligible[-1]['mono_end_ns'])-int(eligible[0]['interval_start_ns']);assert coverage>=15_000_000_000 and admit-start<=20_000_000_000 and int(samples[-1]['mono_end_ns'])>=endrequest
incomplete=[int(s['sample']) for s in eligible if s['counter_complete']!='true'];assert incomplete
assert all(float(s['observed_external_cores'])>0.5 for s in eligible)
assert (d/'NO_NUMERIC_RUN').is_file() and not list(d.glob('fork*.log')) and not (d/'EXECUTED_NOT_YET_GUARD_VALIDATED').exists() and not (d/'DIAGNOSTIC_FAILED').exists()
assert not any('PAIR_' in e['event'] or e['event']=='NODE_IDENTITY' for e in events);assert (d/'runtime.log').read_text()=='v24.16.0\n'
binding=props(d/'binding-before.txt');ob=props(d/'observer-binding.txt');manifest=r/'packaging/js-guard-load-diagnostic/manifest.json';assert sha(manifest)=='500332e4039ebf845099072cb0d93b90ebbfb188d6b6933017c89a4375f5c597'
for e in json.loads(manifest.read_text())['entries']:assert sha(r/e['path'])==e['sha256']
assert ob['observer_sha256']=='738eb482353e73c40da70664850e0df9ecc0eb14187f387087704902fdba53e2' and binding['launcher_sha256']=='23c7ec19bc413507ecb9a76101f3e7a86adeb12929006870691ea4e63a1ee5b1' and binding['source_manifest_sha256']=='d9b87a77f258deeb173c2aee4b506ef93e9ce6faaf63c32779d755c31e3626ef'
attempt=json.loads((r/'actual-public-node-js-paired-small-6-attempt.json').read_text());future=json.loads((r/'packaging/js-guard-load-diagnostic/future-command.json').read_text());assert attempt['argv']==future['argv'] and attempt['cwd']==future['cwd'] and attempt['handle']==99668
out={'status':'PASS_ACTUAL_MONITOR_ADMISSION_INDETERMINATE_NO_NUMERIC_RUN_JS_PERFORMANCE_UNRESOLVED','handle':99668,'source':attempt['source'],'numeric_children':0,'samples':17,'admission_samples':[1,15],'closing_sample':16,'admission_coverage_seconds':coverage/1e9,'admission_decision_seconds':(admit-start)/1e9,'incomplete_counter_intervals':incomplete,'external_CPU_observed_core_range':[min(float(s['observed_external_cores']) for s in eligible),max(float(s['observed_external_cores']) for s in eligible)],'system_CPU_fraction_range':[min(float(s['host_cpu_fraction']) for s in eligible),max(float(s['host_cpu_fraction']) for s in eligible)],'reset_count':sum(int(s['reset_count']) for s in eligible),'external_churn':churn,'owned_PIDs_per_sample':owned,'monitor_cause':'Observed external new/ended PID+start identities under parents26317/93537 and PPID1 cause incomplete intervals; own controller29292, own version probe29322 and each ps child are correctly ancestry-excluded. Parent26317/93537 neither descendant nor ancestor of controller in retained rows. Some intervals are complete, so own sampler churn does not make admission constructively impossible. Even complete intervals exceed external0.5core operational bound; no claim of quiet host. No process names/commands inferred.','disposition':'Correct bounded non-admission, not a numerical pass/failure or performance clearance. One authorized attempt consumed; no automatic retry or admission relaxation. Six prior91477flags remain unresolved, no causal conclusion about that earlier campaign. Source/correctness/serialdecline and plannedNative work remain separate; no further source fix or runtime recommended from this audit.','raw_sha256':{p.name:sha(p) for p in sorted(d.iterdir()) if p.is_file()},'scope_limits':'Matched process CPU only; short-lived unseen/reparented process/start resolution and cpuLoad period limitations retained. This17second timeline proves no cause of earlier91477slowdowns. No numerical strict helper invoked.'};p=r/'independent-js-small6-monitor-admission-actual-audit.json';p.write_text(json.dumps(out,indent=2)+'\n');print('PASS',sha(p));print('coverage',coverage/1e9,'decision',(admit-start)/1e9,'incomplete',incomplete,'external',out['external_CPU_observed_core_range'],'host',out['system_CPU_fraction_range'])
PY
```
