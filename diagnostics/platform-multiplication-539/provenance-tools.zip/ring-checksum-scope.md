# Common calibration escaped-ring checksum scope

Source `7821935`, MultiplicationCampaign539 retains a bounded64-slot ring.
Each timed batch overwrites slots `0 until min(count,64)`; if count<64,
remaining slots may contain prior warmup/case values. A200ms warmup does not
prove64 operations for an arbitrarily expensive case. Therefore a digest of
that partial ring is not an isolated current-result proof.

Independent raw audit requires each case's seven recorded samples to be
consistent; cross-fork / same-operand policy and frame digest equality is an
additional witness only where batch count>=64 establishes complete timed-batch
coverage. Count<64 is labelled partial-ring coverage, with prior-slot influence
retained, rather than inventing an exact product digest. All original rows remain.

Arithmetic correctness continues to require every existing untimed full-result
school-product CHECK and public-JDK oracle on JVM. No checker assertion, source,
warmup, timing, sample count or live campaign was changed by this interpretation.
Digest computation is outside wall/CPU/allocation observation brackets; whole
process RSS and elapsed lifetime can include digest/reference preparation costs.
This is a measurement boundary, not a numerical failure or adoption decision.
