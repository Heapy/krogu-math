# Preliminary complete Native417 serial grid — not adoption

All417 configs/8757TIME independently audited. JSON retains everyforkratio/activitylabel. NoJS/Wasmtransfer and no serial20/10gate.

|Candidate / shape|All3lower measuredsizes|All3higher measuredsizes|
|---|---|---|
|k32-s16-e384 / distinct|16,63,96,192,256,383,512,1024,8192||
|k128-s16-e384 / distinct|16|63,64,96,128,192,256,383,512,4096,8192|
|k256-s16-e384 / distinct|8|63,64,96,128,192,256,383,384,512,1024,4096,8192|
|k32-s16-e384 / ratio2|16,63,96,128,192,384,4096|32|
|k32-s16-e384 / ratio4|32,63,96,128,192,383,384,8192|8,31,512|
|k64-s16-e128 / square|383,512|32,1024|
|k64-s8-e384 / square|8,64|32,192|

These counts include inactive/noise controls; they are not causal evidence without activity.

K32 physicaldistinct balanced is a credible Native candidate: activeall3lower63/96/192/256/383/512/1024/8192, mixed32/64/128/384/4096. NotJSautomatictransfer; actualNativepairs retained.

IfselectedK32 is pursued, it is currentKgridloweredge; existingbounded-adjacent requirement calls for finiteK16neighbor onthat selectedphysicaldistinctbalancedfamily beforechoice. NoautomaticK8 or unboundedoptimumhunt; freezefiniteinventory beforemeasurement.

Do notgeneralize K32 to ratio2/ratio4:32ratio2all3adverse,512ratio4all3adverse andlargerunbalancedmixed. Selectedshape-specificrule wouldneedactualdispatchbinding.

RaisingK128/256 hasbroadactiveadverseonbalancedmedium/large; apparenttinywinsbelowbothK areidenticalschoolcontrols.

Entry128 only383activeall3lower;128/192/256mixed. Its512all3lower and1024all3higher areidenticaldefaultrecursion,notcausalentryeffects. Awaitexistingseparatesquare24;notimportJSentry128.

Leaf4/8 atsize8 materiallyselectsquareinsteaddefaultschoolandbothall3lower; possiblevery-small-squarecandidate,notbroadrecursiveleafproof. Most16..383leaflabelsforceidenticalwhole-square;anyselected8boundarychange needsapplicablesmall/shapecontrols ratherthaninferencefromlargersizes.

Resource and ring limits: AllocationNA/coarseGCheapsnotperoppeak;69largeconfigs sub64ring,completeforcedschoolCHECKsseparate.

Example actualNative K32distinct ratios:63=.827/.748/.776;96=.846/.923/.949;192=.868/.863/.878;1024=.649/.374/.926;4096=1.069/.959/.584(mixed);8192=.930/.959/.969. Preserveallforks; neitherpoolingnorselectedlowerforkconstitutesuniversalwin.

## Separate square24 controls now actual PASS

Active recursion versus default whole-square:128=1.078/.967/.976 mixed;192=.920/.892/.884 and256=.676/.769/.751 all3lower. This supplies Native-specific support for consideringentry128, independentlyofJS, while the128adversepairandoriginalgridmixedpointsremain. Identicalwhole-square192(e1024)=.910/.990/.991 and256(eMAX)=.813/.977/.954 alsoall3lower,showingvariationmustnotbeignored. Whole-square384/512/1024all3adverse; e0/1024all3lower(.999/.854/.997)issamearithmeticdefaultandnotcausalentrygain. Source389/currentartifact,24/504rows/3freshidentities/allstatsPASS;allocNA/coarselastGCheapnotpeak. No automaticadoption;cost/public/finalselectedguardsstillpending.
