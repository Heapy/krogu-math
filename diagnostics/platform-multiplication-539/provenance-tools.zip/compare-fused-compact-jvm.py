from pathlib import Path
import zipfile,subprocess,re,json,hashlib
p=Path(__file__).resolve().parent;out=p/'fused-compact-jvm-semantic-comparison';out.mkdir();old=p/'artifacts/jvm-actual-public-2d74b64/main.jar';new=p/'worktree/build/libs/krogu-math-jvm-0.1.0-SNAPSHOT.jar';javap='/Users/yoda/.sdkman/candidates/java/25.0.4-librca/bin/javap'
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
a=zipfile.ZipFile(old);b=zipfile.ZipFile(new);assert set(a.namelist())==set(b.namelist());changed=[n for n in a.namelist() if a.read(n)!=b.read(n)]
def dump(jar,cls):return subprocess.check_output([javap,'-c','-p','-classpath',str(jar),cls],text=True)
def methods(txt):
 starts=list(re.finditer(r'^  (?:public|private|protected|static).*\);?\s*$',txt,re.M));result={}
 for i,m in enumerate(starts):
  name=m.group().strip();part=txt[m.end():starts[i+1].start() if i+1<len(starts) else len(txt)]
  part=re.sub(r'#\d+','#CP',part);result[name]=part
 return result
reports=[]
for n in changed:
 assert n.endswith('.class'),n
 cls=n[:-6].replace('/','.');x=dump(old,cls);y=dump(new,cls)
 (out/(cls.rsplit('.',1)[-1]+'.old.javap.txt')).write_text(x);(out/(cls.rsplit('.',1)[-1]+'.current.javap.txt')).write_text(y)
 mx,my=methods(x),methods(y); added=set(my)-set(mx); assert not set(mx)-set(my); delta=[k for k in mx if mx[k]!=my[k]]
 if cls.endswith('BigInteger'):
  assert len(delta)==2 and any('parallelMagnitudeSize539' in k for k in delta) and any(' parallelMultiply(' in k for k in delta),delta
  assert not added
  getter=next(k for k in delta if 'parallelMagnitudeSize539' in k)
  assert 'new ' not in my[getter] and 'arraylength' in my[getter] and 'iconst_0' in my[getter]
  public=[k for k in my if ' parallelMultiply(' in k][0]
  assert '32: areturn' in my[public] and 'ifnull        21' in my[public] and '7: getfield' in my[public]
  reports.append({'class':cls,'changed_methods':delta,'all_other_method_listings_equal':True,'public_wrapper_Code_bytes':33,'public_prefix_change':'Direct wideWords-null check skips both private helpers for compact receiver; same virtualfallback. Nonnull path adds a single field/null test then unchanged old predicate/coldhelper. Oldsmallguard remains historical, currentguard required.','helper':'Single wideWords read; null -> primitive0; nonnull -> primitive arraylength; no allocation or backend/math call. Equivalent old helper also primitive on JVM, changed branch/register shape disclosed.'})
 elif cls.endswith('MagnitudeMultiplication'):
  assert len(added)==1 and 'multiplyAdaptiveJs539' in next(iter(added)),added
  assert all('multiplyAdaptiveJs539' not in part for key,part in my.items() if key not in added), 'JS private function must have no invocation from JVM existingmethods'
  assert len(delta)==1 and ' multiplyAdaptive(' in delta[0],delta
  def canon(s):return '\n'.join(re.sub(r'^\s*\d+:\s*','',l) for l in s.splitlines() if not re.match(r'^\s*\d+:\s*nop\s*$',l))
  assert canon(mx[delta[0]])==canon(my[delta[0]])
  reports.append({'class':cls,'all_other_methods_instruction_listings_equal':True,'added_private_JS_helper':'Unreachable from every other compiled JVM method; JS flag folded false. Helper is not covered by an oldmethods byteidentity claim.','multiplyAdaptive_only_delta':'One NOP from JSfalse branch; same method operands/checks/default384 invoke/return. No arithmetic/branch/invoke delta.'})
 else:
  assert not delta and not added,(cls,delta,added)
  reports.append({'class':cls,'all_method_instruction_listings_equal':True,'class_byte_difference':'Constant pool/debug/compiler metadata; normalized javap retained instructions/offsets/operands except CP ordinals.'})
s={'source':'a2070e1e1e7a5c455f25319cd623618714fad921','actual_producer':str(new),'producer_invocation_handle':28184,'producer_log_sha256':h(p/'fused-compact-focused-1.log'),'historical_runtime_source':'2d74b6467c449084d6c528cc26398c2ac93b0a3b','old_main_sha256':h(old),'current_main_sha256':h(new),'entries':len(a.namelist()),'exact_entry_names':True,'byte_equal_entries':len(a.namelist())-len(changed),'changed_classes':reports,'scope':'Bounded eligible-route carryforward proposal: on all historicallyeligible wide operands, new nulltest proceeds to unchanged predicate/privatecoldbody/pool/arithmetic; no new allocation/call there. Actual fresh9 JVMtests include4095/4096/4097 alias/sign/ratio and virtualfallback witnesses. Historical45FIRST1260warm numbers remain2d74, not observations of new33Bentry; extra fieldtest latency unmeasured. Current small28 refresh required. No byteidentity/JIT/recovery claim.'};(out/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
