import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile

val root = File("/Users/yoda/dev/pet/krogu-math/.codex-work/539")
val output = File(root, "final-retention-jvm-semantic-comparison")
check(!output.exists() && output.mkdirs())
val old = File(root, "artifacts/jvm-serial-retention-aa9ca6b/main.jar")
val producer = File(root, "worktree/build/libs/krogu-math-jvm-0.1.0-SNAPSHOT.jar")
check("BUILD SUCCESSFUL" in File(root, "final-retention-full-regression-1.log").readText())
val current = File(output, "main.jar")
producer.copyTo(current)
fun sha(file: File): String = file.inputStream().use { input ->
    val digest = MessageDigest.getInstance("SHA-256")
    val buffer = ByteArray(1024 * 1024)
    while (true) { val count = input.read(buffer); if (count < 0) break; digest.update(buffer, 0, count) }
    digest.digest().joinToString("") { "%02x".format(it) }
}
fun json(value: String): String = "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""
fun dump(jar: File, name: String): String {
    val process = ProcessBuilder("/Users/yoda/.sdkman/candidates/java/25.0.4-librca/bin/javap", "-c", "-p", "-classpath", jar.path, name).redirectErrorStream(true).start()
    val text = process.inputStream.bufferedReader().use { it.readText() }
    check(process.waitFor() == 0)
    return text
}
fun methods(text: String): Map<String, String> {
    val starts = Regex("(?m)^  (?:public|private|protected|static).*\\);?\\s*$").findAll(text).toList()
    return starts.mapIndexed { index, match ->
        match.value.trim() to text.substring(match.range.last + 1, starts.getOrNull(index + 1)?.range?.first ?: text.length).replace(Regex("#\\d+"), "#CP")
    }.toMap()
}
val changed = mutableListOf<String>()
var entries = 0
ZipFile(old).use { before ->
    ZipFile(current).use { after ->
        val names = before.entries().asSequence().map { it.name }.toSet()
        check(names == after.entries().asSequence().map { it.name }.toSet())
        entries = names.size
        for (name in names.sorted()) {
            val a = before.getInputStream(before.getEntry(name)).use { it.readBytes() }
            val b = after.getInputStream(after.getEntry(name)).use { it.readBytes() }
            if (a.contentEquals(b)) continue
            changed += name
            if (!name.endsWith(".class")) { check(name.startsWith("META-INF/")); continue }
            val cls = name.removeSuffix(".class").replace('/', '.')
            val oldDump = dump(old, cls)
            val currentDump = dump(current, cls)
            File(output, cls.substringAfterLast('.') + ".aa9.javap.txt").writeText(oldDump)
            File(output, cls.substringAfterLast('.') + ".final.javap.txt").writeText(currentDump)
            check(methods(oldDump) == methods(currentDump)) { "Changed executable listing: " + cls }
        }
    }
}
val entry = methods(dump(current, "io.heapy.krogu.math.BigInteger")).entries.single { " parallelMultiply(" in it.key }.value
check("33: areturn" in entry)
check(sha(producer) == sha(current))
val summary = """
{
  "source": "3f0e1fb8f763b6518395535e222c18407112c9aa",
  "producer_handle": 3267,
  "old_source": "aa9ca6b9cab6d177ba62b188aa72a0f0fad1e2fa",
  "old_jar_sha256": OLD_SHA,
  "current_jar_sha256": NEW_SHA,
  "producer_equals_copy": true,
  "entries": ENTRY_COUNT,
  "byte_equal_entries": EQUAL_COUNT,
  "changed_entries": CHANGED,
  "public_entry_bytes": 34,
  "all_changed_class_method_instruction_listings_equal": true,
  "scope": "Native-only policy and reviewed comments/KDoc preserve JVM instructions. Historical aa9/a207 small guard and2d74 large data retain their original measured eras; no new margin/JIT/whole-JAR identity claim."
}
""".trimIndent().replace("OLD_SHA", json(sha(old))).replace("NEW_SHA", json(sha(current)))
    .replace("ENTRY_COUNT", entries.toString()).replace("EQUAL_COUNT", (entries - changed.size).toString())
    .replace("CHANGED", changed.joinToString(",", "[", "]") { json(it) })
File(output, "summary.json").writeText(summary + "\n")
println(summary)
