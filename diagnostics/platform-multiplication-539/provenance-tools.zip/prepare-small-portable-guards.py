from pathlib import Path
import hashlib,json,copy
p=Path(__file__).resolve().parent;h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
a=json.loads((p/'js-wasm-small-artifacts.json').read_text());old=json.loads((p/'thin-public-remaining-six-prelaunch.json').read_text());source=p/'js-wasm-small-source.tsv';groups=[]
for g in old['groups']:
 if not g['name'].startswith('portable-paired-'):continue
 g=copy.deepcopy(g);kind=g['platform'];target={'JS':'js','Wasm':'wasmJs'}[kind];root=a['roots'][target];av=g['argv'];av[4]=root['tree'];av[5]=root['manifest_sha256'];av[6]=str(source);av[7]=h(source);av[-1]=str(p/f'actual-public-node-{kind.lower()}-paired-small-3');assert not Path(av[-1]).exists()
 ck=g['post_checker_argv'];ck[2]=av[-1];ck[4]=h(source);ck[6]=root['manifest_sha256'];ck[-1]=av[-1]+'-summary'
 assert h(Path(av[1]))==g['launcher_sha256'];assert h(Path(ck[1]))==g['post_checker_sha256'];assert h(Path(av[8]))==av[9]
 groups.append(g)
s={'source':a['source'],'source_files':405,'source_manifest':str(source),'source_manifest_sha256':h(source),'build_summary':str(p/'js-wasm-small-artifacts.json'),'build_summary_sha256':h(p/'js-wasm-small-artifacts.json'),'focused_summary':str(p/'js-wasm-small-focused-1-results/summary.json'),'focused_summary_sha256':h(p/'js-wasm-small-focused-1-results/summary.json'),'compiled_JVM':str(p/'js-wasm-small-jvm-semantic-comparison/summary.json'),'payload_bindings':str(p/'js-wasm-small-payload-bindings.json'),'groups':groups,'finite_diagnostic_scope':{'JS':'Reviewed tiny<32 historical path; full28 retains all10 oldflags. No recovery claim before actual paired data.','Wasm':'Primitive helper removes compiled boxing if proof confirms. Watch unchanged ordinary1square/511square and changed parallel511distinct; all28 and prior6flags retained. No claim helper fixes ordinary controls.'}}
out=p/'js-wasm-small-portable-guards-prelaunch.json';assert not out.exists();out.write_text(json.dumps(s,indent=2)+'\n');print(out)
