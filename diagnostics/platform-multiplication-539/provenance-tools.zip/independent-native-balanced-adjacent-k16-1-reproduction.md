# Independent Native K16 raw audit reproduction

Read-only raw/statistical analysis; no numerical benchmark execution.

```bash
python3 - <<'PY'
from pathlib import Path
import json,csv,re,hashlib,statistics as st,math
r=Path('.codex-work/539');stem='calibration-native-balanced-adjacent-k16-1';d=r/stem;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((r/(stem+'-summary.json')).read_text());pre=json.loads((r/'native-public-contract-k16-retry2-prelaunch.json').read_text())['groups'][1];a=pre['argv'];sizes=[16,31,32,63,64,128,256,512,1024,4096,8192];ids=[f'kernel/{n}/distinct/k{k}-s16-e384' for n in sizes for k in [16,32,64]]
assert s['exit_code']==s['checker_exit_code']==0 and sha(r/(stem+'.csv'))==s['csv_sha256']
groups={};identities=[];envelopes=[];hashes={}
for fork in range(3):
 p=d/f'fork{fork}.log';text=p.read_text();lines=text.splitlines();assert sha(p)==s['raw'][fork]['sha256'];assert Path(str(p)+'.exit').read_text()=='0\n'
 b=dict(x.split('=',1) for x in Path(str(p)+'.binding').read_text().splitlines());assert b['source_manifest_sha256']==a[5] and b['artifact_manifest_sha256']==a[3] and b['runtime_id']==a[9]
 m=re.fullmatch(r'pid=(\d+) start_epoch_ms=(\d+) executable=(.+)\n',Path(str(p)+'.native-identity.txt').read_text());assert m and int(m[1])>0 and int(m[2])>0 and m[3]==a[6] and b['pid']==m[1] and b['start_epoch_ms']==m[2];identities.append((m[1],m[2]))
 assert Path(str(p)+'.argv.txt').read_text().splitlines()==['/usr/bin/time','-l',a[6],'--ktest_filter=io.heapy.krogu.math.MultiplicationCalibration539.optionalCampaign']
 order='reverse' if fork==1 else 'forward'
 assert f'# calibration539 platform=Native MACOSX ARM64 processors=14 mode=native-balanced-adjacent-k16 order={order} cases=33' in lines
 checks=[x.split(',') for x in lines if x.startswith('CHECK539,')];assert all(x[2]=='PASS' for x in checks) and [x[1] for x in checks]==(ids[::-1] if fork==1 else ids)
 assert lines.count('PASS539,33,7')==1 and lines.count('[  PASSED  ] 1 tests.')==1 and not any(x.startswith('REP539,') for x in lines)
 rows=list(csv.reader(x for x in lines if x.startswith('TIME539,')));assert len(rows)==231;g={}
 for x in rows:
  assert len(x)==9;_,name,sample,count,wall,cpu,alloc,heap,h=x;sample,count,wall,h=map(int,[sample,count,wall,h]);assert name in ids and sample in range(7) and 1<=count<=8388608 and count&(count-1)==0 and wall>0 and alloc=='NA'
  cpu=None if cpu=='NA' else int(cpu);heap=None if heap=='NA' else int(heap);assert cpu is None or cpu>=0;assert heap is None or heap>=0
  g.setdefault(name,[]).append(dict(sample=sample,count=count,wall=wall,cpu=cpu,heap=heap,h=h))
 assert list(g)==(ids[::-1] if fork==1 else ids)
 for name,v in g.items():
  assert [x['sample'] for x in v]==list(range(7)) and len({x['count'] for x in v})==len({x['h'] for x in v})==1
  hashes.setdefault(name,set()).add(v[0]['h'])
 groups[fork]=g
 rss=int(re.search(r'^\s*(\d+)\s+maximum resident set size$',text,re.M)[1]);envelopes.append(dict(fork=fork,rss_bytes=rss))
assert len(set(identities))==3
result=[]
for name in sorted(ids):
 gs=[groups[f][name] for f in range(3)];wall=[st.median(x['wall']/x['count'] for x in v) for v in gs];cpu=[st.median(x['cpu']/x['count'] for x in v) if all(x['cpu'] is not None for x in v) else None for v in gs];heaps=[x['heap'] for v in gs for x in v if x['heap'] is not None]
 result.append(dict(case=name,wall_median_ns=st.median(wall),wall_min_process_median_ns=min(wall),wall_max_process_median_ns=max(wall),cpu_median_ns=st.median(cpu) if all(x is not None for x in cpu) else None,caller_allocated_median_bytes=None,coarse_heap_max_bytes=max(heaps) if heaps else None,fork_wall_ns=wall))
owner=list(csv.DictReader((r/(stem+'.csv')).open()));assert len(owner)==33
for x,y in zip(owner,result):
 assert x['case']==y['case']
 for k in ['wall_median_ns','wall_min_process_median_ns','wall_max_process_median_ns','cpu_median_ns','caller_allocated_median_bytes','coarse_heap_max_bytes']:
  if y[k] is None:assert x[k]=='NA'
  else:assert math.isclose(float(x[k]),y[k],rel_tol=1e-14,abs_tol=1e-9)
by={x['case']:x for x in result};ratios=[]
for n in sizes:
 vals={k:by[f'kernel/{n}/distinct/k{k}-s16-e384']['fork_wall_ns'] for k in [16,32,64]}
 z=dict(size=n,K16_over_K32=[x/y for x,y in zip(vals[16],vals[32])],K32_over_K64=[x/y for x,y in zip(vals[32],vals[64])]);ratios.append(z)
 for k in ['K16_over_K32','K32_over_K64']:assert all(math.isclose(x,y,rel_tol=1e-14) for x,y in zip(z[k],s['ratios'][sizes.index(n)][k]))
full=[n for n in ids if all(groups[f][n][0]['count']>=64 for f in range(3))]
for n in full:assert len(hashes[n])==1
for size in sizes:
 names=[f'kernel/{size}/distinct/k{k}-s16-e384' for k in [16,32,64]]
 if all(n in full for n in names):assert len(set.union(*(hashes[n] for n in names)))==1
for line in Path(a[4]).read_text().splitlines():
 h,n=line.split('\t');assert sha(Path(n))==h
assert sha(Path(a[4]))==a[5] and sha(Path(a[6]))==a[7]
out={'status':'INDEPENDENT_NATIVE_K16_RAW_BINDING_STATS_PASS_NOT_ADOPTED','handle':89826,'source':s['source'],'source_files_verified':405,'cases':33,'TIME':693,'CHECK':99,'fresh_pid_start':identities,'owner_csv_all_stats_and_ratios_exact':True,'per_case':result,'ratios':ratios,'whole_process_envelopes':envelopes,'sub64_ring_cases':[n for n in ids if n not in full],'scope':'Forced-school full prewarm/post-counter product/input checks; Native verifier is not external oracle. Escaping64 ring digest caveat retained. Allocation NA, process CPU, historical coarse lastGC sample, whole-child RSS, no owned/per-operation peak. One bounded neighbor, no scalar20/10 rule/no automatic K8/no global-optimum/adoption.'}
p=r/'independent-native-balanced-adjacent-k16-1-raw-audit.json';p.write_text(json.dumps(out,indent=2)+'\n');print('PASS',sha(p));print(json.dumps(ratios))
PY
```
