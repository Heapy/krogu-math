#!/usr/bin/env python3
"""Strict paired28 inventory/oracle/statistics; no numerical benchmark implementation."""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics as stats
import sys

assert len(sys.argv) == 7, "ROOT JVM|JS|Wasm|Native currentSourceSHA baselineManifestSHA currentManifestSHA newOutputPrefix"
root, platform, source_sha, baseline_sha, current_sha, output = sys.argv[1:]
root, output = Path(root).resolve(), Path(output).resolve()
assert platform in {"JVM", "JS", "Wasm", "Native"}
assert all(re.fullmatch("[a-f0-9]{64}", value) for value in [source_sha, baseline_sha, current_sha])
assert root.is_dir() and not root.is_symlink()
json_output, csv_output = Path(str(output) + ".json"), Path(str(output) + ".csv")
assert not json_output.exists() and not csv_output.exists()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def properties(path):
    entries = [line.split("=", 1) for line in path.read_text().splitlines() if "=" in line]
    assert len(entries) == len({key for key, _ in entries}), f"Duplicate metadata: {path}"
    return dict(entries)

bits_values = [1, 30, 63, 64, 127, 511, 1023]
forward = [f"{api}/{bits}/{shape}" for bits in bits_values for shape in ["distinct", "square"]
           for api in ["public", "parallel-public"]]
ids = set(forward)
assert len(ids) == 28
before = properties(root / "binding-before.txt")
assert before["source_manifest_sha256"] == source_sha
assert before["baseline_manifest"] == baseline_sha and before["current_manifest"] == current_sha
records, identities, runtime_ids, sample_hashes, partial_ring = {}, set(), set(), {}, []
raw_bindings = []

for fork in range(3):
    order = "reverse" if fork == 1 else "forward"
    for label, artifact_sha in [("baseline", baseline_sha), ("current", current_sha)]:
        log = root / f"fork{fork}-{label}.log"
        assert Path(str(log) + ".exit").read_text().strip() == "0"
        binding = properties(Path(str(log) + ".binding"))
        assert binding["label"] == label and binding["source_manifest_sha256"] == source_sha
        assert binding["artifact_manifest_sha256"] == artifact_sha
        if "log_sha256" in binding:
            assert binding["log_sha256"] == sha(log)
        runtime = binding.get("runtime_id", before["runtime_id"])
        assert runtime == before["runtime_id"] and runtime
        runtime_ids.add(runtime)
        text, lines = log.read_text(), log.read_text().splitlines()
        def identity_field(key):
            value = binding.get(key)
            if value is None:
                value = re.search(r"\b" + key + r"=([0-9]+)", binding.get("identity", text)).group(1)
            return int(value)
        pid, started = identity_field("pid"), identity_field("start_epoch_ms")
        assert pid > 0 and started > 0 and (pid, started) not in identities
        if platform == "Native":
            observed = Path(str(log) + ".native-identity.txt").read_text()
        else:
            own_rows = [line for line in lines if line.startswith("# OWN539 ")]
            assert len(own_rows) == 1
            observed = own_rows[0]
        assert int(re.search(r"\bpid=([0-9]+)", observed).group(1)) == pid
        assert int(re.search(r"\bstart_epoch_ms=([0-9]+)", observed).group(1)) == started
        identities.add((pid, started))
        header = [line for line in lines if line.startswith("# calibration539 ")]
        assert len(header) == 1
        assert f"platform={platform} " in header[0] and "mode=public-small " in header[0]
        assert f"order={order} " in header[0] and header[0].endswith("cases=28")
        assert [line for line in lines if line.startswith("PASS539")] == ["PASS539,28,7"]
        checks = []
        for line in lines:
            if line.startswith("CHECK539"):
                fields = line.split(",")
                assert len(fields) == 3 and fields[0] == "CHECK539" and fields[2] == "PASS"
                checks.append(fields[1])
        expected_order = forward if order == "forward" else list(reversed(forward))
        assert checks == expected_order
        reps = {}
        for line in lines:
            if line.startswith("REP539"):
                marker, case, value = line.split(",")
                assert marker == "REP539"
                assert case in ids and case not in reps
                _, bits, shape = case.split("/")
                value_a = 1 if int(bits) == 1 else (1 << (int(bits) - 1)) + 1
                expected = value_a * (value_a if shape == "square" else value_a + 2)
                assert int(value) == expected
                reps[case] = value
        assert set(reps) == ids
        samples = {case: [] for case in ids}
        time_order = []
        for line in lines:
            if not line.startswith("TIME539"):
                continue
            fields = line.split(",")
            assert len(fields) == 9
            marker, case, sample, count, wall, cpu, allocation, heap, digest = fields
            assert marker == "TIME539"
            assert case in ids
            sample, count, wall = int(sample), int(count), int(wall)
            assert sample == len(samples[case]) and 0 <= sample < 7
            assert 1 <= count <= 8_388_608 and count & (count - 1) == 0 and wall > 0
            def available(value):
                if value == "NA":
                    return None
                number = int(value)
                assert number >= 0
                return number
            cpu, allocation, heap = map(available, [cpu, allocation, heap])
            if platform == "JVM":
                assert cpu is not None and allocation is not None
            else:
                assert allocation is None
            if platform in {"JS", "Wasm"}:
                assert cpu is not None
            if platform == "Wasm":
                assert heap is None
            int(digest)
            samples[case].append({"sample": sample, "count": count, "wall_ns": wall,
                                  "cpu_ns": cpu, "allocated_bytes": allocation, "coarse_heap_bytes": heap,
                                  "digest": digest})
            time_order.append(case)
        assert time_order == [case for case in expected_order for _ in range(7)]
        per_case = {}
        for case in sorted(ids):
            rows = samples[case]
            assert len(rows) == 7 and len({row["digest"] for row in rows}) == 1
            assert len({row["count"] for row in rows}) == 1
            if all(row["count"] >= 64 for row in rows):
                sample_hashes.setdefault(case, set()).add(rows[0]["digest"])
            else:
                partial_ring.append({"fork": fork, "label": label, "case": case})
            def median_per_operation(field):
                values = [row[field] / row["count"] for row in rows if row[field] is not None]
                return stats.median(values) if len(values) == 7 else None
            per_case[case] = {"wall_ns": median_per_operation("wall_ns"), "cpu_ns": median_per_operation("cpu_ns"),
                              "caller_allocated_bytes": median_per_operation("allocated_bytes"),
                              "cpu_available_samples": sum(row["cpu_ns"] is not None for row in rows),
                              "allocation_available_samples": sum(row["allocated_bytes"] is not None for row in rows),
                              "samples": rows}
        records[f"{fork}/{label}"] = {"pid": pid, "start_epoch_ms": started, "cases": per_case}
        raw_bindings.append({"fork": fork, "label": label, "log_sha256": sha(log),
                             "binding_sha256": sha(Path(str(log) + ".binding")), "pid": pid, "start_epoch_ms": started})

assert len(runtime_ids) == 1
assert all(len(values) == 1 for values in sample_hashes.values())
for fork in range(3):
    first, second = ("current", "baseline") if fork == 1 else ("baseline", "current")
    assert records[f"{fork}/{first}"]["start_epoch_ms"] < records[f"{fork}/{second}"]["start_epoch_ms"]
    if fork < 2:
        next_first = "current" if fork + 1 == 1 else "baseline"
        assert records[f"{fork}/{second}"]["start_epoch_ms"] < records[f"{fork+1}/{next_first}"]["start_epoch_ms"]

cases = []
for case in sorted(ids):
    baseline = [records[f"{fork}/baseline"]["cases"][case]["wall_ns"] for fork in range(3)]
    current = [records[f"{fork}/current"]["cases"][case]["wall_ns"] for fork in range(3)]
    ratios, deltas = [c / a for a, c in zip(baseline, current)], [c - a for a, c in zip(baseline, current)]
    median_ratio, median_delta = stats.median(ratios), stats.median(deltas)
    assert all(math.isfinite(value) for value in ratios + deltas)
    cases.append({"case": case, "baseline_fork_wall_ns": baseline, "current_fork_wall_ns": current,
                  "paired_ratios": ratios, "paired_deltas_ns": deltas,
                  "median_paired_ratio": median_ratio, "median_paired_delta_ns": median_delta,
                  "investigate_15percent_AND_5ns": median_ratio > 1.15 and median_delta > 5,
                  "all3_slower": all(value > 1 for value in ratios),
                  "all3_faster": all(value < 1 for value in ratios)})
result = {"status": "STRICT_PAIRED_DATA_PASS_NOT_ADOPTION", "platform": platform,
          "TIME": 1176, "REP": 168, "CHECK": 168, "cases": cases, "forks": records,
          "raw_bindings": raw_bindings, "source_manifest_sha256": source_sha,
          "baseline_artifact_manifest_sha256": baseline_sha, "current_artifact_manifest_sha256": current_sha,
          "guard_flags": [row["case"] for row in cases if row["investigate_15percent_AND_5ns"]],
          "partial_ring_scope": partial_ring,
          "scope": "Historical baseline is identified by its immutable artifact manifest, not relabelled as current source. Current source SHA binds the frozen execution context. Caller allocation differs from owned/peak memory; heap samples and whole-process RSS are not per-operation retained size. Guard flags trigger investigation, not an automatic adoption verdict."}
with csv_output.open("x", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["case", "median_paired_ratio", "median_paired_delta_ns", "investigate_15percent_AND_5ns", "pair0_ratio", "pair1_ratio", "pair2_ratio", "pair0_delta_ns", "pair1_delta_ns", "pair2_delta_ns"])
    for row in cases:
        writer.writerow([row["case"], row["median_paired_ratio"], row["median_paired_delta_ns"], row["investigate_15percent_AND_5ns"], *row["paired_ratios"], *row["paired_deltas_ns"]])
with json_output.open("x") as handle:
    json.dump(result, handle, indent=2)
    handle.write("\n")
print(f"STRICT_PAIRED28_PASS,{platform},TIME=1176,REP=168,guard_flags={len(result['guard_flags'])}")
