# Independent KLIB consumer delivery fixture

SOURCE ONLY: UNCOMPILED/UNRESOLVED/UNRUN. Exclusively owned external preparation. No root source/frozen candidate changes, no asset copy, no project dependency, friend access, test/diagnostic worker module, Mocha or private-root registration. It fills a concrete gap: existing root probes cannot establish independently linked KLIB consumer delivery.

## Inputs and source route

Producer must first actually publish the composed Node candidate to an isolated Maven directory. Supply its full actual source commit, GAV and a SHA-bound publication ledger (schema example deliberately has placeholders). Ledger includes ALL Krogu local-publication metadata/POM/KLIB files used; sourceCommit is a provenance label to be tied to the producer's actual build/publish/source logs, not independent proof obtained just by typing a SHA. Root/module coordinates are io.heapy.krogu:krogu-math:<exact supplied version>. Exclusive Gradle repository content prevents Krogu fallback to Maven Central.

Standalone consumer pins Kotlin2.4.21, CommonJS JS executable and ESM Wasm executable. It depends only on that published public Krogu coordinate and ordinary Kotlin stdlib. No srcDir from producer. Producer's embedded independent worker payload must survive KLIB linking/DCE into the consumer automatically. Publishing and checking generated KLIB/resources remain real future proofs, not guaranteed by this descriptor.

The common application calls actual public parallelMultiply on physical4096word distinct/same/sign cases and compares independent power-of-two polynomial identities (no multiplication in oracle), then checks public input preservation. Prepared private production registry observation confirms two real workers, six accepted jobs, payloadkind and idle ownership. This is a version-bound diagnostic observation of current implementation, not a new public API contract. CPU<=2 is explicitly unsupported for child-route proof; numeric fallback is still checked. Missing backend on eligible pinned Node is FAIL, not silent unsupported.

Application-init sentinel requires main-thread invocation and exact one owner file/stdout marker; any entrypoint reexecution in a production worker fails. Its scope is absence of observed application entrypoint reexecution, not a claim every consumer lazy field was force-initialized. The private executable payload/consumer closure build manifests separately establish no consumer root import. Both CJS and Wasm use the same test source; actual consumer linker output mode must be inspected/bound.

## Future build commands — not executed

Use existing repo Gradle9.8.1 wrapper and BellSoft25.0.4+9-LTS via clean explicit JAVA_HOME/PATH. `publish-delivery.init.gradle.kts` adds an external task-owned Delivery539 repository through the existing Maven Publish plugin without editing producer source. Future producer command (not executed):

```
<producer>/gradlew --no-daemon --max-workers=1 --project-dir <producer> \
  --init-script <this-directory>/publish-delivery.init.gradle.kts \
  -Pdelivery539Repository=<new-isolated-Maven-directory> \
  publishKotlinMultiplatformPublicationToDelivery539Repository \
  publishJsPublicationToDelivery539Repository publishWasmJsPublicationToDelivery539Repository
```

This selects root metadata and the two actual consumer targets; it does not require unrelated Native/JVM publication. Task names follow existing KMP publication names and still require first actual Gradle configuration/build proof. Record actual command/exit and produce the complete actual publication ledger before consumer resolution.

Once those actual inputs exist, consumer command:

```
<repo>/gradlew --no-daemon --max-workers=1 --project-dir <this-directory> \
  -PkroguRepository=<isolated-Maven-directory> \
  -PkroguVersion=<exact-published-version> \
  -PkroguCommit=<actual-producer-40hex> \
  -PpublicationLedger=<external-publication-ledger.json> \
  -PpublicationLedgerSha256=<its-64hex> \
  verifyPublished539 jsProductionExecutableCompileSync wasmJsProductionExecutableCompileSync
```

Record actual Gradle/JDK/compiler identities, argv/exit, resolved metadata/classpath and file SHA, source pre/post freeze, and JS/Wasm linked output. No dependency resolution/download/build has happened in this preparation. Build descriptor requires actual supplied hashes; placeholders are not passing evidence. This is an independent consumer after source application, not a comparison measurement or accepted539 completion claim.

## Future runtime command and artifact ledger

Create an external linked manifest for EACH complete runtime output directory, with `sourceCommit`, `publicationLedgerSha256`, and files `{path,bytes,sha256}`. It must include every linked file (maps too if present) and live outside that directory; controller rejects extra/missing/symlinked files. Choose actual executable entry from recorded build output, not a guessed basename. Supply exact Node24.16.0 binary SHA. No worker files are staged separately.

```
<pinned-node-24.16.0> check-delivery.cjs \
  <same-node-path> <node-SHA256> \
  <linked-runtime-root> <actual-entry-relative.js-or.mjs> \
  <external-linked-manifest.json> <linked-manifest-SHA256> \
  <isolated-Maven-directory> <publication-ledger.json> <publication-ledger-SHA256> \
  <actual-producer-40hex> <js-or-wasm> <idle-or-short> <new-owned-output>
```

Controller writes an owned host, pins inputs before/after and launches exactly one cleanenv process with180s deadline/5s owned escalation. Source/published/linked runtime identities remain distinct. Partial stdout/stderr/process/terminal evidence is preserved on failure. COMPLETE only follows numeric proof, one app-init marker and either strict delivery PASS or explicit CPU<=2 unsupported. Other failures are FAIL. It does not manufacture recovery hashes or reinterpret timeouts as successful unsupported.

Run BOTH `idle` and `short` as separate owned fresh processes. Short mode returns immediately after recording the real pool, adds NO observer keepalive, and the parent checks exact original paths absent after natural exit0. This specifically requires the reviewed production normal-exit retirement correction; old idle-only backend must fail this mode.

In idle mode, after main returns, host records the real pool and maintains its OWN ref'ed wait timers solely to observe natural production30s idle retirement. It never directly quarantines/terminates to create a passing cleanup result. All original tempfiles/dir must disappear before PASS, after which the child must naturally exit; retained resources eventually hit the outer deadline. Failure-only cleanup is explicitly labelled and cannot turn failure into success. Workers use only generated internal payload assets; no caller asset copying or application-root import is present.

The separate short mode closes the previous observer-lifetime gap. Explicit process.exit/fatal exit/SIGKILL bypass beforeExit and remain excluded from the normal-natural-exit promise; no crash cleanup guarantee is invented. No performance/first-call/steady/peak numbers are inferred from untimed execution. Existing public-route timing fixture remains separate, and this does not duplicate its benchmark inventory.
