import org.gradle.api.publish.PublishingExtension

// External, reversible publication destination; no producer source mutation.
allprojects {
    pluginManager.withPlugin("maven-publish") {
        extensions.configure<PublishingExtension> {
            repositories {
                maven {
                    name = "Delivery539"
                    url = uri(providers.gradleProperty("delivery539Repository").get())
                }
            }
        }
    }
}
