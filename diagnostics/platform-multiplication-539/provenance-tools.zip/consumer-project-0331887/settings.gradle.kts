pluginManagement { repositories { gradlePluginPortal(); mavenCentral() } }
rootProject.name = "krogu539-delivery-consumer"
