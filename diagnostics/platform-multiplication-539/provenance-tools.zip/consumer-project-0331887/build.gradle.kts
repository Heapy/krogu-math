import groovy.json.JsonSlurper
import java.security.MessageDigest
import java.nio.file.Files
import org.jetbrains.kotlin.gradle.dsl.JsModuleKind

plugins { kotlin("multiplatform") version "2.4.21" }

val repositoryPath = providers.gradleProperty("kroguRepository").get()
val kroguVersion = providers.gradleProperty("kroguVersion").get()
val expectedCommit = providers.gradleProperty("kroguCommit").get().also { require(it.matches(Regex("[a-f0-9]{40}"))) }
val ledgerFile = file(providers.gradleProperty("publicationLedger").get())
val ledgerSha = providers.gradleProperty("publicationLedgerSha256").get()
fun sha(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
fun verifyPublication() {
    require(ledgerSha.matches(Regex("[a-f0-9]{64}")) && sha(ledgerFile.readBytes()) == ledgerSha)
    val root = file(repositoryPath).canonicalFile
    val ledger = JsonSlurper().parse(ledgerFile) as Map<*, *>
    require(ledger["sourceCommit"] == expectedCommit)
    require(ledger["group"] == "io.heapy.krogu" && ledger["module"] == "krogu-math" && ledger["version"] == kroguVersion)
    val paths = mutableSetOf<String>()
    for (entry in ledger["files"] as List<*>) {
        val record = entry as Map<*, *>; val path = record["path"] as String
        require(path.isNotEmpty() && path.split('/').none { it.isEmpty() || it == "." || it == ".." } && !path.startsWith('/'))
        require(paths.add(path))
        val artifact = root.resolve(path).canonicalFile
        require(artifact.toPath().startsWith(root.toPath()) && artifact.isFile)
        require(artifact.length() == (record["bytes"] as Number).toLong())
        require(sha(artifact.readBytes()) == record["sha256"])
    }
    val actual = root.walkTopDown().onEnter { require(!Files.isSymbolicLink(it.toPath())); true }
        .filter { it.isFile }.map { require(!Files.isSymbolicLink(it.toPath())); it.relativeTo(root).invariantSeparatorsPath }.toSet()
    require(actual == paths) { "Isolated publication repository has unindexed files" }
    require(paths.any { it.endsWith(".module") } && paths.count { it.endsWith(".klib") } >= 2)
}
verifyPublication()
repositories {
    exclusiveContent {
        forRepository { maven { url = uri(repositoryPath) } }
        filter { includeGroup("io.heapy.krogu") }
    }
    mavenCentral()
}
kotlin {
    js {
        nodejs(); binaries.executable()
        compilerOptions { moduleKind.set(JsModuleKind.MODULE_COMMONJS) }
    }
    @OptIn(org.jetbrains.kotlin.gradle.ExperimentalWasmDsl::class)
    wasmJs { nodejs(); binaries.executable() }
    sourceSets.commonMain.dependencies { implementation("io.heapy.krogu:krogu-math:$kroguVersion") }
}
val verifyPublished539 = tasks.register("verifyPublished539") { doLast { verifyPublication() } }
tasks.matching { it.name.startsWith("compileKotlin") || it.name.endsWith("ExecutableCompileSync") }.configureEach {
    dependsOn(verifyPublished539)
}
// No sourceSets srcDir from producer, project dependency, diagnostic/test module,
// worker module dependency, assets copy, special friend access or test callbacks.
