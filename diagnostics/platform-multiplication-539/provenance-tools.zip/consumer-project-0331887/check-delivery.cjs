'use strict';
// Standalone untimed delivery controller. Not a numerical benchmark.
const fs=require('node:fs'), path=require('node:path'), crypto=require('node:crypto'), cp=require('node:child_process');
const [node,nodeSHA,rootArg,entryRelative,linkedLedgerArg,linkedSHA,repositoryArg,publicationArg,publicationSHA,commit,kind,lifecycle,outputArg]=process.argv.slice(2);
if(process.argv.length!==15) throw Error('node nodeSHA linkedRoot entryRelative linkedLedger linkedSHA repository publicationLedger publicationSHA sourceCommit js|wasm idle|short newOutput');
if(!['idle','short'].includes(lifecycle)||!['js','wasm'].includes(kind)||!/^[a-f0-9]{40}$/.test(commit)) throw Error('Arguments');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const hashFile=p=>hash(fs.readFileSync(p));
if(fs.realpathSync(process.execPath)!==fs.realpathSync(node)||hashFile(node)!==nodeSHA||process.versions.node!=='24.16.0') throw Error('Pinned Node runtime binding');
const root=fs.realpathSync(rootArg),repository=fs.realpathSync(repositoryArg);
const linkedLedger=fs.realpathSync(linkedLedgerArg),publication=fs.realpathSync(publicationArg);
function fileAt(base,relative) {
 if(typeof relative!=='string'||relative.split('/').some(p=>!p||p==='.'||p==='..')||path.isAbsolute(relative)) throw Error('Manifest path');
 let p=base;
 for(const part of relative.split('/')) {p=path.join(p,part);if(fs.lstatSync(p).isSymbolicLink()) throw Error('Symlink input');}
 return p;
}
function verify() {
 if(hashFile(node)!==nodeSHA||hashFile(linkedLedger)!==linkedSHA||hashFile(publication)!==publicationSHA) throw Error('Input binding changed');
 const pub=JSON.parse(fs.readFileSync(publication,'utf8')), linked=JSON.parse(fs.readFileSync(linkedLedger,'utf8'));
 if(pub.sourceCommit!==commit||linked.sourceCommit!==commit||linked.publicationLedgerSha256!==publicationSHA) throw Error('Source/publication binding');
 for(const [base,ledger] of [[root,linked],[repository,pub]]) {
  if(!Array.isArray(ledger.files)||!ledger.files.length) throw Error('Empty manifest');
  const names=new Set();let size=0;
  for(const record of ledger.files) {
   if(names.has(record.path)) throw Error('Duplicate path');names.add(record.path);
   const file=fileAt(base,record.path), stat=fs.statSync(file);
   size+=stat.size;if(size>512*1024*1024||!stat.isFile()||stat.size!==record.bytes||hashFile(file)!==record.sha256) throw Error('Artifact binding');
  }
  {
   if(base===root && !names.has(entryRelative)) throw Error('Unbound entry');
   const actual=[];
   function walk(dir,prefix) {for(const item of fs.readdirSync(dir,{withFileTypes:true})){if(item.isSymbolicLink())throw Error('Symlink tree');const rel=prefix+item.name;if(item.isDirectory())walk(path.join(dir,item.name),rel+'/');else actual.push(rel);}}
   walk(base,'');if(actual.length!==names.size||actual.some(x=>!names.has(x))) throw Error('Unindexed linked runtime closure');
  }
 }
}
verify();
if(fs.existsSync(outputArg)) throw Error('Output already exists');
fs.mkdirSync(outputArg,{mode:0o700});const output=fs.realpathSync(outputArg);
const appInit=path.join(output,'application-init.txt');
const host=path.join(output,'delivery-host.cjs');
fs.writeFileSync(host,String.raw`
'use strict';
const fs=require('node:fs');
(async()=>{
 const entry=process.argv[2], kind=process.argv[3], lifecycle=process.argv[4];
 await import(require('node:url').pathToFileURL(entry).href);
 const key=Symbol.for('io.heapy.krogu.node-parallel-539.v1'), owner=process[key];
 if(!fs.existsSync(process.env.KROGU539_APP_INIT_PATH)) throw Error('Consumer main was not executed');
 const lines=fs.readFileSync(process.env.KROGU539_APP_INIT_PATH,'utf8').trim().split('\n');
 if(lines.length!==1||lines[0]!==String(process.pid)) throw Error('App initialization witness');
 if(!owner) {
  const o=require('node:os');
  if(o.availableParallelism()>2) throw Error('Missing real public backend');
  console.log('DELIVERY539,UNSUPPORTED,CPU<=2');return;
 }
 const payload=JSON.parse(owner.payload);
 if(payload.kind!==kind||owner.sequence!==6||owner.state!=='IDLE') throw Error('Wrong published backend/accepted route');
 const directory=owner.directory, files=owner.files.slice();
 if(!directory||!owner.timer||owner.timer.hasRef()||owner.slots.some(s=>s.pending||s.port.hasRef())) throw Error('Unbounded/liveness ownership');
 console.log('IDLE_DELIVERY539,'+JSON.stringify({directory,files,payloadIdentity:owner.identity}));
 if(lifecycle==='short') {console.log('DELIVERY539,SHORT_NATURAL_EXIT_READY');return;}
 // The observer's own timers keep this isolated fixture alive long enough to
 // exercise NATURAL idle retirement. No direct quarantine/terminate success shortcut.
 const until=Date.now()+45000;
 while(process[key]===owner) {
  if(Date.now()>until||owner.state==='BROKEN') throw Error('Natural idle cleanup did not complete');
  await new Promise(resolve=>setTimeout(resolve,25));
 }
 if(fs.existsSync(directory)||files.some(file=>fs.existsSync(file))) throw Error('Owned worker files survived normal idle cleanup');
 console.log('DELIVERY539,PASS');
})().catch(async error=>{
 // Failed evidence stays failed; bounded cleanup is explicitly diagnostic.
 console.error(error);
 const owner=process[Symbol.for('io.heapy.krogu.node-parallel-539.v1')];
 if(owner) { console.log('FAILED_DELIVERY_CLEANUP539');owner.quarantine(); }
 process.exitCode=1;
});
`,{flag:'wx',mode:0o600});
const argv=[node,'--max-old-space-size=512',host,fileAt(root,entryRelative),kind,lifecycle];
const binding={nodeSHA,version:process.version,linkedSHA,publicationSHA,sourceCommit:commit,kind,lifecycle,argv,hostSHA:hashFile(host),controllerSHA:hashFile(__filename),scope:'untimed independent KLIB consumer delivery, natural idle cleanup, no manual worker assets'};
fs.writeFileSync(path.join(output,'binding.json'),JSON.stringify(binding,null,2));
// Allocate/open all output files before creating the owned process. Synchronous
// bounded writes avoid unhandled stream errors and COMPLETE-before-flush races.
let outFD=null,errFD=null;
try {
 outFD=fs.openSync(path.join(output,'stdout.log'),'wx',0o600);
 errFD=fs.openSync(path.join(output,'stderr.log'),'wx',0o600);
} catch(error) {if(outFD!==null)fs.closeSync(outFD);throw error;}
let child=null,stdout='',stderr='',timeout=false,overflow=false,failure=null,timer=null,killTimer=null;
function stopOwned(error) {
 if(error && failure===null)failure=error;
 if(!child || child.exitCode!==null || child.signalCode!==null)return;
 try {child.kill('SIGTERM');} catch(problem) {if(failure===null)failure=problem;}
 if(killTimer===null)killTimer=setTimeout(()=>{
  if(child.exitCode===null && child.signalCode===null) {try {child.kill('SIGKILL');} catch(problem) {if(failure===null)failure=problem;}}
 },5000);
}
function capture(which,data) {
 try {
  const current=which==='out'?stdout:stderr, remaining=Math.max(0,4*1024*1024-Buffer.byteLength(current));
  const part=data.subarray(0,remaining);
  let offset=0;while(offset<part.length) {const written=fs.writeSync(which==='out'?outFD:errFD,part,offset,part.length-offset);if(written<=0)throw Error('Captured log write stalled');offset+=written;}
  if(which==='out')stdout+=part;else stderr+=part;
  if(part.length!==data.length){overflow=true;stopOwned(Error('Captured output limit'));}
 } catch(error) {stopOwned(error);}
}
function terminal(code,signal) {
 clearTimeout(timer);clearTimeout(killTimer);
 for(const fd of [outFD,errFD]) if(fd!==null) {
  try {fs.fsyncSync(fd);} catch(error) {if(failure===null)failure=error;}
  try {fs.closeSync(fd);} catch(error) {if(failure===null)failure=error;}
 }
 outFD=null;errFD=null;
 try {
  verify();
  fs.writeFileSync(path.join(output,'terminal.json'),JSON.stringify({code,signal,timeout,overflow,failure:failure?String(failure):null}));
  if(failure||timeout||overflow||code!==0||stderr.length||stdout.split('\n').filter(x=>x.startsWith('APPINIT539,')).length!==1||!stdout.includes('NUMERIC_DELIVERY539,PASS')) throw failure||Error('Consumer execution failed');
  let status=stdout.includes('DELIVERY539,PASS')?'PASS':stdout.includes('DELIVERY539,UNSUPPORTED,CPU<=2')?'UNSUPPORTED_CPU':null;
  if(lifecycle==='short' && stdout.includes('DELIVERY539,SHORT_NATURAL_EXIT_READY')) {
   const records=stdout.split('\n').filter(x=>x.startsWith('IDLE_DELIVERY539,'));
   if(records.length!==1) throw Error('Missing short-exit owned paths');
   const record=JSON.parse(records[0].slice('IDLE_DELIVERY539,'.length));
   if(fs.existsSync(record.directory)||record.files.some(file=>fs.existsSync(file))) throw Error('Natural short exit leaked owned worker files');
   status='PASS';
  }
  if(!status) throw Error('Missing delivery result');
  fs.writeFileSync(path.join(output,'COMPLETE.json'),JSON.stringify({status,sourceCommit:commit,kind,lifecycle}));
  console.log(status);
 } catch(error) {console.error(error);process.exitCode=1;}
}
try {
 child=cp.spawn(node,argv.slice(1),{cwd:output,env:{PATH:path.dirname(node),LANG:'C',LC_ALL:'C',TZ:'UTC',KROGU539_APP_INIT_PATH:appInit},stdio:['ignore','pipe','pipe']});
 // Terminal ownership and cleanup timers precede the first fallible filesystem
 // operation after spawn. Every later failure stops this exact child and waits
 // for close; it never abandons the running process by throwing out of a callback.
 child.once('close',terminal);
 child.once('error',error=>stopOwned(error));
 child.stdout.on('error',error=>stopOwned(error));child.stderr.on('error',error=>stopOwned(error));
 child.stdout.on('data',data=>capture('out',data));child.stderr.on('data',data=>capture('err',data));
 timer=setTimeout(()=>{timeout=true;stopOwned(Error('Delivery deadline'));},180000);
 fs.writeFileSync(path.join(output,'owned-process.json'),JSON.stringify({pid:child.pid,startedAt:new Date().toISOString(),argv}));
} catch(error) {
 if(child){process.exitCode=1;stopOwned(error);}
 else {for(const fd of [outFD,errFD])if(fd!==null){try{fs.closeSync(fd);}catch(_){}}throw error;}
}
