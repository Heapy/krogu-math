package delivery539
internal actual fun markApplicationInit539(): Unit = js("""(function(){
const w=process.getBuiltinModule('worker_threads');
if(!w.isMainThread || (w.workerData&&w.workerData.krogu539Role)) throw Error('Consumer application reentered in worker');
const key=Symbol.for('krogu539.consumer.application.init');
process[key]=(process[key]||0)+1;
if(process[key]!==1) throw Error('Repeated consumer application initialization');
const fs=process.getBuiltinModule('fs');
const target=process.env.KROGU539_APP_INIT_PATH;
if(!target) throw Error('Missing owned application-init witness');
fs.writeFileSync(target,String(process.pid)+'\n',{flag:'wx',mode:384});
console.log('APPINIT539,'+process.pid);
})()""")
internal actual fun inspectPool539(): Unit = js("""(function(){
const p=process, os=p.getBuiltinModule('os');
const cpus=typeof os.availableParallelism==='function'?os.availableParallelism():os.cpus().length;
const owner=p[Symbol.for('io.heapy.krogu.node-parallel-539.v1')];
if(cpus<=2) {if(owner) throw Error('Unexpected pool at CPU<=2');console.log('UNSUPPORTED_DELIVERY539,CPU<=2');return;}
if(!owner || owner.state!=='IDLE' || owner.slots.length!==2 || owner.sequence!==6) throw Error('Actual public worker route not witnessed');
const payload=JSON.parse(owner.payload);
if(payload.protocol!=='krogu539.v1') throw Error('Production payload protocol');
if(owner.slots.some(slot=>slot.pending!==0 || !slot.worker || slot.worker.threadId<1 || slot.port.hasRef())) throw Error('Pool terminal/idle refs');
if(!owner.directory || !owner.timer || owner.timer.hasRef()) throw Error('Pool owned idle retirement');
console.log('POOL_DELIVERY539,'+JSON.stringify({identity:owner.identity,kind:payload.kind,sequence:owner.sequence,directory:owner.directory,files:owner.files}));
})()""")
