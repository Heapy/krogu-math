import java.io.File;
import java.lang.management.ManagementFactory;
import java.lang.reflect.InvocationTargetException;
public final class CalibrationLaunch539 {
  public static void main(String[] args) throws Throwable {
    if(args.length!=1) throw new IllegalArgumentException("one campaign config");
    if(!System.getProperty("java.vendor").equals("BellSoft") || !System.getProperty("java.runtime.version").equals("25.0.4+9-LTS")) throw new AssertionError("pinned runtime");
    for(String name : new String[]{"MagnitudeMultiplication", "MultiplicationPolicy539", "MultiplicationCalibration539JvmMain", "MultiplicationCampaign539"}) {
      Class<?> c=Class.forName("io.heapy.krogu.math."+name, false, CalibrationLaunch539.class.getClassLoader());
      File got=new File(c.getProtectionDomain().getCodeSource().getLocation().toURI()).getCanonicalFile();
      File wanted=new File(System.getProperty(name.equals("MagnitudeMultiplication") || name.equals("MultiplicationPolicy539") ? "krogu539.main" : "krogu539.probe")).getCanonicalFile();
      if(!got.equals(wanted)) throw new AssertionError("wrong origin "+name+" "+got);
      System.out.println("# ORIGIN539 "+name+"="+got);
    }
    long start=ProcessHandle.current().info().startInstant().orElseThrow().toEpochMilli();
    System.out.println("# OWN539 pid="+ProcessHandle.current().pid()+" start_epoch_ms="+start+" max_heap="+Runtime.getRuntime().maxMemory()+" flags="+ManagementFactory.getRuntimeMXBean().getInputArguments());
    try { Class.forName("io.heapy.krogu.math.MultiplicationCalibration539JvmMain").getMethod("main",String[].class).invoke(null,(Object)args); }
    catch(InvocationTargetException e) { throw e.getCause(); }
  }
}
