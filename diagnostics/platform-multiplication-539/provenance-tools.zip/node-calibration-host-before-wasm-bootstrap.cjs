// Untimed task-owned Mocha selector/identity wrapper; numerical code stays in the built Kotlin probe.
const fs = require('node:fs');
const path = require('node:path');
const {performance} = require('node:perf_hooks');
(async () => {
  const [entryArg, mochaArg, kind] = process.argv.slice(2);
  if(process.argv.length!==5 || !['JS','Wasm'].includes(kind) || process.version!=='v24.16.0') throw Error('pinned args/runtime');
  const root=fs.realpathSync(__dirname);
  const entry=fs.realpathSync(entryArg), mochaPath=fs.realpathSync(mochaArg);
  for(const file of [entry,mochaPath]) if(!file.startsWith(root+path.sep)) throw Error('Input outside owned artifact tree');
  function verifyCache(phase) {
    let count=0;
    for(const filename of Object.keys(require.cache)) {
      const real=fs.realpathSync(filename);
      if(!real.startsWith(root+path.sep)) throw Error('Loaded CommonJS file outside immutable tree: '+real);
      count++;
    }
    console.log('# CACHEORIGIN539 phase='+phase+' files='+count+' owned=true');
  }
  console.log('# OWN539 pid='+process.pid+' start_epoch_ms='+Math.trunc(performance.timeOrigin)+' node='+process.version+' kind='+kind+' flags='+JSON.stringify(process.execArgv));
  console.log('# ORIGIN539 entry='+entry+' mocha='+mochaPath);
  const Mocha=require(mochaPath);
  const mocha=new Mocha({ui:'bdd',reporter:'dot',timeout:0,grep:/MultiplicationCalibration539.*optionalCampaign/});
  mocha.addFile(entry);
  await mocha.loadFilesAsync();
  verifyCache('before-run');
  const runner=mocha.run((failures)=> {
    const stats=runner.stats;
    console.log('# SELECTED539 tests='+stats.tests+' passes='+stats.passes+' failures='+stats.failures+' pending='+stats.pending);
    try {
      verifyCache('after-run');
      if(failures!==0 || stats.tests!==1 || stats.passes!==1 || stats.failures!==0 || stats.pending!==0) process.exitCode=3;
    } catch(error) { console.error(error.stack||String(error)); process.exitCode=3; }
  });
})().catch(error=>{ console.error(error.stack||String(error)); process.exitCode=3; });
