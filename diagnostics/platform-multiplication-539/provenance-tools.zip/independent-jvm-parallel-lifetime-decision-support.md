# JVM parallel lifetime decision support — conditional, not adoption

Uses the accepted17831 audit only:1260 steady PAR rows,90 full cold SETUP observations and45 payload rows. JSON companion retains all30 worker/shape/size comparisons, three fork ratios and CPU/allocation deltas. No new run or raw audit.

Each comparator is the faster **same-process, same-prepared-operands** serial kernel/frame median. Steady is seven-sample process median with one actual owned pool reused. Fresh is one actual pool construction→first product→shutdown→await per process; it is not a fresh whole-JVM measurement. Reported qualifying points meet the unchanged PARALLEL-only rule: median ratio≤0.80 and every pair≤0.90. Two adjacent measured sizes are required; this rule is not applied to serial tuning.

| Shape / worker count | Reused-pool qualifying sizes (words) | Fresh-pool qualifying sizes (words) | Conditional reading |
|---|---|---|---|
| Distinct /1 |4096,8192|4096,8192|Two adjacent points in both models;16384 fails the margin, so no monotone all-larger-size claim |
| Distinct /2 |1024,4096,8192,16384|4096,8192,16384|Reuse evidence begins earlier; fresh1024 is slower, not an amortized win |
| Self-square /1 |4096,8192|4096,8192|Two adjacent points;16384 does not qualify in either model |
| Self-square /2 |1024,4096,8192,16384|4096,8192|Fresh16384 has a0.969 adverse-to-margin pair; do not extrapolate the fresh4096/8192 support upward |
|1:2 /1 |256 isolated;4096,8192,16384|8192,16384|256 is not adjacent support because1024 fails; fresh support starts later |
|1:2 /2 |256 isolated;4096,8192,16384|4096,8192|Fresh16384 has a1.029 ratio pair; no all-larger-size fresh guarantee |

There is **no proven public threshold** in this table. It identifies observed latency eligibility for a particular private route and lifetime. All other sizes, mixed pairs and failed margin points remain in the JSON.

## Cost examples that prevent a latency-only conclusion

| Actual observation | Latency comparison | CPU/allocation/lifetime boundary |
|---|---|---|
|1024 distinct,2 workers | Steady median ratio0.512; fresh1.129 (pairs1.068/1.282/1.129) | Steady CPU ratios0.978/1.142/1.433; about24.5kB additional approximate all-thread allocation against chosen serial route. Full fresh pool median0.313ms includes termination; cannot label a single call as0.512× |
|4096 distinct,2 workers | Steady0.392; fresh0.448, both pass all pairs | Steady CPU1.092/1.018/1.130; chosen serial route changes kernel/kernel/frame across forks, so allocation deltas98,282/98,290/522B describe different comparators, not one fixed cost |
|16384 distinct,2 workers | Steady0.670; fresh0.344 in these observations | Steady CPU1.763/2.234/1.116; cold and steady occur in different phases and have different sample counts. Their difference is NOT an isolated pool-overhead measurement |
|256 distinct,2 workers | Steady1.241, slower in all three pairs; fresh15.598 | Thread lifecycle clearly cannot be hidden by a reused-pool figure at this size |

Allocation is approximate **all-thread** bytes, including runtime/background activity; it is distinct from caller-only common-mode allocation. Pool-peak sums are upper bounds containing pre-existing live heap. Whole-process RSS (about303–429MB in these forks) includes runtime, references and earlier cases; neither is an exact per-operation or per-pool retained size. Logical frame payload excludes headers, scheduler state and caller inputs. Fresh SETUP has one observation per case per process, versus seven steady samples; no confidence interval, hypothetical amortization or break-even count is invented.

## Existing final public-route obligations still outstanding

1. Choose and review the **actual** bounded lifetime: reused owned pool or per-call pool. If per-call, charge the measured complete lifecycle; if reused, do not promise the steady figure for first invocation or unsupported reuse.
2. Include the actual current public serial `multiply` comparator where its frontend/materialization differs from private kernel/frame; current28 public-small baseline cases cover both API names but do not establish large public-route performance.
3. Run the already-planned selected-policy/route controls and branch fixtures around the chosen entry/fallback boundary, including aliases/distinct inputs, compact/scalar promotion paths, signs/zero, subtype virtual fallback, result identity and failure/interrupt/resource ownership. Preserve529 scalar fast paths and once-per-operation materialization.
4. Apply the frozen per-case small guard (>15% AND >5ns investigation trigger) to matched final public-small before/after results for BOTH APIs; current baseline is not that final guard.
5. Make an explicit bounded CPU/allocation/peak/startup tradeoff judgment, then focused/full composed correctness and independent acceptance. Latency eligibility alone is not approval.

Other three platforms retain their complete calibration and real transport/lifecycle scope. These JVM observations do not prune them or imply common public adoption.
