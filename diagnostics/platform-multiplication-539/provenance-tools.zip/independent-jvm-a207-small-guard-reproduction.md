Read-only independent audit of actual 98393. This parses retained logs and identities, recomputes the frozen statistics, and verifies source/runtime bindings. It launches no numerical workload. Original JVM sidecars bind the exact raw `# OWN539` identity rather than duplicating PID/start fields.

```sh
python3 - <<'PY'
from pathlib import Path
import json,csv,re,statistics as st,hashlib,math
r=Path('.codex-work/539');d=r/'actual-public-jvm-paired-small-3';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=json.loads((r/'actual-public-jvm-paired-small-3-summary.json').read_text());pre=json.loads((r/'fused-compact-three-guards-prelaunch.json').read_text())['groups'][0];a=pre['argv'];props=lambda p:dict(x.split('=',1) for x in p.read_text().splitlines() if '=' in x);before=props(d/'binding-before.txt');assert before['source_manifest_sha256']==a[7] and before['baseline_manifest']==a[3] and before['current_manifest']==a[5];ids=[f'{api}/{bits}/{shape}' for bits in [1,30,63,64,127,511,1023] for shape in ['distinct','square'] for api in ['public','parallel-public']];records={};identities=[];resources=[];partial=[];digestfull={};rawbind=[]
for fork in range(3):
 order='reverse' if fork==1 else 'forward';expected=ids[::-1] if fork==1 else ids
 for label,tree,mh in [('baseline',Path(a[2]),a[3]),('current',Path(a[4]),a[5])]:
  f=d/f'fork{fork}-{label}.log';t=f.read_text();ls=t.splitlines();assert Path(str(f)+'.exit').read_text()=='0\n';b=props(Path(str(f)+'.binding'));assert b['label']==label and b['source_manifest_sha256']==a[7] and b['artifact_manifest_sha256']==mh
  own=[x for x in ls if x.startswith('# OWN539 ')];assert len(own)==1 and b['identity']==own[0];m=re.fullmatch(r'# OWN539 pid=(\d+) start_epoch_ms=(\d+) max_heap=536870912 flags=\[-Xms256m, -Xmx512m, -XX:\+UseG1GC, -Dkrogu539.main=(.+), -Dkrogu539.probe=(.+)\]',own[0]);assert m and int(m[1])>0 and int(m[2])>0 and m[3]==str(tree/'main.jar') and m[4]==str(tree/'probe.jar');identities.append((int(m[1]),int(m[2])))
  assert Path(str(f)+'.argv.txt').read_text().splitlines()==['/usr/bin/time','-l',a[8],'-Xms256m','-Xmx512m','-XX:+UseG1GC','-Dkrogu539.main='+str(tree/'main.jar'),'-Dkrogu539.probe='+str(tree/'probe.jar'),'-cp',':'.join(str(tree/n) for n in (tree/'classpath.txt').read_text().splitlines()),'CalibrationLaunch539',f'public-small,{order},7,20']
  for cls,jar in [('MagnitudeMultiplication','main.jar'),('MultiplicationPolicy539','main.jar'),('MultiplicationCalibration539JvmMain','probe.jar'),('MultiplicationCampaign539','probe.jar')]:assert ls.count(f'# ORIGIN539 {cls}={tree/jar}')==1
  assert ls.count(f'# calibration539 platform=JVM BellSoft 25.0.4+9-LTS aarch64 mode=public-small order={order} cases=28')==1;assert [x for x in ls if x.startswith('PASS539')]==['PASS539,28,7']
  checks=[x.split(',') for x in ls if x.startswith('CHECK539')];assert checks==[['CHECK539',n,'PASS'] for n in expected]
  reps=[x.split(',') for x in ls if x.startswith('REP539')];assert len(reps)==28 and {x[1] for x in reps}==set(ids)
  for marker,n,v in reps:
   api,bits,shape=n.split('/');bits=int(bits);z=1 if bits==1 else (1<<(bits-1))+1;assert int(v)==z*(z if shape=='square' else z+2)
  groups={n:[] for n in ids};times=[x.split(',') for x in ls if x.startswith('TIME539')];assert len(times)==196 and [x[1] for x in times]==[n for n in expected for _ in range(7)]
  for x in times:
   assert len(x)==9;_,n,sample,count,wall,cpu,alloc,heap,digest=x;sample,count,wall,cpu,alloc=map(int,[sample,count,wall,cpu,alloc]);assert sample==len(groups[n]) and 0<=sample<7 and 1<=count<=8388608 and count&(count-1)==0 and wall>0 and cpu>=0 and alloc>=0;heap=None if heap=='NA' else int(heap);assert heap is None or heap>=0;int(digest);groups[n].append(dict(sample=sample,count=count,wall_ns=wall,cpu_ns=cpu,allocated_bytes=alloc,coarse_heap_bytes=heap,digest=digest))
  per={}
  for n,v in sorted(groups.items()):
   assert len(v)==7 and len({x['count'] for x in v})==len({x['digest'] for x in v})==1;per[n]=dict(wall_ns=st.median(x['wall_ns']/x['count'] for x in v),cpu_ns=st.median(x['cpu_ns']/x['count'] for x in v),caller_allocated_bytes=st.median(x['allocated_bytes']/x['count'] for x in v),cpu_available_samples=7,allocation_available_samples=7,samples=v)
   if v[0]['count']>=64:digestfull.setdefault(n,set()).add(v[0]['digest'])
   else:partial.append(dict(fork=fork,label=label,case=n))
  records[f'{fork}/{label}']=dict(pid=int(m[1]),start_epoch_ms=int(m[2]),cases=per);rss=int(re.search(r'^\s*(\d+)\s+maximum resident set size$',t,re.M)[1]);resources.append(dict(fork=fork,label=label,rss_bytes=rss));rawbind.append(dict(fork=fork,label=label,log_sha256=sha(f),binding_sha256=sha(Path(str(f)+'.binding')),pid=int(m[1]),start_epoch_ms=int(m[2])))
assert len(set(identities))==6 and all(len(v)==1 for v in digestfull.values());assert records==s['forks'] and rawbind==s['raw_bindings'] and partial==s['partial_ring_scope']
chron=[records[f'{f}/{lab}']['start_epoch_ms'] for f in range(3) for lab in (['current','baseline'] if f==1 else ['baseline','current'])];assert chron==sorted(chron) and len(set(chron))==6
cases=[]
for n in sorted(ids):
 base=[records[f'{f}/baseline']['cases'][n]['wall_ns'] for f in range(3)];current=[records[f'{f}/current']['cases'][n]['wall_ns'] for f in range(3)];ratios=[x/y for x,y in zip(current,base)];deltas=[x-y for x,y in zip(current,base)];z=dict(case=n,baseline_fork_wall_ns=base,current_fork_wall_ns=current,paired_ratios=ratios,paired_deltas_ns=deltas,median_paired_ratio=st.median(ratios),median_paired_delta_ns=st.median(deltas),investigate_15percent_AND_5ns=st.median(ratios)>1.15 and st.median(deltas)>5,all3_slower=min(ratios)>1,all3_faster=max(ratios)<1);cases.append(z)
assert cases==s['cases'];flags=[x['case'] for x in cases if x['investigate_15percent_AND_5ns']];assert flags==s['guard_flags'] and len(flags)==0
csvrows=list(csv.DictReader((r/'actual-public-jvm-paired-small-3-summary.csv').open()));assert len(csvrows)==28
for x,z in zip(csvrows,cases):
 assert x['case']==z['case'] and float(x['median_paired_ratio'])==z['median_paired_ratio'] and float(x['median_paired_delta_ns'])==z['median_paired_delta_ns'] and x['investigate_15percent_AND_5ns']==str(z['investigate_15percent_AND_5ns'])
 for i in range(3):assert float(x[f'pair{i}_ratio'])==z['paired_ratios'][i] and float(x[f'pair{i}_delta_ns'])==z['paired_deltas_ns'][i]
for line in Path(a[6]).read_text().splitlines():
 h,n=line.split('\t');assert sha(Path(n))==h
assert sha(Path(a[6]))==a[7] and sha(Path(a[8]))==a[9]
out={'status':'PASS_INDEPENDENT_PAIRED_DATA_ZERO_INVESTIGATION_FLAGS_NOT_ADOPTION','handle':98393,'source':'a2070e1e1e7a5c455f25319cd623618714fad921','source_files_verified':405,'summary_sha256':sha(r/'actual-public-jvm-paired-small-3-summary.json'),'TIME':1176,'REP':168,'CHECK':168,'fresh_pid_start':identities,'cases':cases,'guard_flags':flags,'whole_child_resources':resources,'partial_ring_scope':partial,'scope':'Independent all28 BOTHAPI offline polynomialREP, exactCHECK/time order,7stablecounts, fullrawpercase CPU/callerallocation/NA records and pairedstatistics match. Historical07910baseline separate fromcurrenta207. Flags are preregistered investigation triggers, not automatic rejection or noise waiver. Shared host not isolated; no continuous CPUoverlap/causal attribution claimed. Callerallocation not all-thread memory; wholechildRSS not peropownedpeak. Zero flags observed on fresh33Bcompact-shortcut current artifact; not universal guarantee or JIT-causality proof.'};p=r/'independent-actual-public-jvm-paired-small-3-raw-audit.json';p.write_text(json.dumps(out,indent=2)+'\n');print('PASS',sha(p));print('flags',flags);print('all3slower',sum(x['all3_slower'] for x in cases),'all3faster',sum(x['all3_faster'] for x in cases))
PY
```
