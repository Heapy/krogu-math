from pathlib import Path
import json,hashlib,shutil,subprocess
p=Path(__file__).resolve().parent;w=p/'worktree';commit='aa9ca6b9cab6d177ba62b188aa72a0f0fad1e2fa'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
source=p/'serial-retention-source.tsv'
for line in source.read_text().splitlines():
 h,path=line.split('\t');assert sha(Path(path))==h,path
log=p/'native-final-release-build-1.log';assert 'BUILD SUCCESSFUL' in log.read_text()
producer=w/'build/bin/macosArm64/calibration539ReleaseTest/calibration539.kexe';tree=p/'artifacts/native-release-aa9ca6b';tree.mkdir();exe=tree/'calibration539.kexe';shutil.copy2(producer,exe);h=sha(exe);assert h==sha(producer)
m=tree/'manifest.sha256';m.write_text(h+'\tcalibration539.kexe\n');runtime={cmd:subprocess.check_output([cmd,'-L',str(exe)] if cmd=='/usr/bin/otool' else [cmd,str(exe)] if cmd=='/usr/bin/file' else [cmd,'-a'] if cmd=='/usr/bin/uname' else [cmd],text=True) for cmd in ['/usr/bin/file','/usr/bin/otool','/usr/bin/sw_vers','/usr/bin/uname']}
b={'source':commit,'handle':7550,'exit_code':0,'source_files_post_match':405,'source_manifest_sha256':sha(source),'log_sha256':sha(log),'producer':str(producer),'executable':str(exe),'executable_sha256':h,'executable_bytes':exe.stat().st_size,'tree':str(tree),'manifest_sha256':sha(m),'runtime':runtime,'scope':'Final current Native selected distinct32/alias+unbalanced64/384/16, explicitparallelchildren64;11contracts/preregistered28/currentactualpublic pending.'}
ledger=p/'native-final-release-build-1-summary.json';ledger.write_text(json.dumps(b,indent=2)+'\n');old=json.loads((p/'selected-native-public-prelaunch.json').read_text());groups=[]
for i in [0,2,1]:
 g=old['groups'][i];a=g['argv'];repl={str(p/'artifacts/native-release-df733c0'):str(tree),'f2abd954e20fbfdc7d55eb9dc6aba369d1c543538669925ea972caeceb12bc11':sha(m),str(p/'selected-native-source.tsv'):str(source),'6c33dbb21fdb3c8f677460b628e117c2b478acb6b0fc78b9c3cfb1f749772139':sha(source),str(p/'artifacts/native-release-df733c0/calibration539.kexe'):str(exe),'08d5da47db5cfd162a75b8d5b49c5e2e3a5d14e139facd677792f2862c8c5797':h}
 if i==0:
  repl[a[1]]=str(p/'run-native-final-contracts.main.kts');repl[a[-1]]=str(p/'final-native-contracts-1');g.update(name='final-contracts11',methods=11)
 elif i==2:repl[a[-1]]=str(p/'actual-public-native-paired-small-3');g['name']='final-paired28'
 else:repl[a[-1]]=str(p/'actual-public-native-route-final-1');g['name']='final-actual-public'
 g['argv']=[repl.get(x,x) for x in a];g['launcher_sha256']=sha(Path(g['argv'][1]));assert not Path(g['argv'][-1]).exists()
 if i==2:
  g['post_checker_argv']=['/opt/homebrew/Cellar/python@3.15/3.15.0/Frameworks/Python.framework/Versions/3.15/bin/python3.15',str(p/'check-public-paired-guard.py'),g['argv'][-1],'Native',sha(source),a[3],sha(m),str(p/'actual-public-native-paired-small-3-summary')];g['post_checker_sha256']=sha(p/'check-public-paired-guard.py');g['preregistered_controls']='ordinarycompact30square andalias1023square unchanged;distinct1023 changedK32;all28retained'
 if i==1:
  g['post_checker_argv']=['/Users/yoda/.sdkman/candidates/kotlin/2.4.21/bin/kotlinr',str(p/'packaging/native-public-controller/check-native-public.main.kts'),g['argv'][-1]];g['post_checker_sha256']=sha(Path(g['post_checker_argv'][1]))
 groups.append(g)
(p/'native-final-three-groups-prelaunch.json').write_text(json.dumps({'source':commit,'source_files':405,'source_manifest':str(source),'source_manifest_sha256':sha(source),'build_summary':str(ledger),'build_summary_sha256':sha(ledger),'groups':groups},indent=2)+'\n');print(json.dumps(b,indent=2))
