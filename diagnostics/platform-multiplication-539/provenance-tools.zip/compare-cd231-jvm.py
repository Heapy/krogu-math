from pathlib import Path
import zipfile,subprocess,re,json,hashlib
p=Path(__file__).resolve().parent;out=p/'js-wasm-small-jvm-semantic-comparison';out.mkdir();old=p/'artifacts/jvm-actual-public-2d74b64/main.jar';new=p/'worktree/build/libs/krogu-math-jvm-0.1.0-SNAPSHOT.jar';javap='/Users/yoda/.sdkman/candidates/java/25.0.4-librca/bin/javap'
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
a=zipfile.ZipFile(old);b=zipfile.ZipFile(new);assert set(a.namelist())==set(b.namelist());changed=[n for n in a.namelist() if a.read(n)!=b.read(n)]
def dump(jar,cls):return subprocess.check_output([javap,'-c','-p','-classpath',str(jar),cls],text=True)
def methods(txt):
 starts=list(re.finditer(r'^  (?:public|private|protected|static).*\);?\s*$',txt,re.M));result={}
 for i,m in enumerate(starts):
  name=m.group().strip();part=txt[m.end():starts[i+1].start() if i+1<len(starts) else len(txt)]
  part=re.sub(r'#\d+','#CP',part);result[name]=part
 return result
reports=[]
for n in changed:
 assert n.endswith('.class'),n
 cls=n[:-6].replace('/','.');x=dump(old,cls);y=dump(new,cls)
 (out/(cls.rsplit('.',1)[-1]+'.old.javap.txt')).write_text(x);(out/(cls.rsplit('.',1)[-1]+'.current.javap.txt')).write_text(y)
 mx,my=methods(x),methods(y);assert mx.keys()==my.keys();delta=[k for k in mx if mx[k]!=my[k]]
 if cls.endswith('BigInteger'):
  assert len(delta)==1 and 'parallelMagnitudeSize539' in delta[0],delta
  assert 'new ' not in my[delta[0]] and 'arraylength' in my[delta[0]] and 'iconst_0' in my[delta[0]]
  public=[k for k in my if ' parallelMultiply(' in k][0];assert mx[public]==my[public]
  assert '25: areturn' in my[public]
  reports.append({'class':cls,'changed_methods':delta,'all_other_method_listings_equal':True,'public_wrapper_Code_bytes':26,'helper':'Single wideWords read; null -> primitive0; nonnull -> primitive arraylength; no allocation or backend/math call. Equivalent old helper also primitive on JVM, changed branch/register shape disclosed.'})
 elif cls.endswith('MagnitudeMultiplication'):
  assert len(delta)==1 and ' multiplyAdaptive(' in delta[0],delta
  def canon(s):return '\n'.join(re.sub(r'^\s*\d+:\s*','',l) for l in s.splitlines() if not re.match(r'^\s*\d+:\s*nop\s*$',l))
  assert canon(mx[delta[0]])==canon(my[delta[0]])
  reports.append({'class':cls,'all_other_methods_instruction_listings_equal':True,'multiplyAdaptive_only_delta':'One NOP from JSfalse branch; same method operands/checks/default384 invoke/return. No arithmetic/branch/invoke delta.'})
 else:
  assert not delta,(cls,delta)
  reports.append({'class':cls,'all_method_instruction_listings_equal':True,'class_byte_difference':'Constant pool/debug/compiler metadata; normalized javap retained instructions/offsets/operands except CP ordinals.'})
s={'source':'cd231a59c65ef3261f9379e106b436e17114b946','actual_producer':str(new),'producer_invocation_handle':71151,'producer_log_sha256':h(p/'js-wasm-small-focused-1.log'),'historical_runtime_source':'2d74b6467c449084d6c528cc26398c2ac93b0a3b','old_main_sha256':h(old),'current_main_sha256':h(new),'entries':len(a.namelist()),'exact_entry_names':True,'byte_equal_entries':len(a.namelist())-len(changed),'changed_classes':reports,'scope':'Scoped semantic carryforward only; old JVM ADOPT/guard2/route2 remain executed with historical2d74 jar. No byteidentity/JIT/performance recovery claim for changed classes.'};(out/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
