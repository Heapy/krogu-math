# Independent JVM parallel audit reproduction

Reanalyses retained logs, CSV and immutable input manifests only; no benchmark is launched. Full cold setup, steady pool reuse, process CPU, approximate all-thread allocation and pool-peak bounds remain separate.

```sh
python3 - <<'PY'
from pathlib import Path
import json,csv,re,hashlib,statistics as st,math
p=Path('.codex-work/539');d=p/'calibration-jvm-parallel-1';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
s=json.loads((p/'calibration-jvm-parallel-1-summary.json').read_text());pre=json.loads((p/'jvm-parallel-1-prelaunch.json').read_text());tree=Path(pre['argv'][2])
assert s['exit']==s['checker_exit']==0 and s['PAR']==1260 and s['cold']==90 and s['payload']==45
assert all(sha(p/f)==h for f,h in s['files'].items()) and sha(p/s['csv'])==s['csv_sha256']
shapes=[f'{n}/{shape}' for n in [256,1024,4096,8192,16384] for shape in ['distinct','square','ratio2']]
ids=[shape+'/'+route for shape in shapes for route in ['kernel','frame','worker1','worker2']]
allrows={};cold={};payload={};digests={};identities=[];envelopes=[]
for fork in range(3):
 f=d/f'fork{fork}.log';lines=f.read_text().splitlines();text='\n'.join(lines)
 assert Path(str(f)+'.exit').read_text().strip()=='0'
 binding=dict(x.split('=',1) for x in Path(str(f)+'.binding').read_text().splitlines())
 assert binding['source_manifest_sha256']==pre['argv'][5] and binding['artifact_manifest_sha256']==pre['argv'][3]
 header=next(x for x in lines if x.startswith('# parallel539 '));m=re.fullmatch(r'# parallel539 java=BellSoft 25.0.4\+9-LTS arch=aarch64 processors=(\d+) pid=(\d+) start_ms=(\d+) order=(forward|reverse)',header);assert m
 processors,pid,start,order=m.groups();assert int(processors)>2 and binding['pid']==pid and binding['start_epoch_ms']==start;assert order==('reverse' if fork==1 else 'forward')
 identities.append((pid,start));assert int(pid)>0 and int(start)>0
 assert f"# main={sha(tree/'main.jar')} probe={sha(tree/'probe.jar')} CPU=whole_process allocation=approx_all_threads heap_peak=sum_pool_peaks_upper_bound RSS=external_including_reference_preparation" in lines
 assert '# setup_rows=one_fresh_executor_plus_first_product_shutdown_and_await_termination; steady_rows=reused_warm_executor' in lines
 assert lines.count('PASS_PAR539,artifact_recheck')==1 and not any(x.startswith('INELIGIBLE539,') for x in lines)
 check=[x.split(',')[1] for x in lines if x.startswith('CHECKPAR539,')];assert check==(list(reversed(ids)) if fork==1 else ids)
 argv=Path(str(f)+'.argv.txt').read_text().splitlines();assert argv[:6]==['/usr/bin/time','-l',pre['argv'][6],'-Xms256m','-Xmx512m','-XX:+UseG1GC']
 assert argv[6]=='-cp' and argv[7].split(':')==[str(tree/n) for n in (tree/'classpath.txt').read_text().splitlines()]
 assert argv[8:]==['io.heapy.krogu.math.ParallelCalibration539JvmMain',order,'7',str(tree/'main.jar'),sha(tree/'main.jar'),str(tree/'probe.jar'),sha(tree/'probe.jar')]
 rr=list(csv.reader(x for x in lines if x.startswith('PAR539,')));assert len(rr)==420;groups={}
 for row in rr:
  assert len(row)==9;_,name,sample,count,wall,cpu,allocated,peak,digest=row;assert name in ids
  sample,count,wall,cpu,allocated,peak,digest=map(int,[sample,count,wall,cpu,allocated,peak,digest])
  assert sample in range(7) and 1<=count<=1048576 and count&(count-1)==0 and 0<wall<=60_000_000_000
  assert min(cpu,allocated,peak)>=0 and -(2**31)<=digest<2**31
  groups.setdefault(name,[]).append(dict(sample=sample,count=count,wall=wall,cpu=cpu,allocated=allocated,peak=peak,digest=digest))
 assert set(groups)==set(ids)
 for name,g in groups.items():
  assert len(g)==7 and {x['sample'] for x in g}==set(range(7)) and len({x['count'] for x in g})==1
  digests.setdefault(name,set()).update(x['digest'] for x in g);assert len(digests[name])==1
 allrows[fork]=groups
 cr=list(csv.reader(x for x in lines if x.startswith('SETUP539,')));assert len(cr)==30
 assert {x[1] for x in cr}=={x for x in ids if '/worker' in x}
 for row in cr:
  assert len(row)==6;_,name,wall,cpu,allocated,peak=row;v=list(map(int,[wall,cpu,allocated,peak]));assert 0<v[0]<=60_000_000_000 and min(v[1:])>=0
  cold[(fork,name)]=dict(zip(['wall','cpu','allocated','peak'],v))
 pr=list(csv.reader(x for x in lines if x.startswith('PAYLOAD539,')));assert len(pr)==15 and {x[1] for x in pr}==set(shapes)
 for _,name,words,scope in pr:
  assert scope=='words_excludes_headers_scheduler_inputs' and int(words)>0
  payload.setdefault(name,set()).add(int(words))
 rss=re.search(r'^\s*(\d+)\s+maximum resident set size$',text,re.M);foot=re.search(r'^\s*(\d+)\s+peak memory footprint$',text,re.M);assert rss and foot
 envelopes.append(dict(fork=fork,whole_process_rss_bytes=int(rss[1]),whole_process_peak_footprint_bytes=int(foot[1])))
assert len(set(identities))==3 and all(len(x)==1 for x in payload.values())
for shape in shapes:assert len({next(iter(digests[shape+'/'+route])) for route in ['kernel','frame','worker1','worker2']})==1
results=[]
for name in sorted(ids):
 gs=[allrows[i][name] for i in range(3)];wall=[st.median(x['wall']/x['count'] for x in g) for g in gs];cpu=[st.median(x['cpu']/x['count'] for x in g) for g in gs];alloc=[st.median(x['allocated']/x['count'] for x in g) for g in gs]
 results.append({'case':name,'wall_median_ns':st.median(wall),'wall_min_process_median_ns':min(wall),'wall_max_process_median_ns':max(wall),'cpu_median_ns':st.median(cpu),'approx_all_thread_bytes_median':st.median(alloc),'heap_pool_peak_upper_bound_bytes':max(x['peak'] for g in gs for x in g),'fork_wall_ns':wall,'fork_cpu_ns':cpu,'fork_approx_all_thread_bytes':alloc})
owner=list(csv.DictReader((p/s['csv']).open()));assert len(owner)==60
for a,b in zip(owner,results):
 assert a['case']==b['case']
 for k in ['wall_median_ns','wall_min_process_median_ns','wall_max_process_median_ns','cpu_median_ns','approx_all_thread_bytes_median','heap_pool_peak_upper_bound_bytes']:assert math.isclose(float(a[k]),b[k],rel_tol=1e-14,abs_tol=1e-9),(a['case'],k)
byid={x['case']:x for x in results};comparisons=[];setup=[]
for shape in shapes:
 serial=[min(['kernel','frame'],key=lambda route:byid[shape+'/'+route]['fork_wall_ns'][i]) for i in range(3)]
 for worker in ['worker1','worker2']:
  c=byid[shape+'/'+worker];base=[byid[shape+'/'+serial[i]] for i in range(3)];rat=[c['fork_wall_ns'][i]/base[i]['fork_wall_ns'][i] for i in range(3)]
  comparisons.append({'case':shape+'/'+worker,'serial_comparator_per_fork':serial,'paired_wall_ratios':rat,'median_paired_wall_ratio':st.median(rat),'all3_faster':max(rat)<1,'all3_slower':min(rat)>1,'frozen_parallel_margin_pass':st.median(rat)<=.8 and max(rat)<=.9,'paired_CPU_ratios':[c['fork_cpu_ns'][i]/base[i]['fork_cpu_ns'][i] for i in range(3)],'paired_approx_all_thread_allocation_delta_bytes':[c['fork_approx_all_thread_bytes'][i]-base[i]['fork_approx_all_thread_bytes'][i] for i in range(3)]})
  cc=[cold[(i,shape+'/'+worker)] for i in range(3)]
  setup.append({'case':shape+'/'+worker,'full_cold_wall_ns_median':st.median(x['wall'] for x in cc),'full_cold_wall_ns_range':[min(x['wall'] for x in cc),max(x['wall'] for x in cc)],'full_cold_process_CPU_ns_median':st.median(x['cpu'] for x in cc),'full_cold_approx_all_thread_allocated_bytes_median':st.median(x['allocated'] for x in cc),'full_cold_pool_peak_upper_bound_max':max(x['peak'] for x in cc),'raw_forks':cc})
adjacent=[]
for shape in ['distinct','square','ratio2']:
 for worker in ['worker1','worker2']:
  points=[x for x in comparisons if x['case'].endswith('/'+shape+'/'+worker)];points.sort(key=lambda x:int(x['case'].split('/')[0]))
  for a,b in zip(points,points[1:]):
   if a['frozen_parallel_margin_pass'] and b['frozen_parallel_margin_pass']:adjacent.append(dict(shape=shape,worker=worker,sizes=[int(a['case'].split('/')[0]),int(b['case'].split('/')[0])]))
for h,f in [line.split('\t') for line in Path(pre['argv'][4]).read_text().splitlines()]:assert sha(Path(f))==h
assert all(sha(Path(f))==h for f,h in pre['runtime_files'].items())
for h,f in [line.split('\t') for line in (tree/'manifest.sha256').read_text().splitlines()]:assert sha(tree/f)==h
r={'status':'INDEPENDENT_JVM_PARALLEL_RAW_BINDING_STATS_FULL_COLD_PASS_NOT_ADOPTED','handle':17831,'strict_checker_handle':78015,'source':s['source'],'PAR':1260,'full_cold_SETUP':90,'PAYLOAD':45,'cases':60,'fresh_process_identities':identities,'source_files_verified':378,'all_owner_CSV_stats_exact':True,'all_result_digests_sample_fork_route_equal':True,'per_case':results,'worker_vs_faster_observed_serial':comparisons,'two_adjacent_frozen_margin_eligibility':adjacent,'full_cold_setup':setup,'logical_payload_words':{k:next(iter(v)) for k,v in payload.items()},'whole_process_envelopes':envelopes,'scope':'Actual3freshF/R/F JVMprototype processes. Frozenparallel latencymargin eligibility only, NOT publicadoption: currentpublicserial comparator where distinct, resourcecostjudgment andfinalselectedfrontend/guards remain. ColdSETUP includes construct/firstproduct/shutdown/await but not coldwholeJVM; steady reusesactualownedpool. AllocationapproxALLthreads includesruntime/background, poolpeak sumupperbound andwholeprocessRSS notexactperoperationownedmemory. No otherplatform or universalcrossoverclaim.'}
(p/'independent-jvm-parallel-1-raw-audit.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS1260PAR90fullcold45payload/60CSV/freshidentity/hash/sourcebindings')
print('FROZENadjacent',adjacent)
print('ALL3faster/slower',sum(x['all3_faster'] for x in comparisons),sum(x['all3_slower'] for x in comparisons))
print('LARGEST',[(x['case'],round(x['median_paired_wall_ratio'],3),[round(v,3) for v in x['paired_wall_ratios']],[round(v,3) for v in x['paired_CPU_ratios']]) for x in comparisons if x['case'].startswith('16384/')])
PY
```
