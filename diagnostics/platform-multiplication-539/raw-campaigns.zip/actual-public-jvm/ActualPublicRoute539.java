import io.heapy.krogu.math.BigInteger;
import io.heapy.krogu.math.MagnitudeMultiplication;
import io.heapy.krogu.math.MultiplicationPolicy539;
import java.lang.management.ManagementFactory;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.*;
import java.util.function.Supplier;

/** External actual public-route probe. No copied numerical algorithm. */
public final class ActualPublicRoute539 {
  static volatile Object last;
  static final Object[] ring = new Object[64];
  static final com.sun.management.ThreadMXBean threads =
      (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
  static final com.sun.management.OperatingSystemMXBean os =
      (com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
  static long cpu() { return os.getProcessCpuTime(); }
  static long ownedWorkers() {
    return Arrays.stream(threads.getThreadInfo(threads.getAllThreadIds()))
        .filter(Objects::nonNull).filter(t -> t.getThreadName().startsWith("krogu-multiply-539-")).count();
  }
  static Map<Long, Long> allocated() {
    var out = new HashMap<Long, Long>();
    for (long id : threads.getAllThreadIds()) {
      long n = threads.getThreadAllocatedBytes(id); if (n >= 0) out.put(id, n);
    }
    return out;
  }
  static long allocation(Map<Long, Long> before, Map<Long, Long> after) {
    long n = 0; for (var e : after.entrySet()) n += Math.max(0, e.getValue() - before.getOrDefault(e.getKey(), 0L));
    return n; // all live threads approximation; terminated-thread allocations can be missed
  }
  static String sha(Path p) throws Exception {
    return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(java.nio.file.Files.readAllBytes(p)));
  }
  static void origin(Class<?> type, String wanted) throws Exception {
    var path = Path.of(type.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath();
    if (!sha(path).equals(wanted)) throw new AssertionError("Wrong production origin: " + type);
    System.out.println("ORIGINPUBLIC539," + type.getName() + "," + path + "," + wanted);
  }
  static byte[] packed(int[] words) {
    var out = new byte[(words.length * 30 + 7) / 8];
    for (int i = 0; i < words.length; i++) for (int bit = 0; bit < 30; bit++)
      if ((words[i] & (1 << bit)) != 0) { int at = i * 30 + bit; out[out.length - 1 - at / 8] |= (byte)(1 << (at % 8)); }
    return out;
  }
  static int[] words(java.math.BigInteger n) {
    var out = new int[(n.bitLength() + 29) / 30];
    for (int i = 0; i < out.length; i++) { out[i] = n.intValue() & 0x3fffffff; n = n.shiftRight(30); }
    return out;
  }
  static void verify(Object product, java.math.BigInteger expected, int[] expectedWords) {
    if (product instanceof BigInteger n) {
      if (!Arrays.equals(n.toByteArray(), expected.toByteArray())) throw new AssertionError("Public product");
    } else if (product instanceof int[] n) {
      int length = n.length; while (length > 0 && n[length - 1] == 0) length--;
      if (!Arrays.equals(Arrays.copyOf(n, length), expectedWords)) throw new AssertionError("Kernel product");
    } else throw new AssertionError("Wrong output type");
  }
  record Metrics(long wall, long cpu, long allocation, Object result) {}
  static Metrics observe(int count, Supplier<Object> operation) {
    var before = allocated(); long c0 = cpu(); long t0 = System.nanoTime();
    for (int i = 0; i < count; i++) ring[i & 63] = operation.get();
    last = ring[(count - 1) & 63];
    long wall = System.nanoTime() - t0; long c = cpu() - c0;
    var after = allocated(); return new Metrics(wall, c, allocation(before, after), last);
  }
  public static void main(String[] args) throws Exception {
    if (args.length != 6) throw new IllegalArgumentException("size shape forward|reverse samples productionJarSHA harnessJarSHA");
    int size = Integer.parseInt(args[0]), samples = Integer.parseInt(args[3]);
    if (!Set.of(256, 1024, 4096, 8192, 16384).contains(size) || samples != 7) throw new AssertionError();
    String shape = args[1], order = args[2];
    if (!Set.of("distinct", "square", "ratio2").contains(shape) || !Set.of("forward", "reverse").contains(order)) throw new AssertionError();
    if (!threads.isThreadAllocatedMemorySupported()) throw new AssertionError("No all-thread allocation counter");
    threads.setThreadAllocatedMemoryEnabled(true);
    origin(ActualPublicRoute539.class, args[5]); origin(BigInteger.class, args[4]); origin(MagnitudeMultiplication.class, args[4]); origin(MultiplicationPolicy539.class, args[4]);
    var bean = ManagementFactory.getRuntimeMXBean();
    System.out.println("METAPUBLIC539,pid=" + ProcessHandle.current().pid() + ",start=" + bean.getStartTime() + ",flags=" + bean.getInputArguments());
    System.out.println("SCOPEPUBLIC539,one fresh process per point;first actual parallelMultiply after inputs/JDK preparation;no prototype pool shutdown;warm reused defining-classloader pool;allthread allocation approximation;wholeprocess CPU/RSS");
    int[] a = new int[size]; for (int i = 0; i < size; i++) a[i] = (i * 104729 + 31) & 0x3fffffff;
    int[] b = shape.equals("square") ? a : Arrays.copyOf(a, shape.equals("ratio2") ? Math.max(1, size / 2) : size);
    var beforeA = a.clone(); var beforeB = b.clone();
    byte[] bytesA = packed(a), bytesB = packed(b);
    BigInteger left = new BigInteger(1, bytesA), right = shape.equals("square") ? left : new BigInteger(1, bytesB);
    var expected = new java.math.BigInteger(1, bytesA).multiply(new java.math.BigInteger(1, bytesB));
    byte[] canonicalA = left.toByteArray(), canonicalB = right.toByteArray();
    var expectedWords = words(expected); var policy = new MultiplicationPolicy539(64, 16, 384);
    // No production multiply, frame or worker call before this actual first invocation.
    long workersBefore = ownedWorkers();
    if (workersBefore != 0) throw new AssertionError("First invocation already has a pool");
    Metrics first = observe(1, () -> left.parallelMultiply(right));
    verify(first.result(), expected, expectedWords);
    long workersAfter = ownedWorkers();
    boolean eligible = Math.min(a.length, b.length) >= 4096 && Runtime.getRuntime().availableProcessors() > 2;
    if (eligible ? workersAfter < 1 || workersAfter > 2 : workersAfter != 0) throw new AssertionError("Actual route activity");
    System.out.println("ACTIVITYPUBLIC539,eligible=" + eligible + ",owned_before=" + workersBefore + ",owned_after_first=" + workersAfter);
    System.out.println("FIRSTPUBLIC539," + size + "/" + shape + "," + first.wall() + "," + first.cpu() + "," + first.allocation());
    var variants = new ArrayList<>(List.of("kernel", "frame", "public", "parallel"));
    if (order.equals("reverse")) Collections.reverse(variants);
    for (String variant : variants) {
      Supplier<Object> operation = switch (variant) {
        case "kernel" -> () -> MagnitudeMultiplication.INSTANCE.multiplyConfigured539(a, b, policy);
        case "frame" -> () -> {
          var f = MagnitudeMultiplication.INSTANCE.prepareParallel539(a, b, policy);
          if (f == null) throw new AssertionError();
          return f.combine(f.child(0), f.child(1), f.child(2));
        };
        case "public" -> () -> left.multiply(right);
        default -> () -> left.parallelMultiply(right);
      };
      verify(operation.get(), expected, expectedWords);
      long warmUntil = System.nanoTime() + 200_000_000L;
      do { last = operation.get(); } while (System.nanoTime() < warmUntil);
      int count = 1;
      while (observe(count, operation).wall() < 20_000_000L && count < (1 << 20)) count *= 2;
      for (int sample = 0; sample < samples; sample++) {
        Metrics m = observe(count, operation);
        verify(m.result(), expected, expectedWords);
        if (!Arrays.equals(a, beforeA) || !Arrays.equals(b, beforeB) || !Arrays.equals(left.toByteArray(), canonicalA) || !Arrays.equals(right.toByteArray(), canonicalB)) throw new AssertionError("Input mutation");
        System.out.println("WARM_PUBLIC539," + size + "/" + shape + "/" + variant + "," + sample + "," + count + "," + m.wall() + "," + m.cpu() + "," + m.allocation());
      }
    }
    System.out.println("RESOURCEPUBLIC539,processors=" + Runtime.getRuntime().availableProcessors() + ",peak_threads_all=" + threads.getPeakThreadCount() + ",live_threads_all=" + threads.getThreadCount() + ",heap_used=" + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()));
    System.out.println("PASS_ACTUAL_PUBLIC539");
  }
}
