// SPDX-License-Identifier: Apache-2.0
package io.heapy.krogu.math
import kotlin.test.Test
import kotlin.test.assertEquals

private class IntegralResult(text: String, val trace: StringBuilder) : BigDecimal(text) {
    override fun precision(): Int { trace.append("Q.precision;"); return super.precision() }
    override fun scale(): Int { trace.append("Q.scale;"); return super.scale() }
    override fun signum(): Int { trace.append("Q.sign;"); return super.signum() }
    override fun setScale(n: Int, mode: RoundingMode): BigDecimal {
        trace.append("Q.set($n,$mode);"); return super.setScale(n, mode)
    }
    override fun setScale(n: Int, mode: Int): BigDecimal {
        trace.append("Q.setInt($n,$mode);"); return super.setScale(n, mode)
    }
    override fun setScale(n: Int): BigDecimal { trace.append("Q.set($n);"); return super.setScale(n) }
    override fun stripTrailingZeros(): BigDecimal { trace.append("Q.strip;"); return super.stripTrailingZeros() }
}
private class IntegralSource(text: String, val label: String, val mode: String, val trace: StringBuilder) : BigDecimal(text) {
    override fun precision(): Int { trace.append("$label.precision;"); return super.precision() }
    override fun scale(): Int { trace.append("$label.scale;"); return super.scale() }
    override fun signum(): Int { trace.append("$label.sign;"); return super.signum() }
    override fun abs(): BigDecimal { trace.append("$label.abs;"); return super.abs() }
    override fun compareTo(v: BigDecimal): Int { trace.append("$label.compare;"); return super.compareTo(v) }
    override fun subtract(v: BigDecimal): BigDecimal { trace.append("$label.subtract;"); return super.subtract(v) }
    override fun divideToIntegralValue(v: BigDecimal): BigDecimal {
        trace.append("$label.integral;"); return super.divideToIntegralValue(v)
    }
    override fun divide(v: BigDecimal, mc: MathContext): BigDecimal {
        val context = mc
        trace.append("$label.divide(${context.precision},${context.roundingMode});")
        if (mode == "throw") throw IllegalStateException("divide callback")
        return if (mode == "source") this else IntegralResult(mode, trace)
    }
    fun enter(v: BigDecimal, p: Int): BigDecimal = if (p < 0) super.divideToIntegralValue(v)
        else super.divideToIntegralValue(v, MathContext(p, RoundingMode.UNNECESSARY))
}
private fun integralOutcome(a: String, b: String, p: Int, mode: String, observe: ((BigDecimal) -> Unit)? = null): String {
    val trace = StringBuilder()
    val source = IntegralSource(a, "A", mode, trace)
    val operand = IntegralSource(b, "B", mode, trace)
    return try {
        val result = source.enter(operand, p)
        val calls = trace.toString()
        val diagnostic = "${result.toString()}:${result.scale()}:${when { result === source -> "source"; result === operand -> "divisor"; result is IntegralResult -> "quotient"; else -> "base" }}|$calls"
        observe?.invoke(result)
        diagnostic
    } catch (e: Exception) { "!${e::class.simpleName}:${e.message}|$trace" }
}
private class IntegralMetadata(text: String, val label: String, val digits: Int, val reportedScale: Int, val trace: StringBuilder) : BigDecimal(text) {
    override fun signum(): Int { trace.append("$label.sign;"); return super.signum() }
    override fun precision(): Int { trace.append("$label.precision;"); return digits }
    override fun scale(): Int { trace.append("$label.scale;"); return reportedScale }
    override fun divide(v: BigDecimal, mc: MathContext): BigDecimal {
        val context = mc
        trace.append("$label.divide(${context.precision},${context.roundingMode});")
        throw IllegalStateException("divide callback")
    }
}
private fun metadataOutcome(a: Int, b: Int, aScale: Int, bScale: Int, observe: ((BigDecimal) -> Unit)? = null): String {
    val trace = StringBuilder()
    val source = IntegralMetadata("10.0", "A", a, aScale, trace)
    val divisor = IntegralMetadata("2.0", "B", b, bScale, trace)
    return try {
        val result = source.divideToIntegralValue(divisor)
        val diagnostic = result.toString() + "|$trace"
        observe?.invoke(result)
        diagnostic
    }
        catch (e: Exception) { "!${e::class.simpleName}:${e.message}|$trace" }
}
class DecimalIntegralDispatchOracleTest {
    @Test fun signedMetadataAndScaleEndpointsDetermineContextPrecision() {
        val failures = mutableListOf<String>()
        val rows = jdk25DecimalIntegralMetadataCases()
        DecimalIntegral582DiagnosticPolicy.bindMetadata(rows)
        var selected = 0
        for ((ordinal, row) in rows.withIndex()) {
            val policy = DecimalIntegral582DiagnosticPolicy.metadataSelected(row)
            var observed: DecimalIntegral582DiagnosticPolicy.Numeric? = null
            val observer: ((BigDecimal) -> Unit)? = if (policy) ({ result ->
                observed = DecimalIntegral582DiagnosticPolicy.Numeric(result.unscaledValue().toString(), result.scale(), result.toString())
            }) else null
            val actual = metadataOutcome(row[0].toInt(), row[1].toInt(), row[2].toInt(), row[3].toInt(), observer)
            if (policy) {
                selected++
                DecimalIntegral582DiagnosticPolicy.numericFailure("metadata", ordinal, row, actual, observed,
                    DecimalIntegral582DiagnosticPolicy.expected("10.0", "2.0"))?.let { failures += it }
            } else if (row[4] != actual) failures += row.take(4).toString() + " expected=" + row[4] + " actual=" + actual
        }
        assertEquals(1, selected)
        assertEquals(emptyList<String>(), failures.take(12), failures.size.toString() + " mismatches")
    }
    @Test fun inheritedIntegralDivisionUsesVirtualContextDivision() {
        val failures = mutableListOf<String>()
        val rows = jdk25DecimalIntegralDispatchCases()
        DecimalIntegral582DiagnosticPolicy.bindDispatch(rows)
        var selected = 0
        for ((ordinal, row) in rows.withIndex()) {
            val policy = DecimalIntegral582DiagnosticPolicy.dispatchSelected(row)
            var observed: DecimalIntegral582DiagnosticPolicy.Numeric? = null
            val observer: ((BigDecimal) -> Unit)? = if (policy) ({ result ->
                observed = DecimalIntegral582DiagnosticPolicy.Numeric(result.unscaledValue().toString(), result.scale(), result.toString())
            }) else null
            val actual = integralOutcome(row[0], row[1], row[2].toInt(), row[3], observer)
            if (policy) {
                selected++
                DecimalIntegral582DiagnosticPolicy.numericFailure("dispatch", ordinal, row, actual, observed,
                    DecimalIntegral582DiagnosticPolicy.expected(row[0], row[1]))?.let { failures += it }
            } else if (row[4] != actual) failures += row.take(4).toString() + " expected=" + row[4] + " actual=" + actual
        }
        assertEquals(420, selected)
        assertEquals(emptyList<String>(), failures.take(12), failures.size.toString() + " mismatches")
    }
}
