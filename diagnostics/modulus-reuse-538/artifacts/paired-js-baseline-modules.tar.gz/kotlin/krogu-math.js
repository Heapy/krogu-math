(function (factory) {
  if (typeof define === 'function' && define.amd)
    define(['exports', './kotlin-kotlin-stdlib.js'], factory);
  else if (typeof exports === 'object')
    factory(module.exports, require('./kotlin-kotlin-stdlib.js'));
  else {
    if (typeof globalThis['kotlin-kotlin-stdlib'] === 'undefined') {
      throw new Error("Error loading module 'krogu-math'. Its dependency 'kotlin-kotlin-stdlib' was not found. Please, check whether 'kotlin-kotlin-stdlib' is loaded prior to 'krogu-math'.");
    }
    globalThis['krogu-math'] = factory(typeof globalThis['krogu-math'] === 'undefined' ? {} : globalThis['krogu-math'], globalThis['kotlin-kotlin-stdlib']);
  }
}(function (_, kotlin_kotlin) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var clz32 = Math.clz32;
  var compareTo = kotlin_kotlin.$_$.n5;
  var fromInt = kotlin_kotlin.$_$.x4;
  var subtract = kotlin_kotlin.$_$.e5;
  var add = kotlin_kotlin.$_$.o4;
  var Long = kotlin_kotlin.$_$.t9;
  var compare = kotlin_kotlin.$_$.r4;
  var charSequenceLength = kotlin_kotlin.$_$.m5;
  var NumberFormatException_init_$Create$ = kotlin_kotlin.$_$.p1;
  var charCodeAt = kotlin_kotlin.$_$.k5;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.b;
  var StringBuilder_init_$Create$ = kotlin_kotlin.$_$.f1;
  var digitToIntOrNull = kotlin_kotlin.$_$.s7;
  var Char__toInt_impl_vasixd = kotlin_kotlin.$_$.h;
  var numberToChar = kotlin_kotlin.$_$.j6;
  var get_ONE = kotlin_kotlin.$_$.n4;
  var multiply = kotlin_kotlin.$_$.z4;
  var convertToInt = kotlin_kotlin.$_$.t4;
  var isFinite = kotlin_kotlin.$_$.ja;
  var toBits = kotlin_kotlin.$_$.pa;
  var shiftRightUnsigned = kotlin_kotlin.$_$.d5;
  var bitwiseAnd = kotlin_kotlin.$_$.p4;
  var bitwiseOr = kotlin_kotlin.$_$.q4;
  var countTrailingZeroBits = kotlin_kotlin.$_$.ga;
  var ArithmeticException_init_$Create$ = kotlin_kotlin.$_$.g1;
  var equalsLong = kotlin_kotlin.$_$.w4;
  var coerceIn = kotlin_kotlin.$_$.z6;
  var repeat = kotlin_kotlin.$_$.h8;
  var divide = kotlin_kotlin.$_$.v4;
  var modulo = kotlin_kotlin.$_$.y4;
  var negate = kotlin_kotlin.$_$.a5;
  var equals = kotlin_kotlin.$_$.r5;
  var getKClassFromExpression = kotlin_kotlin.$_$.e7;
  var getKClass = kotlin_kotlin.$_$.f7;
  var noWhenBranchMatchedException = kotlin_kotlin.$_$.na;
  var protoOf = kotlin_kotlin.$_$.o6;
  var objectCreate = kotlin_kotlin.$_$.n6;
  var abs = kotlin_kotlin.$_$.t6;
  var Unit_getInstance = kotlin_kotlin.$_$.w;
  var coerceAtMost = kotlin_kotlin.$_$.y6;
  var VOID = kotlin_kotlin.$_$.a;
  var to = kotlin_kotlin.$_$.ta;
  var padEnd = kotlin_kotlin.$_$.f8;
  var ensureNotNull = kotlin_kotlin.$_$.ia;
  var toString = kotlin_kotlin.$_$.i;
  var substring = kotlin_kotlin.$_$.r8;
  var substring_0 = kotlin_kotlin.$_$.s8;
  var toNumber = kotlin_kotlin.$_$.f5;
  var numberToLong = kotlin_kotlin.$_$.b5;
  var initMetadataForCompanion = kotlin_kotlin.$_$.z5;
  var Number_0 = kotlin_kotlin.$_$.w9;
  var ArithmeticException = kotlin_kotlin.$_$.j9;
  var THROW_CCE = kotlin_kotlin.$_$.y9;
  var toByte = kotlin_kotlin.$_$.p6;
  var toShort = kotlin_kotlin.$_$.q6;
  var convertToShort = kotlin_kotlin.$_$.u4;
  var convertToByte = kotlin_kotlin.$_$.s4;
  var Comparable = kotlin_kotlin.$_$.m9;
  var initMetadataForClass = kotlin_kotlin.$_$.y5;
  var get_lastIndex = kotlin_kotlin.$_$.y2;
  var fill = kotlin_kotlin.$_$.l2;
  var arrayCopy = kotlin_kotlin.$_$.u1;
  var shiftLeft = kotlin_kotlin.$_$.c5;
  var toString_0 = kotlin_kotlin.$_$.r6;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.j1;
  var indexOf = kotlin_kotlin.$_$.a8;
  var IndexOutOfBoundsException_init_$Create$ = kotlin_kotlin.$_$.n1;
  var copyOf = kotlin_kotlin.$_$.e2;
  var lastOrNull = kotlin_kotlin.$_$.b3;
  var last = kotlin_kotlin.$_$.e3;
  var NullPointerException_init_$Create$ = kotlin_kotlin.$_$.o1;
  var countTrailingZeroBits_0 = kotlin_kotlin.$_$.fa;
  var Default_getInstance = kotlin_kotlin.$_$.t;
  var StringBuilder_init_$Create$_0 = kotlin_kotlin.$_$.e1;
  var _ULong___init__impl__c78o9k = kotlin_kotlin.$_$.o;
  var _ULong___get_data__impl__fggpzb = kotlin_kotlin.$_$.p;
  var ULong = kotlin_kotlin.$_$.ba;
  var countOneBits = kotlin_kotlin.$_$.ea;
  var contentEquals = kotlin_kotlin.$_$.z1;
  var until = kotlin_kotlin.$_$.c7;
  var Collection = kotlin_kotlin.$_$.r1;
  var isInterface = kotlin_kotlin.$_$.f6;
  var IllegalStateException_init_$Create$ = kotlin_kotlin.$_$.l1;
  var get_lastIndex_0 = kotlin_kotlin.$_$.z2;
  var initMetadataForObject = kotlin_kotlin.$_$.c6;
  var removePrefix = kotlin_kotlin.$_$.g8;
  var getStringHashCode = kotlin_kotlin.$_$.w5;
  var Char__compareTo_impl_ypi4mb = kotlin_kotlin.$_$.c;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.y;
  var digitToInt = kotlin_kotlin.$_$.t7;
  var copyOfRange = kotlin_kotlin.$_$.d2;
  var numberRangeToNumber = kotlin_kotlin.$_$.h6;
  var ClosedRange = kotlin_kotlin.$_$.w6;
  var contains = kotlin_kotlin.$_$.b7;
  var contains_0 = kotlin_kotlin.$_$.r7;
  var DoubleCompanionObject_getInstance = kotlin_kotlin.$_$.r;
  var doubleFromBits = kotlin_kotlin.$_$.q5;
  var take = kotlin_kotlin.$_$.u8;
  var listOf = kotlin_kotlin.$_$.g3;
  var toString_1 = kotlin_kotlin.$_$.sa;
  var hashCode = kotlin_kotlin.$_$.x5;
  var initMetadataForInterface = kotlin_kotlin.$_$.a6;
  var toBits_0 = kotlin_kotlin.$_$.oa;
  var startsWith = kotlin_kotlin.$_$.l8;
  var startsWith_0 = kotlin_kotlin.$_$.m8;
  var IllegalArgumentException = kotlin_kotlin.$_$.q9;
  var numberToByte = kotlin_kotlin.$_$.i6;
  var numberToShort = kotlin_kotlin.$_$.m6;
  var numberToInt = kotlin_kotlin.$_$.l6;
  var numberToDouble = kotlin_kotlin.$_$.k6;
  var _UInt___get_data__impl__f0vqqw = kotlin_kotlin.$_$.n;
  var ULong__toString_impl_f9au7k = kotlin_kotlin.$_$.q;
  var Random = kotlin_kotlin.$_$.v6;
  var Companion_getInstance = kotlin_kotlin.$_$.u;
  var getOrNull = kotlin_kotlin.$_$.q2;
  var THROW_IAE = kotlin_kotlin.$_$.z9;
  var enumEntries = kotlin_kotlin.$_$.k4;
  var Enum = kotlin_kotlin.$_$.n9;
  var NumberFormatException = kotlin_kotlin.$_$.v9;
  var Error_init_$Create$ = kotlin_kotlin.$_$.i1;
  var IndexOutOfBoundsException = kotlin_kotlin.$_$.s9;
  var IndexOutOfBoundsException_init_$Init$ = kotlin_kotlin.$_$.m1;
  var captureStack = kotlin_kotlin.$_$.h5;
  //endregion
  //region block: pre-declaration
  initMetadataForCompanion(Companion);
  initMetadataForInterface(MathSerializable, 'MathSerializable');
  initMetadataForClass(BigDecimal, 'BigDecimal', VOID, Number_0, [Comparable, MathSerializable]);
  initMetadataForClass(Workspace, 'Workspace');
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(OddModulusContext, 'OddModulusContext');
  initMetadataForClass(DecimalBinaryPrefix, 'DecimalBinaryPrefix');
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(BigInteger, 'BigInteger', VOID, Number_0, [Comparable, MathSerializable]);
  initMetadataForClass(IntegerView583, 'IntegerView583');
  initMetadataForClass(Cells, 'Cells');
  initMetadataForClass(DecimalWords, 'DecimalWords');
  initMetadataForObject(DecimalDivision581, 'DecimalDivision581');
  initMetadataForClass(DecimalKey, 'DecimalKey', VOID, VOID, [Comparable]);
  initMetadataForCompanion(Companion_2);
  initMetadataForClass(State, 'State');
  initMetadataForClass(Pages, 'Pages');
  initMetadataForClass(Words, 'Words');
  initMetadataForObject(DecimalPower593, 'DecimalPower593');
  initMetadataForClass(Cells_0, 'Cells');
  initMetadataForClass(DecimalWords_0, 'DecimalWords');
  initMetadataForObject(DecimalProduct580, 'DecimalProduct580');
  initMetadataForClass(Cells_1, 'Cells');
  initMetadataForClass(DecimalWords_1, 'DecimalWords');
  initMetadataForObject(DecimalSquareRoot579, 'DecimalSquareRoot579');
  initMetadataForClass(View, 'View');
  initMetadataForClass(Cells_2, 'Cells');
  initMetadataForClass(Digits, 'Digits');
  initMetadataForObject(DecimalSum585, 'DecimalSum585');
  initMetadataForClass(Input, 'Input');
  initMetadataForClass(Lexical, 'Lexical');
  initMetadataForClass(Cells_3, 'Cells');
  initMetadataForClass(Digits_0, 'Digits');
  initMetadataForObject(DecimalText588, 'DecimalText588');
  initMetadataForObject(Decimals, 'Decimals');
  initMetadataForInterface(ExactConversion, 'ExactConversion');
  initMetadataForClass(Value, 'Value', VOID, VOID, [ExactConversion]);
  initMetadataForClass(Failure, 'Failure', VOID, VOID, [ExactConversion]);
  initMetadataForClass(QuotientRemainder, 'QuotientRemainder');
  initMetadataForObject(MagnitudeLimits, 'MagnitudeLimits');
  initMetadataForClass(Arena, 'Arena');
  initMetadataForObject(MagnitudeMultiplication, 'MagnitudeMultiplication');
  initMetadataForCompanion(Companion_3);
  initMetadataForClass(MathContext, 'MathContext', VOID, VOID, [MathSerializable]);
  initMetadataForClass(asCommonRandom$1, VOID, VOID, Random);
  initMetadataForObject(PrimalityCertainty, 'PrimalityCertainty');
  initMetadataForObject(PrimeSearchLimits, 'PrimeSearchLimits');
  initMetadataForCompanion(Companion_4);
  initMetadataForClass(RoundingMode, 'RoundingMode', VOID, Enum);
  initMetadataForClass(MathObjectInputStream, 'MathObjectInputStream', MathObjectInputStream);
  initMetadataForClass(PlatformRandom, 'PlatformRandom', PlatformRandom);
  initMetadataForClass(ArrayIndexOutOfBoundsException, 'ArrayIndexOutOfBoundsException', VOID, IndexOutOfBoundsException);
  //endregion
  function _get_serialVersionUID__fhggm9($this) {
    return $this.serialVersionUID_1;
  }
  function compareValues($this, a, aScale, b, bScale) {
    if (!(a.signum_exb08b_k$() === b.signum_exb08b_k$()))
      return compareTo(a.signum_exb08b_k$(), b.signum_exb08b_k$());
    if (a.signum_exb08b_k$() === 0)
      return 0;
    var tmp0 = fromInt(a.decimalMagnitudeDigits_6egwr2_k$());
    // Inline function 'kotlin.Long.minus' call
    var other = b.decimalMagnitudeDigits_6egwr2_k$();
    var digitDifference = subtract(tmp0, fromInt(other));
    var exponent = compare(digitDifference, new Long(0, 0)) > 0 && compare(bScale, subtract(new Long(-1, 2147483647), digitDifference)) > 0 ? 1 : compare(digitDifference, new Long(0, 0)) < 0 && compare(bScale, subtract(new Long(0, -2147483648), digitDifference)) < 0 ? -1 : add(bScale, digitDifference).compareTo_9jj042_k$(aScale);
    if (!(exponent === 0))
      return imul(exponent, a.signum_exb08b_k$());
    return imul(a.compareDecimalSignificand_pncnrq_k$(b), a.signum_exb08b_k$());
  }
  function parse($this, value) {
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(value) === 0)
      throw NumberFormatException_init_$Create$('Empty BigDecimal');
    var i = 0;
    var negative = false;
    if (charCodeAt(value, i) === _Char___init__impl__6a9atx(45) || charCodeAt(value, i) === _Char___init__impl__6a9atx(43)) {
      negative = charCodeAt(value, i) === _Char___init__impl__6a9atx(45);
      i = i + 1 | 0;
    }
    var digits = StringBuilder_init_$Create$();
    var point = false;
    var fraction = new Long(0, 0);
    $l$loop: while (i < value.length && !(charCodeAt(value, i) === _Char___init__impl__6a9atx(101)) && !(charCodeAt(value, i) === _Char___init__impl__6a9atx(69))) {
      var _unary__edvuaz = i;
      i = _unary__edvuaz + 1 | 0;
      var c = charCodeAt(value, _unary__edvuaz);
      if (c === _Char___init__impl__6a9atx(46) && !point) {
        point = true;
        continue $l$loop;
      }
      var tmp0_elvis_lhs = digitToIntOrNull(c, 10);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        throw NumberFormatException_init_$Create$('Invalid decimal digit');
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var d = tmp;
      // Inline function 'kotlin.code' call
      var this_0 = _Char___init__impl__6a9atx(48);
      var tmp$ret$1 = Char__toInt_impl_vasixd(this_0);
      digits.append_am5a4z_k$(numberToChar(tmp$ret$1 + d | 0));
      if (point) {
        var _unary__edvuaz_0 = fraction;
        fraction = add(_unary__edvuaz_0, get_ONE());
      }
    }
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(digits) === 0)
      throw NumberFormatException_init_$Create$('No digits');
    var exponent = new Long(0, 0);
    if (i < value.length) {
      i = i + 1 | 0;
      var expSign = 1;
      if (i < value.length && (charCodeAt(value, i) === _Char___init__impl__6a9atx(43) || charCodeAt(value, i) === _Char___init__impl__6a9atx(45))) {
        if (charCodeAt(value, i) === _Char___init__impl__6a9atx(45))
          expSign = -1;
        i = i + 1 | 0;
      }
      if (i === value.length)
        throw NumberFormatException_init_$Create$('No exponent digits');
      while (i < value.length) {
        var _unary__edvuaz_1 = i;
        i = _unary__edvuaz_1 + 1 | 0;
        var tmp1_elvis_lhs = digitToIntOrNull(charCodeAt(value, _unary__edvuaz_1), 10);
        var tmp_0;
        if (tmp1_elvis_lhs == null) {
          throw NumberFormatException_init_$Create$('Invalid exponent');
        } else {
          tmp_0 = tmp1_elvis_lhs;
        }
        var d_0 = tmp_0;
        // Inline function 'kotlin.Long.times' call
        var this_1 = exponent;
        // Inline function 'kotlin.Long.plus' call
        var this_2 = multiply(this_1, fromInt(10));
        exponent = add(this_2, fromInt(d_0));
        var tmp_1 = exponent;
        // Inline function 'kotlin.Long.plus' call
        var this_3 = new Long(2147483647, 0);
        var tmp$ret$5 = add(this_3, fromInt(1));
        if (compare(tmp_1, add(tmp$ret$5, fraction)) > 0)
          throw NumberFormatException_init_$Create$('Exponent overflow');
      }
      var tmp0 = exponent;
      // Inline function 'kotlin.Long.times' call
      var other = expSign;
      exponent = multiply(tmp0, fromInt(other));
    }
    var scale = subtract(fraction, exponent);
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false))
      throw NumberFormatException_init_$Create$('Scale out of range');
    var number = BigInteger_init_$Create$_0(digits.toString());
    return new BigDecimal(negative ? number.negate_hcqk8u_k$() : number, convertToInt(scale));
  }
  function fromDouble($this, value) {
    if (!isFinite(value))
      throw NumberFormatException_init_$Create$('Infinite or NaN');
    if (value === 0.0)
      return $this.ZERO_1;
    var bits = toBits(value);
    var field = convertToInt(bitwiseAnd(shiftRightUnsigned(bits, 52), new Long(2047, 0)));
    // Inline function 'kotlin.Long.minus' call
    var this_0 = new Long(0, 1048576);
    var tmp$ret$0 = subtract(this_0, fromInt(1));
    var mantissa = bitwiseAnd(bits, tmp$ret$0);
    if (!(field === 0))
      mantissa = bitwiseOr(mantissa, new Long(0, 1048576));
    var exponent = ((field === 0 ? 1 : field) - 1023 | 0) - 52 | 0;
    if (exponent < 0) {
      var tmp0 = countTrailingZeroBits(mantissa);
      // Inline function 'kotlin.comparisons.minOf' call
      var b = -exponent | 0;
      var remove = Math.min(tmp0, b);
      mantissa = shiftRightUnsigned(mantissa, remove);
      exponent = exponent + remove | 0;
    }
    var coefficient = Companion_getInstance_2().valueOf_wwtjy2_k$(mantissa);
    var scale;
    if (exponent >= 0) {
      coefficient = coefficient.shiftLeft_qqh5sf_k$(exponent);
      scale = 0;
    } else {
      scale = -exponent | 0;
      coefficient = coefficient.multiply_9xrhei_k$(Companion_getInstance_2().valueOf_wwtjy2_k$(new Long(5, 0)).pow_iykav4_k$(scale));
    }
    return new BigDecimal(value < 0 ? coefficient.negate_hcqk8u_k$() : coefficient, scale);
  }
  function roundedDouble($this, value, mc) {
    var exact = fromDouble($this, value);
    var context = mc;
    return exact.signum_exb08b_k$() === 0 ? exact : exact.round_x6ni4b_k$(context);
  }
  function tenPow($this, exponent) {
    if (compare(exponent, new Long(0, 0)) < 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    if (compare(exponent, new Long(646456992, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    if (compare(exponent, fromInt($this.SMALL_TEN_POWERS_1.length)) < 0)
      return $this.SMALL_TEN_POWERS_1[convertToInt(exponent)];
    return Companion_getInstance_2().get_TEN_18jk30_k$().pow_iykav4_k$(convertToInt(exponent));
  }
  function _get_SMALL_TEN_POWERS__gz1nod($this) {
    return $this.SMALL_TEN_POWERS_1;
  }
  function checkedScale($this, scale) {
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false))
      throw ArithmeticException_init_$Create$(compare(scale, new Long(0, 0)) < 0 ? 'Overflow' : 'Underflow');
    return convertToInt(scale);
  }
  function checkedRoundingScale($this, scale) {
    var narrowed = convertToInt(scale);
    if (!equalsLong(fromInt(narrowed), scale))
      throw ArithmeticException_init_$Create$(narrowed > 0 ? 'Underflow' : 'Overflow');
    return narrowed;
  }
  function saturatedScale($this, scale) {
    return convertToInt(coerceIn(scale, new Long(-2147483648, -1), new Long(2147483647, 0)));
  }
  function scaleForValue($this, scale, zero) {
    return zero ? saturatedScale($this, scale) : checkedScale($this, scale);
  }
  function zeros($this, count) {
    if (compare(count, new Long(2147483639, 0)) > 0)
      throw ArithmeticException_init_$Create$('String too large');
    return repeat('0', convertToInt(count));
  }
  function exponentText($this, exponent) {
    return 'E' + (compare(exponent, new Long(0, 0)) >= 0 ? '+' : '') + exponent.toString();
  }
  function roundedDivide($this, numerator, denominator, mode) {
    if (getKClassFromExpression(numerator).equals(getKClass(BigInteger)) && getKClassFromExpression(denominator).equals(getKClass(BigInteger))) {
      var a = numerator.decimalCompactValue_llvq0o_k$();
      var b = denominator.decimalCompactValue_llvq0o_k$();
      if (!(a == null) && !(b == null) && !equals(b, new Long(0, 0))) {
        var quotient = divide(a, b);
        var remainder = modulo(a, b);
        if (equalsLong(remainder, new Long(0, 0)))
          return Companion_getInstance_2().valueOf_wwtjy2_k$(quotient);
        var sign = compare(a, new Long(0, 0)) < 0 === compare(b, new Long(0, 0)) < 0 ? 1 : -1;
        var r = compare(remainder, new Long(0, 0)) < 0 ? negate(remainder) : remainder;
        var d = compare(b, new Long(0, 0)) < 0 ? negate(b) : b;
        var half = r.compareTo_9jj042_k$(subtract(d, r));
        var tmp = Companion_getInstance_2();
        var tmp_0;
        if (increment($this, mode, sign, half, !equalsLong(bitwiseAnd(quotient, new Long(1, 0)), new Long(0, 0)))) {
          // Inline function 'kotlin.Long.plus' call
          tmp_0 = add(quotient, fromInt(sign));
        } else {
          tmp_0 = quotient;
        }
        return tmp.valueOf_wwtjy2_k$(tmp_0);
      }
    }
    var qr = numerator.divideAndRemainder_2r68pv_k$(denominator);
    if (qr[1].signum_exb08b_k$() === 0)
      return qr[0];
    var sign_0 = imul(numerator.signum_exb08b_k$(), denominator.signum_exb08b_k$());
    var remainder_0 = qr[1].abs_22cy_k$();
    var divisor = denominator.abs_22cy_k$();
    var half_0 = remainder_0.compareTo_ljvw96_k$(divisor.subtract_7q3n06_k$(remainder_0));
    return increment($this, mode, sign_0, half_0, qr[0].testBit_49w3bx_k$(0)) ? qr[0].add_gx3ep5_k$(Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt(sign_0))) : qr[0];
  }
  function roundTiny($this, sign, mode) {
    return increment($this, mode, sign, -1, false) ? Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt(sign)) : Companion_getInstance_2().get_ZERO_wodlgx_k$();
  }
  function increment($this, mode, sign, half, odd) {
    var tmp;
    switch (mode.get_ordinal_ip24qg_k$()) {
      case 0:
        tmp = true;
        break;
      case 1:
        tmp = false;
        break;
      case 2:
        tmp = sign > 0;
        break;
      case 3:
        tmp = sign < 0;
        break;
      case 4:
        tmp = half >= 0;
        break;
      case 5:
        tmp = half > 0;
        break;
      case 6:
        tmp = half > 0 || (half === 0 && odd);
        break;
      case 7:
        throw ArithmeticException_init_$Create$('Rounding necessary');
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function _get_decimalScale__lew16a($this) {
    return $this.decimalScale_1;
  }
  function _get_coefficient__a73doc($this) {
    return $this.coefficient_1;
  }
  function BigDecimal_init_$Init$(value, $this) {
    BigDecimal.call($this, value.coefficient_1, value.decimalScale_1);
    return $this;
  }
  function BigDecimal_init_$Create$(value) {
    return BigDecimal_init_$Init$(value, objectCreate(protoOf(BigDecimal)));
  }
  function readObject($this, stream) {
    restoreSerializedFields(stream);
    var restored = $this.coefficient_1;
    if (restored == null) {
      invalidSerializedState('Missing BigDecimal coefficient');
    }
  }
  function readObjectNoData($this) {
    invalidSerializedState('Missing BigDecimal data');
  }
  function BigDecimal_init_$Init$_0(value, $this) {
    BigDecimal.call($this, value, 0);
    return $this;
  }
  function BigDecimal_init_$Create$_0(value) {
    return BigDecimal_init_$Init$_0(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_1(value, mc, $this) {
    BigDecimal_init_$Init$(roundValue(BigDecimal_init_$Create$_0(value), mc), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_1(value, mc) {
    return BigDecimal_init_$Init$_1(value, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_2(unscaledVal, scale, mc, $this) {
    BigDecimal_init_$Init$(roundValue(new BigDecimal(unscaledVal, scale), mc), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_2(unscaledVal, scale, mc) {
    return BigDecimal_init_$Init$_2(unscaledVal, scale, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_3(value, $this) {
    BigDecimal_init_$Init$_4(fromInt(value), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_3(value) {
    return BigDecimal_init_$Init$_3(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_4(value, $this) {
    BigDecimal.call($this, Companion_getInstance_2().valueOf_wwtjy2_k$(value), 0);
    return $this;
  }
  function BigDecimal_init_$Create$_4(value) {
    return BigDecimal_init_$Init$_4(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_5(value, mc, $this) {
    BigDecimal_init_$Init$_6(fromInt(value), mc, $this);
    return $this;
  }
  function BigDecimal_init_$Create$_5(value, mc) {
    return BigDecimal_init_$Init$_5(value, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_6(value, mc, $this) {
    BigDecimal_init_$Init$(roundValue(BigDecimal_init_$Create$_4(value), mc), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_6(value, mc) {
    return BigDecimal_init_$Init$_6(value, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_7(value, $this) {
    BigDecimal_init_$Init$(parse(Companion_getInstance_0(), value), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_7(value) {
    return BigDecimal_init_$Init$_7(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_8(value, mc, $this) {
    BigDecimal_init_$Init$(value.length <= 646456992 ? roundValue(parse(Companion_getInstance_0(), value), mc) : DecimalText588_getInstance().parse_ucvsji_k$(value, mc), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_8(value, mc) {
    return BigDecimal_init_$Init$_8(value, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_9(value, $this) {
    BigDecimal_init_$Init$_10(value, 0, value.length, $this);
    return $this;
  }
  function BigDecimal_init_$Create$_9(value) {
    return BigDecimal_init_$Init$_9(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_10(value, offset, len, $this) {
    BigDecimal_init_$Init$(DecimalText588_getInstance().parse_vc79vc_k$(value, offset, len, Companion_getInstance_4().get_UNLIMITED_eshsm0_k$()), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_10(value, offset, len) {
    return BigDecimal_init_$Init$_10(value, offset, len, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_11(value, mc, $this) {
    BigDecimal_init_$Init$_12(value, 0, value.length, mc, $this);
    return $this;
  }
  function BigDecimal_init_$Create$_11(value, mc) {
    return BigDecimal_init_$Init$_11(value, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_12(value, offset, len, mc, $this) {
    BigDecimal_init_$Init$(DecimalText588_getInstance().parse_vc79vc_k$(value, offset, len, mc), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_12(value, offset, len, mc) {
    return BigDecimal_init_$Init$_12(value, offset, len, mc, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_13(value, $this) {
    BigDecimal_init_$Init$(fromDouble(Companion_getInstance_0(), value), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_13(value) {
    return BigDecimal_init_$Init$_13(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_14(value, mc, $this) {
    BigDecimal_init_$Init$(roundedDouble(Companion_getInstance_0(), value, mc), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_14(value, mc) {
    return BigDecimal_init_$Init$_14(value, mc, objectCreate(protoOf(BigDecimal)));
  }
  function storedPrecision($this) {
    return $this.coefficient_1.decimalMagnitudeDigits_6egwr2_k$();
  }
  function contextualUnaryRound($this, mc) {
    return $this.coefficient_1.signum_exb08b_k$() === 0 ? roundValue($this, mc) : $this.plus_utac4v_k$(mc);
  }
  function rawSum585($this, other, subtract, mc) {
    var tmp0_elvis_lhs = $this.coefficient_1.alignedDecimalSum585_shheyo_k$(other.coefficient_1, $this.decimalScale_1, other.decimalScale_1, subtract, mc);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return null;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var result = tmp;
    return new BigDecimal(result.first, result.second);
  }
  function addValue($this, augend) {
    var tmp0 = $this.decimalScale_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = augend.decimalScale_1;
    var scale = Math.max(tmp0, b);
    return new BigDecimal(scaledCoefficient($this, scale).add_gx3ep5_k$(scaledCoefficient(augend, scale)), scale);
  }
  function addContextValue($this, augend, mc) {
    var tmp0 = $this.decimalScale_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = augend.decimalScale_1;
    var preferredScale = Math.max(tmp0, b);
    if ($this.signum_exb08b_k$() === 0 || augend.signum_exb08b_k$() === 0) {
      var nonzero = ($this.signum_exb08b_k$() === 0 ? augend : $this).round_x6ni4b_k$(mc);
      if (nonzero.signum_exb08b_k$() === 0)
        return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), preferredScale);
      var tmp0_0 = fromInt(preferredScale);
      var tmp0_1 = fromInt(nonzero.decimalScale_1);
      // Inline function 'kotlin.Long.plus' call
      var other = mc.get_precision_e8tfsb_k$();
      var tmp0_2 = add(tmp0_1, fromInt(other));
      // Inline function 'kotlin.Long.minus' call
      var other_0 = nonzero.precision_mrc8zm_k$();
      // Inline function 'kotlin.comparisons.minOf' call
      var b_0 = subtract(tmp0_2, fromInt(other_0));
      var scale = compare(tmp0_0, b_0) <= 0 ? tmp0_0 : b_0;
      return nonzero.setScale_k7foeo_k$(checkedScale(Companion_getInstance_0(), scale));
    }
    checkAdditionAlignment($this, augend, mc);
    var tmp;
    var tmp0_3 = fromInt($this.decimalScale_1);
    // Inline function 'kotlin.Long.minus' call
    var other_1 = augend.decimalScale_1;
    var tmp$ret$4 = subtract(tmp0_3, fromInt(other_1));
    if (compare(abs(tmp$ret$4), new Long(10000, 0)) < 0) {
      tmp = true;
    } else {
      var tmp_0 = abs(subtract(adjustedExponent($this), adjustedExponent(augend)));
      // Inline function 'kotlin.Long.plus' call
      var this_0 = fromInt(mc.get_precision_e8tfsb_k$());
      var tmp$ret$5 = add(this_0, fromInt(3));
      tmp = compare(tmp_0, tmp$ret$5) <= 0;
    }
    if (tmp) {
      var tmp0_elvis_lhs = rawSum585($this, augend, false, mc);
      return tmp0_elvis_lhs == null ? roundValue(addValue($this, augend), mc) : tmp0_elvis_lhs;
    }
    var large = compare(adjustedExponent($this), adjustedExponent(augend)) > 0 ? $this : augend;
    var small = large === $this ? augend : $this;
    var tmp0_4 = fromInt(large.decimalScale_1);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_1 = subtract(add(fromInt(mc.get_precision_e8tfsb_k$()), new Long(2, 0)), adjustedExponent(large));
    var workingScale = compare(tmp0_4, b_1) >= 0 ? tmp0_4 : b_1;
    var sticky = stickyAt(small, workingScale);
    var tmp1_elvis_lhs = rawSum585(large, sticky, false, mc);
    var result = tmp1_elvis_lhs == null ? roundValue(addValue(large, sticky), mc) : tmp1_elvis_lhs;
    var tmp0_5 = $this.decimalScale_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_2 = augend.decimalScale_1;
    var preferred = Math.max(tmp0_5, b_2);
    return result.signum_exb08b_k$() === 0 ? result.setScale_k7foeo_k$(preferred) : stripTo(result, preferred);
  }
  function checkAdditionAlignment($this, other, mc) {
    if ($this.decimalScale_1 === other.decimalScale_1)
      return Unit_getInstance();
    var dominant = $this.decimalScale_1 <= other.decimalScale_1 ? $this : other;
    var remote = dominant === $this ? other : $this;
    var tmp0 = fromInt(remote.decimalScale_1);
    // Inline function 'kotlin.Long.minus' call
    var other_0 = remote.precision_mrc8zm_k$();
    // Inline function 'kotlin.Long.plus' call
    var this_0 = subtract(tmp0, fromInt(other_0));
    var leadingPosition = add(this_0, fromInt(1));
    var tmp0_0 = fromInt(dominant.decimalScale_1);
    // Inline function 'kotlin.Long.minus' call
    var other_1 = dominant.precision_mrc8zm_k$();
    var tmp0_1 = subtract(tmp0_0, fromInt(other_1));
    // Inline function 'kotlin.Long.plus' call
    var other_2 = mc.get_precision_e8tfsb_k$();
    var roundingScale = add(tmp0_1, fromInt(other_2));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = fromInt(dominant.decimalScale_1);
    var alignmentThreshold = add(this_1, fromInt(2));
    var tmp;
    if (compare(leadingPosition, alignmentThreshold) > 0) {
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$5 = add(roundingScale, fromInt(2));
      tmp = compare(leadingPosition, tmp$ret$5) > 0;
    } else {
      tmp = false;
    }
    if (tmp) {
      var tmp_0 = Companion_getInstance_0();
      // Inline function 'kotlin.comparisons.maxOf' call
      var a = fromInt(dominant.decimalScale_1);
      // Inline function 'kotlin.Long.plus' call
      var this_2 = compare(a, roundingScale) >= 0 ? a : roundingScale;
      var tmp$ret$7 = add(this_2, fromInt(3));
      checkedScale(tmp_0, tmp$ret$7);
    }
  }
  function stickyAt($this, scale) {
    if ($this.signum_exb08b_k$() === 0 || compare(fromInt($this.decimalScale_1), scale) <= 0)
      return $this;
    var drop = subtract(fromInt($this.decimalScale_1), scale);
    var reportedPrecision = $this.precision_mrc8zm_k$();
    if (equalsLong(drop, fromInt(reportedPrecision)) && !equals($this.coefficient_1.decimalCompactValue_llvq0o_k$(), new Long(0, 0)) && equalsLong(drop, fromInt(storedPrecision($this)))) {
      var tmp = Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt($this.signum_exb08b_k$()));
      var tmp_0 = Companion_getInstance_0();
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$0 = add(scale, fromInt(1));
      return new BigDecimal(tmp, checkedScale(tmp_0, tmp$ret$0));
    }
    if (compare(drop, fromInt(reportedPrecision)) <= 0) {
      var divisor = tenPow(Companion_getInstance_0(), drop);
      var qr = $this.coefficient_1.divideAndRemainder_2r68pv_k$(divisor);
      var sticky = qr[1].signum_exb08b_k$() === 0 ? qr[0] : qr[0].multiply_9xrhei_k$(Companion_getInstance_2().get_TEN_18jk30_k$()).add_gx3ep5_k$(Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt($this.signum_exb08b_k$())));
      var tmp_1;
      if (qr[1].signum_exb08b_k$() === 0) {
        tmp_1 = new BigDecimal(sticky, checkedScale(Companion_getInstance_0(), scale));
      } else {
        var tmp_2 = Companion_getInstance_0();
        // Inline function 'kotlin.Long.plus' call
        var tmp$ret$1 = add(scale, fromInt(1));
        tmp_1 = new BigDecimal(sticky, checkedScale(tmp_2, tmp$ret$1));
      }
      return tmp_1;
    }
    var tmp_3 = Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt($this.signum_exb08b_k$()));
    var tmp_4 = Companion_getInstance_0();
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$2 = add(scale, fromInt(1));
    return new BigDecimal(tmp_3, checkedScale(tmp_4, tmp$ret$2));
  }
  function multiplyValue($this, multiplicand) {
    var tmp = Companion_getInstance_0();
    var tmp0 = fromInt($this.decimalScale_1);
    // Inline function 'kotlin.Long.plus' call
    var other = multiplicand.decimalScale_1;
    var tmp$ret$0 = add(tmp0, fromInt(other));
    var scale = scaleForValue(tmp, tmp$ret$0, $this.coefficient_1.signum_exb08b_k$() === 0);
    return new BigDecimal($this.coefficient_1.multiply_9xrhei_k$(multiplicand.coefficient_1), scale);
  }
  function checkDivisionByZero($this, divisor) {
    if (divisor.signum_exb08b_k$() === 0)
      throw ArithmeticException_init_$Create$($this.signum_exb08b_k$() === 0 ? 'Division undefined' : 'Division by zero');
  }
  function divideExactly($this, divisor) {
    var tmp0 = fromInt($this.decimalScale_1);
    // Inline function 'kotlin.Long.minus' call
    var other = divisor.decimalScale_1;
    var preferred = subtract(tmp0, fromInt(other));
    if ($this.signum_exb08b_k$() === 0)
      return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), saturatedScale(Companion_getInstance_0(), preferred));
    var tmp = fromInt($this.precision_mrc8zm_k$());
    var tmp0_0 = new Long(10, 0);
    // Inline function 'kotlin.Long.times' call
    var other_0 = divisor.precision_mrc8zm_k$();
    // Inline function 'kotlin.Long.plus' call
    var this_0 = multiply(tmp0_0, fromInt(other_0));
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(2));
    var tmp$ret$3 = divide(this_1, fromInt(3));
    var exactPrecision = convertToInt(coerceAtMost(add(tmp, tmp$ret$3), new Long(2147483647, 0)));
    checkDivisionNormalization($this, divisor, exactPrecision);
    var tmp0_elvis_lhs = exactDivisionCoefficient($this, divisor);
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      throw ArithmeticException_init_$Create$('Non-terminating decimal expansion');
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    var quotient = tmp_0;
    return stripTo(new BigDecimal(quotient.first, checkedScale(Companion_getInstance_0(), quotient.second)), saturatedScale(Companion_getInstance_0(), preferred));
  }
  function exactDivisionCoefficient($this, divisor, forContext) {
    forContext = forContext === VOID ? false : forContext;
    var gcd = $this.coefficient_1.gcd_ucjjcu_k$(divisor.coefficient_1);
    var denominator = divisor.coefficient_1.abs_22cy_k$().divide_bsns5t_k$(gcd);
    var numerator = $this.coefficient_1.divide_bsns5t_k$(gcd);
    var divisorSign = forContext ? divisor.coefficient_1.signum_exb08b_k$() : divisor.signum_exb08b_k$();
    if (divisorSign < 0)
      numerator = numerator.negate_hcqk8u_k$();
    var twos = denominator.getLowestSetBit_vnfocz_k$();
    denominator = denominator.shiftRight_g7qmqq_k$(twos);
    var five = Companion_getInstance_2().valueOf_wwtjy2_k$(new Long(5, 0));
    var fives = 0;
    $l$loop: while (true) {
      var qr = denominator.divideAndRemainder_2r68pv_k$(five);
      if (!(qr[1].signum_exb08b_k$() === 0))
        break $l$loop;
      denominator = qr[0];
      fives = fives + 1 | 0;
    }
    if (!denominator.equals(Companion_getInstance_2().get_ONE_18jnkz_k$()))
      return null;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = fives;
    var digits = Math.max(twos, b);
    var tmp0 = fromInt($this.decimalScale_1);
    // Inline function 'kotlin.Long.minus' call
    var other = divisor.decimalScale_1;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = subtract(tmp0, fromInt(other));
    var scale = add(this_0, fromInt(digits));
    if (compare(scale, new Long(-2147483648, -1)) < 0) {
      checkedScale(Companion_getInstance_0(), scale);
    }
    if (compare(scale, new Long(2147483647, 0)) > 0) {
      if (forContext)
        return null;
      checkedScale(Companion_getInstance_0(), scale);
    }
    numerator = numerator.shiftLeft_qqh5sf_k$(digits - twos | 0).multiply_9xrhei_k$(five.pow_iykav4_k$(digits - fives | 0));
    return to(numerator, scale);
  }
  function divideScaledCoefficients($this, divisor, scale, roundingMode, scaleNumerator, raise, checkSourceSign) {
    checkSourceSign = checkSourceSign === VOID ? true : checkSourceSign;
    if (checkSourceSign && $this.signum_exb08b_k$() === 0)
      return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), scale);
    var tmp0 = quotientExponent($this, divisor);
    // Inline function 'kotlin.Long.plus' call
    var other = $this.decimalScale_1;
    var tmp0_0 = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.minus' call
    var other_0 = divisor.decimalScale_1;
    var tmp$ret$1 = subtract(tmp0_0, fromInt(other_0));
    var exponent = add(tmp$ret$1, scaleNumerator ? raise : negate(raise));
    if (compare(exponent, new Long(-1, -1)) < 0 && !($this.coefficient_1.signum_exb08b_k$() === 0) && !(divisor.coefficient_1.signum_exb08b_k$() === 0)) {
      var sign = checkSourceSign ? imul($this.signum_exb08b_k$(), divisor.signum_exb08b_k$()) : imul($this.coefficient_1.signum_exb08b_k$(), divisor.coefficient_1.signum_exb08b_k$());
      return new BigDecimal(roundTiny(Companion_getInstance_0(), sign, roundingMode), scale);
    }
    if (compare(raise, new Long(646456992, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    var numerator = scaleNumerator && compare(raise, new Long(0, 0)) > 0 ? $this.coefficient_1.multiply_9xrhei_k$(tenPow(Companion_getInstance_0(), raise)) : $this.coefficient_1;
    var denominator = !scaleNumerator && compare(raise, new Long(0, 0)) > 0 ? divisor.coefficient_1.multiply_9xrhei_k$(tenPow(Companion_getInstance_0(), raise)) : divisor.coefficient_1;
    if (!checkSourceSign && denominator.signum_exb08b_k$() === 0 && !(numerator.decimalCompactValue_llvq0o_k$() == null))
      throw ArithmeticException_init_$Create$('/ by zero');
    return new BigDecimal(roundedDivide(Companion_getInstance_0(), numerator, denominator, roundingMode), scale);
  }
  function failScaledZeroDivision($this, zeroScale, target) {
    var compact = $this.coefficient_1.decimalCompactValue_llvq0o_k$();
    var tmp = Companion_getInstance_0();
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(target);
    var tmp$ret$0 = add(this_0, fromInt(zeroScale));
    var adjusted = scaleForValue(tmp, tmp$ret$0, equals(compact, new Long(0, 0)));
    var numerator = adjusted > $this.decimalScale_1;
    var tmp_0;
    if (numerator) {
      tmp_0 = (target + zeroScale | 0) - $this.decimalScale_1 | 0;
    } else {
      var tmp_1 = Companion_getInstance_0();
      // Inline function 'kotlin.Long.minus' call
      var this_1 = fromInt($this.decimalScale_1);
      var tmp$ret$1 = subtract(this_1, fromInt(target));
      tmp_0 = saturatedScale(tmp_1, tmp$ret$1) - zeroScale | 0;
    }
    var raise = tmp_0;
    if (raise > 646456992)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    if (compact == null || raise > 18)
      throw ArithmeticException_init_$Create$('BigInteger divide by zero');
    if (numerator && raise > 0) {
      var factor = new Long(1, 0);
      // Inline function 'kotlin.repeat' call
      var inductionVariable = 0;
      if (inductionVariable < raise)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          // Inline function 'kotlin.Long.times' call
          var this_2 = factor;
          factor = multiply(this_2, fromInt(10));
        }
         while (inductionVariable < raise);
      if (compare(abs(compact), divide(new Long(-1, 2147483647), factor)) > 0)
        throw ArithmeticException_init_$Create$('BigInteger divide by zero');
    }
    throw ArithmeticException_init_$Create$('/ by zero');
  }
  function divideWideContext($this, divisor, mc, preferred, normalized, sourceDigits, divisorDigits) {
    var exact = exactDivisionCoefficient($this, divisor, true);
    if (!(exact == null) && exact.first.abs_22cy_k$().toString().length <= mc.get_precision_e8tfsb_k$())
      return new BigDecimal(exact.first, divisionScale($this, exact.second));
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(sourceDigits);
    var tmp0 = subtract(this_0, fromInt(divisorDigits));
    // Inline function 'kotlin.Long.minus' call
    var other = normalized < 0 ? 1 : 0;
    var exponent = subtract(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = mc.get_precision_e8tfsb_k$();
    var tmp$ret$2 = add(preferred, fromInt(other_0));
    var scale = subtract(subtract(tmp$ret$2, new Long(1, 0)), exponent);
    var shift = subtract(scale, preferred);
    if (compare(abs(shift), new Long(646456992, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    var numerator = compare(shift, new Long(0, 0)) > 0 ? $this.coefficient_1.multiply_9xrhei_k$(tenPow(Companion_getInstance_0(), shift)) : $this.coefficient_1;
    var denominator = compare(shift, new Long(0, 0)) < 0 ? divisor.coefficient_1.multiply_9xrhei_k$(tenPow(Companion_getInstance_0(), negate(shift))) : divisor.coefficient_1;
    var isExact = numerator.remainder_djq7c5_k$(denominator).signum_exb08b_k$() === 0;
    var value = roundedDivide(Companion_getInstance_0(), numerator, denominator, mc.get_roundingMode_uxzxk0_k$());
    if (value.abs_22cy_k$().toString().length > mc.get_precision_e8tfsb_k$()) {
      value = value.divide_bsns5t_k$(Companion_getInstance_2().get_TEN_18jk30_k$());
      var _unary__edvuaz = scale;
      scale = subtract(_unary__edvuaz, get_ONE());
    }
    if (isExact)
      $l$loop: while (compare(scale, preferred) > 0 && compare(scale, new Long(-2147483648, -1)) > 0) {
        var qr = value.divideAndRemainder_2r68pv_k$(Companion_getInstance_2().get_TEN_18jk30_k$());
        if (!(qr[1].signum_exb08b_k$() === 0))
          break $l$loop;
        value = qr[0];
        var _unary__edvuaz_0 = scale;
        scale = subtract(_unary__edvuaz_0, get_ONE());
      }
    return new BigDecimal(value, divisionScale($this, scale));
  }
  function normalizedCompactOverflow($this, value, raise) {
    var magnitude = abs(value);
    if (equalsLong(magnitude, new Long(0, 0)))
      return false;
    if (compare(raise, new Long(18, 0)) > 0)
      return true;
    // Inline function 'kotlin.repeat' call
    var times = convertToInt(raise);
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = magnitude;
        // Inline function 'kotlin.Long.div' call
        var this_0 = new Long(-1, 2147483647);
        var tmp$ret$2 = divide(this_0, fromInt(10));
        if (compare(tmp, tmp$ret$2) > 0)
          return true;
        // Inline function 'kotlin.Long.times' call
        var this_1 = magnitude;
        magnitude = multiply(this_1, fromInt(10));
      }
       while (inductionVariable < times);
    return false;
  }
  function checkDivisionNormalization($this, divisor, precision, sourcePrecision, divisorPrecision) {
    sourcePrecision = sourcePrecision === VOID ? null : sourcePrecision;
    divisorPrecision = divisorPrecision === VOID ? null : divisorPrecision;
    var adjustment = normalizedComparison($this, divisor) > 0 ? 1 : 0;
    var divisorDigits = divisorPrecision == null ? divisor.precision_mrc8zm_k$() : divisorPrecision;
    var sourceDigits = sourcePrecision == null ? $this.precision_mrc8zm_k$() : sourcePrecision;
    var tmp0 = fromInt($this.decimalScale_1);
    // Inline function 'kotlin.Long.minus' call
    var other = divisor.decimalScale_1;
    var preferred = subtract(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.plus' call
    var this_0 = add(preferred, fromInt(precision));
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(divisorDigits));
    // Inline function 'kotlin.Long.minus' call
    var this_2 = subtract(this_1, fromInt(sourceDigits));
    var normalization = subtract(this_2, fromInt(adjustment));
    if (sourceDigits === storedPrecision($this) && divisorDigits === storedPrecision(divisor) && !($this.coefficient_1.signum_exb08b_k$() === 0) && !(divisor.coefficient_1.signum_exb08b_k$() === 0))
      return Unit_getInstance();
    divisionScale($this, normalization);
  }
  function divisionScale($this, scale) {
    var narrowed = convertToInt(scale);
    if (!equalsLong(fromInt(narrowed), scale))
      throw ArithmeticException_init_$Create$(narrowed > 0 ? 'Underflow' : 'Overflow');
    return narrowed;
  }
  function quotientExponent($this, divisor) {
    if ($this.coefficient_1.decimalCompactValue_llvq0o_k$() == null || divisor.coefficient_1.decimalCompactValue_llvq0o_k$() == null) {
      var tmp0 = fromInt($this.coefficient_1.decimalMagnitudeDigits_6egwr2_k$());
      // Inline function 'kotlin.Long.minus' call
      var other = divisor.coefficient_1.decimalMagnitudeDigits_6egwr2_k$();
      var tmp$ret$0 = subtract(tmp0, fromInt(other));
      var tmp0_0 = add(tmp$ret$0, fromInt(divisor.decimalScale_1));
      // Inline function 'kotlin.Long.minus' call
      var other_0 = $this.decimalScale_1;
      var tmp0_1 = subtract(tmp0_0, fromInt(other_0));
      // Inline function 'kotlin.Long.minus' call
      var other_1 = $this.coefficient_1.compareDecimalSignificand_pncnrq_k$(divisor.coefficient_1) < 0 ? 1 : 0;
      return subtract(tmp0_1, fromInt(other_1));
    }
    var a = $this.coefficient_1.abs_22cy_k$().toString();
    var b = divisor.coefficient_1.abs_22cy_k$().toString();
    var tmp0_2 = fromInt(a.length);
    // Inline function 'kotlin.Long.minus' call
    var other_2 = b.length;
    var tmp$ret$3 = subtract(tmp0_2, fromInt(other_2));
    var tmp0_3 = add(tmp$ret$3, fromInt(divisor.decimalScale_1));
    // Inline function 'kotlin.Long.minus' call
    var other_3 = $this.decimalScale_1;
    var tmp0_4 = subtract(tmp0_3, fromInt(other_3));
    // Inline function 'kotlin.Long.minus' call
    var other_4 = normalizedComparison($this, divisor) < 0 ? 1 : 0;
    return subtract(tmp0_4, fromInt(other_4));
  }
  function normalizedComparison($this, divisor) {
    if ($this.coefficient_1.decimalCompactValue_llvq0o_k$() == null || divisor.coefficient_1.decimalCompactValue_llvq0o_k$() == null)
      return $this.coefficient_1.compareDecimalSignificand_pncnrq_k$(divisor.coefficient_1);
    var a = $this.coefficient_1.abs_22cy_k$().toString();
    var b = divisor.coefficient_1.abs_22cy_k$().toString();
    var tmp0 = a.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_0 = b.length;
    var length = Math.max(tmp0, b_0);
    return compareTo(padEnd(a, length, _Char___init__impl__6a9atx(48)), padEnd(b, length, _Char___init__impl__6a9atx(48)));
  }
  function integralStrip($this, preferred, preserveIdentity) {
    if ($this.coefficient_1.signum_exb08b_k$() === 0) {
      // Inline function 'kotlin.comparisons.minOf' call
      var a = $this.decimalScale_1;
      var scale = Math.min(a, preferred);
      if (preserveIdentity && $this.decimalScale_1 === scale)
        return $this;
      return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), scale);
    }
    var stripped = stripTo($this, preferred);
    return preserveIdentity ? stripped : new BigDecimal(stripped.coefficient_1, stripped.decimalScale_1);
  }
  function remainderElement($this, pair) {
    if (pair.length < 2) {
      arrayIndexFailure(1, pair.length);
    }
    return pair[1];
  }
  function roundValue($this, mc) {
    if (mc.get_precision_e8tfsb_k$() === 0)
      return $this;
    var drop = $this.precision_mrc8zm_k$() - mc.get_precision_e8tfsb_k$() | 0;
    if (drop <= 0)
      return $this;
    var value = $this.coefficient_1;
    var scale = $this.decimalScale_1;
    while (drop > 0) {
      var tmp = Companion_getInstance_0();
      var tmp0 = fromInt(scale);
      // Inline function 'kotlin.Long.minus' call
      var other = drop;
      var tmp$ret$0 = subtract(tmp0, fromInt(other));
      scale = checkedRoundingScale(tmp, tmp$ret$0);
      value = roundedDivide(Companion_getInstance_0(), value, tenPow(Companion_getInstance_0(), fromInt(drop)), mc.get_roundingMode_uxzxk0_k$());
      drop = value.decimalMagnitudeDigits_6egwr2_k$() - mc.get_precision_e8tfsb_k$() | 0;
    }
    return new BigDecimal(value, scale);
  }
  function setScaleValue($this, newScale, roundingMode) {
    if ($this.decimalScale_1 === newScale)
      return $this;
    if ($this.signum_exb08b_k$() === 0)
      return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), newScale);
    var tmp0 = fromInt(newScale);
    // Inline function 'kotlin.Long.minus' call
    var other = $this.decimalScale_1;
    var shift = subtract(tmp0, fromInt(other));
    var tmp;
    if (compare(shift, new Long(0, 0)) > 0) {
      var distance = checkedScale(Companion_getInstance_0(), shift);
      if (distance > 646456992)
        throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
      tmp = $this.coefficient_1.multiply_9xrhei_k$(tenPow(Companion_getInstance_0(), shift));
    } else {
      var digits = fromInt(storedPrecision($this));
      tmp = compare(negate(shift), digits) > 0 ? roundTiny(Companion_getInstance_0(), $this.signum_exb08b_k$(), roundingMode) : equalsLong(negate(shift), digits) ? roundSubunitCoefficient($this, negate(shift), roundingMode) : roundedDivide(Companion_getInstance_0(), $this.coefficient_1, tenPow(Companion_getInstance_0(), negate(shift)), roundingMode);
    }
    var value = tmp;
    return new BigDecimal(value, newScale);
  }
  function roundSubunitCoefficient($this, digits, mode) {
    var tmp = $this.coefficient_1.abs_22cy_k$();
    var tmp_0 = Companion_getInstance_0();
    // Inline function 'kotlin.Long.minus' call
    var tmp$ret$0 = subtract(digits, fromInt(1));
    var qr = tmp.divideAndRemainder_2r68pv_k$(tenPow(tmp_0, tmp$ret$0));
    var leadingHalf = qr[0].compareTo_ljvw96_k$(Companion_getInstance_2().valueOf_wwtjy2_k$(new Long(5, 0)));
    var half = leadingHalf === 0 && !(qr[1].signum_exb08b_k$() === 0) ? 1 : leadingHalf;
    var sign = $this.coefficient_1.signum_exb08b_k$();
    return increment(Companion_getInstance_0(), mode, sign, half, false) ? Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt(sign)) : Companion_getInstance_2().get_ZERO_wodlgx_k$();
  }
  function stripTo($this, minScale, failOnOverflow) {
    failOnOverflow = failOnOverflow === VOID ? false : failOnOverflow;
    var value = $this.coefficient_1;
    var scale = $this.decimalScale_1;
    var compact = value.decimalCompactValue_llvq0o_k$();
    if (!(compact == null)) {
      var unscaled = compact;
      while (!equals(unscaled, new Long(0, 0)) && scale > minScale && equalsLong(modulo(unscaled, new Long(10, 0)), new Long(0, 0))) {
        unscaled = divide(unscaled, new Long(10, 0));
        scale = scale - 1 | 0;
      }
      if (failOnOverflow && scale === -2147483648 && !equals(unscaled, new Long(0, 0)) && equalsLong(modulo(unscaled, new Long(10, 0)), new Long(0, 0)))
        throw ArithmeticException_init_$Create$('Overflow');
      return scale === $this.decimalScale_1 ? $this : new BigDecimal(Companion_getInstance_2().valueOf_wwtjy2_k$(unscaled), scale);
    }
    if (!(value.signum_exb08b_k$() === 0) && scale > minScale) {
      var qr = value.divideAndRemainder_2r68pv_k$(Companion_getInstance_2().get_TEN_18jk30_k$());
      if (qr[1].signum_exb08b_k$() === 0) {
        value = qr[0];
        scale = scale - 1 | 0;
        var twos = value.getLowestSetBit_vnfocz_k$();
        $l$loop_0: while (scale > minScale && twos > 0) {
          var tmp0 = new Long(9, 0);
          // Inline function 'kotlin.Long.minus' call
          var this_0 = fromInt(scale);
          var tmp2 = subtract(this_0, fromInt(minScale));
          // Inline function 'kotlin.comparisons.minOf' call
          // Inline function 'kotlin.comparisons.minOf' call
          var b = fromInt(twos);
          // Inline function 'kotlin.comparisons.minOf' call
          var b_0 = compare(tmp2, b) <= 0 ? tmp2 : b;
          var tmp$ret$1 = compare(tmp0, b_0) <= 0 ? tmp0 : b_0;
          var chunk = convertToInt(tmp$ret$1);
          var remainder = ensureNotNull(value.remainder_djq7c5_k$(tenPow(Companion_getInstance_0(), fromInt(chunk))).decimalCompactValue_llvq0o_k$());
          var exact = chunk;
          if (!equalsLong(remainder, new Long(0, 0))) {
            var low = remainder;
            exact = 0;
            while (equalsLong(modulo(low, new Long(10, 0)), new Long(0, 0))) {
              low = divide(low, new Long(10, 0));
              exact = exact + 1 | 0;
            }
          }
          if (exact === 0)
            break $l$loop_0;
          value = value.divide_bsns5t_k$(tenPow(Companion_getInstance_0(), fromInt(exact)));
          scale = scale - exact | 0;
          twos = twos - exact | 0;
          if (exact < chunk)
            break $l$loop_0;
        }
      }
    }
    if (failOnOverflow && scale === -2147483648 && !(value.signum_exb08b_k$() === 0) && value.remainder_djq7c5_k$(Companion_getInstance_2().get_TEN_18jk30_k$()).signum_exb08b_k$() === 0)
      throw ArithmeticException_init_$Create$('Overflow');
    return scale === $this.decimalScale_1 ? $this : new BigDecimal(value, scale);
  }
  function movePoint($this, scale) {
    if (equalsLong(scale, fromInt($this.decimalScale_1)) && $this.decimalScale_1 >= 0)
      return $this;
    var result = new BigDecimal($this.coefficient_1, scaleForValue(Companion_getInstance_0(), scale, $this.coefficient_1.signum_exb08b_k$() === 0));
    return result.decimalScale_1 < 0 ? result.setScale_k7foeo_k$(0) : result;
  }
  function finiteExactSquareRoot($this) {
    if ($this.coefficient_1.signum_exb08b_k$() <= 0)
      return null;
    var odd = !(($this.decimalScale_1 & 1) === 0);
    var tmp;
    if (odd) {
      var qr = $this.coefficient_1.divideAndRemainder_2r68pv_k$(Companion_getInstance_2().get_TEN_18jk30_k$());
      if (!(qr[1].signum_exb08b_k$() === 0))
        return null;
      tmp = qr[0];
    } else {
      tmp = $this.coefficient_1;
    }
    var integer = tmp;
    var root = integer.sqrtAndRemainder_n2e1f6_k$();
    if (!(root[1].signum_exb08b_k$() === 0))
      return null;
    var tmp_0;
    if (odd) {
      // Inline function 'kotlin.Long.minus' call
      var this_0 = fromInt($this.decimalScale_1);
      // Inline function 'kotlin.Long.div' call
      var this_1 = subtract(this_0, fromInt(1));
      tmp_0 = divide(this_1, fromInt(2));
    } else {
      // Inline function 'kotlin.Long.div' call
      var this_2 = fromInt($this.decimalScale_1);
      tmp_0 = divide(this_2, fromInt(2));
    }
    var scale = tmp_0;
    return to(root[0], checkedScale(Companion_getInstance_0(), scale));
  }
  function finiteSquareRootResult($this, root, context, preferred) {
    var rounded = roundValue(new BigDecimal(root.first, root.second), context);
    var tmp;
    if (context.get_precision_e8tfsb_k$() === 0) {
      tmp = preferred;
    } else {
      var tmp0 = fromInt(preferred);
      var tmp0_0 = fromInt(rounded.decimalScale_1);
      // Inline function 'kotlin.Long.plus' call
      var other = context.get_precision_e8tfsb_k$();
      var tmp0_1 = add(tmp0_0, fromInt(other));
      // Inline function 'kotlin.Long.minus' call
      var other_0 = storedPrecision(rounded);
      // Inline function 'kotlin.comparisons.minOf' call
      var b = subtract(tmp0_1, fromInt(other_0));
      var tmp$ret$2 = compare(tmp0, b) <= 0 ? tmp0 : b;
      tmp = convertToInt(tmp$ret$2);
    }
    var target = tmp;
    return rounded.decimalScale_1 < target ? setScaleValue(rounded, target, RoundingMode_UNNECESSARY_getInstance()) : rounded;
  }
  function compareMagnitude($this, other) {
    var left = $this.coefficient_1.abs_22cy_k$();
    var right = other.coefficient_1.abs_22cy_k$();
    if (left.signum_exb08b_k$() === 0 || right.signum_exb08b_k$() === 0)
      return compareTo(left.signum_exb08b_k$(), right.signum_exb08b_k$());
    if ($this.decimalScale_1 === other.decimalScale_1)
      return left.compareTo_ljvw96_k$(right);
    var exponent = adjustedExponent($this).compareTo_9jj042_k$(adjustedExponent(other));
    if (!(exponent === 0))
      return exponent;
    return left.compareDecimalSignificand_pncnrq_k$(right);
  }
  function adjustedExponent($this) {
    var tmp0 = fromInt($this.precision_mrc8zm_k$());
    // Inline function 'kotlin.Long.minus' call
    var other = $this.decimalScale_1;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    return subtract(this_0, fromInt(1));
  }
  function scaledCoefficient($this, scale) {
    if ($this.coefficient_1.signum_exb08b_k$() === 0)
      return $this.coefficient_1;
    var tmp = Companion_getInstance_0();
    var tmp0 = fromInt(scale);
    // Inline function 'kotlin.Long.minus' call
    var other = $this.decimalScale_1;
    var tmp$ret$0 = subtract(tmp0, fromInt(other));
    var distance = checkedScale(tmp, tmp$ret$0);
    return $this.coefficient_1.multiply_9xrhei_k$(tenPow(Companion_getInstance_0(), fromInt(distance)));
  }
  function _set_stringCache__9guabw($this, _set____db54di) {
    $this.stringCache_1 = _set____db54di;
  }
  function _get_stringCache__ktjw00($this) {
    return $this.stringCache_1;
  }
  function canonicalStringValue($this) {
    var digits = $this.coefficient_1.abs_22cy_k$().toString();
    var sign = layoutSign($this);
    var tmp0 = fromInt(digits.length);
    // Inline function 'kotlin.Long.minus' call
    var other = $this.decimalScale_1;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    var exponent = subtract(this_0, fromInt(1));
    if ($this.decimalScale_1 >= 0 && compare(exponent, new Long(-6, -1)) >= 0)
      return canonicalPlain($this, digits, sign);
    var tmp;
    if (digits.length === 1) {
      tmp = digits;
    } else {
      // Inline function 'kotlin.text.plus' call
      var this_1 = charCodeAt(digits, 0);
      tmp = toString(this_1) + '.' + substring(digits, 1);
    }
    var body = tmp;
    return (sign < 0 ? '-' : '') + body + exponentText(Companion_getInstance_0(), exponent);
  }
  function layoutSign($this) {
    var compact = $this.coefficient_1.decimalCompactValue_llvq0o_k$();
    var directSign = $this.decimalScale_1 === 0 || ($this.decimalScale_1 === 2 && !(compact == null) && compare(compact, new Long(0, 0)) >= 0 && compare(compact, new Long(2147483647, 0)) < 0);
    return directSign ? $this.coefficient_1.signum_exb08b_k$() : $this.signum_exb08b_k$();
  }
  function canonicalPlain($this, digits, sign) {
    if (compare(plainStringLength($this, digits.length, sign), new Long(2147483647, 0)) > 0) {
      plainStringTooLarge();
    }
    var body = $this.decimalScale_1 === 0 ? digits : $this.decimalScale_1 < digits.length ? substring_0(digits, 0, digits.length - $this.decimalScale_1 | 0) + '.' + substring(digits, digits.length - $this.decimalScale_1 | 0) : '0.' + repeat('0', $this.decimalScale_1 - digits.length | 0) + digits;
    return (sign < 0 ? '-' : '') + body;
  }
  function plainStringLength($this, digits, sign) {
    var signLength = sign < 0 ? new Long(1, 0) : new Long(0, 0);
    return add(signLength, $this.decimalScale_1 <= 0 ? subtract(fromInt(digits), fromInt($this.decimalScale_1)) : $this.decimalScale_1 < digits ? add(fromInt(digits), new Long(1, 0)) : add(fromInt($this.decimalScale_1), new Long(2, 0)));
  }
  function integerLowBits($this, bits) {
    if ($this.decimalScale_1 >= 0)
      return $this.toBigInteger_xwiad5_k$().toLong_edfucp_k$();
    if (compare(negate(fromInt($this.decimalScale_1)), fromInt(bits)) >= 0)
      return new Long(0, 0);
    var raise = negate(fromInt($this.decimalScale_1));
    if (!$this.coefficient_1.decimalLowBitsProductFits591_t956o6_k$(convertToInt(raise)))
      return $this.coefficient_1.decimalProductLowBits591_ut8ae2_k$(convertToInt(raise), bits);
    return $this.coefficient_1.multiply_9xrhei_k$(tenPow(Companion_getInstance_0(), negate(fromInt($this.decimalScale_1)))).toLong_edfucp_k$();
  }
  function narrowExact($this, minimum, maximum) {
    var value = $this.longValueExact_akftqu_k$();
    if (compare(value, minimum) < 0 || compare(value, maximum) > 0)
      throw ArithmeticException_init_$Create$('Overflow');
    return value;
  }
  function binaryValue($this, precision, minExponent, maxExponent) {
    var compact = $this.coefficient_1.decimalCompactValue_llvq0o_k$();
    if (equals(compact, new Long(0, 0)))
      return 0.0;
    var tmp;
    if (compact == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = precision === 24 ? Companion_getInstance_2().valueOf_wwtjy2_k$(compact).toFloat_jhbgwv_k$() : toNumber(compact);
    }
    var compactPrimitive = tmp;
    var maxCompactScale = precision === 24 ? new Long(10, 0) : new Long(22, 0);
    var tmp_0;
    if (!(compact == null)) {
      var tmp_1;
      if ($this.decimalScale_1 === 0) {
        tmp_1 = true;
      } else {
        var tmp_2;
        var containsLower = negate(maxCompactScale);
        var containsArg = fromInt($this.decimalScale_1);
        if (compare(containsLower, containsArg) <= 0 ? compare(containsArg, maxCompactScale) <= 0 : false) {
          tmp_2 = numberToLong(ensureNotNull(compactPrimitive)).equals(compact);
        } else {
          tmp_2 = false;
        }
        tmp_1 = tmp_2;
      }
      tmp_0 = tmp_1;
    } else {
      tmp_0 = false;
    }
    var compactPath = tmp_0;
    var resultSign = compactPath ? ensureNotNull(compact).compareTo_9jj042_k$(new Long(0, 0)) : $this.signum_exb08b_k$();
    var tmp0 = fromInt($this.coefficient_1.decimalDigitLowerBound_4f5nwi_k$());
    // Inline function 'kotlin.Long.minus' call
    var other = $this.decimalScale_1;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    var lowerExponent = subtract(this_0, fromInt(1));
    if (compare(lowerExponent, new Long(400, 0)) > 0)
      return resultSign * Infinity;
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$4 = add(lowerExponent, fromInt(1));
    if (compare(tmp$ret$4, new Long(-400, -1)) < 0)
      return resultSign * 0.0;
    var tmp0_0 = (precision - minExponent | 0) + ((precision + 3 | 0) / 3 | 0) | 0;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = (maxExponent + 3 | 0) / 3 | 0;
    var midpointDigits = Math.max(tmp0_0, b);
    var prefix = $this.coefficient_1.decimalBinaryPrefix_1bw1dx_k$(midpointDigits);
    var tmp0_1 = fromInt(prefix.get_decimalDigits_hhr9m6_k$());
    // Inline function 'kotlin.Long.minus' call
    var other_0 = $this.decimalScale_1;
    // Inline function 'kotlin.Long.minus' call
    var this_1 = subtract(tmp0_1, fromInt(other_0));
    var decimalExponent = subtract(this_1, fromInt(1));
    if (compare(decimalExponent, new Long(400, 0)) > 0)
      return resultSign * Infinity;
    if (compare(decimalExponent, new Long(-400, -1)) < 0)
      return resultSign * 0.0;
    var magnitude = prefix.get_sticky_jnjxf6_k$() ? prefix.get_magnitude_ou7v6h_k$().multiply_9xrhei_k$(Companion_getInstance_2().get_TEN_18jk30_k$()).add_gx3ep5_k$(Companion_getInstance_2().get_ONE_18jnkz_k$()) : prefix.get_magnitude_ou7v6h_k$();
    var tmp0_2 = fromInt($this.decimalScale_1);
    // Inline function 'kotlin.Long.minus' call
    var other_1 = prefix.get_discardedDigits_o1vnja_k$();
    var tmp0_3 = subtract(tmp0_2, fromInt(other_1));
    // Inline function 'kotlin.Long.plus' call
    var other_2 = prefix.get_sticky_jnjxf6_k$() ? 1 : 0;
    var scale = add(tmp0_3, fromInt(other_2));
    var numerator = compare(scale, new Long(0, 0)) < 0 ? magnitude.multiply_9xrhei_k$(tenPow(Companion_getInstance_0(), negate(scale))) : magnitude;
    var denominator = compare(scale, new Long(0, 0)) > 0 ? tenPow(Companion_getInstance_0(), scale) : Companion_getInstance_2().get_ONE_18jnkz_k$();
    var exponent = numerator.bitLength_9mbxrh_k$() - denominator.bitLength_9mbxrh_k$() | 0;
    if (exponent >= 0) {
      if (numerator.compareTo_ljvw96_k$(denominator.shiftLeft_qqh5sf_k$(exponent)) < 0) {
        exponent = exponent - 1 | 0;
      }
    } else if (numerator.shiftLeft_qqh5sf_k$(-exponent | 0).compareTo_ljvw96_k$(denominator) < 0) {
      exponent = exponent - 1 | 0;
    }
    if (exponent > maxExponent)
      return resultSign * Infinity;
    var tmp_3 = precision - 1 | 0;
    // Inline function 'kotlin.comparisons.maxOf' call
    var a = exponent;
    var shift = tmp_3 - Math.max(a, minExponent) | 0;
    var top = shift >= 0 ? roundedDivide(Companion_getInstance_0(), numerator.shiftLeft_qqh5sf_k$(shift), denominator, RoundingMode_HALF_EVEN_getInstance()) : roundedDivide(Companion_getInstance_0(), numerator, denominator.shiftLeft_qqh5sf_k$(-shift | 0), RoundingMode_HALF_EVEN_getInstance());
    var tmp_4 = resultSign * toNumber(top.toLong_edfucp_k$());
    // Inline function 'kotlin.math.pow' call
    var n = -shift | 0;
    return tmp_4 * Math.pow(2.0, n);
  }
  function Companion() {
    Companion_instance = this;
    this.serialVersionUID_1 = new Long(-108976049, 1422333271);
    this.ZERO_1 = new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), 0);
    this.ONE_1 = new BigDecimal(Companion_getInstance_2().get_ONE_18jnkz_k$(), 0);
    this.TWO_1 = new BigDecimal(Companion_getInstance_2().get_TWO_18jjnh_k$(), 0);
    this.TEN_1 = new BigDecimal(Companion_getInstance_2().get_TEN_18jk30_k$(), 0);
    this.ROUND_UP_1 = 0;
    this.ROUND_DOWN_1 = 1;
    this.ROUND_CEILING_1 = 2;
    this.ROUND_FLOOR_1 = 3;
    this.ROUND_HALF_UP_1 = 4;
    this.ROUND_HALF_DOWN_1 = 5;
    this.ROUND_HALF_EVEN_1 = 6;
    this.ROUND_UNNECESSARY_1 = 7;
    var tmp = this;
    // Inline function 'kotlin.run' call
    var power = {_v: new Long(1, 0)};
    var tmp_0 = 0;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(19);
    while (tmp_0 < 19) {
      var tmp_2 = tmp_0;
      if (!(tmp_2 === 0)) {
        power._v = multiply(power._v, new Long(10, 0));
      }
      tmp_1[tmp_2] = Companion_getInstance_2().valueOf_wwtjy2_k$(power._v);
      tmp_0 = tmp_0 + 1 | 0;
    }
    tmp.SMALL_TEN_POWERS_1 = tmp_1;
  }
  protoOf(Companion).get_ZERO_wodlgx_k$ = function () {
    return this.ZERO_1;
  };
  protoOf(Companion).get_ONE_18jnkz_k$ = function () {
    return this.ONE_1;
  };
  protoOf(Companion).get_TWO_18jjnh_k$ = function () {
    return this.TWO_1;
  };
  protoOf(Companion).get_TEN_18jk30_k$ = function () {
    return this.TEN_1;
  };
  protoOf(Companion).get_ROUND_UP_iv1xd7_k$ = function () {
    return this.ROUND_UP_1;
  };
  protoOf(Companion).get_ROUND_DOWN_e30iw4_k$ = function () {
    return this.ROUND_DOWN_1;
  };
  protoOf(Companion).get_ROUND_CEILING_8pgv31_k$ = function () {
    return this.ROUND_CEILING_1;
  };
  protoOf(Companion).get_ROUND_FLOOR_adqff2_k$ = function () {
    return this.ROUND_FLOOR_1;
  };
  protoOf(Companion).get_ROUND_HALF_UP_877z6b_k$ = function () {
    return this.ROUND_HALF_UP_1;
  };
  protoOf(Companion).get_ROUND_HALF_DOWN_3n9ak4_k$ = function () {
    return this.ROUND_HALF_DOWN_1;
  };
  protoOf(Companion).get_ROUND_HALF_EVEN_3na2b0_k$ = function () {
    return this.ROUND_HALF_EVEN_1;
  };
  protoOf(Companion).get_ROUND_UNNECESSARY_j434qk_k$ = function () {
    return this.ROUND_UNNECESSARY_1;
  };
  protoOf(Companion).valueOf_wwtjy2_k$ = function (value) {
    return BigDecimal_init_$Create$_4(value);
  };
  protoOf(Companion).valueOf_eoqnfy_k$ = function (unscaledVal, scale) {
    return new BigDecimal(Companion_getInstance_2().valueOf_wwtjy2_k$(unscaledVal), scale);
  };
  protoOf(Companion).valueOf_6g8uqq_k$ = function (value) {
    return BigDecimal_init_$Create$_7(decimalDoubleString(value));
  };
  var Companion_instance;
  function Companion_getInstance_0() {
    if (Companion_instance == null)
      new Companion();
    return Companion_instance;
  }
  function BigDecimal(coefficient, decimalScale) {
    Companion_getInstance_0();
    Number_0.call(this);
    this.decimalScale_1 = decimalScale;
    this.coefficient_1 = getKClassFromExpression(coefficient).equals(getKClass(BigInteger)) ? coefficient : BigInteger_init_$Create$_2(coefficient.toByteArray_qczt2u_k$());
    this.stringCache_1 = null;
  }
  protoOf(BigDecimal).unscaledValue_ga07pa_k$ = function () {
    return this.coefficient_1;
  };
  protoOf(BigDecimal).scale_1t1miy_k$ = function () {
    return this.decimalScale_1;
  };
  protoOf(BigDecimal).precision_mrc8zm_k$ = function () {
    return storedPrecision(this);
  };
  protoOf(BigDecimal).signum_exb08b_k$ = function () {
    return this.coefficient_1.signum_exb08b_k$();
  };
  protoOf(BigDecimal).abs_22cy_k$ = function () {
    return this.signum_exb08b_k$() < 0 ? this.negate_hcqk8u_k$() : this;
  };
  protoOf(BigDecimal).abs_7nr7qh_k$ = function (mc) {
    return this.signum_exb08b_k$() < 0 ? this.negate_xyjrlz_k$(mc) : contextualUnaryRound(this, mc);
  };
  protoOf(BigDecimal).negate_hcqk8u_k$ = function () {
    return new BigDecimal(this.coefficient_1.negate_hcqk8u_k$(), this.decimalScale_1);
  };
  protoOf(BigDecimal).negate_xyjrlz_k$ = function (mc) {
    return contextualUnaryRound(this.negate_hcqk8u_k$(), mc);
  };
  protoOf(BigDecimal).plus_21ti2_k$ = function () {
    return this;
  };
  protoOf(BigDecimal).plus_utac4v_k$ = function (mc) {
    var result = roundValue(this, mc);
    return result.coefficient_1.signum_exb08b_k$() === 0 ? Companion_getInstance_0().ZERO_1 : result;
  };
  protoOf(BigDecimal).add_6mp6rt_k$ = function (augend) {
    var tmp0_elvis_lhs = rawSum585(this, augend, false, null);
    return tmp0_elvis_lhs == null ? addValue(this, augend) : tmp0_elvis_lhs;
  };
  protoOf(BigDecimal).add_8zel2q_k$ = function (augend, mc) {
    var context = mc;
    if (context.get_precision_e8tfsb_k$() === 0)
      return this.add_6mp6rt_k$(augend);
    return addContextValue(this, augend, context);
  };
  protoOf(BigDecimal).subtract_2kakx6_k$ = function (subtrahend) {
    var operand = subtrahend;
    var tmp0_safe_receiver = rawSum585(this, operand, true, null);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var tmp0 = this.decimalScale_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = operand.decimalScale_1;
    var scale = Math.max(tmp0, b);
    return new BigDecimal(scaledCoefficient(this, scale).subtract_7q3n06_k$(scaledCoefficient(operand, scale)), scale);
  };
  protoOf(BigDecimal).subtract_cqhvj5_k$ = function (subtrahend, mc) {
    var context = mc;
    return context.get_precision_e8tfsb_k$() === 0 ? this.subtract_2kakx6_k$(subtrahend) : this.add_8zel2q_k$(subtrahend.negate_hcqk8u_k$(), context);
  };
  protoOf(BigDecimal).multiply_k85pbu_k$ = function (multiplicand) {
    return multiplyValue(this, multiplicand);
  };
  protoOf(BigDecimal).multiply_j64stt_k$ = function (multiplicand, mc) {
    var context = mc;
    if (context.get_precision_e8tfsb_k$() === 0)
      return this.multiply_k85pbu_k$(multiplicand);
    var operand = multiplicand;
    var tmp0 = fromInt(this.decimalScale_1);
    // Inline function 'kotlin.Long.plus' call
    var other = operand.decimalScale_1;
    var logicalScale = add(tmp0, fromInt(other));
    if (compare(logicalScale, new Long(2147483647, 0)) <= 0 || this.coefficient_1.signum_exb08b_k$() === 0 || operand.coefficient_1.signum_exb08b_k$() === 0) {
      var scale = scaleForValue(Companion_getInstance_0(), logicalScale, this.coefficient_1.signum_exb08b_k$() === 0);
      var raw = this.coefficient_1.roundedDecimalProduct580_fm0dx6_k$(operand.coefficient_1, fromInt(scale), context);
      if (!(raw == null))
        return new BigDecimal(raw.first, raw.second);
      return roundValue(new BigDecimal(this.coefficient_1.multiply_9xrhei_k$(operand.coefficient_1), scale), context);
    }
    var raw_0 = this.coefficient_1.roundedDecimalProduct580_fm0dx6_k$(operand.coefficient_1, logicalScale, context);
    if (!(raw_0 == null))
      return new BigDecimal(raw_0.first, raw_0.second);
    var product = new BigDecimal(this.coefficient_1.multiply_9xrhei_k$(operand.coefficient_1), 0);
    if (storedPrecision(product) <= context.get_precision_e8tfsb_k$()) {
      checkedScale(Companion_getInstance_0(), logicalScale);
    }
    var rounded = product.round_x6ni4b_k$(context);
    var tmp = Companion_getInstance_0();
    // Inline function 'kotlin.Long.plus' call
    var other_0 = rounded.decimalScale_1;
    var tmp$ret$1 = add(logicalScale, fromInt(other_0));
    return new BigDecimal(rounded.coefficient_1, checkedScale(tmp, tmp$ret$1));
  };
  protoOf(BigDecimal).divide_1i9k8h_k$ = function (divisor) {
    var operand = divisor;
    checkDivisionByZero(this, operand);
    var tmp;
    try {
      tmp = divideExactly(this, operand);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var _unused_var__etf5q3 = $p;
        throw ArithmeticException_init_$Create$('Non-terminating decimal expansion; no exact representable decimal result.');
      } else {
        throw $p;
      }
    }
    return tmp;
  };
  protoOf(BigDecimal).divide_n9ljnn_k$ = function (divisor, roundingMode) {
    return this.divide_xle57h_k$(divisor, this.decimalScale_1, roundingMode);
  };
  protoOf(BigDecimal).divide_pmck6h_k$ = function (divisor, roundingMode) {
    var mode = Companion_getInstance_5().valueOf_t43jdc_k$(roundingMode);
    return this.divide_n9ljnn_k$(divisor, mode);
  };
  protoOf(BigDecimal).divide_exvyn_k$ = function (divisor, scale, roundingMode) {
    var mode = Companion_getInstance_5().valueOf_t43jdc_k$(roundingMode);
    return this.divide_xle57h_k$(divisor, scale, mode);
  };
  protoOf(BigDecimal).divide_xle57h_k$ = function (divisor, scale, roundingMode) {
    if (divisor.signum_exb08b_k$() === 0) {
      failScaledZeroDivision(this, divisor.decimalScale_1, scale);
    }
    var tmp0 = fromInt(scale);
    // Inline function 'kotlin.Long.plus' call
    var other = divisor.decimalScale_1;
    var tmp0_0 = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.minus' call
    var other_0 = this.decimalScale_1;
    var shift = subtract(tmp0_0, fromInt(other_0));
    var raw = this.coefficient_1.fixedScaleDecimalQuotient592_y4e3p9_k$(divisor.coefficient_1, shift, roundingMode);
    if (!(raw == null))
      return new BigDecimal(raw, scale);
    var tmp;
    if (!(this.coefficient_1.signum_exb08b_k$() === 0) && compare(abs(shift), new Long(646456992, 0)) > 0) {
      // Inline function 'kotlin.Long.plus' call
      var this_0 = quotientExponent(this, divisor);
      var tmp$ret$2 = add(this_0, fromInt(scale));
      tmp = compare(tmp$ret$2, new Long(-1, -1)) >= 0;
    } else {
      tmp = false;
    }
    if (tmp) {
      var tmp_0 = Companion_getInstance_0();
      var tmp0_1 = fromInt(scale);
      // Inline function 'kotlin.Long.plus' call
      var other_1 = divisor.decimalScale_1;
      var tmp$ret$3 = add(tmp0_1, fromInt(other_1));
      scaleForValue(tmp_0, tmp$ret$3, false);
      if (compare(shift, new Long(0, 0)) <= 0) {
        var tmp_1 = Companion_getInstance_0();
        // Inline function 'kotlin.Long.minus' call
        var this_1 = fromInt(this.decimalScale_1);
        var tmp$ret$4 = subtract(this_1, fromInt(scale));
        scaleForValue(tmp_1, tmp$ret$4, false);
      }
    }
    return divideScaledCoefficients(this, divisor, scale, roundingMode, compare(shift, new Long(0, 0)) >= 0, abs(shift));
  };
  protoOf(BigDecimal).divide_jgiqu2_k$ = function (divisor, mc) {
    var context = mc;
    if (context.get_precision_e8tfsb_k$() === 0)
      return this.divide_1i9k8h_k$(divisor);
    var operand = divisor;
    checkDivisionByZero(this, operand);
    var tmp0 = fromInt(this.decimalScale_1);
    // Inline function 'kotlin.Long.minus' call
    var other = operand.decimalScale_1;
    var preferredScale = subtract(tmp0, fromInt(other));
    if (this.signum_exb08b_k$() === 0)
      return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), saturatedScale(Companion_getInstance_0(), preferredScale));
    var sourceDigits = this.precision_mrc8zm_k$();
    var divisorDigits = operand.precision_mrc8zm_k$();
    var normalized = compareValues(Companion_getInstance_0(), this.coefficient_1.abs_22cy_k$(), fromInt(sourceDigits), operand.coefficient_1.abs_22cy_k$(), fromInt(divisorDigits));
    var adjustment = normalized > 0 ? 1 : 0;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = add(preferredScale, fromInt(context.get_precision_e8tfsb_k$()));
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(divisorDigits));
    // Inline function 'kotlin.Long.minus' call
    var this_2 = subtract(this_1, fromInt(sourceDigits));
    var targetScale = subtract(this_2, fromInt(adjustment));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = operand.decimalScale_1;
    var tmp0_0 = add(targetScale, fromInt(other_0));
    // Inline function 'kotlin.Long.minus' call
    var other_1 = this.decimalScale_1;
    var shift = subtract(tmp0_0, fromInt(other_1));
    var streamed = this.coefficient_1.roundedDecimalQuotient581_unawcx_k$(operand.coefficient_1, preferredScale, targetScale, shift, sourceDigits, divisorDigits, normalized, context);
    if (!(streamed == null))
      return new BigDecimal(streamed.first, streamed.second);
    if ((!(compare(new Long(-2147483648, -1), preferredScale) <= 0 ? compare(preferredScale, new Long(2147483647, 0)) <= 0 : false) || !(compare(new Long(-2147483648, -1), targetScale) <= 0 ? compare(targetScale, new Long(2147483647, 0)) <= 0 : false) || compare(abs(shift), new Long(646456992, 0)) > 0) && sourceDigits === storedPrecision(this) && divisorDigits === storedPrecision(operand) && !(this.coefficient_1.signum_exb08b_k$() === 0) && !(operand.coefficient_1.signum_exb08b_k$() === 0)) {
      var tmp;
      try {
        tmp = divideWideContext(this, operand, context, preferredScale, normalized, sourceDigits, divisorDigits);
      } catch ($p) {
        var tmp_0;
        if ($p instanceof ArithmeticException) {
          var failure = $p;
          divisionScale(this, targetScale);
          if (!(compare(new Long(-2147483648, -1), preferredScale) <= 0 ? compare(preferredScale, new Long(2147483647, 0)) <= 0 : false)) {
            if (compare(abs(shift), new Long(646456992, 0)) > 0)
              throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
            divisionScale(this, preferredScale);
          }
          throw failure;
        } else {
          throw $p;
        }
      }
      return tmp;
    }
    divisionScale(this, targetScale);
    if (compare(abs(shift), new Long(646456992, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    var preferred = divisionScale(this, preferredScale);
    var target = checkedScale(Companion_getInstance_0(), targetScale);
    var compactSource = this.coefficient_1.decimalCompactValue_llvq0o_k$();
    var compactDivisor = operand.coefficient_1.decimalCompactValue_llvq0o_k$();
    var compactNormalization = sourceDigits <= divisorDigits && divisorDigits < 18 && context.get_precision_e8tfsb_k$() < 18 && !(compactSource == null) && !(compactDivisor == null);
    var tmp_1;
    if (compactNormalization) {
      var tmp_2 = ensureNotNull(compactSource);
      // Inline function 'kotlin.Long.minus' call
      var this_3 = fromInt(divisorDigits);
      var tmp$ret$6 = subtract(this_3, fromInt(sourceDigits));
      tmp_1 = normalizedCompactOverflow(this, tmp_2, tmp$ret$6);
    } else {
      tmp_1 = false;
    }
    if (tmp_1)
      return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), preferred);
    if (compactNormalization && normalized === 0) {
      var sign = !(this.coefficient_1.signum_exb08b_k$() < 0 === operand.coefficient_1.signum_exb08b_k$() < 0) ? new Long(-1, -1) : new Long(1, 0);
      var tmp_3 = Companion_getInstance_2().valueOf_wwtjy2_k$(sign);
      // Inline function 'kotlin.Long.plus' call
      // Inline function 'kotlin.Long.minus' call
      var this_4 = add(preferredScale, fromInt(divisorDigits));
      var tmp$ret$8 = subtract(this_4, fromInt(sourceDigits));
      return new BigDecimal(tmp_3, divisionScale(this, tmp$ret$8));
    }
    var result = roundValue(divideScaledCoefficients(this, operand, target, context.get_roundingMode_uxzxk0_k$(), compare(shift, new Long(0, 0)) >= 0, abs(shift), false), context);
    var tmp_4 = Companion_getInstance_0();
    var tmp_5 = result.coefficient_1.multiply_9xrhei_k$(operand.coefficient_1);
    var tmp0_1 = fromInt(result.decimalScale_1);
    // Inline function 'kotlin.Long.plus' call
    var other_2 = operand.decimalScale_1;
    var tmp$ret$9 = add(tmp0_1, fromInt(other_2));
    var exact = compareValues(tmp_4, tmp_5, tmp$ret$9, this.coefficient_1, fromInt(this.decimalScale_1)) === 0;
    var tmp_6;
    if (!exact) {
      tmp_6 = result;
    } else if (result.coefficient_1.signum_exb08b_k$() === 0) {
      var tmp_7 = Companion_getInstance_2().get_ZERO_wodlgx_k$();
      // Inline function 'kotlin.comparisons.minOf' call
      var a = result.decimalScale_1;
      var tmp$ret$10 = Math.min(a, preferred);
      tmp_6 = new BigDecimal(tmp_7, tmp$ret$10);
    } else {
      tmp_6 = stripTo(result, preferred);
    }
    return tmp_6;
  };
  protoOf(BigDecimal).divideToIntegralValue_shg9l3_k$ = function (divisor) {
    var operand = divisor;
    var tmp = Companion_getInstance_0();
    var tmp0 = fromInt(this.decimalScale_1);
    // Inline function 'kotlin.Long.minus' call
    var other = operand.decimalScale_1;
    var tmp$ret$0 = subtract(tmp0, fromInt(other));
    var preferred = saturatedScale(tmp, tmp$ret$0);
    var magnitude = compareMagnitude(this, operand);
    if (magnitude < 0)
      return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), preferred);
    var sourceSign = this.signum_exb08b_k$();
    if (sourceSign === 0 && !(operand.signum_exb08b_k$() === 0))
      return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), preferred);
    var sourcePrecision = this.precision_mrc8zm_k$();
    var sourceDigits = fromInt(sourcePrecision);
    var divisorPrecision = operand.precision_mrc8zm_k$();
    // Inline function 'kotlin.Long.times' call
    var this_0 = new Long(10, 0);
    var divisorDigits = multiply(this_0, fromInt(divisorPrecision));
    // Inline function 'kotlin.Long.div' call
    var tmp0_0 = divide(divisorDigits, fromInt(3));
    var tmp_0;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$3 = modulo(divisorDigits, fromInt(3));
    if (compare(tmp$ret$3, new Long(0, 0)) > 0) {
      tmp_0 = 1;
    } else {
      tmp_0 = 0;
    }
    // Inline function 'kotlin.Long.plus' call
    var other_0 = tmp_0;
    var guardDigits = add(tmp0_0, fromInt(other_0));
    var sourceScale = this.scale_1t1miy_k$();
    var divisorScale = operand.scale_1t1miy_k$();
    var tmp_1 = add(sourceDigits, guardDigits);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(sourceScale);
    var tmp$ret$5 = subtract(this_1, fromInt(divisorScale));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = add(tmp_1, abs(tmp$ret$5));
    var digits = add(this_2, fromInt(2));
    // Inline function 'kotlin.comparisons.minOf' call
    var b = new Long(2147483647, 0);
    var tmp$ret$7 = compare(digits, b) <= 0 ? digits : b;
    var legacyContext = new MathContext(convertToInt(tmp$ret$7), RoundingMode_DOWN_getInstance());
    var integral = this.coefficient_1.integralDecimalQuotient582_mdrb2m_k$(operand.coefficient_1, this.decimalScale_1, operand.decimalScale_1, sourcePrecision, divisorPrecision, sourceScale, divisorScale, sourceSign, magnitude);
    if (!(integral == null))
      return new BigDecimal(integral.first, integral.second);
    var result = this.divide_jgiqu2_k$(operand, legacyContext);
    if (result.decimalScale_1 > 0) {
      result = integralStrip(result.setScale_56o25g_k$(0, RoundingMode_DOWN_getInstance()), preferred, true);
    }
    return preferred > result.decimalScale_1 ? result.setScale_xkfcvs_k$(preferred, 7) : result;
  };
  protoOf(BigDecimal).divideToIntegralValue_sw9rdq_k$ = function (divisor, mc) {
    var context = mc;
    if (context.get_precision_e8tfsb_k$() === 0)
      return this.divideToIntegralValue_shg9l3_k$(divisor);
    var operand = divisor;
    if (compareMagnitude(this, operand) < 0)
      return this.divideToIntegralValue_shg9l3_k$(operand);
    var tmp = Companion_getInstance_0();
    var tmp0 = fromInt(this.decimalScale_1);
    // Inline function 'kotlin.Long.minus' call
    var other = operand.decimalScale_1;
    var tmp$ret$0 = subtract(tmp0, fromInt(other));
    var preferred = saturatedScale(tmp, tmp$ret$0);
    var result = this.divide_jgiqu2_k$(operand, new MathContext(context.get_precision_e8tfsb_k$(), RoundingMode_DOWN_getInstance()));
    var resultScale = result.scale_1t1miy_k$();
    if (resultScale < 0) {
      var certified = resultScale === result.decimalScale_1 ? this.coefficient_1.certifiedDecimalResidual583_fdz1km_k$(operand.coefficient_1, this.decimalScale_1, operand.decimalScale_1, result.coefficient_1, result.decimalScale_1) : null;
      if (certified == null) {
        var residual = this.subtract_2kakx6_k$(result.multiply_k85pbu_k$(operand));
        if (compareMagnitude(residual, operand) >= 0)
          throw ArithmeticException_init_$Create$('Division impossible');
      }
    } else if (result.scale_1t1miy_k$() > 0) {
      result = result.setScale_56o25g_k$(0, RoundingMode_DOWN_getInstance());
    }
    if (preferred > result.scale_1t1miy_k$()) {
      var room = context.get_precision_e8tfsb_k$() - result.precision_mrc8zm_k$() | 0;
      if (room > 0) {
        var scale = result.scale_1t1miy_k$();
        var tmp_0 = result;
        var tmp_1 = fromInt(scale);
        var tmp0_0 = fromInt(room);
        // Inline function 'kotlin.Long.minus' call
        var this_0 = fromInt(preferred);
        // Inline function 'kotlin.comparisons.minOf' call
        var b = subtract(this_0, fromInt(scale));
        var tmp$ret$2 = compare(tmp0_0, b) <= 0 ? tmp0_0 : b;
        return tmp_0.setScale_k7foeo_k$(convertToInt(add(tmp_1, tmp$ret$2)));
      }
    }
    return integralStrip(result, preferred, false);
  };
  protoOf(BigDecimal).divideAndRemainder_7j7z7h_k$ = function (divisor) {
    var quotient = this.divideToIntegralValue_shg9l3_k$(divisor);
    var residual = this.coefficient_1.certifiedDecimalResidual583_fdz1km_k$(divisor.coefficient_1, this.decimalScale_1, divisor.decimalScale_1, quotient.coefficient_1, quotient.decimalScale_1);
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [quotient, residual == null ? this.subtract_2kakx6_k$(quotient.multiply_k85pbu_k$(divisor)) : new BigDecimal(residual.first, residual.second)];
  };
  protoOf(BigDecimal).divideAndRemainder_hsaj58_k$ = function (divisor, mc) {
    var context = mc;
    if (context.get_precision_e8tfsb_k$() === 0)
      return this.divideAndRemainder_7j7z7h_k$(divisor);
    var quotient = this.divideToIntegralValue_sw9rdq_k$(divisor, context);
    var residual = this.coefficient_1.certifiedDecimalResidual583_fdz1km_k$(divisor.coefficient_1, this.decimalScale_1, divisor.decimalScale_1, quotient.coefficient_1, quotient.decimalScale_1);
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [quotient, residual == null ? this.subtract_2kakx6_k$(quotient.multiply_k85pbu_k$(divisor)) : new BigDecimal(residual.first, residual.second)];
  };
  protoOf(BigDecimal).remainder_39bzet_k$ = function (divisor) {
    return remainderElement(this, this.divideAndRemainder_7j7z7h_k$(divisor));
  };
  protoOf(BigDecimal).remainder_v6o34i_k$ = function (divisor, mc) {
    return remainderElement(this, this.divideAndRemainder_hsaj58_k$(divisor, mc));
  };
  protoOf(BigDecimal).round_x6ni4b_k$ = function (mc) {
    return this.plus_utac4v_k$(mc);
  };
  protoOf(BigDecimal).setScale_k7foeo_k$ = function (newScale) {
    return this.setScale_xkfcvs_k$(newScale, 7);
  };
  protoOf(BigDecimal).setScale_xkfcvs_k$ = function (newScale, roundingMode) {
    return setScaleValue(this, newScale, Companion_getInstance_5().valueOf_t43jdc_k$(roundingMode));
  };
  protoOf(BigDecimal).setScale_56o25g_k$ = function (newScale, roundingMode) {
    return this.setScale_xkfcvs_k$(newScale, roundingMode.get_ordinal_ip24qg_k$());
  };
  protoOf(BigDecimal).stripTrailingZeros_9bdwdl_k$ = function () {
    return this.coefficient_1.signum_exb08b_k$() === 0 ? Companion_getInstance_0().ZERO_1 : stripTo(this, -2147483648, true);
  };
  protoOf(BigDecimal).movePointLeft_6mdu42_k$ = function (n) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(this.decimalScale_1);
    var tmp$ret$0 = add(this_0, fromInt(n));
    return movePoint(this, tmp$ret$0);
  };
  protoOf(BigDecimal).movePointRight_gl6xx_k$ = function (n) {
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(this.decimalScale_1);
    var tmp$ret$0 = subtract(this_0, fromInt(n));
    return movePoint(this, tmp$ret$0);
  };
  protoOf(BigDecimal).scaleByPowerOfTen_y9txm_k$ = function (n) {
    var tmp = Companion_getInstance_0();
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(this.decimalScale_1);
    var tmp$ret$0 = subtract(this_0, fromInt(n));
    return new BigDecimal(this.coefficient_1, scaleForValue(tmp, tmp$ret$0, this.coefficient_1.signum_exb08b_k$() === 0));
  };
  protoOf(BigDecimal).ulp_2hfd_k$ = function () {
    return new BigDecimal(Companion_getInstance_2().get_ONE_18jnkz_k$(), this.decimalScale_1);
  };
  protoOf(BigDecimal).pow_iykav4_k$ = function (n) {
    if (!(0 <= n ? n <= 999999999 : false))
      throw ArithmeticException_init_$Create$('Invalid operation');
    if (n === 0)
      return Companion_getInstance_0().ONE_1;
    var tmp = Companion_getInstance_0();
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(this.decimalScale_1);
    var tmp$ret$0 = multiply(this_0, fromInt(n));
    var scale = scaleForValue(tmp, tmp$ret$0, this.coefficient_1.signum_exb08b_k$() === 0);
    return new BigDecimal(this.coefficient_1.pow_iykav4_k$(n), scale);
  };
  protoOf(BigDecimal).pow_kau20n_k$ = function (n, mc) {
    if (mc.get_precision_e8tfsb_k$() === 0)
      return this.pow_iykav4_k$(n);
    if (!(-999999999 <= n ? n <= 999999999 : false))
      throw ArithmeticException_init_$Create$('Invalid operation');
    if (n === 0)
      return Companion_getInstance_0().ONE_1;
    var magnitude = n < 0 ? -n | 0 : n;
    var exponentDigits = magnitude.toString().length;
    if (exponentDigits > mc.get_precision_e8tfsb_k$())
      throw ArithmeticException_init_$Create$('Invalid operation');
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(mc.get_precision_e8tfsb_k$());
    // Inline function 'kotlin.Long.plus' call
    var this_1 = add(this_0, fromInt(exponentDigits));
    var mathematicalPrecision = add(this_1, fromInt(1));
    if (compare(mathematicalPrecision, new Long(646456992, 0)) > 0) {
      var base = this.coefficient_1.decimalPowerState593_1qfbxp_k$(this.decimalScale_1);
      if (!(base == null)) {
        var mode = mc.get_roundingMode_uxzxk0_k$();
        var accumulator = DecimalPower593_getInstance().accumulate_1uip69_k$(base, magnitude, mathematicalPrecision, mode);
        if (n < 0)
          accumulator = DecimalPower593_getInstance().reciprocal_ygvxg5_k$(accumulator, mathematicalPrecision, mc.get_precision_e8tfsb_k$(), mode);
        var result = DecimalPower593_getInstance().publish_qh0kjc_k$(DecimalPower593_getInstance().round_398x3r_k$(accumulator, fromInt(mc.get_precision_e8tfsb_k$()), mode));
        return new BigDecimal(result.first, result.second);
      }
    }
    // Inline function 'kotlin.Long.plus' call
    var this_2 = fromInt(mc.get_precision_e8tfsb_k$());
    // Inline function 'kotlin.Long.plus' call
    var this_3 = add(this_2, fromInt(exponentDigits));
    var tmp0 = add(this_3, fromInt(1));
    // Inline function 'kotlin.comparisons.minOf' call
    var b = new Long(2147483647, 0);
    var tmp$ret$4 = compare(tmp0, b) <= 0 ? tmp0 : b;
    var workPrecision = convertToInt(tmp$ret$4);
    var work = new MathContext(workPrecision, mc.get_roundingMode_uxzxk0_k$());
    var result_0 = Companion_getInstance_0().ONE_1;
    // Inline function 'kotlin.countLeadingZeroBits' call
    var bits = 32 - clz32(magnitude) | 0;
    var inductionVariable = bits - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        result_0 = result_0.multiply_j64stt_k$(result_0, work);
        if (!((magnitude & 1 << i) === 0))
          result_0 = result_0.multiply_j64stt_k$(this, work);
      }
       while (0 <= inductionVariable);
    if (n < 0)
      result_0 = Companion_getInstance_0().ONE_1.divide_jgiqu2_k$(result_0, work);
    return roundValue(result_0, mc);
  };
  protoOf(BigDecimal).sqrt_95gijb_k$ = function (mc) {
    var sign = this.signum_exb08b_k$();
    if (sign < 0)
      throw ArithmeticException_init_$Create$('Attempted square root of negative BigDecimal');
    var context = mc;
    var preferred = this.decimalScale_1 / 2 | 0;
    if (sign === 0)
      return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), preferred);
    var finiteRoot = finiteExactSquareRoot(this);
    if (!(finiteRoot == null))
      return finiteSquareRootResult(this, finiteRoot, context, preferred);
    if (context.get_precision_e8tfsb_k$() === 0 || context.get_roundingMode_uxzxk0_k$().equals(RoundingMode_UNNECESSARY_getInstance())) {
      var normalized = this.stripTrailingZeros_9bdwdl_k$();
      if (!((normalized.decimalScale_1 & 1) === 0))
        throw ArithmeticException_init_$Create$('Computed square root not exact.');
      var tmp;
      if (normalized.unscaledValue_ga07pa_k$().equals(Companion_getInstance_2().get_ONE_18jnkz_k$())) {
        // Inline function 'kotlin.arrayOf' call
        // Inline function 'kotlin.js.unsafeCast' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp = [Companion_getInstance_2().get_ONE_18jnkz_k$(), Companion_getInstance_2().get_ZERO_wodlgx_k$()];
      } else {
        tmp = normalized.unscaledValue_ga07pa_k$().sqrtAndRemainder_n2e1f6_k$();
      }
      var root = tmp;
      if (!(root[1].signum_exb08b_k$() === 0) || (context.get_precision_e8tfsb_k$() > 0 && root[0].abs_22cy_k$().toString().length > context.get_precision_e8tfsb_k$()))
        throw ArithmeticException_init_$Create$('Computed square root not exact.');
      var exact = stripTo(new BigDecimal(root[0], normalized.decimalScale_1 / 2 | 0), preferred);
      var rounded = roundValue(exact, context);
      var tmp_0;
      if (context.get_precision_e8tfsb_k$() === 0) {
        tmp_0 = preferred;
      } else {
        var tmp0 = fromInt(preferred);
        var tmp0_0 = fromInt(rounded.decimalScale_1);
        // Inline function 'kotlin.Long.plus' call
        var other = context.get_precision_e8tfsb_k$();
        var tmp0_1 = add(tmp0_0, fromInt(other));
        // Inline function 'kotlin.Long.minus' call
        var other_0 = storedPrecision(rounded);
        // Inline function 'kotlin.comparisons.minOf' call
        var b = subtract(tmp0_1, fromInt(other_0));
        var tmp$ret$5 = compare(tmp0, b) <= 0 ? tmp0 : b;
        tmp_0 = convertToInt(tmp$ret$5);
      }
      var targetScale = tmp_0;
      if (rounded.coefficient_1.signum_exb08b_k$() === 0)
        return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), targetScale);
      return rounded.decimalScale_1 < targetScale ? setScaleValue(rounded, targetScale, RoundingMode_UNNECESSARY_getInstance()) : rounded;
    }
    var coefficientSign = this.coefficient_1.signum_exb08b_k$();
    if (coefficientSign === 0) {
      this.precision_mrc8zm_k$();
      return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), preferred);
    }
    var exponent = adjustedExponent(this);
    var tmp_1;
    if (compare(exponent, new Long(0, 0)) < 0) {
      // Inline function 'kotlin.Long.minus' call
      // Inline function 'kotlin.Long.div' call
      var this_0 = subtract(exponent, fromInt(1));
      tmp_1 = divide(this_0, fromInt(2));
    } else {
      // Inline function 'kotlin.Long.div' call
      tmp_1 = divide(exponent, fromInt(2));
    }
    var rootExponent = tmp_1;
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(context.get_precision_e8tfsb_k$());
    var tmp$ret$9 = subtract(this_1, fromInt(1));
    var workingScale = subtract(tmp$ret$9, rootExponent);
    var tmp0_2 = multiply(new Long(2, 0), workingScale);
    // Inline function 'kotlin.Long.minus' call
    var other_1 = this.decimalScale_1;
    var shift = subtract(tmp0_2, fromInt(other_1));
    if (coefficientSign > 0 && compare(shift, new Long(0, 0)) > 0 && context.get_precision_e8tfsb_k$() > 268435455) {
      var digits = storedPrecision(this);
      var tmp0_3 = fromInt(digits);
      // Inline function 'kotlin.Long.minus' call
      var other_2 = this.decimalScale_1;
      // Inline function 'kotlin.Long.minus' call
      var this_2 = subtract(tmp0_3, fromInt(other_2));
      var tmp$ret$12 = subtract(this_2, fromInt(1));
      if (equalsLong(exponent, tmp$ret$12)) {
        if (DecimalSquareRoot579_getInstance().inexactPrecisionOverflows_a5y4i3_k$(context.get_precision_e8tfsb_k$()))
          throw ArithmeticException_init_$Create$('BigInteger overflow');
        if (!DecimalSquareRoot579_getInstance().canMaterialize_jcrl0l_k$(digits, shift, workingScale)) {
          var result = DecimalSquareRoot579_getInstance().normalized_giprud_k$(this.coefficient_1, shift, context.get_precision_e8tfsb_k$(), workingScale, preferred, context.get_roundingMode_uxzxk0_k$());
          return new BigDecimal(result.first, result.second);
        }
      }
    }
    var scale = checkedScale(Companion_getInstance_0(), workingScale);
    var numerator = compare(shift, new Long(0, 0)) >= 0 ? this.coefficient_1.multiply_9xrhei_k$(tenPow(Companion_getInstance_0(), shift)) : this.coefficient_1;
    var denominator = compare(shift, new Long(0, 0)) < 0 ? tenPow(Companion_getInstance_0(), negate(shift)) : Companion_getInstance_2().get_ONE_18jnkz_k$();
    var qr = numerator.divideAndRemainder_2r68pv_k$(denominator);
    var root_0 = qr[0].sqrt_23u3k_k$();
    var delta = qr[0].subtract_7q3n06_k$(root_0.multiply_9xrhei_k$(root_0));
    var exact_0 = delta.signum_exb08b_k$() === 0 && qr[1].signum_exb08b_k$() === 0;
    if (!exact_0) {
      var rootComparison = delta.compareTo_ljvw96_k$(root_0);
      var tmp_2;
      if (!(rootComparison === 0)) {
        tmp_2 = rootComparison;
      } else {
        var quarter = denominator.divideAndRemainder_2r68pv_k$(Companion_getInstance_2().valueOf_wwtjy2_k$(new Long(4, 0)));
        var remainderComparison = qr[1].compareTo_ljvw96_k$(quarter[0]);
        tmp_2 = !(remainderComparison === 0) ? remainderComparison : -quarter[1].signum_exb08b_k$() | 0;
      }
      var half = tmp_2;
      if (increment(Companion_getInstance_0(), context.get_roundingMode_uxzxk0_k$(), 1, half, root_0.testBit_49w3bx_k$(0)))
        root_0 = root_0.add_gx3ep5_k$(Companion_getInstance_2().get_ONE_18jnkz_k$());
    }
    var result_0 = roundValue(new BigDecimal(root_0, scale), context);
    return exact_0 ? stripTo(result_0, preferred) : result_0;
  };
  protoOf(BigDecimal).compareTo_b9hobu_k$ = function (other) {
    var operand = other;
    if (this.decimalScale_1 === operand.decimalScale_1) {
      var left = this.coefficient_1.decimalCompactValue_llvq0o_k$();
      var right = operand.coefficient_1.decimalCompactValue_llvq0o_k$();
      if (!(left == null) && !(right == null)) {
        var order = left.compareTo_9jj042_k$(right);
        return order < 0 ? -1 : order > 0 ? 1 : 0;
      }
    }
    var leftSign = this.signum_exb08b_k$();
    var rightSign = operand.signum_exb08b_k$();
    if (!(leftSign === rightSign))
      return leftSign < rightSign ? -1 : 1;
    if (leftSign === 0)
      return 0;
    var magnitude = compareMagnitude(this, operand);
    return magnitude < 0 ? leftSign > 0 ? -1 : 1 : magnitude > 0 ? leftSign > 0 ? 1 : -1 : 0;
  };
  protoOf(BigDecimal).compareTo_hpufkf_k$ = function (other) {
    return this.compareTo_b9hobu_k$(other instanceof BigDecimal ? other : THROW_CCE());
  };
  protoOf(BigDecimal).min_b6fck8_k$ = function (value) {
    return this.compareTo_b9hobu_k$(value) <= 0 ? this : value;
  };
  protoOf(BigDecimal).max_g6q9mu_k$ = function (value) {
    return this.compareTo_b9hobu_k$(value) >= 0 ? this : value;
  };
  protoOf(BigDecimal).equals = function (other) {
    var tmp;
    var tmp_0;
    if (other instanceof BigDecimal) {
      tmp_0 = this.decimalScale_1 === other.decimalScale_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.coefficient_1.equals(other.coefficient_1);
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(BigDecimal).hashCode = function () {
    return imul(31, this.coefficient_1.hashCode()) + this.decimalScale_1 | 0;
  };
  protoOf(BigDecimal).toString = function () {
    var tmp0_safe_receiver = this.stringCache_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    // Inline function 'kotlin.also' call
    var this_0 = canonicalStringValue(this);
    this.stringCache_1 = this_0;
    return this_0;
  };
  protoOf(BigDecimal).toPlainString_6qmubk_k$ = function () {
    if (this.decimalScale_1 === 0)
      return this.coefficient_1.toString();
    if (this.decimalScale_1 < 0) {
      if (this.signum_exb08b_k$() === 0)
        return '0';
      var text = this.coefficient_1.toString();
      if (compare(subtract(fromInt(text.length), fromInt(this.decimalScale_1)), new Long(2147483647, 0)) > 0) {
        plainStringTooLarge();
      }
      return text + repeat('0', convertToInt(negate(fromInt(this.decimalScale_1))));
    }
    return canonicalPlain(this, this.coefficient_1.abs_22cy_k$().toString(), this.signum_exb08b_k$());
  };
  protoOf(BigDecimal).toEngineeringString_h90ert_k$ = function () {
    var digits = this.coefficient_1.abs_22cy_k$().toString();
    var sign = layoutSign(this);
    var tmp0 = fromInt(digits.length);
    // Inline function 'kotlin.Long.minus' call
    var other = this.decimalScale_1;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    var exp = subtract(this_0, fromInt(1));
    if (this.decimalScale_1 >= 0 && compare(exp, new Long(-6, -1)) >= 0)
      return canonicalPlain(this, digits, sign);
    // Inline function 'kotlin.Long.rem' call
    // Inline function 'kotlin.Long.plus' call
    var this_1 = modulo(exp, fromInt(3));
    // Inline function 'kotlin.Long.rem' call
    var this_2 = add(this_1, fromInt(3));
    var tmp$ret$4 = modulo(this_2, fromInt(3));
    var mod = convertToInt(tmp$ret$4);
    // Inline function 'kotlin.Long.minus' call
    var engineeringExp = subtract(exp, fromInt(mod));
    var body;
    if (this.signum_exb08b_k$() === 0) {
      var decimals = (3 - mod | 0) % 3 | 0;
      if (!(mod === 0)) {
        // Inline function 'kotlin.Long.plus' call
        var this_3 = engineeringExp;
        engineeringExp = add(this_3, fromInt(3));
      }
      body = decimals === 0 ? '0' : '0.' + repeat('0', decimals);
    } else {
      var before = mod + 1 | 0;
      body = digits.length <= before ? padEnd(digits, before, _Char___init__impl__6a9atx(48)) : substring_0(digits, 0, before) + '.' + substring(digits, before);
    }
    return (sign < 0 ? '-' : '') + body + (equalsLong(engineeringExp, new Long(0, 0)) ? '' : exponentText(Companion_getInstance_0(), engineeringExp));
  };
  protoOf(BigDecimal).toBigInteger_xwiad5_k$ = function () {
    if (this.signum_exb08b_k$() === 0)
      return Companion_getInstance_2().get_ZERO_wodlgx_k$();
    if (this.decimalScale_1 <= 0)
      return this.coefficient_1.multiply_9xrhei_k$(tenPow(Companion_getInstance_0(), negate(fromInt(this.decimalScale_1))));
    if (this.decimalScale_1 >= this.precision_mrc8zm_k$())
      return Companion_getInstance_2().get_ZERO_wodlgx_k$();
    return this.coefficient_1.divide_bsns5t_k$(tenPow(Companion_getInstance_0(), fromInt(this.decimalScale_1)));
  };
  protoOf(BigDecimal).toBigIntegerExact_538mey_k$ = function () {
    return this.setScale_xkfcvs_k$(0, 7).coefficient_1;
  };
  protoOf(BigDecimal).toInt_1tsl84_k$ = function () {
    return convertToInt(integerLowBits(this, 32));
  };
  protoOf(BigDecimal).toLong_edfucp_k$ = function () {
    return integerLowBits(this, 64);
  };
  protoOf(BigDecimal).toByte_edm0nx_k$ = function () {
    return toByte(this.toInt_1tsl84_k$());
  };
  protoOf(BigDecimal).toShort_ja8oqn_k$ = function () {
    return toShort(this.toInt_1tsl84_k$());
  };
  protoOf(BigDecimal).intValueExact_x1rjxf_k$ = function () {
    return convertToInt(narrowExact(this, new Long(-2147483648, -1), new Long(2147483647, 0)));
  };
  protoOf(BigDecimal).shortValueExact_q6yi0a_k$ = function () {
    return convertToShort(narrowExact(this, new Long(-32768, -1), new Long(32767, 0)));
  };
  protoOf(BigDecimal).byteValueExact_pqedrq_k$ = function () {
    return convertToByte(narrowExact(this, new Long(-128, -1), new Long(127, 0)));
  };
  protoOf(BigDecimal).longValueExact_akftqu_k$ = function () {
    var compact = this.coefficient_1.decimalCompactValue_llvq0o_k$();
    if (!(compact == null) && this.decimalScale_1 === 0)
      return compact;
    if (this.signum_exb08b_k$() === 0)
      return new Long(0, 0);
    var tmp0 = fromInt(this.precision_mrc8zm_k$());
    // Inline function 'kotlin.Long.minus' call
    var other = this.decimalScale_1;
    var tmp$ret$0 = subtract(tmp0, fromInt(other));
    if (compare(tmp$ret$0, new Long(0, 0)) <= 0)
      throw ArithmeticException_init_$Create$('Rounding necessary');
    var tmp0_0 = fromInt(this.precision_mrc8zm_k$());
    // Inline function 'kotlin.Long.minus' call
    var other_0 = this.decimalScale_1;
    var tmp$ret$1 = subtract(tmp0_0, fromInt(other_0));
    if (compare(tmp$ret$1, new Long(19, 0)) > 0)
      throw ArithmeticException_init_$Create$('Overflow');
    var integer = this.setScale_xkfcvs_k$(0, 7);
    if (integer.precision_mrc8zm_k$() >= 19 && integer.coefficient_1.bitLength_9mbxrh_k$() > 63)
      throw ArithmeticException_init_$Create$('Overflow');
    return integer.coefficient_1.toLong_edfucp_k$();
  };
  protoOf(BigDecimal).toDouble_ygsx0s_k$ = function () {
    return binaryValue(this, 53, -1022, 1023);
  };
  protoOf(BigDecimal).toFloat_jhbgwv_k$ = function () {
    return binaryValue(this, 24, -126, 127);
  };
  function _get_MAX_WORDS__he4zp9($this) {
    return $this.MAX_WORDS_1;
  }
  function compareLow($this, a, b) {
    var inductionVariable = get_lastIndex(b);
    if (0 <= inductionVariable)
      do {
        var j = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        if (!(a[j] === b[j]))
          return compareTo(a[j], b[j]);
      }
       while (0 <= inductionVariable);
    return 0;
  }
  function doubleResidue($this, value, modulus, gap) {
    var borrow = new Long(0, 0);
    var inductionVariable = 0;
    var last = modulus.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var j = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = fromInt(modulus[j]);
        // Inline function 'kotlin.Long.minus' call
        var other = value[j];
        var tmp$ret$0 = subtract(tmp0, fromInt(other));
        var difference = subtract(tmp$ret$0, borrow);
        gap[j] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
        borrow = compare(difference, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
      }
       while (inductionVariable <= last);
    if (compareLow($this, value, gap) >= 0) {
      borrow = new Long(0, 0);
      var inductionVariable_0 = 0;
      var last_0 = value.length - 1 | 0;
      if (inductionVariable_0 <= last_0)
        do {
          var j_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          var tmp0_0 = fromInt(value[j_0]);
          // Inline function 'kotlin.Long.minus' call
          var other_0 = gap[j_0];
          var tmp$ret$1 = subtract(tmp0_0, fromInt(other_0));
          var difference_0 = subtract(tmp$ret$1, borrow);
          value[j_0] = convertToInt(bitwiseAnd(difference_0, new Long(1073741823, 0)));
          borrow = compare(difference_0, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
        }
         while (inductionVariable_0 <= last_0);
    } else {
      var carry = new Long(0, 0);
      var inductionVariable_1 = 0;
      var last_1 = value.length - 1 | 0;
      if (inductionVariable_1 <= last_1)
        do {
          var j_1 = inductionVariable_1;
          inductionVariable_1 = inductionVariable_1 + 1 | 0;
          // Inline function 'kotlin.Long.times' call
          var this_0 = fromInt(value[j_1]);
          var tmp$ret$2 = multiply(this_0, fromInt(2));
          var sum = add(tmp$ret$2, carry);
          value[j_1] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
          carry = shiftRightUnsigned(sum, 30);
        }
         while (inductionVariable_1 <= last_1);
    }
  }
  function _get_modulus__p60tq2($this) {
    return $this.modulus_1;
  }
  function _get_rho__e6g054($this) {
    return $this.rho_1;
  }
  function _get_oneMont__314xwd($this) {
    return $this.oneMont_1;
  }
  function _get_r2__ndc8ln($this) {
    return $this.r2__1;
  }
  function Workspace(size) {
    this.scratch_1 = new Int32Array(size + 2 | 0);
    this.input_1 = new Int32Array(size);
    this.factor_1 = new Int32Array(size);
    this.result_1 = new Int32Array(size);
    this.next_1 = new Int32Array(size);
  }
  protoOf(Workspace).get_scratch_x4et5d_k$ = function () {
    return this.scratch_1;
  };
  protoOf(Workspace).get_input_it4gip_k$ = function () {
    return this.input_1;
  };
  protoOf(Workspace).get_factor_d7f9so_k$ = function () {
    return this.factor_1;
  };
  protoOf(Workspace).get_result_iyg5d2_k$ = function () {
    return this.result_1;
  };
  protoOf(Workspace).get_next_wor1vg_k$ = function () {
    return this.next_1;
  };
  function multiply_0($this, a, b, out, scratch) {
    var n = $this.modulus_1.length;
    fill(scratch, 0);
    var inductionVariable = 0;
    if (inductionVariable < n)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp;
        if (b == null) {
          tmp = i === 0 ? new Long(1, 0) : new Long(0, 0);
        } else {
          tmp = fromInt(b[i]);
        }
        var word = tmp;
        addProduct($this, a, word, scratch);
        var q = bitwiseAnd(multiply(fromInt(scratch[0]), $this.rho_1), new Long(1073741823, 0));
        addProduct($this, $this.modulus_1, q, scratch);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 <= n)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            scratch[j] = scratch[j + 1 | 0];
          }
           while (!(j === n));
        scratch[n + 1 | 0] = 0;
      }
       while (inductionVariable < n);
    if (!(scratch[n] === 0) || compareLow(Companion_getInstance_1(), scratch, $this.modulus_1) >= 0) {
      var borrow = new Long(0, 0);
      var inductionVariable_1 = 0;
      if (inductionVariable_1 < n)
        do {
          var j_0 = inductionVariable_1;
          inductionVariable_1 = inductionVariable_1 + 1 | 0;
          var tmp0 = fromInt(scratch[j_0]);
          // Inline function 'kotlin.Long.minus' call
          var other = $this.modulus_1[j_0];
          var tmp$ret$0 = subtract(tmp0, fromInt(other));
          var difference = subtract(tmp$ret$0, borrow);
          scratch[j_0] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
          borrow = compare(difference, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
        }
         while (inductionVariable_1 < n);
      scratch[n] = convertToInt(subtract(fromInt(scratch[n]), borrow));
    }
    // Inline function 'kotlin.collections.copyInto' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_0 = scratch;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp_0, out, 0, 0, n);
  }
  function addProduct($this, a, word, scratch) {
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = a.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var j = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = multiply(fromInt(a[j]), word);
        // Inline function 'kotlin.Long.plus' call
        var other = scratch[j];
        var tmp$ret$0 = add(tmp0, fromInt(other));
        var sum = add(tmp$ret$0, carry);
        scratch[j] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(sum, 30);
      }
       while (inductionVariable <= last);
    var high = add(fromInt(scratch[a.length]), carry);
    scratch[a.length] = convertToInt(bitwiseAnd(high, new Long(1073741823, 0)));
    scratch[a.length + 1 | 0] = convertToInt(add(fromInt(scratch[a.length + 1 | 0]), shiftRightUnsigned(high, 30)));
  }
  function Companion_0() {
    Companion_instance_0 = this;
    this.MAX_WORDS_1 = 4096;
  }
  protoOf(Companion_0).create_x2awi_k$ = function (m) {
    var n = m.words_1.length;
    if (m.sign_1 <= 0 || n === 0 || n > 4096 || (m.words_1[0] & 1) === 0 || (n === 1 && m.words_1[0] === 1))
      return null;
    var size = fromInt(n);
    // Inline function 'kotlin.Long.plus' call
    var scratchCells = add(size, fromInt(2));
    // Inline function 'kotlin.Long.times' call
    var this_0 = new Long(2, 0);
    var tmp$ret$1 = multiply(this_0, fromInt(30));
    var setupSteps = multiply(tmp$ret$1, size);
    // Inline function 'kotlin.Long.plus' call
    var this_1 = multiply(new Long(16, 0), size);
    var payloadCells = add(this_1, fromInt(8));
    var payloadBytes = multiply(new Long(4, 0), payloadCells);
    if (compare(scratchCells, new Long(2147483647, 0)) > 0 || compare(setupSteps, new Long(2147483647, 0)) > 0 || compare(payloadCells, new Long(2147483647, 0)) > 0 || compare(payloadBytes, new Long(2147483647, 0)) > 0)
      return null;
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var modulus = m.words_1.slice();
    var inverse = new Long(1, 0);
    var inductionVariable = 1;
    if (inductionVariable < 30)
      do {
        var bit = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!equalsLong(bitwiseAnd(multiply(fromInt(modulus[0]), inverse), shiftLeft(new Long(1, 0), bit)), new Long(0, 0)))
          inverse = add(inverse, shiftLeft(new Long(1, 0), bit));
      }
       while (inductionVariable < 30);
    var rho = bitwiseAnd(subtract(new Long(1073741824, 0), inverse), new Long(1073741823, 0));
    var oneMont = new Int32Array(n);
    var r2 = new Int32Array(n);
    var gap = new Int32Array(n);
    r2[0] = 1;
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$5 = divide(setupSteps, fromInt(2));
    var half = convertToInt(tmp$ret$5);
    var inductionVariable_0 = 0;
    var last = convertToInt(setupSteps);
    if (inductionVariable_0 < last)
      do {
        var step = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        doubleResidue(this, r2, modulus, gap);
        if ((step + 1 | 0) === half) {
          // Inline function 'kotlin.collections.copyInto' call
          var endIndex = r2.length;
          // Inline function 'kotlin.js.unsafeCast' call
          // Inline function 'kotlin.js.asDynamic' call
          var tmp = r2;
          // Inline function 'kotlin.js.unsafeCast' call
          // Inline function 'kotlin.js.asDynamic' call
          arrayCopy(tmp, oneMont, 0, 0, endIndex);
        }
      }
       while (inductionVariable_0 < last);
    return new OddModulusContext(modulus, rho, oneMont, r2);
  };
  var Companion_instance_0;
  function Companion_getInstance_1() {
    if (Companion_instance_0 == null)
      new Companion_0();
    return Companion_instance_0;
  }
  function _get_serialVersionUID__fhggm9_0($this) {
    return $this.serialVersionUID_1;
  }
  function _get_LIMB_BITS__218cpq($this) {
    return $this.LIMB_BITS_1;
  }
  function _get_MASK__cs1xpb($this) {
    return $this.MASK_1;
  }
  function _get_SMALL_VALUES__lfklwv($this) {
    return $this.SMALL_VALUES_1;
  }
  function _get_DETERMINISTIC_PRIME_LIMIT__2ssyeb($this) {
    return $this.DETERMINISTIC_PRIME_LIMIT_1;
  }
  function _get_DETERMINISTIC_PRIME_BASES__21xvd0($this) {
    return $this.DETERMINISTIC_PRIME_BASES_1;
  }
  function generatePrime($this, bitLength, certainty, rnd) {
    if (bitLength < 2)
      throw ArithmeticException_init_$Create$('bitLength < 2');
    PrimeSearchLimits_getInstance().checkBitLength_rls9oj_k$(bitLength);
    return generatePrime_0($this, bitLength, certainty, asCommonRandom(rnd));
  }
  function randomBits($this, numBits, rnd) {
    // Inline function 'kotlin.require' call
    if (!(numBits >= 0)) {
      var message = 'numBits must be non-negative';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (numBits === 0)
      return $this.ZERO_1;
    return randomBits_0($this, numBits, asCommonRandom(rnd));
  }
  function generatePrime_0($this, bitLength, certainty, rnd) {
    if (bitLength < 2)
      throw ArithmeticException_init_$Create$('bitLength < 2');
    PrimeSearchLimits_getInstance().checkBitLength_rls9oj_k$(bitLength);
    if (bitLength === 2)
      return BigInteger_init_$Create$($this.valueOf_wwtjy2_k$(fromInt(rnd.nextInt_ak696k_k$(2, 4))));
    var rounds = PrimalityCertainty_getInstance().generationRounds_whenz7_k$(bitLength, certainty);
    while (true) {
      var n = randomBits_0($this, bitLength, rnd).setBit_hdw09f_k$(bitLength - 1 | 0).setBit_hdw09f_k$(0);
      if (rounds === 0 || passesPrimeTest(n, fromInt(rounds)))
        return n;
    }
  }
  function randomBits_0($this, numBits, rnd) {
    // Inline function 'kotlin.require' call
    if (!(numBits >= 0)) {
      var message = 'numBits must be non-negative';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(fromInt(numBits), new Long(7, 0));
    var tmp$ret$2 = divide(this_0, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$2));
    rnd.nextBytes_ln07bs_k$(bytes);
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(bytes.length === 0)) {
      bytes[0] = toByte(bytes[0] & (255 >>> ((8 - (numBits % 8 | 0) | 0) % 8 | 0) | 0));
    }
    return fromBytes($this, bytes, 0, bytes.length, false);
  }
  function parse_0($this, value, radix) {
    if (!(2 <= radix ? radix <= 36 : false))
      throw NumberFormatException_init_$Create$('Radix out of range');
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(value) === 0)
      throw NumberFormatException_init_$Create$('Zero length BigInteger');
    if (indexOf(value, _Char___init__impl__6a9atx(45), 1) >= 0 || indexOf(value, _Char___init__impl__6a9atx(43), 1) >= 0)
      throw NumberFormatException_init_$Create$('Illegal embedded sign character');
    var start = 0;
    var sign = 1;
    if (charCodeAt(value, 0) === _Char___init__impl__6a9atx(45) || charCodeAt(value, 0) === _Char___init__impl__6a9atx(43)) {
      sign = charCodeAt(value, 0) === _Char___init__impl__6a9atx(45) ? -1 : 1;
      start = start + 1 | 0;
    }
    if (start === value.length)
      throw NumberFormatException_init_$Create$('Zero length BigInteger');
    while (start < value.length && digitToIntOrNull(charCodeAt(value, start), radix) === 0) {
      start = start + 1 | 0;
    }
    if (start === value.length)
      return $this.ZERO_1;
    if (MagnitudeLimits_getInstance().parserDefinitelyOverflows_zbidp1_k$(value.length - start | 0, radix)) {
      var inductionVariable = start;
      var last = value.length;
      if (inductionVariable < last)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (digitToIntOrNull(charCodeAt(value, i), radix) == null) {
            invalidIntegerDigit($this, value, radix, start, i);
          }
        }
         while (inductionVariable < last);
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    }
    var n = $this.ZERO_1;
    var base = $this.valueOf_wwtjy2_k$(fromInt(radix));
    var inductionVariable_0 = start;
    var last_0 = value.length;
    if (inductionVariable_0 < last_0)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        var tmp0_elvis_lhs = digitToIntOrNull(charCodeAt(value, i_0), radix);
        var tmp;
        if (tmp0_elvis_lhs == null) {
          invalidIntegerDigit($this, value, radix, start, i_0);
        } else {
          tmp = tmp0_elvis_lhs;
        }
        var digit = tmp;
        n = n.multiply_9xrhei_k$(base).add_gx3ep5_k$($this.valueOf_wwtjy2_k$(fromInt(digit)));
      }
       while (inductionVariable_0 < last_0);
    return sign < 0 ? n.negate_hcqk8u_k$() : n;
  }
  function invalidIntegerDigit($this, value, radix, start, invalid) {
    var power = fromInt(radix);
    var width = 1;
    $l$loop: while (true) {
      // Inline function 'kotlin.Long.times' call
      var this_0 = power;
      var tmp$ret$0 = multiply(this_0, fromInt(radix));
      if (!(compare(tmp$ret$0, new Long(2147483647, 0)) <= 0)) {
        break $l$loop;
      }
      // Inline function 'kotlin.Long.times' call
      var this_1 = power;
      power = multiply(this_1, fromInt(radix));
      width = width + 1 | 0;
    }
    var firstWidth = (((value.length - start | 0) - 1 | 0) % width | 0) + 1 | 0;
    var groupStart = invalid < (start + firstWidth | 0) ? start : (start + firstWidth | 0) + imul(((invalid - start | 0) - firstWidth | 0) / width | 0, width) | 0;
    var groupEnd = groupStart === start ? start + firstWidth | 0 : groupStart + width | 0;
    var suffix = radix === 10 ? '' : ' under radix ' + radix;
    throw NumberFormatException_init_$Create$('For input string: "' + substring_0(value, groupStart, groupEnd) + '"' + suffix);
  }
  function fromBytes($this, bytes, off, len, twos) {
    var tmp;
    if (twos) {
      // Inline function 'kotlin.collections.isEmpty' call
      tmp = bytes.length === 0;
    } else {
      tmp = false;
    }
    if (tmp)
      throw NumberFormatException_init_$Create$('Zero length BigInteger');
    checkBounds($this, bytes, off, len);
    if (len === 0)
      return $this.ZERO_1;
    var negative = twos && bytes[off] < 0;
    var start = off;
    var end = off + len | 0;
    if (negative) {
      while ((end - start | 0) > 1 && bytes[start] === -1) {
        start = start + 1 | 0;
      }
    } else {
      while (start < end && bytes[start] === 0) {
        start = start + 1 | 0;
      }
      if (start === end)
        return $this.ZERO_1;
    }
    var result = new Int32Array(MagnitudeLimits_getInstance().packedWords_b6v23i_k$(end - start | 0, negative));
    var buffer = new Long(0, 0);
    var bufferedBits = 0;
    var word = 0;
    var carry = negative ? 1 : 0;
    var inductionVariable = end - 1 | 0;
    var last = start;
    if (last <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var raw = bytes[i] & 255;
        var converted = negative ? (raw ^ 255) + carry | 0 : raw;
        if (negative)
          carry = converted >>> 8 | 0;
        buffer = bitwiseOr(buffer, shiftLeft(fromInt(converted & 255), bufferedBits));
        bufferedBits = bufferedBits + 8 | 0;
        if (bufferedBits >= 30) {
          var _unary__edvuaz = word;
          word = _unary__edvuaz + 1 | 0;
          result[_unary__edvuaz] = convertToInt(bitwiseAnd(buffer, new Long(1073741823, 0)));
          buffer = shiftRightUnsigned(buffer, 30);
          bufferedBits = bufferedBits - 30 | 0;
        }
      }
       while (!(i === last));
    buffer = bitwiseOr(buffer, shiftLeft(fromInt(carry), bufferedBits));
    if (!equalsLong(buffer, new Long(0, 0))) {
      result[word] = convertToInt(buffer);
    }
    return normalized($this, negative ? -1 : 1, result);
  }
  function signedBytes($this, signum, bytes, off, len) {
    if (!(-1 <= signum ? signum <= 1 : false))
      throw NumberFormatException_init_$Create$('Invalid signum value');
    var magnitude = bytes;
    if (signum === 0) {
      checkBounds($this, magnitude, off, len);
      var inductionVariable = off;
      var last = off + len | 0;
      if (inductionVariable < last)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!(magnitude[i] === 0))
            throw NumberFormatException_init_$Create$('signum-magnitude mismatch');
        }
         while (inductionVariable < last);
      return $this.ZERO_1;
    }
    var n = fromBytes($this, magnitude, off, len, false);
    return signum < 0 ? n.negate_hcqk8u_k$() : n;
  }
  function checkBounds($this, bytes, off, len) {
    if (off < 0 || len < 0 || off > (bytes.length - len | 0))
      throw IndexOutOfBoundsException_init_$Create$('Range [' + off + ', ' + off + ' + ' + len + ') out of bounds for length ' + bytes.length);
  }
  function normalized($this, sign, words) {
    var length = words.length;
    while (length > 0 && words[length - 1 | 0] === 0) {
      length = length - 1 | 0;
    }
    if (length === 0)
      return $this.ZERO_1;
    MagnitudeLimits_getInstance().checkedBitLength_5hvey4_k$(length, words[length - 1 | 0]);
    return new BigInteger(sign, length === words.length ? words : copyOf(words, length));
  }
  function compareMagnitude_0($this, a, b) {
    if (!(a.length === b.length))
      return compareTo(a.length, b.length);
    var inductionVariable = a.length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        if (!(a[i] === b[i]))
          return compareTo(a[i], b[i]);
      }
       while (0 <= inductionVariable);
    return 0;
  }
  function addMagnitude($this, a, b) {
    var tmp0 = a.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_0 = b.length;
    var tmp$ret$0 = Math.max(tmp0, b_0);
    var out = new Int32Array(tmp$ret$0 + 1 | 0);
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = get_lastIndex(out);
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.collections.getOrElse' call
        var tmp;
        if (0 <= i ? i <= (a.length - 1 | 0) : false) {
          tmp = a[i];
        } else {
          tmp = 0;
        }
        var tmp$ret$1 = tmp;
        var tmp0_0 = fromInt(tmp$ret$1);
        // Inline function 'kotlin.collections.getOrElse' call
        var tmp_0;
        if (0 <= i ? i <= (b.length - 1 | 0) : false) {
          tmp_0 = b[i];
        } else {
          tmp_0 = 0;
        }
        // Inline function 'kotlin.Long.plus' call
        var other = tmp_0;
        var tmp$ret$5 = add(tmp0_0, fromInt(other));
        var n = add(tmp$ret$5, carry);
        out[i] = convertToInt(bitwiseAnd(n, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(n, 30);
      }
       while (inductionVariable < last);
    out[get_lastIndex(out)] = convertToInt(carry);
    return out;
  }
  function subtractMagnitude($this, a, b) {
    var out = new Int32Array(a.length);
    var borrow = new Long(0, 0);
    var inductionVariable = 0;
    var last = a.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = fromInt(a[i]);
        // Inline function 'kotlin.collections.getOrElse' call
        var tmp;
        if (0 <= i ? i <= (b.length - 1 | 0) : false) {
          tmp = b[i];
        } else {
          tmp = 0;
        }
        // Inline function 'kotlin.Long.minus' call
        var other = tmp;
        var tmp$ret$2 = subtract(tmp0, fromInt(other));
        var n = subtract(tmp$ret$2, borrow);
        out[i] = convertToInt(bitwiseAnd(n, new Long(1073741823, 0)));
        borrow = compare(n, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
      }
       while (inductionVariable <= last);
    return out;
  }
  function _get_sign__ddo3e6($this) {
    return $this.sign_1;
  }
  function _get_words__9f9arc($this) {
    return $this.words_1;
  }
  function BigInteger_init_$Init$(value, $this) {
    BigInteger.call($this, value.sign_1, value.words_1);
    return $this;
  }
  function BigInteger_init_$Create$(value) {
    return BigInteger_init_$Init$(value, objectCreate(protoOf(BigInteger)));
  }
  function readObject_0($this, stream) {
    restoreSerializedFields(stream);
    var restored = $this.words_1;
    var tmp;
    var tmp_0;
    var tmp_1;
    var tmp_2;
    if (restored == null) {
      tmp_2 = true;
    } else {
      var containsArg = $this.sign_1;
      tmp_2 = !(-1 <= containsArg ? containsArg <= 1 : false);
    }
    if (tmp_2) {
      tmp_1 = true;
    } else {
      var tmp_3 = $this.sign_1 === 0;
      // Inline function 'kotlin.collections.isEmpty' call
      tmp_1 = !(tmp_3 === (restored.length === 0));
    }
    if (tmp_1) {
      tmp_0 = true;
    } else {
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.collections.any' call
        var inductionVariable = 0;
        var last_0 = restored.length;
        while (inductionVariable < last_0) {
          var element = restored[inductionVariable];
          inductionVariable = inductionVariable + 1 | 0;
          if (element < 0 || compare(fromInt(element), new Long(1073741823, 0)) > 0) {
            tmp$ret$1 = true;
            break $l$block;
          }
        }
        tmp$ret$1 = false;
      }
      tmp_0 = tmp$ret$1;
    }
    if (tmp_0) {
      tmp = true;
    } else {
      tmp = lastOrNull(restored) === 0;
    }
    if (tmp) {
      invalidSerializedState('Invalid BigInteger representation');
    }
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(restored.length === 0)) {
      try {
        MagnitudeLimits_getInstance().checkedBitLength_5hvey4_k$(restored.length, last(restored));
      } catch ($p) {
        if ($p instanceof ArithmeticException) {
          var _unused_var__etf5q3 = $p;
          invalidSerializedState('BigInteger overflow');
        } else {
          throw $p;
        }
      }
    }
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$5 = restored.slice();
    restoreSerializedMagnitude($this, tmp$ret$5);
  }
  function readObjectNoData_0($this) {
    invalidSerializedState('Missing BigInteger data');
  }
  function BigInteger_init_$Init$_0(value, $this) {
    BigInteger_init_$Init$_1(value, 10, $this);
    return $this;
  }
  function BigInteger_init_$Create$_0(value) {
    return BigInteger_init_$Init$_0(value, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_1(value, radix, $this) {
    BigInteger_init_$Init$(parse_0(Companion_getInstance_2(), value, radix), $this);
    return $this;
  }
  function BigInteger_init_$Create$_1(value, radix) {
    return BigInteger_init_$Init$_1(value, radix, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_2(value, $this) {
    BigInteger_init_$Init$(fromBytes(Companion_getInstance_2(), value, 0, value.length, true), $this);
    return $this;
  }
  function BigInteger_init_$Create$_2(value) {
    return BigInteger_init_$Init$_2(value, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_3(value, off, len, $this) {
    BigInteger_init_$Init$(fromBytes(Companion_getInstance_2(), value, off, len, true), $this);
    return $this;
  }
  function BigInteger_init_$Create$_3(value, off, len) {
    return BigInteger_init_$Init$_3(value, off, len, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_4(signum, magnitude, $this) {
    BigInteger_init_$Init$_5(signum, magnitude, 0, magnitude.length, $this);
    return $this;
  }
  function BigInteger_init_$Create$_4(signum, magnitude) {
    return BigInteger_init_$Init$_4(signum, magnitude, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_5(signum, magnitude, off, len, $this) {
    BigInteger_init_$Init$(signedBytes(Companion_getInstance_2(), signum, magnitude, off, len), $this);
    return $this;
  }
  function BigInteger_init_$Create$_5(signum, magnitude, off, len) {
    return BigInteger_init_$Init$_5(signum, magnitude, off, len, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_6(numBits, rnd, $this) {
    BigInteger_init_$Init$(randomBits(Companion_getInstance_2(), numBits, rnd), $this);
    return $this;
  }
  function BigInteger_init_$Create$_6(numBits, rnd) {
    return BigInteger_init_$Init$_6(numBits, rnd, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_7(bitLength, certainty, rnd, $this) {
    BigInteger_init_$Init$(generatePrime(Companion_getInstance_2(), bitLength, certainty, rnd), $this);
    return $this;
  }
  function BigInteger_init_$Create$_7(bitLength, certainty, rnd) {
    return BigInteger_init_$Init$_7(bitLength, certainty, rnd, objectCreate(protoOf(BigInteger)));
  }
  function quotientStored($this, value) {
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'io.heapy.krogu.math.BigInteger.selectStoredDivision' call
      if (value.sign_1 === 0)
        throw ArithmeticException_init_$Create$('BigInteger divide by zero');
      if (compareMagnitude_0(Companion_getInstance_2(), $this.words_1, value.words_1) < 0) {
        false ? normalized(Companion_getInstance_2(), $this.sign_1, $this.words_1) : Companion_getInstance_2().ZERO_1;
        tmp$ret$0 = Companion_getInstance_2().ZERO_1;
        break $l$block_0;
      }
      if (value.words_1.length === 1) {
        var result = true ? new Int32Array($this.words_1.length) : null;
        var remainder = new Long(0, 0);
        var inductionVariable = $this.words_1.length - 1 | 0;
        if (0 <= inductionVariable)
          do {
            var i = inductionVariable;
            inductionVariable = inductionVariable + -1 | 0;
            var tmp0 = shiftLeft(remainder, 30);
            // Inline function 'kotlin.Long.plus' call
            var other = $this.words_1[i];
            var part = add(tmp0, fromInt(other));
            if (!(result == null)) {
              // Inline function 'kotlin.Long.div' call
              var other_0 = value.words_1[0];
              var tmp$ret$3 = divide(part, fromInt(other_0));
              result[i] = convertToInt(tmp$ret$3);
            }
            // Inline function 'kotlin.Long.rem' call
            var other_1 = value.words_1[0];
            remainder = modulo(part, fromInt(other_1));
          }
           while (0 <= inductionVariable);
        var tmp0_0 = !(result == null) ? normalized(Companion_getInstance_2(), imul($this.sign_1, value.sign_1), result) : Companion_getInstance_2().ZERO_1;
        var tmp;
        if (false) {
          var tmp_0 = Companion_getInstance_2();
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$5 = new Int32Array([convertToInt(remainder)]);
          tmp = normalized(tmp_0, $this.sign_1, tmp$ret$5);
        } else {
          tmp = Companion_getInstance_2().ZERO_1;
        }
        tmp$ret$0 = tmp0_0;
        break $l$block_0;
      }
      var n = value.words_1.length;
      // Inline function 'kotlin.countLeadingZeroBits' call
      var this_0 = last(value.words_1);
      var shift = clz32(this_0) - 2 | 0;
      var divisor = new Int32Array(n);
      normalizeStoredDivision($this, value.words_1, divisor, shift);
      var dividend = new Int32Array($this.words_1.length + 1 | 0);
      dividend[$this.words_1.length] = normalizeStoredDivision($this, $this.words_1, dividend, shift);
      var quotient = true ? new Int32Array(($this.words_1.length - n | 0) + 1 | 0) : null;
      // Inline function 'kotlin.Long.plus' call
      var this_1 = new Long(1073741823, 0);
      var radix = add(this_1, fromInt(1));
      var high = fromInt(divisor[n - 1 | 0]);
      var next = fromInt(divisor[n - 2 | 0]);
      var inductionVariable_0 = $this.words_1.length - n | 0;
      if (0 <= inductionVariable_0)
        do {
          var j = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + -1 | 0;
          var tmp0_1 = shiftLeft(fromInt(dividend[j + n | 0]), 30);
          // Inline function 'kotlin.Long.plus' call
          var other_2 = dividend[(j + n | 0) - 1 | 0];
          var top = add(tmp0_1, fromInt(other_2));
          var tmp0_2 = divide(top, high);
          // Inline function 'kotlin.comparisons.minOf' call
          var b = new Long(1073741823, 0);
          var estimate = compare(tmp0_2, b) <= 0 ? tmp0_2 : b;
          var residual = subtract(top, multiply(estimate, high));
          $l$loop: while (true) {
            var tmp_1;
            if (compare(residual, radix) < 0) {
              var tmp_2 = multiply(estimate, next);
              var tmp0_3 = shiftLeft(residual, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_3 = dividend[(j + n | 0) - 2 | 0];
              var tmp$ret$11 = add(tmp0_3, fromInt(other_3));
              tmp_1 = compare(tmp_2, tmp$ret$11) > 0;
            } else {
              tmp_1 = false;
            }
            if (!tmp_1) {
              break $l$loop;
            }
            var _unary__edvuaz = estimate;
            estimate = subtract(_unary__edvuaz, get_ONE());
            residual = add(residual, high);
          }
          var borrow = new Long(0, 0);
          var inductionVariable_1 = 0;
          if (inductionVariable_1 < n)
            do {
              var i_0 = inductionVariable_1;
              inductionVariable_1 = inductionVariable_1 + 1 | 0;
              var tmp0_4 = estimate;
              // Inline function 'kotlin.Long.times' call
              var other_4 = divisor[i_0];
              var tmp$ret$12 = multiply(tmp0_4, fromInt(other_4));
              var product = add(tmp$ret$12, borrow);
              var difference = subtract(fromInt(dividend[j + i_0 | 0]), bitwiseAnd(product, new Long(1073741823, 0)));
              dividend[j + i_0 | 0] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
              var tmp0_5 = shiftRightUnsigned(product, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_5 = compare(difference, new Long(0, 0)) < 0 ? 1 : 0;
              borrow = add(tmp0_5, fromInt(other_5));
            }
             while (inductionVariable_1 < n);
          var difference_0 = subtract(fromInt(dividend[j + n | 0]), borrow);
          dividend[j + n | 0] = convertToInt(bitwiseAnd(difference_0, new Long(1073741823, 0)));
          if (compare(difference_0, new Long(0, 0)) < 0) {
            var _unary__edvuaz_0 = estimate;
            estimate = subtract(_unary__edvuaz_0, get_ONE());
            var carry = new Long(0, 0);
            var inductionVariable_2 = 0;
            if (inductionVariable_2 < n)
              do {
                var i_1 = inductionVariable_2;
                inductionVariable_2 = inductionVariable_2 + 1 | 0;
                var tmp0_6 = fromInt(dividend[j + i_1 | 0]);
                // Inline function 'kotlin.Long.plus' call
                var other_6 = divisor[i_1];
                var tmp$ret$14 = add(tmp0_6, fromInt(other_6));
                var sum = add(tmp$ret$14, carry);
                dividend[j + i_1 | 0] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
                carry = shiftRightUnsigned(sum, 30);
              }
               while (inductionVariable_2 < n);
            dividend[j + n | 0] = convertToInt(bitwiseAnd(add(fromInt(dividend[j + n | 0]), carry), new Long(1073741823, 0)));
          }
          if (!(quotient == null)) {
            quotient[j] = convertToInt(estimate);
          }
        }
         while (0 <= inductionVariable_0);
      var remainder_0 = false ? new Int32Array(n) : null;
      if (!(remainder_0 == null)) {
        var inductionVariable_3 = 0;
        if (inductionVariable_3 < n)
          do {
            var i_2 = inductionVariable_3;
            inductionVariable_3 = inductionVariable_3 + 1 | 0;
            remainder_0[i_2] = shift === 0 ? dividend[i_2] : dividend[i_2] >>> shift | 0 | convertToInt(bitwiseAnd(shiftLeft(fromInt(dividend[i_2 + 1 | 0]), 30 - shift | 0), new Long(1073741823, 0)));
          }
           while (inductionVariable_3 < n);
      }
      !(remainder_0 == null) ? normalized(Companion_getInstance_2(), $this.sign_1, remainder_0) : Companion_getInstance_2().ZERO_1;
      tmp$ret$0 = !(quotient == null) ? normalized(Companion_getInstance_2(), imul($this.sign_1, value.sign_1), quotient) : Companion_getInstance_2().ZERO_1;
    }
    return tmp$ret$0;
  }
  function remainderStored($this, value) {
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'io.heapy.krogu.math.BigInteger.selectStoredDivision' call
      if (value.sign_1 === 0)
        throw ArithmeticException_init_$Create$('BigInteger divide by zero');
      if (compareMagnitude_0(Companion_getInstance_2(), $this.words_1, value.words_1) < 0) {
        Companion_getInstance_2().ZERO_1;
        tmp$ret$0 = true ? normalized(Companion_getInstance_2(), $this.sign_1, $this.words_1) : Companion_getInstance_2().ZERO_1;
        break $l$block_0;
      }
      if (value.words_1.length === 1) {
        var result = false ? new Int32Array($this.words_1.length) : null;
        var remainder = new Long(0, 0);
        var inductionVariable = $this.words_1.length - 1 | 0;
        if (0 <= inductionVariable)
          do {
            var i = inductionVariable;
            inductionVariable = inductionVariable + -1 | 0;
            var tmp0 = shiftLeft(remainder, 30);
            // Inline function 'kotlin.Long.plus' call
            var other = $this.words_1[i];
            var part = add(tmp0, fromInt(other));
            if (!(result == null)) {
              // Inline function 'kotlin.Long.div' call
              var other_0 = value.words_1[0];
              var tmp$ret$3 = divide(part, fromInt(other_0));
              result[i] = convertToInt(tmp$ret$3);
            }
            // Inline function 'kotlin.Long.rem' call
            var other_1 = value.words_1[0];
            remainder = modulo(part, fromInt(other_1));
          }
           while (0 <= inductionVariable);
        !(result == null) ? normalized(Companion_getInstance_2(), imul($this.sign_1, value.sign_1), result) : Companion_getInstance_2().ZERO_1;
        var tmp;
        if (true) {
          var tmp_0 = Companion_getInstance_2();
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$5 = new Int32Array([convertToInt(remainder)]);
          tmp = normalized(tmp_0, $this.sign_1, tmp$ret$5);
        } else {
          tmp = Companion_getInstance_2().ZERO_1;
        }
        tmp$ret$0 = tmp;
        break $l$block_0;
      }
      var n = value.words_1.length;
      // Inline function 'kotlin.countLeadingZeroBits' call
      var this_0 = last(value.words_1);
      var shift = clz32(this_0) - 2 | 0;
      var divisor = new Int32Array(n);
      normalizeStoredDivision($this, value.words_1, divisor, shift);
      var dividend = new Int32Array($this.words_1.length + 1 | 0);
      dividend[$this.words_1.length] = normalizeStoredDivision($this, $this.words_1, dividend, shift);
      var quotient = false ? new Int32Array(($this.words_1.length - n | 0) + 1 | 0) : null;
      // Inline function 'kotlin.Long.plus' call
      var this_1 = new Long(1073741823, 0);
      var radix = add(this_1, fromInt(1));
      var high = fromInt(divisor[n - 1 | 0]);
      var next = fromInt(divisor[n - 2 | 0]);
      var inductionVariable_0 = $this.words_1.length - n | 0;
      if (0 <= inductionVariable_0)
        do {
          var j = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + -1 | 0;
          var tmp0_0 = shiftLeft(fromInt(dividend[j + n | 0]), 30);
          // Inline function 'kotlin.Long.plus' call
          var other_2 = dividend[(j + n | 0) - 1 | 0];
          var top = add(tmp0_0, fromInt(other_2));
          var tmp0_1 = divide(top, high);
          // Inline function 'kotlin.comparisons.minOf' call
          var b = new Long(1073741823, 0);
          var estimate = compare(tmp0_1, b) <= 0 ? tmp0_1 : b;
          var residual = subtract(top, multiply(estimate, high));
          $l$loop: while (true) {
            var tmp_1;
            if (compare(residual, radix) < 0) {
              var tmp_2 = multiply(estimate, next);
              var tmp0_2 = shiftLeft(residual, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_3 = dividend[(j + n | 0) - 2 | 0];
              var tmp$ret$11 = add(tmp0_2, fromInt(other_3));
              tmp_1 = compare(tmp_2, tmp$ret$11) > 0;
            } else {
              tmp_1 = false;
            }
            if (!tmp_1) {
              break $l$loop;
            }
            var _unary__edvuaz = estimate;
            estimate = subtract(_unary__edvuaz, get_ONE());
            residual = add(residual, high);
          }
          var borrow = new Long(0, 0);
          var inductionVariable_1 = 0;
          if (inductionVariable_1 < n)
            do {
              var i_0 = inductionVariable_1;
              inductionVariable_1 = inductionVariable_1 + 1 | 0;
              var tmp0_3 = estimate;
              // Inline function 'kotlin.Long.times' call
              var other_4 = divisor[i_0];
              var tmp$ret$12 = multiply(tmp0_3, fromInt(other_4));
              var product = add(tmp$ret$12, borrow);
              var difference = subtract(fromInt(dividend[j + i_0 | 0]), bitwiseAnd(product, new Long(1073741823, 0)));
              dividend[j + i_0 | 0] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
              var tmp0_4 = shiftRightUnsigned(product, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_5 = compare(difference, new Long(0, 0)) < 0 ? 1 : 0;
              borrow = add(tmp0_4, fromInt(other_5));
            }
             while (inductionVariable_1 < n);
          var difference_0 = subtract(fromInt(dividend[j + n | 0]), borrow);
          dividend[j + n | 0] = convertToInt(bitwiseAnd(difference_0, new Long(1073741823, 0)));
          if (compare(difference_0, new Long(0, 0)) < 0) {
            var _unary__edvuaz_0 = estimate;
            estimate = subtract(_unary__edvuaz_0, get_ONE());
            var carry = new Long(0, 0);
            var inductionVariable_2 = 0;
            if (inductionVariable_2 < n)
              do {
                var i_1 = inductionVariable_2;
                inductionVariable_2 = inductionVariable_2 + 1 | 0;
                var tmp0_5 = fromInt(dividend[j + i_1 | 0]);
                // Inline function 'kotlin.Long.plus' call
                var other_6 = divisor[i_1];
                var tmp$ret$14 = add(tmp0_5, fromInt(other_6));
                var sum = add(tmp$ret$14, carry);
                dividend[j + i_1 | 0] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
                carry = shiftRightUnsigned(sum, 30);
              }
               while (inductionVariable_2 < n);
            dividend[j + n | 0] = convertToInt(bitwiseAnd(add(fromInt(dividend[j + n | 0]), carry), new Long(1073741823, 0)));
          }
          if (!(quotient == null)) {
            quotient[j] = convertToInt(estimate);
          }
        }
         while (0 <= inductionVariable_0);
      var remainder_0 = true ? new Int32Array(n) : null;
      if (!(remainder_0 == null)) {
        var inductionVariable_3 = 0;
        if (inductionVariable_3 < n)
          do {
            var i_2 = inductionVariable_3;
            inductionVariable_3 = inductionVariable_3 + 1 | 0;
            remainder_0[i_2] = shift === 0 ? dividend[i_2] : dividend[i_2] >>> shift | 0 | convertToInt(bitwiseAnd(shiftLeft(fromInt(dividend[i_2 + 1 | 0]), 30 - shift | 0), new Long(1073741823, 0)));
          }
           while (inductionVariable_3 < n);
      }
      !(quotient == null) ? normalized(Companion_getInstance_2(), imul($this.sign_1, value.sign_1), quotient) : Companion_getInstance_2().ZERO_1;
      tmp$ret$0 = !(remainder_0 == null) ? normalized(Companion_getInstance_2(), $this.sign_1, remainder_0) : Companion_getInstance_2().ZERO_1;
    }
    return tmp$ret$0;
  }
  function divideStored($this, value) {
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'io.heapy.krogu.math.BigInteger.selectStoredDivision' call
      if (value.sign_1 === 0)
        throw ArithmeticException_init_$Create$('BigInteger divide by zero');
      if (compareMagnitude_0(Companion_getInstance_2(), $this.words_1, value.words_1) < 0) {
        // Inline function 'kotlin.arrayOf' call
        // Inline function 'kotlin.js.unsafeCast' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp$ret$0 = [Companion_getInstance_2().ZERO_1, true ? normalized(Companion_getInstance_2(), $this.sign_1, $this.words_1) : Companion_getInstance_2().ZERO_1];
        break $l$block_0;
      }
      if (value.words_1.length === 1) {
        var result = true ? new Int32Array($this.words_1.length) : null;
        var remainder = new Long(0, 0);
        var inductionVariable = $this.words_1.length - 1 | 0;
        if (0 <= inductionVariable)
          do {
            var i = inductionVariable;
            inductionVariable = inductionVariable + -1 | 0;
            var tmp0 = shiftLeft(remainder, 30);
            // Inline function 'kotlin.Long.plus' call
            var other = $this.words_1[i];
            var part = add(tmp0, fromInt(other));
            if (!(result == null)) {
              // Inline function 'kotlin.Long.div' call
              var other_0 = value.words_1[0];
              var tmp$ret$6 = divide(part, fromInt(other_0));
              result[i] = convertToInt(tmp$ret$6);
            }
            // Inline function 'kotlin.Long.rem' call
            var other_1 = value.words_1[0];
            remainder = modulo(part, fromInt(other_1));
          }
           while (0 <= inductionVariable);
        var tmp0_0 = !(result == null) ? normalized(Companion_getInstance_2(), imul($this.sign_1, value.sign_1), result) : Companion_getInstance_2().ZERO_1;
        var tmp;
        if (true) {
          var tmp_0 = Companion_getInstance_2();
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$8 = new Int32Array([convertToInt(remainder)]);
          tmp = normalized(tmp_0, $this.sign_1, tmp$ret$8);
        } else {
          tmp = Companion_getInstance_2().ZERO_1;
        }
        // Inline function 'kotlin.arrayOf' call
        // Inline function 'kotlin.js.unsafeCast' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp$ret$0 = [tmp0_0, tmp];
        break $l$block_0;
      }
      var n = value.words_1.length;
      // Inline function 'kotlin.countLeadingZeroBits' call
      var this_0 = last(value.words_1);
      var shift = clz32(this_0) - 2 | 0;
      var divisor = new Int32Array(n);
      normalizeStoredDivision($this, value.words_1, divisor, shift);
      var dividend = new Int32Array($this.words_1.length + 1 | 0);
      dividend[$this.words_1.length] = normalizeStoredDivision($this, $this.words_1, dividend, shift);
      var quotient = true ? new Int32Array(($this.words_1.length - n | 0) + 1 | 0) : null;
      // Inline function 'kotlin.Long.plus' call
      var this_1 = new Long(1073741823, 0);
      var radix = add(this_1, fromInt(1));
      var high = fromInt(divisor[n - 1 | 0]);
      var next = fromInt(divisor[n - 2 | 0]);
      var inductionVariable_0 = $this.words_1.length - n | 0;
      if (0 <= inductionVariable_0)
        do {
          var j = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + -1 | 0;
          var tmp0_1 = shiftLeft(fromInt(dividend[j + n | 0]), 30);
          // Inline function 'kotlin.Long.plus' call
          var other_2 = dividend[(j + n | 0) - 1 | 0];
          var top = add(tmp0_1, fromInt(other_2));
          var tmp0_2 = divide(top, high);
          // Inline function 'kotlin.comparisons.minOf' call
          var b = new Long(1073741823, 0);
          var estimate = compare(tmp0_2, b) <= 0 ? tmp0_2 : b;
          var residual = subtract(top, multiply(estimate, high));
          $l$loop: while (true) {
            var tmp_1;
            if (compare(residual, radix) < 0) {
              var tmp_2 = multiply(estimate, next);
              var tmp0_3 = shiftLeft(residual, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_3 = dividend[(j + n | 0) - 2 | 0];
              var tmp$ret$17 = add(tmp0_3, fromInt(other_3));
              tmp_1 = compare(tmp_2, tmp$ret$17) > 0;
            } else {
              tmp_1 = false;
            }
            if (!tmp_1) {
              break $l$loop;
            }
            var _unary__edvuaz = estimate;
            estimate = subtract(_unary__edvuaz, get_ONE());
            residual = add(residual, high);
          }
          var borrow = new Long(0, 0);
          var inductionVariable_1 = 0;
          if (inductionVariable_1 < n)
            do {
              var i_0 = inductionVariable_1;
              inductionVariable_1 = inductionVariable_1 + 1 | 0;
              var tmp0_4 = estimate;
              // Inline function 'kotlin.Long.times' call
              var other_4 = divisor[i_0];
              var tmp$ret$18 = multiply(tmp0_4, fromInt(other_4));
              var product = add(tmp$ret$18, borrow);
              var difference = subtract(fromInt(dividend[j + i_0 | 0]), bitwiseAnd(product, new Long(1073741823, 0)));
              dividend[j + i_0 | 0] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
              var tmp0_5 = shiftRightUnsigned(product, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_5 = compare(difference, new Long(0, 0)) < 0 ? 1 : 0;
              borrow = add(tmp0_5, fromInt(other_5));
            }
             while (inductionVariable_1 < n);
          var difference_0 = subtract(fromInt(dividend[j + n | 0]), borrow);
          dividend[j + n | 0] = convertToInt(bitwiseAnd(difference_0, new Long(1073741823, 0)));
          if (compare(difference_0, new Long(0, 0)) < 0) {
            var _unary__edvuaz_0 = estimate;
            estimate = subtract(_unary__edvuaz_0, get_ONE());
            var carry = new Long(0, 0);
            var inductionVariable_2 = 0;
            if (inductionVariable_2 < n)
              do {
                var i_1 = inductionVariable_2;
                inductionVariable_2 = inductionVariable_2 + 1 | 0;
                var tmp0_6 = fromInt(dividend[j + i_1 | 0]);
                // Inline function 'kotlin.Long.plus' call
                var other_6 = divisor[i_1];
                var tmp$ret$20 = add(tmp0_6, fromInt(other_6));
                var sum = add(tmp$ret$20, carry);
                dividend[j + i_1 | 0] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
                carry = shiftRightUnsigned(sum, 30);
              }
               while (inductionVariable_2 < n);
            dividend[j + n | 0] = convertToInt(bitwiseAnd(add(fromInt(dividend[j + n | 0]), carry), new Long(1073741823, 0)));
          }
          if (!(quotient == null)) {
            quotient[j] = convertToInt(estimate);
          }
        }
         while (0 <= inductionVariable_0);
      var remainder_0 = true ? new Int32Array(n) : null;
      if (!(remainder_0 == null)) {
        var inductionVariable_3 = 0;
        if (inductionVariable_3 < n)
          do {
            var i_2 = inductionVariable_3;
            inductionVariable_3 = inductionVariable_3 + 1 | 0;
            remainder_0[i_2] = shift === 0 ? dividend[i_2] : dividend[i_2] >>> shift | 0 | convertToInt(bitwiseAnd(shiftLeft(fromInt(dividend[i_2 + 1 | 0]), 30 - shift | 0), new Long(1073741823, 0)));
          }
           while (inductionVariable_3 < n);
      }
      // Inline function 'kotlin.arrayOf' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp$ret$0 = [!(quotient == null) ? normalized(Companion_getInstance_2(), imul($this.sign_1, value.sign_1), quotient) : Companion_getInstance_2().ZERO_1, !(remainder_0 == null) ? normalized(Companion_getInstance_2(), $this.sign_1, remainder_0) : Companion_getInstance_2().ZERO_1];
    }
    return tmp$ret$0;
  }
  function selectStoredDivision($this, value, needQuotient, needRemainder, select) {
    if (value.sign_1 === 0)
      throw ArithmeticException_init_$Create$('BigInteger divide by zero');
    if (compareMagnitude_0(Companion_getInstance_2(), $this.words_1, value.words_1) < 0)
      return select(Companion_getInstance_2().ZERO_1, needRemainder ? normalized(Companion_getInstance_2(), $this.sign_1, $this.words_1) : Companion_getInstance_2().ZERO_1);
    if (value.words_1.length === 1) {
      var result = needQuotient ? new Int32Array($this.words_1.length) : null;
      var remainder = new Long(0, 0);
      var inductionVariable = $this.words_1.length - 1 | 0;
      if (0 <= inductionVariable)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + -1 | 0;
          var tmp0 = shiftLeft(remainder, 30);
          // Inline function 'kotlin.Long.plus' call
          var other = $this.words_1[i];
          var part = add(tmp0, fromInt(other));
          if (!(result == null)) {
            // Inline function 'kotlin.Long.div' call
            var other_0 = value.words_1[0];
            var tmp$ret$1 = divide(part, fromInt(other_0));
            result[i] = convertToInt(tmp$ret$1);
          }
          // Inline function 'kotlin.Long.rem' call
          var other_1 = value.words_1[0];
          remainder = modulo(part, fromInt(other_1));
        }
         while (0 <= inductionVariable);
      var tmp = !(result == null) ? normalized(Companion_getInstance_2(), imul($this.sign_1, value.sign_1), result) : Companion_getInstance_2().ZERO_1;
      var tmp_0;
      if (needRemainder) {
        var tmp_1 = Companion_getInstance_2();
        // Inline function 'kotlin.intArrayOf' call
        var tmp$ret$3 = new Int32Array([convertToInt(remainder)]);
        tmp_0 = normalized(tmp_1, $this.sign_1, tmp$ret$3);
      } else {
        tmp_0 = Companion_getInstance_2().ZERO_1;
      }
      return select(tmp, tmp_0);
    }
    var n = value.words_1.length;
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_0 = last(value.words_1);
    var shift = clz32(this_0) - 2 | 0;
    var divisor = new Int32Array(n);
    normalizeStoredDivision($this, value.words_1, divisor, shift);
    var dividend = new Int32Array($this.words_1.length + 1 | 0);
    dividend[$this.words_1.length] = normalizeStoredDivision($this, $this.words_1, dividend, shift);
    var quotient = needQuotient ? new Int32Array(($this.words_1.length - n | 0) + 1 | 0) : null;
    // Inline function 'kotlin.Long.plus' call
    var this_1 = new Long(1073741823, 0);
    var radix = add(this_1, fromInt(1));
    var high = fromInt(divisor[n - 1 | 0]);
    var next = fromInt(divisor[n - 2 | 0]);
    var inductionVariable_0 = $this.words_1.length - n | 0;
    if (0 <= inductionVariable_0)
      do {
        var j = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + -1 | 0;
        var tmp0_0 = shiftLeft(fromInt(dividend[j + n | 0]), 30);
        // Inline function 'kotlin.Long.plus' call
        var other_2 = dividend[(j + n | 0) - 1 | 0];
        var top = add(tmp0_0, fromInt(other_2));
        var tmp0_1 = divide(top, high);
        // Inline function 'kotlin.comparisons.minOf' call
        var b = new Long(1073741823, 0);
        var estimate = compare(tmp0_1, b) <= 0 ? tmp0_1 : b;
        var residual = subtract(top, multiply(estimate, high));
        $l$loop: while (true) {
          var tmp_2;
          if (compare(residual, radix) < 0) {
            var tmp_3 = multiply(estimate, next);
            var tmp0_2 = shiftLeft(residual, 30);
            // Inline function 'kotlin.Long.plus' call
            var other_3 = dividend[(j + n | 0) - 2 | 0];
            var tmp$ret$8 = add(tmp0_2, fromInt(other_3));
            tmp_2 = compare(tmp_3, tmp$ret$8) > 0;
          } else {
            tmp_2 = false;
          }
          if (!tmp_2) {
            break $l$loop;
          }
          var _unary__edvuaz = estimate;
          estimate = subtract(_unary__edvuaz, get_ONE());
          residual = add(residual, high);
        }
        var borrow = new Long(0, 0);
        var inductionVariable_1 = 0;
        if (inductionVariable_1 < n)
          do {
            var i_0 = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var tmp0_3 = estimate;
            // Inline function 'kotlin.Long.times' call
            var other_4 = divisor[i_0];
            var tmp$ret$9 = multiply(tmp0_3, fromInt(other_4));
            var product = add(tmp$ret$9, borrow);
            var difference = subtract(fromInt(dividend[j + i_0 | 0]), bitwiseAnd(product, new Long(1073741823, 0)));
            dividend[j + i_0 | 0] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
            var tmp0_4 = shiftRightUnsigned(product, 30);
            // Inline function 'kotlin.Long.plus' call
            var other_5 = compare(difference, new Long(0, 0)) < 0 ? 1 : 0;
            borrow = add(tmp0_4, fromInt(other_5));
          }
           while (inductionVariable_1 < n);
        var difference_0 = subtract(fromInt(dividend[j + n | 0]), borrow);
        dividend[j + n | 0] = convertToInt(bitwiseAnd(difference_0, new Long(1073741823, 0)));
        if (compare(difference_0, new Long(0, 0)) < 0) {
          var _unary__edvuaz_0 = estimate;
          estimate = subtract(_unary__edvuaz_0, get_ONE());
          var carry = new Long(0, 0);
          var inductionVariable_2 = 0;
          if (inductionVariable_2 < n)
            do {
              var i_1 = inductionVariable_2;
              inductionVariable_2 = inductionVariable_2 + 1 | 0;
              var tmp0_5 = fromInt(dividend[j + i_1 | 0]);
              // Inline function 'kotlin.Long.plus' call
              var other_6 = divisor[i_1];
              var tmp$ret$11 = add(tmp0_5, fromInt(other_6));
              var sum = add(tmp$ret$11, carry);
              dividend[j + i_1 | 0] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
              carry = shiftRightUnsigned(sum, 30);
            }
             while (inductionVariable_2 < n);
          dividend[j + n | 0] = convertToInt(bitwiseAnd(add(fromInt(dividend[j + n | 0]), carry), new Long(1073741823, 0)));
        }
        if (!(quotient == null)) {
          quotient[j] = convertToInt(estimate);
        }
      }
       while (0 <= inductionVariable_0);
    var remainder_0 = needRemainder ? new Int32Array(n) : null;
    if (!(remainder_0 == null)) {
      var inductionVariable_3 = 0;
      if (inductionVariable_3 < n)
        do {
          var i_2 = inductionVariable_3;
          inductionVariable_3 = inductionVariable_3 + 1 | 0;
          remainder_0[i_2] = shift === 0 ? dividend[i_2] : dividend[i_2] >>> shift | 0 | convertToInt(bitwiseAnd(shiftLeft(fromInt(dividend[i_2 + 1 | 0]), 30 - shift | 0), new Long(1073741823, 0)));
        }
         while (inductionVariable_3 < n);
    }
    return select(!(quotient == null) ? normalized(Companion_getInstance_2(), imul($this.sign_1, value.sign_1), quotient) : Companion_getInstance_2().ZERO_1, !(remainder_0 == null) ? normalized(Companion_getInstance_2(), $this.sign_1, remainder_0) : Companion_getInstance_2().ZERO_1);
  }
  function normalizeStoredDivision($this, source, target, shift) {
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = source.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var digit = bitwiseOr(shiftLeft(fromInt(source[i]), shift), carry);
        target[i] = convertToInt(bitwiseAnd(digit, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(digit, 30);
      }
       while (inductionVariable <= last);
    return convertToInt(carry);
  }
  function shiftPower($this, value, distance) {
    var tmp;
    if (distance > 0 && !(value.sign_1 === 0)) {
      // Inline function 'kotlin.Long.plus' call
      var this_0 = fromInt(magnitudeBits(value));
      var tmp$ret$0 = add(this_0, fromInt(distance));
      tmp = compare(tmp$ret$0, new Long(2147483647, 0)) > 0;
    } else {
      tmp = false;
    }
    if (tmp)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    return shiftLeftValue(value, distance);
  }
  function oddModPowStored($this, exponent, modulus) {
    var tmp;
    if (exponent == null) {
      throw NullPointerException_init_$Create$();
    } else {
      tmp = exponent;
    }
    var power = tmp;
    if (power.equals(Companion_getInstance_2().ONE_1))
      return $this;
    // Inline function 'kotlin.collections.isEmpty' call
    if ($this.words_1.length === 0)
      return Companion_getInstance_2().ZERO_1;
    var m = new BigInteger(1, modulus.words_1);
    var base = (new BigInteger(1, $this.words_1)).mod_aagpmg_k$(m);
    var result = Companion_getInstance_2().ONE_1.mod_aagpmg_k$(m);
    var bits = magnitudeBits(power);
    var trivialBase = base.sign_1 === 0 || (base.words_1.length === 1 && base.words_1[0] === 1);
    var tmp_0;
    if (power.words_1.length === 1) {
      var tmp_1 = multiply(fromInt(power.words_1[0]), fromInt(magnitudeBits(base)));
      // Inline function 'kotlin.Long.minus' call
      var this_0 = fromInt(magnitudeBits(m));
      var tmp$ret$1 = subtract(this_0, fromInt(1));
      tmp_0 = compare(tmp_1, tmp$ret$1) <= 0;
    } else {
      tmp_0 = false;
    }
    var belowModulus = tmp_0;
    var context = bits === 0 || trivialBase || belowModulus ? null : Companion_getInstance_1().create_x2awi_k$(m);
    if (!(context == null))
      return context.pow_yl686k_k$(base, power, bits);
    var inductionVariable = 0;
    if (inductionVariable < bits)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!((power.words_1[i / 30 | 0] & 1 << (i % 30 | 0)) === 0))
          result = multiplyMod(result, base, m);
        if ((i + 1 | 0) < bits)
          base = multiplyMod(base, base, m);
      }
       while (inductionVariable < bits);
    return result.sign_1 === 0 ? BigInteger_init_$Create$(result) : result;
  }
  function OddModulusContext(modulus, rho, oneMont, r2) {
    Companion_getInstance_1();
    this.modulus_1 = modulus;
    this.rho_1 = rho;
    this.oneMont_1 = oneMont;
    this.r2__1 = r2;
  }
  protoOf(OddModulusContext).pow_yl686k_k$ = function (base, power, bits) {
    var workspace = new Workspace(this.modulus_1.length);
    var tmp0 = base.words_1;
    // Inline function 'kotlin.collections.copyInto' call
    var destination = workspace.input_1;
    var endIndex = tmp0.length;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp = tmp0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp, destination, 0, 0, endIndex);
    var factor = workspace.factor_1;
    var result = workspace.result_1;
    var next = workspace.next_1;
    multiply_0(this, workspace.input_1, this.r2__1, factor, workspace.scratch_1);
    var tmp0_0 = this.oneMont_1;
    // Inline function 'kotlin.collections.copyInto' call
    var destination_0 = result;
    var endIndex_0 = tmp0_0.length;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_0 = tmp0_0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp_0, destination_0, 0, 0, endIndex_0);
    var inductionVariable = 0;
    if (inductionVariable < bits)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!((power.words_1[i / 30 | 0] & 1 << (i % 30 | 0)) === 0)) {
          multiply_0(this, result, factor, next, workspace.scratch_1);
          var previous = result;
          result = next;
          next = previous;
        }
        if ((i + 1 | 0) < bits) {
          multiply_0(this, factor, factor, next, workspace.scratch_1);
          var previous_0 = factor;
          factor = next;
          next = previous_0;
        }
      }
       while (inductionVariable < bits);
    multiply_0(this, result, null, next, workspace.scratch_1);
    var tmp0_1 = next;
    var tmp$ret$10;
    $l$block: {
      // Inline function 'kotlin.collections.all' call
      var inductionVariable_0 = 0;
      var last = tmp0_1.length;
      while (inductionVariable_0 < last) {
        var element = tmp0_1[inductionVariable_0];
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        if (!(element === 0)) {
          tmp$ret$10 = false;
          break $l$block;
        }
      }
      tmp$ret$10 = true;
    }
    if (tmp$ret$10)
      return BigInteger_init_$Create$(Companion_getInstance_2().ZERO_1);
    var tmp_1 = Companion_getInstance_2();
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$12 = next.slice();
    return normalized(tmp_1, 1, tmp$ret$12);
  };
  function moduloPowerOfTwo($this, bits) {
    if ($this.bitLength_9mbxrh_k$() <= bits)
      return $this;
    if (bits === 0)
      return Companion_getInstance_2().ZERO_1;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(bits);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(30));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = divide(this_2, fromInt(30));
    var out = copyOf($this.words_1, convertToInt(tmp$ret$2));
    if (!((bits % 30 | 0) === 0)) {
      out[get_lastIndex(out)] = last(out) & ((1 << (bits % 30 | 0)) - 1 | 0);
    }
    return normalized(Companion_getInstance_2(), 1, out);
  }
  function modPowPowerOfTwo($this, exponent, bits) {
    var base = moduloPowerOfTwo($this, bits);
    var result = Companion_getInstance_2().ONE_1;
    var tmp;
    if (exponent == null) {
      throw NullPointerException_init_$Create$();
    } else {
      tmp = exponent;
    }
    var power = tmp;
    var limit = power.bitLength_9mbxrh_k$();
    if ($this.testBit_49w3bx_k$(0)) {
      var tmp0 = bits - 1 | 0;
      // Inline function 'kotlin.comparisons.minOf' call
      var b = limit;
      limit = Math.min(tmp0, b);
    }
    var inductionVariable = 0;
    var last = limit;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (power.testBit_49w3bx_k$(i))
          result = multiplyPowerOfTwo(result, base, bits);
        if ((i + 1 | 0) < limit)
          base = multiplyPowerOfTwo(new BigInteger(base.sign_1, base.words_1), base, bits);
      }
       while (inductionVariable < last);
    return result;
  }
  function multiplyPowerOfTwo($this, value, bits) {
    var tmp0 = fromInt(magnitudeBits($this));
    // Inline function 'kotlin.Long.plus' call
    var other = magnitudeBits(value);
    var tmp$ret$0 = add(tmp0, fromInt(other));
    if (compare(tmp$ret$0, new Long(2147483647, 0)) <= 0)
      return moduloPowerOfTwo($this.multiply_9xrhei_k$(value), bits);
    var modulus = shiftLeftValue(Companion_getInstance_2().ONE_1, bits);
    var a = (new BigInteger(1, $this.words_1)).mod_aagpmg_k$(modulus);
    var b = (new BigInteger(1, value.words_1)).mod_aagpmg_k$(modulus);
    return a.multiplyModuloBounded_2yyb6o_k$(b, modulus);
  }
  function multiplyMod($this, value, m) {
    var tmp;
    var tmp0 = fromInt(magnitudeBits($this));
    // Inline function 'kotlin.Long.plus' call
    var other = magnitudeBits(value);
    var tmp$ret$0 = add(tmp0, fromInt(other));
    if (compare(tmp$ret$0, new Long(2147483647, 0)) <= 0) {
      tmp = $this.multiply_9xrhei_k$(value).mod_aagpmg_k$(m);
    } else {
      tmp = $this.multiplyModuloBounded_2yyb6o_k$(value, m);
    }
    return tmp;
  }
  function sqrtStored($this) {
    if ($this.sign_1 < 0)
      throw ArithmeticException_init_$Create$('Negative BigInteger');
    if ($this.sign_1 === 0)
      return Companion_getInstance_2().ZERO_1;
    var bits = magnitudeBits($this);
    if (bits === 1)
      return normalized(Companion_getInstance_2(), 1, $this.words_1);
    var value = new BigInteger(1, $this.words_1);
    var x = shiftLeftValue(Companion_getInstance_2().ONE_1, MagnitudeLimits_getInstance().initialSqrtShift_vufmey_k$(bits));
    while (true) {
      var next = shiftRightValue(x.add_gx3ep5_k$(quotientStored(value, x)), 1);
      if (compareMagnitude_0(Companion_getInstance_2(), next.words_1, x.words_1) >= 0)
        return normalized(Companion_getInstance_2(), 1, x.words_1);
      x = next;
    }
  }
  function shiftLeftValue($this, n) {
    if ($this.sign_1 === 0)
      return Companion_getInstance_2().ZERO_1;
    if (n === 0)
      return $this;
    if (n < 0)
      return n === -2147483648 ? $this.sign_1 < 0 ? Companion_getInstance_2().ONE_1.negate_hcqk8u_k$() : Companion_getInstance_2().ZERO_1 : shiftRightValue($this, -n | 0);
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(magnitudeBits($this));
    var tmp$ret$0 = add(this_0, fromInt(n));
    if (compare(tmp$ret$0, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    var whole = n / 30 | 0;
    var bits = n % 30 | 0;
    var result = new Int32Array(($this.words_1.length + whole | 0) + 1 | 0);
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = $this.words_1.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var v = bitwiseOr(shiftLeft(fromInt($this.words_1[i]), bits), carry);
        result[i + whole | 0] = convertToInt(bitwiseAnd(v, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(v, 30);
      }
       while (inductionVariable <= last);
    result[$this.words_1.length + whole | 0] = convertToInt(carry);
    return normalized(Companion_getInstance_2(), $this.sign_1, result);
  }
  function shiftRightValue($this, n) {
    if ($this.sign_1 === 0)
      return Companion_getInstance_2().ZERO_1;
    if (n === 0)
      return $this;
    if (n < 0) {
      if (n === -2147483648)
        throw ArithmeticException_init_$Create$('BigInteger overflow');
      return shiftLeftValue($this, -n | 0);
    }
    if (n >= magnitudeBits($this))
      return $this.sign_1 < 0 ? Companion_getInstance_2().ONE_1.negate_hcqk8u_k$() : Companion_getInstance_2().ZERO_1;
    var whole = n / 30 | 0;
    var bits = n % 30 | 0;
    var result = new Int32Array($this.words_1.length - whole | 0);
    var inductionVariable = 0;
    var last = result.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var v = $this.words_1[i + whole | 0] >>> bits | 0;
        if (!(bits === 0) && ((i + whole | 0) + 1 | 0) < $this.words_1.length)
          v = v | $this.words_1[(i + whole | 0) + 1 | 0] << (30 - bits | 0) & 1073741823;
        result[i] = v;
      }
       while (inductionVariable <= last);
    var truncated = normalized(Companion_getInstance_2(), $this.sign_1, result);
    return $this.sign_1 < 0 && lowestSetBitValue($this) < n ? truncated.subtract_7q3n06_k$(Companion_getInstance_2().ONE_1) : truncated;
  }
  function magnitudeBits($this) {
    var tmp;
    // Inline function 'kotlin.collections.isEmpty' call
    if ($this.words_1.length === 0) {
      tmp = 0;
    } else {
      var tmp_0 = imul($this.words_1.length - 1 | 0, 30) + 32 | 0;
      // Inline function 'kotlin.countLeadingZeroBits' call
      var this_0 = last($this.words_1);
      tmp = tmp_0 - clz32(this_0) | 0;
    }
    return tmp;
  }
  function lowestSetBitValue($this) {
    var inductionVariable = 0;
    var last = $this.words_1.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!($this.words_1[i] === 0))
          return imul(i, 30) + countTrailingZeroBits_0($this.words_1[i]) | 0;
      }
       while (inductionVariable <= last);
    return -1;
  }
  function firstNonzeroWord($this) {
    var first = 0;
    while ($this.words_1[first] === 0) {
      first = first + 1 | 0;
    }
    return first;
  }
  function testBitValue($this, n) {
    if (n < 0)
      throw ArithmeticException_init_$Create$('Negative bit address');
    var index = n / 30 | 0;
    // Inline function 'kotlin.collections.getOrElse' call
    var this_0 = $this.words_1;
    var tmp;
    if (0 <= index ? index <= (this_0.length - 1 | 0) : false) {
      tmp = this_0[index];
    } else {
      tmp = 0;
    }
    var raw = tmp;
    var tmp_0;
    if ($this.sign_1 >= 0) {
      tmp_0 = raw;
    } else {
      var first = firstNonzeroWord($this);
      tmp_0 = index < first ? 0 : index === first ? -raw | 0 : ~raw;
    }
    var word = tmp_0;
    return !((word & 1 << (n % 30 | 0)) === 0);
  }
  function changeBit($this, n, operation) {
    if (n < 0)
      throw ArithmeticException_init_$Create$('Negative bit address');
    var length32 = bitwiseLength32($this);
    var present = testBitValue($this, n);
    if (n === 2147483647 && (operation === 1 && present || (operation === 0 && !present)))
      return BigInteger_init_$Create$($this);
    if (n === 2147483647)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    var index = n / 30 | 0;
    var tmp;
    if (operation === 0) {
      // Inline function 'kotlin.Long.plus' call
      var this_0 = fromInt(n);
      // Inline function 'kotlin.Long.div' call
      var this_1 = add(this_0, fromInt(1));
      // Inline function 'kotlin.Long.plus' call
      var this_2 = divide(this_1, fromInt(32));
      var tmp$ret$2 = add(this_2, fromInt(1));
      tmp = convertToInt(tmp$ret$2);
    } else {
      tmp = (n / 32 | 0) + 2 | 0;
    }
    var addressedLength32 = tmp;
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$3 = Math.max(length32, addressedLength32);
    // Inline function 'kotlin.Long.times' call
    var this_3 = fromInt(tmp$ret$3);
    var width = multiply(this_3, fromInt(32));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.minus' call
    var this_4 = add(width, fromInt(30));
    // Inline function 'kotlin.Long.div' call
    var this_5 = subtract(this_4, fromInt(1));
    var tmp$ret$7 = divide(this_5, fromInt(30));
    var result = twosComplement($this, convertToInt(tmp$ret$7));
    var mask = 1 << (n % 30 | 0);
    result[index] = operation === 0 ? result[index] & ~mask : operation === 1 ? result[index] | mask : result[index] ^ mask;
    return bitwiseResult($this, result, width);
  }
  function bitwiseLength32($this) {
    return ($this.bitLength_9mbxrh_k$() >>> 5 | 0) + 1 | 0;
  }
  function bitwise($this, value, op) {
    var tmp0 = bitwiseLength32($this);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = bitwiseLength32(value);
    var tmp$ret$0 = Math.max(tmp0, b);
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(tmp$ret$0);
    var width = multiply(this_0, fromInt(32));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(width, fromInt(30));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$4 = divide(this_2, fromInt(30));
    var length = convertToInt(tmp$ret$4);
    var a = twosComplement($this, length);
    var b_0 = twosComplement(value, length);
    var tmp = 0;
    var tmp_0 = new Int32Array(length);
    while (tmp < length) {
      var tmp_1 = tmp;
      tmp_0[tmp_1] = op(a[tmp_1], b_0[tmp_1]) & 1073741823;
      tmp = tmp + 1 | 0;
    }
    var out = tmp_0;
    return bitwiseResult($this, out, width);
  }
  function bitwiseResult($this, out, width) {
    // Inline function 'kotlin.Long.minus' call
    // Inline function 'kotlin.Long.rem' call
    var this_0 = subtract(width, fromInt(1));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = modulo(this_0, fromInt(30));
    var tmp$ret$2 = add(this_1, fromInt(1));
    var highBits = convertToInt(tmp$ret$2);
    var highMask = (1 << highBits) - 1 | 0;
    out[get_lastIndex(out)] = last(out) & highMask;
    if (!((last(out) & 1 << (highBits - 1 | 0)) === 0)) {
      out[get_lastIndex(out)] = last(out) | 1073741823 ^ highMask;
    }
    var result = fromTwosComplement($this, out);
    return result.sign_1 === 0 ? BigInteger_init_$Create$(result) : result;
  }
  function fromTwosComplement($this, out) {
    if ((last(out) & 536870912) === 0)
      return normalized(Companion_getInstance_2(), 1, out);
    var carry = new Long(1, 0);
    var inductionVariable = 0;
    var last_0 = out.length - 1 | 0;
    if (inductionVariable <= last_0)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var v = add(fromInt(~out[i] & 1073741823), carry);
        out[i] = convertToInt(bitwiseAnd(v, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(v, 30);
      }
       while (inductionVariable <= last_0);
    return normalized(Companion_getInstance_2(), -1, out);
  }
  function twosComplement($this, length) {
    if ($this.sign_1 >= 0)
      return copyOf($this.words_1, length);
    var out = new Int32Array(length);
    var carry = new Long(1, 0);
    var inductionVariable = 0;
    var last = out.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.collections.getOrElse' call
        var this_0 = $this.words_1;
        var tmp;
        if (0 <= i ? i <= (this_0.length - 1 | 0) : false) {
          tmp = this_0[i];
        } else {
          tmp = 0;
        }
        var tmp$ret$0 = tmp;
        var v = add(fromInt(~tmp$ret$0 & 1073741823), carry);
        out[i] = convertToInt(bitwiseAnd(v, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(v, 30);
      }
       while (inductionVariable <= last);
    return out;
  }
  function passesPrimeTest($this, rounds) {
    var n = $this.abs_22cy_k$();
    if (n.equals(Companion_getInstance_2().TWO_1))
      return true;
    if (!n.testBit_49w3bx_k$(0) || n.equals(Companion_getInstance_2().ONE_1))
      return false;
    n.bitLength_9mbxrh_k$();
    if (n.sign_1 < 0)
      return false;
    // Inline function 'kotlin.intArrayOf' call
    var smallPrimes = new Int32Array([2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]);
    var inductionVariable = 0;
    var last = smallPrimes.length;
    while (inductionVariable < last) {
      var p = smallPrimes[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      var prime = Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt(p));
      if (n.equals(prime))
        return true;
      if (n.remainder_djq7c5_k$(prime).sign_1 === 0)
        return false;
    }
    var nm1 = n.subtract_7q3n06_k$(Companion_getInstance_2().ONE_1);
    var s = nm1.getLowestSetBit_vnfocz_k$();
    var d = nm1.shiftRight_g7qmqq_k$(s);
    if (n.compareTo_ljvw96_k$(Companion_getInstance_2().DETERMINISTIC_PRIME_LIMIT_1) < 0) {
      var indexedObject = Companion_getInstance_2().DETERMINISTIC_PRIME_BASES_1;
      var inductionVariable_0 = 0;
      var last_0 = indexedObject.length;
      while (inductionVariable_0 < last_0) {
        var base = indexedObject[inductionVariable_0];
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        if (!passesPrimeTest$passesWitness(d, n, nm1, s, Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt(base))))
          return false;
      }
      return true;
    }
    var remaining = rounds;
    while (compare(remaining, new Long(0, 0)) > 0) {
      var _unary__edvuaz = remaining;
      remaining = subtract(_unary__edvuaz, get_ONE());
      var a;
      do {
        a = randomBits_0(Companion_getInstance_2(), n.bitLength_9mbxrh_k$(), Default_getInstance());
      }
       while (a.compareTo_ljvw96_k$(Companion_getInstance_2().TWO_1) < 0 || a.compareTo_ljvw96_k$(nm1) >= 0);
      if (!passesPrimeTest$passesWitness(d, n, nm1, s, a))
        return false;
    }
    return true;
  }
  function magnitudeWord32($this, index) {
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(index);
    var start = multiply(this_0, fromInt(32));
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(start, fromInt(30));
    var word = convertToInt(tmp$ret$1);
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(start, fromInt(30));
    var offset = convertToInt(tmp$ret$2);
    var chunk = shiftRightUnsigned(fromInt($this.words_1[word]), offset);
    if ((word + 1 | 0) < $this.words_1.length)
      chunk = bitwiseOr(chunk, shiftLeft(fromInt($this.words_1[word + 1 | 0]), 30 - offset | 0));
    return bitwiseAnd(chunk, new Long(-1, 0));
  }
  function toPowerOfTwoString($this, radix, negative) {
    var bitsPerDigit;
    switch (radix) {
      case 2:
        bitsPerDigit = 1;
        break;
      case 4:
        bitsPerDigit = 2;
        break;
      case 8:
        bitsPerDigit = 3;
        break;
      case 16:
        bitsPerDigit = 4;
        break;
      default:
        bitsPerDigit = 5;
        break;
    }
    var top = last($this.words_1);
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt($this.words_1.length - 1 | 0);
    var tmp0 = multiply(this_0, fromInt(30));
    // Inline function 'kotlin.countLeadingZeroBits' call
    // Inline function 'kotlin.Long.plus' call
    var other = 32 - clz32(top) | 0;
    var bitLength = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = bitsPerDigit;
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(bitLength, fromInt(other_0));
    var tmp0_0 = subtract(this_1, fromInt(1));
    // Inline function 'kotlin.Long.div' call
    var other_1 = bitsPerDigit;
    var digitCountLong = divide(tmp0_0, fromInt(other_1));
    // Inline function 'kotlin.Long.plus' call
    var other_2 = negative ? 1 : 0;
    var capacityLong = add(digitCountLong, fromInt(other_2));
    if (compare(capacityLong, new Long(2147483647, 0)) > 0) {
      plainStringTooLarge();
    }
    var digitCount = convertToInt(digitCountLong);
    // Inline function 'kotlin.Long.minus' call
    var this_2 = shiftLeft(new Long(1, 0), bitsPerDigit);
    var mask = subtract(this_2, fromInt(1));
    var text = StringBuilder_init_$Create$_0(convertToInt(capacityLong));
    if (negative) {
      text.append_am5a4z_k$(_Char___init__impl__6a9atx(45));
    }
    var inductionVariable = digitCount - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0_1 = fromInt(index);
        // Inline function 'kotlin.Long.times' call
        var other_3 = bitsPerDigit;
        var bit = multiply(tmp0_1, fromInt(other_3));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$9 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$9);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$10 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$10);
        var digit = shiftRightUnsigned(fromInt($this.words_1[word]), offset);
        if ((offset + bitsPerDigit | 0) > 30 && (word + 1 | 0) < $this.words_1.length)
          digit = bitwiseOr(digit, shiftLeft(fromInt($this.words_1[word + 1 | 0]), 30 - offset | 0));
        text.append_am5a4z_k$(charCodeAt('0123456789abcdefghijklmnopqrstuvwxyz', convertToInt(bitwiseAnd(digit, mask))));
      }
       while (0 <= inductionVariable);
    return text.toString();
  }
  function divideDecimalChunk($this, magnitude, length, divisor) {
    var remainder = new Long(0, 0);
    var inductionVariable = length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = shiftLeft(remainder, 30);
        // Inline function 'kotlin.Long.plus' call
        var other = magnitude[i];
        var part = add(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$1 = divide(part, fromInt(divisor));
        magnitude[i] = convertToInt(tmp$ret$1);
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(divisor));
      }
       while (0 <= inductionVariable);
    return convertToInt(remainder);
  }
  function compareDecimalScratch($this, magnitude, length, other) {
    if (!(length === other.length))
      return compareTo(length, other.length);
    var inductionVariable = length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var order = compareTo(magnitude[i], other[i]);
        if (!(order === 0))
          return order;
      }
       while (0 <= inductionVariable);
    return 0;
  }
  function DecimalBinaryPrefix(magnitude, decimalDigits, discardedDigits, sticky) {
    this.magnitude_1 = magnitude;
    this.decimalDigits_1 = decimalDigits;
    this.discardedDigits_1 = discardedDigits;
    this.sticky_1 = sticky;
  }
  protoOf(DecimalBinaryPrefix).get_magnitude_ou7v6h_k$ = function () {
    return this.magnitude_1;
  };
  protoOf(DecimalBinaryPrefix).get_decimalDigits_hhr9m6_k$ = function () {
    return this.decimalDigits_1;
  };
  protoOf(DecimalBinaryPrefix).get_discardedDigits_o1vnja_k$ = function () {
    return this.discardedDigits_1;
  };
  protoOf(DecimalBinaryPrefix).get_sticky_jnjxf6_k$ = function () {
    return this.sticky_1;
  };
  function floatingValue($this, precision, maxExponent, dispatchSmallValue) {
    dispatchSmallValue = dispatchSmallValue === VOID ? true : dispatchSmallValue;
    if ($this.sign_1 === 0)
      return 0.0;
    var bits = magnitudeBits($this);
    if (dispatchSmallValue && bits <= 63) {
      var small = $this.toLong_edfucp_k$();
      return precision === 53 ? toNumber(small) : floatingValue(Companion_getInstance_2().valueOf_wwtjy2_k$(small), precision, maxExponent, false);
    }
    if (bits > maxExponent)
      return $this.sign_1 < 0 ? -Infinity : Infinity;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = bits - precision | 0;
    var shift = Math.max(0, b);
    var top = new Long(0, 0);
    var inductionVariable = bits - 1 | 0;
    if (shift <= inductionVariable)
      do {
        var bit = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        top = bitwiseOr(shiftLeft(top, 1), floatingValue$magnitudeBit($this, bit) ? new Long(1, 0) : new Long(0, 0));
      }
       while (!(bit === shift));
    if (shift > 0 && floatingValue$magnitudeBit($this, shift - 1 | 0) && (lowestSetBitValue($this) < (shift - 1 | 0) || !equalsLong(bitwiseAnd(top, new Long(1, 0)), new Long(0, 0)))) {
      var _unary__edvuaz = top;
      top = add(_unary__edvuaz, get_ONE());
    }
    var tmp = $this.sign_1 * toNumber(top);
    // Inline function 'kotlin.math.pow' call
    return tmp * Math.pow(2.0, shift);
  }
  function Companion_1() {
    Companion_instance_1 = this;
    this.serialVersionUID_1 = new Long(-1455686883, -1929601249);
    this.LIMB_BITS_1 = 30;
    this.MASK_1 = new Long(1073741823, 0);
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$0 = new Int32Array([]);
    tmp.ZERO_1 = new BigInteger(0, tmp$ret$0);
    var tmp_0 = this;
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$1 = new Int32Array([1]);
    tmp_0.ONE_1 = new BigInteger(1, tmp$ret$1);
    var tmp_1 = this;
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$2 = new Int32Array([2]);
    tmp_1.TWO_1 = new BigInteger(1, tmp$ret$2);
    var tmp_2 = this;
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$3 = new Int32Array([10]);
    tmp_2.TEN_1 = new BigInteger(1, tmp$ret$3);
    var tmp_3 = this;
    var tmp_4 = 0;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_5 = Array(33);
    while (tmp_4 < 33) {
      var tmp_6 = tmp_4;
      var value = tmp_6 - 16 | 0;
      var tmp_7;
      switch (value) {
        case 0:
          tmp_7 = Companion_getInstance_2().ZERO_1;
          break;
        case 1:
          tmp_7 = Companion_getInstance_2().ONE_1;
          break;
        case 2:
          tmp_7 = Companion_getInstance_2().TWO_1;
          break;
        case 10:
          tmp_7 = Companion_getInstance_2().TEN_1;
          break;
        default:
          var tmp_8 = value < 0 ? -1 : 1;
          // Inline function 'kotlin.intArrayOf' call

          var tmp$ret$6 = new Int32Array([value < 0 ? -value | 0 : value]);
          tmp_7 = new BigInteger(tmp_8, tmp$ret$6);
          break;
      }
      tmp_5[tmp_6] = tmp_7;
      tmp_4 = tmp_4 + 1 | 0;
    }
    tmp_3.SMALL_VALUES_1 = tmp_5;
    this.DETERMINISTIC_PRIME_LIMIT_1 = BigInteger_init_$Create$_0('3317044064679887385961981');
    var tmp_9 = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp_9.DETERMINISTIC_PRIME_BASES_1 = new Int32Array([2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41]);
  }
  protoOf(Companion_1).get_ZERO_wodlgx_k$ = function () {
    return this.ZERO_1;
  };
  protoOf(Companion_1).get_ONE_18jnkz_k$ = function () {
    return this.ONE_1;
  };
  protoOf(Companion_1).get_TWO_18jjnh_k$ = function () {
    return this.TWO_1;
  };
  protoOf(Companion_1).get_TEN_18jk30_k$ = function () {
    return this.TEN_1;
  };
  protoOf(Companion_1).valueOf_wwtjy2_k$ = function (value) {
    if (compare(new Long(-16, -1), value) <= 0 ? compare(value, new Long(16, 0)) <= 0 : false) {
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$0 = add(value, fromInt(16));
      return this.SMALL_VALUES_1[convertToInt(tmp$ret$0)];
    }
    var tmp;
    if (compare(value, new Long(0, 0)) < 0) {
      var tmp0 = _ULong___init__impl__c78o9k(new Long(0, 0));
      // Inline function 'kotlin.toULong' call
      // Inline function 'kotlin.ULong.minus' call
      var other = _ULong___init__impl__c78o9k(value);
      tmp = _ULong___init__impl__c78o9k(subtract(_ULong___get_data__impl__fggpzb(tmp0), _ULong___get_data__impl__fggpzb(other)));
    } else {
      // Inline function 'kotlin.toULong' call
      tmp = _ULong___init__impl__c78o9k(value);
    }
    var magnitude = tmp;
    var result = new Int32Array(3);
    var i = 0;
    while (!equals(new ULong(magnitude), new ULong(_ULong___init__impl__c78o9k(new Long(0, 0))))) {
      var _unary__edvuaz = i;
      i = _unary__edvuaz + 1 | 0;
      var tmp0_0 = magnitude;
      // Inline function 'kotlin.toULong' call
      var this_0 = new Long(1073741823, 0);
      // Inline function 'kotlin.ULong.and' call
      var other_0 = _ULong___init__impl__c78o9k(this_0);
      // Inline function 'kotlin.ULong.toInt' call
      var this_1 = _ULong___init__impl__c78o9k(bitwiseAnd(_ULong___get_data__impl__fggpzb(tmp0_0), _ULong___get_data__impl__fggpzb(other_0)));
      result[_unary__edvuaz] = convertToInt(_ULong___get_data__impl__fggpzb(this_1));
      // Inline function 'kotlin.ULong.shr' call
      var this_2 = magnitude;
      magnitude = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_2), 30));
    }
    return normalized(this, compare(value, new Long(0, 0)) < 0 ? -1 : 1, result);
  };
  protoOf(Companion_1).probablePrime_lh9pvv_k$ = function (bitLength, rnd) {
    return generatePrime_0(this, bitLength, 100, rnd);
  };
  protoOf(Companion_1).probablePrime_a61dir_k$ = function (bitLength, rnd) {
    return generatePrime(this, bitLength, 100, rnd);
  };
  protoOf(Companion_1).randomValue_8k6b2q_k$ = function (numBits, rnd) {
    return randomBits_0(this, numBits, rnd);
  };
  protoOf(Companion_1).primeValue_w20hnc_k$ = function (bitLength, certainty, rnd) {
    return generatePrime_0(this, bitLength, certainty, rnd);
  };
  var Companion_instance_1;
  function Companion_getInstance_2() {
    if (Companion_instance_1 == null)
      new Companion_1();
    return Companion_instance_1;
  }
  function multiplyModuloBounded$addResidues($m, a, b) {
    var gap = $m.subtract_7q3n06_k$(b);
    return a.compareTo_ljvw96_k$(gap) >= 0 ? a.subtract_7q3n06_k$(gap) : a.add_gx3ep5_k$(b);
  }
  function BigInteger$and$lambda(a, b) {
    return a & b;
  }
  function BigInteger$or$lambda(a, b) {
    return a | b;
  }
  function BigInteger$xor$lambda(a, b) {
    return a ^ b;
  }
  function BigInteger$andNot$lambda(a, b) {
    return a & ~b;
  }
  function passesPrimeTest$passesWitness(d, n, nm1, s, a) {
    var x = a.modPow_kosrdq_k$(d, n);
    if (x.equals(Companion_getInstance_2().ONE_1) || x.equals(nm1))
      return true;
    var inductionVariable = 1;
    if (inductionVariable < s)
      do {
        var r = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        x = multiplyMod(x, x, n);
        if (x.equals(nm1))
          return true;
      }
       while (inductionVariable < s);
    return false;
  }
  function floatingValue$magnitudeBit(this$0, n) {
    return !((this$0.words_1[n / 30 | 0] & 1 << (n % 30 | 0)) === 0);
  }
  function BigInteger(sign, words) {
    Companion_getInstance_2();
    Number_0.call(this);
    this.sign_1 = sign;
    this.words_1 = words;
  }
  protoOf(BigInteger).signum_exb08b_k$ = function () {
    return this.sign_1;
  };
  protoOf(BigInteger).abs_22cy_k$ = function () {
    return this.sign_1 < 0 ? this.negate_hcqk8u_k$() : this;
  };
  protoOf(BigInteger).negate_hcqk8u_k$ = function () {
    return this.sign_1 === 0 ? this : new BigInteger(-this.sign_1 | 0, this.words_1);
  };
  protoOf(BigInteger).add_gx3ep5_k$ = function (value) {
    if (this.sign_1 === 0)
      return value;
    if (value.sign_1 === 0)
      return this;
    if (this.sign_1 === value.sign_1)
      return normalized(Companion_getInstance_2(), this.sign_1, addMagnitude(Companion_getInstance_2(), this.words_1, value.words_1));
    var cmp = compareMagnitude_0(Companion_getInstance_2(), this.words_1, value.words_1);
    return cmp === 0 ? Companion_getInstance_2().ZERO_1 : cmp > 0 ? normalized(Companion_getInstance_2(), this.sign_1, subtractMagnitude(Companion_getInstance_2(), this.words_1, value.words_1)) : normalized(Companion_getInstance_2(), value.sign_1, subtractMagnitude(Companion_getInstance_2(), value.words_1, this.words_1));
  };
  protoOf(BigInteger).subtract_7q3n06_k$ = function (value) {
    if (value.sign_1 === 0)
      return this;
    if (this.sign_1 === 0)
      return value.negate_hcqk8u_k$();
    if (!(this.sign_1 === value.sign_1))
      return normalized(Companion_getInstance_2(), this.sign_1, addMagnitude(Companion_getInstance_2(), this.words_1, value.words_1));
    var cmp = compareMagnitude_0(Companion_getInstance_2(), this.words_1, value.words_1);
    return cmp === 0 ? Companion_getInstance_2().ZERO_1 : cmp > 0 ? normalized(Companion_getInstance_2(), this.sign_1, subtractMagnitude(Companion_getInstance_2(), this.words_1, value.words_1)) : normalized(Companion_getInstance_2(), -this.sign_1 | 0, subtractMagnitude(Companion_getInstance_2(), value.words_1, this.words_1));
  };
  protoOf(BigInteger).multiply_9xrhei_k$ = function (value) {
    if (this.sign_1 === 0 || value.sign_1 === 0)
      return Companion_getInstance_2().ZERO_1;
    MagnitudeMultiplication_getInstance().checkBitLengths_utqcyw_k$(magnitudeBits(this), magnitudeBits(value));
    return normalized(Companion_getInstance_2(), imul(this.sign_1, value.sign_1), MagnitudeMultiplication_getInstance().multiplyAdaptive_p1t9i2_k$(this.words_1, value.words_1));
  };
  protoOf(BigInteger).parallelMultiply_qewlfj_k$ = function (value) {
    return this.multiply_9xrhei_k$(value);
  };
  protoOf(BigInteger).alignedDecimalSum585_shheyo_k$ = function (value, leftScale, rightScale, subtract, mc) {
    var tmp1_elvis_lhs = mc == null ? null : mc.get_precision_e8tfsb_k$();
    var precision = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    if (leftScale === rightScale && (precision === 0 || precision > 646456993))
      return null;
    var rightSign = subtract ? -value.sign_1 | 0 : value.sign_1;
    if (materializedDecimalSum585(this.sign_1, rightSign, magnitudeBits(this), magnitudeBits(value), leftScale, rightScale))
      return null;
    var leftDigits = this.sign_1 === 0 ? 0 : this.decimalMagnitudeDigits_6egwr2_k$();
    var rightDigits = value.sign_1 === 0 ? 0 : value.decimalMagnitudeDigits_6egwr2_k$();
    if (!certifiedDecimalSumSpan585(leftDigits, rightDigits, leftScale, rightScale, precision))
      return null;
    return DecimalSum585_getInstance().sum_v0avwh_k$(this.sign_1, this.words_1, leftScale, rightSign, value.words_1, rightScale, mc);
  };
  protoOf(BigInteger).roundedDecimalProduct580_fm0dx6_k$ = function (value, scale, mc) {
    if (this.sign_1 === 0 || value.sign_1 === 0 || !needsRawDecimalProduct580(magnitudeBits(this), magnitudeBits(value)))
      return null;
    return DecimalProduct580_getInstance().rounded_ir9ghy_k$(imul(this.sign_1, value.sign_1), this.words_1, value.words_1, scale, mc);
  };
  protoOf(BigInteger).roundedDecimalQuotient581_unawcx_k$ = function (value, preferred, target, shift, sourceDigits, divisorDigits, normalized, mc) {
    if (this.sign_1 === 0 || value.sign_1 === 0)
      return null;
    if (materializedDecimalDivision581(magnitudeBits(this), magnitudeBits(value), mc.get_precision_e8tfsb_k$(), preferred, target, shift))
      return null;
    if (!(sourceDigits === this.decimalMagnitudeDigits_6egwr2_k$()) || !(divisorDigits === value.decimalMagnitudeDigits_6egwr2_k$()) || !(normalized === this.compareDecimalSignificand_pncnrq_k$(value)))
      return null;
    if (mc.get_precision_e8tfsb_k$() > 646456993)
      return DecimalDivision581_getInstance().largePrecision_q4a9aj_k$(imul(this.sign_1, value.sign_1), new BigInteger(1, this.words_1), new BigInteger(1, value.words_1), preferred, mc.get_precision_e8tfsb_k$());
    return DecimalDivision581_getInstance().rounded_ir9ghy_k$(imul(this.sign_1, value.sign_1), this.words_1, value.words_1, preferred, mc);
  };
  protoOf(BigInteger).integralDecimalQuotient582_mdrb2m_k$ = function (value, sourceScale, divisorScale, sourceDigits, divisorDigits, reportedSourceScale, reportedDivisorScale, sourceSign, magnitude) {
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(sourceScale);
    var preferred = subtract(this_0, fromInt(divisorScale));
    if (!(compare(new Long(-2147483648, -1), preferred) <= 0 ? compare(preferred, new Long(2147483647, 0)) <= 0 : false) || this.sign_1 === 0 || value.sign_1 === 0 || !(sourceSign === this.sign_1) || !(reportedSourceScale === sourceScale) || !(reportedDivisorScale === divisorScale) || !(sourceDigits === this.decimalMagnitudeDigits_6egwr2_k$()) || !(divisorDigits === value.decimalMagnitudeDigits_6egwr2_k$()))
      return null;
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(sourceDigits);
    var tmp = subtract(this_1, fromInt(sourceScale));
    // Inline function 'kotlin.Long.minus' call
    var this_2 = fromInt(divisorDigits);
    var tmp$ret$2 = subtract(this_2, fromInt(divisorScale));
    var exponents = tmp.compareTo_9jj042_k$(tmp$ret$2);
    var storedMagnitude = !(exponents === 0) ? exponents : this.compareDecimalSignificand_pncnrq_k$(value);
    if (!(compareTo(magnitude, 0) === compareTo(storedMagnitude, 0)) || storedMagnitude < 0)
      return null;
    if (compare(preferred, new Long(0, 0)) < 0) {
      var zeros = negate(preferred);
      var tmp_0;
      if (compare(zeros, fromInt(divisorDigits)) >= 0) {
        var tmp_1 = add(fromInt(sourceDigits), zeros);
        var tmp_2 = new Long(646456993, 0);
        // Inline function 'kotlin.Long.times' call
        var this_3 = new Long(2, 0);
        var tmp$ret$3 = multiply(this_3, fromInt(divisorDigits));
        // Inline function 'kotlin.Long.minus' call
        var this_4 = add(tmp_2, tmp$ret$3);
        var tmp$ret$4 = subtract(this_4, fromInt(1));
        tmp_0 = compare(tmp_1, tmp$ret$4) > 0;
      } else {
        tmp_0 = false;
      }
      if (tmp_0)
        return DecimalDivision581_getInstance().largePrecision_q4a9aj_k$(imul(this.sign_1, value.sign_1), new BigInteger(1, this.words_1), new BigInteger(1, value.words_1), preferred, 2147483647);
      return DecimalDivision581_getInstance().integral_b2vfd8_k$(imul(this.sign_1, value.sign_1), this.words_1, value.words_1, convertToInt(preferred));
    }
    var power = Companion_getInstance_2().TEN_1.pow_iykav4_k$(convertToInt(preferred));
    var absoluteDivisor = new BigInteger(1, value.words_1);
    var denominator = equalsLong(preferred, new Long(0, 0)) ? absoluteDivisor : absoluteDivisor.multiply_9xrhei_k$(power);
    var quotient = quotientStored(new BigInteger(1, this.words_1), denominator);
    var coefficient = equalsLong(preferred, new Long(0, 0)) ? quotient : quotient.multiply_9xrhei_k$(power);
    return to(this.sign_1 === value.sign_1 || coefficient.sign_1 === 0 ? coefficient : new BigInteger(-1, coefficient.words_1), convertToInt(preferred));
  };
  protoOf(BigInteger).certifiedDecimalResidual583_fdz1km_k$ = function (value, sourceScale, divisorScale, quotient, quotientScale) {
    if (value.sign_1 === 0 || materializedDecimalResidual583(magnitudeBits(this), magnitudeBits(value), magnitudeBits(quotient), sourceScale, divisorScale, quotientScale))
      return null;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(sourceScale);
    var preferred = subtract(this_0, fromInt(divisorScale));
    if (compare(preferred, new Long(-2147483648, -1)) < 0)
      return this.certifiedExactLowResidual590_jjbdgg_k$(value, sourceScale, divisorScale, quotient, quotientScale);
    var tmp;
    if (!(compare(new Long(-2147483648, -1), preferred) <= 0 ? compare(preferred, new Long(2147483647, 0)) <= 0 : false)) {
      tmp = true;
    } else {
      var tmp_0 = fromInt(quotientScale);
      // Inline function 'kotlin.comparisons.maxOf' call
      var b = new Long(0, 0);
      var tmp$ret$1 = compare(preferred, b) >= 0 ? preferred : b;
      tmp = compare(tmp_0, tmp$ret$1) > 0;
    }
    if (tmp)
      return null;
    if (this.sign_1 === 0)
      return quotient.sign_1 === 0 && equalsLong(fromInt(quotientScale), preferred) ? to(Companion_getInstance_2().ZERO_1, sourceScale) : null;
    var sourceDigits = this.decimalMagnitudeDigits_6egwr2_k$();
    var divisorDigits = value.decimalMagnitudeDigits_6egwr2_k$();
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(sourceDigits);
    var tmp_1 = subtract(this_1, fromInt(sourceScale));
    // Inline function 'kotlin.Long.minus' call
    var this_2 = fromInt(divisorDigits);
    var tmp$ret$3 = subtract(this_2, fromInt(divisorScale));
    var exponents = tmp_1.compareTo_9jj042_k$(tmp$ret$3);
    var magnitude = !(exponents === 0) ? exponents : this.compareDecimalSignificand_pncnrq_k$(value);
    if (quotient.sign_1 === 0)
      return equalsLong(fromInt(quotientScale), preferred) && magnitude < 0 ? to(new BigInteger(this.sign_1, this.words_1), sourceScale) : null;
    if (!(quotient.sign_1 === imul(this.sign_1, value.sign_1)) || magnitude < 0)
      return null;
    if (compare(preferred, new Long(0, 0)) < 0)
      return DecimalDivision581_getInstance().certifiedResidual583_9qpnmp_k$(this.sign_1, this.words_1, value.words_1, quotient.words_1, convertToInt(preferred), divisorScale, quotientScale);
    var absoluteDivisor = new BigInteger(1, value.words_1);
    var denominator = equalsLong(preferred, new Long(0, 0)) ? absoluteDivisor : absoluteDivisor.multiply_9xrhei_k$(Companion_getInstance_2().TEN_1.pow_iykav4_k$(convertToInt(preferred)));
    var qr = divideStored(new BigInteger(1, this.words_1), denominator);
    if (!DecimalDivision581_getInstance().matchesInteger583_g68r3b_k$(quotient.words_1, quotientScale, qr[0].words_1))
      return null;
    var residual = qr[1];
    return to(this.sign_1 < 0 && !(residual.sign_1 === 0) ? new BigInteger(-1, residual.words_1) : residual, sourceScale);
  };
  protoOf(BigInteger).fixedScaleDecimalQuotient592_y4e3p9_k$ = function (value, shift, mode) {
    if (this.sign_1 === 0 || value.sign_1 === 0)
      return null;
    var tmp;
    var tmp_0;
    if (compare(new Long(-646456992, -1), shift) <= 0 ? compare(shift, new Long(646456992, 0)) <= 0 : false) {
      var tmp_1 = fromInt(magnitudeBits(this));
      var tmp_2 = new Long(4, 0);
      // Inline function 'kotlin.comparisons.maxOf' call
      var b = new Long(0, 0);
      var tmp$ret$0 = compare(shift, b) >= 0 ? shift : b;
      tmp_0 = compare(add(tmp_1, multiply(tmp_2, tmp$ret$0)), new Long(2147483647, 0)) <= 0;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      var tmp_3 = fromInt(magnitudeBits(value));
      var tmp_4 = new Long(4, 0);
      var tmp0 = negate(shift);
      // Inline function 'kotlin.comparisons.maxOf' call
      var b_0 = new Long(0, 0);
      var tmp$ret$1 = compare(tmp0, b_0) >= 0 ? tmp0 : b_0;
      tmp = compare(add(tmp_3, multiply(tmp_4, tmp$ret$1)), new Long(2147483647, 0)) <= 0;
    } else {
      tmp = false;
    }
    if (tmp)
      return null;
    return DecimalDivision581_getInstance().fixedScale592_pl4rvi_k$(imul(this.sign_1, value.sign_1), this.words_1, value.words_1, shift, mode);
  };
  protoOf(BigInteger).certifiedExactLowResidual590_jjbdgg_k$ = function (value, sourceScale, divisorScale, quotient, quotientScale) {
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(sourceScale);
    var preferred = subtract(this_0, fromInt(divisorScale));
    if (compare(preferred, new Long(-2147483648, -1)) >= 0 || this.sign_1 === 0 || value.sign_1 === 0 || quotient.sign_1 === 0 || !(quotient.sign_1 === imul(this.sign_1, value.sign_1)))
      return null;
    var tmp0 = fromInt(sourceScale);
    // Inline function 'kotlin.Long.plus' call
    var this_1 = fromInt(quotientScale);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = add(this_1, fromInt(divisorScale));
    var residualScale = compare(tmp0, b) >= 0 ? tmp0 : b;
    if (!(compare(new Long(-2147483648, -1), residualScale) <= 0 ? compare(residualScale, new Long(2147483647, 0)) <= 0 : false))
      return null;
    var tmp;
    try {
      tmp = DecimalDivision581_getInstance().largePrecision_q4a9aj_k$(imul(this.sign_1, value.sign_1), new BigInteger(1, this.words_1), new BigInteger(1, value.words_1), preferred, 2147483647);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var _unused_var__etf5q3 = $p;
        return null;
      } else {
        throw $p;
      }
    }
    var exact = tmp;
    var tmp_1;
    var tmp0_0 = fromInt(exact.first.decimalMagnitudeDigits_6egwr2_k$());
    // Inline function 'kotlin.Long.minus' call
    var other = exact.second;
    var tmp_2 = subtract(tmp0_0, fromInt(other));
    // Inline function 'kotlin.Long.minus' call
    var this_2 = fromInt(quotient.decimalMagnitudeDigits_6egwr2_k$());
    var tmp$ret$4 = subtract(this_2, fromInt(quotientScale));
    if (!equalsLong(tmp_2, tmp$ret$4)) {
      tmp_1 = true;
    } else {
      tmp_1 = !(exact.first.compareDecimalSignificand_pncnrq_k$(quotient) === 0);
    }
    if (tmp_1)
      return null;
    return to(Companion_getInstance_2().ZERO_1, convertToInt(residualScale));
  };
  protoOf(BigInteger).decimalPowerState593_1qfbxp_k$ = function (scale) {
    return this.sign_1 === 0 ? null : DecimalPower593_getInstance().fromMagnitude_1i7lcv_k$(this.sign_1, this.words_1, scale);
  };
  protoOf(BigInteger).divide_bsns5t_k$ = function (value) {
    return quotientStored(this, value);
  };
  protoOf(BigInteger).remainder_djq7c5_k$ = function (value) {
    return remainderStored(this, value);
  };
  protoOf(BigInteger).divideAndRemainder_2r68pv_k$ = function (value) {
    return divideStored(this, value);
  };
  protoOf(BigInteger).pow_iykav4_k$ = function (exponent) {
    if (exponent < 0)
      throw ArithmeticException_init_$Create$('Negative exponent');
    if (exponent === 0)
      return Companion_getInstance_2().ONE_1;
    if (this.equals(Companion_getInstance_2().ONE_1))
      return Companion_getInstance_2().ONE_1;
    if (this.sign_1 === 0 || exponent === 1)
      return this;
    var absolute = this.abs_22cy_k$();
    var twos = absolute.getLowestSetBit_vnfocz_k$();
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(twos);
    var shift = multiply(this_0, fromInt(exponent));
    if (compare(shift, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    var part = absolute.shiftRight_g7qmqq_k$(twos);
    var bits = part.bitLength_9mbxrh_k$();
    var negative = this.sign_1 < 0 && !((exponent & 1) === 0);
    if (bits === 1)
      return shiftPower(this, negative ? Companion_getInstance_2().valueOf_wwtjy2_k$(new Long(-1, -1)) : Companion_getInstance_2().ONE_1, convertToInt(shift));
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(bits);
    // Inline function 'kotlin.Long.times' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = multiply(this_2, fromInt(exponent));
    if (compare(tmp$ret$2, new Long(2147483647, 0)) >= 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    // Inline function 'kotlin.Long.times' call
    var this_3 = fromInt(bits);
    var estimate = multiply(this_3, fromInt(exponent));
    if (compare(estimate, new Long(64, 0)) <= 0) {
      // Inline function 'kotlin.collections.isEmpty' call
      if (part.words_1.length === 0) {
        emptyPowMagnitude();
      }
      // Inline function 'kotlin.Long.plus' call
      var this_4 = fromInt(magnitudeBits(part));
      // Inline function 'kotlin.Long.div' call
      var this_5 = add(this_4, fromInt(31));
      var tmp$ret$6 = divide(this_5, fromInt(32));
      var count = convertToInt(tmp$ret$6);
      var factor = magnitudeWord32(part, count - 1 | 0);
      var e = equalsLong(factor, new Long(2, 0)) ? 0 : exponent;
      var product = equalsLong(factor, new Long(2, 0)) ? shiftLeft(new Long(1, 0), exponent) : new Long(1, 0);
      while (!(e === 0)) {
        if (!((e & 1) === 0))
          product = multiply(product, factor);
        e = e >>> 1 | 0;
        if (!(e === 0))
          factor = multiply(factor, factor);
      }
      var compactShift = compare(add(estimate, shift), new Long(64, 0)) <= 0;
      if (compactShift)
        product = shiftLeft(product, convertToInt(shift));
      // Inline function 'kotlin.toULong' call
      var this_6 = product;
      var magnitude = _ULong___init__impl__c78o9k(this_6);
      var packed = new Int32Array(3);
      var size = 0;
      while (!equals(new ULong(magnitude), new ULong(_ULong___init__impl__c78o9k(new Long(0, 0))))) {
        var _unary__edvuaz = size;
        size = _unary__edvuaz + 1 | 0;
        var tmp0 = magnitude;
        // Inline function 'kotlin.toULong' call
        var this_7 = new Long(1073741823, 0);
        // Inline function 'kotlin.ULong.and' call
        var other = _ULong___init__impl__c78o9k(this_7);
        // Inline function 'kotlin.ULong.toInt' call
        var this_8 = _ULong___init__impl__c78o9k(bitwiseAnd(_ULong___get_data__impl__fggpzb(tmp0), _ULong___get_data__impl__fggpzb(other)));
        packed[_unary__edvuaz] = convertToInt(_ULong___get_data__impl__fggpzb(this_8));
        // Inline function 'kotlin.ULong.shr' call
        var this_9 = magnitude;
        magnitude = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_9), 30));
      }
      var tmp;
      if (size === 0) {
        // Inline function 'kotlin.intArrayOf' call
        var tmp$ret$12 = new Int32Array([]);
        tmp = new BigInteger(0, tmp$ret$12);
      } else {
        tmp = normalized(Companion_getInstance_2(), negative ? -1 : 1, packed);
      }
      var value = tmp;
      return compactShift ? value : shiftPower(this, value, convertToInt(shift));
    }
    var e_0 = exponent;
    var base = normalized(Companion_getInstance_2(), part.sign_1, part.words_1);
    var result = Companion_getInstance_2().ONE_1;
    while (!(e_0 === 0)) {
      if (!((e_0 & 1) === 0))
        result = result.multiply_9xrhei_k$(base);
      e_0 = e_0 >>> 1 | 0;
      if (!(e_0 === 0))
        base = base.multiply_9xrhei_k$(base);
    }
    return shiftPower(this, negative ? result.negate_hcqk8u_k$() : result, convertToInt(shift));
  };
  protoOf(BigInteger).gcd_ucjjcu_k$ = function (value) {
    if (value.sign_1 === 0)
      return this.abs_22cy_k$();
    if (this.sign_1 === 0)
      return value.abs_22cy_k$();
    var a = new BigInteger(1, this.words_1);
    var b = new BigInteger(1, value.words_1);
    while (!(b.sign_1 === 0)) {
      var r = remainderStored(a, b);
      a = b;
      b = r;
    }
    return normalized(Companion_getInstance_2(), 1, a.words_1);
  };
  protoOf(BigInteger).mod_aagpmg_k$ = function (m) {
    if (m.sign_1 <= 0)
      throw ArithmeticException_init_$Create$('BigInteger: modulus not positive');
    var r = this.remainder_djq7c5_k$(m);
    return r.sign_1 < 0 ? r.add_gx3ep5_k$(m) : r;
  };
  protoOf(BigInteger).modPow_kosrdq_k$ = function (exponent, m) {
    if (m.sign_1 <= 0)
      throw ArithmeticException_init_$Create$('BigInteger: modulus not positive');
    var power = exponent;
    if (power.sign_1 === 0)
      return m.equals(Companion_getInstance_2().ONE_1) ? Companion_getInstance_2().ZERO_1 : Companion_getInstance_2().ONE_1;
    if (this.equals(Companion_getInstance_2().ONE_1))
      return m.equals(Companion_getInstance_2().ONE_1) ? Companion_getInstance_2().ZERO_1 : Companion_getInstance_2().ONE_1;
    if (this.equals(Companion_getInstance_2().ZERO_1) && power.sign_1 >= 0)
      return Companion_getInstance_2().ZERO_1;
    if (this.equals(Companion_getInstance_2().valueOf_wwtjy2_k$(new Long(-1, -1))) && !power.testBit_49w3bx_k$(0))
      return m.equals(Companion_getInstance_2().ONE_1) ? Companion_getInstance_2().ZERO_1 : Companion_getInstance_2().ONE_1;
    var inverse = power.sign_1 < 0;
    var e = inverse ? power.negate_hcqk8u_k$() : power;
    var base = this.sign_1 < 0 || this.compareTo_ljvw96_k$(m) >= 0 ? this.mod_aagpmg_k$(m) : this;
    var tmp;
    if (m.testBit_49w3bx_k$(0)) {
      tmp = oddModPowStored(base, e, m);
    } else {
      var p = m.getLowestSetBit_vnfocz_k$();
      var oddModulus = m.shiftRight_g7qmqq_k$(p);
      var oddBase = this.sign_1 < 0 || this.compareTo_ljvw96_k$(oddModulus) >= 0 ? this.mod_aagpmg_k$(oddModulus) : this;
      var oddResidue = oddModulus.equals(Companion_getInstance_2().ONE_1) ? Companion_getInstance_2().ZERO_1 : oddModPowStored(oddBase, e, oddModulus);
      var binaryResidue = modPowPowerOfTwo(base, e, p);
      var binaryModulus = shiftLeftValue(Companion_getInstance_2().ONE_1, p);
      var binaryInverse = binaryModulus.modInverse_1eu0e4_k$(oddModulus);
      var oddInverse = oddModulus.modInverse_1eu0e4_k$(binaryModulus);
      var tmp_0;
      // Inline function 'kotlin.Long.times' call
      var this_0 = fromInt(magnitudeBits(m));
      // Inline function 'kotlin.Long.plus' call
      var this_1 = multiply(this_0, fromInt(2));
      var tmp$ret$1 = add(this_1, fromInt(2));
      if (compare(tmp$ret$1, new Long(2147483647, 0)) <= 0) {
        tmp_0 = oddResidue.multiply_9xrhei_k$(binaryModulus).multiply_9xrhei_k$(binaryInverse).add_gx3ep5_k$(binaryResidue.multiply_9xrhei_k$(oddModulus).multiply_9xrhei_k$(oddInverse)).mod_aagpmg_k$(m);
      } else {
        var modulus = new BigInteger(1, m.words_1);
        var left = multiplyMod(oddResidue.multiply_9xrhei_k$(binaryModulus), binaryInverse, modulus);
        var right = multiplyMod(binaryResidue.multiply_9xrhei_k$(oddModulus), oddInverse, modulus);
        var gap = modulus.subtract_7q3n06_k$(right);
        tmp_0 = left.compareTo_ljvw96_k$(gap) >= 0 ? left.subtract_7q3n06_k$(gap) : left.add_gx3ep5_k$(right);
      }
      tmp = tmp_0;
    }
    var result = tmp;
    return inverse ? result.modInverse_1eu0e4_k$(m) : result;
  };
  protoOf(BigInteger).modInverse_1eu0e4_k$ = function (m) {
    if (m.sign_1 <= 0)
      throw ArithmeticException_init_$Create$('BigInteger: modulus not positive');
    if (m.equals(Companion_getInstance_2().ONE_1))
      return Companion_getInstance_2().ZERO_1;
    var reduced = this.sign_1 < 0 || compareMagnitude_0(Companion_getInstance_2(), this.words_1, m.words_1) >= 0 ? this.mod_aagpmg_k$(m) : this;
    if (reduced.equals(Companion_getInstance_2().ONE_1))
      return Companion_getInstance_2().ONE_1;
    if (reduced.sign_1 === 0)
      throw ArithmeticException_init_$Create$('BigInteger not invertible.');
    var modulus = new BigInteger(1, m.words_1);
    var r = modulus;
    var nextR = new BigInteger(1, reduced.words_1);
    var t = Companion_getInstance_2().ZERO_1;
    var nextT = Companion_getInstance_2().ONE_1;
    while (!(nextR.sign_1 === 0)) {
      var qr = divideStored(r, nextR);
      var temp = t.subtract_7q3n06_k$(qr[0].multiply_9xrhei_k$(nextT));
      t = nextT;
      nextT = temp;
      r = nextR;
      nextR = qr[1];
    }
    if (!r.equals(Companion_getInstance_2().ONE_1))
      throw ArithmeticException_init_$Create$('BigInteger not invertible.');
    return t.mod_aagpmg_k$(modulus);
  };
  protoOf(BigInteger).multiplyModuloBounded_2yyb6o_k$ = function (value, m) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(this.sign_1 >= 0 && value.sign_1 >= 0 && m.sign_1 > 0 && this.compareTo_ljvw96_k$(m) < 0 && value.compareTo_ljvw96_k$(m) < 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var result = Companion_getInstance_2().ZERO_1;
    var addend = this;
    var bits = magnitudeBits(value);
    var inductionVariable = 0;
    if (inductionVariable < bits)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (value.testBit_49w3bx_k$(i))
          result = multiplyModuloBounded$addResidues(m, result, addend);
        if ((i + 1 | 0) < bits)
          addend = multiplyModuloBounded$addResidues(m, addend, addend);
      }
       while (inductionVariable < bits);
    return result;
  };
  protoOf(BigInteger).sqrt_23u3k_k$ = function () {
    return sqrtStored(this);
  };
  protoOf(BigInteger).sqrtAndRemainder_n2e1f6_k$ = function () {
    var root = sqrtStored(this);
    var square = root.multiply_9xrhei_k$(root);
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [root, normalized(Companion_getInstance_2(), 1, subtractMagnitude(Companion_getInstance_2(), this.words_1, square.words_1))];
  };
  protoOf(BigInteger).shiftLeft_qqh5sf_k$ = function (n) {
    return shiftLeftValue(this, n);
  };
  protoOf(BigInteger).shiftRight_g7qmqq_k$ = function (n) {
    return shiftRightValue(this, n);
  };
  protoOf(BigInteger).bitLength_9mbxrh_k$ = function () {
    var bits = magnitudeBits(this);
    if (this.sign_1 >= 0 || !(countOneBits(last(this.words_1)) === 1))
      return bits;
    var inductionVariable = 0;
    var last_0 = get_lastIndex(this.words_1);
    if (inductionVariable < last_0)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(this.words_1[i] === 0))
          return bits;
      }
       while (inductionVariable < last_0);
    return bits - 1 | 0;
  };
  protoOf(BigInteger).bitCount_hvylfm_k$ = function () {
    if (this.sign_1 >= 0) {
      // Inline function 'kotlin.collections.sumOf' call
      var sum = 0;
      var indexedObject = this.words_1;
      var inductionVariable = 0;
      var last = indexedObject.length;
      while (inductionVariable < last) {
        var element = indexedObject[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = sum;
        sum = tmp + countOneBits(element) | 0;
      }
      return sum;
    }
    // Inline function 'kotlin.collections.sumOf' call
    var sum_0 = 0;
    var indexedObject_0 = this.words_1;
    var inductionVariable_0 = 0;
    var last_0 = indexedObject_0.length;
    while (inductionVariable_0 < last_0) {
      var element_0 = indexedObject_0[inductionVariable_0];
      inductionVariable_0 = inductionVariable_0 + 1 | 0;
      var tmp_0 = sum_0;
      sum_0 = tmp_0 + countOneBits(element_0) | 0;
    }
    return (sum_0 + this.getLowestSetBit_vnfocz_k$() | 0) - 1 | 0;
  };
  protoOf(BigInteger).getLowestSetBit_vnfocz_k$ = function () {
    return lowestSetBitValue(this);
  };
  protoOf(BigInteger).testBit_49w3bx_k$ = function (n) {
    return testBitValue(this, n);
  };
  protoOf(BigInteger).setBit_hdw09f_k$ = function (n) {
    return changeBit(this, n, 1);
  };
  protoOf(BigInteger).clearBit_4ii6l4_k$ = function (n) {
    return changeBit(this, n, 0);
  };
  protoOf(BigInteger).flipBit_vkir60_k$ = function (n) {
    return changeBit(this, n, 2);
  };
  protoOf(BigInteger).not_2cb7_k$ = function () {
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(bitwiseLength32(this));
    var width = multiply(this_0, fromInt(32));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(width, fromInt(30));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$3 = divide(this_2, fromInt(30));
    var result = twosComplement(this, convertToInt(tmp$ret$3));
    var inductionVariable = 0;
    var last = result.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        result[i] = ~result[i] & 1073741823;
      }
       while (inductionVariable <= last);
    return bitwiseResult(this, result, width);
  };
  protoOf(BigInteger).and_8ls3xv_k$ = function (value) {
    return bitwise(this, value, BigInteger$and$lambda);
  };
  protoOf(BigInteger).or_yhmmu1_k$ = function (value) {
    return bitwise(this, value, BigInteger$or$lambda);
  };
  protoOf(BigInteger).xor_21fdsh_k$ = function (value) {
    return bitwise(this, value, BigInteger$xor$lambda);
  };
  protoOf(BigInteger).andNot_t6xpgy_k$ = function (value) {
    return bitwise(this, value, BigInteger$andNot$lambda);
  };
  protoOf(BigInteger).isProbablePrime_9jwjxq_k$ = function (certainty) {
    if (certainty <= 0)
      return true;
    return passesPrimeTest(this, fromInt(PrimalityCertainty_getInstance().testRounds_cm9w9t_k$(certainty)));
  };
  protoOf(BigInteger).nextProbablePrime_7w2065_k$ = function () {
    if (this.sign_1 < 0)
      throw ArithmeticException_init_$Create$('start < 0: ' + this.toString());
    if (this.sign_1 === 0 || (this.words_1.length === 1 && this.words_1[0] === 1))
      return Companion_getInstance_2().TWO_1;
    PrimeSearchLimits_getInstance().checkBitLength_rls9oj_k$(magnitudeBits(this));
    var n = this.add_gx3ep5_k$(Companion_getInstance_2().ONE_1).setBit_hdw09f_k$(0);
    var candidateIndex = Companion_getInstance_2().ONE_1;
    while (true) {
      PrimeSearchLimits_getInstance().checkBitLength_rls9oj_k$(magnitudeBits(n));
      if (passesPrimeTest(n, PrimalityCertainty_getInstance().successorRounds_2crnv1_k$(candidateIndex.bitLength_9mbxrh_k$())))
        return n;
      n = n.add_gx3ep5_k$(Companion_getInstance_2().TWO_1);
      candidateIndex = candidateIndex.add_gx3ep5_k$(Companion_getInstance_2().ONE_1);
    }
  };
  protoOf(BigInteger).compareTo_ljvw96_k$ = function (other) {
    var operand = other;
    if (!(this.sign_1 === operand.sign_1))
      return this.sign_1 < operand.sign_1 ? -1 : 1;
    var magnitude = compareMagnitude_0(Companion_getInstance_2(), this.words_1, operand.words_1);
    return magnitude < 0 ? -this.sign_1 | 0 : magnitude > 0 ? this.sign_1 : 0;
  };
  protoOf(BigInteger).compareTo_hpufkf_k$ = function (other) {
    return this.compareTo_ljvw96_k$(other instanceof BigInteger ? other : THROW_CCE());
  };
  protoOf(BigInteger).min_lgtkhk_k$ = function (value) {
    return this.compareTo_ljvw96_k$(value) < 0 ? this : value;
  };
  protoOf(BigInteger).max_qh4hk6_k$ = function (value) {
    return this.compareTo_ljvw96_k$(value) > 0 ? this : value;
  };
  protoOf(BigInteger).equals = function (other) {
    var tmp;
    var tmp_0;
    if (other instanceof BigInteger) {
      tmp_0 = this.sign_1 === other.sign_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = contentEquals(this.words_1, other.words_1);
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(BigInteger).hashCode = function () {
    var hash = 0;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(magnitudeBits(this));
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(31));
    var tmp$ret$1 = divide(this_1, fromInt(32));
    var count = convertToInt(tmp$ret$1);
    var inductionVariable = count - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var chunk = magnitudeWord32(this, i);
        var tmp0 = new Long(31, 0);
        // Inline function 'kotlin.Long.times' call
        var other = hash;
        var tmp$ret$2 = multiply(tmp0, fromInt(other));
        hash = convertToInt(add(tmp$ret$2, chunk));
      }
       while (0 <= inductionVariable);
    return imul(hash, this.sign_1);
  };
  protoOf(BigInteger).toString = function () {
    return this.toString_w4mr8s_k$(10);
  };
  protoOf(BigInteger).toString_w4mr8s_k$ = function (radix) {
    if (this.sign_1 === 0)
      return '0';
    var r = (2 <= radix ? radix <= 36 : false) ? radix : 10;
    var magnitude = this.abs_22cy_k$();
    if ((2 <= radix ? radix <= 36 : false) && getKClassFromExpression(this).equals(getKClass(BigInteger)) && getKClassFromExpression(magnitude).equals(getKClass(BigInteger)) && magnitude.sign_1 > 0) {
      switch (r) {
        case 2:
        case 4:
        case 8:
        case 16:
        case 32:
          return toPowerOfTwoString(magnitude, r, this.sign_1 < 0);
      }
    }
    var divisor = Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt(r));
    var text = StringBuilder_init_$Create$();
    var value = magnitude;
    while (!(value.sign_1 === 0)) {
      var qr = value.divideAndRemainder_2r68pv_k$(divisor);
      text.append_am5a4z_k$(charCodeAt('0123456789abcdefghijklmnopqrstuvwxyz', qr[1].toInt_1tsl84_k$()));
      value = qr[0];
    }
    if (this.sign_1 < 0) {
      text.append_am5a4z_k$(_Char___init__impl__6a9atx(45));
    }
    return text.reverse_i6tiw2_k$().toString();
  };
  protoOf(BigInteger).toByteArray_qczt2u_k$ = function () {
    var length = (this.bitLength_9mbxrh_k$() / 8 | 0) + 1 | 0;
    var magnitude = this.sign_1 < 0 ? this.abs_22cy_k$().subtract_7q3n06_k$(Companion_getInstance_2().ONE_1) : this;
    var tmp = 0;
    var tmp_0 = new Int8Array(length);
    while (tmp < length) {
      var tmp_1 = tmp;
      var byte = 0;
      var inductionVariable = 0;
      if (inductionVariable <= 7)
        do {
          var b = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (magnitude.testBit_49w3bx_k$(imul((length - tmp_1 | 0) - 1 | 0, 8) + b | 0))
            byte = byte | 1 << b;
        }
         while (inductionVariable <= 7);
      tmp_0[tmp_1] = toByte(this.sign_1 < 0 ? ~byte : byte);
      tmp = tmp + 1 | 0;
    }
    return tmp_0;
  };
  protoOf(BigInteger).toInt_1tsl84_k$ = function () {
    // Inline function 'kotlin.collections.getOrElse' call
    var this_0 = this.words_1;
    var tmp;
    if (0 <= 0 ? 0 <= (this_0.length - 1 | 0) : false) {
      tmp = this_0[0];
    } else {
      tmp = 0;
    }
    var tmp_0 = tmp;
    // Inline function 'kotlin.collections.getOrElse' call
    var this_1 = this.words_1;
    var tmp_1;
    if (0 <= 1 ? 1 <= (this_1.length - 1 | 0) : false) {
      tmp_1 = this_1[1];
    } else {
      tmp_1 = 0;
    }
    var low = tmp_0 | tmp_1 << 30;
    return this.sign_1 < 0 ? -low | 0 : low;
  };
  protoOf(BigInteger).toLong_edfucp_k$ = function () {
    var value = new Long(0, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var a = this.words_1.length;
    var inductionVariable = Math.min(a, 3) - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        value = bitwiseOr(shiftLeft(value, 30), fromInt(this.words_1[i]));
      }
       while (0 <= inductionVariable);
    return this.sign_1 < 0 ? negate(value) : value;
  };
  protoOf(BigInteger).decimalLowBitsProductFits591_t956o6_k$ = function (raise) {
    var tmp = fromInt(magnitudeBits(this));
    // Inline function 'kotlin.Long.times' call
    var this_0 = new Long(4, 0);
    var tmp$ret$0 = multiply(this_0, fromInt(raise));
    return compare(add(tmp, tmp$ret$0), new Long(2147483647, 0)) <= 0;
  };
  protoOf(BigInteger).decimalProductLowBits591_ut8ae2_k$ = function (raise, bits) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(bits === 32 || bits === 64)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(0 <= raise ? raise < bits : false)) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    var value = new Long(0, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var a = this.words_1.length;
    var inductionVariable = Math.min(a, 3) - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        value = bitwiseOr(shiftLeft(value, 30), fromInt(this.words_1[i]));
      }
       while (0 <= inductionVariable);
    if (this.sign_1 < 0)
      value = negate(value);
    // Inline function 'kotlin.repeat' call
    var inductionVariable_0 = 0;
    if (inductionVariable_0 < raise)
      do {
        var index = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        value = multiply(value, new Long(10, 0));
      }
       while (inductionVariable_0 < raise);
    return bits === 32 ? fromInt(convertToInt(value)) : value;
  };
  protoOf(BigInteger).decimalCompactValue_llvq0o_k$ = function () {
    if (this.words_1.length > 3 || (this.words_1.length === 3 && this.words_1[2] >= 8))
      return null;
    var value = new Long(0, 0);
    var inductionVariable = this.words_1.length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        value = bitwiseOr(shiftLeft(value, 30), fromInt(this.words_1[i]));
      }
       while (0 <= inductionVariable);
    return this.sign_1 < 0 ? negate(value) : value;
  };
  protoOf(BigInteger).decimalDigitLowerBound_4f5nwi_k$ = function () {
    return this.sign_1 === 0 ? 1 : convertToInt(shiftRightUnsigned(multiply(fromInt(magnitudeBits(this) - 1 | 0), new Long(1292913986, 0)), 32)) + 1 | 0;
  };
  protoOf(BigInteger).decimalMagnitudeDigits_6egwr2_k$ = function () {
    if (this.sign_1 === 0)
      return 1;
    var lower = this.decimalDigitLowerBound_4f5nwi_k$();
    if (lower === 646456993)
      return lower;
    var threshold = Companion_getInstance_2().TEN_1.pow_iykav4_k$(lower);
    return lower + (compareMagnitude_0(Companion_getInstance_2(), this.words_1, threshold.words_1) >= 0 ? 1 : 0) | 0;
  };
  protoOf(BigInteger).compareDecimalSignificand_pncnrq_k$ = function (other) {
    if (this.sign_1 === 0 || other.sign_1 === 0)
      return compareTo(this.sign_1 === 0 ? 0 : 1, other.sign_1 === 0 ? 0 : 1);
    var difference = this.decimalMagnitudeDigits_6egwr2_k$() - other.decimalMagnitudeDigits_6egwr2_k$() | 0;
    if (difference === 0)
      return compareMagnitude_0(Companion_getInstance_2(), this.words_1, other.words_1);
    var longer = difference > 0 ? this : other;
    var shorter = difference > 0 ? other : this;
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var quotient = longer.words_1.slice();
    var length = quotient.length;
    var drop = difference > 0 ? difference : -difference | 0;
    var sticky = false;
    while (drop >= 9) {
      var remainder = divideDecimalChunk(this, quotient, length, 1000000000);
      sticky = sticky || !(remainder === 0);
      while (length > 0 && quotient[length - 1 | 0] === 0) {
        length = length - 1 | 0;
      }
      drop = drop - 9 | 0;
    }
    if (drop > 0) {
      var divisor = 1;
      // Inline function 'kotlin.repeat' call
      var times = drop;
      var inductionVariable = 0;
      if (inductionVariable < times)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          divisor = imul(divisor, 10);
        }
         while (inductionVariable < times);
      var remainder_0 = divideDecimalChunk(this, quotient, length, divisor);
      sticky = sticky || !(remainder_0 === 0);
      while (length > 0 && quotient[length - 1 | 0] === 0) {
        length = length - 1 | 0;
      }
    }
    var quotientOrder = compareDecimalScratch(this, quotient, length, shorter.words_1);
    var order = !(quotientOrder === 0) ? quotientOrder : sticky ? 1 : 0;
    return difference > 0 ? order : -order | 0;
  };
  protoOf(BigInteger).decimalBinaryPrefix_1bw1dx_k$ = function (maxDigits) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(maxDigits > 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (this.sign_1 === 0)
      return new DecimalBinaryPrefix(Companion_getInstance_2().ZERO_1, 1, 0, false);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = this.decimalDigitLowerBound_4f5nwi_k$() - maxDigits | 0;
    var trim = Math.max(0, b);
    var absolute = new BigInteger(1, this.words_1);
    var tmp;
    if (trim === 0) {
      // Inline function 'kotlin.arrayOf' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp = [absolute, Companion_getInstance_2().ZERO_1];
    } else {
      tmp = divideStored(absolute, Companion_getInstance_2().TEN_1.pow_iykav4_k$(trim));
    }
    var qr = tmp;
    var digits = qr[0].toString();
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_0 = digits.length - maxDigits | 0;
    var extra = Math.max(0, b_0);
    var tmp_0;
    if (!(qr[1].sign_1 === 0)) {
      tmp_0 = true;
    } else {
      var tmp0 = until(maxDigits, digits.length);
      var tmp$ret$8;
      $l$block_0: {
        // Inline function 'kotlin.collections.any' call
        var tmp_1;
        if (isInterface(tmp0, Collection)) {
          tmp_1 = tmp0.isEmpty_y1axqb_k$();
        } else {
          tmp_1 = false;
        }
        if (tmp_1) {
          tmp$ret$8 = false;
          break $l$block_0;
        }
        var inductionVariable = tmp0.get_first_irdx8n_k$();
        var last = tmp0.get_last_wopotb_k$();
        if (inductionVariable <= last)
          do {
            var element = inductionVariable;
            inductionVariable = inductionVariable + 1 | 0;
            var it = element;
            if (!(charCodeAt(digits, it) === _Char___init__impl__6a9atx(48))) {
              tmp$ret$8 = true;
              break $l$block_0;
            }
          }
           while (!(element === last));
        tmp$ret$8 = false;
      }
      tmp_0 = tmp$ret$8;
    }
    var sticky = tmp_0;
    var prefix = extra === 0 ? qr[0] : BigInteger_init_$Create$_0(substring_0(digits, 0, maxDigits));
    return new DecimalBinaryPrefix(prefix, trim + digits.length | 0, trim + extra | 0, sticky);
  };
  protoOf(BigInteger).toByte_edm0nx_k$ = function () {
    return toByte(this.toInt_1tsl84_k$());
  };
  protoOf(BigInteger).toShort_ja8oqn_k$ = function () {
    return toShort(this.toInt_1tsl84_k$());
  };
  protoOf(BigInteger).toDouble_ygsx0s_k$ = function () {
    return floatingValue(this, 53, 1024);
  };
  protoOf(BigInteger).toFloat_jhbgwv_k$ = function () {
    return floatingValue(this, 24, 128);
  };
  protoOf(BigInteger).intValueExact_x1rjxf_k$ = function () {
    if (magnitudeBits(this) > 32 || this.bitLength_9mbxrh_k$() > 31)
      throw ArithmeticException_init_$Create$('BigInteger out of int range');
    return this.toInt_1tsl84_k$();
  };
  protoOf(BigInteger).longValueExact_akftqu_k$ = function () {
    if (magnitudeBits(this) > 64 || this.bitLength_9mbxrh_k$() > 63)
      throw ArithmeticException_init_$Create$('BigInteger out of long range');
    return this.toLong_edfucp_k$();
  };
  protoOf(BigInteger).shortValueExact_q6yi0a_k$ = function () {
    if (magnitudeBits(this) > 32 || this.bitLength_9mbxrh_k$() > 15)
      throw ArithmeticException_init_$Create$('BigInteger out of short range');
    return this.toShort_ja8oqn_k$();
  };
  protoOf(BigInteger).byteValueExact_pqedrq_k$ = function () {
    if (magnitudeBits(this) > 32 || this.bitLength_9mbxrh_k$() > 7)
      throw ArithmeticException_init_$Create$('BigInteger out of byte range');
    return this.toByte_edm0nx_k$();
  };
  function get_lowestSetBit(_this__u8e3s4) {
    return _this__u8e3s4.getLowestSetBit_vnfocz_k$();
  }
  function _get_coefficientDigits__cunepi($this) {
    return $this.coefficientDigits_1;
  }
  function _get_lastNonzero__mjhnua($this) {
    return $this.lastNonzero_1;
  }
  function _get_capacity__a9k9f3($this) {
    return $this.capacity_1;
  }
  function _get_pages__cygrxv($this) {
    return $this.pages_1;
  }
  function _get_cells__j1rckg($this) {
    return $this.cells_1;
  }
  function _set_size__9twho6($this, _set____db54di) {
    $this.size_1 = _set____db54di;
  }
  function trim($this) {
    while ($this.size_1 > 0 && $this.cells_1.get_c1px32_k$($this.size_1 - 1 | 0) === 0) {
      $this.size_1 = $this.size_1 - 1 | 0;
    }
  }
  function _get_BASE__cm0716($this) {
    return $this.BASE_1;
  }
  function _get_PAGE__ctp2fw($this) {
    return $this.PAGE_1;
  }
  function _get_MAX_DIGITS__vbaa22($this) {
    return $this.MAX_DIGITS_1;
  }
  function _get_powers__vdnpa5($this) {
    return $this.powers_1;
  }
  function IntegerView583(coefficient, length, coefficientDigits, lastNonzero) {
    this.coefficient_1 = coefficient;
    this.length_1 = length;
    this.coefficientDigits_1 = coefficientDigits;
    this.lastNonzero_1 = lastNonzero;
  }
  protoOf(IntegerView583).get_coefficient_r375cc_k$ = function () {
    return this.coefficient_1;
  };
  protoOf(IntegerView583).get_length_g42xv3_k$ = function () {
    return this.length_1;
  };
  protoOf(IntegerView583).digit_5clizl_k$ = function (position) {
    // Inline function 'kotlin.check' call
    if (!(compare(new Long(0, 0), position) <= 0 ? compare(position, this.length_1) < 0 : false)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return compare(position, this.coefficientDigits_1) < 0 ? ensureNotNull(this.coefficient_1).digitFromLeft_byk0bm_k$(position, this.coefficientDigits_1) : 0;
  };
  protoOf(IntegerView583).zeroTail_1lfwoa_k$ = function (position) {
    return compare(position, this.lastNonzero_1) >= 0;
  };
  function integerView583($this, coefficient, scale) {
    if (coefficient == null)
      return new IntegerView583(null, new Long(0, 0), new Long(0, 0), new Long(0, 0));
    var digits = coefficient.digits_m0zfve_k$();
    var zeros = coefficient.trailingZeros_kq0ik1_k$();
    if (scale > 0 && compare(zeros, fromInt(scale)) < 0)
      return null;
    return new IntegerView583(coefficient, subtract(digits, fromInt(scale)), digits, subtract(digits, zeros));
  }
  function exactResult($this, q, sign, preferred, exponent, kept, precision) {
    // Inline function 'kotlin.Long.minus' call
    var this_0 = add(preferred, kept);
    var tmp$ret$0 = subtract(this_0, fromInt(1));
    var scale = subtract(tmp$ret$0, exponent);
    while (q.endsInZero_4aac1n_k$()) {
      // Inline function 'kotlin.check' call
      if (!(q.divideTen_qc6bdo_k$() === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var _unary__edvuaz = scale;
      scale = subtract(_unary__edvuaz, get_ONE());
    }
    var tmp0 = subtract(preferred, scale);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = new Long(0, 0);
    var tmp0_0 = compare(tmp0, b) >= 0 ? tmp0 : b;
    // Inline function 'kotlin.comparisons.minOf' call
    var b_0 = subtract(precision, q.digits_m0zfve_k$());
    var padding = compare(tmp0_0, b_0) <= 0 ? tmp0_0 : b_0;
    var resultScale = checkedScale_0($this, add(scale, padding));
    var remaining = padding;
    while (compare(remaining, new Long(0, 0)) > 0) {
      q.multiplyAdd_d61a5v_k$(10, 0);
      var _unary__edvuaz_0 = remaining;
      remaining = subtract(_unary__edvuaz_0, get_ONE());
    }
    return publish($this, q, sign, resultScale);
  }
  function increment_0($this, mode, sign, half, odd) {
    var tmp;
    switch (mode.get_ordinal_ip24qg_k$()) {
      case 0:
        tmp = true;
        break;
      case 1:
        tmp = false;
        break;
      case 2:
        tmp = sign > 0;
        break;
      case 3:
        tmp = sign < 0;
        break;
      case 4:
        tmp = half >= 0;
        break;
      case 5:
        tmp = half > 0;
        break;
      case 6:
        tmp = half > 0 || (half === 0 && odd);
        break;
      case 7:
        throw ArithmeticException_init_$Create$('Rounding necessary');
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function checkedScale_0($this, scale) {
    var narrowed = convertToInt(scale);
    if (!equalsLong(fromInt(narrowed), scale))
      throw ArithmeticException_init_$Create$(narrowed > 0 ? 'Underflow' : 'Overflow');
    return narrowed;
  }
  function decimalChunks($this, words, scratch) {
    var inductionVariable = 0;
    var last = words.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        scratch.set_g707pu_k$(i, words[i]);
      }
       while (inductionVariable <= last);
    var size = words.length;
    var tmp0 = new Long(646456993, 0);
    var tmp0_0 = new Long(10, 0);
    // Inline function 'kotlin.Long.times' call
    var other = words.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(tmp0_0, fromInt(other));
    var digitBound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(digitBound, fromInt(8));
    var tmp$ret$3 = divide(this_0, fromInt(9));
    var result = new DecimalWords(convertToInt(tmp$ret$3));
    while (size > 0) {
      var remainder = new Long(0, 0);
      var inductionVariable_0 = size - 1 | 0;
      if (0 <= inductionVariable_0)
        do {
          var i_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + -1 | 0;
          var tmp0_1 = shiftLeft(remainder, 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = scratch.get_c1px32_k$(i_0);
          var part = add(tmp0_1, fromInt(other_0));
          // Inline function 'kotlin.Long.div' call
          var other_1 = 1000000000;
          var tmp$ret$5 = divide(part, fromInt(other_1));
          scratch.set_g707pu_k$(i_0, convertToInt(tmp$ret$5));
          // Inline function 'kotlin.Long.rem' call
          var other_2 = 1000000000;
          remainder = modulo(part, fromInt(other_2));
        }
         while (0 <= inductionVariable_0);
      result.append_dlf032_k$(convertToInt(remainder));
      while (size > 0 && scratch.get_c1px32_k$(size - 1 | 0) === 0) {
        size = size - 1 | 0;
      }
    }
    // Inline function 'kotlin.check' call
    if (!(result.size_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return result;
  }
  function publish($this, decimal, sign, scale) {
    var tmp0 = new Long(2147483647, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(new Long(4, 0), decimal.digits_m0zfve_k$());
    var bitBound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bitBound, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = divide(this_0, fromInt(30));
    var tmp$ret$3 = add(this_1, fromInt(1));
    var binary = new Cells(convertToInt(tmp$ret$3));
    var size = 0;
    var inductionVariable = decimal.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var carry = fromInt(decimal.get_c1px32_k$(i));
        var j = 0;
        while (j < size) {
          var tmp0_0 = fromInt(binary.get_c1px32_k$(j));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$4 = multiply(tmp0_0, fromInt(other));
          var part = add(tmp$ret$4, carry);
          binary.set_g707pu_k$(j, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
          j = j + 1 | 0;
        }
        if (!equalsLong(carry, new Long(0, 0))) {
          var _unary__edvuaz = size;
          size = _unary__edvuaz + 1 | 0;
          binary.set_g707pu_k$(_unary__edvuaz, convertToInt(carry));
        }
        var tmp0_1 = new Long(30, 0);
        // Inline function 'kotlin.Long.times' call
        var other_0 = size - 1 | 0;
        // Inline function 'kotlin.Long.plus' call
        var this_2 = multiply(tmp0_1, fromInt(other_0));
        var tmp0_2 = add(this_2, fromInt(32));
        // Inline function 'kotlin.countLeadingZeroBits' call
        var this_3 = binary.get_c1px32_k$(size - 1 | 0);
        // Inline function 'kotlin.Long.minus' call
        var other_1 = clz32(this_3);
        var bits = subtract(tmp0_2, fromInt(other_1));
        if (compare(bits, new Long(2147483647, 0)) > 0)
          throw ArithmeticException_init_$Create$('BigInteger overflow');
      }
       while (0 <= inductionVariable);
    var tmp0_3 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_4 = multiply(tmp0_3, fromInt(other_2));
    var tmp0_4 = add(this_4, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_5 = binary.get_c1px32_k$(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_5);
    var bits_0 = subtract(tmp0_4, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_6 = add(bits_0, fromInt(7));
    var tmp$ret$14 = divide(this_6, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$14));
    var inductionVariable_0 = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_7 = new Long(8, 0);
        var bit = multiply(this_7, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$16 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$16);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$17 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$17);
        var value = shiftRightUnsigned(fromInt(binary.get_c1px32_k$(word)), offset);
        if (offset > 22 && (word + 1 | 0) < size)
          value = bitwiseOr(value, shiftLeft(fromInt(binary.get_c1px32_k$(word + 1 | 0)), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last);
    return to(BigInteger_init_$Create$_4(sign, bytes), scale);
  }
  function Cells(limit) {
    this.capacity_1 = limit;
    var tmp = this;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(limit);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(8192));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = divide(this_2, fromInt(8192));
    // Inline function 'kotlin.arrayOfNulls' call
    var size = convertToInt(tmp$ret$2);
    tmp.pages_1 = Array(size);
  }
  protoOf(Cells).get_c1px32_k$ = function (index) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.capacity_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tmp0_safe_receiver = this.pages_1[index / 8192 | 0];
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver[index % 8192 | 0];
    return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  };
  protoOf(Cells).set_g707pu_k$ = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.capacity_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var slot = index / 8192 | 0;
    var tmp0_elvis_lhs = this.pages_1[slot];
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.comparisons.minOf' call
      var b = this.capacity_1 - imul(slot, 8192) | 0;
      var tmp$ret$1 = Math.min(8192, b);
      // Inline function 'kotlin.also' call
      var this_0 = new Int32Array(tmp$ret$1);
      this.pages_1[slot] = this_0;
      tmp = this_0;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var page = tmp;
    page[index % 8192 | 0] = value;
  };
  function DecimalWords(capacity) {
    this.cells_1 = new Cells(capacity);
    this.size_1 = 0;
  }
  protoOf(DecimalWords).get_size_woubt6_k$ = function () {
    return this.size_1;
  };
  protoOf(DecimalWords).get_c1px32_k$ = function (index) {
    return this.cells_1.get_c1px32_k$(index);
  };
  protoOf(DecimalWords).append_dlf032_k$ = function (value) {
    this.cells_1.set_g707pu_k$(this.size_1, value);
    this.size_1 = this.size_1 + 1 | 0;
  };
  protoOf(DecimalWords).digits_m0zfve_k$ = function () {
    // Inline function 'kotlin.check' call
    if (!(this.size_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var width = 1;
    var top = this.cells_1.get_c1px32_k$(this.size_1 - 1 | 0);
    while (width < 9 && top >= DecimalDivision581_getInstance().powers_1[width]) {
      width = width + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.size_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = width;
    return add(tmp0_0, fromInt(other_0));
  };
  protoOf(DecimalWords).trailingZeros_kq0ik1_k$ = function () {
    var index = 0;
    while (this.cells_1.get_c1px32_k$(index) === 0) {
      index = index + 1 | 0;
    }
    var value = this.cells_1.get_c1px32_k$(index);
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = index;
    var zeros = multiply(tmp0, fromInt(other));
    while ((value % 10 | 0) === 0) {
      value = value / 10 | 0;
      var _unary__edvuaz = zeros;
      zeros = add(_unary__edvuaz, get_ONE());
    }
    return zeros;
  };
  protoOf(DecimalWords).digitFromLeft_byk0bm_k$ = function (position, digits) {
    // Inline function 'kotlin.Long.minus' call
    var tmp$ret$0 = subtract(digits, fromInt(1));
    var at = subtract(tmp$ret$0, position);
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(at, fromInt(9));
    var tmp = this.cells_1.get_c1px32_k$(convertToInt(tmp$ret$1));
    var tmp_0 = DecimalDivision581_getInstance().powers_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(at, fromInt(9));
    return (tmp / tmp_0[convertToInt(tmp$ret$2)] | 0) % 10 | 0;
  };
  protoOf(DecimalWords).odd_2crz_k$ = function () {
    return !((this.cells_1.get_c1px32_k$(0) % 2 | 0) === 0);
  };
  protoOf(DecimalWords).endsInZero_4aac1n_k$ = function () {
    return (this.cells_1.get_c1px32_k$(0) % 10 | 0) === 0;
  };
  protoOf(DecimalWords).multiplyAdd_d61a5v_k$ = function (factor, addend) {
    var carry = fromInt(addend);
    var inductionVariable = 0;
    var last = this.size_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(this.cells_1.get_c1px32_k$(i));
        var tmp$ret$0 = multiply(this_0, fromInt(factor));
        var part = add(tmp$ret$0, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$1 = modulo(part, fromInt(other));
        this.cells_1.set_g707pu_k$(i, convertToInt(tmp$ret$1));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < last);
    if (!equalsLong(carry, new Long(0, 0))) {
      this.append_dlf032_k$(convertToInt(carry));
    }
    trim(this);
  };
  protoOf(DecimalWords).product_il4yc8_k$ = function (source, factor) {
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = source.size_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(source.cells_1.get_c1px32_k$(i));
        var tmp$ret$0 = multiply(this_0, fromInt(factor));
        var part = add(tmp$ret$0, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$1 = modulo(part, fromInt(other));
        this.cells_1.set_g707pu_k$(i, convertToInt(tmp$ret$1));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < last);
    this.size_1 = source.size_1;
    if (!equalsLong(carry, new Long(0, 0))) {
      this.append_dlf032_k$(convertToInt(carry));
    }
  };
  protoOf(DecimalWords).compare_s2p8dm_k$ = function (other) {
    if (!(this.size_1 === other.size_1))
      return compareTo(this.size_1, other.size_1);
    var inductionVariable = this.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var order = compareTo(this.cells_1.get_c1px32_k$(i), other.cells_1.get_c1px32_k$(i));
        if (!(order === 0))
          return order;
      }
       while (0 <= inductionVariable);
    return 0;
  };
  protoOf(DecimalWords).subtract_djf557_k$ = function (other) {
    var borrow = new Long(0, 0);
    var inductionVariable = 0;
    var last = this.size_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = fromInt(this.cells_1.get_c1px32_k$(i));
        // Inline function 'kotlin.Long.minus' call
        var other_0 = i < other.size_1 ? other.cells_1.get_c1px32_k$(i) : 0;
        var tmp$ret$0 = subtract(tmp0, fromInt(other_0));
        var part = subtract(tmp$ret$0, borrow);
        borrow = compare(part, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
        if (compare(part, new Long(0, 0)) < 0) {
          var tmp0_0 = part;
          // Inline function 'kotlin.Long.plus' call
          var other_1 = 1000000000;
          part = add(tmp0_0, fromInt(other_1));
        }
        this.cells_1.set_g707pu_k$(i, convertToInt(part));
      }
       while (inductionVariable < last);
    // Inline function 'kotlin.check' call
    if (!equalsLong(borrow, new Long(0, 0))) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    trim(this);
  };
  protoOf(DecimalWords).increment_vga7q7_k$ = function () {
    var i = 0;
    while (i < this.size_1 && this.cells_1.get_c1px32_k$(i) === 999999999) {
      this.cells_1.set_g707pu_k$(i, 0);
      i = i + 1 | 0;
    }
    if (i === this.size_1) {
      this.append_dlf032_k$(1);
    } else {
      this.cells_1.set_g707pu_k$(i, this.cells_1.get_c1px32_k$(i) + 1 | 0);
    }
  };
  protoOf(DecimalWords).divideTen_qc6bdo_k$ = function () {
    var remainder = new Long(0, 0);
    var inductionVariable = this.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.cells_1.get_c1px32_k$(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(10));
        this.cells_1.set_g707pu_k$(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(10));
      }
       while (0 <= inductionVariable);
    trim(this);
    return convertToInt(remainder);
  };
  protoOf(DecimalWords).appendZeroDigits_7dl9km_k$ = function (count) {
    // Inline function 'kotlin.check' call
    if (!(this.size_1 > 0 && compare(count, new Long(0, 0)) >= 0 && compare(add(this.digits_m0zfve_k$(), count), new Long(646456993, 0)) <= 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(count, fromInt(9));
    var whole = convertToInt(tmp$ret$1);
    if (!(whole === 0)) {
      var inductionVariable = this.size_1 - 1 | 0;
      if (0 <= inductionVariable)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + -1 | 0;
          this.cells_1.set_g707pu_k$(i + whole | 0, this.cells_1.get_c1px32_k$(i));
        }
         while (0 <= inductionVariable);
      var inductionVariable_0 = 0;
      if (inductionVariable_0 < whole)
        do {
          var i_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          this.cells_1.set_g707pu_k$(i_0, 0);
        }
         while (inductionVariable_0 < whole);
      this.size_1 = this.size_1 + whole | 0;
    }
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(count, fromInt(9));
    var rest = convertToInt(tmp$ret$2);
    if (!(rest === 0)) {
      this.multiplyAdd_d61a5v_k$(DecimalDivision581_getInstance().powers_1[rest], 0);
    }
  };
  protoOf(DecimalWords).removeZeroDigits583_s9i4xs_k$ = function (count) {
    // Inline function 'kotlin.check' call
    if (!(this.size_1 > 0 && compare(count, new Long(0, 0)) >= 0 && compare(count, this.trailingZeros_kq0ik1_k$()) <= 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(count, fromInt(9));
    var whole = convertToInt(tmp$ret$1);
    var inductionVariable = 0;
    if (inductionVariable < whole)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.check' call
        if (!(this.cells_1.get_c1px32_k$(i) === 0)) {
          throw IllegalStateException_init_$Create$('Check failed.');
        }
      }
       while (inductionVariable < whole);
    var remaining = this.size_1 - whole | 0;
    var inductionVariable_0 = 0;
    if (inductionVariable_0 < remaining)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        this.cells_1.set_g707pu_k$(i_0, this.cells_1.get_c1px32_k$(i_0 + whole | 0));
      }
       while (inductionVariable_0 < remaining);
    this.size_1 = remaining;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$3 = modulo(count, fromInt(9));
    var rest = convertToInt(tmp$ret$3);
    if (!(rest === 0)) {
      var factor = DecimalDivision581_getInstance().powers_1[rest];
      var residual = new Long(0, 0);
      var inductionVariable_1 = this.size_1 - 1 | 0;
      if (0 <= inductionVariable_1)
        do {
          var i_1 = inductionVariable_1;
          inductionVariable_1 = inductionVariable_1 + -1 | 0;
          var tmp0 = residual;
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp0_0 = multiply(tmp0, fromInt(other));
          // Inline function 'kotlin.Long.plus' call
          var other_0 = this.cells_1.get_c1px32_k$(i_1);
          var part = add(tmp0_0, fromInt(other_0));
          // Inline function 'kotlin.Long.div' call
          var tmp$ret$6 = divide(part, fromInt(factor));
          this.cells_1.set_g707pu_k$(i_1, convertToInt(tmp$ret$6));
          // Inline function 'kotlin.Long.rem' call
          residual = modulo(part, fromInt(factor));
        }
         while (0 <= inductionVariable_1);
      // Inline function 'kotlin.check' call
      if (!equalsLong(residual, new Long(0, 0))) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
    }
    trim(this);
  };
  function fixedScale592$nextDigit(position, inputDigits, a, remainder, trial, b) {
    var input = compare(position._v, inputDigits) < 0 ? a.digitFromLeft_byk0bm_k$(position._v, inputDigits) : 0;
    var _unary__edvuaz = position._v;
    position._v = add(_unary__edvuaz, get_ONE());
    remainder.multiplyAdd_d61a5v_k$(10, input);
    var digit = 9;
    $l$loop: while (digit > 0) {
      trial.product_il4yc8_k$(b, digit);
      if (remainder.compare_s2p8dm_k$(trial) >= 0)
        break $l$loop;
      digit = digit - 1 | 0;
    }
    if (!(digit === 0)) {
      remainder.subtract_djf557_k$(trial);
    }
    return digit;
  }
  function DecimalDivision581() {
    DecimalDivision581_instance = this;
    this.BASE_1 = 1000000000;
    this.PAGE_1 = 8192;
    this.MAX_DIGITS_1 = new Long(646456993, 0);
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.powers_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalDivision581).largePrecision_q4a9aj_k$ = function (sign, left, right, preferred, precision) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(fromInt(precision), new Long(646456993, 0)) > 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var gcd = left.gcd_ucjjcu_k$(right);
    var numerator = left.divide_bsns5t_k$(gcd);
    var denominator = right.divide_bsns5t_k$(gcd);
    var twos = denominator.getLowestSetBit_vnfocz_k$();
    denominator = denominator.shiftRight_g7qmqq_k$(twos);
    var five = Companion_getInstance_2().valueOf_wwtjy2_k$(new Long(5, 0));
    var fives = 0;
    $l$loop: while (true) {
      var qr = denominator.divideAndRemainder_2r68pv_k$(five);
      if (!(qr[1].signum_exb08b_k$() === 0))
        break $l$loop;
      denominator = qr[0];
      fives = fives + 1 | 0;
    }
    if (!denominator.equals(Companion_getInstance_2().get_ONE_18jnkz_k$()))
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = fives;
    var places = Math.max(twos, b);
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$4 = add(preferred, fromInt(places));
    var scale = checkedScale_0(this, tmp$ret$4);
    if (places > twos)
      numerator = numerator.shiftLeft_qqh5sf_k$(places - twos | 0);
    if (places > fives)
      numerator = numerator.multiply_9xrhei_k$(five.pow_iykav4_k$(places - fives | 0));
    return to(sign < 0 ? numerator.negate_hcqk8u_k$() : numerator, scale);
  };
  protoOf(DecimalDivision581).rounded_ir9ghy_k$ = function (sign, left, right, preferred, context) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(sign === -1 || sign === 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    var tmp_0;
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(left.length === 0)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      // Inline function 'kotlin.collections.isEmpty' call
      tmp_0 = !(right.length === 0);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = context.get_precision_e8tfsb_k$() > 0;
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(new Long(1, -1), preferred) <= 0 ? compare(preferred, new Long(-1, 0)) <= 0 : false)) {
      var message_1 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_1));
    }
    var tmp0 = left.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = right.length;
    var tmp$ret$13 = Math.max(tmp0, b);
    var scratch = new Cells(tmp$ret$13);
    var a = decimalChunks(this, left, scratch);
    var b_0 = decimalChunks(this, right, scratch);
    var inputDigits = a.digits_m0zfve_k$();
    var lastNonzero = subtract(inputDigits, a.trailingZeros_kq0ik1_k$());
    var remainder = new DecimalWords(b_0.size_1 + 1 | 0);
    var trial = new DecimalWords(b_0.size_1 + 1 | 0);
    var precision = fromInt(context.get_precision_e8tfsb_k$());
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.plus' call
    var this_0 = add(precision, fromInt(1));
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(9));
    var tmp$ret$17 = add(this_2, fromInt(1));
    var quotient = new DecimalWords(convertToInt(tmp$ret$17));
    var position = new Long(0, 0);
    var kept = new Long(0, 0);
    var exponent = new Long(0, 0);
    $l$loop_0: while (true) {
      var input = compare(position, inputDigits) < 0 ? a.digitFromLeft_byk0bm_k$(position, inputDigits) : 0;
      var _unary__edvuaz = position;
      position = add(_unary__edvuaz, get_ONE());
      remainder.multiplyAdd_d61a5v_k$(10, input);
      var digit = 9;
      $l$loop: while (digit > 0) {
        trial.product_il4yc8_k$(b_0, digit);
        if (remainder.compare_s2p8dm_k$(trial) >= 0)
          break $l$loop;
        digit = digit - 1 | 0;
      }
      if (!(digit === 0)) {
        remainder.subtract_djf557_k$(trial);
      }
      var exact = remainder.size_1 === 0 && compare(position, lastNonzero) >= 0;
      if (equalsLong(kept, new Long(0, 0)) && digit === 0) {
        // Inline function 'kotlin.check' call
        if (!!exact) {
          throw IllegalStateException_init_$Create$('Check failed.');
        }
        continue $l$loop_0;
      }
      if (equalsLong(kept, new Long(0, 0)))
        exponent = subtract(inputDigits, position);
      if (compare(kept, precision) < 0) {
        quotient.multiplyAdd_d61a5v_k$(10, digit);
        var _unary__edvuaz_0 = kept;
        kept = add(_unary__edvuaz_0, get_ONE());
        if (exact)
          return exactResult(this, quotient, sign, preferred, exponent, kept, precision);
      } else {
        if (digit === 0 && exact)
          return exactResult(this, quotient, sign, preferred, exponent, kept, precision);
        var half = digit === 5 && !exact ? 1 : compareTo(digit, 5);
        if (increment_0(this, context.get_roundingMode_uxzxk0_k$(), sign, half, quotient.odd_2crz_k$())) {
          quotient.increment_vga7q7_k$();
        }
        // Inline function 'kotlin.Long.minus' call
        var this_3 = add(preferred, precision);
        var tmp$ret$19 = subtract(this_3, fromInt(1));
        var scale = subtract(tmp$ret$19, exponent);
        if (compare(quotient.digits_m0zfve_k$(), precision) > 0) {
          // Inline function 'kotlin.check' call
          if (!(quotient.divideTen_qc6bdo_k$() === 0)) {
            throw IllegalStateException_init_$Create$('Check failed.');
          }
          var _unary__edvuaz_1 = scale;
          scale = subtract(_unary__edvuaz_1, get_ONE());
        }
        return publish(this, quotient, sign, checkedScale_0(this, scale));
      }
    }
  };
  protoOf(DecimalDivision581).fixedScale592_pl4rvi_k$ = function (sign, left, right, shift, mode) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(sign === -1 || sign === 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(left.length === 0)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      // Inline function 'kotlin.collections.isEmpty' call
      tmp = !(right.length === 0);
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(new Long(-2147483647, -2), shift) <= 0 ? compare(shift, new Long(2147483646, 1)) <= 0 : false)) {
      var message_1 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_1));
    }
    var tmp0 = left.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = right.length;
    var tmp$ret$13 = Math.max(tmp0, b);
    var scratch = new Cells(tmp$ret$13);
    var a = decimalChunks(this, left, scratch);
    var b_0 = decimalChunks(this, right, scratch);
    var inputDigits = a.digits_m0zfve_k$();
    var limit = add(inputDigits, shift);
    if (compare(limit, new Long(0, 0)) < 0)
      return increment_0(this, mode, sign, -1, false) ? Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt(sign)) : Companion_getInstance_2().get_ZERO_wodlgx_k$();
    if (compare(subtract(limit, b_0.digits_m0zfve_k$()), new Long(646456993, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    var lastNonzero = subtract(inputDigits, a.trailingZeros_kq0ik1_k$());
    var remainder = new DecimalWords(b_0.size_1 + 1 | 0);
    var trial = new DecimalWords(b_0.size_1 + 1 | 0);
    var tmp0_0 = new Long(646456993, 0);
    var tmp0_1 = new Long(1, 0);
    // Inline function 'kotlin.Long.plus' call
    var this_0 = subtract(limit, b_0.digits_m0zfve_k$());
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_1 = add(this_0, fromInt(1));
    // Inline function 'kotlin.comparisons.minOf' call
    var b_2 = compare(tmp0_1, b_1) >= 0 ? tmp0_1 : b_1;
    var maximumDigits = compare(tmp0_0, b_2) <= 0 ? tmp0_0 : b_2;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(maximumDigits, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(9));
    var tmp$ret$19 = add(this_2, fromInt(1));
    var quotient = new DecimalWords(convertToInt(tmp$ret$19));
    var position = {_v: new Long(0, 0)};
    var zeros = new Long(0, 0);
    $l$loop: while (compare(position._v, limit) < 0) {
      var digit = fixedScale592$nextDigit(position, inputDigits, a, remainder, trial, b_0);
      if (digit === 0) {
        if (!(quotient.size_1 === 0)) {
          var _unary__edvuaz = zeros;
          zeros = add(_unary__edvuaz, get_ONE());
        }
      } else {
        var tmp_0;
        if (quotient.size_1 === 0) {
          tmp_0 = new Long(1, 0);
        } else {
          // Inline function 'kotlin.Long.plus' call
          var this_3 = add(quotient.digits_m0zfve_k$(), zeros);
          tmp_0 = add(this_3, fromInt(1));
        }
        var digits = tmp_0;
        if (compare(digits, new Long(646456993, 0)) > 0)
          throw ArithmeticException_init_$Create$('BigInteger overflow');
        if (!(quotient.size_1 === 0)) {
          quotient.appendZeroDigits_7dl9km_k$(zeros);
        }
        quotient.multiplyAdd_d61a5v_k$(10, digit);
        zeros = new Long(0, 0);
      }
      if (remainder.size_1 === 0 && compare(position._v, lastNonzero) >= 0) {
        if (!(quotient.size_1 === 0))
          zeros = add(zeros, subtract(limit, position._v));
        position._v = limit;
        break $l$loop;
      }
    }
    if (!(quotient.size_1 === 0)) {
      if (compare(add(quotient.digits_m0zfve_k$(), zeros), new Long(646456993, 0)) > 0)
        throw ArithmeticException_init_$Create$('BigInteger overflow');
      quotient.appendZeroDigits_7dl9km_k$(zeros);
    }
    if (!(remainder.size_1 === 0) || compare(position._v, lastNonzero) < 0) {
      var guard = fixedScale592$nextDigit(position, inputDigits, a, remainder, trial, b_0);
      var sticky = !(remainder.size_1 === 0) || compare(position._v, lastNonzero) < 0;
      var half = guard === 5 && sticky ? 1 : compareTo(guard, 5);
      if (increment_0(this, mode, sign, half, !(quotient.size_1 === 0) && quotient.odd_2crz_k$())) {
        quotient.increment_vga7q7_k$();
      }
    }
    if (quotient.size_1 === 0)
      return Companion_getInstance_2().get_ZERO_wodlgx_k$();
    if (compare(quotient.digits_m0zfve_k$(), new Long(646456993, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    return publish(this, quotient, sign, 0).first;
  };
  protoOf(DecimalDivision581).integral_b2vfd8_k$ = function (sign, left, right, preferred) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(sign === -1 || sign === 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    var tmp_0;
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(left.length === 0)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      // Inline function 'kotlin.collections.isEmpty' call
      tmp_0 = !(right.length === 0);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = preferred < 0;
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    var tmp0 = left.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = right.length;
    var tmp$ret$10 = Math.max(tmp0, b);
    var scratch = new Cells(tmp$ret$10);
    var a = decimalChunks(this, left, scratch);
    var b_0 = decimalChunks(this, right, scratch);
    var inputDigits = a.digits_m0zfve_k$();
    var lastNonzero = subtract(inputDigits, a.trailingZeros_kq0ik1_k$());
    var limit = subtract(inputDigits, fromInt(preferred));
    var remainder = new DecimalWords(b_0.size_1 + 1 | 0);
    var trial = new DecimalWords(b_0.size_1 + 1 | 0);
    var tmp0_0 = new Long(1, 0);
    var tmp0_1 = new Long(646456993, 0);
    // Inline function 'kotlin.Long.plus' call
    var this_0 = subtract(limit, b_0.digits_m0zfve_k$());
    // Inline function 'kotlin.comparisons.minOf' call
    var b_1 = add(this_0, fromInt(1));
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_2 = compare(tmp0_1, b_1) <= 0 ? tmp0_1 : b_1;
    var quotientDigits = compare(tmp0_0, b_2) >= 0 ? tmp0_0 : b_2;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(quotientDigits, fromInt(8));
    var tmp$ret$15 = divide(this_1, fromInt(9));
    var quotient = new DecimalWords(convertToInt(tmp$ret$15));
    var position = new Long(0, 0);
    var zeros = new Long(0, 0);
    $l$loop_0: while (compare(position, limit) < 0) {
      var input = compare(position, inputDigits) < 0 ? a.digitFromLeft_byk0bm_k$(position, inputDigits) : 0;
      var _unary__edvuaz = position;
      position = add(_unary__edvuaz, get_ONE());
      remainder.multiplyAdd_d61a5v_k$(10, input);
      var digit = 9;
      $l$loop: while (digit > 0) {
        trial.product_il4yc8_k$(b_0, digit);
        if (remainder.compare_s2p8dm_k$(trial) >= 0)
          break $l$loop;
        digit = digit - 1 | 0;
      }
      if (!(digit === 0)) {
        remainder.subtract_djf557_k$(trial);
      }
      if (digit === 0) {
        if (!(quotient.size_1 === 0)) {
          var _unary__edvuaz_0 = zeros;
          zeros = add(_unary__edvuaz_0, get_ONE());
        }
      } else {
        var tmp_1;
        if (quotient.size_1 === 0) {
          tmp_1 = new Long(1, 0);
        } else {
          // Inline function 'kotlin.Long.plus' call
          var this_2 = add(quotient.digits_m0zfve_k$(), zeros);
          tmp_1 = add(this_2, fromInt(1));
        }
        var digits = tmp_1;
        if (compare(digits, new Long(646456993, 0)) > 0)
          throw ArithmeticException_init_$Create$('BigInteger overflow');
        if (!(quotient.size_1 === 0)) {
          quotient.appendZeroDigits_7dl9km_k$(zeros);
        }
        quotient.multiplyAdd_d61a5v_k$(10, digit);
        zeros = new Long(0, 0);
      }
      if (remainder.size_1 === 0 && compare(position, lastNonzero) >= 0) {
        if (quotient.size_1 === 0)
          return to(Companion_getInstance_2().get_ZERO_wodlgx_k$(), preferred);
        zeros = add(zeros, subtract(limit, position));
        break $l$loop_0;
      }
    }
    if (quotient.size_1 === 0)
      return to(Companion_getInstance_2().get_ZERO_wodlgx_k$(), preferred);
    var tmp0_2 = negate(zeros);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_3 = fromInt(preferred);
    var scale = compare(tmp0_2, b_3) >= 0 ? tmp0_2 : b_3;
    var padding = add(zeros, scale);
    if (compare(add(quotient.digits_m0zfve_k$(), padding), new Long(646456993, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    quotient.appendZeroDigits_7dl9km_k$(padding);
    return publish(this, quotient, sign, convertToInt(scale));
  };
  protoOf(DecimalDivision581).matchesInteger583_g68r3b_k$ = function (candidate, scale, integer) {
    var tmp0 = candidate.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = integer.length;
    var tmp$ret$0 = Math.max(tmp0, b);
    var scratch = new Cells(tmp$ret$0);
    var tmp;
    // Inline function 'kotlin.collections.isEmpty' call
    if (candidate.length === 0) {
      tmp = null;
    } else {
      tmp = decimalChunks(this, candidate, scratch);
    }
    var coefficient = tmp;
    var tmp0_elvis_lhs = integerView583(this, coefficient, scale);
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      return false;
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    var expected = tmp_0;
    // Inline function 'kotlin.collections.isEmpty' call
    if (integer.length === 0)
      return equalsLong(expected.length_1, new Long(0, 0));
    var actual = decimalChunks(this, integer, scratch);
    if (!equalsLong(actual.digits_m0zfve_k$(), expected.length_1))
      return false;
    var position = new Long(0, 0);
    while (compare(position, expected.length_1) < 0) {
      if (!(actual.digitFromLeft_byk0bm_k$(position, expected.length_1) === expected.digit_5clizl_k$(position)))
        return false;
      var _unary__edvuaz = position;
      position = add(_unary__edvuaz, get_ONE());
    }
    return true;
  };
  protoOf(DecimalDivision581).certifiedResidual583_9qpnmp_k$ = function (sign, left, right, candidate, preferred, divisorScale, quotientScale) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(sign === -1 || sign === 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    var tmp_0;
    var tmp_1;
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(left.length === 0)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      // Inline function 'kotlin.collections.isEmpty' call
      tmp_1 = !(right.length === 0);
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = preferred < 0;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = quotientScale <= 0;
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    var tmp_2;
    // Inline function 'kotlin.collections.isEmpty' call
    if (candidate.length === 0) {
      tmp_2 = !(quotientScale === preferred);
    } else {
      tmp_2 = false;
    }
    if (tmp_2)
      return null;
    var tmp0 = left.length;
    var tmp2 = right.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var c = candidate.length;
    var tmp$ret$11 = Math.max(tmp0, tmp2, c);
    var scratch = new Cells(tmp$ret$11);
    var a = decimalChunks(this, left, scratch);
    var b = decimalChunks(this, right, scratch);
    var tmp_3;
    // Inline function 'kotlin.collections.isEmpty' call
    if (candidate.length === 0) {
      tmp_3 = null;
    } else {
      tmp_3 = decimalChunks(this, candidate, scratch);
    }
    var q = tmp_3;
    var tmp0_elvis_lhs = integerView583(this, q, quotientScale);
    var tmp_4;
    if (tmp0_elvis_lhs == null) {
      return null;
    } else {
      tmp_4 = tmp0_elvis_lhs;
    }
    var expected = tmp_4;
    var inputDigits = a.digits_m0zfve_k$();
    var lastNonzero = subtract(inputDigits, a.trailingZeros_kq0ik1_k$());
    var limit = subtract(inputDigits, fromInt(preferred));
    var remainder = new DecimalWords(b.size_1 + 1 | 0);
    var trial = new DecimalWords(b.size_1 + 1 | 0);
    var position = new Long(0, 0);
    var emitted = new Long(0, 0);
    var started = false;
    $l$loop_0: while (compare(position, limit) < 0) {
      var input = compare(position, inputDigits) < 0 ? a.digitFromLeft_byk0bm_k$(position, inputDigits) : 0;
      var _unary__edvuaz = position;
      position = add(_unary__edvuaz, get_ONE());
      remainder.multiplyAdd_d61a5v_k$(10, input);
      var digit = 9;
      $l$loop: while (digit > 0) {
        trial.product_il4yc8_k$(b, digit);
        if (remainder.compare_s2p8dm_k$(trial) >= 0)
          break $l$loop;
        digit = digit - 1 | 0;
      }
      if (!(digit === 0)) {
        remainder.subtract_djf557_k$(trial);
      }
      if (!(digit === 0))
        started = true;
      if (started) {
        if (compare(emitted, expected.length_1) >= 0 || !(digit === expected.digit_5clizl_k$(emitted)))
          return null;
        var _unary__edvuaz_0 = emitted;
        emitted = add(_unary__edvuaz_0, get_ONE());
      }
      if (remainder.size_1 === 0 && compare(position, lastNonzero) >= 0) {
        var remaining = subtract(limit, position);
        if (started) {
          if (!equalsLong(add(emitted, remaining), expected.length_1) || !expected.zeroTail_1lfwoa_k$(emitted))
            return null;
          emitted = add(emitted, remaining);
        } else if (!equalsLong(expected.length_1, new Long(0, 0)))
          return null;
        break $l$loop_0;
      }
    }
    if (!equalsLong(emitted, expected.length_1))
      return null;
    var tmp0_0 = negate(fromInt(preferred));
    // Inline function 'kotlin.comparisons.minOf' call
    var b_0 = negate(fromInt(quotientScale));
    var removed = compare(tmp0_0, b_0) <= 0 ? tmp0_0 : b_0;
    var scale = subtract(fromInt(divisorScale), removed);
    // Inline function 'kotlin.check' call
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    if (remainder.size_1 === 0)
      return to(Companion_getInstance_2().get_ZERO_wodlgx_k$(), convertToInt(scale));
    remainder.removeZeroDigits583_s9i4xs_k$(removed);
    return publish(this, remainder, sign, convertToInt(scale));
  };
  var DecimalDivision581_instance;
  function DecimalDivision581_getInstance() {
    if (DecimalDivision581_instance == null)
      new DecimalDivision581();
    return DecimalDivision581_instance;
  }
  function materializedDecimalDivision581(leftBits, rightBits, precision, preferred, target, shift) {
    if (leftBits <= 0 || rightBits <= 0 || precision <= 0 || !(compare(new Long(-2147483648, -1), preferred) <= 0 ? compare(preferred, new Long(2147483647, 0)) <= 0 : false) || !(compare(new Long(-2147483648, -1), target) <= 0 ? compare(target, new Long(2147483647, 0)) <= 0 : false) || equalsLong(target, new Long(-2147483648, -1)) || !(compare(new Long(-646456992, -1), shift) <= 0 ? compare(shift, new Long(646456992, 0)) <= 0 : false))
      return false;
    var numeratorBits = add(fromInt(leftBits), compare(shift, new Long(0, 0)) > 0 ? multiply(new Long(4, 0), shift) : new Long(0, 0));
    var denominatorBits = add(fromInt(rightBits), compare(shift, new Long(0, 0)) < 0 ? multiply(new Long(-4, -1), shift) : new Long(0, 0));
    var tmp;
    if (compare(numeratorBits, new Long(2147483647, 0)) <= 0 && compare(denominatorBits, new Long(2147483647, 0)) <= 0) {
      // Inline function 'kotlin.Long.times' call
      var this_0 = new Long(4, 0);
      // Inline function 'kotlin.Long.plus' call
      var this_1 = multiply(this_0, fromInt(precision));
      var tmp$ret$1 = add(this_1, fromInt(rightBits));
      tmp = compare(tmp$ret$1, new Long(2147483647, 0)) <= 0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function materializedDecimalResidual583(sourceBits, divisorBits, quotientBits, sourceScale, divisorScale, quotientScale) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(quotientScale);
    var productScale = add(this_0, fromInt(divisorScale));
    if (!(compare(new Long(-2147483648, -1), productScale) <= 0 ? compare(productScale, new Long(2147483647, 0)) <= 0 : false))
      return false;
    // Inline function 'kotlin.comparisons.maxOf' call
    var a = fromInt(sourceScale);
    var scale = compare(a, productScale) >= 0 ? a : productScale;
    // Inline function 'kotlin.Long.minus' call
    var sourceRaise = subtract(scale, fromInt(sourceScale));
    var productRaise = subtract(scale, productScale);
    if (!(compare(new Long(0, 0), sourceRaise) <= 0 ? compare(sourceRaise, new Long(646456992, 0)) <= 0 : false) || !(compare(new Long(0, 0), productRaise) <= 0 ? compare(productRaise, new Long(646456992, 0)) <= 0 : false))
      return false;
    var tmp;
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$3 = Math.max(sourceBits, 1);
    if (compare(add(fromInt(tmp$ret$3), multiply(new Long(4, 0), sourceRaise)), new Long(2147483646, 0)) <= 0) {
      // Inline function 'kotlin.comparisons.maxOf' call
      var tmp$ret$4 = Math.max(quotientBits, 1);
      var tmp0 = fromInt(tmp$ret$4);
      // Inline function 'kotlin.comparisons.maxOf' call
      // Inline function 'kotlin.Long.plus' call
      var other = Math.max(divisorBits, 1);
      var tmp$ret$6 = add(tmp0, fromInt(other));
      tmp = compare(add(tmp$ret$6, multiply(new Long(4, 0), productRaise)), new Long(2147483646, 0)) <= 0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function numericallyEquals(_this__u8e3s4, other) {
    return toDecimalKey(_this__u8e3s4).equals(toDecimalKey(other));
  }
  function _get_sign__ddo3e6_0($this) {
    return $this.sign_1;
  }
  function _get_digits__5rvfvf($this) {
    return $this.digits_1;
  }
  function _get_scale__bic0mx($this) {
    return $this.scale_1;
  }
  function _get_hash__d7hhq5($this) {
    return $this.hash_1;
  }
  function DecimalKey(value) {
    var snapshot = new BigDecimal(value.unscaledValue_ga07pa_k$(), value.scale_1t1miy_k$());
    this.sign_1 = snapshot.signum_exb08b_k$();
    if (this.sign_1 === 0) {
      this.digits_1 = '0';
      this.scale_1 = new Long(0, 0);
    } else {
      var text = removePrefix(snapshot.unscaledValue_ga07pa_k$().toString(), '-');
      var end = text.length;
      while (charCodeAt(text, end - 1 | 0) === _Char___init__impl__6a9atx(48)) {
        end = end - 1 | 0;
      }
      this.digits_1 = substring_0(text, 0, end);
      var tmp = this;
      var tmp0 = fromInt(snapshot.scale_1t1miy_k$());
      // Inline function 'kotlin.Long.minus' call
      var other = text.length - end | 0;
      tmp.scale_1 = subtract(tmp0, fromInt(other));
    }
    this.hash_1 = imul(31, imul(31, this.sign_1) + getStringHashCode(this.digits_1) | 0) + this.scale_1.hashCode() | 0;
  }
  protoOf(DecimalKey).equals = function (other) {
    var tmp;
    var tmp_0;
    var tmp_1;
    if (other instanceof DecimalKey) {
      tmp_1 = this.sign_1 === other.sign_1;
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = equalsLong(this.scale_1, other.scale_1);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.digits_1 === other.digits_1;
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(DecimalKey).hashCode = function () {
    return this.hash_1;
  };
  protoOf(DecimalKey).compareTo_gpdn6t_k$ = function (other) {
    if (!(this.sign_1 === other.sign_1))
      return compareTo(this.sign_1, other.sign_1);
    if (this.sign_1 === 0)
      return 0;
    var exponentOrder = subtract(fromInt(this.digits_1.length), this.scale_1).compareTo_9jj042_k$(subtract(fromInt(other.digits_1.length), other.scale_1));
    if (!(exponentOrder === 0))
      return imul(this.sign_1, exponentOrder);
    var inductionVariable = 0;
    var tmp0 = this.digits_1.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = other.digits_1.length;
    var last = Math.max(tmp0, b);
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var left = index < this.digits_1.length ? charCodeAt(this.digits_1, index) : _Char___init__impl__6a9atx(48);
        var right = index < other.digits_1.length ? charCodeAt(other.digits_1, index) : _Char___init__impl__6a9atx(48);
        if (!(left === right))
          return imul(this.sign_1, Char__compareTo_impl_ypi4mb(left, right));
      }
       while (inductionVariable < last);
    return 0;
  };
  protoOf(DecimalKey).compareTo_hpufkf_k$ = function (other) {
    return this.compareTo_gpdn6t_k$(other instanceof DecimalKey ? other : THROW_CCE());
  };
  protoOf(DecimalKey).toString = function () {
    return (this.sign_1 < 0 ? '-' : '') + this.digits_1 + 'E' + negate(this.scale_1).toString();
  };
  function toDecimalKey(_this__u8e3s4) {
    return new DecimalKey(_this__u8e3s4);
  }
  function _get_capacity__a9k9f3_0($this) {
    return $this.capacity_1;
  }
  function _get_pages__cygrxv_0($this) {
    return $this.pages_1;
  }
  function _get_capacity__a9k9f3_1($this) {
    return $this.capacity_1;
  }
  function _get_cells__j1rckg_0($this) {
    return $this.cells_1;
  }
  function _set_size__9twho6_0($this, _set____db54di) {
    $this.size_1 = _set____db54di;
  }
  function Companion_2() {
    Companion_instance_2 = this;
  }
  protoOf(Companion_2).one_2d0m_k$ = function () {
    // Inline function 'kotlin.also' call
    var this_0 = new Words(2);
    this_0.append_dlf032_k$(1);
    return this_0;
  };
  var Companion_instance_2;
  function Companion_getInstance_3() {
    if (Companion_instance_2 == null)
      new Companion_2();
    return Companion_instance_2;
  }
  function _get_BASE__cm0716_0($this) {
    return $this.BASE_1;
  }
  function _get_PAGE__ctp2fw_0($this) {
    return $this.PAGE_1;
  }
  function _get_MAX_DIGITS__vbaa22_0($this) {
    return $this.MAX_DIGITS_1;
  }
  function _get_MAX_WORK__aw8mjj($this) {
    return $this.MAX_WORK_1;
  }
  function _get_MAX_CELLS__r0n1id($this) {
    return $this.MAX_CELLS_1;
  }
  function _get_powers__vdnpa5_0($this) {
    return $this.powers_1;
  }
  function State(sign, core, zeros, scale) {
    this.sign_1 = sign;
    this.core_1 = core;
    this.zeros_1 = zeros;
    this.scale_1 = scale;
  }
  protoOf(State).get_sign_wa43n3_k$ = function () {
    return this.sign_1;
  };
  protoOf(State).get_core_c1sokv_k$ = function () {
    return this.core_1;
  };
  protoOf(State).get_zeros_z2fb05_k$ = function () {
    return this.zeros_1;
  };
  protoOf(State).get_scale_iyf28x_k$ = function () {
    return this.scale_1;
  };
  protoOf(State).digits_m0zfve_k$ = function () {
    return add(this.core_1.digits_m0zfve_k$(), this.zeros_1);
  };
  function multiply_1($this, left, right, precision, mode) {
    var tmp0 = fromInt(left.scale_1);
    // Inline function 'kotlin.Long.plus' call
    var other = right.scale_1;
    var scale = add(tmp0, fromInt(other));
    if (compare(scale, new Long(-2147483648, -1)) < 0) {
      checkedScale_1($this, scale);
    }
    var a = left.core_1;
    var b = right.core_1;
    var tmp0_0 = fromInt(a.size_1);
    // Inline function 'kotlin.Long.plus' call
    var other_0 = b.size_1;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = add(tmp0_0, fromInt(other_0));
    var tmp$ret$2 = add(this_0, fromInt(1));
    var product = new Words(cellCount($this, tmp$ret$2));
    product.zeroSize_nzxzz5_k$(a.size_1 + b.size_1 | 0);
    var inductionVariable = 0;
    var last = a.size_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        var last_0 = b.size_1;
        if (inductionVariable_0 < last_0)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp0_1 = fromInt(a.get_c1px32_k$(i));
            // Inline function 'kotlin.Long.times' call
            var other_1 = b.get_c1px32_k$(j);
            var tmp0_2 = multiply(tmp0_1, fromInt(other_1));
            // Inline function 'kotlin.Long.plus' call
            var other_2 = product.get_c1px32_k$(i + j | 0);
            var tmp$ret$4 = add(tmp0_2, fromInt(other_2));
            var part = add(tmp$ret$4, carry);
            var tmp = i + j | 0;
            // Inline function 'kotlin.Long.rem' call
            var other_3 = 1000000000;
            var tmp$ret$5 = modulo(part, fromInt(other_3));
            product.set_g707pu_k$(tmp, convertToInt(tmp$ret$5));
            // Inline function 'kotlin.Long.div' call
            var other_4 = 1000000000;
            carry = divide(part, fromInt(other_4));
          }
           while (inductionVariable_0 < last_0);
        product.set_g707pu_k$(i + b.size_1 | 0, convertToInt(carry));
      }
       while (inductionVariable < last);
    product.trim_7lhr2q_k$();
    return roundOwned($this, imul(left.sign_1, right.sign_1), product, add(left.zeros_1, right.zeros_1), scale, precision, mode);
  }
  function roundOwned($this, sign, core, zeroTail, scale, precision, mode) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(new Long(1, 0), precision) <= 0 ? compare(precision, new Long(-2147483639, 0)) <= 0 : false)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var initialTail = core.trailingZeros_kq0ik1_k$();
    if (!equalsLong(initialTail, new Long(0, 0))) {
      core.dropDigits_3uq0vr_k$(initialTail);
    }
    var zeros = add(zeroTail, initialTail);
    var tmp0 = subtract(add(core.digits_m0zfve_k$(), zeros), precision);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = new Long(0, 0);
    var drop = compare(tmp0, b) >= 0 ? tmp0 : b;
    if (compare(drop, zeros) <= 0) {
      zeros = subtract(zeros, drop);
    } else {
      var coreDrop = subtract(drop, zeros);
      // Inline function 'kotlin.Long.minus' call
      var tmp$ret$4 = subtract(coreDrop, fromInt(1));
      var guard = core.digit_5clizl_k$(tmp$ret$4);
      // Inline function 'kotlin.Long.minus' call
      var tmp$ret$5 = subtract(coreDrop, fromInt(1));
      var sticky = core.anyBelow_yb9nh3_k$(tmp$ret$5);
      core.dropDigits_3uq0vr_k$(coreDrop);
      zeros = new Long(0, 0);
      var inexact = !(guard === 0) || sticky;
      var half = guard === 5 && sticky ? 1 : compareTo(guard, 5);
      if (inexact && increment_1($this, mode, sign, half, core.odd_2crz_k$())) {
        core.increment_vga7q7_k$();
        if (compare(core.digits_m0zfve_k$(), precision) > 0) {
          // Inline function 'kotlin.check' call
          if (!(core.divideSmall_udw0om_k$(10) === 0)) {
            throw IllegalStateException_init_$Create$('Check failed.');
          }
          var _unary__edvuaz = drop;
          drop = add(_unary__edvuaz, get_ONE());
        }
      }
    }
    return commit($this, sign, core, zeros, subtract(scale, drop));
  }
  function exactReciprocal($this, value) {
    var remaining = value.core_1.copy_1tks5_k$();
    var factor;
    var chunk;
    var chunkPower;
    var reciprocalBase;
    if ((remaining.get_c1px32_k$(0) % 2 | 0) === 0) {
      factor = 2;
      chunk = 536870912;
      chunkPower = 29;
      reciprocalBase = 5;
    } else if ((remaining.get_c1px32_k$(0) % 5 | 0) === 0) {
      factor = 5;
      chunk = 244140625;
      chunkPower = 12;
      reciprocalBase = 2;
    } else
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    var count = new Long(0, 0);
    while (remaining.remainderSmall_tivewm_k$(chunk) === 0) {
      // Inline function 'kotlin.check' call
      if (!(remaining.divideSmall_udw0om_k$(chunk) === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var tmp0 = count;
      // Inline function 'kotlin.Long.plus' call
      var other = chunkPower;
      count = add(tmp0, fromInt(other));
      if (compare(count, new Long(2147483647, 0)) >= 0)
        throw ArithmeticException_init_$Create$('BigInteger overflow');
    }
    while (remaining.remainderSmall_tivewm_k$(factor) === 0) {
      // Inline function 'kotlin.check' call
      if (!(remaining.divideSmall_udw0om_k$(factor) === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var _unary__edvuaz = count;
      count = add(_unary__edvuaz, get_ONE());
      if (compare(count, new Long(2147483647, 0)) >= 0)
        throw ArithmeticException_init_$Create$('BigInteger overflow');
    }
    if (!remaining.isOne_1ntj30_k$())
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    var tmp0_0 = add(value.zeros_1, count);
    // Inline function 'kotlin.Long.minus' call
    var other_0 = value.scale_1;
    var tmp$ret$3 = subtract(tmp0_0, fromInt(other_0));
    var scale = checkedScale_1($this, tmp$ret$3);
    var coefficient = Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt(reciprocalBase)).pow_iykav4_k$(convertToInt(count));
    var natural = ensureNotNull(coefficient.decimalPowerState593_1qfbxp_k$(scale));
    return new State(value.sign_1, natural.core_1, natural.zeros_1, natural.scale_1);
  }
  function commit($this, sign, core, zeroTail, scale) {
    // Inline function 'kotlin.check' call
    if (!(core.size_1 > 0 && (sign === -1 || sign === 1))) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tail = core.trailingZeros_kq0ik1_k$();
    if (!equalsLong(tail, new Long(0, 0))) {
      core.dropDigits_3uq0vr_k$(tail);
    }
    return new State(sign, core, add(zeroTail, tail), checkedScale_1($this, scale));
  }
  function checkedScale_1($this, scale) {
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false))
      throw ArithmeticException_init_$Create$(compare(scale, new Long(0, 0)) < 0 ? 'Overflow' : 'Underflow');
    return convertToInt(scale);
  }
  function cellCount($this, count) {
    // Inline function 'kotlin.check' call
    if (!(compare(new Long(1, 0), count) <= 0 ? compare(count, new Long(477218593, 0)) <= 0 : false)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return convertToInt(count);
  }
  function increment_1($this, mode, sign, half, odd) {
    var tmp;
    switch (mode.get_ordinal_ip24qg_k$()) {
      case 0:
        tmp = true;
        break;
      case 1:
        tmp = false;
        break;
      case 2:
        tmp = sign > 0;
        break;
      case 3:
        tmp = sign < 0;
        break;
      case 4:
        tmp = half >= 0;
        break;
      case 5:
        tmp = half > 0;
        break;
      case 6:
        tmp = half > 0 || (half === 0 && odd);
        break;
      case 7:
        throw ArithmeticException_init_$Create$('Rounding necessary');
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function Pages(capacity) {
    this.capacity_1 = capacity;
    var tmp = this;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(this.capacity_1);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(8192));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = divide(this_2, fromInt(8192));
    // Inline function 'kotlin.arrayOfNulls' call
    var size = convertToInt(tmp$ret$2);
    tmp.pages_1 = Array(size);
  }
  protoOf(Pages).get_c1px32_k$ = function (index) {
    // Inline function 'kotlin.check' call
    if (!(0 <= index ? index < this.capacity_1 : false)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tmp0_safe_receiver = this.pages_1[index / 8192 | 0];
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver[index % 8192 | 0];
    return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  };
  protoOf(Pages).set_g707pu_k$ = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(0 <= index ? index < this.capacity_1 : false)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var slot = index / 8192 | 0;
    var tmp0_elvis_lhs = this.pages_1[slot];
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.run' call
      // Inline function 'kotlin.Long.times' call
      var this_0 = fromInt(slot);
      var start = multiply(this_0, fromInt(8192));
      var tmp0 = new Long(8192, 0);
      // Inline function 'kotlin.comparisons.minOf' call
      var b = subtract(fromInt(this.capacity_1), start);
      var tmp$ret$4 = compare(tmp0, b) <= 0 ? tmp0 : b;
      // Inline function 'kotlin.also' call
      var this_1 = new Int32Array(convertToInt(tmp$ret$4));
      this.pages_1[slot] = this_1;
      tmp = this_1;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var page = tmp;
    page[index % 8192 | 0] = value;
  };
  function Words(capacity) {
    Companion_getInstance_3();
    this.capacity_1 = capacity;
    this.cells_1 = new Pages(this.capacity_1);
    this.size_1 = 0;
  }
  protoOf(Words).get_size_woubt6_k$ = function () {
    return this.size_1;
  };
  protoOf(Words).get_c1px32_k$ = function (index) {
    return this.cells_1.get_c1px32_k$(index);
  };
  protoOf(Words).set_g707pu_k$ = function (index, value) {
    this.cells_1.set_g707pu_k$(index, value);
  };
  protoOf(Words).zeroSize_nzxzz5_k$ = function (length) {
    // Inline function 'kotlin.check' call
    if (!(this.size_1 === 0 && length <= this.capacity_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    this.size_1 = length;
  };
  protoOf(Words).append_dlf032_k$ = function (value) {
    var _unary__edvuaz = this.size_1;
    this.size_1 = _unary__edvuaz + 1 | 0;
    this.cells_1.set_g707pu_k$(_unary__edvuaz, value);
  };
  protoOf(Words).trim_7lhr2q_k$ = function () {
    while (this.size_1 > 0 && this.cells_1.get_c1px32_k$(this.size_1 - 1 | 0) === 0) {
      this.size_1 = this.size_1 - 1 | 0;
    }
  };
  protoOf(Words).isOne_1ntj30_k$ = function () {
    return this.size_1 === 1 && this.cells_1.get_c1px32_k$(0) === 1;
  };
  protoOf(Words).odd_2crz_k$ = function () {
    return !(this.size_1 === 0) && !((this.cells_1.get_c1px32_k$(0) % 2 | 0) === 0);
  };
  protoOf(Words).digits_m0zfve_k$ = function () {
    // Inline function 'kotlin.check' call
    if (!(this.size_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var width = 1;
    var top = this.cells_1.get_c1px32_k$(this.size_1 - 1 | 0);
    while (width < 9 && top >= DecimalPower593_getInstance().powers_1[width]) {
      width = width + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.size_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = width;
    return add(tmp0_0, fromInt(other_0));
  };
  protoOf(Words).copy_1tks5_k$ = function () {
    var tmp = DecimalPower593_getInstance();
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(this.size_1);
    var tmp$ret$0 = add(this_0, fromInt(1));
    var result = new Words(cellCount(tmp, tmp$ret$0));
    var inductionVariable = 0;
    var last = this.size_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        result.append_dlf032_k$(this.cells_1.get_c1px32_k$(i));
      }
       while (inductionVariable < last);
    return result;
  };
  protoOf(Words).trailingZeros_kq0ik1_k$ = function () {
    // Inline function 'kotlin.check' call
    if (!(this.size_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var whole = 0;
    while (this.cells_1.get_c1px32_k$(whole) === 0) {
      whole = whole + 1 | 0;
    }
    var low = this.cells_1.get_c1px32_k$(whole);
    var extra = 0;
    while ((low % 10 | 0) === 0) {
      low = low / 10 | 0;
      extra = extra + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = whole;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = extra;
    return add(tmp0_0, fromInt(other_0));
  };
  protoOf(Words).digit_5clizl_k$ = function (position) {
    // Inline function 'kotlin.check' call
    if (!(compare(position, new Long(0, 0)) >= 0 && compare(position, this.digits_m0zfve_k$()) < 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(position, fromInt(9));
    var tmp = this.cells_1.get_c1px32_k$(convertToInt(tmp$ret$1));
    var tmp_0 = DecimalPower593_getInstance().powers_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(position, fromInt(9));
    return (tmp / tmp_0[convertToInt(tmp$ret$2)] | 0) % 10 | 0;
  };
  protoOf(Words).anyBelow_yb9nh3_k$ = function (count) {
    // Inline function 'kotlin.check' call
    if (!(compare(count, new Long(0, 0)) >= 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(count, fromInt(9));
    var whole = convertToInt(tmp$ret$1);
    var inductionVariable = 0;
    if (inductionVariable < whole)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(this.cells_1.get_c1px32_k$(i) === 0))
          return true;
      }
       while (inductionVariable < whole);
    var tmp;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(count, fromInt(9));
    if (!equalsLong(tmp$ret$2, new Long(0, 0))) {
      var tmp_0 = this.cells_1.get_c1px32_k$(whole);
      var tmp_1 = DecimalPower593_getInstance().powers_1;
      // Inline function 'kotlin.Long.rem' call
      var tmp$ret$3 = modulo(count, fromInt(9));
      tmp = !((tmp_0 % tmp_1[convertToInt(tmp$ret$3)] | 0) === 0);
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(Words).dropDigits_3uq0vr_k$ = function (count) {
    // Inline function 'kotlin.check' call
    if (!(compare(count, new Long(0, 0)) >= 0 && compare(count, this.digits_m0zfve_k$()) < 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(count, fromInt(9));
    var whole = convertToInt(tmp$ret$1);
    var length = this.size_1 - whole | 0;
    var inductionVariable = 0;
    if (inductionVariable < length)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.cells_1.set_g707pu_k$(i, this.cells_1.get_c1px32_k$(i + whole | 0));
      }
       while (inductionVariable < length);
    this.size_1 = length;
    var tmp = DecimalPower593_getInstance().powers_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(count, fromInt(9));
    var divisor = tmp[convertToInt(tmp$ret$2)];
    if (!(divisor === 1))
      this.divideSmall_udw0om_k$(divisor);
    else {
      this.trim_7lhr2q_k$();
    }
  };
  protoOf(Words).divideSmall_udw0om_k$ = function (divisor) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(1 <= divisor ? divisor < 1000000000 : false)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var remainder = new Long(0, 0);
    var inductionVariable = this.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.cells_1.get_c1px32_k$(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$5 = divide(part, fromInt(divisor));
        this.cells_1.set_g707pu_k$(i, convertToInt(tmp$ret$5));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(divisor));
      }
       while (0 <= inductionVariable);
    this.trim_7lhr2q_k$();
    return convertToInt(remainder);
  };
  protoOf(Words).remainderSmall_tivewm_k$ = function (divisor) {
    var remainder = new Long(0, 0);
    var inductionVariable = this.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.cells_1.get_c1px32_k$(i);
        // Inline function 'kotlin.Long.rem' call
        var this_0 = add(tmp0_0, fromInt(other_0));
        remainder = modulo(this_0, fromInt(divisor));
      }
       while (0 <= inductionVariable);
    return convertToInt(remainder);
  };
  protoOf(Words).multiplyAdd_d61a5v_k$ = function (multiplier, addition) {
    var carry = fromInt(addition);
    var inductionVariable = 0;
    var last = this.size_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(this.cells_1.get_c1px32_k$(i));
        var tmp$ret$0 = multiply(this_0, fromInt(multiplier));
        var part = add(tmp$ret$0, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$1 = modulo(part, fromInt(other));
        this.cells_1.set_g707pu_k$(i, convertToInt(tmp$ret$1));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < last);
    if (!equalsLong(carry, new Long(0, 0))) {
      this.append_dlf032_k$(convertToInt(carry));
    }
  };
  protoOf(Words).productSmall_izrm9d_k$ = function (source, multiplier) {
    this.size_1 = 0;
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = source.size_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(source.get_c1px32_k$(i));
        var tmp$ret$0 = multiply(this_0, fromInt(multiplier));
        var part = add(tmp$ret$0, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$1 = modulo(part, fromInt(other));
        this.append_dlf032_k$(convertToInt(tmp$ret$1));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < last);
    if (!equalsLong(carry, new Long(0, 0))) {
      this.append_dlf032_k$(convertToInt(carry));
    }
    this.trim_7lhr2q_k$();
  };
  protoOf(Words).compare_6r9rd6_k$ = function (other) {
    if (!(this.size_1 === other.size_1))
      return compareTo(this.size_1, other.size_1);
    var inductionVariable = this.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        if (!(this.cells_1.get_c1px32_k$(i) === other.get_c1px32_k$(i)))
          return compareTo(this.cells_1.get_c1px32_k$(i), other.get_c1px32_k$(i));
      }
       while (0 <= inductionVariable);
    return 0;
  };
  protoOf(Words).subtract_f3u9jp_k$ = function (other) {
    var borrow = new Long(0, 0);
    var inductionVariable = 0;
    var last = this.size_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = fromInt(this.cells_1.get_c1px32_k$(i));
        // Inline function 'kotlin.Long.minus' call
        var other_0 = i < other.size_1 ? other.get_c1px32_k$(i) : 0;
        var tmp$ret$0 = subtract(tmp0, fromInt(other_0));
        var part = subtract(tmp$ret$0, borrow);
        if (compare(part, new Long(0, 0)) < 0) {
          var tmp0_0 = part;
          // Inline function 'kotlin.Long.plus' call
          var other_1 = 1000000000;
          part = add(tmp0_0, fromInt(other_1));
          borrow = new Long(1, 0);
        } else
          borrow = new Long(0, 0);
        this.cells_1.set_g707pu_k$(i, convertToInt(part));
      }
       while (inductionVariable < last);
    // Inline function 'kotlin.check' call
    if (!equalsLong(borrow, new Long(0, 0))) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    this.trim_7lhr2q_k$();
  };
  protoOf(Words).increment_vga7q7_k$ = function () {
    var i = 0;
    while (i < this.size_1 && this.cells_1.get_c1px32_k$(i) === 999999999) {
      this.cells_1.set_g707pu_k$(i, 0);
      i = i + 1 | 0;
    }
    if (i === this.size_1) {
      this.append_dlf032_k$(1);
    } else {
      this.cells_1.set_g707pu_k$(i, this.cells_1.get_c1px32_k$(i) + 1 | 0);
    }
  };
  protoOf(Words).powerOfTen_z5xabn_k$ = function (exponent) {
    // Inline function 'kotlin.check' call
    if (!(this.size_1 === 0 && compare(exponent, new Long(0, 0)) >= 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(exponent, fromInt(9));
    var at = convertToInt(tmp$ret$1);
    var tmp = DecimalPower593_getInstance().powers_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(exponent, fromInt(9));
    this.cells_1.set_g707pu_k$(at, tmp[convertToInt(tmp$ret$2)]);
    this.size_1 = at + 1 | 0;
  };
  function reciprocal$nextDigit(remainder, trial, denominator) {
    remainder.multiplyAdd_d61a5v_k$(10, 0);
    var digit = 9;
    $l$loop: while (digit > 0) {
      trial.productSmall_izrm9d_k$(denominator, digit);
      if (remainder.compare_6r9rd6_k$(trial) >= 0)
        break $l$loop;
      digit = digit - 1 | 0;
    }
    if (!(digit === 0)) {
      remainder.subtract_f3u9jp_k$(trial);
    }
    return digit;
  }
  function DecimalPower593() {
    DecimalPower593_instance = this;
    this.BASE_1 = 1000000000;
    this.PAGE_1 = 8192;
    this.MAX_DIGITS_1 = new Long(646456993, 0);
    this.MAX_WORK_1 = new Long(-2147483639, 0);
    this.MAX_CELLS_1 = new Long(477218593, 0);
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.powers_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalPower593).fromMagnitude_1i7lcv_k$ = function (sign, words, scale) {
    var tmp;
    var tmp_0;
    switch (sign) {
      case -1:
      case 1:
        // Inline function 'kotlin.collections.isNotEmpty' call

        // Inline function 'kotlin.collections.isEmpty' call

        tmp_0 = !(words.length === 0);
        break;
      default:
        tmp_0 = false;
        break;
    }
    if (tmp_0) {
      tmp = last(words) > 0;
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var scratch = words.slice();
    var size = scratch.length;
    var tmp0 = new Long(646456993, 0);
    var tmp0_0 = new Long(10, 0);
    // Inline function 'kotlin.Long.times' call
    var other = size;
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(tmp0_0, fromInt(other));
    var bound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bound, fromInt(8));
    var tmp$ret$10 = divide(this_0, fromInt(9));
    var decimal = new Words(cellCount(this, tmp$ret$10));
    while (!(size === 0)) {
      var remainder = new Long(0, 0);
      var inductionVariable = size - 1 | 0;
      if (0 <= inductionVariable)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + -1 | 0;
          var tmp0_1 = shiftLeft(remainder, 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = scratch[i];
          var part = add(tmp0_1, fromInt(other_0));
          // Inline function 'kotlin.Long.div' call
          var other_1 = 1000000000;
          var tmp$ret$12 = divide(part, fromInt(other_1));
          scratch[i] = convertToInt(tmp$ret$12);
          // Inline function 'kotlin.Long.rem' call
          var other_2 = 1000000000;
          remainder = modulo(part, fromInt(other_2));
        }
         while (0 <= inductionVariable);
      decimal.append_dlf032_k$(convertToInt(remainder));
      while (!(size === 0) && scratch[size - 1 | 0] === 0) {
        size = size - 1 | 0;
      }
    }
    return commit(this, sign, decimal, new Long(0, 0), fromInt(scale));
  };
  protoOf(DecimalPower593).accumulate_1uip69_k$ = function (base, exponent, precision, mode) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!((1 <= exponent ? exponent <= 999999999 : false) && (compare(new Long(1, 0), precision) <= 0 ? compare(precision, new Long(-2147483639, 0)) <= 0 : false))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var result = commit(this, 1, Companion_getInstance_3().one_2d0m_k$(), new Long(0, 0), new Long(0, 0));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var bits = 32 - clz32(exponent) | 0;
    var inductionVariable = bits - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var bit = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        result = multiply_1(this, result, result, precision, mode);
        if (!((exponent & 1 << bit) === 0))
          result = multiply_1(this, result, base, precision, mode);
      }
       while (0 <= inductionVariable);
    return result;
  };
  protoOf(DecimalPower593).round_398x3r_k$ = function (value, precision, mode) {
    return roundOwned(this, value.sign_1, value.core_1.copy_1tks5_k$(), value.zeros_1, fromInt(value.scale_1), precision, mode);
  };
  protoOf(DecimalPower593).reciprocal_ygvxg5_k$ = function (value, precision, destinationPrecision, mode) {
    var tmp;
    if (destinationPrecision > 0 && compare(precision, new Long(-2147483639, 0)) <= 0) {
      var containsArg = subtract(precision, fromInt(destinationPrecision));
      tmp = compare(new Long(2, 0), containsArg) <= 0 ? compare(containsArg, new Long(10, 0)) <= 0 : false;
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (value.core_1.isOne_1ntj30_k$()) {
      var tmp_0 = Companion_getInstance_3().one_2d0m_k$();
      var tmp_1 = new Long(0, 0);
      var tmp0 = value.zeros_1;
      // Inline function 'kotlin.Long.minus' call
      var other = value.scale_1;
      var tmp$ret$3 = subtract(tmp0, fromInt(other));
      return commit(this, value.sign_1, tmp_0, tmp_1, tmp$ret$3);
    }
    if (compare(fromInt(destinationPrecision), new Long(646456993, 0)) > 0)
      return exactReciprocal(this, value);
    var denominator = value.core_1;
    var digits = denominator.digits_m0zfve_k$();
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(denominator.size_1);
    var tmp$ret$4 = add(this_0, fromInt(1));
    var remainder = new Words(cellCount(this, tmp$ret$4));
    // Inline function 'kotlin.Long.minus' call
    var tmp$ret$5 = subtract(digits, fromInt(1));
    remainder.powerOfTen_z5xabn_k$(tmp$ret$5);
    // Inline function 'kotlin.Long.plus' call
    var this_1 = fromInt(denominator.size_1);
    var tmp$ret$6 = add(this_1, fromInt(1));
    var trial = new Words(cellCount(this, tmp$ret$6));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.plus' call
    var this_2 = add(precision, fromInt(1));
    // Inline function 'kotlin.Long.div' call
    var this_3 = add(this_2, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_4 = divide(this_3, fromInt(9));
    var tmp$ret$10 = add(this_4, fromInt(1));
    var quotient = new Words(cellCount(this, tmp$ret$10));
    var kept = new Long(0, 0);
    while (compare(kept, precision) < 0) {
      quotient.multiplyAdd_d61a5v_k$(10, reciprocal$nextDigit(remainder, trial, denominator));
      var _unary__edvuaz = kept;
      kept = add(_unary__edvuaz, get_ONE());
      if (remainder.size_1 === 0) {
        // Inline function 'kotlin.Long.minus' call
        var this_5 = add(negate(fromInt(value.scale_1)), kept);
        var tmp$ret$11 = subtract(this_5, fromInt(1));
        var scale = add(add(tmp$ret$11, digits), value.zeros_1);
        return commit(this, value.sign_1, quotient, new Long(0, 0), scale);
      }
    }
    var guard = reciprocal$nextDigit(remainder, trial, denominator);
    var sticky = !(remainder.size_1 === 0);
    var half = guard === 5 && sticky ? 1 : compareTo(guard, 5);
    if ((!(guard === 0) || sticky) && increment_1(this, mode, value.sign_1, half, quotient.odd_2crz_k$())) {
      quotient.increment_vga7q7_k$();
    }
    // Inline function 'kotlin.Long.minus' call
    var this_6 = add(negate(fromInt(value.scale_1)), precision);
    var tmp$ret$12 = subtract(this_6, fromInt(1));
    var scale_0 = add(add(tmp$ret$12, digits), value.zeros_1);
    if (compare(quotient.digits_m0zfve_k$(), precision) > 0) {
      // Inline function 'kotlin.check' call
      if (!(quotient.divideSmall_udw0om_k$(10) === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var _unary__edvuaz_0 = scale_0;
      scale_0 = subtract(_unary__edvuaz_0, get_ONE());
    }
    return commit(this, value.sign_1, quotient, new Long(0, 0), scale_0);
  };
  protoOf(DecimalPower593).publish_qh0kjc_k$ = function (value) {
    var digits = value.digits_m0zfve_k$();
    if (compare(digits, new Long(646456993, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    // Inline function 'kotlin.Long.div' call
    var this_0 = value.zeros_1;
    var whole = divide(this_0, fromInt(9));
    // Inline function 'kotlin.Long.rem' call
    var this_1 = value.zeros_1;
    var tmp$ret$1 = modulo(this_1, fromInt(9));
    var offset = convertToInt(tmp$ret$1);
    var tmp;
    if (offset === 0) {
      tmp = value.core_1;
    } else {
      // Inline function 'kotlin.also' call
      var this_2 = value.core_1.copy_1tks5_k$();
      this_2.multiplyAdd_d61a5v_k$(DecimalPower593_getInstance().powers_1[offset], 0);
      tmp = this_2;
    }
    var decimal = tmp;
    var cells = add(fromInt(decimal.size_1), whole);
    var tmp0 = new Long(2147483647, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(new Long(4, 0), digits);
    var bitBound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_3 = add(bitBound, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_4 = divide(this_3, fromInt(30));
    var tmp$ret$7 = add(this_4, fromInt(1));
    var binary = new Pages(cellCount(this, tmp$ret$7));
    var size = 0;
    var at = cells;
    while (!equalsLong(at, new Long(0, 0))) {
      var _unary__edvuaz = at;
      at = subtract(_unary__edvuaz, get_ONE());
      var carry = compare(at, whole) < 0 ? new Long(0, 0) : fromInt(decimal.get_c1px32_k$(convertToInt(subtract(at, whole))));
      var inductionVariable = 0;
      var last = size;
      if (inductionVariable < last)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var tmp0_0 = fromInt(binary.get_c1px32_k$(i));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$8 = multiply(tmp0_0, fromInt(other));
          var part = add(tmp$ret$8, carry);
          binary.set_g707pu_k$(i, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
        }
         while (inductionVariable < last);
      if (!equalsLong(carry, new Long(0, 0))) {
        var _unary__edvuaz_0 = size;
        size = _unary__edvuaz_0 + 1 | 0;
        binary.set_g707pu_k$(_unary__edvuaz_0, convertToInt(carry));
      }
      var tmp0_1 = new Long(30, 0);
      // Inline function 'kotlin.Long.times' call
      var other_0 = size - 1 | 0;
      // Inline function 'kotlin.Long.plus' call
      var this_5 = multiply(tmp0_1, fromInt(other_0));
      var tmp0_2 = add(this_5, fromInt(32));
      // Inline function 'kotlin.countLeadingZeroBits' call
      var this_6 = binary.get_c1px32_k$(size - 1 | 0);
      // Inline function 'kotlin.Long.minus' call
      var other_1 = clz32(this_6);
      var bits = subtract(tmp0_2, fromInt(other_1));
      if (compare(bits, new Long(2147483647, 0)) > 0)
        throw ArithmeticException_init_$Create$('BigInteger overflow');
    }
    var tmp0_3 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_7 = multiply(tmp0_3, fromInt(other_2));
    var tmp0_4 = add(this_7, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_8 = binary.get_c1px32_k$(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_8);
    var bits_0 = subtract(tmp0_4, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_9 = add(bits_0, fromInt(7));
    var tmp$ret$18 = divide(this_9, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$18));
    var inductionVariable_0 = 0;
    var last_0 = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last_0)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_10 = new Long(8, 0);
        var bit = multiply(this_10, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$20 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$20);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$21 = modulo(bit, fromInt(30));
        var shift = convertToInt(tmp$ret$21);
        var part_0 = shiftRightUnsigned(fromInt(binary.get_c1px32_k$(word)), shift);
        if (shift > 22 && (word + 1 | 0) < size)
          part_0 = bitwiseOr(part_0, shiftLeft(fromInt(binary.get_c1px32_k$(word + 1 | 0)), 30 - shift | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(part_0, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last_0);
    return to(BigInteger_init_$Create$_4(value.sign_1, bytes), value.scale_1);
  };
  var DecimalPower593_instance;
  function DecimalPower593_getInstance() {
    if (DecimalPower593_instance == null)
      new DecimalPower593();
    return DecimalPower593_instance;
  }
  function _get_limit__eq4zuy($this) {
    return $this.limit_1;
  }
  function _get_pages__cygrxv_1($this) {
    return $this.pages_1;
  }
  function _get_cells__j1rckg_1($this) {
    return $this.cells_1;
  }
  function _set_size__9twho6_1($this, _set____db54di) {
    $this.size_1 = _set____db54di;
  }
  function _get_BASE__cm0716_1($this) {
    return $this.BASE_1;
  }
  function _get_PAGE__ctp2fw_1($this) {
    return $this.PAGE_1;
  }
  function _get_powers__vdnpa5_1($this) {
    return $this.powers_1;
  }
  function increment_2($this, mode, sign, half, odd) {
    var tmp;
    switch (mode.get_ordinal_ip24qg_k$()) {
      case 0:
        tmp = true;
        break;
      case 1:
        tmp = false;
        break;
      case 2:
        tmp = sign > 0;
        break;
      case 3:
        tmp = sign < 0;
        break;
      case 4:
        tmp = half >= 0;
        break;
      case 5:
        tmp = half > 0;
        break;
      case 6:
        tmp = half > 0 || (half === 0 && odd);
        break;
      case 7:
        throw ArithmeticException_init_$Create$('Rounding necessary');
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function checkedScale_2($this, scale) {
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false))
      throw ArithmeticException_init_$Create$(compare(scale, new Long(0, 0)) < 0 ? 'Overflow' : 'Underflow');
    return convertToInt(scale);
  }
  function decimalChunks_0($this, words, scratch) {
    var inductionVariable = 0;
    var last = words.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        scratch.set_g707pu_k$(i, words[i]);
      }
       while (inductionVariable <= last);
    var size = words.length;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = new Long(646456993, 0);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(8));
    var tmp$ret$1 = divide(this_1, fromInt(9));
    var chunks = new DecimalWords_0(convertToInt(tmp$ret$1));
    while (!(size === 0)) {
      var remainder = new Long(0, 0);
      var inductionVariable_0 = size - 1 | 0;
      if (0 <= inductionVariable_0)
        do {
          var i_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + -1 | 0;
          var tmp0 = shiftLeft(remainder, 30);
          // Inline function 'kotlin.Long.plus' call
          var other = scratch.get_c1px32_k$(i_0);
          var part = add(tmp0, fromInt(other));
          // Inline function 'kotlin.Long.div' call
          var other_0 = 1000000000;
          var tmp$ret$3 = divide(part, fromInt(other_0));
          scratch.set_g707pu_k$(i_0, convertToInt(tmp$ret$3));
          // Inline function 'kotlin.Long.rem' call
          var other_1 = 1000000000;
          remainder = modulo(part, fromInt(other_1));
        }
         while (0 <= inductionVariable_0);
      chunks.append_dlf032_k$(convertToInt(remainder));
      while (size > 0 && scratch.get_c1px32_k$(size - 1 | 0) === 0) {
        size = size - 1 | 0;
      }
    }
    // Inline function 'kotlin.check' call
    if (!(chunks.size_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return chunks;
  }
  function binaryCoefficient($this, decimal, sign) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = new Long(2147483647, 0);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(30));
    var tmp$ret$2 = add(this_2, fromInt(1));
    var binary = new Cells_0(convertToInt(tmp$ret$2));
    var size = 0;
    var inductionVariable = decimal.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var carry = fromInt(decimal.get_c1px32_k$(i));
        var j = 0;
        while (j < size) {
          var tmp0 = fromInt(binary.get_c1px32_k$(j));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$3 = multiply(tmp0, fromInt(other));
          var part = add(tmp$ret$3, carry);
          binary.set_g707pu_k$(j, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
          j = j + 1 | 0;
        }
        if (!equalsLong(carry, new Long(0, 0))) {
          var _unary__edvuaz = size;
          size = _unary__edvuaz + 1 | 0;
          binary.set_g707pu_k$(_unary__edvuaz, convertToInt(carry));
        }
        var tmp0_0 = new Long(30, 0);
        // Inline function 'kotlin.Long.times' call
        var other_0 = size - 1 | 0;
        // Inline function 'kotlin.Long.plus' call
        var this_3 = multiply(tmp0_0, fromInt(other_0));
        var tmp0_1 = add(this_3, fromInt(32));
        // Inline function 'kotlin.countLeadingZeroBits' call
        var this_4 = binary.get_c1px32_k$(size - 1 | 0);
        // Inline function 'kotlin.Long.minus' call
        var other_1 = clz32(this_4);
        var bits = subtract(tmp0_1, fromInt(other_1));
        if (compare(bits, new Long(2147483647, 0)) > 0)
          throw ArithmeticException_init_$Create$('BigInteger overflow');
      }
       while (0 <= inductionVariable);
    var tmp0_2 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_5 = multiply(tmp0_2, fromInt(other_2));
    var tmp0_3 = add(this_5, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_6 = binary.get_c1px32_k$(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_6);
    var bits_0 = subtract(tmp0_3, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_7 = add(bits_0, fromInt(7));
    var tmp$ret$13 = divide(this_7, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$13));
    var inductionVariable_0 = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_8 = new Long(8, 0);
        var bit = multiply(this_8, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$15 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$15);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$16 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$16);
        var value = shiftRightUnsigned(fromInt(binary.get_c1px32_k$(word)), offset);
        if (offset > 22 && (word + 1 | 0) < size)
          value = bitwiseOr(value, shiftLeft(fromInt(binary.get_c1px32_k$(word + 1 | 0)), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last);
    return BigInteger_init_$Create$_4(sign, bytes);
  }
  function Cells_0(limit) {
    this.limit_1 = limit;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.pages_1 = ArrayList_init_$Create$();
  }
  protoOf(Cells_0).get_c1px32_k$ = function (index) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.limit_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var page = index / 8192 | 0;
    return page < this.pages_1.get_size_woubt6_k$() ? this.pages_1.get_c1px32_k$(page)[index % 8192 | 0] : 0;
  };
  protoOf(Cells_0).set_g707pu_k$ = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.limit_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var page = index / 8192 | 0;
    while (this.pages_1.get_size_woubt6_k$() <= page) {
      this.pages_1.add_utx5q5_k$(new Int32Array(8192));
    }
    this.pages_1.get_c1px32_k$(page)[index % 8192 | 0] = value;
  };
  function DecimalWords_0(capacity) {
    this.cells_1 = new Cells_0(capacity);
    this.size_1 = 0;
  }
  protoOf(DecimalWords_0).get_size_woubt6_k$ = function () {
    return this.size_1;
  };
  protoOf(DecimalWords_0).get_c1px32_k$ = function (index) {
    return this.cells_1.get_c1px32_k$(index);
  };
  protoOf(DecimalWords_0).set_g707pu_k$ = function (index, value) {
    this.cells_1.set_g707pu_k$(index, value);
  };
  protoOf(DecimalWords_0).zeroSize_nzxzz5_k$ = function (length) {
    // Inline function 'kotlin.check' call
    if (!(this.size_1 === 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    this.size_1 = length;
  };
  protoOf(DecimalWords_0).append_dlf032_k$ = function (value) {
    this.cells_1.set_g707pu_k$(this.size_1, value);
    this.size_1 = this.size_1 + 1 | 0;
  };
  protoOf(DecimalWords_0).trim_7lhr2q_k$ = function () {
    while (this.size_1 > 0 && this.cells_1.get_c1px32_k$(this.size_1 - 1 | 0) === 0) {
      this.size_1 = this.size_1 - 1 | 0;
    }
  };
  protoOf(DecimalWords_0).digits_m0zfve_k$ = function () {
    // Inline function 'kotlin.check' call
    if (!(this.size_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var topDigits = 1;
    var top = this.cells_1.get_c1px32_k$(this.size_1 - 1 | 0);
    while (topDigits < 9 && top >= DecimalProduct580_getInstance().powers_1[topDigits]) {
      topDigits = topDigits + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.size_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = topDigits;
    var tmp$ret$2 = add(tmp0_0, fromInt(other_0));
    return convertToInt(tmp$ret$2);
  };
  protoOf(DecimalWords_0).dropDigits_hdpg3x_k$ = function (count) {
    var whole = count / 9 | 0;
    var length = this.size_1 - whole | 0;
    var inductionVariable = 0;
    if (inductionVariable < length)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.cells_1.set_g707pu_k$(i, this.cells_1.get_c1px32_k$(i + whole | 0));
      }
       while (inductionVariable < length);
    this.size_1 = length;
    this.divideSmall_udw0om_k$(DecimalProduct580_getInstance().powers_1[count % 9 | 0]);
    this.trim_7lhr2q_k$();
  };
  protoOf(DecimalWords_0).divideSmall_udw0om_k$ = function (divisor) {
    var remainder = new Long(0, 0);
    var inductionVariable = this.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.cells_1.get_c1px32_k$(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(divisor));
        this.cells_1.set_g707pu_k$(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(divisor));
      }
       while (0 <= inductionVariable);
    this.trim_7lhr2q_k$();
    return convertToInt(remainder);
  };
  protoOf(DecimalWords_0).increment_vga7q7_k$ = function () {
    var i = 0;
    while (i < this.size_1 && this.cells_1.get_c1px32_k$(i) === 999999999) {
      this.cells_1.set_g707pu_k$(i, 0);
      i = i + 1 | 0;
    }
    if (i === this.size_1) {
      this.append_dlf032_k$(1);
    } else {
      this.cells_1.set_g707pu_k$(i, this.cells_1.get_c1px32_k$(i) + 1 | 0);
    }
  };
  function DecimalProduct580() {
    DecimalProduct580_instance = this;
    this.BASE_1 = 1000000000;
    this.PAGE_1 = 8192;
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.powers_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalProduct580).rounded_ir9ghy_k$ = function (sign, left, right, scale, context) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(sign === -1 || sign === 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(left.length === 0)) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      // Inline function 'kotlin.collections.isEmpty' call
      tmp = !(right.length === 0);
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    var precision = context.get_precision_e8tfsb_k$();
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(precision > 0)) {
      var message_1 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_1));
    }
    if (compare(scale, new Long(-2147483648, -1)) < 0) {
      checkedScale_2(this, scale);
    }
    var tmp0 = left.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = right.length;
    var tmp$ret$13 = Math.max(tmp0, b);
    var scratch = new Cells_0(tmp$ret$13);
    var a = decimalChunks_0(this, left, scratch);
    var b_0 = decimalChunks_0(this, right, scratch);
    var tmp0_0 = fromInt(a.size_1);
    // Inline function 'kotlin.Long.plus' call
    var other = b_0.size_1;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = add(tmp0_0, fromInt(other));
    var tmp$ret$15 = add(this_0, fromInt(1));
    var capacity = convertToInt(tmp$ret$15);
    var product = new DecimalWords_0(capacity);
    product.zeroSize_nzxzz5_k$(capacity - 1 | 0);
    var inductionVariable = 0;
    var last = a.size_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        var last_0 = b_0.size_1;
        if (inductionVariable_0 < last_0)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var at = i + j | 0;
            var tmp0_1 = fromInt(a.get_c1px32_k$(i));
            // Inline function 'kotlin.Long.times' call
            var other_0 = b_0.get_c1px32_k$(j);
            var tmp0_2 = multiply(tmp0_1, fromInt(other_0));
            // Inline function 'kotlin.Long.plus' call
            var other_1 = product.get_c1px32_k$(at);
            var tmp$ret$17 = add(tmp0_2, fromInt(other_1));
            var part = add(tmp$ret$17, carry);
            // Inline function 'kotlin.Long.rem' call
            var other_2 = 1000000000;
            var tmp$ret$18 = modulo(part, fromInt(other_2));
            product.set_g707pu_k$(at, convertToInt(tmp$ret$18));
            // Inline function 'kotlin.Long.div' call
            var other_3 = 1000000000;
            carry = divide(part, fromInt(other_3));
          }
           while (inductionVariable_0 < last_0);
        product.set_g707pu_k$(i + b_0.size_1 | 0, convertToInt(carry));
      }
       while (inductionVariable < last);
    product.trim_7lhr2q_k$();
    var digits = product.digits_m0zfve_k$();
    if (compare(scale, new Long(2147483647, 0)) > 0 && digits <= precision) {
      checkedScale_2(this, scale);
    }
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(digits);
    var tmp0_3 = subtract(this_1, fromInt(precision));
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_1 = new Long(0, 0);
    var drop = compare(tmp0_3, b_1) >= 0 ? tmp0_3 : b_1;
    if (!equalsLong(drop, new Long(0, 0))) {
      // Inline function 'kotlin.Long.minus' call
      var this_2 = drop;
      var guardPosition = subtract(this_2, fromInt(1));
      // Inline function 'kotlin.Long.div' call
      var tmp$ret$23 = divide(guardPosition, fromInt(9));
      var guardCell = convertToInt(tmp$ret$23);
      // Inline function 'kotlin.Long.rem' call
      var tmp$ret$24 = modulo(guardPosition, fromInt(9));
      var offset = convertToInt(tmp$ret$24);
      var guard = (product.get_c1px32_k$(guardCell) / this.powers_1[offset] | 0) % 10 | 0;
      var sticky = !((product.get_c1px32_k$(guardCell) % this.powers_1[offset] | 0) === 0);
      var i_0 = 0;
      while (!sticky && i_0 < guardCell) {
        sticky = !(product.get_c1px32_k$(i_0) === 0);
        i_0 = i_0 + 1 | 0;
      }
      var inexact = !(guard === 0) || sticky;
      var tmp_0;
      if (guard === 5) {
        tmp_0 = sticky ? 1 : 0;
      } else {
        tmp_0 = compareTo(guard, 5);
      }
      var half = tmp_0;
      product.dropDigits_hdpg3x_k$(convertToInt(drop));
      if (inexact && increment_2(this, context.get_roundingMode_uxzxk0_k$(), sign, half, !((product.get_c1px32_k$(0) % 2 | 0) === 0))) {
        product.increment_vga7q7_k$();
        if (product.digits_m0zfve_k$() > precision) {
          // Inline function 'kotlin.check' call
          if (!(product.divideSmall_udw0om_k$(10) === 0)) {
            throw IllegalStateException_init_$Create$('Check failed.');
          }
          var _unary__edvuaz = drop;
          drop = add(_unary__edvuaz, get_ONE());
        }
      }
    }
    var finalScale = checkedScale_2(this, subtract(scale, drop));
    return to(binaryCoefficient(this, product, sign), finalScale);
  };
  var DecimalProduct580_instance;
  function DecimalProduct580_getInstance() {
    if (DecimalProduct580_instance == null)
      new DecimalProduct580();
    return DecimalProduct580_instance;
  }
  function needsRawDecimalProduct580(leftBits, rightBits) {
    var tmp;
    if (leftBits > 0 && rightBits > 0) {
      // Inline function 'kotlin.Long.plus' call
      var this_0 = fromInt(leftBits);
      var tmp$ret$0 = add(this_0, fromInt(rightBits));
      tmp = compare(tmp$ret$0, new Long(2147483647, 0)) > 0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  function _get_limit__eq4zuy_0($this) {
    return $this.limit_1;
  }
  function _get_pages__cygrxv_2($this) {
    return $this.pages_1;
  }
  function _get_cells__j1rckg_2($this) {
    return $this.cells_1;
  }
  function _set_size__9twho6_2($this, _set____db54di) {
    $this.size_1 = _set____db54di;
  }
  function trim_0($this) {
    while ($this.size_1 > 0 && $this.cells_1.get_c1px32_k$($this.size_1 - 1 | 0) === 0) {
      $this.size_1 = $this.size_1 - 1 | 0;
    }
  }
  function _get_BASE__cm0716_2($this) {
    return $this.BASE_1;
  }
  function _get_PAGE__ctp2fw_2($this) {
    return $this.PAGE_1;
  }
  function _get_powers__vdnpa5_2($this) {
    return $this.powers_1;
  }
  function decimalChunks_1($this, coefficient) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = new Long(646456993, 0);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(8));
    var tmp$ret$1 = divide(this_1, fromInt(9));
    var chunks = new DecimalWords_1(convertToInt(tmp$ret$1));
    var divisor = Companion_getInstance_2().valueOf_wwtjy2_k$(new Long(1000000000, 0));
    var value = coefficient;
    while (!(value.signum_exb08b_k$() === 0)) {
      var qr = value.divideAndRemainder_2r68pv_k$(divisor);
      chunks.append_dlf032_k$(qr[1].toInt_1tsl84_k$());
      value = qr[0];
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!!(chunks.size_1 === 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    return chunks;
  }
  function binaryCoefficient_0($this, decimal) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = new Long(2147483647, 0);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(30));
    var tmp$ret$2 = add(this_2, fromInt(1));
    var binary = new Cells_1(convertToInt(tmp$ret$2));
    var size = 0;
    var inductionVariable = decimal.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var carry = fromInt(decimal.get_c1px32_k$(i));
        var j = 0;
        while (j < size) {
          var tmp0 = fromInt(binary.get_c1px32_k$(j));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$3 = multiply(tmp0, fromInt(other));
          var part = add(tmp$ret$3, carry);
          binary.set_g707pu_k$(j, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
          j = j + 1 | 0;
        }
        if (!equalsLong(carry, new Long(0, 0))) {
          var _unary__edvuaz = size;
          size = _unary__edvuaz + 1 | 0;
          binary.set_g707pu_k$(_unary__edvuaz, convertToInt(carry));
        }
        if (!(size === 0)) {
          var tmp0_0 = new Long(30, 0);
          // Inline function 'kotlin.Long.times' call
          var other_0 = size - 1 | 0;
          // Inline function 'kotlin.Long.plus' call
          var this_3 = multiply(tmp0_0, fromInt(other_0));
          var tmp0_1 = add(this_3, fromInt(32));
          // Inline function 'kotlin.countLeadingZeroBits' call
          var this_4 = binary.get_c1px32_k$(size - 1 | 0);
          // Inline function 'kotlin.Long.minus' call
          var other_1 = clz32(this_4);
          var bits = subtract(tmp0_1, fromInt(other_1));
          if (compare(bits, new Long(2147483647, 0)) > 0)
            throw ArithmeticException_init_$Create$('BigInteger overflow');
        }
      }
       while (0 <= inductionVariable);
    // Inline function 'kotlin.check' call
    if (!!(size === 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tmp0_2 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_5 = multiply(tmp0_2, fromInt(other_2));
    var tmp0_3 = add(this_5, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_6 = binary.get_c1px32_k$(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_6);
    var bits_0 = subtract(tmp0_3, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_7 = add(bits_0, fromInt(7));
    var tmp$ret$14 = divide(this_7, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$14));
    var inductionVariable_0 = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_8 = new Long(8, 0);
        var bit = multiply(this_8, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$16 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$16);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$17 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$17);
        var value = shiftRightUnsigned(fromInt(binary.get_c1px32_k$(word)), offset);
        if (offset > 22 && (word + 1 | 0) < size)
          value = bitwiseOr(value, shiftLeft(fromInt(binary.get_c1px32_k$(word + 1 | 0)), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last);
    return BigInteger_init_$Create$_4(1, bytes);
  }
  function Cells_1(limit) {
    this.limit_1 = limit;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.pages_1 = ArrayList_init_$Create$();
  }
  protoOf(Cells_1).get_c1px32_k$ = function (index) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.limit_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return this.pages_1.get_c1px32_k$(index / 8192 | 0)[index % 8192 | 0];
  };
  protoOf(Cells_1).set_g707pu_k$ = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.limit_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var page = index / 8192 | 0;
    while (this.pages_1.get_size_woubt6_k$() <= page) {
      this.pages_1.add_utx5q5_k$(new Int32Array(8192));
    }
    this.pages_1.get_c1px32_k$(page)[index % 8192 | 0] = value;
  };
  function DecimalWords_1(capacity) {
    this.cells_1 = new Cells_1(capacity);
    this.size_1 = 0;
  }
  protoOf(DecimalWords_1).get_size_woubt6_k$ = function () {
    return this.size_1;
  };
  protoOf(DecimalWords_1).get_c1px32_k$ = function (index) {
    return this.cells_1.get_c1px32_k$(index);
  };
  protoOf(DecimalWords_1).append_dlf032_k$ = function (value) {
    this.cells_1.set_g707pu_k$(this.size_1, value);
    this.size_1 = this.size_1 + 1 | 0;
  };
  protoOf(DecimalWords_1).assign_3dx9l3_k$ = function (other) {
    var inductionVariable = 0;
    var last = other.size_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.cells_1.set_g707pu_k$(i, other.get_c1px32_k$(i));
      }
       while (inductionVariable < last);
    this.size_1 = other.size_1;
  };
  protoOf(DecimalWords_1).multiplyAdd_d61a5v_k$ = function (multiplier, addition) {
    var carry = fromInt(addition);
    var inductionVariable = 0;
    var last = this.size_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(this.cells_1.get_c1px32_k$(i));
        var tmp$ret$0 = multiply(this_0, fromInt(multiplier));
        var part = add(tmp$ret$0, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$1 = modulo(part, fromInt(other));
        this.cells_1.set_g707pu_k$(i, convertToInt(tmp$ret$1));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < last);
    while (!equalsLong(carry, new Long(0, 0))) {
      var tmp0 = carry;
      // Inline function 'kotlin.Long.rem' call
      var other_1 = 1000000000;
      var tmp$ret$3 = modulo(tmp0, fromInt(other_1));
      this.append_dlf032_k$(convertToInt(tmp$ret$3));
      var tmp0_0 = carry;
      // Inline function 'kotlin.Long.div' call
      var other_2 = 1000000000;
      carry = divide(tmp0_0, fromInt(other_2));
    }
    trim_0(this);
  };
  protoOf(DecimalWords_1).compare_zbc0gx_k$ = function (other) {
    if (!(this.size_1 === other.size_1))
      return compareTo(this.size_1, other.size_1);
    var inductionVariable = this.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var compared = compareTo(this.cells_1.get_c1px32_k$(i), other.get_c1px32_k$(i));
        if (!(compared === 0))
          return compared;
      }
       while (0 <= inductionVariable);
    return 0;
  };
  protoOf(DecimalWords_1).subtract_7jnlj2_k$ = function (other) {
    var borrow = 0;
    var inductionVariable = 0;
    var last = this.size_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var value = (this.cells_1.get_c1px32_k$(i) - (i < other.size_1 ? other.get_c1px32_k$(i) : 0) | 0) - borrow | 0;
        borrow = value < 0 ? 1 : 0;
        if (value < 0)
          value = value + 1000000000 | 0;
        this.cells_1.set_g707pu_k$(i, value);
      }
       while (inductionVariable < last);
    // Inline function 'kotlin.check' call
    if (!(borrow === 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    trim_0(this);
  };
  protoOf(DecimalWords_1).divideTen_qc6bdo_k$ = function () {
    var remainder = new Long(0, 0);
    var inductionVariable = this.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.cells_1.get_c1px32_k$(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(10));
        this.cells_1.set_g707pu_k$(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(10));
      }
       while (0 <= inductionVariable);
    trim_0(this);
    return convertToInt(remainder);
  };
  function normalized$digit(position, digits, topDigits, top, input) {
    var _unary__edvuaz = position._v;
    position._v = add(_unary__edvuaz, get_ONE());
    var at = _unary__edvuaz;
    if (compare(at, digits) >= 0)
      return 0;
    if (compare(at, fromInt(topDigits._v)) < 0)
      return (top / DecimalSquareRoot579_getInstance().powers_1[(topDigits._v - 1 | 0) - convertToInt(at) | 0] | 0) % 10 | 0;
    // Inline function 'kotlin.Long.minus' call
    var other = topDigits._v;
    var tail = subtract(at, fromInt(other));
    var tmp = input.size_1 - 2 | 0;
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(tail, fromInt(9));
    var chunk = tmp - convertToInt(tmp$ret$1) | 0;
    var tmp_0 = input.get_c1px32_k$(chunk);
    var tmp_1 = DecimalSquareRoot579_getInstance().powers_1;
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(tail, fromInt(9));
    return (tmp_0 / tmp_1[8 - convertToInt(tmp$ret$2) | 0] | 0) % 10 | 0;
  }
  function DecimalSquareRoot579() {
    DecimalSquareRoot579_instance = this;
    this.BASE_1 = 1000000000;
    this.PAGE_1 = 8192;
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.powers_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalSquareRoot579).canMaterialize_jcrl0l_k$ = function (digits, shift, scale) {
    return (compare(new Long(1, 0), shift) <= 0 ? compare(shift, new Long(646456992, 0)) <= 0 : false) && (compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false) && compare(multiply(new Long(4, 0), add(fromInt(digits), shift)), new Long(2147483647, 0)) <= 0;
  };
  protoOf(DecimalSquareRoot579).inexactPrecisionOverflows_a5y4i3_k$ = function (precision) {
    return precision > 646456993;
  };
  protoOf(DecimalSquareRoot579).normalized_giprud_k$ = function (coefficient, shift, precision, scale, preferred, mode) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(shift, new Long(0, 0)) > 0 && precision > 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(precision);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(11));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(9));
    var tmp$ret$5 = add(this_2, fromInt(1));
    var capacity = convertToInt(tmp$ret$5);
    var input = decimalChunks_1(this, coefficient);
    var top = input.get_c1px32_k$(input.size_1 - 1 | 0);
    var topDigits = {_v: 1};
    while (topDigits._v < 9 && top >= this.powers_1[topDigits._v]) {
      topDigits._v = topDigits._v + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = input.size_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = topDigits._v;
    var digits = add(tmp0_0, fromInt(other_0));
    var total = add(digits, shift);
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_3 = add(total, fromInt(1));
    var tmp$ret$9 = divide(this_3, fromInt(2));
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!equalsLong(tmp$ret$9, fromInt(precision))) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    var position = {_v: new Long(0, 0)};
    var root = new DecimalWords_1(capacity);
    var remainder = new DecimalWords_1(capacity);
    var trial = new DecimalWords_1(capacity);
    var allNines = true;
    var first = true;
    while (compare(position._v, total) < 0) {
      var pair = first && !equalsLong(modulo(total, new Long(2, 0)), new Long(0, 0)) ? normalized$digit(position, digits, topDigits, top, input) : imul(10, normalized$digit(position, digits, topDigits, top, input)) + normalized$digit(position, digits, topDigits, top, input) | 0;
      first = false;
      remainder.multiplyAdd_d61a5v_k$(100, pair);
      var d = 9;
      $l$loop: while (true) {
        trial.assign_3dx9l3_k$(root);
        trial.multiplyAdd_d61a5v_k$(20, d);
        trial.multiplyAdd_d61a5v_k$(d, 0);
        if (trial.compare_zbc0gx_k$(remainder) <= 0)
          break $l$loop;
        d = d - 1 | 0;
      }
      remainder.subtract_7jnlj2_k$(trial);
      root.multiplyAdd_d61a5v_k$(10, d);
      if (!(d === 9))
        allNines = false;
    }
    var inexact = !(remainder.size_1 === 0);
    if (inexact && mode.equals(RoundingMode_UNNECESSARY_getInstance()))
      throw ArithmeticException_init_$Create$('Rounding necessary');
    var halfAbove = remainder.compare_zbc0gx_k$(root) > 0;
    var tmp;
    if (inexact) {
      var tmp_0;
      switch (mode.get_ordinal_ip24qg_k$()) {
        case 0:
        case 2:
          tmp_0 = true;
          break;
        case 1:
        case 3:
          tmp_0 = false;
          break;
        case 4:
        case 5:
        case 6:
          tmp_0 = halfAbove;
          break;
        case 7:
          tmp_0 = false;
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    var increment = tmp;
    var finalScale = scale;
    if (increment) {
      root.multiplyAdd_d61a5v_k$(1, 1);
      if (allNines) {
        // Inline function 'kotlin.check' call
        if (!(root.divideTen_qc6bdo_k$() === 0)) {
          throw IllegalStateException_init_$Create$('Check failed.');
        }
        var _unary__edvuaz = finalScale;
        finalScale = subtract(_unary__edvuaz, get_ONE());
      }
    }
    while (!inexact && compare(finalScale, fromInt(preferred)) > 0 && (root.get_c1px32_k$(0) % 10 | 0) === 0) {
      // Inline function 'kotlin.check' call
      if (!(root.divideTen_qc6bdo_k$() === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var _unary__edvuaz_0 = finalScale;
      finalScale = subtract(_unary__edvuaz_0, get_ONE());
    }
    if (!(compare(new Long(-2147483648, -1), finalScale) <= 0 ? compare(finalScale, new Long(2147483647, 0)) <= 0 : false))
      throw ArithmeticException_init_$Create$(compare(finalScale, new Long(0, 0)) < 0 ? 'Overflow' : 'Underflow');
    return to(binaryCoefficient_0(this, root), convertToInt(finalScale));
  };
  var DecimalSquareRoot579_instance;
  function DecimalSquareRoot579_getInstance() {
    if (DecimalSquareRoot579_instance == null)
      new DecimalSquareRoot579();
    return DecimalSquareRoot579_instance;
  }
  function _get_capacity__a9k9f3_2($this) {
    return $this.capacity_1;
  }
  function _get_pages__cygrxv_3($this) {
    return $this.pages_1;
  }
  function _get_cells__j1rckg_3($this) {
    return $this.cells_1;
  }
  function _get_BASE__cm0716_3($this) {
    return $this.BASE_1;
  }
  function _get_PAGE__ctp2fw_3($this) {
    return $this.PAGE_1;
  }
  function _get_MAX_DIGITS__vbaa22_1($this) {
    return $this.MAX_DIGITS_1;
  }
  function _get_powers__vdnpa5_3($this) {
    return $this.powers_1;
  }
  function decimal($this, words, scratch) {
    // Inline function 'kotlin.collections.isEmpty' call
    if (words.length === 0)
      return new Digits(0);
    var inductionVariable = 0;
    var last = words.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        scratch.set_g707pu_k$(i, words[i]);
      }
       while (inductionVariable <= last);
    var size = words.length;
    var tmp0 = new Long(646456993, 0);
    var tmp0_0 = new Long(10, 0);
    // Inline function 'kotlin.Long.times' call
    var other = words.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(tmp0_0, fromInt(other));
    var bound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bound, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = divide(this_0, fromInt(9));
    var tmp$ret$5 = add(this_1, fromInt(1));
    var result = new Digits(convertToInt(tmp$ret$5));
    while (size > 0) {
      var remainder = new Long(0, 0);
      var inductionVariable_0 = size - 1 | 0;
      if (0 <= inductionVariable_0)
        do {
          var i_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + -1 | 0;
          var tmp0_1 = shiftLeft(remainder, 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = scratch.get_c1px32_k$(i_0);
          var part = add(tmp0_1, fromInt(other_0));
          // Inline function 'kotlin.Long.div' call
          var other_1 = 1000000000;
          var tmp$ret$7 = divide(part, fromInt(other_1));
          scratch.set_g707pu_k$(i_0, convertToInt(tmp$ret$7));
          // Inline function 'kotlin.Long.rem' call
          var other_2 = 1000000000;
          remainder = modulo(part, fromInt(other_2));
        }
         while (0 <= inductionVariable_0);
      result.set_g707pu_k$(result.size_1, convertToInt(remainder));
      result.size_1 = result.size_1 + 1 | 0;
      while (size > 0 && scratch.get_c1px32_k$(size - 1 | 0) === 0) {
        size = size - 1 | 0;
      }
    }
    return result;
  }
  function aligned($this, value, raise) {
    if (value.size_1 === 0)
      return new View(value, new Long(0, 0));
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$0 = modulo(raise, fromInt(9));
    var factor = $this.powers_1[convertToInt(tmp$ret$0)];
    var carry = new Long(0, 0);
    var oldSize = value.size_1;
    var inductionVariable = 0;
    if (inductionVariable < oldSize)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(value.get_c1px32_k$(i));
        var tmp$ret$1 = multiply(this_0, fromInt(factor));
        var part = add(tmp$ret$1, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$2 = modulo(part, fromInt(other));
        value.set_g707pu_k$(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < oldSize);
    if (!equalsLong(carry, new Long(0, 0))) {
      value.set_g707pu_k$(oldSize, convertToInt(carry));
      value.size_1 = value.size_1 + 1 | 0;
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$4 = divide(raise, fromInt(9));
    return new View(value, tmp$ret$4);
  }
  function View(value, offset) {
    this.value_1 = value;
    this.offset_1 = offset;
  }
  protoOf(View).get_value_j01efc_k$ = function () {
    return this.value_1;
  };
  protoOf(View).get_offset_hjmqak_k$ = function () {
    return this.offset_1;
  };
  protoOf(View).get_end_18j6ha_k$ = function () {
    var tmp;
    if (this.value_1.size_1 === 0) {
      tmp = new Long(0, 0);
    } else {
      var tmp0 = this.offset_1;
      // Inline function 'kotlin.Long.plus' call
      var other = this.value_1.size_1;
      tmp = add(tmp0, fromInt(other));
    }
    return tmp;
  };
  protoOf(View).contains_aa6tld_k$ = function (at) {
    return !(this.value_1.size_1 === 0) && compare(at, this.offset_1) >= 0 && compare(at, this.get_end_18j6ha_k$()) < 0;
  };
  protoOf(View).get_ugtq3c_k$ = function (at) {
    return this.contains_aa6tld_k$(at) ? this.value_1.get_c1px32_k$(convertToInt(subtract(at, this.offset_1))) : 0;
  };
  protoOf(View).next_27ektv_k$ = function (at, limit) {
    var tmp;
    if (!(this.value_1.size_1 === 0) && compare(at, this.offset_1) < 0) {
      // Inline function 'kotlin.comparisons.minOf' call
      var a = this.offset_1;
      tmp = compare(a, limit) <= 0 ? a : limit;
    } else {
      tmp = limit;
    }
    return tmp;
  };
  protoOf(View).digits_m0zfve_k$ = function () {
    return this.value_1.size_1 === 0 ? new Long(0, 0) : add(multiply(new Long(9, 0), this.offset_1), this.value_1.digits_m0zfve_k$());
  };
  function compare_0($this, a, b) {
    var order = a.digits_m0zfve_k$().compareTo_9jj042_k$(b.digits_m0zfve_k$());
    if (!(order === 0))
      return order;
    var tmp0 = a.get_end_18j6ha_k$();
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_0 = b.get_end_18j6ha_k$();
    var at = compare(tmp0, b_0) >= 0 ? tmp0 : b_0;
    while (compare(at, new Long(0, 0)) > 0) {
      var _unary__edvuaz = at;
      at = subtract(_unary__edvuaz, get_ONE());
      var cell = compareTo(a.get_ugtq3c_k$(at), b.get_ugtq3c_k$(at));
      if (!(cell === 0))
        return cell;
    }
    return 0;
  }
  function publish_0($this, decimal, sign, scale) {
    if (compare(decimal.digits_m0zfve_k$(), new Long(646456993, 0)) > 0)
      return null;
    var tmp0 = new Long(2147483647, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(new Long(4, 0), decimal.digits_m0zfve_k$());
    var bound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bound, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = divide(this_0, fromInt(30));
    var tmp$ret$3 = add(this_1, fromInt(1));
    var binary = new Cells_2(convertToInt(tmp$ret$3));
    var size = 0;
    var inductionVariable = decimal.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var carry = fromInt(decimal.get_c1px32_k$(i));
        var j = 0;
        while (j < size) {
          var tmp0_0 = fromInt(binary.get_c1px32_k$(j));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$4 = multiply(tmp0_0, fromInt(other));
          var part = add(tmp$ret$4, carry);
          binary.set_g707pu_k$(j, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
          j = j + 1 | 0;
        }
        if (!equalsLong(carry, new Long(0, 0))) {
          var _unary__edvuaz = size;
          size = _unary__edvuaz + 1 | 0;
          binary.set_g707pu_k$(_unary__edvuaz, convertToInt(carry));
        }
        var tmp0_1 = new Long(30, 0);
        // Inline function 'kotlin.Long.times' call
        var other_0 = size - 1 | 0;
        // Inline function 'kotlin.Long.plus' call
        var this_2 = multiply(tmp0_1, fromInt(other_0));
        var tmp0_2 = add(this_2, fromInt(32));
        // Inline function 'kotlin.countLeadingZeroBits' call
        var this_3 = binary.get_c1px32_k$(size - 1 | 0);
        // Inline function 'kotlin.Long.minus' call
        var other_1 = clz32(this_3);
        var bits = subtract(tmp0_2, fromInt(other_1));
        if (compare(bits, new Long(2147483647, 0)) > 0)
          return null;
      }
       while (0 <= inductionVariable);
    var tmp0_3 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_4 = multiply(tmp0_3, fromInt(other_2));
    var tmp0_4 = add(this_4, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_5 = binary.get_c1px32_k$(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_5);
    var bits_0 = subtract(tmp0_4, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_6 = add(bits_0, fromInt(7));
    var tmp$ret$14 = divide(this_6, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$14));
    var inductionVariable_0 = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_7 = new Long(8, 0);
        var bit = multiply(this_7, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$16 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$16);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$17 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$17);
        var value = shiftRightUnsigned(fromInt(binary.get_c1px32_k$(word)), offset);
        if (offset > 22 && (word + 1 | 0) < size)
          value = bitwiseOr(value, shiftLeft(fromInt(binary.get_c1px32_k$(word + 1 | 0)), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last);
    return to(BigInteger_init_$Create$_4(sign, bytes), scale);
  }
  function Cells_2(capacity) {
    this.capacity_1 = capacity;
    var tmp = this;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(this.capacity_1);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(8192));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = divide(this_2, fromInt(8192));
    // Inline function 'kotlin.arrayOfNulls' call
    var size = convertToInt(tmp$ret$2);
    tmp.pages_1 = Array(size);
  }
  protoOf(Cells_2).get_c1px32_k$ = function (index) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.capacity_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tmp0_safe_receiver = this.pages_1[index / 8192 | 0];
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver[index % 8192 | 0];
    return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  };
  protoOf(Cells_2).set_g707pu_k$ = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.capacity_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var slot = index / 8192 | 0;
    var page = this.pages_1[slot];
    if (page == null) {
      if (value === 0)
        return Unit_getInstance();
      // Inline function 'kotlin.Long.times' call
      var this_0 = fromInt(slot);
      var start = multiply(this_0, fromInt(8192));
      var tmp0 = new Long(8192, 0);
      // Inline function 'kotlin.comparisons.minOf' call
      var b = subtract(fromInt(this.capacity_1), start);
      var tmp$ret$2 = compare(tmp0, b) <= 0 ? tmp0 : b;
      page = new Int32Array(convertToInt(tmp$ret$2));
      this.pages_1[slot] = page;
    }
    page[index % 8192 | 0] = value;
  };
  protoOf(Cells_2).anyBelow_n2fok3_k$ = function (end) {
    var start = new Long(0, 0);
    var indexedObject = this.pages_1;
    var inductionVariable = 0;
    var last = indexedObject.length;
    $l$loop: while (inductionVariable < last) {
      var page = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (compare(start, fromInt(end)) >= 0)
        break $l$loop;
      if (!(page == null)) {
        var tmp0 = fromInt(page.length);
        // Inline function 'kotlin.comparisons.minOf' call
        var b = subtract(fromInt(end), start);
        var tmp$ret$0 = compare(tmp0, b) <= 0 ? tmp0 : b;
        var count = convertToInt(tmp$ret$0);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < count)
          do {
            var i = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            if (!(page[i] === 0))
              return true;
          }
           while (inductionVariable_0 < count);
      }
      // Inline function 'kotlin.Long.plus' call
      var this_0 = start;
      start = add(this_0, fromInt(8192));
    }
    return false;
  };
  function Digits(capacity) {
    this.cells_1 = new Cells_2(capacity);
    this.size_1 = 0;
  }
  protoOf(Digits).set_size_e2677a_k$ = function (_set____db54di) {
    this.size_1 = _set____db54di;
  };
  protoOf(Digits).get_size_woubt6_k$ = function () {
    return this.size_1;
  };
  protoOf(Digits).get_c1px32_k$ = function (index) {
    return this.cells_1.get_c1px32_k$(index);
  };
  protoOf(Digits).set_g707pu_k$ = function (index, value) {
    this.cells_1.set_g707pu_k$(index, value);
  };
  protoOf(Digits).fill_v6d2p1_k$ = function (start, end, value) {
    var inductionVariable = start;
    if (inductionVariable < end)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.cells_1.set_g707pu_k$(i, value);
      }
       while (inductionVariable < end);
  };
  protoOf(Digits).trim_7lhr2q_k$ = function () {
    while (this.size_1 > 0 && this.cells_1.get_c1px32_k$(this.size_1 - 1 | 0) === 0) {
      this.size_1 = this.size_1 - 1 | 0;
    }
  };
  protoOf(Digits).digits_m0zfve_k$ = function () {
    // Inline function 'kotlin.check' call
    if (!(this.size_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var width = 1;
    while (width < 9 && this.cells_1.get_c1px32_k$(this.size_1 - 1 | 0) >= DecimalSum585_getInstance().powers_1[width]) {
      width = width + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.size_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = width;
    return add(tmp0_0, fromInt(other_0));
  };
  protoOf(Digits).anyBelow_n2fok3_k$ = function (end) {
    return this.cells_1.anyBelow_n2fok3_k$(end);
  };
  protoOf(Digits).drop_zf6gy9_k$ = function (whole, divisor) {
    var result = new Digits((this.size_1 - whole | 0) + 1 | 0);
    var remainder = new Long(0, 0);
    var inductionVariable = this.size_1 - 1 | 0;
    if (whole <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.cells_1.get_c1px32_k$(i);
        var part = add(tmp0_0, fromInt(other_0));
        var tmp = i - whole | 0;
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(divisor));
        result.set_g707pu_k$(tmp, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(divisor));
      }
       while (!(i === whole));
    result.size_1 = this.size_1 - whole | 0;
    result.trim_7lhr2q_k$();
    return result;
  };
  protoOf(Digits).increment_vga7q7_k$ = function () {
    var at = 0;
    while (at < this.size_1 && this.cells_1.get_c1px32_k$(at) === 999999999) {
      this.cells_1.set_g707pu_k$(at, 0);
      at = at + 1 | 0;
    }
    this.cells_1.set_g707pu_k$(at, at === this.size_1 ? 1 : this.cells_1.get_c1px32_k$(at) + 1 | 0);
    if (at === this.size_1) {
      this.size_1 = this.size_1 + 1 | 0;
    }
  };
  protoOf(Digits).divideTen_qc6bdo_k$ = function () {
    var remainder = new Long(0, 0);
    var inductionVariable = this.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.cells_1.get_c1px32_k$(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(10));
        this.cells_1.set_g707pu_k$(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(10));
      }
       while (0 <= inductionVariable);
    this.trim_7lhr2q_k$();
    return convertToInt(remainder);
  };
  function DecimalSum585() {
    DecimalSum585_instance = this;
    this.BASE_1 = 1000000000;
    this.PAGE_1 = 8192;
    this.MAX_DIGITS_1 = new Long(646456993, 0);
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.powers_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalSum585).sum_v0avwh_k$ = function (leftSign, left, leftScale, rightSign, right, rightScale, context) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!((-1 <= leftSign ? leftSign <= 1 : false) && (-1 <= rightSign ? rightSign <= 1 : false))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    var tmp_0 = leftSign === 0;
    // Inline function 'kotlin.collections.isEmpty' call
    if (tmp_0 === (left.length === 0)) {
      var tmp_1 = rightSign === 0;
      // Inline function 'kotlin.collections.isEmpty' call
      tmp = tmp_1 === (right.length === 0);
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    // Inline function 'kotlin.comparisons.maxOf' call
    var scale = Math.max(leftScale, rightScale);
    var tmp1_elvis_lhs = context == null ? null : context.get_precision_e8tfsb_k$();
    var precision = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    var tmp0 = left.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = right.length;
    var tmp$ret$9 = Math.max(tmp0, b);
    var scratch = new Cells_2(tmp$ret$9);
    var a = decimal(this, left, scratch);
    var b_0 = decimal(this, right, scratch);
    var da = a.size_1 === 0 ? 0 : convertToInt(a.digits_m0zfve_k$());
    var db = b_0.size_1 === 0 ? 0 : convertToInt(b_0.digits_m0zfve_k$());
    if (!certifiedDecimalSumSpan585(da, db, leftScale, rightScale, precision))
      return null;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(scale);
    var tmp$ret$10 = subtract(this_0, fromInt(leftScale));
    var av = aligned(this, a, tmp$ret$10);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(scale);
    var tmp$ret$11 = subtract(this_1, fromInt(rightScale));
    var bv = aligned(this, b_0, tmp$ret$11);
    var order = compare_0(this, av, bv);
    if (!(leftSign === rightSign) && order === 0 || (leftSign === 0 && rightSign === 0))
      return to(Companion_getInstance_2().get_ZERO_wodlgx_k$(), scale);
    var subtract_0 = !(leftSign === 0) && !(rightSign === 0) && !(leftSign === rightSign);
    var high = subtract_0 && order < 0 ? bv : av;
    var low = subtract_0 && order < 0 ? av : bv;
    var sign = leftSign === 0 || (subtract_0 && order < 0) ? rightSign : leftSign;
    var tmp0_0 = high.get_end_18j6ha_k$();
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_1 = low.get_end_18j6ha_k$();
    var end = compare(tmp0_0, b_1) >= 0 ? tmp0_0 : b_1;
    var result = new Digits(convertToInt(add(end, new Long(1, 0))));
    var at = new Long(0, 0);
    var carry = 0;
    $l$loop: while (compare(at, end) < 0) {
      if (!high.contains_aa6tld_k$(at) && !low.contains_aa6tld_k$(at)) {
        var tmp0_1 = high.next_27ektv_k$(at, end);
        // Inline function 'kotlin.comparisons.minOf' call
        var b_2 = low.next_27ektv_k$(at, end);
        var next = compare(tmp0_1, b_2) <= 0 ? tmp0_1 : b_2;
        // Inline function 'kotlin.check' call
        if (!(compare(next, at) > 0)) {
          throw IllegalStateException_init_$Create$('Check failed.');
        }
        if (subtract_0) {
          if (!(carry === 0)) {
            result.fill_v6d2p1_k$(convertToInt(at), convertToInt(next), 999999999);
          }
        } else if (!(carry === 0)) {
          result.set_g707pu_k$(convertToInt(at), 1);
          carry = 0;
        }
        at = next;
        continue $l$loop;
      }
      var h = high.get_ugtq3c_k$(at);
      var l = low.get_ugtq3c_k$(at);
      if (subtract_0) {
        // Inline function 'kotlin.Long.minus' call
        var this_2 = fromInt(h);
        var tmp0_2 = subtract(this_2, fromInt(l));
        // Inline function 'kotlin.Long.minus' call
        var other = carry;
        var part = subtract(tmp0_2, fromInt(other));
        var tmp_2 = convertToInt(at);
        var tmp_3;
        if (compare(part, new Long(0, 0)) < 0) {
          // Inline function 'kotlin.Long.plus' call
          var other_0 = 1000000000;
          tmp_3 = add(part, fromInt(other_0));
        } else {
          tmp_3 = part;
        }
        result.set_g707pu_k$(tmp_2, convertToInt(tmp_3));
        carry = compare(part, new Long(0, 0)) < 0 ? 1 : 0;
      } else {
        // Inline function 'kotlin.Long.plus' call
        var this_3 = fromInt(h);
        var tmp0_3 = add(this_3, fromInt(l));
        // Inline function 'kotlin.Long.plus' call
        var other_1 = carry;
        var part_0 = add(tmp0_3, fromInt(other_1));
        var tmp_4 = convertToInt(at);
        // Inline function 'kotlin.Long.rem' call
        var other_2 = 1000000000;
        var tmp$ret$20 = modulo(part_0, fromInt(other_2));
        result.set_g707pu_k$(tmp_4, convertToInt(tmp$ret$20));
        // Inline function 'kotlin.Long.div' call
        var other_3 = 1000000000;
        var tmp$ret$21 = divide(part_0, fromInt(other_3));
        carry = convertToInt(tmp$ret$21);
      }
      var _unary__edvuaz = at;
      at = add(_unary__edvuaz, get_ONE());
    }
    if (subtract_0) {
      // Inline function 'kotlin.check' call
      if (!(carry === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
    } else if (!(carry === 0)) {
      result.set_g707pu_k$(convertToInt(end), carry);
    }
    result.size_1 = convertToInt(end) + (!subtract_0 && !(carry === 0) ? 1 : 0) | 0;
    result.trim_7lhr2q_k$();
    if (result.size_1 === 0)
      return to(Companion_getInstance_2().get_ZERO_wodlgx_k$(), scale);
    var digits = result.digits_m0zfve_k$();
    if (precision === 0 || compare(digits, fromInt(precision)) <= 0)
      return publish_0(this, result, sign, scale);
    if (compare(fromInt(precision), new Long(646456993, 0)) > 0)
      return null;
    // Inline function 'kotlin.Long.minus' call
    var drop = subtract(digits, fromInt(precision));
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$24 = divide(drop, fromInt(9));
    var whole = convertToInt(tmp$ret$24);
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$25 = modulo(drop, fromInt(9));
    var tail = convertToInt(tmp$ret$25);
    var guardCell = tail === 0 ? whole - 1 | 0 : whole;
    var guardPlace = tail === 0 ? 8 : tail - 1 | 0;
    var guard = (result.get_c1px32_k$(guardCell) / this.powers_1[guardPlace] | 0) % 10 | 0;
    var sticky = !((result.get_c1px32_k$(guardCell) % this.powers_1[guardPlace] | 0) === 0) || result.anyBelow_n2fok3_k$(guardCell);
    var inexact = !(guard === 0) || sticky;
    // Inline function 'kotlin.checkNotNull' call
    var tmp$ret$27;
    $l$block: {
      // Inline function 'kotlin.checkNotNull' call
      if (context == null) {
        var message_1 = 'Required value was null.';
        throw IllegalStateException_init_$Create$(toString_0(message_1));
      } else {
        tmp$ret$27 = context;
        break $l$block;
      }
    }
    var mode = tmp$ret$27.get_roundingMode_uxzxk0_k$();
    if (inexact && mode.equals(RoundingMode_UNNECESSARY_getInstance()))
      return null;
    var quotient = result.drop_zf6gy9_k$(whole, this.powers_1[tail]);
    var half = guard === 5 && sticky ? 1 : compareTo(guard, 5);
    var tmp_5;
    if (inexact) {
      var tmp_6;
      switch (mode.get_ordinal_ip24qg_k$()) {
        case 0:
          tmp_6 = true;
          break;
        case 1:
          tmp_6 = false;
          break;
        case 2:
          tmp_6 = sign > 0;
          break;
        case 3:
          tmp_6 = sign < 0;
          break;
        case 4:
          tmp_6 = half >= 0;
          break;
        case 5:
          tmp_6 = half > 0;
          break;
        case 6:
          tmp_6 = half > 0 || (half === 0 && !((quotient.get_c1px32_k$(0) % 2 | 0) === 0));
          break;
        case 7:
          tmp_6 = false;
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
      tmp_5 = tmp_6;
    } else {
      tmp_5 = false;
    }
    var increment = tmp_5;
    if (increment) {
      quotient.increment_vga7q7_k$();
    }
    var finalScale = subtract(fromInt(scale), drop);
    if (compare(quotient.digits_m0zfve_k$(), fromInt(precision)) > 0) {
      // Inline function 'kotlin.check' call
      if (!(quotient.divideTen_qc6bdo_k$() === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var _unary__edvuaz_0 = finalScale;
      finalScale = subtract(_unary__edvuaz_0, get_ONE());
    }
    if (!(compare(new Long(-2147483648, -1), finalScale) <= 0 ? compare(finalScale, new Long(2147483647, 0)) <= 0 : false))
      return null;
    return publish_0(this, quotient, sign, convertToInt(finalScale));
  };
  var DecimalSum585_instance;
  function DecimalSum585_getInstance() {
    if (DecimalSum585_instance == null)
      new DecimalSum585();
    return DecimalSum585_instance;
  }
  function materializedDecimalSum585(leftSign, rightSign, leftBits, rightBits, leftScale, rightScale) {
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$0 = Math.max(leftScale, rightScale);
    var scale = fromInt(tmp$ret$0);
    var limit = !(leftSign === 0) && leftSign === rightSign ? new Long(2147483646, 0) : new Long(2147483647, 0);
    return materializedDecimalSum585$supported(scale, limit, leftSign, leftBits, leftScale) && materializedDecimalSum585$supported(scale, limit, rightSign, rightBits, rightScale);
  }
  function certifiedDecimalSumSpan585(leftDigits, rightDigits, leftScale, rightScale, precision) {
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$0 = Math.max(leftScale, rightScale);
    var scale = fromInt(tmp$ret$0);
    var tmp;
    if (leftDigits === 0) {
      tmp = new Long(0, 0);
    } else {
      // Inline function 'kotlin.Long.minus' call
      var this_0 = add(fromInt(leftDigits), scale);
      tmp = subtract(this_0, fromInt(leftScale));
    }
    var left = tmp;
    var tmp_0;
    if (rightDigits === 0) {
      tmp_0 = new Long(0, 0);
    } else {
      // Inline function 'kotlin.Long.minus' call
      var this_1 = add(fromInt(rightDigits), scale);
      tmp_0 = subtract(this_1, fromInt(rightScale));
    }
    var right = tmp_0;
    // Inline function 'kotlin.comparisons.maxOf' call
    var largest = compare(left, right) >= 0 ? left : right;
    return precision === 0 || precision > 646456993 ? compare(largest, new Long(646456994, 0)) <= 0 : compare(largest, new Long(1292913989, 0)) <= 0;
  }
  function materializedDecimalSum585$supported(scale, limit, sign, bits, sourceScale) {
    if (sign === 0)
      return true;
    // Inline function 'kotlin.Long.minus' call
    var raise = subtract(scale, fromInt(sourceScale));
    return (compare(new Long(0, 0), raise) <= 0 ? compare(raise, new Long(646456992, 0)) <= 0 : false) && compare(add(fromInt(bits), multiply(new Long(4, 0), raise)), limit) <= 0;
  }
  function _get_capacity__a9k9f3_3($this) {
    return $this.capacity_1;
  }
  function _get_pages__cygrxv_4($this) {
    return $this.pages_1;
  }
  function _get_cells__j1rckg_4($this) {
    return $this.cells_1;
  }
  function _get_MAX_DIGITS__vbaa22_2($this) {
    return $this.MAX_DIGITS_1;
  }
  function _get_BASE__cm0716_4($this) {
    return $this.BASE_1;
  }
  function _get_PAGE__ctp2fw_4($this) {
    return $this.PAGE_1;
  }
  function _get_powers__vdnpa5_4($this) {
    return $this.powers_1;
  }
  function Input(text, characters) {
    this.text_1 = text;
    this.characters_1 = characters;
    var tmp = this;
    var tmp0_safe_receiver = this.text_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.length;
    var tmp_0;
    if (tmp1_elvis_lhs == null) {
      // Inline function 'kotlin.checkNotNull' call
      var tmp0 = this.characters_1;
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.checkNotNull' call
        if (tmp0 == null) {
          var message = 'Required value was null.';
          throw IllegalStateException_init_$Create$(toString_0(message));
        } else {
          tmp$ret$1 = tmp0;
          break $l$block;
        }
      }
      tmp_0 = tmp$ret$1.length;
    } else {
      tmp_0 = tmp1_elvis_lhs;
    }
    tmp.length_1 = tmp_0;
  }
  protoOf(Input).get_text_wouvsm_k$ = function () {
    return this.text_1;
  };
  protoOf(Input).get_characters_f8ovn_k$ = function () {
    return this.characters_1;
  };
  protoOf(Input).get_length_g42xv3_k$ = function () {
    return this.length_1;
  };
  protoOf(Input).get_kdzpvg_k$ = function (index) {
    var tmp;
    if (!(this.text_1 == null)) {
      tmp = charCodeAt(this.text_1, index);
    } else {
      // Inline function 'kotlin.checkNotNull' call
      var tmp0 = this.characters_1;
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.checkNotNull' call
        if (tmp0 == null) {
          var message = 'Required value was null.';
          throw IllegalStateException_init_$Create$(toString_0(message));
        } else {
          tmp$ret$1 = tmp0;
          break $l$block;
        }
      }
      tmp = tmp$ret$1[index];
    }
    return tmp;
  };
  function Lexical(sign, scale, first, digits, guard, sticky) {
    this.sign_1 = sign;
    this.scale_1 = scale;
    this.first_1 = first;
    this.digits_1 = digits;
    this.guard_1 = guard;
    this.sticky_1 = sticky;
  }
  protoOf(Lexical).get_sign_woubd2_k$ = function () {
    return this.sign_1;
  };
  protoOf(Lexical).get_scale_iyf28x_k$ = function () {
    return this.scale_1;
  };
  protoOf(Lexical).get_first_irdx8n_k$ = function () {
    return this.first_1;
  };
  protoOf(Lexical).get_digits_cdspnz_k$ = function () {
    return this.digits_1;
  };
  protoOf(Lexical).get_guard_is5118_k$ = function () {
    return this.guard_1;
  };
  protoOf(Lexical).get_sticky_jnjxf6_k$ = function () {
    return this.sticky_1;
  };
  function scan($this, input, precision) {
    if (input.length_1 === 0)
      throw NumberFormatException_init_$Create$('Empty BigDecimal');
    var i = 0;
    var sign = 1;
    if (input.get_kdzpvg_k$(i) === _Char___init__impl__6a9atx(45) || input.get_kdzpvg_k$(i) === _Char___init__impl__6a9atx(43)) {
      if (input.get_kdzpvg_k$(i) === _Char___init__impl__6a9atx(45))
        sign = -1;
      i = i + 1 | 0;
    }
    var seenDigit = false;
    var point = false;
    var fraction = new Long(0, 0);
    var first = -1;
    var digits = new Long(0, 0);
    var guard = 0;
    var sticky = false;
    var guardOrdinal = add(fromInt(precision), new Long(1, 0));
    $l$loop: while (i < input.length_1 && !(input.get_kdzpvg_k$(i) === _Char___init__impl__6a9atx(101)) && !(input.get_kdzpvg_k$(i) === _Char___init__impl__6a9atx(69))) {
      var at = i;
      var _unary__edvuaz = i;
      i = _unary__edvuaz + 1 | 0;
      var c = input.get_kdzpvg_k$(_unary__edvuaz);
      if (c === _Char___init__impl__6a9atx(46) && !point) {
        point = true;
        continue $l$loop;
      }
      var tmp0_elvis_lhs = digitToIntOrNull(c, 10);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        throw NumberFormatException_init_$Create$('Invalid decimal digit');
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var digit = tmp;
      seenDigit = true;
      if (point) {
        var _unary__edvuaz_0 = fraction;
        fraction = add(_unary__edvuaz_0, get_ONE());
      }
      if (first < 0 && !(digit === 0))
        first = at;
      if (first >= 0) {
        var _unary__edvuaz_1 = digits;
        digits = add(_unary__edvuaz_1, get_ONE());
        if (precision > 0) {
          if (equalsLong(digits, guardOrdinal))
            guard = digit;
          else if (compare(digits, guardOrdinal) > 0 && !(digit === 0))
            sticky = true;
        }
      }
    }
    if (!seenDigit)
      throw NumberFormatException_init_$Create$('No digits');
    var exponent = new Long(0, 0);
    if (i < input.length_1) {
      i = i + 1 | 0;
      var exponentSign = 1;
      if (i < input.length_1 && (input.get_kdzpvg_k$(i) === _Char___init__impl__6a9atx(43) || input.get_kdzpvg_k$(i) === _Char___init__impl__6a9atx(45))) {
        if (input.get_kdzpvg_k$(i) === _Char___init__impl__6a9atx(45))
          exponentSign = -1;
        i = i + 1 | 0;
      }
      if (i === input.length_1)
        throw NumberFormatException_init_$Create$('No exponent digits');
      while (i < input.length_1) {
        var _unary__edvuaz_2 = i;
        i = _unary__edvuaz_2 + 1 | 0;
        var tmp1_elvis_lhs = digitToIntOrNull(input.get_kdzpvg_k$(_unary__edvuaz_2), 10);
        var tmp_0;
        if (tmp1_elvis_lhs == null) {
          throw NumberFormatException_init_$Create$('Invalid exponent');
        } else {
          tmp_0 = tmp1_elvis_lhs;
        }
        var digit_0 = tmp_0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = exponent;
        // Inline function 'kotlin.Long.plus' call
        var this_1 = multiply(this_0, fromInt(10));
        exponent = add(this_1, fromInt(digit_0));
        var tmp_1 = exponent;
        // Inline function 'kotlin.Long.plus' call
        var this_2 = new Long(2147483647, 0);
        var tmp$ret$2 = add(this_2, fromInt(1));
        if (compare(tmp_1, add(tmp$ret$2, fraction)) > 0)
          throw NumberFormatException_init_$Create$('Exponent overflow');
      }
      var tmp0 = exponent;
      // Inline function 'kotlin.Long.times' call
      var other = exponentSign;
      exponent = multiply(tmp0, fromInt(other));
    }
    var scale = subtract(fraction, exponent);
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false))
      throw NumberFormatException_init_$Create$('Scale out of range');
    return new Lexical(sign, convertToInt(scale), first, digits, guard, sticky);
  }
  function parse_1($this, input, context) {
    var lexical = scan($this, input, context.get_precision_e8tfsb_k$());
    if (equalsLong(lexical.digits_1, new Long(0, 0)))
      return new BigDecimal(Companion_getInstance_2().get_ZERO_wodlgx_k$(), lexical.scale_1);
    var kept = retainedDecimalText588(lexical.digits_1, context.get_precision_e8tfsb_k$());
    if (compare(kept, new Long(646456993, 0)) > 0) {
      overflow($this);
    }
    var drop = subtract(lexical.digits_1, kept);
    var scale = roundingScale($this, subtract(fromInt(lexical.scale_1), drop));
    var inexact = !(lexical.guard_1 === 0) || lexical.sticky_1;
    if (compare(drop, new Long(0, 0)) > 0 && inexact && context.get_roundingMode_uxzxk0_k$().equals(RoundingMode_UNNECESSARY_getInstance()))
      throw ArithmeticException_init_$Create$('Rounding necessary');
    var prefix_0 = prefix($this, input, lexical.first_1, convertToInt(kept));
    if (compare(drop, new Long(0, 0)) > 0 && inexact) {
      var half = lexical.guard_1 === 5 && lexical.sticky_1 ? 1 : compareTo(lexical.guard_1, 5);
      var tmp;
      switch (context.get_roundingMode_uxzxk0_k$().get_ordinal_ip24qg_k$()) {
        case 0:
          tmp = true;
          break;
        case 1:
          tmp = false;
          break;
        case 2:
          tmp = lexical.sign_1 > 0;
          break;
        case 3:
          tmp = lexical.sign_1 < 0;
          break;
        case 4:
          tmp = half >= 0;
          break;
        case 5:
          tmp = half > 0;
          break;
        case 6:
          tmp = half > 0 || (half === 0 && !((prefix_0.get_c1px32_k$(0) % 2 | 0) === 0));
          break;
        case 7:
          tmp = false;
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
      var increment = tmp;
      if (increment) {
        prefix_0.increment_vga7q7_k$();
      }
    }
    if (compare(prefix_0.digits_m0zfve_k$(), kept) > 0) {
      // Inline function 'kotlin.check' call
      if (!(prefix_0.divideTen_qc6bdo_k$() === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      // Inline function 'kotlin.Long.minus' call
      var this_0 = fromInt(scale);
      var tmp$ret$1 = subtract(this_0, fromInt(1));
      scale = roundingScale($this, tmp$ret$1);
    }
    return new BigDecimal(publish_1($this, prefix_0, lexical.sign_1), scale);
  }
  function roundingScale($this, scale) {
    var narrowed = convertToInt(scale);
    if (!equalsLong(fromInt(narrowed), scale))
      throw ArithmeticException_init_$Create$(narrowed > 0 ? 'Underflow' : 'Overflow');
    return narrowed;
  }
  function overflow($this) {
    throw ArithmeticException_init_$Create$('BigInteger overflow');
  }
  function prefix($this, input, first, kept) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(kept);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(9));
    var tmp$ret$2 = add(this_2, fromInt(1));
    var result = new Digits_0(convertToInt(tmp$ret$2));
    var i = first;
    var consumed = 0;
    var block = 0;
    var inBlock = 0;
    $l$loop: while (consumed < kept) {
      var _unary__edvuaz = i;
      i = _unary__edvuaz + 1 | 0;
      var c = input.get_kdzpvg_k$(_unary__edvuaz);
      if (c === _Char___init__impl__6a9atx(46))
        continue $l$loop;
      block = imul(block, 10) + digitToInt(c, 10) | 0;
      consumed = consumed + 1 | 0;
      inBlock = inBlock + 1 | 0;
      if (inBlock === 9) {
        var _unary__edvuaz_0 = result.size_1;
        result.size_1 = _unary__edvuaz_0 + 1 | 0;
        result.set_g707pu_k$(_unary__edvuaz_0, block);
        block = 0;
        inBlock = 0;
      }
    }
    var low = 0;
    var high = result.size_1 - 1 | 0;
    while (low < high) {
      var cell = result.get_c1px32_k$(low);
      var _unary__edvuaz_1 = low;
      low = _unary__edvuaz_1 + 1 | 0;
      result.set_g707pu_k$(_unary__edvuaz_1, result.get_c1px32_k$(high));
      var _unary__edvuaz_2 = high;
      high = _unary__edvuaz_2 - 1 | 0;
      result.set_g707pu_k$(_unary__edvuaz_2, cell);
    }
    if (inBlock > 0) {
      var factor = $this.powers_1[inBlock];
      var carry = fromInt(block);
      var inductionVariable = 0;
      var last = result.size_1;
      if (inductionVariable < last)
        do {
          var at = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          // Inline function 'kotlin.Long.times' call
          var this_3 = fromInt(result.get_c1px32_k$(at));
          var tmp$ret$3 = multiply(this_3, fromInt(factor));
          var part = add(tmp$ret$3, carry);
          // Inline function 'kotlin.Long.rem' call
          var other = 1000000000;
          var tmp$ret$4 = modulo(part, fromInt(other));
          result.set_g707pu_k$(at, convertToInt(tmp$ret$4));
          // Inline function 'kotlin.Long.div' call
          var other_0 = 1000000000;
          carry = divide(part, fromInt(other_0));
        }
         while (inductionVariable < last);
      if (!equalsLong(carry, new Long(0, 0))) {
        var _unary__edvuaz_3 = result.size_1;
        result.size_1 = _unary__edvuaz_3 + 1 | 0;
        result.set_g707pu_k$(_unary__edvuaz_3, convertToInt(carry));
      }
    }
    // Inline function 'kotlin.check' call
    if (!(result.size_1 > 0 && !(result.get_c1px32_k$(result.size_1 - 1 | 0) === 0))) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return result;
  }
  function Cells_3(capacity) {
    this.capacity_1 = capacity;
    var tmp = this;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(this.capacity_1);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(8192));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = divide(this_2, fromInt(8192));
    // Inline function 'kotlin.arrayOfNulls' call
    var size = convertToInt(tmp$ret$2);
    tmp.pages_1 = Array(size);
  }
  protoOf(Cells_3).get_c1px32_k$ = function (index) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.capacity_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tmp0_safe_receiver = this.pages_1[index / 8192 | 0];
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver[index % 8192 | 0];
    return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  };
  protoOf(Cells_3).set_g707pu_k$ = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.capacity_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var slot = index / 8192 | 0;
    var page = this.pages_1[slot];
    if (page == null) {
      if (value === 0)
        return Unit_getInstance();
      // Inline function 'kotlin.comparisons.minOf' call
      var b = this.capacity_1 - imul(slot, 8192) | 0;
      var tmp$ret$1 = Math.min(8192, b);
      page = new Int32Array(tmp$ret$1);
      this.pages_1[slot] = page;
    }
    page[index % 8192 | 0] = value;
  };
  function Digits_0(capacity) {
    this.cells_1 = new Cells_3(capacity);
    this.size_1 = 0;
  }
  protoOf(Digits_0).set_size_e2677a_k$ = function (_set____db54di) {
    this.size_1 = _set____db54di;
  };
  protoOf(Digits_0).get_size_woubt6_k$ = function () {
    return this.size_1;
  };
  protoOf(Digits_0).get_c1px32_k$ = function (index) {
    return this.cells_1.get_c1px32_k$(index);
  };
  protoOf(Digits_0).set_g707pu_k$ = function (index, value) {
    this.cells_1.set_g707pu_k$(index, value);
  };
  protoOf(Digits_0).digits_m0zfve_k$ = function () {
    var top = this.cells_1.get_c1px32_k$(this.size_1 - 1 | 0);
    var count = 0;
    do {
      count = count + 1 | 0;
      top = top / 10 | 0;
    }
     while (!(top === 0));
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.size_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = count;
    return add(tmp0_0, fromInt(other_0));
  };
  protoOf(Digits_0).increment_vga7q7_k$ = function () {
    var i = 0;
    while (i < this.size_1 && this.cells_1.get_c1px32_k$(i) === 999999999) {
      this.cells_1.set_g707pu_k$(i, 0);
      i = i + 1 | 0;
    }
    if (i === this.size_1) {
      this.cells_1.set_g707pu_k$(i, 1);
      this.size_1 = this.size_1 + 1 | 0;
    } else {
      this.cells_1.set_g707pu_k$(i, this.cells_1.get_c1px32_k$(i) + 1 | 0);
    }
  };
  protoOf(Digits_0).divideTen_qc6bdo_k$ = function () {
    var remainder = new Long(0, 0);
    var inductionVariable = this.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.cells_1.get_c1px32_k$(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(10));
        this.cells_1.set_g707pu_k$(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(10));
      }
       while (0 <= inductionVariable);
    while (this.size_1 > 0 && this.cells_1.get_c1px32_k$(this.size_1 - 1 | 0) === 0) {
      this.size_1 = this.size_1 - 1 | 0;
    }
    // Inline function 'kotlin.check' call
    if (!(this.size_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return convertToInt(remainder);
  };
  function publish_1($this, decimal, sign) {
    var tmp0 = new Long(2147483647, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(new Long(4, 0), decimal.digits_m0zfve_k$());
    var bound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bound, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = divide(this_0, fromInt(30));
    var tmp$ret$3 = add(this_1, fromInt(1));
    var binary = new Cells_3(convertToInt(tmp$ret$3));
    var size = 0;
    var inductionVariable = decimal.size_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var carry = fromInt(decimal.get_c1px32_k$(i));
        var j = 0;
        while (j < size) {
          var tmp0_0 = fromInt(binary.get_c1px32_k$(j));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$4 = multiply(tmp0_0, fromInt(other));
          var part = add(tmp$ret$4, carry);
          binary.set_g707pu_k$(j, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
          j = j + 1 | 0;
        }
        if (!equalsLong(carry, new Long(0, 0))) {
          var _unary__edvuaz = size;
          size = _unary__edvuaz + 1 | 0;
          binary.set_g707pu_k$(_unary__edvuaz, convertToInt(carry));
        }
        var tmp0_1 = new Long(30, 0);
        // Inline function 'kotlin.Long.times' call
        var other_0 = size - 1 | 0;
        // Inline function 'kotlin.Long.plus' call
        var this_2 = multiply(tmp0_1, fromInt(other_0));
        var tmp0_2 = add(this_2, fromInt(32));
        // Inline function 'kotlin.countLeadingZeroBits' call
        var this_3 = binary.get_c1px32_k$(size - 1 | 0);
        // Inline function 'kotlin.Long.minus' call
        var other_1 = clz32(this_3);
        var bits = subtract(tmp0_2, fromInt(other_1));
        if (compare(bits, new Long(2147483647, 0)) > 0) {
          overflow($this);
        }
      }
       while (0 <= inductionVariable);
    var tmp0_3 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_4 = multiply(tmp0_3, fromInt(other_2));
    var tmp0_4 = add(this_4, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_5 = binary.get_c1px32_k$(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_5);
    var bits_0 = subtract(tmp0_4, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_6 = add(bits_0, fromInt(7));
    var tmp$ret$14 = divide(this_6, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$14));
    var inductionVariable_0 = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_7 = new Long(8, 0);
        var bit = multiply(this_7, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$16 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$16);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$17 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$17);
        var value = shiftRightUnsigned(fromInt(binary.get_c1px32_k$(word)), offset);
        if (offset > 22 && (word + 1 | 0) < size)
          value = bitwiseOr(value, shiftLeft(fromInt(binary.get_c1px32_k$(word + 1 | 0)), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last);
    return BigInteger_init_$Create$_4(sign, bytes);
  }
  function DecimalText588() {
    DecimalText588_instance = this;
    this.MAX_DIGITS_1 = new Long(646456993, 0);
    this.BASE_1 = 1000000000;
    this.PAGE_1 = 8192;
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.powers_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalText588).parse_ucvsji_k$ = function (value, context) {
    return parse_1(this, new Input(value, null), context);
  };
  protoOf(DecimalText588).parse_vc79vc_k$ = function (value, offset, length, context) {
    if (offset < 0 || length < 0 || offset > (value.length - length | 0))
      throw NumberFormatException_init_$Create$('Bad character range');
    return parse_1(this, new Input(null, copyOfRange(value, offset, offset + length | 0)), context);
  };
  var DecimalText588_instance;
  function DecimalText588_getInstance() {
    if (DecimalText588_instance == null)
      new DecimalText588();
    return DecimalText588_instance;
  }
  function retainedDecimalText588(digits, precision) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(digits, new Long(0, 0)) >= 0 && precision >= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    if (precision === 0) {
      tmp = digits;
    } else {
      // Inline function 'kotlin.comparisons.minOf' call
      var b = fromInt(precision);
      tmp = compare(digits, b) <= 0 ? digits : b;
    }
    return tmp;
  }
  function decimalDoubleString(value) {
    if (!isFinite(value))
      throw NumberFormatException_init_$Create$('Infinite or NaN');
    if (value === 0.0)
      return '0.0';
    var magnitude = value < 0 ? -value : value;
    var stripped = shortestDoubleDecimal(magnitude).stripTrailingZeros_9bdwdl_k$();
    var tmp0 = fromInt(stripped.precision_mrc8zm_k$());
    // Inline function 'kotlin.Long.minus' call
    var other = stripped.scale_1t1miy_k$();
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    var exponent = subtract(this_0, fromInt(1));
    // Inline function 'kotlin.ranges.contains' call
    var this_1 = numberRangeToNumber(-3, 6);
    if (contains(isInterface(this_1, ClosedRange) ? this_1 : THROW_CCE(), exponent)) {
      var plain = stripped.toPlainString_6qmubk_k$();
      var text = contains_0(plain, _Char___init__impl__6a9atx(46)) ? plain : plain + '.0';
      return (value < 0 ? '-' : '') + text;
    }
    var digits = stripped.unscaledValue_ga07pa_k$().abs_22cy_k$().toString();
    // Inline function 'kotlin.text.plus' call
    var this_2 = charCodeAt(digits, 0);
    var mantissa = toString(this_2) + '.' + (digits.length === 1 ? '0' : substring(digits, 1));
    return (value < 0 ? '-' : '') + mantissa + 'E' + exponent.toString();
  }
  function shortestDoubleDecimal(magnitude) {
    var exact = BigDecimal_init_$Create$_13(magnitude);
    var exactDigits = exact.unscaledValue_ga07pa_k$().toString();
    var exponent = (exactDigits.length - exact.scale_1t1miy_k$() | 0) - 1 | 0;
    var bits = toBits(magnitude);
    DoubleCompanionObject_getInstance();
    // Inline function 'kotlin.Long.minus' call
    // Inline function 'kotlin.fromBits' call
    var bits_0 = subtract(bits, fromInt(1));
    var tmp$ret$1 = doubleFromBits(bits_0);
    var previous = BigDecimal_init_$Create$_13(tmp$ret$1);
    DoubleCompanionObject_getInstance();
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.fromBits' call
    var bits_1 = add(bits, fromInt(1));
    var next = doubleFromBits(bits_1);
    var successor = isFinite(next) ? BigDecimal_init_$Create$_13(next) : null;
    var includesMidpoints = equalsLong(bitwiseAnd(bits, new Long(1, 0)), new Long(0, 0));
    var tmp0 = exact.scale_1t1miy_k$();
    var tmp2 = previous.scale_1t1miy_k$();
    var tmp1_elvis_lhs = successor == null ? null : successor.scale_1t1miy_k$();
    // Inline function 'kotlin.comparisons.maxOf' call
    var c = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    var tmp0_0 = Math.max(tmp0, tmp2, c);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = 16 - exponent | 0;
    var commonScale = Math.max(tmp0_0, b) + 1 | 0;
    var exactCoefficient = exact.setScale_k7foeo_k$(commonScale).unscaledValue_ga07pa_k$();
    var previousCoefficient = previous.setScale_k7foeo_k$(commonScale).unscaledValue_ga07pa_k$();
    var lowerCoefficient = exactCoefficient.add_gx3ep5_k$(previousCoefficient).shiftRight_g7qmqq_k$(1);
    var tmp;
    if (!(successor == null)) {
      tmp = exactCoefficient.add_gx3ep5_k$(successor.setScale_k7foeo_k$(commonScale).unscaledValue_ga07pa_k$()).shiftRight_g7qmqq_k$(1);
    } else {
      tmp = exactCoefficient.add_gx3ep5_k$(exactCoefficient.subtract_7q3n06_k$(previousCoefficient).shiftRight_g7qmqq_k$(1));
    }
    var upperCoefficient = tmp;
    // Inline function 'kotlin.collections.buildList' call
    // Inline function 'kotlin.collections.buildListInternal' call
    // Inline function 'kotlin.apply' call
    var this_0 = ArrayList_init_$Create$();
    var unit = Companion_getInstance_2().get_TEN_18jk30_k$().pow_iykav4_k$((commonScale + exponent | 0) - 16 | 0);
    // Inline function 'kotlin.repeat' call
    var inductionVariable = 0;
    if (inductionVariable < 17)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this_0.add_utx5q5_k$(unit);
        unit = unit.multiply_9xrhei_k$(Companion_getInstance_2().get_TEN_18jk30_k$());
      }
       while (inductionVariable < 17);
    var units = this_0.build_nmwvly_k$();
    var inductionVariable_0 = 2;
    if (inductionVariable_0 <= 17)
      do {
        var digits = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        var minimum = Companion_getInstance_2().get_TEN_18jk30_k$().pow_iykav4_k$(digits - 1 | 0);
        var maximum = minimum.multiply_9xrhei_k$(Companion_getInstance_2().get_TEN_18jk30_k$()).subtract_7q3n06_k$(Companion_getInstance_2().get_ONE_18jnkz_k$());
        var best = null;
        var bestDistance = null;
        var offsets = digits === 2 ? numberRangeToNumber(-1, 1) : numberRangeToNumber(0, 0);
        var inductionVariable_1 = offsets.get_first_irdx8n_k$();
        var last = offsets.get_last_wopotb_k$();
        if (inductionVariable_1 <= last)
          do {
            var offset = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var scale = ((digits - 1 | 0) - exponent | 0) - offset | 0;
            var unit_0 = units.get_c1px32_k$((17 - digits | 0) + offset | 0);
            var length = digits - offset | 0;
            var floor = BigInteger_init_$Create$_0(padEnd(take(exactDigits, length), length, _Char___init__impl__6a9atx(48)));
            var _iterator__ex2g4s = listOf([floor, floor.add_gx3ep5_k$(Companion_getInstance_2().get_ONE_18jnkz_k$())]).iterator_jk1svi_k$();
            $l$loop: while (_iterator__ex2g4s.hasNext_bitz1p_k$()) {
              var coefficient = _iterator__ex2g4s.next_20eer_k$();
              var bounded = coefficient.compareTo_ljvw96_k$(minimum) < 0 ? minimum : coefficient.compareTo_ljvw96_k$(maximum) > 0 ? maximum : coefficient;
              var aligned = bounded.multiply_9xrhei_k$(unit_0);
              var lowerComparison = aligned.compareTo_ljvw96_k$(lowerCoefficient);
              var upperComparison = aligned.compareTo_ljvw96_k$(upperCoefficient);
              if (lowerComparison < 0 || upperComparison > 0 || (!includesMidpoints && (lowerComparison === 0 || upperComparison === 0)))
                continue $l$loop;
              var decimal = (new BigDecimal(bounded, scale)).stripTrailingZeros_9bdwdl_k$();
              var distance = exactCoefficient.subtract_7q3n06_k$(aligned).abs_22cy_k$();
              var tmp2_safe_receiver = bestDistance;
              var tmp_0;
              if (tmp2_safe_receiver == null) {
                tmp_0 = null;
              } else {
                // Inline function 'kotlin.let' call
                tmp_0 = distance.compareTo_ljvw96_k$(tmp2_safe_receiver);
              }
              var tmp3_elvis_lhs = tmp_0;
              var comparison = tmp3_elvis_lhs == null ? -1 : tmp3_elvis_lhs;
              if (comparison < 0 || (comparison === 0 && !decimal.unscaledValue_ga07pa_k$().testBit_49w3bx_k$(0))) {
                best = decimal;
                bestDistance = distance;
              }
            }
          }
           while (!(offset === last));
        if (!(best == null))
          return best;
      }
       while (inductionVariable_0 <= 17);
    // Inline function 'kotlin.error' call
    var message = 'No seventeen-digit round-trip decimal';
    throw IllegalStateException_init_$Create$(toString_0(message));
  }
  function Decimals() {
    Decimals_instance = this;
  }
  protoOf(Decimals).fromBinary_ge9st7_k$ = function (value) {
    return BigDecimal_init_$Create$_13(value);
  };
  protoOf(Decimals).fromBinary_jnnzzm_k$ = function (value, context) {
    return BigDecimal_init_$Create$_14(value, context);
  };
  protoOf(Decimals).fromCanonical_vwg4o4_k$ = function (value) {
    return Companion_getInstance_0().valueOf_6g8uqq_k$(value);
  };
  protoOf(Decimals).fromCanonical_yr4zfx_k$ = function (value, context) {
    var canonical = Companion_getInstance_0().valueOf_6g8uqq_k$(value);
    return BigDecimal_init_$Create$_2(canonical.unscaledValue_ga07pa_k$(), canonical.scale_1t1miy_k$(), context);
  };
  protoOf(Decimals).parseOrNull_7h2hqb_k$ = function (text) {
    return toBigDecimalOrNull(text);
  };
  protoOf(Decimals).parseOrNull_f2jzh0_k$ = function (text, context) {
    return toBigDecimalOrNull_0(text, context);
  };
  var Decimals_instance;
  function Decimals_getInstance() {
    if (Decimals_instance == null)
      new Decimals();
    return Decimals_instance;
  }
  function divideExact(_this__u8e3s4, divisor) {
    return _this__u8e3s4.divide_1i9k8h_k$(divisor);
  }
  function roundToPrecision(_this__u8e3s4, precision, mode) {
    return _this__u8e3s4.round_x6ni4b_k$(new MathContext(precision, mode));
  }
  function roundToScale(_this__u8e3s4, scale, mode) {
    return _this__u8e3s4.setScale_56o25g_k$(scale, mode);
  }
  function Value(value) {
    this.value_1 = value;
  }
  protoOf(Value).get_value_j01efc_k$ = function () {
    return this.value_1;
  };
  protoOf(Value).component1_7eebsc_k$ = function () {
    return this.value_1;
  };
  protoOf(Value).copy_62qimy_k$ = function (value) {
    return new Value(value);
  };
  protoOf(Value).copy$default_2wmnep_k$ = function (value, $super) {
    value = value === VOID ? this.value_1 : value;
    return $super === VOID ? this.copy_62qimy_k$(value) : $super.copy_62qimy_k$.call(this, value);
  };
  protoOf(Value).toString = function () {
    return 'Value(value=' + toString_1(this.value_1) + ')';
  };
  protoOf(Value).hashCode = function () {
    return this.value_1 == null ? 0 : hashCode(this.value_1);
  };
  protoOf(Value).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Value))
      return false;
    if (!equals(this.value_1, other.value_1))
      return false;
    return true;
  };
  function Failure(cause) {
    this.cause_1 = cause;
  }
  protoOf(Failure).get_cause_iplhs0_k$ = function () {
    return this.cause_1;
  };
  protoOf(Failure).component1_7eebsc_k$ = function () {
    return this.cause_1;
  };
  protoOf(Failure).copy_8b1aki_k$ = function (cause) {
    return new Failure(cause);
  };
  protoOf(Failure).copy$default_8ubso6_k$ = function (cause, $super) {
    cause = cause === VOID ? this.cause_1 : cause;
    return $super === VOID ? this.copy_8b1aki_k$(cause) : $super.copy_8b1aki_k$.call(this, cause);
  };
  protoOf(Failure).toString = function () {
    return 'Failure(cause=' + this.cause_1.toString() + ')';
  };
  protoOf(Failure).hashCode = function () {
    return hashCode(this.cause_1);
  };
  protoOf(Failure).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Failure))
      return false;
    if (!equals(this.cause_1, other.cause_1))
      return false;
    return true;
  };
  function ExactConversion() {
  }
  function toLongExactResult(_this__u8e3s4) {
    // Inline function 'io.heapy.krogu.math.exactConversion' call
    var tmp;
    try {
      var tmp$ret$1 = _this__u8e3s4.longValueExact_akftqu_k$();
      tmp = new Value(tmp$ret$1);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var failure = $p;
        tmp_0 = new Failure(failure);
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function toBigIntegerExactResult(_this__u8e3s4) {
    // Inline function 'io.heapy.krogu.math.exactConversion' call
    var tmp;
    try {
      var tmp$ret$1 = _this__u8e3s4.toBigIntegerExact_538mey_k$();
      tmp = new Value(tmp$ret$1);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var failure = $p;
        tmp_0 = new Failure(failure);
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function toIntExactResult(_this__u8e3s4) {
    // Inline function 'io.heapy.krogu.math.exactConversion' call
    var tmp;
    try {
      var tmp$ret$1 = _this__u8e3s4.intValueExact_x1rjxf_k$();
      tmp = new Value(tmp$ret$1);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var failure = $p;
        tmp_0 = new Failure(failure);
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function toLongExactResult_0(_this__u8e3s4) {
    // Inline function 'io.heapy.krogu.math.exactConversion' call
    var tmp;
    try {
      var tmp$ret$1 = _this__u8e3s4.longValueExact_akftqu_k$();
      tmp = new Value(tmp$ret$1);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var failure = $p;
        tmp_0 = new Failure(failure);
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function toIntExactResult_0(_this__u8e3s4) {
    // Inline function 'io.heapy.krogu.math.exactConversion' call
    var tmp;
    try {
      var tmp$ret$1 = _this__u8e3s4.intValueExact_x1rjxf_k$();
      tmp = new Value(tmp$ret$1);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var failure = $p;
        tmp_0 = new Failure(failure);
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function QuotientRemainder(quotient, remainder) {
    this.quotient_1 = quotient;
    this.remainder_1 = remainder;
  }
  protoOf(QuotientRemainder).get_quotient_ooukvo_k$ = function () {
    return this.quotient_1;
  };
  protoOf(QuotientRemainder).get_remainder_mwecu4_k$ = function () {
    return this.remainder_1;
  };
  protoOf(QuotientRemainder).component1_7eebsc_k$ = function () {
    return this.quotient_1;
  };
  protoOf(QuotientRemainder).component2_7eebsb_k$ = function () {
    return this.remainder_1;
  };
  protoOf(QuotientRemainder).copy_sxa67d_k$ = function (quotient, remainder) {
    return new QuotientRemainder(quotient, remainder);
  };
  protoOf(QuotientRemainder).copy$default_wcyrou_k$ = function (quotient, remainder, $super) {
    quotient = quotient === VOID ? this.quotient_1 : quotient;
    remainder = remainder === VOID ? this.remainder_1 : remainder;
    return $super === VOID ? this.copy_sxa67d_k$(quotient, remainder) : $super.copy_sxa67d_k$.call(this, quotient, remainder);
  };
  protoOf(QuotientRemainder).toString = function () {
    return 'QuotientRemainder(quotient=' + toString_1(this.quotient_1) + ', remainder=' + toString_1(this.remainder_1) + ')';
  };
  protoOf(QuotientRemainder).hashCode = function () {
    var result = this.quotient_1 == null ? 0 : hashCode(this.quotient_1);
    result = imul(result, 31) + (this.remainder_1 == null ? 0 : hashCode(this.remainder_1)) | 0;
    return result;
  };
  protoOf(QuotientRemainder).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof QuotientRemainder))
      return false;
    if (!equals(this.quotient_1, other.quotient_1))
      return false;
    if (!equals(this.remainder_1, other.remainder_1))
      return false;
    return true;
  };
  function quotientAndRemainder(_this__u8e3s4, divisor) {
    // Inline function 'kotlin.let' call
    var it = _this__u8e3s4.divideAndRemainder_2r68pv_k$(divisor);
    return new QuotientRemainder(it[0], it[1]);
  }
  function quotientAndRemainder_0(_this__u8e3s4, divisor) {
    // Inline function 'kotlin.let' call
    var it = _this__u8e3s4.divideAndRemainder_7j7z7h_k$(divisor);
    return new QuotientRemainder(it[0], it[1]);
  }
  function quotientAndRemainder_1(_this__u8e3s4, divisor, context) {
    // Inline function 'kotlin.let' call
    var it = _this__u8e3s4.divideAndRemainder_hsaj58_k$(divisor, context);
    return new QuotientRemainder(it[0], it[1]);
  }
  function exactConversion(operation) {
    var tmp;
    try {
      tmp = new Value(operation());
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var failure = $p;
        tmp_0 = new Failure(failure);
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function decimalFloatString(value) {
    var raw = toBits_0(value);
    var bits = raw & 2147483647;
    if (bits >= 2139095040)
      throw NumberFormatException_init_$Create$('Infinite or NaN');
    if (bits === 0)
      return '0.0';
    var selected = selectFloatDecimal(bits);
    var digits = selected.unscaledValue_ga07pa_k$().toString();
    var exponent = (digits.length - selected.scale_1t1miy_k$() | 0) - 1 | 0;
    var tmp;
    if (-3 <= exponent ? exponent <= 6 : false) {
      var plain = selected.toPlainString_6qmubk_k$();
      tmp = contains_0(plain, _Char___init__impl__6a9atx(46)) ? plain : plain + '.0';
    } else {
      var fraction = digits.length === 1 ? '0' : substring(digits, 1);
      // Inline function 'kotlin.text.plus' call
      var this_0 = charCodeAt(digits, 0);
      tmp = toString(this_0) + '.' + fraction + 'E' + exponent;
    }
    var unsigned = tmp;
    return raw < 0 ? '-' + unsigned : unsigned;
  }
  function selectFloatDecimal(bits) {
    var factor = Companion_getInstance_2().valueOf_wwtjy2_k$(new Long(5, 0)).pow_iykav4_k$(150);
    var center = floatLatticeInteger(bits);
    var exact = center.shiftLeft_qqh5sf_k$(1).multiply_9xrhei_k$(factor);
    var lower = center.add_gx3ep5_k$(floatLatticeInteger(bits - 1 | 0)).multiply_9xrhei_k$(factor);
    var upper = center.add_gx3ep5_k$(floatLatticeInteger(bits + 1 | 0)).multiply_9xrhei_k$(factor);
    var closed = (bits & 1) === 0;
    var exactDigits = exact.toString();
    var exponent = exactDigits.length - 151 | 0;
    // Inline function 'kotlin.collections.buildList' call
    // Inline function 'kotlin.collections.buildListInternal' call
    // Inline function 'kotlin.apply' call
    var this_0 = ArrayList_init_$Create$();
    var unit = Companion_getInstance_2().get_TEN_18jk30_k$().pow_iykav4_k$((150 + exponent | 0) - 8 | 0);
    // Inline function 'kotlin.repeat' call
    var inductionVariable = 0;
    if (inductionVariable < 9)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this_0.add_utx5q5_k$(unit);
        unit = unit.multiply_9xrhei_k$(Companion_getInstance_2().get_TEN_18jk30_k$());
      }
       while (inductionVariable < 9);
    var units = this_0.build_nmwvly_k$();
    var inductionVariable_0 = 2;
    if (inductionVariable_0 <= 9)
      do {
        var budget = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        var first = Companion_getInstance_2().get_TEN_18jk30_k$().pow_iykav4_k$(budget - 1 | 0);
        var last = first.multiply_9xrhei_k$(Companion_getInstance_2().get_TEN_18jk30_k$()).subtract_7q3n06_k$(Companion_getInstance_2().get_ONE_18jnkz_k$());
        var chosen = null;
        var distance = null;
        var progression = budget === 2 ? numberRangeToNumber(-1, 1) : numberRangeToNumber(0, 0);
        var inductionVariable_1 = progression.get_first_irdx8n_k$();
        var last_0 = progression.get_last_wopotb_k$();
        if (inductionVariable_1 <= last_0)
          do {
            var offset = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var scale = ((budget - 1 | 0) - exponent | 0) - offset | 0;
            var unit_0 = units.get_c1px32_k$((9 - budget | 0) + offset | 0);
            var prefixLength = budget - offset | 0;
            var floor = BigInteger_init_$Create$_0(padEnd(take(exactDigits, prefixLength), prefixLength, _Char___init__impl__6a9atx(48)));
            var _iterator__ex2g4s = listOf([floor, floor.add_gx3ep5_k$(Companion_getInstance_2().get_ONE_18jnkz_k$())]).iterator_jk1svi_k$();
            $l$loop: while (_iterator__ex2g4s.hasNext_bitz1p_k$()) {
              var unbounded = _iterator__ex2g4s.next_20eer_k$();
              var coefficient = unbounded.compareTo_ljvw96_k$(first) < 0 ? first : unbounded.compareTo_ljvw96_k$(last) > 0 ? last : unbounded;
              var aligned = coefficient.multiply_9xrhei_k$(unit_0);
              var low = aligned.compareTo_ljvw96_k$(lower);
              var high = aligned.compareTo_ljvw96_k$(upper);
              if (low < 0 || high > 0 || (!closed && (low === 0 || high === 0)))
                continue $l$loop;
              var candidate = (new BigDecimal(coefficient, scale)).stripTrailingZeros_9bdwdl_k$();
              var delta = exact.subtract_7q3n06_k$(aligned).abs_22cy_k$();
              var tmp0_safe_receiver = distance;
              var tmp;
              if (tmp0_safe_receiver == null) {
                tmp = null;
              } else {
                // Inline function 'kotlin.let' call
                tmp = delta.compareTo_ljvw96_k$(tmp0_safe_receiver);
              }
              var tmp1_elvis_lhs = tmp;
              var order = tmp1_elvis_lhs == null ? -1 : tmp1_elvis_lhs;
              if (order < 0 || (order === 0 && !candidate.unscaledValue_ga07pa_k$().testBit_49w3bx_k$(0))) {
                chosen = candidate;
                distance = delta;
              }
            }
          }
           while (!(offset === last_0));
        if (!(chosen == null))
          return chosen;
      }
       while (inductionVariable_0 <= 9);
    // Inline function 'kotlin.error' call
    var message = 'No nine-digit binary32 round-trip decimal';
    throw IllegalStateException_init_$Create$(toString_0(message));
  }
  function floatLatticeInteger(bits) {
    var field = bits >>> 23 | 0;
    var fraction = bits & 8388607;
    var significand = field === 0 ? fraction : fraction + 8388608 | 0;
    return Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt(significand)).shiftLeft_qqh5sf_k$(field === 0 ? 0 : field - 1 | 0);
  }
  function MagnitudeLimits() {
    MagnitudeLimits_instance = this;
    this.WORD_BITS_1 = 30;
    this.MAX_BYTES_1 = 268435456;
  }
  protoOf(MagnitudeLimits).get_WORD_BITS_18amj2_k$ = function () {
    return this.WORD_BITS_1;
  };
  protoOf(MagnitudeLimits).get_MAX_BYTES_5euo7t_k$ = function () {
    return this.MAX_BYTES_1;
  };
  protoOf(MagnitudeLimits).packedWords_b6v23i_k$ = function (byteCount, extraCarryBit) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(byteCount >= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (byteCount > 268435456)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(byteCount);
    var tmp0 = multiply(this_0, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var other = extraCarryBit ? 1 : 0;
    var bits = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(bits, fromInt(30));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$7 = divide(this_2, fromInt(30));
    return convertToInt(tmp$ret$7);
  };
  protoOf(MagnitudeLimits).checkedBitLength_5hvey4_k$ = function (wordCount, highWord) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(wordCount > 0 && (1 <= highWord ? highWord < 1073741824 : false))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(wordCount);
    // Inline function 'kotlin.Long.times' call
    var this_1 = subtract(this_0, fromInt(1));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = multiply(this_1, fromInt(30));
    var tmp0 = add(this_2, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    // Inline function 'kotlin.Long.minus' call
    var other = clz32(highWord);
    var bits = subtract(tmp0, fromInt(other));
    if (compare(bits, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    return convertToInt(bits);
  };
  protoOf(MagnitudeLimits).parserDefinitelyOverflows_zbidp1_k$ = function (significantDigits, radix) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(significantDigits > 0 && (2 <= radix ? radix <= 36 : false))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.countLeadingZeroBits' call
    var bitsPerDigit = 31 - clz32(radix) | 0;
    var tmp = new Long(1, 0);
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(significantDigits);
    // Inline function 'kotlin.Long.times' call
    var this_1 = subtract(this_0, fromInt(1));
    var tmp$ret$5 = multiply(this_1, fromInt(bitsPerDigit));
    var minimumBits = add(tmp, tmp$ret$5);
    return compare(minimumBits, new Long(2147483647, 0)) > 0;
  };
  protoOf(MagnitudeLimits).initialSqrtShift_vufmey_k$ = function (bitLength) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(bitLength);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(1));
    var tmp$ret$1 = divide(this_1, fromInt(2));
    return convertToInt(tmp$ret$1);
  };
  var MagnitudeLimits_instance;
  function MagnitudeLimits_getInstance() {
    if (MagnitudeLimits_instance == null)
      new MagnitudeLimits();
    return MagnitudeLimits_instance;
  }
  function _get_BITS__cm5c05($this) {
    return $this.BITS_1;
  }
  function _get_MASK__cs1xpb_0($this) {
    return $this.MASK_1;
  }
  function Arena(size) {
    this.words_1 = new Int32Array(size);
    this.used_1 = 0;
  }
  protoOf(Arena).get_words_j0u8w0_k$ = function () {
    return this.words_1;
  };
  protoOf(Arena).set_used_sj5gb2_k$ = function (_set____db54di) {
    this.used_1 = _set____db54di;
  };
  protoOf(Arena).get_used_wovsp2_k$ = function () {
    return this.used_1;
  };
  protoOf(Arena).allocate_fhfxbv_k$ = function (size) {
    var offset = this.used_1;
    // Inline function 'kotlin.check' call
    if (!(size <= (this.words_1.length - offset | 0))) {
      var message = 'Multiplication scratch bound';
      throw IllegalStateException_init_$Create$(toString_0(message));
    }
    this.used_1 = this.used_1 + size | 0;
    return offset;
  };
  function product($this, a, ao, al, b, bo, bl, out, oo, arena, threshold, squareThreshold) {
    fill(out, 0, oo, (oo + al | 0) + bl | 0);
    if (al === 0 || bl === 0)
      return Unit_getInstance();
    // Inline function 'kotlin.comparisons.minOf' call
    var small = Math.min(al, bl);
    // Inline function 'kotlin.comparisons.maxOf' call
    var large = Math.max(al, bl);
    if (small < threshold) {
      if (a === b && ao === bo && al === bl && al >= squareThreshold) {
        square($this, a, ao, al, out, oo);
      } else {
        school($this, a, ao, al, b, bo, bl, out, oo);
      }
      return Unit_getInstance();
    }
    var mark = arena.used_1;
    var tmp = fromInt(large);
    // Inline function 'kotlin.Long.times' call
    var this_0 = new Long(2, 0);
    var tmp$ret$2 = multiply(this_0, fromInt(small));
    if (compare(tmp, tmp$ret$2) > 0) {
      var longer = al >= bl ? a : b;
      var lo = al >= bl ? ao : bo;
      var shorter = al >= bl ? b : a;
      var so = al >= bl ? bo : ao;
      var temp = arena.allocate_fhfxbv_k$(imul(2, small));
      var position = 0;
      while (position < large) {
        // Inline function 'kotlin.comparisons.minOf' call
        var b_0 = large - position | 0;
        var length = Math.min(small, b_0);
        product($this, longer, lo + position | 0, length, shorter, so, small, arena.words_1, temp, arena, threshold, squareThreshold);
        addAt($this, out, oo + position | 0, arena.words_1, temp, length + small | 0);
        position = position + length | 0;
      }
      arena.used_1 = mark;
      return Unit_getInstance();
    }
    var split = large / 2 | 0;
    // Inline function 'kotlin.comparisons.minOf' call
    var aLow = Math.min(al, split);
    // Inline function 'kotlin.comparisons.minOf' call
    var bLow = Math.min(bl, split);
    var aHigh = al - aLow | 0;
    var bHigh = bl - bLow | 0;
    product($this, a, ao, aLow, b, bo, bLow, out, oo, arena, threshold, squareThreshold);
    if (aHigh > 0 && bHigh > 0) {
      product($this, a, ao + aLow | 0, aHigh, b, bo + bLow | 0, bHigh, out, oo + imul(2, split) | 0, arena, threshold, squareThreshold);
    }
    // Inline function 'kotlin.comparisons.maxOf' call
    var ac = Math.max(aLow, aHigh) + 1 | 0;
    // Inline function 'kotlin.comparisons.maxOf' call
    var bc = Math.max(bLow, bHigh) + 1 | 0;
    var sumA = arena.allocate_fhfxbv_k$(ac);
    var sumB = arena.allocate_fhfxbv_k$(bc);
    var middle = arena.allocate_fhfxbv_k$(ac + bc | 0);
    var aLength = sum($this, a, ao, aLow, ao + aLow | 0, aHigh, arena.words_1, sumA, ac);
    var bLength = sum($this, b, bo, bLow, bo + bLow | 0, bHigh, arena.words_1, sumB, bc);
    product($this, arena.words_1, sumA, aLength, arena.words_1, sumB, bLength, arena.words_1, middle, arena, threshold, squareThreshold);
    var middleLength = aLength + bLength | 0;
    subtract_0($this, arena.words_1, middle, middleLength, out, oo, aLow + bLow | 0);
    if (aHigh > 0 && bHigh > 0) {
      subtract_0($this, arena.words_1, middle, middleLength, out, oo + imul(2, split) | 0, aHigh + bHigh | 0);
    }
    addAt($this, out, oo + split | 0, arena.words_1, middle, trimmed($this, arena.words_1, middle, middleLength));
    arena.used_1 = mark;
  }
  function school($this, a, ao, al, b, bo, bl, out, oo) {
    var inductionVariable = 0;
    if (inductionVariable < al)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < bl)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp0 = fromInt(a[ao + i | 0]);
            // Inline function 'kotlin.Long.times' call
            var other = b[bo + j | 0];
            var tmp0_0 = multiply(tmp0, fromInt(other));
            // Inline function 'kotlin.Long.plus' call
            var other_0 = out[(oo + i | 0) + j | 0];
            var tmp$ret$1 = add(tmp0_0, fromInt(other_0));
            var value = add(tmp$ret$1, carry);
            out[(oo + i | 0) + j | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
            carry = shiftRightUnsigned(value, 30);
          }
           while (inductionVariable_0 < bl);
        out[(oo + i | 0) + bl | 0] = convertToInt(carry);
      }
       while (inductionVariable < al);
  }
  function square($this, a, offset, length, out, oo) {
    var inductionVariable = 0;
    if (inductionVariable < length)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var word = fromInt(a[offset + i | 0]);
        var tmp0 = multiply(word, word);
        // Inline function 'kotlin.Long.plus' call
        var other = out[oo + imul(2, i) | 0];
        var diagonal = add(tmp0, fromInt(other));
        out[oo + imul(2, i) | 0] = convertToInt(bitwiseAnd(diagonal, new Long(1073741823, 0)));
        var carry = shiftRightUnsigned(diagonal, 30);
        var inductionVariable_0 = i + 1 | 0;
        if (inductionVariable_0 < length)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp0_0 = multiply(new Long(2, 0), word);
            // Inline function 'kotlin.Long.times' call
            var other_0 = a[offset + j | 0];
            var tmp0_1 = multiply(tmp0_0, fromInt(other_0));
            // Inline function 'kotlin.Long.plus' call
            var other_1 = out[(oo + i | 0) + j | 0];
            var tmp$ret$2 = add(tmp0_1, fromInt(other_1));
            var value = add(tmp$ret$2, carry);
            out[(oo + i | 0) + j | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
            carry = shiftRightUnsigned(value, 30);
          }
           while (inductionVariable_0 < length);
        var index = (oo + i | 0) + length | 0;
        while (!equalsLong(carry, new Long(0, 0))) {
          var value_0 = add(fromInt(out[index]), carry);
          var _unary__edvuaz = index;
          index = _unary__edvuaz + 1 | 0;
          out[_unary__edvuaz] = convertToInt(bitwiseAnd(value_0, new Long(1073741823, 0)));
          carry = shiftRightUnsigned(value_0, 30);
        }
      }
       while (inductionVariable < length);
  }
  function sum($this, a, low, lowLength, high, highLength, out, offset, capacity) {
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = capacity - 1 | 0;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var value = add(add(i < lowLength ? fromInt(a[low + i | 0]) : new Long(0, 0), i < highLength ? fromInt(a[high + i | 0]) : new Long(0, 0)), carry);
        out[offset + i | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(value, 30);
      }
       while (inductionVariable < last);
    out[(offset + capacity | 0) - 1 | 0] = convertToInt(carry);
    return trimmed($this, out, offset, capacity);
  }
  function subtract_0($this, out, offset, length, b, bo, bl) {
    var borrow = new Long(0, 0);
    var inductionVariable = 0;
    if (inductionVariable < length)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var value = subtract(subtract(fromInt(out[offset + i | 0]), i < bl ? fromInt(b[bo + i | 0]) : new Long(0, 0)), borrow);
        out[offset + i | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
        borrow = compare(value, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
      }
       while (inductionVariable < length);
    // Inline function 'kotlin.check' call
    if (!equalsLong(borrow, new Long(0, 0))) {
      var message = 'Negative Karatsuba cross product';
      throw IllegalStateException_init_$Create$(toString_0(message));
    }
  }
  function addAt($this, out, offset, b, bo, length) {
    var carry = new Long(0, 0);
    var i = 0;
    while (i < length || !equalsLong(carry, new Long(0, 0))) {
      var value = add(add(fromInt(out[offset + i | 0]), i < length ? fromInt(b[bo + i | 0]) : new Long(0, 0)), carry);
      out[offset + i | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
      carry = shiftRightUnsigned(value, 30);
      i = i + 1 | 0;
    }
  }
  function trimmed($this, a, offset, length) {
    var size = length;
    while (size > 0 && a[(offset + size | 0) - 1 | 0] === 0) {
      size = size - 1 | 0;
    }
    return size;
  }
  function MagnitudeMultiplication() {
    MagnitudeMultiplication_instance = this;
    this.KARATSUBA_THRESHOLD_1 = 64;
    this.SQUARE_THRESHOLD_1 = 16;
    this.SQUARE_ENTRY_THRESHOLD_1 = 384;
    this.BITS_1 = 30;
    this.MASK_1 = new Long(1073741823, 0);
  }
  protoOf(MagnitudeMultiplication).get_KARATSUBA_THRESHOLD_z8ncb1_k$ = function () {
    return this.KARATSUBA_THRESHOLD_1;
  };
  protoOf(MagnitudeMultiplication).get_SQUARE_THRESHOLD_193f2_k$ = function () {
    return this.SQUARE_THRESHOLD_1;
  };
  protoOf(MagnitudeMultiplication).get_SQUARE_ENTRY_THRESHOLD_ggtpxh_k$ = function () {
    return this.SQUARE_ENTRY_THRESHOLD_1;
  };
  protoOf(MagnitudeMultiplication).checkBitLengths_utqcyw_k$ = function (left, right) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(left);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(right));
    var tmp$ret$1 = subtract(this_1, fromInt(1));
    if (compare(tmp$ret$1, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
  };
  protoOf(MagnitudeMultiplication).multiplyAdaptive_p1t9i2_k$ = function (a, b) {
    return this.multiplyWithSquareEntry_ieywbx_k$(a, b, 384);
  };
  protoOf(MagnitudeMultiplication).multiplyWithSquareEntry_ieywbx_k$ = function (a, b, squareEntryThreshold) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(squareEntryThreshold >= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (a.length >= 16 && a.length < squareEntryThreshold && a === b) {
      var out = new Int32Array(a.length + b.length | 0);
      square(this, a, 0, a.length, out, 0);
      return out;
    }
    return this.multiply$default_72hqo7_k$(a, b);
  };
  protoOf(MagnitudeMultiplication).multiply_lcd45g_k$ = function (a, b, threshold, squareThreshold) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(threshold >= 4 && squareThreshold >= 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var out = new Int32Array(a.length + b.length | 0);
    var tmp0 = a.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b_0 = b.length;
    if (Math.min(tmp0, b_0) < threshold) {
      if (a.length >= squareThreshold && a === b) {
        square(this, a, 0, a.length, out, 0);
      } else {
        school(this, a, 0, a.length, b, 0, b.length, out, 0);
      }
    } else {
      var arena = new Arena(this.scratchWords_becgev_k$(a.length, b.length, threshold));
      product(this, a, 0, a.length, b, 0, b.length, out, 0, arena, threshold, squareThreshold);
    }
    return out;
  };
  protoOf(MagnitudeMultiplication).multiply$default_72hqo7_k$ = function (a, b, threshold, squareThreshold, $super) {
    threshold = threshold === VOID ? 64 : threshold;
    squareThreshold = squareThreshold === VOID ? 16 : squareThreshold;
    return $super === VOID ? this.multiply_lcd45g_k$(a, b, threshold, squareThreshold) : $super.multiply_lcd45g_k$.call(this, a, b, threshold, squareThreshold);
  };
  protoOf(MagnitudeMultiplication).scratchWords_becgev_k$ = function (a, b, threshold) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(a >= 0 && b >= 0 && threshold >= 4)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.comparisons.minOf' call
    var small = Math.min(a, b);
    if (small < threshold)
      return 0;
    var tmp;
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$4 = Math.max(a, b);
    var tmp_0 = fromInt(tmp$ret$4);
    // Inline function 'kotlin.Long.times' call
    var this_0 = new Long(2, 0);
    var tmp$ret$5 = multiply(this_0, fromInt(small));
    if (compare(tmp_0, tmp$ret$5) > 0) {
      tmp = small;
    } else {
      // Inline function 'kotlin.comparisons.maxOf' call
      tmp = Math.max(a, b);
    }
    var size = tmp;
    var tmp_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$7 = Math.max(a, b);
    var tmp_2 = fromInt(tmp$ret$7);
    // Inline function 'kotlin.Long.times' call
    var this_1 = new Long(2, 0);
    var tmp$ret$8 = multiply(this_1, fromInt(small));
    if (compare(tmp_2, tmp$ret$8) > 0) {
      // Inline function 'kotlin.Long.times' call
      var this_2 = new Long(2, 0);
      tmp_1 = multiply(this_2, fromInt(small));
    } else {
      tmp_1 = new Long(0, 0);
    }
    var total = tmp_1;
    while (size >= threshold) {
      // Inline function 'kotlin.Long.plus' call
      var this_3 = fromInt(size);
      // Inline function 'kotlin.Long.div' call
      var this_4 = add(this_3, fromInt(1));
      // Inline function 'kotlin.Long.plus' call
      var this_5 = divide(this_4, fromInt(2));
      var tmp$ret$12 = add(this_5, fromInt(1));
      size = convertToInt(tmp$ret$12);
      var tmp_3 = total;
      var tmp0 = new Long(4, 0);
      // Inline function 'kotlin.Long.times' call
      var other = size;
      var tmp$ret$13 = multiply(tmp0, fromInt(other));
      total = add(tmp_3, tmp$ret$13);
    }
    if (compare(total, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    return convertToInt(total);
  };
  protoOf(MagnitudeMultiplication).scratchWords$default_qglv85_k$ = function (a, b, threshold, $super) {
    threshold = threshold === VOID ? 64 : threshold;
    return $super === VOID ? this.scratchWords_becgev_k$(a, b, threshold) : $super.scratchWords_becgev_k$.call(this, a, b, threshold);
  };
  var MagnitudeMultiplication_instance;
  function MagnitudeMultiplication_getInstance() {
    if (MagnitudeMultiplication_instance == null)
      new MagnitudeMultiplication();
    return MagnitudeMultiplication_instance;
  }
  function _get_serialVersionUID__fhggm9_1($this) {
    return $this.serialVersionUID_1;
  }
  function parse_2($this, value) {
    var separator = indexOf(value, _Char___init__impl__6a9atx(32));
    if (!startsWith(value, 'precision=') || separator <= 10 || !startsWith_0(value, 'roundingMode=', separator + 1 | 0)) {
      parse$badFormat();
    }
    var index = 10;
    var negative = charCodeAt(value, index) === _Char___init__impl__6a9atx(45);
    if (negative || charCodeAt(value, index) === _Char___init__impl__6a9atx(43)) {
      index = index + 1 | 0;
    }
    if (index === separator) {
      parse$badFormat();
    }
    var limit = negative ? new Long(-2147483648, 0) : new Long(2147483647, 0);
    var magnitude = new Long(0, 0);
    while (index < separator) {
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      var tmp0_elvis_lhs = digitToIntOrNull(charCodeAt(value, _unary__edvuaz), 10);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        parse$badFormat();
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var digit = tmp;
      // Inline function 'kotlin.Long.times' call
      var this_0 = magnitude;
      // Inline function 'kotlin.Long.plus' call
      var this_1 = multiply(this_0, fromInt(10));
      magnitude = add(this_1, fromInt(digit));
      if (compare(magnitude, limit) > 0) {
        parse$badFormat();
      }
    }
    var tmp_0;
    try {
      tmp_0 = valueOf(substring(value, separator + 14 | 0));
    } catch ($p) {
      var tmp_1;
      if ($p instanceof IllegalArgumentException) {
        var _unused_var__etf5q3 = $p;
        parse$badFormat();
      } else {
        throw $p;
      }
      tmp_0 = tmp_1;
    }
    var rounding = tmp_0;
    var precision = convertToInt(negative ? negate(magnitude) : magnitude);
    return to(precision, rounding);
  }
  function parse$badFormat() {
    throw IllegalArgumentException_init_$Create$('bad string format');
  }
  function readObject_1($this, stream) {
    restoreSerializedFields(stream);
    var restored = $this.roundingMode_1;
    if ($this.precision_1 < 0 || restored == null) {
      invalidSerializedState('Invalid MathContext');
    }
  }
  function readObjectNoData_1($this) {
    invalidSerializedState('Missing MathContext data');
  }
  function MathContext_init_$Init$(setPrecision, $this) {
    MathContext.call($this, setPrecision, RoundingMode_HALF_UP_getInstance());
    return $this;
  }
  function MathContext_init_$Create$(setPrecision) {
    return MathContext_init_$Init$(setPrecision, objectCreate(protoOf(MathContext)));
  }
  function MathContext_init_$Init$_0(parsed, $this) {
    MathContext.call($this, parsed.first, parsed.second);
    return $this;
  }
  function MathContext_init_$Create$_0(parsed) {
    return MathContext_init_$Init$_0(parsed, objectCreate(protoOf(MathContext)));
  }
  function MathContext_init_$Init$_1(value, $this) {
    MathContext_init_$Init$_0(parse_2(Companion_getInstance_4(), value), $this);
    return $this;
  }
  function MathContext_init_$Create$_1(value) {
    return MathContext_init_$Init$_1(value, objectCreate(protoOf(MathContext)));
  }
  function Companion_3() {
    Companion_instance_3 = this;
    this.serialVersionUID_1 = new Long(527827455, 1299129800);
    this.UNLIMITED_1 = new MathContext(0, RoundingMode_HALF_UP_getInstance());
    this.DECIMAL32__1 = new MathContext(7, RoundingMode_HALF_EVEN_getInstance());
    this.DECIMAL64__1 = new MathContext(16, RoundingMode_HALF_EVEN_getInstance());
    this.DECIMAL128__1 = new MathContext(34, RoundingMode_HALF_EVEN_getInstance());
  }
  protoOf(Companion_3).get_UNLIMITED_eshsm0_k$ = function () {
    return this.UNLIMITED_1;
  };
  protoOf(Companion_3).get_DECIMAL32_am61qx_k$ = function () {
    return this.DECIMAL32__1;
  };
  protoOf(Companion_3).get_DECIMAL64_am61oa_k$ = function () {
    return this.DECIMAL64__1;
  };
  protoOf(Companion_3).get_DECIMAL128_q2cq9b_k$ = function () {
    return this.DECIMAL128__1;
  };
  var Companion_instance_3;
  function Companion_getInstance_4() {
    if (Companion_instance_3 == null)
      new Companion_3();
    return Companion_instance_3;
  }
  function MathContext(precision, roundingMode) {
    Companion_getInstance_4();
    this.precision_1 = precision;
    // Inline function 'kotlin.require' call
    if (!(this.precision_1 >= 0)) {
      var message = 'Digits < 0';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    this.roundingMode_1 = roundingMode;
  }
  protoOf(MathContext).get_precision_e8tfsb_k$ = function () {
    return this.precision_1;
  };
  protoOf(MathContext).get_roundingMode_uxzxk0_k$ = function () {
    return this.roundingMode_1;
  };
  protoOf(MathContext).getPrecision_mx243c_k$ = function () {
    return this.precision_1;
  };
  protoOf(MathContext).getRoundingMode_hqao1f_k$ = function () {
    return this.roundingMode_1;
  };
  protoOf(MathContext).equals = function (other) {
    var tmp;
    var tmp_0;
    if (other instanceof MathContext) {
      tmp_0 = this.precision_1 === other.precision_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.roundingMode_1.equals(other.roundingMode_1);
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(MathContext).hashCode = function () {
    return this.precision_1 + imul(this.roundingMode_1.hashCode(), 59) | 0;
  };
  protoOf(MathContext).toString = function () {
    return 'precision=' + this.precision_1 + ' roundingMode=' + this.roundingMode_1.toString();
  };
  function toKroguByte(_this__u8e3s4) {
    var tmp;
    if (_this__u8e3s4 instanceof BigInteger) {
      tmp = _this__u8e3s4.toByte_edm0nx_k$();
    } else {
      if (_this__u8e3s4 instanceof BigDecimal) {
        tmp = _this__u8e3s4.toByte_edm0nx_k$();
      } else {
        tmp = numberToByte(_this__u8e3s4);
      }
    }
    return tmp;
  }
  function toKroguShort(_this__u8e3s4) {
    var tmp;
    if (_this__u8e3s4 instanceof BigInteger) {
      tmp = _this__u8e3s4.toShort_ja8oqn_k$();
    } else {
      if (_this__u8e3s4 instanceof BigDecimal) {
        tmp = _this__u8e3s4.toShort_ja8oqn_k$();
      } else {
        tmp = numberToShort(_this__u8e3s4);
      }
    }
    return tmp;
  }
  function toKroguInt(_this__u8e3s4) {
    var tmp;
    if (_this__u8e3s4 instanceof BigInteger) {
      tmp = _this__u8e3s4.toInt_1tsl84_k$();
    } else {
      if (_this__u8e3s4 instanceof BigDecimal) {
        tmp = _this__u8e3s4.toInt_1tsl84_k$();
      } else {
        tmp = numberToInt(_this__u8e3s4);
      }
    }
    return tmp;
  }
  function toKroguLong(_this__u8e3s4) {
    var tmp;
    if (_this__u8e3s4 instanceof BigInteger) {
      tmp = _this__u8e3s4.toLong_edfucp_k$();
    } else {
      if (_this__u8e3s4 instanceof BigDecimal) {
        tmp = _this__u8e3s4.toLong_edfucp_k$();
      } else {
        tmp = numberToLong(_this__u8e3s4);
      }
    }
    return tmp;
  }
  function toKroguFloat(_this__u8e3s4) {
    var tmp;
    if (_this__u8e3s4 instanceof BigInteger) {
      tmp = _this__u8e3s4.toFloat_jhbgwv_k$();
    } else {
      if (_this__u8e3s4 instanceof BigDecimal) {
        tmp = _this__u8e3s4.toFloat_jhbgwv_k$();
      } else {
        tmp = numberToDouble(_this__u8e3s4);
      }
    }
    return tmp;
  }
  function toKroguDouble(_this__u8e3s4) {
    var tmp;
    if (_this__u8e3s4 instanceof BigInteger) {
      tmp = _this__u8e3s4.toDouble_ygsx0s_k$();
    } else {
      if (_this__u8e3s4 instanceof BigDecimal) {
        tmp = _this__u8e3s4.toDouble_ygsx0s_k$();
      } else {
        tmp = numberToDouble(_this__u8e3s4);
      }
    }
    return tmp;
  }
  function toBigDecimal(_this__u8e3s4, mathContext) {
    var canonical = Companion_getInstance_0().valueOf_6g8uqq_k$(_this__u8e3s4);
    return BigDecimal_init_$Create$_2(canonical.unscaledValue_ga07pa_k$(), canonical.scale_1t1miy_k$(), mathContext);
  }
  function toBigDecimal_0(_this__u8e3s4) {
    return Companion_getInstance_0().valueOf_6g8uqq_k$(_this__u8e3s4);
  }
  function toBigDecimal_1(_this__u8e3s4, mathContext) {
    return BigDecimal_init_$Create$_8(decimalFloatString(_this__u8e3s4), mathContext);
  }
  function toBigInteger(_this__u8e3s4) {
    return Companion_getInstance_2().valueOf_wwtjy2_k$(fromInt(_this__u8e3s4));
  }
  function toBigInteger_0(_this__u8e3s4) {
    return Companion_getInstance_2().valueOf_wwtjy2_k$(_this__u8e3s4);
  }
  function toBigInteger_1(_this__u8e3s4) {
    var tmp = Companion_getInstance_2();
    // Inline function 'kotlin.UInt.toLong' call
    // Inline function 'kotlin.uintToLong' call
    var value = _UInt___get_data__impl__f0vqqw(_this__u8e3s4);
    var tmp$ret$0 = bitwiseAnd(fromInt(value), new Long(-1, 0));
    return tmp.valueOf_wwtjy2_k$(tmp$ret$0);
  }
  function toBigInteger_2(_this__u8e3s4) {
    return BigInteger_init_$Create$_0(ULong__toString_impl_f9au7k(_this__u8e3s4));
  }
  function toBigDecimal_2(_this__u8e3s4) {
    return BigDecimal_init_$Create$_3(_this__u8e3s4);
  }
  function toBigDecimal_3(_this__u8e3s4, mathContext) {
    return BigDecimal_init_$Create$_5(_this__u8e3s4, mathContext);
  }
  function toBigDecimal_4(_this__u8e3s4) {
    return BigDecimal_init_$Create$_4(_this__u8e3s4);
  }
  function toBigDecimal_5(_this__u8e3s4, mathContext) {
    return BigDecimal_init_$Create$_6(_this__u8e3s4, mathContext);
  }
  function toBigDecimal_6(_this__u8e3s4) {
    return BigDecimal_init_$Create$_0(_this__u8e3s4);
  }
  function toBigDecimal_7(_this__u8e3s4, scale, mathContext) {
    scale = scale === VOID ? 0 : scale;
    mathContext = mathContext === VOID ? Companion_getInstance_4().get_UNLIMITED_eshsm0_k$() : mathContext;
    return BigDecimal_init_$Create$_2(_this__u8e3s4, scale, mathContext);
  }
  function toBigDecimal_8(_this__u8e3s4) {
    return BigDecimal_init_$Create$_7(decimalFloatString(_this__u8e3s4));
  }
  function div(_this__u8e3s4, other) {
    return _this__u8e3s4.divide_n9ljnn_k$(other, RoundingMode_HALF_EVEN_getInstance());
  }
  function unaryMinus(_this__u8e3s4) {
    return _this__u8e3s4.negate_hcqk8u_k$();
  }
  function times(_this__u8e3s4, other) {
    return _this__u8e3s4.multiply_9xrhei_k$(other);
  }
  function plus(_this__u8e3s4, other) {
    return _this__u8e3s4.add_gx3ep5_k$(other);
  }
  function minus(_this__u8e3s4, other) {
    return _this__u8e3s4.subtract_7q3n06_k$(other);
  }
  function div_0(_this__u8e3s4, other) {
    return _this__u8e3s4.divide_bsns5t_k$(other);
  }
  function rem(_this__u8e3s4, other) {
    return _this__u8e3s4.remainder_djq7c5_k$(other);
  }
  function unaryPlus(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  function plus_0(_this__u8e3s4, other) {
    return _this__u8e3s4.add_6mp6rt_k$(other);
  }
  function minus_0(_this__u8e3s4, other) {
    return _this__u8e3s4.subtract_2kakx6_k$(other);
  }
  function times_0(_this__u8e3s4, other) {
    return _this__u8e3s4.multiply_k85pbu_k$(other);
  }
  function rem_0(_this__u8e3s4, other) {
    return _this__u8e3s4.remainder_39bzet_k$(other);
  }
  function unaryMinus_0(_this__u8e3s4) {
    return _this__u8e3s4.negate_hcqk8u_k$();
  }
  function unaryPlus_0(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  function inc(_this__u8e3s4) {
    return _this__u8e3s4.add_gx3ep5_k$(Companion_getInstance_2().get_ONE_18jnkz_k$());
  }
  function dec(_this__u8e3s4) {
    return _this__u8e3s4.subtract_7q3n06_k$(Companion_getInstance_2().get_ONE_18jnkz_k$());
  }
  function inc_0(_this__u8e3s4) {
    return _this__u8e3s4.add_6mp6rt_k$(Companion_getInstance_0().get_ONE_18jnkz_k$());
  }
  function dec_0(_this__u8e3s4) {
    return _this__u8e3s4.subtract_2kakx6_k$(Companion_getInstance_0().get_ONE_18jnkz_k$());
  }
  function inv(_this__u8e3s4) {
    return _this__u8e3s4.not_2cb7_k$();
  }
  function shl(_this__u8e3s4, n) {
    return _this__u8e3s4.shiftLeft_qqh5sf_k$(n);
  }
  function shr(_this__u8e3s4, n) {
    return _this__u8e3s4.shiftRight_g7qmqq_k$(n);
  }
  function and(_this__u8e3s4, other) {
    return _this__u8e3s4.and_8ls3xv_k$(other);
  }
  function or(_this__u8e3s4, other) {
    return _this__u8e3s4.or_yhmmu1_k$(other);
  }
  function xor(_this__u8e3s4, other) {
    return _this__u8e3s4.xor_21fdsh_k$(other);
  }
  function asCommonRandom(_this__u8e3s4) {
    return new asCommonRandom$1(_this__u8e3s4);
  }
  function asCommonRandom$1($this_asCommonRandom) {
    this.$this_asCommonRandom_1 = $this_asCommonRandom;
    Random.call(this);
  }
  protoOf(asCommonRandom$1).nextBits_kty4bl_k$ = function (bitCount) {
    if (bitCount === 0)
      return 0;
    var bytes = this.nextBytes_ln07bs_k$(new Int8Array(4));
    var bits = 0;
    var inductionVariable = 0;
    var last = bytes.length;
    while (inductionVariable < last) {
      var byte = bytes[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      bits = bits << 8 | byte & 255;
    }
    return bits >>> (32 - bitCount | 0) | 0;
  };
  protoOf(asCommonRandom$1).nextBytes_ln07bs_k$ = function (array) {
    this.$this_asCommonRandom_1.nextBytes_xsn77s_k$(array);
    return array;
  };
  function rounds($this, certainty) {
    var tmp;
    if (compare(certainty, new Long(0, 0)) <= 0) {
      tmp = 0;
    } else {
      // Inline function 'kotlin.Long.plus' call
      // Inline function 'kotlin.Long.div' call
      var this_0 = add(certainty, fromInt(1));
      var tmp$ret$1 = divide(this_0, fromInt(2));
      tmp = convertToInt(tmp$ret$1);
    }
    return tmp;
  }
  function PrimalityCertainty() {
    PrimalityCertainty_instance = this;
  }
  protoOf(PrimalityCertainty).testRounds_cm9w9t_k$ = function (certainty) {
    return rounds(this, fromInt(certainty));
  };
  protoOf(PrimalityCertainty).generationRounds_whenz7_k$ = function (bitLength, certainty) {
    if (certainty <= 0)
      return 0;
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_0 = bitLength - 1 | 0;
    var selectionBits = 32 - clz32(this_0) | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_1 = fromInt(certainty);
    var tmp$ret$1 = add(this_1, fromInt(selectionBits));
    return rounds(this, tmp$ret$1);
  };
  protoOf(PrimalityCertainty).successorRounds_2crnv1_k$ = function (candidateIndexBits) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = new Long(50, 0);
    return add(this_0, fromInt(candidateIndexBits));
  };
  var PrimalityCertainty_instance;
  function PrimalityCertainty_getInstance() {
    if (PrimalityCertainty_instance == null)
      new PrimalityCertainty();
    return PrimalityCertainty_instance;
  }
  function PrimeSearchLimits() {
    PrimeSearchLimits_instance = this;
    this.MAX_BITS_1 = 500000000;
  }
  protoOf(PrimeSearchLimits).get_MAX_BITS_bmqcye_k$ = function () {
    return this.MAX_BITS_1;
  };
  protoOf(PrimeSearchLimits).checkBitLength_rls9oj_k$ = function (bitLength) {
    if (bitLength > 500000000)
      throw ArithmeticException_init_$Create$('Probable prime size exceeds supported range');
  };
  var PrimeSearchLimits_instance;
  function PrimeSearchLimits_getInstance() {
    if (PrimeSearchLimits_instance == null)
      new PrimeSearchLimits();
    return PrimeSearchLimits_instance;
  }
  function BigInteger_0(bitLength, certainty, rnd) {
    return Companion_getInstance_2().primeValue_w20hnc_k$(bitLength, certainty, rnd);
  }
  function BigInteger_1(numBits, rnd) {
    return Companion_getInstance_2().randomValue_8k6b2q_k$(numBits, rnd);
  }
  var static_init_called;
  function static_init() {
    if (static_init_called)
      return Unit_getInstance();
    static_init_called = true;
    RoundingMode_UP_instance = new RoundingMode('UP', 0);
    RoundingMode_DOWN_instance = new RoundingMode('DOWN', 1);
    RoundingMode_CEILING_instance = new RoundingMode('CEILING', 2);
    RoundingMode_FLOOR_instance = new RoundingMode('FLOOR', 3);
    RoundingMode_HALF_UP_instance = new RoundingMode('HALF_UP', 4);
    RoundingMode_HALF_DOWN_instance = new RoundingMode('HALF_DOWN', 5);
    RoundingMode_HALF_EVEN_instance = new RoundingMode('HALF_EVEN', 6);
    RoundingMode_UNNECESSARY_instance = new RoundingMode('UNNECESSARY', 7);
    if (Companion_instance_4 == null) {
      Companion_getInstance();
      new Companion_4();
    }
  }
  var RoundingMode_UP_instance;
  var RoundingMode_DOWN_instance;
  var RoundingMode_CEILING_instance;
  var RoundingMode_FLOOR_instance;
  var RoundingMode_HALF_UP_instance;
  var RoundingMode_HALF_DOWN_instance;
  var RoundingMode_HALF_EVEN_instance;
  var RoundingMode_UNNECESSARY_instance;
  function Companion_4() {
    Companion_instance_4 = this;
  }
  protoOf(Companion_4).valueOf_t43jdc_k$ = function (rm) {
    var tmp0_elvis_lhs = getOrNull(get_entries(), rm);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('Invalid rounding mode');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_4;
  function Companion_getInstance_5() {
    static_init();
    return Companion_instance_4;
  }
  function values() {
    static_init();
    return [RoundingMode_UP_getInstance(), RoundingMode_DOWN_getInstance(), RoundingMode_CEILING_getInstance(), RoundingMode_FLOOR_getInstance(), RoundingMode_HALF_UP_getInstance(), RoundingMode_HALF_DOWN_getInstance(), RoundingMode_HALF_EVEN_getInstance(), RoundingMode_UNNECESSARY_getInstance()];
  }
  function valueOf(value) {
    static_init();
    switch (value) {
      case 'UP':
        return RoundingMode_UP_getInstance();
      case 'DOWN':
        return RoundingMode_DOWN_getInstance();
      case 'CEILING':
        return RoundingMode_CEILING_getInstance();
      case 'FLOOR':
        return RoundingMode_FLOOR_getInstance();
      case 'HALF_UP':
        return RoundingMode_HALF_UP_getInstance();
      case 'HALF_DOWN':
        return RoundingMode_HALF_DOWN_getInstance();
      case 'HALF_EVEN':
        return RoundingMode_HALF_EVEN_getInstance();
      case 'UNNECESSARY':
        return RoundingMode_UNNECESSARY_getInstance();
      default:
        THROW_IAE('No enum constant io.heapy.krogu.math.RoundingMode.' + value);
        break;
    }
  }
  function get_entries() {
    static_init();
    if ($ENTRIES == null)
      $ENTRIES = enumEntries(values());
    return $ENTRIES;
  }
  var $ENTRIES;
  function RoundingMode(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function RoundingMode_UP_getInstance() {
    static_init();
    return RoundingMode_UP_instance;
  }
  function RoundingMode_DOWN_getInstance() {
    static_init();
    return RoundingMode_DOWN_instance;
  }
  function RoundingMode_CEILING_getInstance() {
    static_init();
    return RoundingMode_CEILING_instance;
  }
  function RoundingMode_FLOOR_getInstance() {
    static_init();
    return RoundingMode_FLOOR_instance;
  }
  function RoundingMode_HALF_UP_getInstance() {
    static_init();
    return RoundingMode_HALF_UP_instance;
  }
  function RoundingMode_HALF_DOWN_getInstance() {
    static_init();
    return RoundingMode_HALF_DOWN_instance;
  }
  function RoundingMode_HALF_EVEN_getInstance() {
    static_init();
    return RoundingMode_HALF_EVEN_instance;
  }
  function RoundingMode_UNNECESSARY_getInstance() {
    static_init();
    return RoundingMode_UNNECESSARY_instance;
  }
  function toBigInteger_3(_this__u8e3s4, radix) {
    // Inline function 'kotlin.require' call
    if (!(2 <= radix ? radix <= 36 : false)) {
      var message = 'radix ' + radix + ' was not in valid range 2..36';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    return BigInteger_init_$Create$_1(_this__u8e3s4, radix);
  }
  function toBigIntegerOrNull(_this__u8e3s4, radix) {
    // Inline function 'kotlin.require' call
    if (!(2 <= radix ? radix <= 36 : false)) {
      var message = 'radix ' + radix + ' was not in valid range 2..36';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    try {
      tmp = BigInteger_init_$Create$_1(_this__u8e3s4, radix);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof NumberFormatException) {
        var _unused_var__etf5q3 = $p;
        tmp_0 = null;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function toBigDecimal_9(_this__u8e3s4) {
    return BigDecimal_init_$Create$_7(_this__u8e3s4);
  }
  function toBigDecimalOrNull(_this__u8e3s4) {
    var tmp;
    try {
      tmp = BigDecimal_init_$Create$_7(_this__u8e3s4);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof NumberFormatException) {
        var _unused_var__etf5q3 = $p;
        tmp_0 = null;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function toBigInteger_4(_this__u8e3s4) {
    return BigInteger_init_$Create$_0(_this__u8e3s4);
  }
  function toBigIntegerOrNull_0(_this__u8e3s4) {
    return toBigIntegerOrNull(_this__u8e3s4, 10);
  }
  function toBigDecimal_10(_this__u8e3s4, mathContext) {
    return BigDecimal_init_$Create$_8(_this__u8e3s4, mathContext);
  }
  function toBigDecimalOrNull_0(_this__u8e3s4, mathContext) {
    var tmp;
    try {
      tmp = BigDecimal_init_$Create$_8(_this__u8e3s4, mathContext);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof NumberFormatException) {
        var _unused_var__etf5q3 = $p;
        tmp_0 = null;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  function MathSerializable() {
  }
  function MathObjectInputStream() {
  }
  function restoreSerializedFields(stream) {
    return Unit_getInstance();
  }
  function invalidSerializedState(message) {
    throw IllegalStateException_init_$Create$(message);
  }
  function restoreSerializedMagnitude(owner, words) {
    return Unit_getInstance();
  }
  function plainStringTooLarge() {
    throw Error_init_$Create$('too large to fit in a String');
  }
  function _get_source__4cuw5s($this) {
    return $this.source_1;
  }
  function PlatformRandom(source) {
    source = source === VOID ? Default_getInstance() : source;
    this.source_1 = source;
  }
  protoOf(PlatformRandom).nextBytes_xsn77s_k$ = function (bytes) {
    this.source_1.nextBytes_ln07bs_k$(bytes);
  };
  function arrayIndexFailure(index, length) {
    throw new ArrayIndexOutOfBoundsException('Index ' + index + ' out of bounds for length ' + length);
  }
  function emptyPowMagnitude() {
    arrayIndexFailure(0, 0);
  }
  function ArrayIndexOutOfBoundsException(message) {
    IndexOutOfBoundsException_init_$Init$(message, this);
    captureStack(this, ArrayIndexOutOfBoundsException);
  }
  //region block: exports
  _.$_$ = _.$_$ || {};
  _.$_$.a = RoundingMode_CEILING_getInstance;
  _.$_$.b = RoundingMode_DOWN_getInstance;
  _.$_$.c = RoundingMode_FLOOR_getInstance;
  _.$_$.d = RoundingMode_HALF_DOWN_getInstance;
  _.$_$.e = RoundingMode_HALF_EVEN_getInstance;
  _.$_$.f = RoundingMode_HALF_UP_getInstance;
  _.$_$.g = RoundingMode_UNNECESSARY_getInstance;
  _.$_$.h = RoundingMode_UP_getInstance;
  _.$_$.i = Companion_getInstance_0;
  _.$_$.j = Companion_getInstance_2;
  _.$_$.k = DecimalDivision581_getInstance;
  _.$_$.l = DecimalPower593_getInstance;
  _.$_$.m = DecimalProduct580_getInstance;
  _.$_$.n = DecimalSquareRoot579_getInstance;
  _.$_$.o = DecimalSum585_getInstance;
  _.$_$.p = DecimalText588_getInstance;
  _.$_$.q = Decimals_getInstance;
  _.$_$.r = MagnitudeLimits_getInstance;
  _.$_$.s = MagnitudeMultiplication_getInstance;
  _.$_$.t = Companion_getInstance_4;
  _.$_$.u = PrimalityCertainty_getInstance;
  _.$_$.v = PrimeSearchLimits_getInstance;
  _.$_$.w = Companion_getInstance_5;
  _.$_$.x = BigDecimal_init_$Create$_1;
  _.$_$.y = BigDecimal_init_$Init$_9;
  _.$_$.z = BigDecimal_init_$Create$_9;
  _.$_$.a1 = BigDecimal_init_$Init$_10;
  _.$_$.b1 = BigDecimal_init_$Create$_10;
  _.$_$.c1 = BigDecimal_init_$Create$_14;
  _.$_$.d1 = BigDecimal_init_$Init$_3;
  _.$_$.e1 = BigDecimal_init_$Create$_3;
  _.$_$.f1 = BigDecimal_init_$Create$_0;
  _.$_$.g1 = BigDecimal_init_$Init$_7;
  _.$_$.h1 = BigDecimal_init_$Create$_7;
  _.$_$.i1 = BigDecimal_init_$Create$_6;
  _.$_$.j1 = BigDecimal_init_$Create$_5;
  _.$_$.k1 = BigDecimal_init_$Create$_4;
  _.$_$.l1 = BigDecimal_init_$Create$_11;
  _.$_$.m1 = BigDecimal_init_$Create$_13;
  _.$_$.n1 = BigDecimal_init_$Create$_2;
  _.$_$.o1 = BigDecimal_init_$Create$_8;
  _.$_$.p1 = BigDecimal_init_$Create$_12;
  _.$_$.q1 = BigInteger_init_$Create$_1;
  _.$_$.r1 = BigInteger_init_$Create$_2;
  _.$_$.s1 = BigInteger_init_$Init$_0;
  _.$_$.t1 = BigInteger_init_$Create$_0;
  _.$_$.u1 = BigInteger_init_$Init$_4;
  _.$_$.v1 = BigInteger_init_$Create$_4;
  _.$_$.w1 = BigInteger_init_$Create$_5;
  _.$_$.x1 = BigInteger_init_$Create$_3;
  _.$_$.y1 = MathContext_init_$Create$;
  _.$_$.z1 = MathContext_init_$Create$_1;
  _.$_$.a2 = BigDecimal;
  _.$_$.b2 = BigInteger_0;
  _.$_$.c2 = BigInteger_1;
  _.$_$.d2 = BigInteger;
  _.$_$.e2 = DecimalKey;
  _.$_$.f2 = Failure;
  _.$_$.g2 = Value;
  _.$_$.h2 = MathContext;
  _.$_$.i2 = QuotientRemainder;
  _.$_$.j2 = get_entries;
  _.$_$.k2 = valueOf;
  _.$_$.l2 = values;
  _.$_$.m2 = and;
  _.$_$.n2 = certifiedDecimalSumSpan585;
  _.$_$.o2 = decimalDoubleString;
  _.$_$.p2 = dec;
  _.$_$.q2 = dec_0;
  _.$_$.r2 = divideExact;
  _.$_$.s2 = div;
  _.$_$.t2 = div_0;
  _.$_$.u2 = inc_0;
  _.$_$.v2 = inc;
  _.$_$.w2 = inv;
  _.$_$.x2 = get_lowestSetBit;
  _.$_$.y2 = materializedDecimalDivision581;
  _.$_$.z2 = materializedDecimalSum585;
  _.$_$.a3 = minus_0;
  _.$_$.b3 = minus;
  _.$_$.c3 = needsRawDecimalProduct580;
  _.$_$.d3 = numericallyEquals;
  _.$_$.e3 = or;
  _.$_$.f3 = plus_0;
  _.$_$.g3 = plus;
  _.$_$.h3 = quotientAndRemainder;
  _.$_$.i3 = quotientAndRemainder_1;
  _.$_$.j3 = quotientAndRemainder_0;
  _.$_$.k3 = rem;
  _.$_$.l3 = rem_0;
  _.$_$.m3 = retainedDecimalText588;
  _.$_$.n3 = roundToPrecision;
  _.$_$.o3 = roundToScale;
  _.$_$.p3 = shl;
  _.$_$.q3 = shr;
  _.$_$.r3 = times_0;
  _.$_$.s3 = times;
  _.$_$.t3 = toBigDecimalOrNull_0;
  _.$_$.u3 = toBigDecimalOrNull;
  _.$_$.v3 = toBigDecimal_9;
  _.$_$.w3 = toBigDecimal_7;
  _.$_$.x3 = toBigDecimal_0;
  _.$_$.y3 = toBigDecimal_2;
  _.$_$.z3 = toBigDecimal_3;
  _.$_$.a4 = toBigDecimal_6;
  _.$_$.b4 = toBigDecimal_8;
  _.$_$.c4 = toBigDecimal_10;
  _.$_$.d4 = toBigDecimal_4;
  _.$_$.e4 = toBigDecimal_5;
  _.$_$.f4 = toBigDecimal_1;
  _.$_$.g4 = toBigDecimal;
  _.$_$.h4 = toBigIntegerExactResult;
  _.$_$.i4 = toBigIntegerOrNull;
  _.$_$.j4 = toBigIntegerOrNull_0;
  _.$_$.k4 = toBigInteger_3;
  _.$_$.l4 = toBigInteger_4;
  _.$_$.m4 = toBigInteger;
  _.$_$.n4 = toBigInteger_0;
  _.$_$.o4 = toBigInteger_2;
  _.$_$.p4 = toBigInteger_1;
  _.$_$.q4 = toDecimalKey;
  _.$_$.r4 = toIntExactResult_0;
  _.$_$.s4 = toIntExactResult;
  _.$_$.t4 = toKroguByte;
  _.$_$.u4 = toKroguDouble;
  _.$_$.v4 = toKroguFloat;
  _.$_$.w4 = toKroguInt;
  _.$_$.x4 = toKroguLong;
  _.$_$.y4 = toKroguShort;
  _.$_$.z4 = toLongExactResult;
  _.$_$.a5 = toLongExactResult_0;
  _.$_$.b5 = unaryMinus_0;
  _.$_$.c5 = unaryMinus;
  _.$_$.d5 = unaryPlus;
  _.$_$.e5 = unaryPlus_0;
  _.$_$.f5 = xor;
  //endregion
  return _;
}));

//# sourceMappingURL=krogu-math.js.map
