# Native529 matched Debug owned graph result

Actual captures: baseline9513 and candidate74191, both exit0. Sixteen original raw dumps and lossless gzip are retained; all captured bytes and312/323 source manifests, executable hashes, argv and immutable build bindings independently checked. The graph is of matched Debug diagnostic artifacts with hookd6d594f; candidate production09e6dc36b3dfaae3878dbe6304b9c9dcaa96735d. This is not automatically a Release performance graph.

## Actual ownership and separately modeled extents

Every phase has an actual GLOBAL_ROOT→NativeGraphRoot529→values Array→256 roots. Non-Unit cohorts contain256 distinct roots. Complete GLOBAL_ROOT/THREAD_ROOT strong reachability is calculated with the carrier removed; numeric ownership follows every recorded traced reference offset and object-array slot. Unresolved references, unexpected associations and incorrect phase/type/root/control contents fail closed. Owned auxiliary ExtraObject records are absent in the observed cohorts.

| Cohort, B/root average | Baseline serialized payload | Candidate serialized payload | Baseline ABI extent model | Candidate ABI extent model |
|---|---:|---:|---:|---:|
| BigInteger small | 20 | 24 | 44 | 32 |
| BigDecimal small | 44 | 36 | 76 | 44 |
| BigInteger wide | 77.5 | 89.5 | 101.5 | 113.5 |
| BigDecimal wide | 101.5 | 125.5 | 133.5 | 157.5 |
| ByteArray0 | 0 | 0 | 16 | 16 |
| ByteArray256 | 256 | 256 | 272 | 272 |
| IntArray64 | 256 | 256 | 272 | 272 |

Small BI removes one magnitude array (2→1 owned objects/root); small BD removes coefficient and magnitude objects (3→1). Compact roots contain no owned magnitude, coefficient wrapper or Long box. Wide BI remains two objects/root and increases modeled extent12 B; wide BD remains three and increases24 B. Wide0..15 suffixes span differing limb counts, so fractional values are cohort averages, not universal exact object sizes.

Serialized payload is exactly dump data. The separately justified pinned Native ABI model adds8 B per ordinary object (TypeInfo instance extent) or16 B per allowed Array/ByteArray/IntArray/LongArray. It includes actual compiler field-layout padding encoded by TypeInfo, but not allocator slot/tail rounding, GC prefixes, metadata, free/reserved pages or fragmentation. Do not call the model total physical retained heap bytes. Native small BI serialized bytes increase4 B while removing an entire array/header; reporting only either column would hide this distinction.

The equal carrier has modeled extent2064 B; the typed marker20 B. Both are excluded from per-root totals. Static/shared objects and class TypeInfo are not charged per root.

## Actual controls and shared cache

Every observed control array has exact raw length0/256/64 and all-zero primitive contents; its data byte count is0/256/256. Both variants therefore independently demonstrate256 B payload contrast and equal modeled headers. This replaces the failed Native GC-total delta method for the stated graph/payload scope, not by changing its thresholds.

Candidate globally roots one helper→LongArray19. All19 actual negative decimal powers are checked directly from dumped bytes. Raw cache cells are152 B; the pinned ABI array extent model is168 B. Associated helper serialized body16 B/model24 B is separate, not incremental cache-only cost versus the pre-cache helper. Allocator overhead remains unmeasured. The shared cache is excluded from per-number graphs.

## Unit image singleton: initial failure retained and resolved narrowly

Initial parser92889 failed before analysis because the default compiled-script cache was not writable. Same source with a task-local cache ran as13868, then failed the strict Unit external-GC-root assertion. Both failures and exact old source are retained. Controls/BI/BD initially passed without a relaxed sharing guard.

The dump does not enumerate every permanent image object as a GC root. Baseline Unit object/type IDs match exact executable symbols _theUnitInstance/_kclass:kotlin.Unit using a single0xee8000 ASLR slide; candidate has its own0x4738000 slide and its own independently reviewed executable/raw/proof hashes. Both Unit objects occupy __DATA_CONST,__const with zero serialized body and no references. File-image headers contain chained fixups; they are not presented as direct live-memory header reads. Pinned runtime permanence-tag semantics are retained separately.

Reviewed correction e5b11818 applies only to phase0, exact kotlin.Unit/type IDs and a hash-bound same-executable/raw image-symbol proof, one singleton, zero body/no refs and owned set exactlyUnit. No other unrooted object gets this exception. Existing raw dumps were reanalysed; no capture was repeated. Baseline51851 and candidate45680 finished exit0 with exclusive Unit ownership0. Independent candidate image proof is in independent-native-candidate-unit-image-proof-review.json.

## Retained failure and artifact limits

Native18398 runtime GC-total slopes remain FAILED_UNVERIFIED (all three original strict checkers exit3), including baseline50k contrast115.34336 B/root below the criterion and below repeat noise. GC.collect is documented to wait; producer frames return before collection. No precise async or allocator failure mechanism is claimed. Native TIME/CHECK audit remains independent and bound to its historical9641 artifact; no old timing is relabelled as current09e.

This result establishes actual matched Debug root/type/field/storage/payload ownership plus an explicitly limited Native ABI extent model. Debug versus Release allocation/layout transfer requires separate actual TypeInfo/reference-offset/field/ABI binding or sufficient Release capture. That proof is not implied by this report. Process RSS and exact native allocator-retained totals are not inferred.

## Inspectable evidence

- native-graph-paired-debug-audit.json: all16 rows, raw/parser SHA, type schemas, counts, modeled extents, controls and build/capture binding.
- native-graph-abi-proof.md and native-graph-abi-provenance.json: pinned bitcode model and extracted exact functions.
- native-graph-{baseline,candidate}-unit-static-inspection.json and independent Unit review: distinct image proofs.
- native-graph-pilot-initial-failures.json, native-graph-infrastructure-92889.log, native-graph-unit-failure-13868.log and native-graph-analyze-before-unit.main.kts: failed attempts retained.
- native-graph-analyze.main.kts e5b11818: reviewed runnable parser. Capture source895b51a1, hook manifest and source reviews are separate.

## Reproduction

Use pinned Kotlin2.4.21/BellSoft25.0.4+9, task-local KOTLIN_MAIN_KTS_COMPILED_SCRIPTS_CACHE_DIR, and a serialized analysis slot. For non-Unit phases, invoke:

```sh
JAVA_HOME=/Users/yoda/.sdkman/candidates/java/25.0.4-librca KOTLIN_MAIN_KTS_COMPILED_SCRIPTS_CACHE_DIR=/Users/yoda/dev/pet/krogu-math/.codex-work/529/native-graph-kts-cache /Users/yoda/.sdkman/candidates/kotlin/2.4.21/bin/kotlinr .codex-work/529/native-graph-analyze.main.kts INPUT.kdump NEW_OUTPUT.json PHASE baseline_OR_candidate
```

Unit phase0 additionally requires reviewed proof file, exact proof SHA and exact executable after the four normal arguments. Existing outputs are never overwritten. The generated analyzer outputs and raw dumps support the ABI calculation below; this retained inline metadata analysis is not standalone tooling.

```sh
python3 - <<'PY'
from pathlib import Path
import hashlib,json
p=Path('.codex-work/529'); rows=[];sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest(); phases=['unit','integer_small','integer_wide','decimal_small','decimal_wide','control_bytes0','control_bytes256','control_ints64']
abi=json.loads((p/'native-graph-abi-provenance.json').read_text())
for item in abi['inputs']:
 assert sha(item['input'])==item['input_sha256'] and sha(item['output'])==item['output_sha256']
allowed_arrays={'kotlin.Array':8,'kotlin.ByteArray':1,'kotlin.IntArray':4,'kotlin.LongArray':8}
for impl in ['baseline','candidate']:
 folder=p/f'native-heap-{impl}-debug-1';summary=json.loads((p/f'logs/native-heap-{impl}-debug-1-summary.json').read_text()); recovery=(folder/'recovery-ledger.txt').read_text()
 for phase,name in enumerate(phases):
  f=folder/f'{phase}-{name}-graph.json';d=json.loads(f.read_text());raw=folder/f'{phase}-{name}.kdump';assert sha(raw)==d['input_sha256'] and d['input_sha256'] in recovery and d['id_size']==8 and d['implementation']==impl
  assert len(d['roots'])==256 and len(set(d['roots']))==(1 if phase==0 else 256)
  extents=[];payload=0
  for item in d['owned_edges']:
   t=d['type_schemas'][item['type']];n=item['serialized_data_bytes'];payload+=n
   if item['array_count'] is not None:
    assert item['type'] in allowed_arrays and t['serialized_instance_or_element_bytes']==allowed_arrays[item['type']]
    assert n==item['array_count']*allowed_arrays[item['type']];extent=n+16
   else:
    assert item['type'] in ['io.heapy.krogu.math.BigInteger','io.heapy.krogu.math.BigDecimal'] and n==t['serialized_instance_or_element_bytes'];extent=n+8
   extents.append(extent)
  assert not d['extra_objects']
  cache=d['shared_power_cache'];assert len(cache)==(impl=='candidate')
  if cache:assert cache[0]['all19_values_checked'] and cache[0]['array_count']==19 and cache[0]['logical_payload_bytes']==152
  row={'implementation':impl,'phase':name,'raw_sha256':sha(raw),'parser_output_sha256':sha(f),'root_count':256,'owned_objects':len(extents),'serialized_owned_payload_bytes':payload,'serialized_payload_per_root':payload/256,'modeled_runtime_extent_bytes':sum(extents),'modeled_extent_per_root':sum(extents)/256,'actual_type_schemas':d['type_schemas'],'carrier_extent_bytes':16+256*8,'marker_extent_bytes':d['type_schemas']['bench.NativeGraphRoot529']['serialized_instance_or_element_bytes']+8,'shared_cache':cache,'extra_auxiliary_objects':0}
  rows.append(row);print(impl,name,'objects',len(extents),'payload/root',payload/256,'extent/root',sum(extents)/256,'cache',cache)
controls=[]
for impl in ['baseline','candidate']:
 get=lambda name:next(x for x in rows if x['implementation']==impl and x['phase']==name)
 for column in ['serialized_payload_per_root','modeled_extent_per_root']:
  assert get('control_bytes256')[column]-get('control_bytes0')[column]==256 and get('control_ints64')[column]-get('control_bytes0')[column]==256
 controls.append({'implementation':impl,'actual_primitive_payload_contrast_bytes':256,'modeled_header_equal_contrast_bytes':256})
out={'status':'ACTUAL_NATIVE_DEBUG_OWNERSHIP_PAYLOAD_CONTROLS_AND_SCOPED_ABI_EXTENTS_PASS','source_production':'09e6dc3','diagnostic_hook':'d6d594f','snapshots':16,'rows':rows,'controls':controls,'abi_provenance_sha256':sha(p/'native-graph-abi-provenance.json'),'unit_proof_shas':{impl:sha(p/f'native-graph-{impl}-unit-static-inspection.json') for impl in ['baseline','candidate']},'scope':'Actual matchedDEBUG graph exclusive ownership and primitive payload. Runtime instance extent model adds observed pinnedABI8-byte object/typeptr or16-byte array dataoffset, allowlistedtypes only. NOT exactallocatorresidency/GCprefix/slot/tailrounding/freepages. NoReleasegraphsizeclaim. Sharedcacheandcarrier/markerexcludedperroot. FailedNative18398GCslopesremainFAILED_UNVERIFIED.'}
(p/'native-graph-paired-debug-audit.json').write_text(json.dumps(out,indent=2)+'\n')
PY
```

