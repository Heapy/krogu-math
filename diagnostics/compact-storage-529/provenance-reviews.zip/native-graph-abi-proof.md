# Pinned Kotlin/Native ABI evidence for the task529 dump pilot

Status: READ-ONLY ABI PROOF, not an actual capture or retained-memory acceptance. Full46319 is live; no shared hook was edited or compiler/benchmark launched. The proof reads the locally pinned2.4.21 runtime bitcode instead of assuming that upstream master headers match the compiler.

## Actual pinned inputs

See native-graph-abi-provenance.json for SHA256 of runtime.bc, mm.bc, llvm-dis, selected extracts and compiler fingerprint. Both bitcodes come from /Users/yoda/.konan/kotlin-native-prebuilt-macos-aarch64-2.4.21/konan/targets/macos_arm64/native. They declare arm64-apple-macosx12.0.0, little-endian64-bit target layout. Compiler fingerprint is3c576bff017f719cddeb5fcd46cfa494657d6369cf69f993de297c836c9193. Future capture must additionally prove id_size==8 and bind its exact native executable/toolchain.

This is LLVM disassembly of runtime observability/layout code only, not a numerical implementation or new compilation. Extracts retain full selected function bodies with stable line references and SHA. The independent upstream reference schema remains explicitly not sufficient by itself to bind the pinned ABI.

## What is directly established

| Pinned extract | Direct observation | Reproducible consequence |
|---|---|---|
| native-graph-abi-runtime-extract.ll:3 | ObjHeader type contains one pointer | Header layout agrees with8-byte pointer for this target |
| native-graph-abi-runtime-extract.ll:6 | object-array getter begins data at byte16, loads8-byte refs | Object array elements start at16 |
| native-graph-abi-runtime-extract.ll:15 | array length is loaded as i32 at byte8 | Count is after leading8-byte header |
| native-graph-abi-runtime-extract.ll:21,29,37 | ByteArray/IntArray/LongArray getters begin at byte16 | These supported primitive cohorts all have16-byte data offset |
| native-graph-abi-mm-extract.ll:184–199 | DumpObject loads TypeInfo instance size, subtracts8, serializes data from object+8 | Actual dump object.data.size+8 recovers TypeInfo instance extent including compiler field padding |
| native-graph-abi-mm-extract.ll:208–243 | DumpObjectInfo emits instance size and traced-reference offsets reduced by8 | Dump reference/field offsets are relative to serialized data, not original object pointer |
| native-graph-abi-mm-extract.ll:56–84 | DumpArray reads count at+8, computes alignUp(16,elementSize), emits count*elementSize data | Supported element sizes1/4/8 have data offset16; serialized data contains payload only |

Line references refer to retained extracts, not shifting upstream files. Runtime getter and dumper independently agree on offsets. The actual dump parser must reject incompatible version, ID width, array element sizes or object/array data sizes instead of applying this model blindly.

## Permitted derived totals after the pilot passes

For an actually observed ordinary object, define runtime_instance_extent = serialized_object_data_bytes+8. This equals the TypeInfo instance size recovered by the pinned dumper, including leading type-info header and compiler object-field padding.

For actually observed object arrays or Byte/Int/Long arrays with element sizes8/1/4/8, define runtime_array_extent =16+serialized_element_data_bytes. This is the extent through the last array element, including its runtime header. It does not assert allocator slot rounding. Native LongArray19 consequently has152 raw cell bytes and168 bytes runtime array extent, contingent on actual length/type/schema checks. This value is independently derived from the Native runtime; equal JVM numeric size is coincidental evidence, not its basis.

Sum these extents only over the actual exclusive graph. Report root and shared cache separately, per-value cohort averages and object/array counts, wide-field cost, equal carrier separately. Shared helper is associated metadata, not an incremental cache-only total. The exact primitive control contrast remains256 B because both arrays have equal known header extent.

## Excluded or unresolved costs

Do NOT call the sum exact allocated/live/process heap bytes. The dump does not encode custom allocator cell prefixes, size-class/slack/tail rounding, free/reserved pages, fragmentation or all GC bookkeeping. ExtraObject records are graph metadata without a complete size field; optional runtime auxiliary object costs cannot be fabricated. Non-null associated-object edges fail the initial analyzer until modeled; even null-associated auxiliary records are recorded separately and omitted from ABI-instance totals, explicitly.

No actual system allocator overhead or per-object RSS is measured. The failed post-GC heap-total controls remain failed, and neither the header model nor compiler source proves their precise failure mechanism. Confirmed observations support insufficient resolution/accounting stability; page allocator effects remain a hypothesis unless independently traced.

A Native retained-size result can faithfully present the observed owned graph, serialized payload, this explicitly modeled runtime instance/header extent and excluded allocator costs. Final literal acceptance must judge that stated scope; it cannot imply unavailable exact allocator residency.

## Next finite validation

After full46319 terminal, owner grants the benchmark hook window. Apply/review identical two-file opt-in diagnostic hook on baseline/candidate, source-freeze and build. First capture baseline debug compact529-heap256 once under an owned deadline; inspect actual header/id width/type/debug-field/object offsets/root records and0/256/64 primitive controls. If visible, complete matched candidate8phases and apply the ABI model only after schema/type checks. If runtime header/field layout differs, stop with actual failed pilot; do not use this static proof to override data.

Analyzer SOURCE PASS at d4dfcb43 covers graph/payload visibility only. A narrow reviewed addition may emit modeled extents tied to this ABI provenance; it must preserve separate serialized byte columns, auxiliary-object counts and UNMEASURED allocator-cost fields.

## Reproduction

Use the exact hashed llvm-dis binary in provenance. Each operation is read-only, not compilation:

```sh
/opt/homebrew/opt/llvm/bin/llvm-dis /Users/yoda/.konan/kotlin-native-prebuilt-macos-aarch64-2.4.21/konan/targets/macos_arm64/native/runtime.bc -o -
/opt/homebrew/opt/llvm/bin/llvm-dis /Users/yoda/.konan/kotlin-native-prebuilt-macos-aarch64-2.4.21/konan/targets/macos_arm64/native/mm.bc -o -
```

Select complete functions named in the provenance. Re-check all input/extract SHA values before using the model. No heap dump or runtime execution has yet occurred.

