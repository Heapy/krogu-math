#529 bounded post-fix residual source/cost mapping

Source fade6ce, measured JAR379262e4642beac40aef7a132b8f9346c47a1b08562a274f1269c694ca0ad4d7;33-case JVM campaign97872,1386 rows. Actual raw/graph reviewed by527, not repeated here. No current frozen source edits or new numerical run. This is source mapping, not CPU profiling or final acceptance.

| All-three-pair adverse case | Baseline→candidate ns | Transient B/op | Paired ratios |
| --- | ---: | ---: | --- |
| decimal/metadata | 3.036 → 3.168 | 0 → 0 | 1.467/1.035/1.043 |
| decimal/original527-mc34-divide | 184.585 → 291.203 | 610 → 714 | 1.300/6.080/1.102 |
| decimal/wide-add | 87.690 → 118.801 | 632 → 712 | 1.643/1.395/1.236 |
| decimal/wide-create | 3.705 → 4.445 | 32 → 40 | 1.572/1.276/1.094 |
| decimal/wide-multiply | 880.016 → 1387.700 | 3680 → 3544 | 1.086/1.795/1.063 |
| decimal/wide-round | 282.326 → 326.140 | 1568 → 1368 | 1.155/1.155/1.043 |
| integer/metadata | 3.346 → 5.697 | 0 → 0 | 1.627/1.914/1.084 |
| integer/wide-divide | 154.154 → 251.393 | 296 → 304 | 1.566/1.867/1.097 |
| integer/wide-multiply | 159.843 → 296.590 | 328 → 336 | 2.095/1.669/1.149 |

* Metadata has no hidden BI/magnitude materialization: BigInteger.bitLength compact route reconstructs scalar and counts leading zeros; BigDecimal.storedPrecision uses physical tag/subtype guard then volatile cached Int, computing primitive decimal digits only on cache miss. Both actual metadata rows allocate0B/op. Their measured latency differences are real observations, not evidence of a cheap mistaken array path. Preserve597 subtype bypass and volatile/transient visibility; do not remove safeguards to chase tiny controls.
* Promotion/demotion allocation defects were proportionately fixed. Actual promotion88→64B and demotion56→32B; old adverse evidence remains archived. This is a demonstrated implemented improvement, not a basis to hide remaining costs.
* Wide/wide BI multiply borrows both immutable arrays. Its output object's extra8B matches physical layout; wide divide now avoids the compact input array and has only observed296→304B difference. CPU causes cannot be inferred from byte deltas; preserve all-fork latency adverse values.
* Wide decimal graph/shallow fields differ, and its shared arithmetic may construct several intermediates. Wide-create actual32→40B is one new BD root's shallow layout; graph delta+16 includes both BD and its BI coefficient. Wide multiply/round have LOWER transient bytes despite adverse wall times; labelling those as allocation regressions would be false. Wide-add632→712B remains observed; no exact attribution to a particular field count has been established.
* MC34: both callers now pass captured coefficients once; there is no remaining duplicate pair in divideScaledCoefficients. The initial two compact coefficientSnapshot wrappers are a current general wide-result fallback boundary. Actual inputs require32/33 decimal raises and a34digit coefficient, so the compact scaledLong solver correctly declines; MC7 is not coverage.
* One concrete avoidable NEW input temporary remains: coefficient.multiply(tenPow(raise)) enters BI multiply compact×wide and materializeMagnitude creates one base2^30 input array (actual coefficients12345..13845 fit one limb). Baseline already stores that array in its coefficient. A direct scalar-limb×borrowed-wide route could avoid this24B temporary while retaining the same bounded radix product/carry and general fallback. This is not proof that all104B difference comes from that path: wrapper/field growth and offsetting intermediate savings also exist. No timing-cause claim.
* Existing one-limb division publishes a remainder through an IntArray in BOTH old and new source. It may be optimized separately, but is not evidence for this new104B difference; avoid broadening this bounded review into every preexisting allocation.

Next action for root/owner: after current frozen portable build terminates, choose a narrow scalar×wide input-array fix if desired under the explicit avoidable-temporary decision; review exact bounds/sign/zero/subtype/alias/range and meaningful one-limb boundary tests before actual focused/final artifact gates. Otherwise the remaining general wide-result fallback and layout tradeoffs must be explicitly accepted/documented, never relabelled unavoidable mathematics. Do not promise all-size/JDK parity or initiate a profiling campaign from latency alone.

Final529 acceptance still requires actual portable memory/owned Wasm visibility and complete unfiltered target regressions on settled source. This source review grants neither graph coverage nor task closure.
