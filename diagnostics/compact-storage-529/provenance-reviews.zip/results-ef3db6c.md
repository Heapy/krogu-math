#529 current execution evidence (nonfinal)

Final numerical source: ef3db6c; accepted matched baseline: f8565ca. Focused JVM43095:58 PASS,0fail/error/skip; final-source other-target focused and full unfiltered four-target gates pending. Earlier144 and56 focused gates are historical source checkpoints and are not added to final counts.

Third JVM campaign64286 exited0:1386 TIME rows/33 cases, independent exact raw/source/runtime/graph audit PASS. Per-process seven-sample medians are aggregated across three fresh processes; ranges are preserved. This shared-host diagnostic does not establish universal latency or JDK comparison.22 cases faster in all paired forks; zero slower in all paired forks. Eight pooled latency adverse cases remain mixed across forks. Original adverse campaigns1/2 remain retained.

| Case | Baseline ns/op | Candidate ns/op | Ratio | Baseline B/op | Candidate B/op | Paired latency ratios |
|---|---:|---:|---:|---:|---:|---|
| decimal/accumulator-compact-fresh | 1022.669 | 1038.701 | 1.016 | 1880.50 | 1792.00 | 0.710/1.037/0.866 |
| decimal/add-small | 44.570 | 10.118 | 0.227 | 264.00 | 40.00 | 0.213/0.307/0.191 |
| decimal/create-min | 10.537 | 6.514 | 0.618 | 88.00 | 40.00 | 0.388/0.736/0.653 |
| decimal/create-small | 11.871 | 5.169 | 0.435 | 112.00 | 40.00 | 0.372/0.695/0.325 |
| decimal/divide-context | 161.713 | 57.004 | 0.353 | 410.50 | 45.00 | 0.289/0.299/0.425 |
| decimal/divide-scaled | 49.676 | 23.730 | 0.478 | 273.00 | 64.00 | 0.478/0.469/0.458 |
| decimal/metadata | 4.637 | 4.702 | 1.014 | 0.00 | 0.00 | 1.110/0.951/0.701 |
| decimal/multiply-small | 21.534 | 7.934 | 0.368 | 112.00 | 40.00 | 0.337/0.432/0.572 |
| decimal/original527-mc34-divide | 248.128 | 296.109 | 1.193 | 610.00 | 666.00 | 1.193/1.135/0.957 |
| decimal/parse-rounded | 83.647 | 87.066 | 1.041 | 344.00 | 184.00 | 0.440/1.154/1.592 |
| decimal/parse-small | 113.399 | 86.865 | 0.766 | 216.00 | 184.00 | 0.603/0.777/0.895 |
| decimal/round | 24.075 | 14.867 | 0.618 | 160.00 | 40.00 | 0.690/0.475/0.682 |
| decimal/setScale | 19.776 | 8.528 | 0.431 | 136.00 | 40.00 | 0.497/0.374/0.518 |
| decimal/strip | 29.971 | 11.949 | 0.399 | 328.00 | 40.00 | 0.464/0.338/0.570 |
| decimal/subtract-small | 41.146 | 8.321 | 0.202 | 232.00 | 40.00 | 0.202/0.189/0.214 |
| decimal/wide-add | 141.019 | 95.931 | 0.680 | 632.00 | 664.00 | 0.713/0.692/0.445 |
| decimal/wide-create | 5.950 | 6.324 | 1.063 | 32.00 | 40.00 | 0.969/1.086/0.948 |
| decimal/wide-divide | 3374.329 | 2357.778 | 0.699 | 7533.50 | 6650.50 | 0.923/0.843/0.511 |
| decimal/wide-multiply | 1427.231 | 1304.972 | 0.914 | 3680.00 | 3520.00 | 0.986/0.914/1.135 |
| decimal/wide-round | 567.987 | 321.608 | 0.566 | 1568.00 | 1344.00 | 0.922/0.566/0.507 |
| integer/add-small | 13.627 | 7.274 | 0.534 | 80.00 | 32.00 | 0.534/0.552/0.602 |
| integer/create-min | 6.379 | 3.809 | 0.597 | 56.00 | 32.00 | 0.647/0.520/0.597 |
| integer/create-small | 9.199 | 3.634 | 0.395 | 80.00 | 32.00 | 0.490/0.403/0.242 |
| integer/demote | 11.750 | 6.635 | 0.565 | 56.00 | 32.00 | 0.551/0.729/0.872 |
| integer/divide-min-overflow | 14.011 | 8.224 | 0.587 | 56.00 | 64.00 | 0.581/0.929/0.520 |
| integer/metadata | 5.391 | 4.968 | 0.922 | 0.00 | 0.00 | 0.910/1.087/1.251 |
| integer/multiply-small | 14.562 | 8.688 | 0.597 | 80.00 | 32.00 | 0.421/0.653/0.927 |
| integer/parse-small | 76.554 | 83.553 | 1.091 | 136.00 | 128.00 | 1.091/1.058/0.933 |
| integer/promote | 12.223 | 8.773 | 0.718 | 88.00 | 64.00 | 0.685/0.844/0.707 |
| integer/subtract-small | 11.299 | 6.926 | 0.613 | 48.00 | 32.00 | 0.613/0.658/0.926 |
| integer/wide-add | 28.735 | 26.686 | 0.929 | 200.00 | 208.00 | 0.907/1.428/0.875 |
| integer/wide-divide | 223.770 | 250.270 | 1.118 | 296.00 | 304.00 | 0.903/1.380/1.419 |
| integer/wide-multiply | 227.221 | 280.035 | 1.232 | 328.00 | 336.00 | 1.161/0.739/1.232 |

JVM Instrumentation scoped identity-owned graphs: small BigInteger48→32B, fullLong MIN/MAX56→32B; small BigDecimal80→40B, MIN88→40B. Wide BigInteger104→112B and wide BigDecimal136→152B; wide primitive-array shallow size (including its header/alignment) remains80B in this fixture. These are fresh uncached root graphs excluding statics/shared runtime metadata, not total heap, RSS or transient residency.

Portable JVM72608 exited0:6 fresh children,882 TIME rows/486 RETAIN rows/336 representation checks per child. All three strict pair checkers exited0, independently verified. Known256-byte payload contrasts scale around256.4B per root; runtime GC retained-batch slopes remain distinct from exact graphs.

Final portable builds: baseline46986 and candidate69827 exited0, all source309/320 SHA unchanged. Both final27-file trees include bound copied JVM classpaths and final JS/Wasm/Native executables.16 Wasm snapshots captured under72963/77759 exit0, sanitized child environment and lossless raw/gzip recovery hashes. Actual Wasm root/type/field/payload ownership analysis subsequently passed; details below distinguish capture from the ownership proof.

Remaining: three fresh paired JS/Wasm/Native arithmetic+retention campaigns, final unfiltered four-target correctness, complete evidence packaging/independent acceptance/integration. No task closure or final performance claim is made.

Actual WasmGC graph gate subsequently PASS:16 snapshots, strong module-global/carrier ownership,256 distinct numeric roots per numeric phase, external shared metadata and equal2128B carrier excluded. Cohort average exclusive bytes per numeric root: BI small144→72,wide203→219;BDsmall216→80,wide275→299. These are the prepared256-value cohort averages, not universal wide object sizes. ByteArray256−ByteArray0 and IntArray64−ByteArray0 expose exactly256B/root payload contrast. Primitive backing node/type/self_size is visible; primitive element contents/length are not exposed by V8 and are not imputed. Full raw graph proof/report/reproduction is independent-wasm-owned-graph-report.md.
