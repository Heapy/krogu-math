#529 composition map — source-only checkpoint

Frozen529 HEAD17b340222a13bcab2ff856821ba2a8f87b03d85a and539 HEAD72e1aa88fa078abbcf3844a0b746f6410d109b7b remain unchanged. This note records direct source inspection, not compilation, runtime acceptance or measured effects.597 source is still owned by coordinator and must be accepted before composition.537 must integrate before529; both measured artifacts must include identical accepted537/current-main changes.

##597 bounded powers and precision cache

597 `DecimalPowers597` owns immutable exponents0..128, with unchanged general fallback beyond128. Compose its lookup into529 BigInteger.decimalMagnitudeDigits wide branch (currently TEN.pow(lower), line1310), retaining529 primitive decimalDigits before materializeMagnitude. Preserve the maximum-digit proof and one explicit magnitude view per general fallback. Compose597 tenPow lookup after existing small-power table; never interpret128 as a numerical limit.

597 BigDecimal.cachedStoredPrecision597 is volatile/transient and zero-initialized; no constructor/parser cache seeding. In529 storedPrecision (line74), inspect representation directly, without coefficientSnapshot/unscaledValue allocation: physical compact uses storedLong; ordinary wide may use the lazy cache; restored coefficient subtype must retain its original uncached route. Retaining the lazy cache for ordinary compact values is a legitimate option for matching597 repeated-precision behavior and needs final source review. Both baseline/candidate retain the cache field and diagnostics measure its actual alignment/extra-wide cost. Current-format deserialization resets transient cache; copies should not accidentally introduce eager seeding.

##597 compact normalization overlaps529 already

Actual597 BigDecimal.quotientExponent/normalizedComparison now have exact ordinary coefficient-class plus decimalCompactValue guards, primitive prefix/remainder normalization, and legacy MIN/subtype fallback. Frozen529 already has physical-compact branches in the same methods (lines505/517), using CompactInteger529.decimalDigits/compareDecimalSignificands without coefficient wrappers or text. BigInteger529.compareDecimalSignificand (line1318) independently has a primitive branch too.

Therefore do not duplicate597 helpers or replace529 storage branches with allocating coefficient checks. Reconcile accepted597 semantic guards and tests with529 full-MIN physical representation; restored subtype/callback paths remain distinct. The remaining string fallback is not the ordinary compact case. Preserve callback witnesses and negative/MIN normalization controls during delta review. This is source overlap, not measured proof of equal performance or an instruction to widen historical callback shortcuts.

## MC34 remains a separate performance control

Unchanged527 decimal/small/divide uses16 pairs123.45..138.45 /11.37..26.37, MC34 HALF_EVEN. Every pair is nonterminating and final coefficient is wide.529 scalar scaled quotient declines raises32/33 (>18), so general scaled division remains even though its normalization substage is already primitive. Existing529 MC7 probe is not coverage of this MC34 operation. Preserve unchanged527 MC34 alongside MC7, endpoint oracle matrix (including precision34), wide controls and all representation/exception checks. Attribute only529 delta after both artifacts include accepted597 normalization/cache changes; do not promise the residual will disappear.

##535 accumulator ingestion

Current main DecimalAccumulator has ordinary compact probes through unscaledValue().decimalCompactValue at lines51,157–158,167; stored() at176 constructs BI before BD. Under529 these can create avoidable per-term wrappers. Adapt through a narrow internal ordinary-storage helper after the existing observed() snapshot boundary. Keep fullLong physical compactness distinct from historical decimalCompactValue exclusion of MIN; explicitly decide and review MIN eligibility for each535 operation. Keep truthful restored coefficient subtype observations, optional budget checks, failed-add atomicity, exact FINAL_RESULT versus EACH_STEP cohorts, and alias/snapshot behavior.

stored() may publish BigDecimal.valueOf(compact,scale) directly. checkedDigits may read primitive digits for eligible ordinary storage; wide lower-bound budget rejection and public precision behavior must remain. DecimalSignedWork535 expanded conversion can still legitimately materialize coefficients; do not claim529 resolves535 wide page/conversion overhead without matched evidence.

## Ordered composition and gates

1. Preserve frozen commits/manifests and wait accepted597 plus accepted537/current main. Rebase529, dropping duplicate537 source commit while comparing preserved parser/writer hunks.
2. Resolve representation/publication seams,597 cache/power/normalization overlap and535 direct ingestion in separately reviewable changes. Send exact source delta to coordinator/527 before compilation.
3. Fresh matched old/new source-before/after and artifact manifests, explicit jvmJar, full build logs; old/new differ only529.
4. Run prepared compact endpoint/6776 division/current-format serialization/subclass/537 parser fixtures and535 exact/step/atomicity regressions, then full four-target suites under granted queue.
5. Execute reviewed JVM graphs/transient allocations and portable arithmetic/retention controls. Wasm requires actual rooted graph/type/owned-edge and payload coverage; census or RSS alone remains insufficient. Include unchanged MC34, wide-field/cache cost, and ordinary535 ingestion allocations. Preserve all adverse observations.

No source branch was edited and no compiler, numerical probe or SSH command was run for this map.

## Exact review anchors and targeted composition tests

Paths below are relative to their indicated worktree; line numbers describe this read-only checkpoint and will move on rebase.

| Owner/source anchor | Composition obligation |
| --- | --- |
|597 src/commonMain/kotlin/io/heapy/krogu/math/BigDecimal.kt:18–20,51–57 | volatile/transient zero-sentinel precision cache; coefficient-subtype bypass |
|597 BigInteger.kt:1135; BigDecimal.kt:1129; DecimalPowers597.kt:4–17 | bounded immutable power lookup plus unchanged out-of-cache fallback |
|597 BigDecimal.kt:418–478 | quotientExponent and normalizedComparison ordinary-class/MIN gates, positive-prefix/remainder proof (factor at most10^18), legacy callback fallback |
|529 BigDecimal.kt:74–75,505–525 | storage-first precision and existing direct compact normalization; preserve accepted597 semantics while avoiding wrappers/text |
|529 BigInteger.kt:1304–1320 | primitive digits and significands, explicit wide fallback; do not replace with allocating words facade |
|main DecimalAccumulator.kt:51,157–176,182–183 | ordinary compact ingestion/publication after subtype snapshot, wide budget checks and atomicity unchanged |
|597 CompactNormalization597JvmTest.kt:19–40,47–68 | independent text-defined normalized comparison/exponent, publicMC34 coefficient+scale oracle; restored subtype marker identity on BOTH receiver/operand routes |

Targeted regression gate must retain597 coefficient Cartesian matrix (zero, powers of ten, equal prefixes with zero/nonzero suffixes, MAX/MAX−1, MIN, +2^63 and truly wide values), signs and scale pairs0/0, MIN/MAX, MAX/MIN; long scale difference must not narrow before subtraction. The529 full-MIN helper may replace the597 positive-only helper only after checking exact numeric equivalence (including zero) and required callback sequence for restored subtype/MIN. Preserve strict−1/0/+1 public comparison contract.

The597 resolveObject fixture currently serializes a compact1234 BI carrier. Under529 this must use a genuine wide carrier at identical scale, as the earlier reviewed529 fixture adaptations do; then resolve the coefficient to the same truthful subtype and retain all identity/marker assertions. Do not weaken the assertion or force compact values to retain a coefficient just for fixture setup. Add/retain precision-cache roundtrip reset and restored subtype behavior, cached/fallback threshold neighbors127/128/129, fullLong promotion/demotion, and535 positive/negative MIN +overflow +failed-add atomicity/snapshot controls in composed tests. All are planned gates, not executed evidence.
