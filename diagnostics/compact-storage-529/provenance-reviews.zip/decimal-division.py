from pathlib import Path
p=Path('src/commonMain/kotlin/io/heapy/krogu/math/BigDecimal.kt');s=p.read_text()
# Metadata certification doesn't need to publish a coefficient object.
a=s.index('    private fun checkDivisionNormalization(');b=s.index('\n    }',a);t=s[a:b].replace('        val coefficient = coefficientSnapshot()\n        val divisorCoefficient529 = divisor.coefficientSnapshot()\n','').replace('coefficient.signum()', 'storedSign529()').replace('divisorCoefficient529.signum()', 'divisor.storedSign529()');s=s[:a]+t+s[b:]
for name,expr in [('normalizedComparison','CompactInteger529.compareDecimalSignificands(compactValue529(), divisor.compactValue529())'),('quotientExponent','CompactInteger529.decimalDigits(compactValue529()).toLong() - CompactInteger529.decimalDigits(divisor.compactValue529()) +\n                divisor.decimalScale.toLong() - decimalScale - if (CompactInteger529.compareDecimalSignificands(compactValue529(), divisor.compactValue529()) < 0) 1 else 0')]:
 a=s.index('    private fun '+name+'(');i=s.index('        val coefficient =',a);s=s[:i]+'        if (representation == 1 && divisor.representation == 1) return '+expr+'\n'+s[i:]
pos=s.index('    private fun compactQuotient529(')
s=s[:pos]+'''    private fun compactExactQuotient529(divisor: BigDecimal): BigDecimal? {
        if (this::class != BigDecimal::class || divisor::class != BigDecimal::class ||
            representation != 1 || divisor.representation != 1) return null
        val a = compactValue529(); val b = divisor.compactValue529()
        if (a == 0L || b == 0L) return null
        var x = if (a > 0) -a else a
        var y = if (b > 0) -b else b
        while (y != 0L) { val remainder = x % y; x = y; y = remainder }
        // gcd is negative, including MIN. Reject only this optimization's
        // positive2^63 quotient; the general exact path still handles it.
        if (x == -1L && (a == Long.MIN_VALUE || b == Long.MIN_VALUE)) return null
        var numerator = a / x
        var denominator = b / x
        if (denominator < 0) {
            if (numerator == Long.MIN_VALUE || denominator == Long.MIN_VALUE) return null
            numerator = -numerator; denominator = -denominator
        }
        val twos = denominator.countTrailingZeroBits()
        denominator = denominator ushr twos
        var fives = 0
        while (denominator % 5 == 0L) { denominator /= 5; fives++ }
        if (denominator != 1L) return null
        val digits = maxOf(twos, fives)
        repeat(digits - twos) {
            val next = numerator * 2L
            if (!CompactInteger529.multiplyFits(numerator, 2L, next)) return null
            numerator = next
        }
        repeat(digits - fives) {
            val next = numerator * 5L
            if (!CompactInteger529.multiplyFits(numerator, 5L, next)) return null
            numerator = next
        }
        val scale = decimalScale.toLong() - divisor.decimalScale + digits
        if (scale !in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong()) return null
        return BigDecimal(numerator, scale.toInt())
    }

    private fun compactProductEquals529(quotient: BigDecimal, divisor: BigDecimal): Boolean? {
        if (quotient.representation != 1) return null
        val q = quotient.compactValue529(); val d = divisor.compactValue529()
        val product = q * d
        if (!CompactInteger529.multiplyFits(q, d, product)) return null
        val productScale = quotient.decimalScale.toLong() + divisor.decimalScale
        val commonScale = maxOf(decimalScale.toLong(), productScale)
        val left = scaledCompact529(compactValue529(), commonScale - decimalScale) ?: return null
        val right = scaledCompact529(product, commonScale - productScale) ?: return null
        return left == right
    }

'''+s[pos:]
a=s.index('    private fun divideExactly(');i=s.index('        val quotient = exactDivisionCoefficient',a)
s=s[:i]+'''        compactExactQuotient529(divisor)?.let { return it.stripTo(saturatedScale(preferred)) }
'''+s[i:]
a=s.index('    open fun divide(divisor: BigDecimal, mc: MathContext)');b=s.index('\n    }',a);t=s[a:b]
t=t.replace('        val coefficient = coefficientSnapshot()\n','').replace('        val operandCoefficient529 = operand.coefficientSnapshot()\n','')
i=t.index('        val normalized = compareValues(')
t=t[:i]+'''        if (this::class == BigDecimal::class && operand::class == BigDecimal::class &&
            representation == 1 && operand.representation == 1) {
            val exact = compactExactQuotient529(operand)
            if (exact != null && exact.storedPrecision() <= context.precision)
                return exact.stripTo(saturatedScale(preferredScale))
            val normalizedCompact = CompactInteger529.compareDecimalSignificands(compactValue529(), operand.compactValue529())
            val targetCompact = preferredScale + context.precision.toLong() + divisorDigits - sourceDigits -
                if (normalizedCompact > 0) 1 else 0
            if (preferredScale in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong() &&
                targetCompact in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong()) {
                val result = compactQuotient529(operand, targetCompact.toInt(), context.roundingMode)?.roundValue(context)
                if (result != null) {
                    val exactResult = compactProductEquals529(result, operand)
                    if (exactResult != null) return if (exactResult) result.stripTo(preferredScale.toInt()) else result
                }
            }
        }
        val coefficient = coefficientSnapshot()
        val operandCoefficient529 = operand.coefficientSnapshot()
'''+t[i:];s=s[:a]+t+s[b:]
p.write_text(s)
