define zeroext i1 @Kotlin_Debugging_isPermanent(ptr noundef readonly captures(none) %0) local_unnamed_addr #56 personality ptr @__gxx_personality_v0 {
  %2 = load atomic i64, ptr %0 monotonic, align 8
  %3 = and i64 %2, 3
  %4 = icmp eq i64 %3, 1
  ret i1 %4
}
