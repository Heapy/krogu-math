#!/usr/bin/env kotlinr
// SPDX-License-Identifier: Apache-2.0
// Untimed task-owned Native dump capture. Never builds or changes source.
import java.io.File
import java.security.MessageDigest
import java.time.Instant
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

require(args.size == 6) { "executable expectedSHA newOutput baseline|candidate sourceBinding expectedBindingSHA" }
check(KotlinVersion.CURRENT.toString() == "2.4.21")
check(System.getProperty("java.runtime.version") == "25.0.4+9-LTS" && System.getProperty("java.vendor") == "BellSoft")
val executable = File(args[0]).canonicalFile
val expected = args[1]
val output = File(args[2]).canonicalFile
val implementation = args[3].also { require(it in listOf("baseline", "candidate")) }
val sourceBinding = File(args[4]).canonicalFile
val expectedBinding = args[5]
require(executable.isFile && executable.canExecute() && sourceBinding.isFile)
require(expected.matches(Regex("[a-f0-9]{64}")) && expectedBinding.matches(Regex("[a-f0-9]{64}")))
require(output.toPath().startsWith(File("/Users/yoda/dev/pet/krogu-math/.codex-work/529").toPath()) && !output.exists())
check(output.mkdirs())
fun sha(file: File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().use { stream -> val buffer = ByteArray(65536); while (true) { val n = stream.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) } }
    return digest.digest().joinToString("") { "%02x".format(it) }
}
val script = File("/Users/yoda/dev/pet/krogu-math/.codex-work/529/native-graph-capture.main.kts")
val scriptSha = sha(script)
val java = File(System.getProperty("java.home"), "bin/java").canonicalFile
val javaSha = sha(java)
check(sha(executable) == expected && sha(sourceBinding) == expectedBinding)
File(output, "binding-before.txt").writeText("timestamp=${Instant.now()} implementation=$implementation\nexecutable=$executable sha256=$expected\nsourceBinding=$sourceBinding sha256=$expectedBinding\nscript=$script sha256=$scriptSha\ncontrollerJava=$java sha256=$javaSha runtime=${System.getProperty("java.runtime.version")} kotlin=${KotlinVersion.CURRENT}\nchild_deadline_seconds=180 cleanup_seconds=10; controller compilation/hash/compression excluded\n")
fun execute(command: List<String>, log: File, seconds: Long) {
    File(log.path + ".argv.txt").writeText(command.joinToString("\n", postfix = "\n"))
    val builder = ProcessBuilder(command).redirectErrorStream(true).redirectOutput(log)
    builder.environment().clear()
    builder.environment().putAll(mapOf("LANG" to "C", "TZ" to "UTC", "KROGU_NATIVE_GRAPH_OUT" to output.path))
    val child = builder.start()
    var completed = false
    var failure: Throwable? = null
    try {
        File(log.path + ".identity.txt").writeText("pid=${child.pid()} start=${child.toHandle().info().startInstant().orElse(null)}\n")
        completed = child.waitFor(seconds, TimeUnit.SECONDS)
        check(completed) { "Deadline: $log" }
        check(child.exitValue() == 0) { "Child failed: $log exit=${child.exitValue()}" }
    } catch (caught: Throwable) {
        failure = caught
        throw caught
    } finally {
        if (!completed || child.isAlive) {
            var cleanupFailure: Throwable? = null
            fun record(caught: Throwable) {
                if (cleanupFailure == null) cleanupFailure = caught else cleanupFailure!!.addSuppressed(caught)
            }
            val descendants = try { child.toHandle().descendants().toList() }
                catch (caught: Throwable) { record(caught); emptyList() }
            for (handle in descendants.asReversed() + child.toHandle()) {
                try { handle.destroyForcibly() } catch (caught: Throwable) { record(caught) }
            }
            val until = System.nanoTime() + TimeUnit.SECONDS.toNanos(10)
            val capturedInterrupt = Thread.interrupted()
            var interrupted = capturedInterrupt || failure is InterruptedException
            for (handle in descendants + child.toHandle()) {
                while (handle.isAlive && System.nanoTime() < until) {
                    try { handle.onExit().get(maxOf(1L, until - System.nanoTime()), TimeUnit.NANOSECONDS); break }
                    catch (_: InterruptedException) { interrupted = true }
                    catch (_: java.util.concurrent.TimeoutException) { break }
                    catch (caught: Throwable) { record(caught); break }
                }
            }
            val survivors = descendants.filter { it.isAlive }.map { it.pid() }
            if (child.isAlive || survivors.isNotEmpty())
                record(IllegalStateException("Owned cleanup survivors=$survivors rootAlive=${child.isAlive}"))
            if (interrupted) Thread.currentThread().interrupt()
            if (cleanupFailure != null) {
                if (failure != null) failure.addSuppressed(cleanupFailure!!) else throw cleanupFailure!!
            }
        }
    }
}

execute(listOf(executable.path, "compact529-heap", "256"), File(output, "capture.log"), 180)
val phases = listOf("unit", "integer_small", "integer_wide", "decimal_small", "decimal_wide", "control_bytes0", "control_bytes256", "control_ints64")
val expectedFiles = phases.mapIndexed { index, phase -> "$index-$phase.kdump" }.toSet()
check(output.listFiles()!!.filter { it.extension == "kdump" }.map { it.name }.toSet() == expectedFiles)
val recovery = arrayListOf<String>()
for ((index, phase) in phases.withIndex()) {
    val raw = File(output, "$index-$phase.kdump")
    check(raw.length() in 1..134_217_728L)
    raw.inputStream().use { stream ->
        val header = StringBuilder()
        while (true) { val c = stream.read(); check(c >= 0); if (c == 0) break; check(header.length < 64); header.append(c.toChar()) }
        check(header.toString() == "Kotlin/Native dump 1.0.8" && stream.read() in 0..1 && stream.read() == 8)
    }
    val rawSha = sha(raw)
    val compressed = File(output, raw.name + ".gz")
    check(!compressed.exists())
    raw.inputStream().use { from -> GZIPOutputStream(compressed.outputStream()).use { to -> from.copyTo(to) } }
    val digest = MessageDigest.getInstance("SHA-256")
    var expanded = 0L
    GZIPInputStream(compressed.inputStream()).use { stream -> val buffer = ByteArray(65536); while (true) { val n = stream.read(buffer); if (n < 0) break; expanded += n; check(expanded <= 134_217_728); digest.update(buffer, 0, n) } }
    check(expanded == raw.length() && digest.digest().joinToString("") { "%02x".format(it) } == rawSha)
    recovery += "phase=$index name=$phase raw=${raw.name} bytes=${raw.length()} raw_sha256=$rawSha gzip_sha256=${sha(compressed)}"
    File(output, "recovery-ledger.txt").writeText(recovery.joinToString("\n", postfix = "\n"))
    // Keep raw inputs for the separately reviewed parser; cleanup only after graph validation.
}
check(sha(executable) == expected && sha(sourceBinding) == expectedBinding && sha(script) == scriptSha && sha(java) == javaSha)
File(output, "CAPTURED_NOT_YET_OWNERSHIP_VALIDATED").writeText("eight lossless dumps; payload/schema/ownership/header-model audit remains separate\n")
println("PASS captured8 Native dumps; graph validation not yet performed")
