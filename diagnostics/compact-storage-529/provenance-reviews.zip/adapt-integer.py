from pathlib import Path
p=Path('src/commonMain/kotlin/io/heapy/krogu/math/BigInteger.kt'); s=p.read_text()
s=s.replace('open class BigInteger private constructor(private val sign: Int, private val words: IntArray) :', '''open class BigInteger private constructor(
    private val sign: Int,
    private val compactHigh: Int,
    private val compactLow: Int,
    private val representation: Int,
    private val wideWords: IntArray?,
) :''')
a=s.index('    private constructor(value: BigInteger)'); b=s.index('    private fun readObjectNoData()',a)
s=s[:a]+'''    // Compact values retain no magnitude array or boxed Long on any target.
    private constructor(value: Long) : this(
        value.compareTo(0L), (value shr 32).toInt(), value.toInt(), 1, null)
    private constructor(sign: Int, words: IntArray) : this(
        sign,
        if (CompactInteger529.fits(sign, words)) (CompactInteger529.fromMagnitude(sign, words) shr 32).toInt() else 0,
        if (CompactInteger529.fits(sign, words)) CompactInteger529.fromMagnitude(sign, words).toInt() else 0,
        if (CompactInteger529.fits(sign, words)) 1 else 2,
        if (CompactInteger529.fits(sign, words)) null else words,
    )
    private constructor(value: BigInteger) : this(value.sign, value.compactHigh, value.compactLow,
        value.representation, value.wideWords)

    @kotlin.jvm.JvmSynthetic
    internal fun hasCompactStorage529(): Boolean = representation == 1
    @kotlin.jvm.JvmSynthetic
    internal fun compactStoredValue529(): Long = CompactInteger529.value(compactHigh, compactLow)

    // Explicit operation boundary: borrow immutable wide storage; compact callers
    // allocate one scratch view only after their primitive path has declined.
    private fun materializeMagnitude(): IntArray = wideWords ?: CompactInteger529.magnitude(compactHigh, compactLow)

    private fun readObject(stream: MathObjectInputStream) {
        restoreSerializedFields(stream)
        if (sign !in -1..1) invalidSerializedState("Invalid BigInteger sign")
        when (representation) {
            1 -> if (wideWords != null || compactStoredValue529().compareTo(0L) != sign)
                invalidSerializedState("Invalid compact BigInteger")
            2 -> {
                val restored = wideWords ?: invalidSerializedState("Missing BigInteger magnitude")
                if (compactHigh != 0 || compactLow != 0 || sign == 0 || restored.isEmpty() ||
                    restored.any { it < 0 || it.toLong() > MASK } || restored.last() == 0 ||
                    CompactInteger529.fits(sign, restored))
                    invalidSerializedState("Invalid wide BigInteger")
                try { MagnitudeLimits.checkedBitLength(restored.size, restored.last()) }
                catch (_: ArithmeticException) { invalidSerializedState("BigInteger overflow") }
                restoreSerializedMagnitude(this, restored.copyOf())
            }
            else -> invalidSerializedState("Missing BigInteger representation")
        }
    }
''' + s[b:]
# Existing array algorithms take exactly one receiver snapshot. Primitive paths
# below are inserted before these declarations, not hidden inside a property.
methods=['add','subtract','multiply','alignedDecimalSum585','roundedDecimalProduct580','roundedDecimalQuotient581',
'integralDecimalQuotient582','certifiedDecimalResidual583','fixedScaleDecimalQuotient592','certifiedExactLowResidual590',
'pow','gcd','modPow','oddModPowStored','moduloPowerOfTwo','modPowPowerOfTwo','multiplyPowerOfTwo','modInverse',
'sqrtStored','sqrtAndRemainder','shiftLeftValue','shiftRightValue','bitLength','bitCount','lowestSetBitValue',
'firstNonzeroWord','testBitValue','twosComplement','nextProbablePrime','compareTo','magnitudeWord32',
 'toPowerOfTwoString','toInt','toLong','decimalProductLowBits591','decimalCompactValue','decimalMagnitudeDigits',
'compareDecimalSignificand','decimalBinaryPrefix','floatingValue']
import re
for name in methods:
 pat=re.compile(r'^    (?:[^\n]*\bfun )'+re.escape(name)+r'\(',re.M)
 m=pat.search(s)
 if not m: raise Exception(name)
 # Find body opening after balanced parameter list.
 i=s.index('(',m.start()); depth=1;i+=1
 while depth:
  if s[i]=='(':depth+=1
  elif s[i]==')':depth-=1
  i+=1
 j=s.index('{',i)
 # All methods listed have block bodies. Insert only if body actually needs receiver words.
 # Bound by next method, sufficient to identify own field references.
 end=re.search(r'^    (?:private |internal |open |override |@|companion)',s[j+1:],re.M)
 body=s[j+1:j+1+end.start()] if end else s[j+1:]
 if re.search(r'(?<![\w.])words\b',body):
  s=s[:j+1]+'\n        val words = materializeMagnitude()'+s[j+1:]
# Division generic signature isn't matched above.
idx=s.index('    private inline fun <T> selectStoredDivision(');j=s.index(') :',idx) if ') :' in s[idx:s.index('    private fun normalizeStoredDivision',idx)] else -1
# Body begins after select callback type; locate first { on signature.
j=s.index('{',idx);s=s[:j+1]+'\n        val words = materializeMagnitude()'+s[j+1:]
# Explicit named operand views; these uses occur inside one selected operation.
s=s.replace('value.words','value.materializeMagnitude()').replace('operand.words','operand.materializeMagnitude()').replace('other.words','other.materializeMagnitude()')
# Secondary intermediate objects appear only after their local creation.
for name in ['coefficient','quotient','residual','part','a','b','m','base','power','modulus','reduced','next','x','square','longer','shorter','threshold']:
 s=s.replace(name+'.words',name+'.materializeMagnitude()')
s=s.replace('qr[0].words','qr[0].materializeMagnitude()')
# Expression bodies that still referenced the old field.
s=s.replace('BigInteger(-sign, words)','BigInteger(-sign, materializeMagnitude())')
s=s.replace('DecimalPower593.fromMagnitude(sign, words, scale)','DecimalPower593.fromMagnitude(sign, materializeMagnitude(), scale)')
s=s.replace('private fun magnitudeBits(): Int = if (words.isEmpty()) 0 else (words.size - 1) * LIMB_BITS + 32 - words.last().countLeadingZeroBits()', '''private fun magnitudeBits(): Int = if (representation == 1) CompactInteger529.magnitudeBits(compactStoredValue529())
        else (wideWords!!.size - 1) * LIMB_BITS + 32 - wideWords.last().countLeadingZeroBits()''')
s=s.replace('override fun equals(other: Any?): Boolean = other is BigInteger && sign == other.sign && words.contentEquals(other.materializeMagnitude())', '''override fun equals(other: Any?): Boolean = other is BigInteger && sign == other.sign &&
        if (representation == 1) other.representation == 1 && compactHigh == other.compactHigh && compactLow == other.compactLow
        else other.representation == 2 && wideWords!!.contentEquals(other.wideWords!!)''')
a=s.index('            var magnitude = if (value < 0) 0uL');b=s.index('\n        }',a)
s=s[:a]+'            return BigInteger(value)'+s[b:]
p.write_text(s)
