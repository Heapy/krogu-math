#529 independent JS owned graph audit

Status: PASS for the sixteen snapshots from baseline capture 46155 and candidate capture 21234 (both owner-confirmed terminal exit 0). Final analysis 43119 terminated with exit 0, and the heavy slot was released immediately. This evidence is bound to the frozen ef3db6c candidate and accepted537 f8565ca baseline; a later artifact needs explicit composition/layout/cache binding before these figures are carried forward.

The detailed machine ledger is [independent-js-owned-graph-audit.json](independent-js-owned-graph-audit.json). It retains raw/recovered gzip SHA256, actual lexical context/carrier/root paths and node IDs, complete owned strong edges, positive-size node unions, external-sharing exclusions, type/shallow totals and payload controls.

| Fresh cohort | Baseline owned bytes / root | Candidate owned bytes / root | Difference |
| --- | ---: | ---: | ---: |
| Integer small | 264 | 96 | -168 |
| Integer wide | 331.5 | 371.5 | +40 |
| Decimal small | 320 | 96 | -224 |
| Decimal wide | 387.5 | 467.5 | +80 |

These are cohort totals divided by 256, not universal exact sizes of all possible values. The wide cohort mixes sixteen numerical identities and backing sizes/alignment. Every numeric cohort contains 256 distinct fresh objects. The same 2,096-byte carrier Array plus elements backing is excluded and reported separately. Unit has one externally shared singleton referenced 256 times and contributes no exclusive numeric owned bytes.

## What is actually retained

The actual root path runs from snapshot root 0 to the live lexical Context slot named retained529, then to its Array and 256 indexed roots. The numeric roots are not selected from a global type-count difference.

For every phase, the analysis removes the carrier and traverses the complete snapshot through all non-weak edges. It then follows all strong edges from numeric/typed roots, including any positive-size object not otherwise reachable. This accounts for numeric objects, typed-array wrappers, ArrayBuffers, inline array elements backing, native JSArrayBufferData, spilled property storage and any physical number nodes. Prototype/map/static/shared nodes are excluded only when independently strongly reachable without the carrier; zero-size synthetic primitive value nodes do not add physical bytes. No private field or internal property store is silently omitted.

The candidate compact small graphs contain one BigInteger or BigDecimal plus its V8 PropertyArray (56 + 40 = 96 bytes in these snapshots). The PropertyArray is real VM storage for the extra fields, not a magnitude/coefficient array. No retained JS Long box, BigInteger coefficient, typed magnitude array, ArrayBuffer or native backing data is present in those compact graphs. This is an observed retained-graph result for these cohorts, not a claim of allocation-free arithmetic or all-value absence of transient boxes.

Wide values retain the wider field/property-store cost: +40 bytes per integer root and +80 per complete decimal graph. Both short inline typed-array backing nodes and native external backing nodes are counted; the wide cohort averages must not be mistaken for a fixed object size.

JS snapshots expose numeric property kinds but not every scalar or primitive-array value. Source-bound paired CHECK rows separately establish numerical value/scale truth. The graph proves actual object/storage ownership and size, not a new arithmetic oracle.

## Payload controls and the failed runtime delta

ByteArray(0) roots own 200 bytes each. ByteArray(256) and IntArray(64) roots own 456 bytes each, through actual typed array -> ArrayBuffer -> native backing_store edges. The native backing data is 256 bytes in both payload controls. Both observed contrasts are exactly 256 bytes/root in baseline and candidate. The strong carrier-removal analysis proves their exclusivity.

The original JS campaign 23960 remains distinct: all 882 TIME rows and 336 CHECK rows per each of six children have independent arithmetic/binding acceptance; its 486 RETAIN observations remain FAILED/UNVERIFIED. All three combined strict checkers exited 3 at coverage. At 50,000 roots, the first observed payload contrast was only 2.64192 bytes/root with 6,379,008 bytes of spread, far outside the original coverage criterion.

Generated producer code returns after replacing the retained carrier before GC. In the raw memory counters, Unit BEFORE ArrayBuffer accounting remains close to the preceding cohort AFTER while heapUsed drops. That supports stale/delayed external accounting; it does not prove an exact asynchronous mechanism. No assertion was weakened, no arbitrary GC delay was introduced, and the unchanged arithmetic campaign was not rerun. Actual owned snapshots provide the separate retained/object-graph proof required by the task.

The independent JS arithmetic audit retains adverse results: MC34 and rounding are slower in all three pairs in the existing run; other cases vary. Those costs are not hidden by the successful graph evidence.

## Limits and reproduction

This is Node 24.16.0 / V8 13.6.233.17-node.49 snapshot-reported strong-exclusive numeric/storage graph evidence on this host and these cohorts. Shared runtime/class metadata and carrier overhead remain explicit. It is not global heap delta, process RSS, allocator overhead beyond the represented nodes, transient allocated bytes, peak memory or cross-platform object-size parity. All original failed deltas and all baseline/candidate raw snapshots remain retained.

The traversal caps were 4,096 owned positive-size nodes and 16 MiB owned bytes per phase; the largest actual union has 1,792 nodes and no truncation occurred. Sixteen snapshots were read sequentially. The generic closure traverser initially exposed the real PropertyArray cost; an optimistic analysis assertion was corrected to include it, without editing source, data or measurement criteria.

The following verbatim inline analysis command is retained for review/reproduction, not installed as standalone project tooling. Restore the recorded frozen captures and run from the project root. It rewrites only the task-owned analysis ledger; no numerical implementation is involved.

```bash
python3 - <<'PY'
from pathlib import Path
import gzip,json,hashlib,collections
P=Path('.codex-work/529'); phases=['unit','integer_small','integer_wide','decimal_small','decimal_wide','control_bytes0','control_bytes256','control_ints64'];reports=[]
for label in ['baseline','candidate']:
 folder=P/f'js-heap-{label}-1';summary=json.loads((folder/'snapshot-summary.json').read_text());assert summary['node']=='v24.16.0' and summary['rootCount']==256 and [x['phase'] for x in summary['phases']]==phases
 for phase in phases:
  led=next(x for x in summary['phases'] if x['phase']==phase);path=folder/(led['file']+'.gz');compressed=path.read_bytes();raw=gzip.decompress(compressed);assert hashlib.sha256(raw).hexdigest()==led['sha256'] and len(raw)==led['bytes'];D=json.loads(raw);del raw;m=D['snapshot']['meta'];N=D['nodes'];E=D['edges'];S=D['strings'];nf=m['node_fields'];ef=m['edge_fields'];nw=len(nf);ew=len(ef);assert len(N)%nw==0 and len(E)%ew==0;nn=nf.index('name');sz=nf.index('self_size');ec=nf.index('edge_count');nt=nf.index('type');number=len(N)//nw;names=[S[N[i*nw+nn]] for i in range(number)];sizes=[N[i*nw+sz] for i in range(number)];kinds=[m['node_types'][nt][N[i*nw+nt]] for i in range(number)];starts=[];pos=0
  for i in range(number):starts.append(pos);pos+=N[i*nw+ec]*ew
  assert pos==len(E)
  def edges(i):
   for z in range(N[i*nw+ec]):
    k,key,to=E[starts[i]+z*ew:starts[i]+(z+1)*ew];kind=m['edge_types'][0][k];assert to%nw==0 and 0<=to<len(N);yield kind,key if kind in ['element','hidden'] else S[key],to//nw
  pairs=[]
  for i in range(number):
   if names[i]=='system / Context':
    for kind,key,to in edges(i):
     if kind=='context' and key=='retained529':pairs.append((i,to))
  assert len(pairs)==1;context,carrier=pairs[0];assert names[carrier]=='Array';roots={key:to for kind,key,to in edges(carrier) if kind=='element'};assert set(roots)==set(range(256));rootlist=[roots[i] for i in range(256)];expected={'unit':'Unit','integer_small':'BigInteger','integer_wide':'BigInteger','decimal_small':'BigDecimal','decimal_wide':'BigDecimal','control_bytes0':'Int8Array','control_bytes256':'Int8Array','control_ints64':'Int32Array'}[phase];assert all(names[i]==expected for i in rootlist);assert len(set(rootlist))==(1 if phase=='unit' else 256)
  parent={0:None};q=collections.deque([0])
  while q and carrier not in parent:
   i=q.popleft()
   for kind,key,to in edges(i):
    if kind!='weak' and to not in parent:parent[to]=(i,kind,key);q.append(to)
  assert carrier in parent;route=[];at=carrier
  while parent[at] is not None:
   before,kind,key=parent[at];route.append({'from':before,'from_name':names[before],'kind':kind,'edge':key,'to':at,'to_name':names[at]});at=before
  route.reverse();reached={0};q=collections.deque([0])
  while q:
   i=q.popleft()
   for kind,key,to in edges(i):
    if kind!='weak' and to!=carrier and to not in reached:reached.add(to);q.append(to)
  if phase=='unit':assert all(i in reached for i in rootlist)
  else:assert all(i not in reached for i in rootlist)
  owned=set();todo=list(set(rootlist));refs=[];excluded={}
  while todo:
   i=todo.pop()
   if i in owned:continue
   if i in reached:excluded[i]={'node':i,'name':names[i],'kind':kinds[i],'shallow_bytes':sizes[i],'reason':'Strongly reachable from root0 with carrier removed'};continue
   if sizes[i]==0:continue
   owned.add(i);assert len(owned)<=4096 and sum(sizes[j] for j in owned)<=16777216
   for kind,key,to in edges(i):
    if kind=='weak':continue
    refs.append({'from':i,'field':key,'kind':kind,'to':to,'type':names[to],'target_shallow_bytes':sizes[to]});todo.append(to)
  assert not owned&reached
  typesummary={}
  for i in owned:
   key=kinds[i]+'|'+names[i];r=typesummary.setdefault(key,{'count':0,'shallow_bytes':0});r['count']+=1;r['shallow_bytes']+=sizes[i]
  numericnodes=[i for i in owned if names[i] in ['BigInteger','BigDecimal']];assert not any(names[i] in ['Long','Long_0'] for i in owned)
  # Every expected live typed-array root owns its own ArrayBuffer/backing, not a census difference.
  buffers=[i for i in owned if names[i]=='ArrayBuffer'];native=[i for i in owned if names[i]=='system / JSArrayBufferData']
  if phase.startswith('control_'):
   assert len(buffers)==256
   if phase=='control_bytes0':assert not native
   else:assert len(native)==256 and all(sizes[i]==256 for i in native)
  if label=='candidate' and phase in ['integer_small','decimal_small']:
   assert set(names[i] for i in owned)<={expected,'system / PropertyArray'} and sum(names[i]==expected for i in owned)==256;assert not buffers and not native
  backing=[to for kind,key,to in edges(carrier) if key=='elements'];assert len(backing)==1;carrierbytes=sizes[carrier]+sizes[backing[0]]
  fieldsamples=[{'node':i,'type':names[i],'shallow_bytes':sizes[i],'fields':[{'kind':kind,'field':key,'to':to,'type':names[to],'target_kind':kinds[to],'target_shallow_bytes':sizes[to]} for kind,key,to in edges(i)]} for i in rootlist[:2]]
  reports.append({'label':label,'phase':phase,'raw_file':str(path),'raw_sha256':led['sha256'],'gzip_sha256':hashlib.sha256(compressed).hexdigest(),'snapshot_nodes':number,'lexical_context_node':context,'carrier_node':carrier,'carrier_elements_node':backing[0],'carrier_shallow_bytes':carrierbytes,'root_path':route,'root_node_ids':rootlist,'distinct_root_count':len(set(rootlist)),'root_shallow_bytes_each':sorted({sizes[i] for i in rootlist}),'owned_node_ids':sorted(owned),'owned_type_counts_shallow':typesummary,'exclusive_owned_bytes':sum(sizes[i] for i in owned),'owned_bytes_per_root_cohort_average':sum(sizes[i] for i in owned)/256,'storage_and_owned_edges':refs,'shared_excluded_nodes':list(excluded.values()),'field_examples':fieldsamples,'retained_JSLong_box_count':0,'proof':'Starting at observed numeric/typed roots, follow all non-weak edges. Exclude only nodes independently strongly reachable without carrier and zero-size primitive value nodes. Every remaining positive-size node included; no prototype/map/property-array/native backing implicitly omitted.'});print(label,phase,'owned',len(owned),'bytes/root',sum(sizes[i] for i in owned)/256,'types',typesummary)
  del D,N,E,S,reached,parent
controls=[]
for label in ['baseline','candidate']:
 get=lambda phase:next(x for x in reports if x['label']==label and x['phase']==phase)
 zero=get('control_bytes0')['exclusive_owned_bytes'];byte=get('control_bytes256')['exclusive_owned_bytes'];ints=get('control_ints64')['exclusive_owned_bytes'];assert (byte-zero)/256==(ints-zero)/256==256;controls.append({'label':label,'byte256_minus_byte0_payload_contrast':256,'int64_minus_byte0_payload_contrast':256})
result={'status':'INDEPENDENT_JS_OWNED_GRAPH_AND_CONTROLS_PASS_SEPARATE_FROM_FAILED_GC_DELTAS','snapshots':16,'root_count_per_phase':256,'phase_graphs':reports,'payload_controls':controls,'failed_runtime_slopes_status':'23960 RETAIN remains FAILED_UNVERIFIED; no numerical rerun or metric threshold change. Arithmetic/time accepted separately.','scope':'Actual V8 snapshot exclusive owned cohort graphs, with all positive-size dominated objects including typed arrays/ArrayBuffers/native data/property storage. Shared/static metadata and equal carrier excluded by actual strong reachability. Cohort averages not universal object sizes; no heap delta/RSS substitution. JS primitive values not all numerically readable, paired CHECKs establish value truth.'};(P/'independent-js-owned-graph-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('FINAL',result['status'])
PY
```

