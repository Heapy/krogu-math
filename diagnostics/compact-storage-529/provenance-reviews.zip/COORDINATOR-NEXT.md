## Authoritative superseding checkpoint: source 9641a959

Current source: 9641a959a591a3265a24e17ab4250d63959d6c5f. Focused JVM 40677 and other targets 32424 passed 159 methods (60/33/33/33), zero failure/error/skip; 320 source hashes unchanged. Build 60787 exited 0; independent artifact binding verifies 27 candidate and 27 baseline files. Current JAR c655942a6bea80d8e5fe403d662ed969075d4e6a2dac4f993e7a29871f4a3434. JVM cache observer 48330 passed separately: 168 B LongArray shallow, 152 B payload; associated helper 16 B, static metadata excluded.

Final JS campaign 83323 and new candidate JS/Wasm graph analysis are complete as recorded below. Remaining explicit order: unchanged current-source 33-case JVM campaign (six alternating children, 1,386 TIME plus fresh-root graphs); remaining Wasm/Native portable campaigns; final unfiltered four-target regression; canonical report/index and independent acceptance/integration. The mapped final33 gate is retained because common arithmetic helpers changed. Old ef3 timing and graph evidence is historical, never relabelled to 9641.

Latest completed evidence: final JS 83323 exited 0; independent arithmetic audit PASS, nine cases faster in all three pairs and MC34 the sole all-three adverse (pooled 1.617); round pooled 0.841 with mixed forks. New candidate JS/Wasm captures 9567/45869 and independent sixteen-phase owned-graph/cache analysis PASS. Per-number JS small 96 B, wide BI371.5/BD467.5 B; Wasm small BI72/BD80 B, wide BI219/BD299 B. Shared cache separate: JS1072/helper96 B, Wasm232/helper64 B; values opaque where unexposed. Both original and updated failed JS runtime-delta retention methods stay FAILED/UNVERIFIED. Final graph report and metadata clarification are reviewed in independent-9641-report-delta-scope-review.json. Current33 prelaunch binding accepted by reviewer527; await actual terminal rather than infer completion from prelaunch.

The sections below are chronological history, not current execution claims.

# Coordinator current529 checkpoint

Main clean f8565cae98081ff0121ce7a40919d8a4cfd92013;537 DONE, canonical diagnostics/numeric-text-537 report/evidence24files/25SHA, full1988/final2160 accepted. Completed537 worktrees removed normally, branch/evidence retained. Fouropen529/539/598/553; queue529→539→598→553.

529 ownera6bbf558 worker decimal_keys_536. Independent production/sourcecomposition owned coordinator; diagnostics/objectgraph/retention/alloc/raw owned worker benchmarks_527, avoid duplicate review. Candidate accepted537 rebasea291e67 exactsrc/bench/scripts/compactdocs bytes priorreviewedf9b36b5; three duplicate537commits dropped. All320freeze verified. One actual compilation issue54283:K2 nullablemutablelocal lostsmartcast; tiny reviewed inlineElvis explicitIntArray fix f84c007, no arithmetic/allocation/publication change. Focusedretry21049 actual54JVM PASS, JAR757afa1281f6a869f4875a5c46938375a73b9e0fd3bc4f61218e3cc3b0dbddbc,320sourceunchanged. Otherfocused47224 SETUPfailure sandbox ~/.kotlin lock, no tests/no sourcechange; escalatedsamecommand87694 currentlyLIVE JScompile/link. Worker owns polls, no restart/time-based assumption.

Baseline .codex-work/529/baseline detachedexactf8565ca,292trackedsrcbyteidentical acceptedmain; exactly6opt-inbenchmarkharnesspaths copycandidate unchanged, no production/builddelta. Baseline freshartifact pending. Coordinator independent-baseline-harness-review.json PASS,527 independently verified focusedactualJVM/source/JAR and exactbaselineharness. FullphysicalInteger+Decimal scope, allLong bounds/currentserialization/subtypes/Float/concurrency retained. Exactownedgraph/widefieldcost and Wasmownedroot/edge/controlcoverage remain mandatory, noUNVERIFIEDclosure/RSSsubstitution. Full unfiltered4target aftersource settled required, no performance claim fromfocused.

Prospective execution comment2663 underour owned529session authorizes actualmatchedbuilds/diagnostics/allgates after537handoff; noexternalexport grant. External537export was denied, no bypass; futureremotepayload needs actualauthority.

Independent relevant notes: independent-accepted537-rebase-review.json,independent-parser-smartcast-compile-fix.json,independent-baseline-harness-review.json; taskacceptance/commands are worker-owned metadata and mustrefresh actualsource/runtime states.


## Allocation-fix checkpoint

Initial JVM9179 completed1386 rows/33 cases and showed actual adverse promote/demote/MC34/wide-divide. No waiver: four-file source fix fade6ce independently reviewed in independent-allocation-fix-source-review.json. BD passes once-captured coefficient pair; BI creates direct overflow result<=2^64, certifies mixed cancellation with correct65bitfallback, reads compact divisor1..3 words directly into unchanged division-normalization scratch. Common/JVM endpoints, signs/roles, exactnegative65bit−MIN, originaltwo-limbdivisor and allq/r APIs added. No foreign or new division kernel.

Actual focused78721 TERMINAL0:56 JVM methods PASS,320 source hashes unchanged, newcandidate JAR379262… (full hash from owner ledger). Initial focused144 still pertains to earlier source; do not sum it as final four-target acceptance. Samebaseline33-case final pairedcampaign97872 LIVE, outputjvm-paired-2, reviewer527 owns binding/raw/graph audit. Initial raw plus14portableartifacts preserved. Portable retention/Wasm actual coverage and final unfiltered4target suite remain pending; no DONE claim.


## Settled scalar-wide source checkpoint

Exact currentcandidate ef3db6c adds independently reviewed same-schoolRow scalar-wide path;4file hashes/proof in independent-scalar-multiply-source-review.json. New current-source focused43095 TERMINAL0:58 JVM methods PASS,320source unchanged, freshJAR0d8b1d78…cc740 (use exactowner ledger hash, do not infer fullSHA). Final same33case JVM campaign3 nowLIVE64286. Old144focused, later56focused and prior1386 campaigns remain intermediate evidence, not final four-target acceptance. Reviewer527 owns freshJAR/runtime/probe/33case raw/objectgraph; coordinator owns production/contracts and finalserialintegration. Portable21case/9cohortretention/Wasmownedgraph and finalunfiltered4targets remain mandatory. No competingjob bycoordinator.


## Third JVM completed, portable pending

Actual64286 TERMINAL0,1,386 rows/33 cases, all320+309 source SHA unchanged; independent-jvm-third-raw-graph-audit.json PASS from527.22 cases faster in all3pairs,0 slower in all3,8 pooledadverse mixed. MC34 remains610→666B, pairedlatency1.193/1.135/.957; all residuals retained and no causal allocation sum inferred. GraphsmallBI48→32,BD80→40,wide+8/+16 unchanged. Identified avoidable materialization fixes now complete; root explicitly requires no new wide solver/JVM rerun absent newconcern. Candidate finalportablebuild69827 LIVE atlastrootcheckpoint. Next portable21case/retention/actualWasmownedgraph then finalunfiltered4targets onsettledsource; finalreport must distinguish earlier9allforkadversecampaign from latest0. Trackercomment2667 records this actualmilestone,529 stillinprogress.


## Portable JVM and Wasm owned graph evidence now actual

Portable JVM72608 terminal0:6children,882TIME/486RETAIN/336CHECK perchild; three strictchecker exits0. independent-portable-jvm-raw-audit.json PASS,21 ownerstats/controlcoverage exact. It has its own adverse results (fresh535pooled2.715 and MC34all3adverse); do not replace them with favorable direct33case values or combine different protocols as controlledstage effects.

Wasm captures72963/77759 and ownershipanalysis91014/88132 terminal0. Reviewer527 independent-wasm-owned-graph-audit.json verifies16phases,256distinctroots,actualstrongdomination/sharing and256Bpayloadcontrols. Actualownedcohortaverages: BI144→72small,203→219wide;BD216→80small,275→299wide. Carrier2128B excluded. These are cohortaverages, not fixeduniversalobjectsize, and notRSS. Heavyanalysiswindow released toworker536. Remaining pairedJS/Wasm/Native arithmetic/retention, current-source unfiltered4targets, canonicalreport/index/independentacceptance/integration. No sourcechange.


## JS retained metric failure and owned-graph fallback

JS23960 all6 children exited0 but strict retention payloadcontrol FAILED (reported256Bcontrast only2.64B/root at50k with6.38MBspread). Preserve originalraw/status; no unchangedrerun or weakenedassertion. Production source stays ef3db6c. TIME occurs beforeRETAIN and may be independently accepted separately after strictinventory/binding, never combinedcheckerFAIL relabelledPASS.

Literal529 retained/objectgraph requirement is method-agnostic: actual JS ownedBI/BD+typedarray/backing graphs withroot/ownership/payloadcontrols can satisfy it, whileglobaldelta remainsFAILED/UNVERIFIED. Baseline graph39876 terminal0 sourceeligibility PASS independent-js-baseline-graph-eligibility.json: Contextretained529→Array256→numeric roots,typedArray→ArrayBuffer→nativebacking visible;emptycontrol200B versusByte256/Int64control456B givesactual256Bcontrast. Candidate capture/full16phase ownership,sharing,widefieldcost proof stillPENDING; this baselineeligibility alone is notJS memoryacceptance. Reviewer527 owns actualproof; coordinator source/literal review agrees existingfrozencapturemethod route withoutnewnumericimplementation.


## Latest bounded JS cost fix (current source9641a959)

JS23960 arithmetic independentlyPASS but stableadverse round2.222x andMC342.126x required boundedsource review, not paritygate. Exactsourcecause: newroundedCompactPower percallLongpowerloop pluspostroundrepeatedLongdigits; quotientExponent re-counts capturedad/bd. Baseline597compactDigits alsoLong/10loop (do notclaimalloldmetadata cached). OwncompiledJS importsLongops/explicitconstructions confirmed, no foreignstdlibbodyread/noCPUfractionclaim.

Actual4file newtable/digits/reuse source independentPASS in independent-compact-decimal-cost-source-review.json. Oneprivate19negativeLong powers10^0..18 (152logicalpayload, headers/JSLongobjects extra), initializationonlyLongops/noBI/BDrecursion; binarymid1..18/<=5exactcomparisons, zero1/MIN19, noFloat/absMIN. Positivepowerlookup safe, round0/19+ unchanged. ExistingSMALL_BI table stillsamevalueOf sequence/0..18behavior. PrivatecapturedLong/digits reuse preserveshistoricalMIN/coefficient-subtype fallback/publiccallbackorder. Newcommonallpowerneighbors/sign/fullLong tests andJVMallmodes/precisions/carryoracles reviewed.

Latestcommit9641a959 (getfullSHAfromowner) focused40677 LIVE atlastrootcheckpoint; no currentruntimePASSyet. All ef3graphs/campaigns remainretainedsource-specific. NumericBI/BDfieldlayoutunchanged, butnewglobalcachechangesmodulehash/possibleWasmglobalordinal; explicitfinalgraph/layout/cachebinding required, no oldgraph relabel. Reviewer527 owns exactmethod/actualgraphbindings andrawresults; coordinator owns source/literalacceptance/serialintegration. FinalactualJSproof foraffectedcases+controls and finalunfiltered4targets required. No more source reviewunlessactualdelta/failure.

Oldef3JSownedgraphactual16phase PASS, independent-js-owned-graph-audit.json/report.md:smallBI264→96/smallBD320→96;wideBI+40/BD+80; carrier2096excluded; actualtypedarray/ArrayBuffer/nativepayload controls256B; spilledPropertyArrayincluded. Original486JSglobaldeltaRETAIN remainFAILED/UNVERIFIED; arithmetic882TIME/336CHECKperchild separatelyPASS. This graph proof stillhasits originalexactartifact until scopedfinalbindingreview.
