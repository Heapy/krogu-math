# Compact storage and parser publication seam

Agreed with worker benchmarks_527 on 2026-10-16 against reviewed 537 draft f6695e3.

529 owns representation/construction/materialization, primitive arithmetic, and compact branches of the 537 builder/publication/formatter during composition. 537 owns NumericText537, grouped lexical validation/errors and support-bound fallback, and existing wide/power-of-two output algorithms. Preserve those hunks.

ParsedMagnitude537 keeps bits(), multiplyAdd(power, block), publish(sign). It initially holds a negative-domain scalar magnitude (including Long.MIN_VALUE); before a checked multiply-add would exceed that domain it promotes once into owned base-2^30 scratch. Positive 2^63 publishes wide; negative 2^63 publishes compact. publishDecimal(sign, scale) may publish directly into compact decimal fields after the same lexical/rounding validation, avoiding a temporary coefficient object.

Physical immutable compact storage is two Int fields and a nullable wide reference, not a retained JS Long object. materializeMagnitude() explicitly borrows immutable wide storage or constructs one compact scratch view per fallback operation. No allocating computed words property or per-limb materialization. Compact output chooses a primitive branch inside the writer boundary; wide chunk algorithms remain unchanged.

Composed acceptance includes overflow/carry/sign/MIN boundaries, grouped parser/output and current-format serialization/subclass fixtures. No requirement to preserve historical serialized descriptors; current-format validation, detachment, identity/cycles and subclass fields remain required.
