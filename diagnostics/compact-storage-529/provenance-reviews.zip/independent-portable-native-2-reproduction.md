# Current Native2 raw audit reproduction

This reanalyses preserved output only. Failed retained controls remain failed; the accepted Debug heap graph is separate evidence.

```sh
python3 - <<'PY'
from pathlib import Path
import csv,json,hashlib,statistics,math,re
p=Path('.codex-work/529'); platform='native'; d=p/f'portable-{platform}-2'; expected_cases={'integer/create-small','integer/create-min','integer/add-small','integer/multiply-small','integer/wide-add','integer/wide-multiply','integer/wide-divide','decimal/create-small','decimal/create-min','decimal/add-small','decimal/multiply-small','decimal/divide-context','decimal/original527-mc34-divide','decimal/accumulator-compact-fresh','decimal/round','decimal/setScale','decimal/metadata','decimal/wide-create','decimal/wide-add','decimal/wide-multiply','decimal/wide-divide'}; cohorts={'integer/small','integer/min','integer/wide','decimal/small','decimal/min','decimal/wide','control/bytes0','control/bytes256','control/ints64'}; nsizes=[25000,50000,100000]; sampleids=set(range(7)); metric={'jvm':'jvm_total_heap_used_after_gc_request','js':'node_heap_used_and_array_buffers_after_gc','wasm':'wasm_node_heap_coverage_unverified_and_process_rss','native':'native_last_gc_total_objects_size_bytes'}[platform]
assert (d/'EXECUTED_SOURCE_BOUND_NOT_YET_METRICS_VALIDATED').is_file(); checks=[]; timings={}; mem={}; identities=[]; ntime=0; nretain=0
for fork in range(3):
 checker=(d/f'check-{fork}.log').read_text(); assert 'UNVERIFIED retained-payload coverage' in checker
 for variant in ['baseline','candidate']:
  f=d/f'{fork}-{variant}.log'; lines=f.read_text().splitlines(); assert lines[-1]=='PASS compact529'; header=next(l for l in lines if l.startswith('# compact529;')); assert 'warmups=3;samples=7;target_ns=20000000;retained_count=100000' in header
  rr=list(csv.reader(l for l in lines if not l.startswith('#'))); check=[r for r in rr if r[0]=='CHECK']; assert len(check)==336 and {r[1] for r in check}==expected_cases; assert len({(r[1],int(r[2])) for r in check})==336
  for name in expected_cases: assert {int(r[2]) for r in check if r[1]==name}==set(range(16))
  checks.append(check); rows=[r for r in rr if r[0]=='TIME']; assert len(rows)==147; ntime+=len(rows)
  for name in expected_cases:
   group=[r for r in rows if r[1]==name]; assert {int(r[2]) for r in group}==sampleids and len(group)==7; vals=[]; alloc=[]
   for r in group:
    count=int(r[3]); elapsed=int(r[4]); assert count>0 and count<=1048576 and count&(count-1)==0 and 0<elapsed<=180000000000; int(r[6]); vals.append(elapsed/count)
    if platform=='jvm': a=float(r[5]); assert math.isfinite(a) and a>=0; alloc.append(a)
    else: assert r[5]=='NA'
   timings[(variant,fork,name)]={'ns':statistics.median(vals),'bytes':statistics.median(alloc) if alloc else None}
  rows=[r for r in rr if r[0]=='RETAIN']; assert len(rows)==81; nretain+=len(rows); assert len({(r[1],int(r[2]),int(r[3])) for r in rows})==81
  assert {(r[1],int(r[3])) for r in rows}=={(c,n) for c in cohorts for n in nsizes}
  for r in rows:
   assert len(r)==11 and r[4]==metric and int(r[2]) in range(3)
   for v in r[5:]: assert v=='NA' or int(v)>=0
   assert r[5]!='NA' and r[6]!='NA'; heap=int(r[6])-int(r[5]); arrays=(int(r[8])-int(r[7])) if platform=='js' else 0
   mem.setdefault((variant,fork,r[1],int(r[3])),[]).append(heap+arrays)
  identity=(d/f'{fork}-{variant}.log.identity.txt').read_text().strip(); assert re.fullmatch(r'pid=\d+ start=.+',identity); assert 'start=null' not in identity; identities.append(identity)
  argv=(d/f'{fork}-{variant}.log.argv.txt').read_text().splitlines(); assert argv[-5:]==['compact529','3','7','20','100000']; root=(p/('artifacts/portable-baseline-d6d594f' if variant=='baseline' else 'artifacts/portable-candidate-d6d594f')).absolute()
  if platform=='native': assert argv[0]==str(root/'benchmarks.kexe')
  if platform=='jvm':
   assert argv[:5]==['/Users/yoda/.sdkman/candidates/java/25.0.4-librca/bin/java','-Xms256m','-Xmx512m','-XX:+UseG1GC','-cp'] and argv[6]=='bench.MainKt'; expected=[str(root/e) for e in (root/'jvm-classpath.txt').read_text().splitlines()]; assert argv[5].split(':')==expected
assert len(set(identities))==6; assert all(c==checks[0] for c in checks)
summary=[]
for name in sorted(expected_cases):
 a=[timings[('baseline',i,name)] for i in range(3)]; b=[timings[('candidate',i,name)] for i in range(3)]; an=statistics.median(x['ns'] for x in a); bn=statistics.median(x['ns'] for x in b)
 summary.append({'case':name,'baseline_ns':an,'candidate_ns':bn,'ratio':bn/an,'baseline_forks':[x['ns'] for x in a],'candidate_forks':[x['ns'] for x in b],'paired_ratios':[b[i]['ns']/a[i]['ns'] for i in range(3)],'baseline_allocated_bytes':statistics.median(x['bytes'] for x in a) if platform=='jvm' else None,'candidate_allocated_bytes':statistics.median(x['bytes'] for x in b) if platform=='jvm' else None})
retention=[]; coverage=[]
for variant in ['baseline','candidate']:
 for cohort in sorted(cohorts):
  sample=[]
  for fork in range(3):
   medians={n:statistics.median(mem[(variant,fork,cohort,n)]) for n in nsizes}; slope=(medians[100000]-medians[25000])/75000
   sample.append({'fork':fork,'median_deltas':medians,'per_root_runtime_delta_100000':medians[100000]/100000,'growth_slope_25000_to100000':slope,'within_count_ranges':{n:max(mem[(variant,fork,cohort,n)])-min(mem[(variant,fork,cohort,n)]) for n in nsizes}})
  retention.append({'variant':variant,'cohort':cohort,'processes':sample,'median_growth_slope':statistics.median(x['growth_slope_25000_to100000'] for x in sample)})
 for fork in range(3):
  slopes=[]
  for n in [50000,100000]:
   x=mem[(variant,fork,'control/bytes256',n)]; y=mem[(variant,fork,'control/bytes0',n)]; contrast=statistics.median(x)-statistics.median(y); noise=max(max(x)-min(x),max(y)-min(y)); per=contrast/n; slopes.append(per); coverage.append({'variant':variant,'fork':fork,'count':n,'payload_contrast':contrast,'noise':noise,'bytes_per_element_coverage':per,'passes_original_contrast_noise_band':contrast>noise and 128<=per<=512})
  pass # Failed controls remain unverified.

r={'status':'INDEPENDENT_NATIVE_ARITHMETIC_BINDINGS_PASS_RETENTION_FAILED','target':platform,'time_rows':ntime,'retain_rows':nretain,'cases':len(expected_cases),'fresh_processes':6,'equal_full_representation_rows_per_process':336,'process_identities':identities,'timing_summary':summary,'retention_runtime_delta_summary':retention,'coverage_controls':coverage,'all3_faster':[x['case'] for x in summary if all(v<1 for v in x['paired_ratios'])],'all3_slower':[x['case'] for x in summary if all(v>1 for v in x['paired_ratios'])],'pooled_latency_adverse':[x for x in summary if x['ratio']>1],'retention_status':'FAILED_UNVERIFIED_DO_NOT_INFER_RETAINED_BYTES','scope':'Post-GC runtime deltas/slopes are NOT exact per-value owned/retained bytes; Unit-root control removes equal carrier baseline, metadata/cache/heap noise remain. JVM exact root graph separately measured via Instrumentation. Three fresh process pairs, not21 independent replicates. Current shared host; no cross-campaign/platform speed ratios.'}; (p/f'independent-portable-{platform}-2-raw-audit.json').write_text(json.dumps(r,indent=2)+'\n')
print('PASS',ntime,nretain,'all3 faster/slower',len(r['all3_faster']),len(r['all3_slower'])); print('ADVERSE',[(x['case'],round(x['ratio'],3),[round(y,3) for y in x['paired_ratios']]) for x in r['pooled_latency_adverse']]); print('RETENTION',[(x['variant'],x['cohort'],round(x['median_growth_slope'],3)) for x in retention])
PY
```
