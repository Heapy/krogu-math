Current execution ledger (2026-10-16): accepted537 parent f8565ca. Initial focused144 methods belong f84c007/b06947f; intermediate allocation-fix focused56 methods and JVM campaign2 belong fade6ce. Final scalar-wide school-row source is ef3db6c: actual43095 terminal0,58 JVM methods PASS and fresh JAR0d8b1d78a36dd0bf177f0a3f512e97b75dda6ea25ee518e3578e0622934cc740,320 source SHA unchanged. Same-protocol final JVM campaign3 runs under owned64286; no result is claimed before terminal/raw review. Candidate portable builds85948/83310 are preserved pre-final-source artifacts; baseline46986 is accepted537 and reusable with final matching harness. No portable runtime/control/graph result yet. Full unfiltered final-source four-target correctness pending.

# Task529 execution protocol and actual commands

Actual local execution began after accepted537 and independent source-equivalence review; numerical/performance gates below remain pending unless explicitly recorded. Do not run during another owner's numerical work. Read actual source/build outputs before filling final artifact paths.

## Final source basis and binding

Final source rebase completed: candidate a291e6714d5fc8fcf1b9b5355fd5099098d69d97 on accepted537 main f8565cae98081ff0121ce7a40919d8a4cfd92013 (contains accepted597/538/535). The320-file source freeze is accepted537-rebase-source.json; numeric/test/harness bytes are identical to reviewed pre-rebase f9b36b5. Preserve/drop duplicate6176a3b only after comparing its actual537 source hunks with accepted537. Baseline is that exact integrated parent, candidate is parent+529. The earlier9436354/6b1c685/6176a3b drafts are not a valid final paired baseline.

Record exact baseline/candidate commits and patch, clean tracked source status, toolchain versions and the common harness SHA. For BOTH builds:

1. Save SHA256 for every numeric common/platform production source, applicable tests, benchmark sources and build configuration BEFORE build.
2. Explicitly invoke JVM jar packaging, not only jvmTest; retain the entire raw command/build log and all task outcomes. Native/JS/Wasm binaries must likewise come from the recorded linked build tasks.
3. Recompute the source SHA list AFTER build, requiring identical entries. Store actual jar or complete linked module-tree hashes and exact source/commit mapping. Copy the immutable artifact only after verifying its hash against that build record.
4. Use identical529 diagnostic/harness sources in both builds.537 parser source must be identical except for the explicitly reviewed529 compact builder/publication/formatter adaptations. Only529 changes may explain measured differences.

Source binding is an acceptance prerequisite alongside the runner's loaded-origin/hash assertions; a jar hash alone is not source provenance. Outputs belong under `.codex-work/529/logs/` and `.codex-work/529/artifacts/`, never/tmp.

## Focused and full correctness

Run from `.codex-work/529/worktree`, using BellSoft25.0.4+9-LTS and the established2.4.21 Gradle wrapper:

```bash
JAVA_HOME=/Users/yoda/.sdkman/candidates/java/25.0.4-librca ./gradlew --no-daemon :jvmJar :jvmTest --tests '*Compact*529*' --console=plain
JAVA_HOME=/Users/yoda/.sdkman/candidates/java/25.0.4-librca ./gradlew --no-daemon :jsNodeTest --tests '*Compact*529*' :wasmJsNodeTest --tests '*Compact*529*' :macosArm64Test --tests '*Compact*529*' --console=plain
JAVA_HOME=/Users/yoda/.sdkman/candidates/java/25.0.4-librca ./gradlew --no-daemon :jvmTest :jsNodeTest :wasmJsNodeTest :macosArm64Test --console=plain
```

Focused fixture selection intentionally does not replace full unfiltered tests: serialization/subtype/537 writer/parser fixtures must be included in the final full composition. Retain XML/summary/log/source-manifest binding and actual process terminal exit for every gate. Do not restart a live process merely because observation timed out.

## JVM paired diagnostic

After independently reviewed source guards and fresh matched jar builds, run the prepared script with exact immutable paths, SHA256 and a NEW output directory:

```text
JAVA_HOME=<pinned25> <pinned2.4.21>/bin/kotlinr scripts/measure-compact-storage-529.main.kts BASELINE_JAR CANDIDATE_JAR NEW_OUTPUT_DIRECTORY BASELINE_SHA CANDIDATE_SHA
```

The script creates its own identical Java adapter/agent, validates33×16 full results before timing, captures seven exact owned fresh-root graphs, then runs six alternating fresh JVMs. It records child argv and actual pinned G1/heap flags; inherited JVM option variables are sanitized. Compile/setup/graph/checks are outside timed allocation brackets. Preserve all raw logs, adapter source/classes/jar and manifest. Aggregate per-process medians into per-case three-fork ranges; do not mix retained bytes, transient allocation and elapsed time.

## Portable arithmetic/retention

Build the exact same opt-in benchmark harness against baseline and candidate with the existing :benchmarks targets. Use actual linked JVM classpath, JS/Wasm entry module or Native executable from each recorded build. Pass:

```text
compact529 3 7 20 100000
```

Run three fresh processes per implementation/target, alternating old/new order. Node runs require `--expose-gc`; clear inherited NODE_OPTIONS. Compile/startup never enters the timing intervals. The default527 workload inventory is unchanged. Each paired process log is gated by:

```text
<pinned2.4.21>/bin/kotlinr scripts/check-compact-portable-529.main.kts BASELINE_LOG CANDIDATE_LOG 7 100000 TARGET
```

TARGET is jvm/js/wasm/native. The checker validates336 full value/scale input results,21×7 timed rows and81 retained rows. Its known256-byte control criterion validates observable payload coverage only. Retained estimates still need module-owned topology and uncertainty; RSS is not per-value bytes. Case-level small/wide medians/ranges and extra-field/allocation costs remain explicit.

## WasmGC graph capture

For the linked JS/Wasm distribution tree, save SHA256 in the form `sha256  relative/path` for EVERY artifact file, in a manifest outside that tree. Use the same pinned Node executable for both. Run:

```text
<pinned2.4.21>/bin/kotlinr scripts/capture-compact-heap-529.main.kts NODE_BINARY ARTIFACT_DIRECTORY ENTRY_RELATIVE TREE_SHA_MANIFEST NEW_OUTPUT_DIRECTORY baseline
```

Repeat for candidate with its matched tree and label. Eight strictly ordered phases retain256 uncached values/controls. The child gets only nonsecret locale/timezone environment variables. Its capture-only result does not pass graph acceptance. Inspect the actual V8 schema and WasmGC nodes/root paths/field/array edges; separate owned headers/payload/shared metadata and sum the owned graph. Schema-aware census files aid discovery; no global heap delta or missing node can silently become an exact graph. Raw snapshots are retained losslessly as gzip, with raw/recovered/compressed SHA ledgers. If expected nodes/fields are not visible, record NOT_VISIBLE/UNVERIFIED and investigate supported tooling rather than substitute RSS.

## Actual focused invocations

Candidate f84c007 follows accepted537 parent f8565ca; the only change after320-file rebase review is independently reviewed nonnullable parser scratch local. First JVM54283 failed compile before tests; retry21049 passed54 methods and freshjvmJar. Candidate source320SHA unchanged after retry; XML/source/JAR binding is logs/focused-jvm-2-summary.json. No benchmark timing ran in these build/test tasks.

```bash
JAVA_HOME=/Users/yoda/.sdkman/candidates/java/25.0.4-librca ./gradlew --no-daemon :jvmJar :jvmTest --tests '*Compact*529*' --tests '*CompactNormalization597*' --tests '*DecimalMetadata597*' --tests '*DecimalAccumulator535*' --tests '*Text*537*' --tests '*SerializationConformanceTest*' --console=plain
JAVA_HOME=/Users/yoda/.sdkman/candidates/java/25.0.4-librca ./gradlew --no-daemon :jsNodeTest --tests '*Compact*529*' --tests '*DecimalAccumulator535*' --tests '*DecimalMetadata597*' --tests '*Text*537*' :wasmJsNodeTest --tests '*Compact*529*' --tests '*DecimalAccumulator535*' --tests '*DecimalMetadata597*' --tests '*Text*537*' :macosArm64Test --tests '*Compact*529*' --tests '*DecimalAccumulator535*' --tests '*DecimalMetadata597*' --tests '*Text*537*' --console=plain
```

Other-target first47224 failed SETUP only at kotlinWasmToolingSetup due sandbox user-home npm-tooling lock; no tests ran. Same invocation87694 has authorized escalation and is still live at this ledger update, raw logs/focused-other-2.log; do not infer success from startup. No source change or numerical assertion relaxation followed the setup failure.Gradle properties pin4GiB/in-process compiler/maxworkers1; these are build settings, not forthcoming512MiB benchmark child settings.

Matched baseline at .codex-work/529/baseline is detached exactf8565ca production plus SIX byte-identical reviewed benchmark-harness files (baseline-harness-binding.json / baseline-source-before.json). Both independent baseline source reviews PASS; no baseline build/performance result yet.

## Current identity-publication correction09e6dc3

Initial full45317 on9641 exited1 (683 JVMmethods,12 failures; other targets not reached), retained at logs/full-regression-initial-jvm-failure. Reviewed09e correction restores observable fresh publication while retaining public valueOf interning and existing identity exits. Focused84984 exited0,120 JVMmethodsPASS,320SHA unchanged; this is not a sum with historical focused159. Full46319 uses unchanged production09e and the existing unfiltered four-target command above, raw log logs/full-regression-2.log. Keep benchmark hook edits outside this live source freeze.

The current09e JAR is artifacts/candidate-09e6dc3.jar SHA64625bcdbba069763d9da0318dfc143ea9c0a5bcd5e99334744495379d371e37. Fresh matched source/build/artifact ledgers and current same33/21 timing protocols follow final full correctness;9641 timings stay historical. Native18398 terminal0/timeinventory valid, but all3 strict checker exits3 are retained asFAILED_UNVERIFIED, not per-object bytes. No RSS replacement or relaxed control threshold.
