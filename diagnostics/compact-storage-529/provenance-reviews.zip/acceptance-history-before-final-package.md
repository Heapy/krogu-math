# Current settled production09e6dc3: correctness PASS, measurement pending

Full46319 authoritatively exited0 (BUILD SUCCESSFUL9m4s):2055 PASS =684JVM+457JS+457Wasm+457macOS/Native; zero failures/errors/skips. All320 source hashes unchanged. Exact method inventories, XMLarchive hash and source mapping:logs/full-regression-2-summary.json; rawlog/fullXML retained. This independently fixes the observed45317 failures; initial failed log/XML remain preserved and are not weakened.

Current numeric production remains09e6dc36b3dfaae3878dbe6304b9c9dcaa96735d, accepted baselinef8565cae98081ff0121ce7a40919d8a4cfd92013. Current-source timing/allocation evidence remains pending fresh artifacts and matched33/21 protocols. Native retained-size pilot under preparation; all three18398 coverage failures remainFAILED_UNVERIFIED. Only opt-in benchmark hook may now change; full-tested production files stay frozen and need explicit source equivalence to final artifacts.

---

# Current acceptance checkpoint:09e6dc3 (nonfinal)

- Accepted matched baseline:f8565cae98081ff0121ce7a40919d8a4cfd92013. Current candidate:09e6dc36b3dfaae3878dbe6304b9c9dcaa96735d.
- Current identity correction independently SOURCE/boundary PASS. Focused84984 terminal0:120 affected JVMmethodsPASS,0fail/error/skip, all320 source hashes unchanged; fresh JAR64625bcdbba069763d9da0318dfc143ea9c0a5bcd5e99334744495379d371e37. Exact XML/log/source/JAR ledger:logs/identity-fix-jvm-summary.json.
- Full unfiltered four-target suite46319 LIVE; no final correctness PASS yet. Initial45317 on9641 failed12 of683 JVMmethods and did not reach other targets; preservedlogs/full-regression-initial-jvm-failure. Assertions unchanged.
- Completed9641 performance and actual owned graphs remain source-specific:results-9641a95.md contains all108 case rows/ranges/paired adverse. Current09e timings/allocation are NOT established by those old runs. Native retained coverage failed all3 strict checks and remainsFAILED_UNVERIFIED; supported actual heap-dump alternative under preparation by independentreviewer.
- Constructor/physical storage/cache/retention-factory source invariance independentlyPASS for scopedgraphcarryforward; final compiled artifact/layout/factory binding still mandatory. Do not relabel9641 captures as new09e captures.
- Historical sections below retain chronological evidence and are superseded by this checkpoint for current status. No task closure/integration/acceptance yet.

---

Current-source superseding checkpoint: **9641a959a591a3265a24e17ab4250d63959d6c5f**. Focused40677/32424 terminal0: **159 PASS =60JVM+33JS+33Wasm+33macOS**, all zero fail/error/skip and320 source SHA unchanged. Shared-cache observer48330 terminal0:168B JVM LongArray shallow/152B raw value payload; associated INSTANCE16B separately, Classmetadataexcluded. Fresh portable build60787 live. Prior ef3 numerical timings/owned graphs below are accepted historical component evidence, not final9641 timing/graph claims. New candidate JS/Wasm graphs+shared-cache cost and final updated performance remain pending, as does full unfiltered final-source four-target correctness. Matched accepted baseline f8565ca is unchanged. No requirement is waived.

# Task529 acceptance status

Status: IN PROGRESS, not task acceptance. Final numerical source **ef3db6c**; matched accepted parent **f8565cae98081ff0121ce7a40919d8a4cfd92013**. Dedicated tracker a6bbf558 is owned by the coordinator. No source changes during current final-source builds/campaigns.

Actual final-source gates: focused43095 terminal0,58 JVM methods PASS/0fail/error/skip,320 source hashes unchanged. Final JVM33-case campaign64286 terminal0,1386 TIME rows and full result/graph/source/runtime bindings independently PASS;22 cases faster in all3 paired forks,0 slower in all3,8 pooled adverse with mixed forks retained. Portable build69827 terminal0, final27-file candidate and matched baseline trees independently bound. Portable JVM72608 terminal0:6 fresh children,882 TIME/486 RETAIN/336 CHECK per child;3 strict pair checkers and independent raw audit PASS. Wasm captures72963/77759 terminal0 with8 lossless gzip snapshots per implementation; actual ownership/control/sharing analysis independently PASS; graph-gap released. JS arithmetic/TIME campaign23960 executed6 children; its retained-delta control FAILED/UNVERIFIED (three checker exits3), preserved without assertion weakening or timing repeat. Actual baseline JS8-phase graph capture46155 passed capture only, ownership/payload proof pending. Wasm/Native portable campaigns and final unfiltered four-target correctness are UNRUN.

Historical gates are kept separately:54283 compile failure ran no tests;21049 initial54 JVM PASS and87694 initial30/30/30 other-target PASS belong f84/b069;12509 baseline harness facade collision retained. Reviewed fixes and fresh matched baseline build37540 followed. Intermediate fade6ce focused78721 passed56 methods and campaign97872 passed1386 raw rows. These are not added to final ef3db6c correctness counts. Earlier adverse campaigns1/2 and original17b3402/a054554/f9b36b5 refs remain retained. Accepted537 rebase dropped duplicate parser/writer commits with zero numerical-source drift from reviewed composition. Full both-type scope is unchanged.

| Requirement | Evidence | Current status |
|---|---|---|
| Physical compact Integer and Decimal | two primitive Int halves/tag and nullable wide storage; no allocating computed words/coefficient facade | Source PASS; JVM graphs PASS; remaining target evidence pending |
| Full Long range, promotion/demotion | endpoint/MIN/-1/overflow and mixed cancellation fixtures, scalar-wide row signs/carries/all operand roles | Final focused JVM PASS; final other targets/full pending |
| Decimal overflow/rounding/cohorts |6,776-case public-JDK division matrix, scaled controls, exact representation/exception fixtures | Final focused JVM PASS; final common target/full pending |
| Construction/materialization | compact-first537 reader builder, direct exact/finite-context publication, explicit borrowed wide fallback | Independent seam SOURCE PASS; focused JVM PASS; target/full pending |
| Virtual/subtype behavior | MIN signum poison, restored coefficient byte callback identity, exact Float guard/sticky midpoint witnesses | Reviewed and final focused JVM PASS; full target contracts pending |
| Current-format serialization | tag/sign/branch/canonical rejection; detached arrays; subtype cycles/alias/state; truthful wide-carrier resolver fixtures | Final focused JVM PASS; full current-format regression pending |
| JVM owned graph and extra wide fields | fresh uncached roots, Instrumentation shallow/identity-owned graphs;33-case per-thread transient allocation | Independently PASS; small BI48→32B/BD80→40B, wide BI+8B/BD+16B; array shallow80B unchanged including header/alignment |
| Retained memory on target runtimes | Unit-root carrier,9cohorts×3sizes×3replicates; controlled256-byte array payload | JVM runtime-slope control PASS; JS slopes FAILED/UNVERIFIED; actual JS graph path under investigation. Native/Wasm slopes UNRUN; no exact graph/RSS inference |
| Wasm actual graph | source-bound module-global→256-root carrier→numeric fields/backing arrays;16 snapshots+compiled layouts | Actual16-phase graph/global/strong-ownership/control/sharing independent PASS; carrier/shared metadata excluded |
| Small/wide latency on4targets |33-case JVM and21-case portable inventories, same16-input checks,3 fresh alternating pairs | JVM both inventories PASS with all adverse retained; JS time/CHECK raw executed, independent audit pending; JS memory control failure preserved; Wasm/Native UNRUN |
| Full composition/regressions | accepted537+597/535/538 parent, matched baseline, all frozen source/artifact ledgers; unfiltered4targets | Source/binding PASS; final full unfiltered correctness pending |

Retained storage, exact JVM graph bytes, transient allocated bytes and whole-runtime heap/RSS are separate metrics. No claim that every operation is allocation-free or that process RSS equals per-value retained bytes. All actual builds must retain before/after source manifests, clean/dirty source identity, exact commits/patches, fresh explicit JVM jar/package tasks and full logs. Both baseline and candidate must contain identical accepted537 source; only529 changes may be attributed to529.

## Mandatory MC34 control after597 mapping

Preserve the UNCHANGED527 `decimal/small/divide` cohort in final529 performance
acceptance, alongside existing MC7/scale4 diagnostics. Workloads.kt uses
123.45..138.45 divided by11.37..26.37 with MathContext(34, HALF_EVEN),16 identities.
The frozen529 primitive helper declines scaledLong raises>18; these cases require
raise32(firsttwo) or33(remaining) and a wide34digit coefficient. MC7 measurements
must not be relabelled as coverage or a promised fix of this MC34 residual.

Source algebra: coefficients a=12345+100i and b=1137+100i have constantdifference
11208=8*3*467. Each b is odd/notdivisibleby5, and none is an odddivisor1/3/467/1401
of11208. Reduction therefore leaves a denominator factorotherthan2/5, so the
quotients are nonterminating. The final finite34digit cohort is wide; current529
falls back to general materialized division after compact metadata checks. This
is a legitimate general rational fallback, not evidence that its allocations or
latency are optimal. Root routed uncovered597division profiling/ownership to the
coordinator; do not duplicate an implementation or shrink529's fullLong scope.

Both finalbaseline/candidate must include accepted597 threshold/cache changes.
Adapt cache checks directly to representation tag/storedLong before any computed
unscaledValue/materialization, preserve ordinarywide lazycache and restoredsubtype
virtual behavior, and measure the extra transientvolatilecache field on all root
graphs. Ordinary535compact ingestion uses the reviewed directstorage seam rather than constructing a temporary BI just to inspect compactness. The current33-case and21-case inventories both retain the unchanged MC34 control. Third JVM campaign measured610→666B/op with mixed paired latency ratios1.193/1.135/0.957; this is a residual limitation, not a claim that MC7 covers MC34.
