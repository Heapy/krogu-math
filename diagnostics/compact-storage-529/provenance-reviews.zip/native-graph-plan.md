# Native retained-memory proof pilot for task529

Status: SOURCE PREPARATION ONLY; analyzer uncompiled/unrun. Shared hook not edited while owner full46319 is live. Current publication fix09e6dc3 has120 focused methods passing, but full acceptance remains pending. Historical Native TIME data stays bound to9641; failed GC controls stay FAILED_UNVERIFIED.

## Confirmed current failure

Native18398 executes six children,882 TIME and336 CHECK each; independent TIME/binding audit passes in independent-portable-native-raw-audit.json. All three unchanged memory checkers exit3. Baseline first50k payload contrast5767168 B=115.34336 B/root, repeat noise7077888 B; criterion correctly fails. Observations include large negative repeated ByteArray controls and strongly131072-byte-quantized deltas. These are observations, not proof of a particular allocator bug or async GC cause.

The common producer assigns the new global array and returns before measuring. No source-held previous cohort is identified. Pinned2.4.21 stdlib sources confirm GC.collect waits for completion and lastGCInfo describes the last finished run. An unwaited collection is therefore not an established explanation. Heap-total statistics are insufficient for retained per-value proof in this campaign. Do not add arbitrary sleeps, repeat-until-pretty collections or weaker thresholds.

Official reference: [GC.collect](https://kotlinlang.org/api/core/kotlin-stdlib/kotlin.native.runtime/-g-c/collect.html), [memory management](https://kotlinlang.org/docs/native-memory-manager.html). The locally pinned source archive is /Users/yoda/.konan/kotlin-native-prebuilt-macos-aarch64-2.4.21/sources/kotlin-stdlib-native-sources.zip.

## Supported capture and coordinated hook

Pinned nativeMain/kotlin/native/runtime/Debugging.kt declares Debugging.dumpMemory(fd:Long):Boolean. It writes a binary dump to an already-open POSIX descriptor. Actual return/header/schema must be validated; API availability is not a successful capture claim.

Owner536 approved this exact two-file benchmark-only hook plan, but edits are HELD until full46319 terminal and an explicit hook window:

1. Add internal common accessor compactRetainedRoots529():Array<Any> returning checkNotNull(retained529). Existing factories, compact529 timing/RETAIN and compactHeap529 phases unchanged.
2. Native compactSnapshot529 replaces its own private global NativeGraphRoot529(phaseId:Int,values:Array<Any>) before collection. The marker references the current common cohort. Collect after replacement, open a unique O_EXCL file under explicit KROGU_NATIVE_GRAPH_OUT, invoke dumpMemory, require true, close descriptor in finally and preserve primary failures. Never keep the previous marker between replacement and collection.
3. Apply identical hook to candidate and exactaccepted537 baseline benchmark sources, with separate fresh executable/source manifests. No production or timed API edit. No source mutation during builds.

The unique global marker gives an actual GLOBAL_ROOT→NativeGraphRoot529→values Array→256 roots proof, disambiguating the result ring and unrelated arrays. Marker phaseId must match phase. Current benchmark producers return before collection; capture temporaries may still appear in THREAD_ROOT and must be considered by full reachability, not silently dropped.

## Bounded format/schema pilot

Prepared analyzer: native-graph-analyze.main.kts. It is task-owned code, not copied numerical code. Reference runtime-format sources are retained under native-graph-schema with upstream immutable commit/hash provenance. Reference master format is NOT assumed to match pinned runtime until actual capture header/records fully validate.

Reader fails closed on unsupported header/endianness/ID width/tags/flags/types, malformed lengths, unresolved object references, duplicate IDs or missing marker/debug fields. Caps:128MiB input,2M records,1M array elements,4096 owned objects. It records full rawSHA, actual type/field/ref layouts, marker/carrier/root IDs, all owned edges and serialized payload sizes.

Runtime writer and reader are authoritative over draft MemoryDump.md: the draft ARRAY order and THREAD_ROOT order differ from actual writer/reader. Expected actual ARRAY record is id,type,count,dataSize,data. TYPE carries object reference offsets even when optional field names are absent; pilot requires named marker phaseId/values fields to identify the root reliably.

First visibility gate: one baseline debug executable, existing eight phases at count256. Analyze unit, bytes0, bytes256 and representative integer/decimal phases first. Require unique rooted marker, actual256-object array, correct numeric/array types and field links, zero-content primitive controls with actual count0/256/64 and backing byte lengths0/256/256. If any visibility/schema assertion fails, preserve raw and stop; no full candidate capture or memory PASS from census.

Once pilot passes, complete all eight baseline phases and matched candidate phases. Each has unit, small/wide BI, small/wide BD, bytes0/bytes256/ints64. Small/min arithmetic correctness remains in existing CHECK/focused fixtures; these graph cohorts do not claim MIN-specific measured retained bytes.

## Ownership and size boundaries

Starting from all GLOBAL_ROOT and THREAD_ROOT records, compute strong reachability with the observed carrier removed. Follow actual TYPE reference offsets and object-array slots from256 roots. Exclude only independently shared nodes; Unit must remain shared. No census subtraction or GC heap-total/RSS proxy. Any extra-object record with a non-null associated-object edge fails the pilot until those edges are explicitly modeled in both outside and owned traversals.

Important: dump OBJECT/TYPE instance byte arrays omit the leading type-info pointer. ARRAY records contain element payload, omitting ArrayHeader/alignment. The analyzer labels these serialized data bytes, never exact allocator-retained bytes. Actual256B primitive payload contrast can still be demonstrated directly. A separate supported runtime ABI/layout proof is required before adding modeled object/array headers; extra allocator/GC bookkeeping remains explicitly distinct. Do not import JVM/Wasm header sizes or call152 logical cache bytes total Native cost. Final native size conclusions must state measured payload/object counts and any independently justified header model separately.

Shared cache is a separate global helper→LongArray19 graph; its152 raw cell bytes and array length/values should be inspected if exposed, never charged per number or silently omitted. Existing JVM/JS/Wasm cache measurements do not establish Native headers. Wide extra storage fields/counts must remain visible and adverse costs reported.

## Launcher and lifecycle plan

Prepare a .main.kts launcher only after exact hook review. Arguments: frozen executable tree+manifestSHA, new output directory, implementation label, pilot/full mode. Pin executable/source/compiler artifacts before/after, env.clear with LANG=C/TZ=UTC and explicit KROGU_NATIVE_GRAPH_OUT only. Launch compact529-heap256, new PID/start/argv ledger,180s owned deadline,10s bounded cleanup with interruption/primary-error preservation. No process-wide unrelated actions. Size-check outputs, rawSHA before compression, gzip roundtripSHA before any raw deletion; capture status is CAPTURED_NOT_YET_OWNERSHIP_VALIDATED. No timed campaign, no concurrent heavy job.

Next finite step: independent source review of prepared analyzer + exact hook diff after owner window; then compile/parser binding and one baseline visibility pilot under serialized slot. Final publication/source changes invalidate numerical artifact bindings; use accepted final production for the diagnostic build.

