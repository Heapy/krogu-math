# Task529 final remaining actions

Fresh authority: main f8565cae98081ff0121ce7a40919d8a4cfd92013 clean; project active. Four open tasks:529/539 in progress,598/553 todo. Task598 exists with its original full comparison title, todo/blocked, exact dependencies529/537/539 and URL null. Owned529 identity remains a6bbf558; progress comment2693 records actual correctness/memory milestones.

## Substantive acceptance is complete

independent-final-literal-acceptance.md accepts full both-type physical compact scope and all numerical/correctness/measurement obligations. Production09e full46319 passed2055 methods, source/Git correctness transfer is independently checked for298 src paths through d6 diagnostic hook. Final current JVM87962, JS71641, Wasm40973 and Native77132 arithmetic/raw audits all pass with every adverse result retained. Failed JS/Native GC slopes remain FAILED_UNVERIFIED; actual owned graph/storage evidence supplies the separately stated memory scope.

Scoped final compiled JS/Wasm graph applicability is accepted in independent-final-compiled-memory-applicability-review.json, with original9641 snapshots retaining their identities and no fresh final PropertyArray claim. Native matched Debug graph/control/model is accepted; optional Release metadata attempt failed and does not support Release-byte claims or introduce a new mandatory gate.

## Only actually remaining

1. Owner finalizes canonical REPORT/REQUIREMENTS/README/REPRODUCE and lossless ZIP groups/member ledgers/index under worktree/diagnostics/compact-storage-529. Reviewer527 hash-binds final numerical/method wording after the small documented wording corrections. No runtime/source fix is pending.
2. Coordinator runs external packaging/verify-package.py on exact staged inventory/SHA/ZIP member bytes and source manifest, then verifies every committed canonical Git blob. It requires existing537-compatible evidence-index.json, evidence.sha256 and indexed member ledgers. No self-hash recursion. Source-only preparatory syntax and tiny synthetic ZIP/source/corruption checks passed; actual canonical execution is not yet claimed.
3. Revalidate tracker/main/source tree; serially integrate exact accepted commits/tree into clean main, verify canonical source/hash equivalence, then owned review/done/archive. Preserve source/evidence/artifacts and perform normal no-force completed-worktree cleanup with owner. Direct next handoff is539.

No unrelated open check, new solver, profiler, benchmark repeat, full correctness rerun or additional storage gate is introduced. Coordinator owns only external packaging tooling/checklists and acceptance/integration records; owner536 owns canonical report/tables/raw selection/index generation, reviewer527 owns raw/method audits.

Read-only task show --json initially exited2 because CLI defaults to JSON and does not accept that flag; corrected ref-less529/explicit598 reads succeeded. No task state or dependency mutation occurred during this verification.
