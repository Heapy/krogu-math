from pathlib import Path
p=Path('src/commonMain/kotlin/io/heapy/krogu/math/BigDecimal.kt');s=p.read_text()
s=s.replace('constructor(coefficient: BigInteger, scale: Int) : this(normalizedCoefficient529(coefficient), scale, Unit)', 'constructor(coefficient: BigInteger, decimalScale: Int) : this(normalizedCoefficient529(coefficient), decimalScale, Unit)')
s=s.replace('setScale(0, ROUND_UNNECESSARY).coefficient','setScale(0, ROUND_UNNECESSARY).coefficientSnapshot()')
s=s.replace('if (result.coefficientSnapshot().signum() == 0) ZERO else result','if (result.storedSign529() == 0) ZERO else result')
# Representation-only scale changes never construct an intermediate coefficient.
s=s.replace('''        val coefficient = coefficientSnapshot()
        val result = BigDecimal(coefficient, scaleForValue(scale, coefficient.signum() == 0))''','''        val result = withScale529(scaleForValue(scale, storedSign529() == 0))''')
# Full-range primitive divide by a decimal power: negative domain avoids abs(MIN).
pos=s.index('    private fun withScale529(')
s=s[:pos]+'''    private fun roundedCompactPower529(value: Long, drop: Long, mode: RoundingMode): Long {
        if (drop == 0L || value == 0L) return value
        val sign = value.compareTo(0L)
        if (drop >= 19) {
            val negative = if (value > 0) -value else value
            val half = if (drop > 19) -1 else (-5000000000000000000L).compareTo(negative)
            return if (increment(mode, sign, half, false)) sign.toLong() else 0L
        }
        var divisor = 1L
        repeat(drop.toInt()) { divisor *= 10 }
        val quotient = value / divisor
        val remainder = value % divisor
        if (remainder == 0L) return quotient
        val magnitude = if (remainder < 0) -remainder else remainder
        val half = magnitude.compareTo(divisor - magnitude)
        return if (increment(mode, sign, half, quotient and 1L != 0L)) quotient + sign else quotient
    }

    private fun scaledCompact529(value: Long, raise: Long): Long? {
        if (value == 0L) return 0L
        if (raise > 18) return null
        var result = value
        repeat(raise.toInt()) {
            val next = result * 10L
            if (!CompactInteger529.multiplyFits(result, 10L, next)) return null
            result = next
        }
        return result
    }

'''+s[pos:]
# Raw sum selects primitive arithmetic before any coefficient snapshot.
a=s.index('    private fun rawSum585(');i=s.index('        val coefficient =',a)
s=s[:i]+'''        if (representation == 1 && other.representation == 1) {
            val scale = maxOf(decimalScale, other.decimalScale)
            val a = scaledCompact529(compactValue529(), scale.toLong() - decimalScale)
            val b = scaledCompact529(other.compactValue529(), scale.toLong() - other.decimalScale)
            if (a != null && b != null) {
                val result = if (subtract) a - b else a + b
                if (if (subtract) CompactInteger529.subtractFits(a, b, result) else CompactInteger529.addFits(a, b, result)) {
                    val decimal = BigDecimal(result, scale)
                    return if (mc == null) decimal else decimal.roundValue(mc)
                }
            }
        }
'''+s[i:]
# Exact multiplication checks the original source-zero scale rule first.
a=s.index('    private fun multiplyValue(');b=s.index('\n    }',a)
s=s[:a]+'''    private fun multiplyValue(multiplicand: BigDecimal): BigDecimal {
        val scale = scaleForValue(decimalScale.toLong() + multiplicand.decimalScale, storedSign529() == 0)
        if (representation == 1 && multiplicand.representation == 1) {
            val a = compactValue529(); val b = multiplicand.compactValue529()
            val result = a * b
            if (CompactInteger529.multiplyFits(a, b, result)) return BigDecimal(result, scale)
        }
        val coefficient = coefficientSnapshot()
        val otherCoefficient = multiplicand.coefficientSnapshot()
        return BigDecimal(coefficient.multiply(otherCoefficient), scale)
    }'''+s[b+6:]
# Contextual multiplication rescues only high logical scale, exactly as old path.
a=s.index('    open fun multiply(multiplicand: BigDecimal, mc: MathContext)');i=s.index('        val coefficient =',a);s=s[:i]+s[i:].replace('        val coefficient = coefficientSnapshot()\n','',1)
i=s.index('        // Preserve exact, low-scale',a)
s=s[:i]+'''        if (representation == 1 && operand.representation == 1) {
            val a = compactValue529(); val b = operand.compactValue529()
            val product = a * b
            if (CompactInteger529.multiplyFits(a, b, product)) {
                if (logicalScale <= Int.MAX_VALUE || a == 0L || b == 0L)
                    return BigDecimal(product, scaleForValue(logicalScale, a == 0L)).roundValue(context)
                val neutral = BigDecimal(product, 0)
                if (neutral.storedPrecision() <= context.precision) checkedScale(logicalScale)
                val rounded = neutral.round(context)
                return rounded.withScale529(checkedScale(logicalScale + rounded.decimalScale))
            }
        }
        val coefficient = coefficientSnapshot()
        val operandCoefficient = operand.coefficientSnapshot()
'''+s[i:]
a=s.index('    open fun multiply(multiplicand: BigDecimal, mc: MathContext)');b=s.index('\n    }',a);t=s[a:b];t=t.replace('operand.coefficientSnapshot()', 'operandCoefficient').replace('val operandCoefficient = operandCoefficient','val operandCoefficient = operand.coefficientSnapshot()');s=s[:a]+t+s[b:]
# Round's first virtual precision observation stays before scalar selection.
a=s.index('    private fun roundValue(');b=s.index('\n    }',a);t=s[a:b].replace('        val coefficient = coefficientSnapshot()\n','')
i=t.index('        var value = coefficient');t=t[:i]+'''        if (representation == 1 && this::class == BigDecimal::class) {
            var compact = compactValue529()
            var scale = decimalScale
            while (drop > 0) {
                scale = checkedRoundingScale(scale.toLong() - drop)
                compact = roundedCompactPower529(compact, drop.toLong(), mc.roundingMode)
                drop = CompactInteger529.decimalDigits(compact) - mc.precision
            }
            return BigDecimal(compact, scale)
        }
        val coefficient = coefficientSnapshot()
'''+t[i:];s=s[:a]+t+s[b:]
# setScale keeps virtual signum prefix; exact-class scalar path handles MIN and tiny results.
a=s.index('    private fun setScaleValue(');b=s.index('\n    }',a);t=s[a:b].replace('        val coefficient = coefficientSnapshot()\n','')
i=t.index('        val value = if (shift > 0)');t=t[:i]+'''        if (representation == 1 && this::class == BigDecimal::class) {
            val compact = compactValue529()
            if (shift <= 0) return BigDecimal(roundedCompactPower529(compact, -shift, roundingMode), newScale)
            val scaled = scaledCompact529(compact, shift)
            if (scaled != null) return BigDecimal(scaled, newScale)
        }
        val coefficient = coefficientSnapshot()
'''+t[i:];s=s[:a]+t+s[b:]
# Strip primitive path retains MIN, avoiding even a transient coefficient object.
a=s.index('    private fun stripTo(');b=s.index('        // A one-digit probe',a);t=s[a:b]
t=t.replace('        val coefficient = coefficientSnapshot()\n        var value = coefficient\n','')
t=t.replace('''        // Most application coefficients fit a signed Long. No negation is
        // needed, and decimalCompactValue excludes the Long.MIN_VALUE boundary.
        val compact = value.decimalCompactValue()
        if (compact != null) {
            var unscaled = compact''','''        if (representation == 1) {
            var unscaled = compactValue529()''')
t=t.replace('BigDecimal(BigInteger.valueOf(unscaled), scale)', 'BigDecimal(unscaled, scale)')
t+='        var value = coefficientSnapshot()\n';s=s[:a]+t+s[b:]
# Same-scale compare (originally stored, nonvirtual) needs no coefficient object.
a=s.index('    override fun compareTo(');i=s.index('        val coefficient =',a);s=s[:i]+'''        if (decimalScale == other.decimalScale && representation == 1 && other.representation == 1)
            return compactValue529().compareTo(other.compactValue529())
'''+s[i:]
# low-bit conversions avoid integer publication for exact base decimals, preserving subclass callbacks.
a=s.index('    private fun integerLowBits(');i=s.index('        val coefficient =',a)
s=s[:i]+'''        if (representation == 1 && this::class == BigDecimal::class) {
            var value = compactValue529()
            if (decimalScale >= 19) return 0L
            if (decimalScale > 0) repeat(decimalScale) { value /= 10L }
            if (decimalScale < 0) {
                val raise = -decimalScale.toLong()
                if (raise >= bits) return 0L
                repeat(raise.toInt()) { value *= 10L }
            }
            return if (bits == 32) value.toInt().toLong() else value
        }
'''+s[i:]
# Original fast longValueExact prefix excluded MIN; full MIN only for exact base class.
a=s.index('    open fun longValueExact(');i=s.index('        val coefficient =',a)
s=s[:i]+'''        if (representation == 1 && decimalScale == 0 &&
            (compactValue529() != Long.MIN_VALUE || this::class == BigDecimal::class)) return compactValue529()
'''+s[i:]
p.write_text(s)
