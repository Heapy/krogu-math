# Current529 production09e6dc3: verified correctness and partial final measurements

Accepted parentf8565cae98081ff0121ce7a40919d8a4cfd92013; numeric production09e6dc36b3dfaae3878dbe6304b9c9dcaa96735d; candidate HEADd6d594f9bb5f8da5ea962e87ee92796135e9f3d9 adds only the matched opt-in benchmark hook. Final unfiltered46319 passed2055 methods(684/457/457/457), zero failures/errors/skips,320 frozen source hashes unchanged. Hook-only delta separately reviewed/bound323candidate/312baseline sources. Earlier12/683 failure and cwd-only measurement startup error remain preserved; assertions unchanged.

Final JVM33 campaign87962 independently PASS:1386TIME,528 fullCHECK×8,7 fresh root graphs; exact source/artifact/runtime/flags/adapter binding. Same three alternating fresh pairs and seven samples/process, median-of-process-medians with full ranges/paired ratios. Shared host/no CPU affinity or power isolation.17 cases faster all3, fresh accumulator sole all3 adverse1.099;13 pooled adverse retained. No universal speedup or current JDK claim. Current JS21 campaign71641 remains live; current Wasm/Native21 and canonical package pending. All9641/earlier metrics remain source-labelled in results-9641a95.md/results-ef3db6c.md.

## Final current JVM33

| Case | Baseline ns [min,max] | Candidate ns [min,max] | Ratio | Paired ratios | Transient B/op old→new |
|---|---:|---:|---:|---|---:|
| decimal/accumulator-compact-fresh | 696.692 [536.054,1247.457] | 765.759 [763.339,1413.854] | 1.099 | 1.424/1.099/1.133 | 1880.5→1792 |
| decimal/add-small | 38.758 [33.319,49.167] | 7.535 [4.802,8.173] | 0.194 | 0.098/0.226/0.211 | 264→40 |
| decimal/create-min | 9.904 [7.495,16.766] | 5.264 [3.313,6.314] | 0.531 | 0.335/0.702/0.377 | 88→40 |
| decimal/create-small | 10.443 [8.444,16.189] | 6.057 [3.581,6.760] | 0.580 | 0.343/0.717/0.418 | 112→40 |
| decimal/divide-context | 183.618 [99.789,204.716] | 33.704 [33.348,53.114] | 0.184 | 0.184/0.334/0.259 | 410.5→45 |
| decimal/divide-scaled | 58.213 [34.704,64.056] | 21.244 [14.812,30.607] | 0.365 | 0.254/0.612/0.478 | 273→64 |
| decimal/metadata | 3.729 [3.326,5.757] | 4.605 [3.209,5.640] | 1.235 | 0.861/1.384/0.980 | 0→0 |
| decimal/multiply-small | 21.271 [13.989,21.611] | 7.159 [4.835,7.972] | 0.337 | 0.227/0.512/0.369 | 112→40 |
| decimal/original527-mc34-divide | 286.245 [179.311,293.182] | 291.567 [196.778,298.263] | 1.019 | 0.671/1.626/1.042 | 610→634 |
| decimal/parse-rounded | 107.481 [64.571,129.758] | 82.028 [58.039,92.833] | 0.763 | 0.540/1.270/0.715 | 344→184 |
| decimal/parse-small | 102.223 [94.466,125.785] | 71.705 [49.238,82.506] | 0.701 | 0.482/0.759/0.656 | 216→184 |
| decimal/round | 23.855 [16.727,30.381] | 11.801 [8.930,16.579] | 0.495 | 0.374/0.706/0.546 | 160→40 |
| decimal/setScale | 20.303 [15.871,26.644] | 7.964 [5.809,9.252] | 0.392 | 0.286/0.502/0.347 | 136→40 |
| decimal/strip | 27.348 [21.187,37.443] | 11.875 [8.498,12.135] | 0.434 | 0.311/0.560/0.324 | 328→40 |
| decimal/subtract-small | 46.212 [29.623,51.460] | 6.748 [4.854,8.185] | 0.146 | 0.105/0.228/0.159 | 232→40 |
| decimal/wide-add | 105.999 [87.228,177.761] | 87.476 [64.473,109.280] | 0.825 | 0.608/1.003/0.615 | 632→664 |
| decimal/wide-create | 4.335 [3.847,7.556] | 5.834 [3.988,7.209] | 1.346 | 0.920/1.517/0.954 | 32→40 |
| decimal/wide-divide | 2260.198 [1934.176,3650.640] | 2574.964 [2472.804,2861.766] | 1.139 | 1.139/1.278/0.784 | 7533.5→6844.5 |
| decimal/wide-multiply | 879.894 [859.152,1843.862] | 1436.961 [1106.421,1462.830] | 1.633 | 1.288/1.633/0.793 | 3680→3520 |
| decimal/wide-round | 314.332 [275.147,637.445] | 350.031 [331.572,402.403] | 1.114 | 1.114/1.205/0.631 | 1568→1376 |
| integer/add-small | 14.256 [13.603,14.563] | 6.589 [4.239,6.992] | 0.462 | 0.297/0.480/0.484 | 80→32 |
| integer/create-min | 5.061 [4.699,6.201] | 2.797 [2.050,4.396] | 0.553 | 0.436/0.451/0.869 | 56→32 |
| integer/create-small | 8.495 [7.695,9.182] | 2.904 [2.223,4.369] | 0.342 | 0.242/0.342/0.568 | 80→32 |
| integer/demote | 9.240 [8.667,12.324] | 8.325 [4.369,10.328] | 0.901 | 0.473/0.961/0.838 | 56→32 |
| integer/divide-min-overflow | 10.638 [9.498,16.121] | 12.063 [5.383,12.072] | 1.134 | 0.506/1.271/0.748 | 56→64 |
| integer/metadata | 4.046 [3.456,6.093] | 5.705 [3.094,6.869] | 1.410 | 0.765/1.987/0.936 | 0→0 |
| integer/multiply-small | 15.220 [14.045,18.377] | 7.876 [5.140,8.258] | 0.517 | 0.280/0.543/0.561 | 80→32 |
| integer/parse-small | 70.317 [67.669,84.601] | 76.805 [66.287,88.495] | 1.092 | 0.784/1.092/1.308 | 136→128 |
| integer/promote | 12.304 [12.210,13.817] | 8.447 [5.463,12.832] | 0.687 | 0.395/0.692/1.043 | 88→64 |
| integer/subtract-small | 10.805 [10.497,10.998] | 5.937 [4.047,6.424] | 0.549 | 0.368/0.595/0.566 | 48→32 |
| integer/wide-add | 21.795 [20.008,23.413] | 28.163 [15.361,34.033] | 1.292 | 0.656/1.701/1.292 | 200→208 |
| integer/wide-divide | 177.041 [156.089,383.764] | 253.303 [162.310,281.026] | 1.431 | 0.917/1.623/0.732 | 296→304 |
| integer/wide-multiply | 195.171 [163.220,255.636] | 279.233 [156.472,279.767] | 1.431 | 0.802/1.714/1.092 | 328→336 |

## Retained graph scopes

Fresh final JVM root graphs are actually measured in87962: BI small48→32B, MIN/MAX56→32; BDsmall80→40/MIN88→40; wideBI104→112(+8) andBD136→152(+16). Wide primitive array80B is shallow including header/alignment. Identity-reachable library graph excludes static caches/metadata and operation garbage, not a universal retainedheap guarantee.

JS/Wasm actual9641 snapshots and controls remain retained with their own artifact hashes. Source storage/constructor/factory/cache invariance across09e is reviewed; final compiled layout/factory binding is pending, so snapshots are not relabelled as new captures. Existing source-specific observed cohort averages: JSBI264→96/BD320→96small andwide331.5→371.5(+40)/387.5→467.5(+80); WasmBI144→72/BD216→80small andwide203→219(+16)/275→299(+24),256 distinct roots/strong closure. Carrier and independent shared metadata excluded. Raw global JS slopes failed and remainFAILED_UNVERIFIED.

Native matched Debug graph16-phase audit independently PASS: actual payload/type/ref/root/control ownership plus separately pinned-ABI modeled runtime instance extents. Small BI44→32/BD76→44; wide cohort averages101.5→113.5(+12)/133.5→157.5(+24). These are Debug configuration instance extents, not allocator size classes/padding/pages/GC bookkeeping or process memory; no Release transfer claim yet. Failed NativeGC slopes remainFAILED_UNVERIFIED. Exact Unit image/permanent proof corrects its omission from enumerated GCroots; original strict failure remains preserved.

Shared cache is separate per number:152 logical raw bytes, JVM array168B+associated helper16B; observed JS exclusivecache1072B/helper96B andWasm232B/helper64B fromsource-labelled9641 snapshots; NativeDebug actual152payload, modeled168array+associatedhelper24. Associated helper is not incremental cache-only owner growth. Final unchanged-class/layout binding must support carry-forward; allocator/class/static metadata remain excluded as stated. Source/actualgraph/nativeproof reports retain all boundaries and reproduction commands.
