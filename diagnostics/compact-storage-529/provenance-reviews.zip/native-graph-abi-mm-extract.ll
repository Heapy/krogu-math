target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx12.0.0"

define linkonce_odr void @_ZN6kotlin2mm12MemoryDumper9DumpArrayEPK8TypeInfoP11ArrayHeader(ptr noundef nonnull align 8 dereferenceable(152) %0, ptr noundef %1, ptr noundef %2) local_unnamed_addr #15 personality ptr @__gxx_personality_v0 {
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = alloca ptr, align 8
  %7 = alloca ptr, align 8
  %8 = alloca i8, align 1
  %9 = alloca [1 x i32], align 4
  %10 = load i32, ptr @Kotlin_runtimeLogsEnabled, align 4, !tbaa !23
  %11 = icmp eq i32 %10, 0
  br i1 %11, label %21, label %12

12:                                               ; preds = %3
  %13 = tail call noundef ptr @_ZN6kotlin8compiler11runtimeLogsEv() #45
  %14 = getelementptr inbounds nuw i8, ptr %13, i64 44
  %15 = load i32, ptr %14, align 4, !tbaa !23
  %16 = icmp slt i32 %15, 4
  br i1 %16, label %21, label %17

17:                                               ; preds = %12
  call void @llvm.lifetime.start.p0(ptr %9)
  store i32 11, ptr %9, align 4, !tbaa !283
  %18 = ptrtoint ptr %9 to i64
  %19 = insertvalue [2 x i64] poison, i64 %18, 0
  %20 = insertvalue [2 x i64] %19, i64 1, 1
  call void (i32, [2 x i64], ptr, ...) @_ZN6kotlin7logging3LogENS0_5LevelESt16initializer_listINS0_3TagEEPKcz(i32 noundef 4, [2 x i64] %20, ptr noundef nonnull @.str.17.140, ptr noundef %2) #45
  call void @llvm.lifetime.end.p0(ptr %9)
  br label %21

21:                                               ; preds = %12, %3, %17
  %22 = getelementptr inbounds nuw i8, ptr %0, i64 2
  %23 = load i8, ptr %22, align 2, !tbaa !374
  call void @llvm.lifetime.start.p0(ptr %8)
  store i8 %23, ptr %8, align 1, !tbaa !57
  %24 = ptrtoint ptr %8 to i64
  %25 = insertvalue [2 x i64] poison, i64 %24, 0
  %26 = insertvalue [2 x i64] %25, i64 1, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIhEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %26)
  call void @llvm.lifetime.end.p0(ptr %8)
  call void @llvm.lifetime.start.p0(ptr %7)
  store ptr %2, ptr %7, align 8, !tbaa !344
  %27 = ptrtoint ptr %7 to i64
  %28 = insertvalue [2 x i64] poison, i64 %27, 0
  %29 = insertvalue [2 x i64] %28, i64 1, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIPKvEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %29)
  call void @llvm.lifetime.end.p0(ptr %7)
  call void @llvm.lifetime.start.p0(ptr %6)
  store ptr %1, ptr %6, align 8, !tbaa !344
  %30 = ptrtoint ptr %6 to i64
  %31 = insertvalue [2 x i64] poison, i64 %30, 0
  %32 = insertvalue [2 x i64] %31, i64 1, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIPKvEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %32)
  call void @llvm.lifetime.end.p0(ptr %6)
  %33 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %34 = load i32, ptr %33, align 8, !tbaa !170
  call void @llvm.lifetime.start.p0(ptr %5)
  store i32 %34, ptr %5, align 4, !tbaa !23
  %35 = ptrtoint ptr %5 to i64
  %36 = insertvalue [2 x i64] poison, i64 %35, 0
  %37 = insertvalue [2 x i64] %36, i64 1, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIjEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %37)
  call void @llvm.lifetime.end.p0(ptr %5)
  %38 = getelementptr inbounds nuw i8, ptr %1, i64 20
  %39 = load i32, ptr %38, align 4, !tbaa !373
  %40 = sub nsw i32 0, %39
  %41 = sext i32 %40 to i64
  %42 = add nsw i64 %41, 15
  %43 = sub nsw i64 0, %41
  %44 = and i64 %42, %43
  %45 = mul i32 %34, %40
  %46 = zext i32 %45 to i64
  call void @llvm.lifetime.start.p0(ptr %4)
  store i32 %45, ptr %4, align 4, !tbaa !23
  %47 = ptrtoint ptr %4 to i64
  %48 = insertvalue [2 x i64] poison, i64 %47, 0
  %49 = insertvalue [2 x i64] %48, i64 1, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIjEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %49)
  call void @llvm.lifetime.end.p0(ptr %4)
  %50 = getelementptr inbounds nuw i8, ptr %2, i64 %44
  %51 = ptrtoint ptr %50 to i64
  %52 = insertvalue [2 x i64] poison, i64 %51, 0
  %53 = insertvalue [2 x i64] %52, i64 %46, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIhEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %53)
  ret void
}

define linkonce_odr void @_ZN6kotlin2mm12MemoryDumper10DumpObjectEPK8TypeInfoP9ObjHeader(ptr noundef nonnull align 8 dereferenceable(152) %0, ptr noundef %1, ptr noundef %2) local_unnamed_addr #15 personality ptr @__gxx_personality_v0 {
  %4 = alloca i32, align 4
  %5 = alloca ptr, align 8
  %6 = alloca ptr, align 8
  %7 = alloca i8, align 1
  %8 = alloca %"class.std::__1::basic_string", align 8
  %9 = alloca [1 x i32], align 4
  %10 = alloca %"class.std::__1::basic_string", align 8
  call void @llvm.lifetime.start.p0(ptr %8)
  call void @_ZNK8TypeInfo6fqNameEv(ptr dead_on_unwind nonnull writable sret(%"class.std::__1::basic_string") align 8 %8, ptr noundef nonnull align 8 dereferenceable(128) %1)
  %11 = getelementptr inbounds nuw i8, ptr %8, i64 23
  %12 = load i32, ptr @Kotlin_runtimeLogsEnabled, align 4, !tbaa !23
  %13 = icmp eq i32 %12, 0
  br i1 %13, label %19, label %14

14:                                               ; preds = %3
  %15 = call noundef ptr @_ZN6kotlin8compiler11runtimeLogsEv() #45
  %16 = getelementptr inbounds nuw i8, ptr %15, i64 44
  %17 = load i32, ptr %16, align 4, !tbaa !23
  %18 = icmp sgt i32 %17, 3
  br label %19

19:                                               ; preds = %14, %3
  %20 = phi i1 [ false, %3 ], [ %18, %14 ]
  %21 = load i8, ptr %11, align 1
  %22 = icmp slt i8 %21, 0
  br i1 %22, label %23, label %28

23:                                               ; preds = %19
  %24 = load ptr, ptr %8, align 8, !tbaa !57
  %25 = getelementptr inbounds nuw i8, ptr %8, i64 16
  %26 = load i64, ptr %25, align 8
  %27 = and i64 %26, 9223372036854775807
  call void @_ZdlPvm(ptr noundef %24, i64 noundef %27) #44
  br label %28

28:                                               ; preds = %19, %23
  call void @llvm.lifetime.end.p0(ptr %8)
  br i1 %20, label %29, label %46

29:                                               ; preds = %28
  call void @llvm.lifetime.start.p0(ptr %9)
  store i32 11, ptr %9, align 4, !tbaa !283
  call void @llvm.lifetime.start.p0(ptr %10)
  call void @_ZNK8TypeInfo6fqNameEv(ptr dead_on_unwind nonnull writable sret(%"class.std::__1::basic_string") align 8 %10, ptr noundef nonnull align 8 dereferenceable(128) %1)
  %30 = getelementptr inbounds nuw i8, ptr %10, i64 23
  %31 = load i8, ptr %30, align 1
  %32 = icmp slt i8 %31, 0
  %33 = load ptr, ptr %10, align 8
  %34 = select i1 %32, ptr %33, ptr %10
  %35 = ptrtoint ptr %9 to i64
  %36 = insertvalue [2 x i64] poison, i64 %35, 0
  %37 = insertvalue [2 x i64] %36, i64 1, 1
  call void (i32, [2 x i64], ptr, ...) @_ZN6kotlin7logging3LogENS0_5LevelESt16initializer_listINS0_3TagEEPKcz(i32 noundef 4, [2 x i64] %37, ptr noundef nonnull @.str.18.139, ptr noundef %2, ptr noundef %34) #45
  %38 = load i8, ptr %30, align 1
  %39 = icmp slt i8 %38, 0
  br i1 %39, label %40, label %45

40:                                               ; preds = %29
  %41 = load ptr, ptr %10, align 8, !tbaa !57
  %42 = getelementptr inbounds nuw i8, ptr %10, i64 16
  %43 = load i64, ptr %42, align 8
  %44 = and i64 %43, 9223372036854775807
  call void @_ZdlPvm(ptr noundef %41, i64 noundef %44) #44
  br label %45

45:                                               ; preds = %29, %40
  call void @llvm.lifetime.end.p0(ptr %10)
  call void @llvm.lifetime.end.p0(ptr %9)
  br label %46

46:                                               ; preds = %28, %45
  %47 = getelementptr inbounds nuw i8, ptr %0, i64 1
  %48 = load i8, ptr %47, align 1, !tbaa !375
  call void @llvm.lifetime.start.p0(ptr %7)
  store i8 %48, ptr %7, align 1, !tbaa !57
  %49 = ptrtoint ptr %7 to i64
  %50 = insertvalue [2 x i64] poison, i64 %49, 0
  %51 = insertvalue [2 x i64] %50, i64 1, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIhEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %51)
  call void @llvm.lifetime.end.p0(ptr %7)
  call void @llvm.lifetime.start.p0(ptr %6)
  store ptr %2, ptr %6, align 8, !tbaa !344
  %52 = ptrtoint ptr %6 to i64
  %53 = insertvalue [2 x i64] poison, i64 %52, 0
  %54 = insertvalue [2 x i64] %53, i64 1, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIPKvEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %54)
  call void @llvm.lifetime.end.p0(ptr %6)
  call void @llvm.lifetime.start.p0(ptr %5)
  store ptr %1, ptr %5, align 8, !tbaa !344
  %55 = ptrtoint ptr %5 to i64
  %56 = insertvalue [2 x i64] poison, i64 %55, 0
  %57 = insertvalue [2 x i64] %56, i64 1, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIPKvEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %57)
  call void @llvm.lifetime.end.p0(ptr %5)
  %58 = getelementptr inbounds nuw i8, ptr %1, i64 20
  %59 = load i32, ptr %58, align 4, !tbaa !373
  %60 = sext i32 %59 to i64
  %61 = add nsw i64 %60, -8
  %62 = getelementptr inbounds nuw i8, ptr %2, i64 8
  %63 = trunc i64 %61 to i32
  call void @llvm.lifetime.start.p0(ptr %4)
  store i32 %63, ptr %4, align 4, !tbaa !23
  %64 = ptrtoint ptr %4 to i64
  %65 = insertvalue [2 x i64] poison, i64 %64, 0
  %66 = insertvalue [2 x i64] %65, i64 1, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIjEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %66)
  call void @llvm.lifetime.end.p0(ptr %4)
  %67 = ptrtoint ptr %62 to i64
  %68 = insertvalue [2 x i64] poison, i64 %67, 0
  %69 = insertvalue [2 x i64] %68, i64 %61, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIhEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %69)
  ret void
}

define linkonce_odr void @_ZN6kotlin2mm12MemoryDumper14DumpObjectInfoEPK8TypeInfo(ptr noundef nonnull align 8 dereferenceable(152) %0, ptr noundef %1) local_unnamed_addr #15 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  %5 = alloca i32, align 4
  %6 = getelementptr inbounds nuw i8, ptr %1, i64 20
  %7 = load i32, ptr %6, align 4, !tbaa !373
  %8 = add i32 %7, -8
  call void @llvm.lifetime.start.p0(ptr %5)
  store i32 %8, ptr %5, align 4, !tbaa !23
  %9 = ptrtoint ptr %5 to i64
  %10 = insertvalue [2 x i64] poison, i64 %9, 0
  %11 = insertvalue [2 x i64] %10, i64 1, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIjEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %11)
  call void @llvm.lifetime.end.p0(ptr %5)
  %12 = getelementptr inbounds nuw i8, ptr %1, i64 40
  %13 = load i32, ptr %12, align 8, !tbaa !202
  call void @llvm.lifetime.start.p0(ptr %4)
  store i32 %13, ptr %4, align 4, !tbaa !23
  %14 = ptrtoint ptr %4 to i64
  %15 = insertvalue [2 x i64] poison, i64 %14, 0
  %16 = insertvalue [2 x i64] %15, i64 1, 1
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIjEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %16)
  call void @llvm.lifetime.end.p0(ptr %4)
  %17 = icmp sgt i32 %13, 0
  br i1 %17, label %18, label %32

18:                                               ; preds = %2
  %19 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %20 = ptrtoint ptr %3 to i64
  %21 = insertvalue [2 x i64] poison, i64 %20, 0
  %22 = insertvalue [2 x i64] %21, i64 1, 1
  %23 = zext nneg i32 %13 to i64
  br label %24

24:                                               ; preds = %24, %18
  %25 = phi i64 [ 0, %18 ], [ %30, %24 ]
  %26 = load ptr, ptr %19, align 8, !tbaa !203
  %27 = getelementptr inbounds nuw i32, ptr %26, i64 %25
  %28 = load i32, ptr %27, align 4, !tbaa !23
  %29 = add i32 %28, -8
  call void @llvm.lifetime.start.p0(ptr %3)
  store i32 %29, ptr %3, align 4, !tbaa !23
  call void @_ZN6kotlin2mm12MemoryDumper8DumpSpanIjEEvNS_11std_support4spanIT_Lm18446744073709551615EEE(ptr noundef nonnull align 8 dereferenceable(152) %0, [2 x i64] %22)
  call void @llvm.lifetime.end.p0(ptr %3)
  %30 = add nuw nsw i64 %25, 1
  %31 = icmp eq i64 %30, %23
  br i1 %31, label %32, label %24, !llvm.loop !392

32:                                               ; preds = %24, %2
  %33 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %34 = load ptr, ptr %33, align 8, !tbaa !385
  %35 = icmp eq ptr %34, null
  br i1 %35, label %37, label %36

36:                                               ; preds = %32
  call void @_ZN6kotlin2mm12MemoryDumper14DumpObjectInfoEPK16ExtendedTypeInfom(ptr noundef nonnull align 8 dereferenceable(152) %0, ptr noundef nonnull %34, i64 noundef 8)
  br label %37

37:                                               ; preds = %36, %32
  ret void
}
