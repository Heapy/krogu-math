#!/usr/bin/env kotlinr
// SPDX-License-Identifier: Apache-2.0
// Task-owned, untimed reader of runtime dump records; no numerical implementation.
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.ArrayDeque

require(args.size == 4 || args.size == 7) { "input.kdump new-output.json phase baseline|candidate [reviewedUnitProof expectedProofSHA executable]" }
val input = File(args[0]).canonicalFile
val output = File(args[1]).canonicalFile
val phase = args[2].toInt().also { require(it in 0..7) }
val implementation = args[3].also { require(it in listOf("baseline", "candidate")) }
require(args.size == 4 || phase == 0) { "Static Unit proof applies only to phase0" }
require(input.isFile && input.length() in 1..134_217_728L && !output.exists())
require(output.toPath().startsWith(File("/Users/yoda/dev/pet/krogu-math/.codex-work/529").toPath()) && output.parentFile.isDirectory)
val bytes = input.readBytes()
val rawSha = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
var position = 0
fun u8(): Int { check(position < bytes.size); return bytes[position++].toInt() and 255 }
fun cstring(): String {
    val start = position
    while (u8() != 0) check(position - start <= 65536)
    return bytes.copyOfRange(start, position - 1).toString(Charsets.UTF_8)
}
check(cstring() == "Kotlin/Native dump 1.0.8") { "Unsupported dump version" }
val endian = u8().also { check(it in 0..1) }
val order = if (endian == 1) ByteOrder.LITTLE_ENDIAN else ByteOrder.BIG_ENDIAN
val idSize = u8().also { check(it in listOf(1, 2, 4, 8)) }
fun number(width: Int): Long {
    check(width in listOf(1, 2, 4, 8) && position + width <= bytes.size)
    val b = ByteBuffer.wrap(bytes, position, width).order(order)
    position += width
    return when (width) { 1 -> b.get().toLong() and 255; 2 -> b.short.toLong() and 65535; 4 -> b.int.toLong() and 0xffffffffL; else -> b.long }
}
fun count(cap: Int = 1_000_000): Int = number(4).also { check(it in 0..cap.toLong()) }.toInt()
fun id() = number(idSize)
data class Field(val offset: Int, val kind: Int, val name: String)
data class Shape(val id: Long, val name: String, val flags: Int, val size: Int, val offsets: List<Int>, val fields: List<Field>)
data class Item(val id: Long, val type: Long, val count: Int?, val data: ByteArray)
val shapes = linkedMapOf<Long, Shape>()
val objects = linkedMapOf<Long, Item>()
val roots = arrayListOf<Long>()
val globalRoots = hashSetOf<Long>()
val extras = arrayListOf<List<Long>>()
var records = 0
fun payload(): ByteArray {
    val n = count(33_554_432)
    check(position + n <= bytes.size)
    return bytes.copyOfRange(position, position + n).also { position += n }
}
while (position < bytes.size) {
    check(++records <= 2_000_000)
    when (val tag = u8()) {
        1 -> {
            val key = id(); val flags = u8(); check(flags and 0xf8 == 0); id()
            val pkg = cstring(); val name = cstring(); val size = count(33_554_432)
            val offsets = if (flags and 1 == 0) List(count(10000)) { count(33_554_432) } else emptyList()
            val fields = if (flags and 2 != 0 && flags and 1 == 0) List(count(10000)) {
                Field(count(33_554_432), u8().also { check(it in 1..10) }, cstring())
            } else emptyList()
            if (flags and 2 != 0 && flags and 1 != 0) check(u8() in 1..10)
            check(shapes.put(key, Shape(key, "$pkg.$name".trimStart('.'), flags, size, offsets, fields)) == null)
        }
        2 -> { val key = id(); val type = id(); check(objects.put(key, Item(key, type, null, payload())) == null) }
        3 -> { val key = id(); val type = id(); val n = count(); check(objects.put(key, Item(key, type, n, payload())) == null) }
        4 -> extras += listOf(id(), id(), id())
        5 -> id()
        6 -> { check(u8() in 1..2); val key = id(); roots += key; globalRoots += key }
        7 -> { id(); check(u8() in 1..2); roots += id() }
        else -> error("Unknown record $tag at ${position - 1}")
    }
}
fun shape(i: Item) = checkNotNull(shapes[i.type])
fun pointer(data: ByteArray, offset: Int): Long {
    check(offset >= 0 && offset + idSize <= data.size)
    val b = ByteBuffer.wrap(data, offset, idSize).order(order)
    return when (idSize) { 1 -> b.get().toLong() and 255; 2 -> b.short.toLong() and 65535; 4 -> b.int.toLong() and 0xffffffffL; else -> b.long }
}
fun references(i: Item): List<Long> {
    val t = shape(i)
    if (i.count != null) {
        check(t.flags and 1 != 0 && i.data.size.toLong() == i.count.toLong() * t.size)
        return if (t.flags and 4 != 0) {
            check(t.size == idSize); List(i.count) { pointer(i.data, it * idSize) }
        } else emptyList()
    }
    check(t.flags and 1 == 0 && i.data.size == t.size)
    return t.offsets.map { pointer(i.data, it) }
}
objects.values.forEach { references(it).filter { v -> v != 0L }.forEach { v -> check(v in objects) { "Unresolved object reference" } } }
val markers = objects.values.filter { shape(it).name.endsWith("NativeGraphRoot529") }
check(markers.size == 1 && markers.single().id in globalRoots) { "Unique globally rooted marker required" }
val marker = markers.single()
val markerShape = shape(marker)
val phaseField = markerShape.fields.single { it.name == "phaseId" && it.kind == 4 }
check(ByteBuffer.wrap(marker.data, phaseField.offset, 4).order(order).int == phase)
val valuesField = markerShape.fields.single { it.name == "values" && it.kind == 1 }
check(valuesField.offset in markerShape.offsets) { "Marker values must be a declared traced reference" }
check(extras.none { it[2] != 0L }) { "Associated-object edges require explicit graph modeling" }
val carrierId = pointer(marker.data, valuesField.offset)
val carrier = checkNotNull(objects[carrierId]); check(carrier.count == 256)
val values = references(carrier); check(values.size == 256)
val expectedType = listOf("Unit", "BigInteger", "BigInteger", "BigDecimal", "BigDecimal", "ByteArray", "ByteArray", "IntArray")[phase]
check(values.all { shape(checkNotNull(objects[it])).name.substringAfterLast('.') == expectedType })
check(values.distinct().size == if (phase == 0) 1 else 256)
val outside = hashSetOf<Long>(); val queue = ArrayDeque<Long>()
roots.filter { it != 0L && it != carrierId }.forEach { if (outside.add(it)) queue.add(it) }
while (queue.isNotEmpty()) references(checkNotNull(objects[queue.removeFirst()])).filter { it != 0L && it != carrierId }.forEach { if (outside.add(it)) queue.add(it) }
val owned = hashSetOf<Long>(); queue.addAll(values)
while (queue.isNotEmpty()) {
    val key = queue.removeFirst()
    if (key == 0L || key in outside || !owned.add(key)) continue
    check(owned.size <= 4096)
    references(checkNotNull(objects[key])).forEach(queue::add)
}
var staticUnitProof: Map<String, String>? = null
if (phase != 0) check(values.none { it in outside })
else if (!(values.all { it in outside } && owned.isEmpty())) {
    check(args.size == 7) { "Unit must be externally shared or have exact reviewed static-image proof" }
    val proofFile = File(args[4]).canonicalFile
    val expectedProofSha = args[5].also { check(it.matches(Regex("[a-f0-9]{64}"))) }
    val image = File(args[6]).canonicalFile
    check(proofFile.isFile && proofFile.length() in 1..16384 && image.isFile && image.length() <= 134_217_728)
    fun digest(file: File) = MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString("") { "%02x".format(it) }
    check(digest(proofFile) == expectedProofSha)
    val proof = proofFile.readText()
    fun stringField(key: String): String = Regex("\"" + Regex.escape(key) + "\"\\s*:\\s*\"([^\"]*)\"")
        .findAll(proof).toList().single().groupValues[1]
    check(stringField("status") == "ACTUAL_STATIC_IMAGE_UNIT_ADDRESS_MATCH")
    check(stringField("dump_raw_sha256") == rawSha && stringField("executable_sha256") == digest(image))
    val unitId = values.distinct().single()
    val unit = checkNotNull(objects[unitId])
    check(shape(unit).name == "kotlin.Unit" && unit.count == null && unit.data.isEmpty() && references(unit).isEmpty())
    check(owned == setOf(unitId)) { "No other unrooted object may use the Unit exception" }
    fun hex(key: String) = stringField(key).removePrefix("0x").toLong(16)
    check(hex("unit_id") == unitId && hex("unit_type_id") == unit.type)
    check(hex("image_unit_symbol") + hex("aslr_slide") == unitId)
    check(hex("image_typeinfo_symbol") + hex("aslr_slide") == unit.type)
    check(stringField("segment") == "__DATA_CONST" && stringField("section") == "__const")
    // The reviewed proof matches actual IDs to immutable image symbols; GC-root
    // enumeration does not list every permanent image object. No live header is inferred.
    owned.remove(unitId)
    staticUnitProof = mapOf("proof_sha256" to expectedProofSha, "executable_sha256" to stringField("executable_sha256"), "unit_id" to unitId.toString(16), "basis" to "Exact reviewed zero-body Unit image singleton; not an inferred GC root or live-memory header read")
}
if (phase in 5..7) {
    val expectedCount = if (phase == 5) 0 else if (phase == 6) 256 else 64
    values.forEach {
        val array = checkNotNull(objects[it])
        check(array.count == expectedCount && array.data.all { byte -> byte == 0.toByte() })
        check(array.data.size == if (phase == 5) 0 else 256)
    }
}
val grouped = owned.map { checkNotNull(objects[it]) }.groupBy { shape(it).name }.mapValues { (_, list) ->
    mapOf("count" to list.size, "serialized_data_bytes" to list.sumOf { it.data.size.toLong() }, "array_counts" to list.mapNotNull { it.count }.distinct().sorted())
}
fun json(v: Any?): String = when (v) {
    null -> "null"
    is String -> "\"" + v.flatMap { c -> when (c) { '\\' -> "\\\\".toList(); '"' -> "\\\"".toList(); '\n' -> "\\n".toList(); else -> if (c.code < 32) "\\u%04x".format(c.code).toList() else listOf(c) } }.joinToString("") + "\""
    is Map<*, *> -> v.entries.joinToString(",", "{", "}") { json(it.key.toString()) + ":" + json(it.value) }
    is Iterable<*> -> v.joinToString(",", "[", "]") { json(it) }
    else -> v.toString()
}
val typeDetails = (owned + marker.id + carrier.id).map { shape(checkNotNull(objects[it])) }.distinctBy { it.id }.associate { type ->
    type.name to mapOf("serialized_instance_or_element_bytes" to type.size, "flags" to type.flags, "reference_offsets" to type.offsets, "fields" to type.fields.map { mapOf("name" to it.name, "offset" to it.offset, "kind" to it.kind) })
}
val ownedEdges = owned.sorted().map { key ->
    val item = checkNotNull(objects[key])
    mapOf("id" to key.toString(16), "type" to shape(item).name, "serialized_data_bytes" to item.data.size, "array_count" to item.count, "references" to references(item).map { it.toString(16) })
}
val sharedCaches = objects.values.filter { shape(it).name.endsWith("CompactInteger529") }.mapNotNull { helper ->
    val field = shape(helper).fields.singleOrNull { it.name == "negativePowers" && it.kind == 1 } ?: return@mapNotNull null
    check(field.offset in shape(helper).offsets) { "Cache must be a declared traced reference" }
    val cache = checkNotNull(objects[pointer(helper.data, field.offset)])
    check(shape(cache).name == "kotlin.LongArray" && cache.count == 19 && cache.data.size == 152)
    repeat(19) { index ->
        val actual = ByteBuffer.wrap(cache.data, index * 8, 8).order(order).long
        var expected = -1L; repeat(index) { expected *= 10L }; check(actual == expected)
    }
    check(helper.id in globalRoots && cache.id in outside && cache.id !in owned)
    mapOf("helper_id" to helper.id.toString(16), "helper_serialized_bytes" to helper.data.size, "cache_id" to cache.id.toString(16), "array_count" to 19, "logical_payload_bytes" to 152, "all19_values_checked" to true, "runtime_headers_and_allocator_bytes" to "UNMEASURED")
}
check(sharedCaches.size == if (implementation == "candidate") 1 else 0) { "Candidate requires actual cache observation; baseline requires absence" }
val result = mapOf("status" to "ROOT_TYPE_FIELD_PAYLOAD_VISIBILITY_ONLY_NOT_ALLOCATOR_SIZE", "implementation" to implementation, "input_sha256" to rawSha, "schema" to "Kotlin/Native dump 1.0.8", "id_size" to idSize, "records" to records, "phase" to phase, "static_unit_proof" to staticUnitProof, "marker_id" to marker.id.toString(16), "carrier_id" to carrierId.toString(16), "roots" to values.map { it.toString(16) }, "owned_ids" to owned.sorted().map { it.toString(16) }, "owned_types" to grouped, "type_schemas" to typeDetails, "owned_edges" to ownedEdges, "shared_power_cache" to sharedCaches, "extra_objects" to extras.filter { it[1] in owned }, "limits" to "Serialized object/array data excludes runtime headers, alignment and allocator overhead. No exact physical retained bytes inferred. Header ABI/ownership proof remains separate.")
output.writeText(json(result) + "\n")
println("PASS pilot visibility phase=$phase owned=${owned.size}; serialized payload only")
