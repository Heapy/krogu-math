# Identity publication correction: evidence invalidation map (review requested)

Source9641a95→09e6dc36 changes ONLY BigInteger result publication policies and common identity tests. It restores old observable identities; it does not broaden public identity guarantees. Public valueOf cache and explicit zero/operand/shift0 shortcuts unchanged. Failed45317 XML and all9641 timing/graph/cache observations remain attached to original source/artifact.

## Correctness

New focused oracle/context/compact/bit gate84984 and full four-target suites must run on09e. The159 older focused passes and683/12failed full JVM are historical, not summed as final gates.

## Timing/allocation

Changed return policies can create fresh−16..16 values where9641used interned instances. Any measured operation reaching those intermediates may alter allocation/CPU; unchanged arithmetic does not establish performance invariance. Keep all9641 measurements source-labelled. Fresh final artifacts and current matched-parent JVM33 / portable21 proof are the conservative existing mapped protocol; no extra noise reruns or new solver scope. Source/build/runtime ledgers must be refreshed. No final09e performance claim before actual measurements.

## Owned graph and cache scoped carry-forward request

BI physical constructor bodies/fields/discriminator/materialize seams unchanged (actual diff contains return sites and new helper only), BD/CompactInteger529/cache exactbytes unchanged. The reviewed retained-root factories use unique values starting12345000001, MIN-neighbors and wide magnitudes, not interned−16..16 arithmetic outputs. Factory bodies and baseline artifacts are byte-identical. Compact-number roots are directly constructed/published by those factories; borrowed wide arrays and per-number initialization remain identical. Existing actual9641 V8 shapes/strong closures cannot simply be relabelled on logical fields alone: final generated factory/constructor/initialization bodies and field-layout/root mappings must be rebound and independently compared. If those paths differ, do targeted actual graph proof rather than assume byte sizes.

Private negativePowers table/initializer and associated helper fields remain exactbytes. Public valueOf interning unaffected; class/static metadata and unrelated DecimalPowers597 shared values are outside the measured negative-power cache closure. Fresh artifact origin/hash binding remains required. Native logical152payload stays modelled, not totalheap; failed native metric coverage cannot be repaired by this mapping.

## Native diagnostic-only hook

527 owns proposed equal baseline/candidate accessor+snapshot hook and isolated dump/parser/launcher. Apply only after active production correctness source freeze ends; it must not alter numeric bodies or timed loops. Separate benchmark-only source manifest/fresh links and independent review precede actual dump pilot.
