# Task529 live checkpoint — source frozen, runtime pending

Worktree: /Users/yoda/dev/pet/krogu-math/.codex-work/529/worktree
Branch: codex/backlog-529
Dedicated tracker: a6bbf558 (coordinator owns transitions/comments)
Base:943635476c052bb6377f20d79d2bcb856c2c104e

Clean committed source chain:

-6b1c6854432484a11e3b2f79afbaa3a40d9b95ae initial529 physical storage/primitive source draft.
-6176a3bde82c1239f72f9494e593749829e4f407 separate reviewed537f6695e3 source composition.
-eba53e67c848b0a5fa00c12b432a36f73dec375d compact publication/division/callback/current-serialization tests.
-17b340222a13bcab2ff856821ba2a8f87b03d85a guarded graph/runtime diagnostics and docs.

Production/test21 source SHA manifest: source-review-final-draft.json. Coordinator independently verified all hashes and reviewed source PASS. Diagnostic10 source SHA manifest: diagnostic-review-final-draft.json (revision env-sanitized-per-phase-census). Worker527 independently verified hashes and revised methodology source PASS. These are SOURCE approvals only. No529 compilation, tests, numerical run or heap capture has occurred; no live process is owned. Root explicitly requires freeze while starting source-only539.

Important reviewed callback fixes: physical compact MIN remains excluded from BigDecimal's old direct same-scale semantic compare shortcut; both receiver/operand poison-signum fixtures prepared. Direct scale storage copies normalize stream-restored coefficient subtypes through public constructor/toByteArray, with exact restored marker identity fixture. Float retains explicit guard/sticky24-bit rounding (including2^55 midpoint+1 witnesses), not a JS intrinsic assumption. Public compact comparisons/sign fields explicitly normalize units.

Current-format compact decimals serialize no coefficient object. Eight existing resolver fixture setups now use a genuine public wide carrier at the same scale when the control is compact, then resolve to the original truthful replacement; post-read numeric/callback/identity assertions unchanged. Ordinary wide coefficient identity test unchanged. No historical/cross-version stream promise. Wide arrays are detached, tags/branch/sign/magnitude invariants validated; restored coefficient subtype may legally occupy wide branch even if its numerical payload fitsLong.

Parser ownership/seam: seam-537.md. Compact-first negative-domain grouped builder and primitive writer independently reviewed527 PASS. Finite-context DecimalText588 publication now folds rounded base1e9 digits directly to checked signedLong after all existing carry/scale/inexactness checks; positive2^63 falls back wide.

Prepared focused JVM division matrix6,776 endpoint/mode/fixed-scale/context outcomes plus bounded scaled/exact controls, asserting coefficient/scale/text and AE class/message. All unrun.

Diagnostics:

- measure-compact-storage-529.main.kts:31cases×16 full checks, same generated Java adapter/agent, exact fresh owned JVM root graph via Instrumentation, separate thread allocation, six alternating fresh child JVMs with200ms prewarm,3warm/7adaptive samples. JVM option env sanitized; actual G1/256MiB initial/512MiB max flags+argv pinned/recorded.
- Opt-in benchmark compact529 mode:19cases, Unit-root retention control,9cohorts×3sizes×3samples; JS heapUsed+arrayBuffers separately, Native returned producer frames +lastGC heapbytes; Wasm node heap coverage remains UNVERIFIED until own payload controls.
- check-compact-portable-529.main.kts: paired304 full checks, strict case/sample/count/metric inventory, known256byte-minus-empty coverage contrast and size scaling; RSS never substitutes for retained bytes.
- capture-compact-heap-529.main.kts: eight bounded256-root Node/V8 snapshots with actualschema/type census, only explicit nonsecret locale/TZ child environment, immediate per-phase summary files, lossless rawgzip+SHA recovery. Capture status is NOT_GRAPH_VALIDATED. Actual WasmGC root/type/owned field+array edges and shared/runtime metadata must be inspected before retained graph/size acceptance. Whole-snapshot census orRSS alone is insufficient.

Required future order: accepted537 must be integrated before529 main integration. Rebase onto current accepted main incl538/535/etc as root directs; compare/drop duplicate537 commit and review representation/parser/modulus/accumulator seams. Both final old/new measurement builds MUST contain the SAME accepted537/current-main base with only529 delta. Never use a pre537 baseline and attribute537 parser speedups to529. Preserve source-before/after hashes, exact commits/patches, explicit fresh jar/link build logs and artifact manifests for BOTH sides. Commands/protocol: commands.md. Full acceptance mapping: acceptance.md.

Remaining actual gates: queued compile/focused +unfiltered JVM/JS/Wasm/macOS correctness including all serialization/subtype/537 fixtures; actual per-case small/wide transient/retained/runtime data, extra wide-field cost, Wasm owned graph visibility/coverage proof; independent aggregation/acceptance; coordinator integration/closure. No task completion claim.

597 source composition: frozen17b3402 retained under refs/codex-evidence/529-pre-597-composition. Rebased clean fourcommitstack ontoaccepted e4bb2ab ->e74ee38; six conflicts in BI/BD resolved with597 cache/table/MINgates and538 once-per-session exponent materialization. Separate537numericcommit4d1a570 retains original6176a3b stablepatch-id e82d3dcbc90a25a359be2542093298eda79f0bce;537owner new2b461b6 algorithm unchanged, optional-time scriptfollowup notyetcomposed. Current source review manifestcomposition-source-review.json; no compile/runtime.535ingestion and newMC34/freshaccumulator diagnostics pendingpeerreview.

Source checkpoint committed ec9afe6 (535ingestion/tests/carrier/MC34diagnostic), separate537optional-timefollowup a054554. Earlyproductioncomposition coordinatorSOURCEPASS inindependent-597-535-early-composition.json. AllUNCOMPILED/UNRUN; methoddelta527 pending. Final537acceptance/mainrebase and matchedparentartifact binding stillmandatory.

Exact537 writerfix519a757 source-composed by clean cherry-pick f9b36b5; no conflict ormanualwriteredit. Prior529 a054554 preserved refs/codex-evidence/529-pre-537-writer-fix. Existing529 exactBD/tag2subtype guard already precedes canonicalstringCache, so nocompactcoefficientboxing added. SharedNumericOutput unchangedfromreviewed537; source-onlypeerreviewpending manifestwriter-537-composition-review.json. Finalaccepted537mainrebase+parentbinding/runtime stillpending.
