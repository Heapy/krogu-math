from pathlib import Path
p=Path('src/commonMain/kotlin/io/heapy/krogu/math/BigInteger.kt');s=p.read_text()
a=s.index('        private class ParsedMagnitude537 {');b=s.index('\n        private fun invalidIntegerDigit',a)
s=s[:a]+'''        private class ParsedMagnitude537 {
            private var compactNegative = 0L
            private var wide: IntArray? = null
            private var size = 0
            fun bits(): Int = wide?.let { if (size == 0) 0 else (size - 1) * LIMB_BITS + 32 - it[size - 1].countLeadingZeroBits() }
                ?: CompactInteger529.magnitudeBits(compactNegative)
            fun multiplyAdd(power: Int, block: Int) {
                var words = wide
                if (words == null) {
                    // Check both operations before evaluating them in the negative domain.
                    // power > 0 and 0 <= block < power; MIN is an ordinary payload.
                    if (compactNegative >= Long.MIN_VALUE / power) {
                        val product = compactNegative * power
                        if (product >= Long.MIN_VALUE + block) {
                            compactNegative = product - block
                            return
                        }
                    }
                    val magnitude = CompactInteger529.magnitude((compactNegative shr 32).toInt(), compactNegative.toInt())
                    size = magnitude.size
                    words = magnitude.copyOf(maxOf(4, size + 1))
                    wide = words
                }
                var carry = block.toLong()
                for (index in 0 until size) {
                    val part = words[index].toLong() * power + carry
                    words[index] = (part and MASK).toInt()
                    carry = part ushr LIMB_BITS
                }
                while (carry != 0L) {
                    if (size == words.size) {
                        val next = minOf((Int.MAX_VALUE.toLong() + LIMB_BITS - 1) / LIMB_BITS,
                            words.size.toLong() * 2).toInt()
                        if (next == words.size) throw ArithmeticException("BigInteger overflow")
                        words = words.copyOf(next)
                        wide = words
                    }
                    words[size++] = (carry and MASK).toInt()
                    carry = carry ushr LIMB_BITS
                }
                if (size > 0) MagnitudeLimits.checkedBitLength(size, words[size - 1])
            }
            fun publish(sign: Int): BigInteger {
                val words = wide
                if (words != null) return normalized(sign, words.copyOf(size))
                return if (sign < 0) valueOf(compactNegative)
                    else if (compactNegative == Long.MIN_VALUE) BigInteger(1, intArrayOf(0, 0, 8))
                    else valueOf(-compactNegative)
            }
            fun publishDecimal(sign: Int, scale: Int): BigDecimal {
                if (wide == null && (sign < 0 || compactNegative != Long.MIN_VALUE))
                    return BigDecimal.valueOf(if (sign < 0) compactNegative else -compactNegative, scale)
                return BigDecimal(publish(sign), scale)
            }
        }
''' +s[b:]
# Share the validated prefix reader; only publication differs for decimal consumers.
a=s.index('        internal fun decimalPrefix537(');b=s.index('\n        private fun parse(value: NumericText537',a);t=s[a:b]
t=t.replace('''            val builder = ParsedMagnitude537()
''','''            return decimalPrefixBuilder529(value, first, digits).publish(sign)
        }

        @kotlin.jvm.JvmSynthetic
        internal fun decimalValuePrefix529(value: NumericText537, first: Int, digits: Int, sign: Int, scale: Int): BigDecimal =
            decimalPrefixBuilder529(value, first, digits).publishDecimal(sign, scale)

        private fun decimalPrefixBuilder529(value: NumericText537, first: Int, digits: Int): ParsedMagnitude537 {
            val builder = ParsedMagnitude537()
''',1).replace('            return builder.publish(sign)','            return builder',1)
s=s[:a]+t+s[b:]
# Primitive chunk writer; output chunks are the writer's representation, not BI storage.
a=s.index('    internal fun radixDigits537(');i=s.index('        val upperBits =',a);s=s[:i]+'''        if (representation == 1) return compactRadixDigits529(compactStoredValue529(), radix, maxDigits)
        val words = wideWords!!
'''+s[i:]
pos=s.index('        private fun parse(value: String, radix: Int)');s=s[:pos]+'''        @kotlin.jvm.JvmSynthetic
        internal fun compactRadixDigits529(value: Long, radix: Int, maxDigits: Long? = null): RadixDigits537 {
            var power = radix
            var width = 1
            while (power.toLong() * radix <= Int.MAX_VALUE) { power *= radix; width++ }
            var negative = if (value > 0) -value else value
            val chunks = IntArray(3)
            var size = 0
            do {
                chunks[size++] = -(negative % power).toInt()
                negative /= power
            } while (negative != 0L)
            val result = RadixDigits537(chunks, size, radix, width)
            checkTextLimit537(result.length, maxDigits)
            return result
        }

'''+s[pos:];p.write_text(s)
p=Path('src/commonMain/kotlin/io/heapy/krogu/math/BigDecimal.kt');s=p.read_text()
s=s.replace('this::class != BigDecimal::class || coefficient::class != BigInteger::class', 'this::class != BigDecimal::class || (representation == 2 && wideCoefficient!!::class != BigInteger::class)')
a=s.index('    private fun textLayout537(');b=s.index('\n    }',a);t=s[a:b].replace('val sign = coefficient.signum()', 'val sign = storedSign529()').replace('val lowerDigits = coefficient.decimalDigitLowerBound().toLong()', 'val lowerDigits = if (representation == 1) CompactInteger529.decimalDigits(compactValue529()).toLong()\n            else wideCoefficient!!.decimalDigitLowerBound().toLong()').replace('val digits = coefficient.radixDigits537(10, maxChars?.minus(prefix))', '''val digits = if (representation == 1) BigInteger.compactRadixDigits529(compactValue529(), 10, maxChars?.minus(prefix))
            else wideCoefficient!!.radixDigits537(10, maxChars?.minus(prefix))''');s=s[:a]+t+s[b:];p.write_text(s)
p=Path('src/commonMain/kotlin/io/heapy/krogu/math/DecimalText588.kt');s=p.read_text().replace('return BigDecimal(BigInteger.decimalPrefix537(input, lexical.first, kept.toInt(), lexical.sign), lexical.scale)', 'return BigInteger.decimalValuePrefix529(input, lexical.first, kept.toInt(), lexical.sign, lexical.scale)');p.write_text(s)
