# Source9641a95 measured stage (not final task acceptance)

Candidate9641a959a591a3265a24e17ab4250d63959d6c5f, JARc655942a6bea80d8e5fe403d662ed969075d4e6a2dac4f993e7a29871f4a3434; baseline acceptedf8565cae98081ff0121ce7a40919d8a4cfd92013, JARf54132036bcd7b0fa4cda473a1576cb715a7356e4fbdb188f0d650d32735397c. Same-host paired results; shared AppleM4Max host/no CPU isolation, toolchains pinned. No current-source/JDK comparison is implied: this is old Krogu versus candidate Krogu.

Focused correctness159 PASS (60 JVM+33 each JS/Wasm/macOS) was followed by full suite45317: JVM683 methods,12 failures,0errors/skips; other targets not reached. These are observable publication-identity regressions, retained in logs/full-regression-initial-jvm-failure. A proportional identity fix is under source review; NONE of these measurements are silently relabelled as later source.

Three alternating fresh process pairs, seven samples per process. Tables show median of process medians, full three-process range and paired candidate/baseline ratios. All adverse results are retained; ratios include harness overhead. JVM allocated bytes are transient bytes/op; other platforms report NA. Setup/compilation/checks outside timing. Default527 dataset unchanged; originalMC34 control is its unchanged16-pair MC34/HALF_EVEN fixture, separate from MC7 compact division. Fresh535 includes constructor+2adds+snapshot.

## JVM33

Handle93667 terminal0; owner summary `jvm-paired-4-summary.json`. Independent raw/graphs/binding PASS,1386 TIME rows/33cases, fresh-root graph and full representation checks.

| Case | Baseline ns [min,max] | Candidate ns [min,max] | Ratio | Paired ratios | Alloc B/op old→new |
|---|---:|---:|---:|---|---:|
| decimal/accumulator-compact-fresh | 694.771 [689.535,725.232] | 740.134 [428.023,1199.730] | 1.065 | 1.073/0.616/1.654 | 1880.5→1792 |
| decimal/add-small | 31.350 [31.113,31.542] | 5.129 [5.129,9.019] | 0.164 | 0.165/0.164/0.286 | 264→40 |
| decimal/create-min | 6.827 [6.788,6.830] | 3.471 [3.434,5.596] | 0.508 | 0.503/0.511/0.819 | 88→40 |
| decimal/create-small | 7.977 [7.961,8.222] | 3.734 [3.721,6.051] | 0.468 | 0.468/0.453/0.760 | 112→40 |
| decimal/divide-context | 100.175 [99.333,111.599] | 33.795 [33.719,53.326] | 0.337 | 0.337/0.340/0.478 | 410.5→45 |
| decimal/divide-scaled | 36.472 [35.890,48.785] | 14.776 [14.536,21.880] | 0.405 | 0.405/0.405/0.448 | 273→64 |
| decimal/metadata | 3.153 [3.122,3.480] | 3.120 [3.100,4.875] | 0.990 | 0.983/0.897/1.561 | 0→0 |
| decimal/multiply-small | 13.548 [13.243,13.752] | 4.919 [4.830,7.559] | 0.363 | 0.363/0.351/0.571 | 112→40 |
| decimal/original527-mc34-divide | 179.080 [175.933,180.770] | 184.281 [181.737,323.203] | 1.029 | 1.047/1.015/1.788 | 610→666 |
| decimal/parse-rounded | 66.210 [64.995,66.536] | 56.228 [55.510,92.581] | 0.849 | 0.849/0.854/1.391 | 344→184 |
| decimal/parse-small | 88.773 [86.955,89.933] | 49.456 [49.295,78.277] | 0.557 | 0.567/0.550/0.882 | 216→184 |
| decimal/round | 17.311 [17.306,27.108] | 9.090 [9.076,13.400] | 0.525 | 0.525/0.524/0.494 | 160→40 |
| decimal/setScale | 16.100 [15.197,23.739] | 5.893 [5.851,8.736] | 0.366 | 0.363/0.388/0.368 | 136→40 |
| decimal/strip | 20.918 [20.605,30.010] | 8.098 [8.086,11.708] | 0.387 | 0.387/0.393/0.390 | 328→40 |
| decimal/subtract-small | 28.445 [28.257,28.781] | 5.187 [5.057,8.950] | 0.182 | 0.180/0.178/0.317 | 232→40 |
| decimal/wide-add | 91.310 [86.767,153.823] | 60.002 [59.932,74.034] | 0.657 | 0.656/0.692/0.481 | 632→664 |
| decimal/wide-create | 3.879 [3.827,7.122] | 4.010 [3.943,5.322] | 1.034 | 1.034/1.030/0.747 | 32→40 |
| decimal/wide-divide | 1913.684 [1911.423,2340.159] | 1783.442 [1777.692,2051.661] | 0.932 | 0.929/0.933/0.877 | 7533.5→6650.5 |
| decimal/wide-multiply | 870.032 [866.529,1243.963] | 915.068 [906.649,1196.679] | 1.052 | 1.052/1.046/0.962 | 3680→3520 |
| decimal/wide-round | 279.692 [276.111,336.558] | 260.898 [260.280,276.849] | 0.933 | 0.931/0.945/0.823 | 1568→1344 |
| integer/add-small | 9.389 [9.168,9.471] | 4.543 [4.524,5.368] | 0.484 | 0.480/0.482/0.586 | 80→32 |
| integer/create-min | 4.976 [4.771,5.234] | 2.123 [2.121,2.578] | 0.427 | 0.426/0.406/0.540 | 56→32 |
| integer/create-small | 8.126 [7.362,8.152] | 2.215 [2.178,2.734] | 0.273 | 0.272/0.268/0.371 | 80→32 |
| integer/demote | 7.525 [7.523,7.690] | 4.899 [4.790,7.596] | 0.651 | 0.623/0.651/1.010 | 56→32 |
| integer/divide-min-overflow | 8.754 [8.735,8.871] | 5.767 [5.537,8.934] | 0.659 | 0.650/0.632/1.023 | 56→64 |
| integer/metadata | 3.283 [3.274,3.327] | 3.357 [3.119,5.124] | 1.023 | 1.009/0.953/1.561 | 0→0 |
| integer/multiply-small | 11.414 [11.242,11.708] | 5.527 [5.448,8.072] | 0.484 | 0.484/0.485/0.689 | 80→32 |
| integer/parse-small | 61.365 [60.380,61.642] | 33.866 [33.724,41.848] | 0.552 | 0.552/0.547/0.693 | 136→128 |
| integer/promote | 9.497 [9.452,9.544] | 6.028 [5.674,10.486] | 0.635 | 0.638/0.597/1.099 | 88→64 |
| integer/subtract-small | 7.429 [7.336,7.547] | 4.305 [4.224,5.650] | 0.579 | 0.570/0.576/0.760 | 48→32 |
| integer/wide-add | 18.971 [18.429,19.062] | 16.751 [15.776,25.576] | 0.883 | 0.909/0.828/1.348 | 200→208 |
| integer/wide-divide | 153.495 [152.835,155.544] | 157.673 [151.285,254.917] | 1.027 | 0.986/1.032/1.639 | 296→304 |
| integer/wide-multiply | 157.102 [152.963,157.402] | 161.528 [154.317,275.341] | 1.028 | 1.026/1.009/1.753 | 328→336 |

## JS21

Handle83323 terminal0; owner summary `portable-js-2-summary.json`. Independent TIME/CHECK/binding PASS; all three strict retained-payload checkers exit3. Global deltas remain FAILED/UNVERIFIED; actual owned graphs below are a separate validated method.

| Case | Baseline ns [min,max] | Candidate ns [min,max] | Ratio | Paired ratios | Alloc B/op old→new |
|---|---:|---:|---:|---|---:|
| decimal/accumulator-compact-fresh | 13777.283 [11257.040,21666.911] | 21122.721 [16357.056,23747.803] | 1.533 | 2.110/0.975/1.187 | NA |
| decimal/add-small | 2009.595 [1221.761,2010.460] | 316.957 [290.063,342.400] | 0.158 | 0.259/0.170/0.144 | NA |
| decimal/create-min | 567.921 [408.618,573.393] | 29.412 [21.619,46.938] | 0.052 | 0.072/0.082/0.038 | NA |
| decimal/create-small | 550.315 [450.707,643.017] | 49.362 [37.960,85.836] | 0.090 | 0.084/0.077/0.156 | NA |
| decimal/divide-context | 13475.505 [11260.885,17177.165] | 14447.245 [9925.903,17294.719] | 1.072 | 1.283/1.007/0.737 | NA |
| decimal/metadata | 62.451 [37.595,88.002] | 14.033 [9.610,16.673] | 0.225 | 0.373/0.267/0.109 | NA |
| decimal/multiply-small | 862.671 [516.632,957.846] | 483.767 [369.586,808.141] | 0.561 | 0.715/0.844/0.561 | NA |
| decimal/original527-mc34-divide | 19003.886 [16300.619,27066.366] | 30733.968 [28249.837,40541.666] | 1.617 | 1.885/1.498/1.487 | NA |
| decimal/round | 1794.482 [1290.853,2294.317] | 1509.410 [1351.929,1733.101] | 0.841 | 1.169/0.755/0.753 | NA |
| decimal/setScale | 1875.641 [1176.793,2089.437] | 1019.329 [753.337,1656.311] | 0.543 | 0.640/0.793/0.543 | NA |
| decimal/wide-add | 7409.973 [4507.589,7466.970] | 9186.320 [6729.055,9348.511] | 1.240 | 2.038/1.252/0.908 | NA |
| decimal/wide-create | 65.685 [41.829,66.999] | 93.100 [58.085,112.160] | 1.417 | 2.681/1.417/0.867 | NA |
| decimal/wide-divide | 315158.859 [239788.414,381330.078] | 364833.328 [254074.875,469795.562] | 1.158 | 1.060/1.491/0.957 | NA |
| decimal/wide-multiply | 106557.938 [69556.803,119331.383] | 104508.949 [95476.238,132739.910] | 0.981 | 1.502/1.246/0.800 | NA |
| integer/add-small | 382.941 [380.063,419.849] | 298.129 [205.483,320.142] | 0.779 | 0.763/0.784/0.537 | NA |
| integer/create-min | 499.614 [441.301,510.080] | 79.041 [62.413,84.319] | 0.158 | 0.158/0.165/0.141 | NA |
| integer/create-small | 490.721 [445.864,568.718] | 152.497 [122.431,179.841] | 0.311 | 0.403/0.268/0.249 | NA |
| integer/multiply-small | 719.381 [670.015,739.292] | 452.833 [368.698,869.508] | 0.629 | 1.176/0.550/0.629 | NA |
| integer/wide-add | 1325.094 [1304.502,1342.183] | 1324.715 [886.665,1542.033] | 1.000 | 1.000/1.149/0.680 | NA |
| integer/wide-divide | 16072.347 [14830.505,20221.720] | 11585.449 [11177.612,20185.953] | 0.721 | 1.361/0.573/0.695 | NA |
| integer/wide-multiply | 31553.549 [31249.063,45598.227] | 32295.613 [21527.466,34866.699] | 1.024 | 1.033/0.765/0.682 | NA |

## Wasm21

Handle86653 terminal0; owner summary `portable-wasm-1-summary.json`. Independent TIME/CHECK/binding PASS; all three strict controls pass. Runtime slopes remain distinct from owned graphs.

| Case | Baseline ns [min,max] | Candidate ns [min,max] | Ratio | Paired ratios | Alloc B/op old→new |
|---|---:|---:|---:|---|---:|
| decimal/accumulator-compact-fresh | 1699.847 [1612.439,2312.884] | 1621.096 [1431.857,2324.804] | 0.954 | 0.842/1.005/1.005 | NA |
| decimal/add-small | 240.834 [215.099,333.479] | 44.283 [32.431,52.473] | 0.184 | 0.135/0.206/0.157 | NA |
| decimal/create-min | 45.899 [36.818,61.583] | 21.784 [16.707,29.645] | 0.475 | 0.454/0.475/0.481 | NA |
| decimal/create-small | 42.529 [34.932,71.954] | 20.206 [16.241,22.450] | 0.475 | 0.382/0.281/0.643 | NA |
| decimal/divide-context | 615.404 [550.359,723.214] | 207.361 [178.881,243.681] | 0.337 | 0.291/0.377/0.337 | NA |
| decimal/metadata | 36.433 [32.382,43.972] | 20.844 [18.099,26.113] | 0.572 | 0.559/0.572/0.594 | NA |
| decimal/multiply-small | 99.161 [87.985,113.990] | 40.914 [32.356,48.332] | 0.413 | 0.326/0.465/0.424 | NA |
| decimal/original527-mc34-divide | 748.769 [741.249,1108.215] | 681.386 [657.705,775.551] | 0.910 | 0.887/0.910/0.700 | NA |
| decimal/round | 121.051 [97.546,161.027] | 48.338 [47.972,76.720] | 0.399 | 0.396/0.496/0.476 | NA |
| decimal/setScale | 154.398 [105.276,154.584] | 51.085 [46.748,64.280] | 0.331 | 0.444/0.330/0.416 | NA |
| decimal/wide-add | 532.407 [449.472,1474.945] | 308.243 [307.201,348.344] | 0.579 | 0.683/0.579/0.236 | NA |
| decimal/wide-create | 33.061 [29.503,38.855] | 40.460 [33.289,62.879] | 1.224 | 1.128/1.224/1.618 | NA |
| decimal/wide-divide | 7354.940 [6529.561,10065.735] | 5687.612 [4767.217,7705.852] | 0.773 | 0.730/0.773/0.766 | NA |
| decimal/wide-multiply | 4043.711 [3637.680,5565.125] | 2841.227 [2836.929,7602.834] | 0.703 | 0.780/0.703/1.366 | NA |
| integer/add-small | 58.544 [53.338,68.120] | 34.660 [28.301,42.533] | 0.592 | 0.650/0.483/0.624 | NA |
| integer/create-min | 30.497 [27.183,30.876] | 22.176 [21.207,25.800] | 0.727 | 0.816/0.695/0.836 | NA |
| integer/create-small | 38.692 [31.244,45.353] | 23.744 [23.223,25.891] | 0.614 | 0.760/0.600/0.571 | NA |
| integer/multiply-small | 79.965 [71.434,80.587] | 36.265 [31.611,36.556] | 0.454 | 0.512/0.395/0.450 | NA |
| integer/wide-add | 120.481 [107.407,122.783] | 127.905 [126.038,144.413] | 1.062 | 1.062/1.345/1.027 | NA |
| integer/wide-divide | 277.281 [265.844,333.574] | 352.882 [289.698,494.191] | 1.273 | 1.090/1.273/1.482 | NA |
| integer/wide-multiply | 615.428 [608.971,773.112] | 617.393 [498.479,700.150] | 1.003 | 0.810/1.014/0.906 | NA |

## Native21

Handle18398 terminal0; owner summary `portable-native-1-summary.json`. Independent TIME/CHECK audit pending; all three strict retained-payload checkers exit3, so retained slope coverage FAILED/UNVERIFIED.

| Case | Baseline ns [min,max] | Candidate ns [min,max] | Ratio | Paired ratios | Alloc B/op old→new |
|---|---:|---:|---:|---|---:|
| decimal/accumulator-compact-fresh | 1597.453 [1401.550,2060.631] | 2436.124 [2320.791,2541.555] | 1.525 | 1.591/1.738/1.126 | NA |
| decimal/add-small | 247.128 [221.116,279.673] | 52.617 [51.883,60.363] | 0.213 | 0.235/0.244/0.188 | NA |
| decimal/create-min | 73.416 [72.679,78.245] | 24.431 [24.173,25.766] | 0.333 | 0.333/0.329/0.333 | NA |
| decimal/create-small | 71.269 [53.207,113.982] | 24.850 [22.666,27.599] | 0.349 | 0.349/0.519/0.199 | NA |
| decimal/divide-context | 640.896 [619.359,733.906] | 270.950 [253.392,306.145] | 0.423 | 0.409/0.417/0.423 | NA |
| decimal/metadata | 27.644 [25.959,31.219] | 21.347 [18.039,23.824] | 0.772 | 0.763/0.822/0.653 | NA |
| decimal/multiply-small | 133.933 [106.091,191.836] | 41.884 [41.564,45.574] | 0.313 | 0.395/0.238/0.310 | NA |
| decimal/original527-mc34-divide | 731.494 [722.743,912.587] | 1021.369 [674.215,1036.625] | 1.396 | 1.396/1.434/0.739 | NA |
| decimal/round | 181.246 [164.298,243.476] | 71.493 [67.295,87.324] | 0.394 | 0.294/0.531/0.371 | NA |
| decimal/setScale | 153.155 [151.707,445.314] | 87.555 [68.692,149.103] | 0.572 | 0.335/0.449/0.577 | NA |
| decimal/wide-add | 372.293 [353.043,404.865] | 441.619 [206.638,456.802] | 1.186 | 1.128/0.555/1.251 | NA |
| decimal/wide-create | 34.519 [25.435,37.626] | 38.630 [32.549,96.420] | 1.119 | 3.791/1.027/0.943 | NA |
| decimal/wide-divide | 9150.828 [8327.983,10311.195] | 8196.228 [7147.715,9182.515] | 0.896 | 0.858/0.795/1.003 | NA |
| decimal/wide-multiply | 3045.665 [2233.866,3470.866] | 3831.965 [3172.211,4520.747] | 1.258 | 1.258/1.420/1.302 | NA |
| integer/add-small | 58.912 [50.622,68.323] | 42.796 [42.571,51.593] | 0.726 | 0.723/1.019/0.626 | NA |
| integer/create-min | 42.895 [34.255,44.468] | 37.743 [32.726,38.027] | 0.880 | 1.110/0.763/0.849 | NA |
| integer/create-small | 53.754 [49.949,92.397] | 31.540 [25.421,32.006] | 0.587 | 0.595/0.509/0.341 | NA |
| integer/multiply-small | 68.814 [62.102,88.448] | 45.360 [42.499,63.290] | 0.659 | 1.019/0.659/0.480 | NA |
| integer/wide-add | 83.989 [65.584,104.057] | 116.886 [102.970,121.083] | 1.392 | 1.442/1.782/0.990 | NA |
| integer/wide-divide | 343.573 [302.359,397.589] | 421.364 [318.469,482.584] | 1.226 | 1.053/1.405/1.060 | NA |
| integer/wide-multiply | 504.716 [431.114,1107.437] | 452.777 [442.155,456.634] | 0.897 | 1.026/0.905/0.409 | NA |

## Retained graph and shared cache boundaries

Actual fresh9641 candidate8-phase JS and8-phase Wasm snapshots against unchanged baseline snapshots independently PASS. Carrier→256 distinct uncached roots, exact owned field/array/backing edges and exclusive strong closure verified; Byte256/Int64 versusByte0 controls show exact256B contrast. Runtime/class/static metadata/shared objects excluded only after independent external-root proof. Per-number cohort averages below are not universal wide object sizes.

| Method | BI small | BD small | BI wide | BD wide |
|---|---:|---:|---:|---:|
| JVM identity-reachable owned graph B/root |48→32|80→40|104→112|136→152|
| JS strong owned cohort B/root |264→96|320→96|331.5→371.5|387.5→467.5|
| Wasm strong owned cohort B/root |144→72|216→80|203→219|275→299|

JVM MIN/MAX BI56→32, BD MIN88→40. JVM wide array80B is shallow including header/alignment, not raw payload. JS root56+PropertyArray40=96 for compact roots; wide+40/+80B and Wasm wide+16/+24B are explicit costs. Equal carrier2096B JS/2128B Wasm excluded. Primitive element contents can be opaque in snapshots; full numeric CHECKs are separate.

New private19-cell negative-power cache has152B logical raw payload, not total heap. JVM actual cache array168B shallow, associated helper INSTANCE16B separate; JS actual strong cache1072B (19Long760+Array32+elements168+PropertyArray40+exclusiveMap72), associated helper96B shallow separate; Wasm cache232B(wrapper56+backing176), associated helper64B separate. Associated helper size is not incremental cache-only owner growth. Cache globally rooted and excluded per-number. Native152B is modelled logical cells only; native headers/helper total remain unmeasured. Native wholeheap GC deltas failed coverage and cannot supply retained bytes/root.

Bindings/audits: independent-jvm-fourth-raw-graph-audit.json; independent-portable-js-2-raw-audit.json; independent-portable-wasm-raw-audit.json; independent-9641-owned-graph-report.md and per-platform audit JSON; independent-9641-cache-domination-audit.json; independent-shared-cache-observer-actual-audit.json. Historical ef3db6c/earlier campaigns retain their source identities and adverse observations.
