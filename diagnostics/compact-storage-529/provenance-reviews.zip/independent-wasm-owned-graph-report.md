#529 independent actual Wasm owned graph audit

Status: PASS for the sixteen frozen snapshots from actual baseline capture 72963 and candidate capture 77759 (both owner-confirmed terminal exit 0). Analysis processes 91014 and 88132 both terminated with exit 0; the reserved heavy slot was explicitly released before JS campaign 23960. No extra capture or numerical rerun was performed.

The machine ledger is [independent-wasm-owned-graph-audit.json](independent-wasm-owned-graph-audit.json). It records raw/recovered gzip SHA256, schema-derived node and edge traversal, module-global mapping, actual instance/global/carrier/root node IDs and root paths, explicit storage edges, node unions, shared exclusions and control results. [final-wasm-graph-layout-metadata.json](final-wasm-graph-layout-metadata.json) binds each final module's actual type/field/global names and binary-derived reference-global ordinal.

| Fresh cohort | Baseline owned bytes / root | Candidate owned bytes / root | Difference |
| --- | ---: | ---: | ---: |
| Integer small | 144 | 72 | -72 |
| Integer wide | 203 | 219 | +16 |
| Decimal small | 216 | 80 | -136 |
| Decimal wide | 275 | 299 | +24 |

These are identity-deduplicated numeric/array owned cohort totals divided by 256. Wide cohorts contain sixteen repeated numerical identities represented by 256 distinct fresh objects; their limb lengths/alignment can differ. The wide figures are cohort averages, not universal exact sizes of every wide object. Per-type shallow totals and actual node IDs are in the ledger. The candidate small graphs contain only each numeric root; the baseline graphs additionally retain coefficient/magnitude wrappers and backing arrays.

Each equal-length carrier (Kotlin Array plus its WasmAnyArray backing) occupies 2,128 bytes and is reported separately. The Unit phase has 256 references to one externally shared singleton, excluded from numeric owned bytes. Candidate integer roots have 72-byte shallow size; that fact alone was not used as an owned-size proof.

## Ownership and payload proof

The binary global table was independently parsed: baseline retained529 global 548 has reference-global ordinal 531; candidate global 550 has ordinal 533. Seventeen preceding numeric/nonreference globals explain the difference. This matches the actual WasmTrustedInstanceData -> tagged_globals_buffer -> reference-slot -> Kotlin Array -> storage -> 256 elements path. Type IDs happen to match between these two modules, but their field layouts differ and are taken from each module separately.

Every numeric/array phase has 256 distinct expected roots. The analysis follows only explicit numeric coefficient/magnitude and primitive-array storage fields, validates compact scalar/tag/scale/cache state where exposed, and records all owned references. Removing the carrier and traversing the complete snapshot from root 0 through every non-weak edge leaves none of the numeric or array graph nodes reachable. This proves exclusive strong ownership within the observed snapshot graph. All excluded nonzero-size vtable/itable/rtti/map nodes remain strongly reachable without the carrier; their shared exclusion is checked, not assumed.

The controls independently expose actual primitive-array payload: ByteArray(0) graph is 80 bytes/root, ByteArray(256) and IntArray(64) graphs are each 336 bytes/root in both implementations. Both observed contrasts are exactly 256 bytes/root. Their backing nodes and storage edges are visible. Shallow node sizes include headers/alignment; the contrasts expose payload bytes rather than relabelling complete array size as raw payload.

V8 exposes zero-size synthetic nodes for scalar field values. They are not counted as physical boxed objects. It exposes primitive-array backing nodes/type/self_size but does not expose their individual primitive elements or array length in these snapshots. No missing element values were invented. Compact scalar values are checked directly; wide numerical results are separately validated by the source-bound paired CHECK inventories. Array-control source identities plus observed backing-size contrasts establish payload coverage.

## Limits

This result describes V8 13.6.233.17-node.49 on pinned Node 24.16.0, final modules 30b35e57... (baseline) and c70de5ca... (candidate), and these specific 256-root cohorts. It is not JVM header sizing, process RSS, whole-runtime heap delta, transient allocation, peak memory or a promise about every numeric value. Shared runtime metadata and carrier costs remain explicit. The separate portable retained-batch slopes and arithmetic campaign have their own measurements and uncertainty.

The finite traversal caps were 4,096 owned object/array nodes and 16 MiB owned bytes per phase; no truncation occurred. Actual numeric phase unions contain at most 1,024 owned nodes. Sixteen snapshots were parsed sequentially, not retained together in memory.

## Verbatim reproduction commands

Run from the project root with the recorded frozen artifact trees, captures and final module layout ledger restored at their recorded paths. These inline Python commands are retained as analysis notes, not installed standalone project tooling. The first recomputes binary global/reference-slot correspondence; the second verifies raw hashes and repeats schema/root/edge/ownership/control analysis. It rewrites only task-owned analysis ledgers. The owner may package an equivalent reviewed .main.kts analyzer; no numerical implementation is involved.

```bash
python3 - <<'PY'
from pathlib import Path
import json
p=Path('.codex-work/529'); meta=json.loads((p/'final-wasm-graph-layout-metadata.json').read_text())
for label in ['baseline','candidate']:
 b=Path(meta['modules'][label]['artifact']).read_bytes(); globaltypes=[]
 def leb(i):
  n=0;s=0
  while True:
   v=b[i];i+=1;n|=(v&127)<<s
   if v<128:return n,i
   s+=7
 def skipstr(i):n,i=leb(i);return i+n
 def val(i):
  c=b[i];i+=1
  if c in [0x63,0x64]: _,i=leb(i)
  return c not in [0x7f,0x7e,0x7d,0x7c,0x7b],i
 def limits(i):
  flags,i=leb(i);_,i=leb(i)
  if flags&1:_,i=leb(i)
  return i
 i=8; ins={}
 while i<len(b):
  tag=b[i];i+=1;n,i=leb(i);end=i+n
  if tag==2:
   count,k=leb(i)
   for z in range(count):
    k=skipstr(skipstr(k));kind=b[k];k+=1
    if kind==0:_,k=leb(k)
    elif kind==1:_,k=val(k);k=limits(k)
    elif kind==2:k=limits(k)
    elif kind==3:r,k=val(k);k+=1;globaltypes.append(r)
    elif kind==4:k+=1;_,k=leb(k)
    else:raise Exception(('importkind',kind))
   assert k==end
  if tag==6:
   count,k=leb(i)
   for z in range(count):
    r,k=val(k);k+=1;globaltypes.append(r)
    while True:
     op=b[k];k+=1;ins[hex(op)]=ins.get(hex(op),0)+1
     if op==0x0b:break
     elif op in [0x41,0x42,0x23,0xd0,0xd2]:_,k=leb(k)
     elif op==0x43:k+=4
     elif op==0x44:k+=8
     elif op==0xfb:
      sub,k=leb(k);ins['gc'+str(sub)]=ins.get('gc'+str(sub),0)+1
      if sub in [0,1,6,7]:_,k=leb(k)
      elif sub in [8,9,10]:_,k=leb(k);_,k=leb(k)
      elif sub in [26,27,28]:pass
      else:raise Exception(('GC initializer subop',sub,z,k))
     elif op in [0x6a,0x6b,0x6c,0x7c,0x7d,0x7e]:pass
     else:raise Exception(('initializeropcode',hex(op),z,k))
   assert k==end
  i=end
 target=int(next(iter(meta['modules'][label]['retained_global']))); assert globaltypes[target]; ordinal=sum(globaltypes[:target]); print(label,'global',target,'taggedrefordinal',ordinal,'totalglobals',len(globaltypes),'nonrefs_before',target-ordinal,'initops',ins)
 meta['modules'][label]['retained_global_ref_ordinal']=ordinal;meta['modules'][label]['global_mapping_proof']={'global_index':target,'reference_globals_before':ordinal,'nonreference_globals_before':target-ordinal,'total_globals':len(globaltypes),'initializer_opcodes':ins,'method':'Independent binary import/global-section value-type counting; validated complete section consumption and known initializer opcodes. Zero-based reference-global ordinal correlates V8 tagged_globals_buffer index.'}
(p/'final-wasm-graph-layout-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
PY
```

```bash
python3 - <<'PY'
from pathlib import Path
import gzip,json,hashlib,collections,time
P=Path('.codex-work/529'); metadata=json.loads((P/'final-wasm-graph-layout-metadata.json').read_text()); phases=['unit','integer_small','integer_wide','decimal_small','decimal_wide','control_bytes0','control_bytes256','control_ints64']; reports=[]
for label in ['baseline','candidate']:
 folder=P/f'wasm-heap-{label}-1'; summary=json.loads((folder/'snapshot-summary.json').read_text()); assert summary['node']=='v24.16.0' and summary['rootCount']==256; assert [x['phase'] for x in summary['phases']]==phases
 ordinal=metadata['modules'][label]['retained_global_ref_ordinal']
 for phase in phases:
  led=next(x for x in summary['phases'] if x['phase']==phase); path=folder/(led['file']+'.gz'); compressed=path.read_bytes(); raw=gzip.decompress(compressed); rawsha=hashlib.sha256(raw).hexdigest(); assert rawsha==led['sha256'] and len(raw)==led['bytes']; D=json.loads(raw); del raw
  m=D['snapshot']['meta']; nf=m['node_fields']; ef=m['edge_fields']; N=D['nodes']; E=D['edges']; S=D['strings']; nw=len(nf); ew=len(ef); assert len(N)%nw==0 and len(E)%ew==0
  nt=nf.index('type'); nn=nf.index('name'); ns=nf.index('self_size'); nc=nf.index('edge_count'); et=ef.index('type'); en=ef.index('name_or_index'); eto=ef.index('to_node'); types=m['node_types'][nt]; ets=m['edge_types'][et]; number=len(N)//nw
  names=[S[N[i*nw+nn]] for i in range(number)]; sizes=[N[i*nw+ns] for i in range(number)]; starts=[]; pos=0
  for i in range(number): starts.append(pos);pos+=N[i*nw+nc]*ew
  assert pos==len(E)
  def edges(i):
   at=starts[i]
   for k in range(N[i*nw+nc]):
    off=at+k*ew; kind=ets[E[off+et]]; v=E[off+en]; target=E[off+eto]; assert target%nw==0 and 0<=target<len(N)
    yield (kind,v if kind in ['element','hidden'] else S[v],target//nw)
  def prop(i,name):
   x=[to for kind,key,to in edges(i) if key==name]; assert len(x)==1,(label,phase,i,name,x); return x[0]
  def els(i):return {int(key):to for kind,key,to in edges(i) if kind=='element'}
  expected={'unit':'$kotlin.Unit (wasm)','integer_small':'$io.heapy.krogu.math.BigInteger (wasm)','integer_wide':'$io.heapy.krogu.math.BigInteger (wasm)','decimal_small':'$io.heapy.krogu.math.BigDecimal (wasm)','decimal_wide':'$io.heapy.krogu.math.BigDecimal (wasm)','control_bytes0':'$kotlin.ByteArray (wasm)','control_bytes256':'$kotlin.ByteArray (wasm)','control_ints64':'$kotlin.IntArray (wasm)'}[phase]
  candidates=[]
  for i,name in enumerate(names):
   if name=='system / WasmTrustedInstanceData':
    for kind,key,buffer in edges(i):
     if key=='tagged_globals_buffer':
      for kind2,key2,carrier in edges(buffer):
       if str(key2)==str(ordinal) and names[carrier]=='$kotlin.Array (wasm)':
        storage=prop(carrier,'$storage'); values=els(storage)
        if set(values)==set(range(256)) and all(names[t]==expected for t in values.values()):candidates.append((i,buffer,carrier,storage,values))
  assert len(candidates)==1,(label,phase,candidates); instance,buffer,carrier,storage,values=candidates[0]; roots=[values[i] for i in range(256)]; assert len(set(roots))==(1 if phase=='unit' else 256)
  # Strong root-path proof, then dominance by removing the equal-length carrier.
  parent={0:None}; queue=collections.deque([0])
  while queue and carrier not in parent:
   i=queue.popleft()
   for kind,key,to in edges(i):
    if kind!='weak' and to not in parent:parent[to]=(i,kind,key);queue.append(to)
  assert carrier in parent; route=[]; at=carrier
  while parent[at] is not None:
   before,kind,key=parent[at];route.append({'from':before,'from_name':names[before],'kind':kind,'edge':key,'to':at,'to_name':names[at]});at=before
  route.reverse()
  reached={0}; queue=collections.deque([0])
  while queue:
   i=queue.popleft()
   for kind,key,to in edges(i):
    if kind!='weak' and to!=carrier and to not in reached:reached.add(to);queue.append(to)
  # Only explicit numeric/array storage references, never vtable/rtti/map metadata.
  owned=set(); todo=list(set(roots)); references=[]; scalars=[]
  while todo:
   i=todo.pop()
   if i in owned:continue
   owned.add(i); assert len(owned)<=4096 and sum(sizes[x] for x in owned)<=16777216
   name=names[i]; allowed=[]
   if name=='$io.heapy.krogu.math.BigInteger (wasm)':allowed=['$words' if label=='baseline' else '$wideWords']
   elif name=='$io.heapy.krogu.math.BigDecimal (wasm)':allowed=['$coefficient' if label=='baseline' else '$wideCoefficient','$stringCache']
   elif name in ['$kotlin.IntArray (wasm)','$kotlin.ByteArray (wasm)']:allowed=['$storage']
   elif name in ['$kotlin.wasm.internal.WasmIntArray (wasm)','$kotlin.wasm.internal.WasmByteArray (wasm)','$kotlin.Unit (wasm)']:pass
   else:raise AssertionError(('unexpected owned type',name))
   for field in allowed:
    to=prop(i,field); references.append({'from':i,'field':field,'to':to,'type':names[to]})
    if names[to]!='system / WasmNull':todo.append(to)
   if name.startswith('$io.heapy.krogu.math.'):
    vals={str(key):names[to] for kind,key,to in edges(i) if kind=='internal' and str(key).startswith('$')};scalars.append({'node':i,'type':name,'values':vals})
  external=sorted(owned&reached); exclusive=owned-reached
  if phase!='unit':assert not external,(label,phase,'unexpected externally retained graph nodes',external)
  if phase=='unit':assert external==list(set(roots))
  # Exposed numeric scalar values are checked; opaque primitive elements use separate paired CHECK evidence.
  def integer_value(i):
   if label=='candidate' and names[prop(i,'$wideWords')]=='system / WasmNull':
    hi=int(names[prop(i,'$compactHigh')]);lo=int(names[prop(i,'$compactLow')]);value=(hi<<32)|(lo&0xffffffff)
    assert int(names[prop(i,'$representation')])==1;return value
   words=prop(i,'$words' if label=='baseline' else '$wideWords');back=prop(words,'$storage');vv=els(back)
   if not vv:return None
   assert set(vv)==set(range(len(vv)));return int(names[prop(i,'$sign')])*sum(int(names[vv[k]])<<(30*k) for k in vv)
  for idx,i in enumerate(roots):
   if phase.startswith('integer_'):
    expectedvalue=12345000001+(idx&15) if phase.endswith('small') else int('123456789'*16+str(idx&15));actual=integer_value(i);assert actual is None or actual==expectedvalue
   elif phase.startswith('decimal_'):
    assert int(names[prop(i,'$decimalScale')])==2 and names[prop(i,'$stringCache')]=='system / WasmNull'
    if label=='candidate' and phase.endswith('small'):
     assert names[prop(i,'$wideCoefficient')]=='system / WasmNull' and int(names[prop(i,'$representation')])==1;actual=(int(names[prop(i,'$compactHigh')])<<32)|(int(names[prop(i,'$compactLow')])&0xffffffff)
    else:actual=integer_value(prop(i,'$coefficient' if label=='baseline' else '$wideCoefficient'))
    assert actual is None or actual==(12345000001+(idx&15) if phase.endswith('small') else int('123456789'*16+str(idx&15)))
   elif phase.startswith('control_'):
    backing=prop(i,'$storage');vv=els(backing);length={'control_bytes0':0,'control_bytes256':256,'control_ints64':64}[phase];assert not vv or len(vv)==length and all(int(names[t])==0 for t in vv.values())
  typesummary={}
  for i in owned:
   row=typesummary.setdefault(names[i],{'count':0,'shallow_bytes':0});row['count']+=1;row['shallow_bytes']+=sizes[i]
  excluded_metadata={}
  for ownednode in owned:
   for kind,key,to in edges(ownednode):
    if str(key) in ['$vtable','$itable','$rtti','map'] and to not in owned:
     excluded_metadata[to]={'node':to,'type':names[to],'shallow_bytes':sizes[to],'externally_strong_reachable_without_carrier':to in reached}
  assert all(x['shallow_bytes']==0 or x['externally_strong_reachable_without_carrier'] for x in excluded_metadata.values())
  row={'excluded_metadata':list(excluded_metadata.values()),'label':label,'phase':phase,'raw_file':str(path),'raw_sha256':rawsha,'gzip_sha256':hashlib.sha256(compressed).hexdigest(),'snapshot_nodes':number,'global_index':next(iter(metadata['modules'][label]['retained_global'])),'reference_global_ordinal':ordinal,'instance_node':instance,'globals_buffer_node':buffer,'carrier_node':carrier,'carrier_storage_node':storage,'carrier_shallow_bytes':sizes[carrier]+sizes[storage],'root_path':route,'root_node_ids':roots,'root_count':len(roots),'distinct_root_count':len(set(roots)),'root_shallow_bytes_each':sorted({sizes[x] for x in roots}),'owned_node_ids':sorted(owned),'owned_type_counts_shallow':typesummary,'owned_reachable_bytes':sum(sizes[x] for x in owned),'exclusive_numeric_or_array_bytes':sum(sizes[x] for x in exclusive),'exclusive_bytes_per_root':sum(sizes[x] for x in exclusive)/256,'externally_shared_owned_node_ids':external,'storage_references':references,'scalar_examples':scalars[:3],'primitive_array_contents':'V8 exposes owned backing node/type/self_size but not primitive elements/length. No numeric contents imputed; compact scalar fields checked directly, wide numeric outputs independently checked in paired arithmetic. Known array source controls and observed byte-size contrasts establish payload coverage.','proof':'Full snapshot strong-edge reachability with carrier removed leaves no numeric/array owned node reachable from root0. Unit singleton remains externally shared and excluded. Metadata vtable/itable/rtti/map, carrier and zero-size numeric value nodes excluded from owned graph.'}
  reports.append(row); print(label,phase,'roots',len(set(roots)),'owned',len(owned),'bytes/root',row['exclusive_bytes_per_root'],'carrier',row['carrier_shallow_bytes'])
  del D,N,E,S,parent,reached
# Controls prove actual shallow payload differences, not source-inferred bytes.
control=[]
for label in ['baseline','candidate']:
 get=lambda phase:next(x for x in reports if x['label']==label and x['phase']==phase)
 b0=get('control_bytes0');b256=get('control_bytes256');ints=get('control_ints64');contrast=(b256['exclusive_numeric_or_array_bytes']-b0['exclusive_numeric_or_array_bytes'])/256;icontrast=(ints['exclusive_numeric_or_array_bytes']-b0['exclusive_numeric_or_array_bytes'])/256;assert contrast==icontrast==256;control.append({'label':label,'byte256_minus_byte0_bytes_per_root':contrast,'int64_minus_byte0_bytes_per_root':icontrast})
result={'status':'INDEPENDENT_WASM_OWNED_GRAPH_AND_CONTROLS_PASS','snapshots':16,'root_count_per_phase':256,'module_mapping':metadata,'phase_graphs':reports,'payload_controls':control,'scope':'Actual strong-edge exclusive numeric/array graph bytes, excluding equal carrier, shared metadata/static objects and synthetic scalar value nodes. V8-reported node shallow sizes include headers/alignment; control contrasts independently expose actual256-byte primitive payload. Not process RSS, heap delta, transient allocation or cross-runtime object-size equality.'};(P/'independent-wasm-owned-graph-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('FINAL',result['status'])
PY
```

