#!/usr/bin/env kotlinr
// Untimed JVM Instrumentation of own storage fields; no timed numerical API calls.
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import javax.tools.ToolProvider

require(args.size == 9) { "baselineJar candidateJar agentJar stdlibJar fourExpectedSHA256 newOutput" }
check(KotlinVersion.CURRENT.toString() == "2.4.21")
check(System.getProperty("java.runtime.version") == "25.0.4+9-LTS" && System.getProperty("java.vendor") == "BellSoft")
val inputs = args.take(4).map { File(it).canonicalFile }
val expected = args.slice(4..7)
check(inputs.all { it.isFile } && inputs.distinct().size == 4)
val output = File(args[8]).canonicalFile
check(output.toPath().startsWith(File("/Users/yoda/dev/pet/krogu-math/.codex-work/529").toPath()) && !output.exists() && output.mkdirs())
fun sha(file: File) = MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString("") { "%02x".format(it) }
fun verify() { inputs.zip(expected).forEach { (file, hash) -> check(sha(file) == hash) } }
val observerScript = File("/Users/yoda/dev/pet/krogu-math/.codex-work/529/measure-shared-cache.main.kts")
val observerSha = sha(observerScript)
verify()
val java = File(System.getProperty("java.home"), "bin/java").canonicalFile
val javaSha = sha(java)
val source = File(output, "SharedCache529.java")
source.writeText("""
import java.io.File;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.Field;
public final class SharedCache529 {
    static void origin(Class<?> type, File expected) throws Exception {
        File actual=new File(type.getProtectionDomain().getCodeSource().getLocation().toURI()).getCanonicalFile();
        if(!actual.equals(expected))throw new AssertionError("origin "+type);
    }
    public static void main(String[] args) throws Exception {
        if(!System.getProperty("java.runtime.version").equals("25.0.4+9-LTS") || !System.getProperty("java.vendor").equals("BellSoft"))throw new AssertionError("runtime");
        if(Runtime.getRuntime().maxMemory()!=536870912L)throw new AssertionError("heap");
        File main=new File(args[0]).getCanonicalFile(),agent=new File(args[1]).getCanonicalFile();
        origin(SharedCache529.class,new File(args[2]).getCanonicalFile());
        origin(Class.forName("io.heapy.krogu.math.BigInteger",false,SharedCache529.class.getClassLoader()),main);
        Class<?> probe=Class.forName("Compact529Probe"); origin(probe,agent);
        Field instrument=probe.getDeclaredField("instrumentation");instrument.setAccessible(true);
        Instrumentation inst=(Instrumentation)instrument.get(null);
        if(inst==null)throw new AssertionError("agent missing");
        final Class<?> helper;
        try { helper=Class.forName("io.heapy.krogu.math.CompactInteger529"); }
        catch(ClassNotFoundException absent) { System.out.println("CACHE,ABSENT,0,0,0");return; }
        origin(helper,main);
        Field cache=helper.getDeclaredField("negativePowers");cache.setAccessible(true);
        long[] values=(long[])cache.get(null);
        if(values.length!=19)throw new AssertionError("length");
        long power=-1;
        for(int i=0;i<19;i++){if(values[i]!=power)throw new AssertionError("threshold "+i);if(i<18)power*=10;}
        Object instance=helper.getField("INSTANCE").get(null);
        System.out.println("CACHE,PRESENT,"+inst.getObjectSize(values)+","+inst.getObjectSize(instance)+",152");
    }
}
""".trimIndent())
val compiler = checkNotNull(ToolProvider.getSystemJavaCompiler())
check(compiler.run(null, null, null, "-d", output.path, source.path) == 0)
val compiled = File(output, "SharedCache529.class")
val adapterSourceSha = sha(source)
val adapterClassSha = sha(compiled)
File(output, "binding.txt").writeText(buildString {
    appendLine("observer=$observerSha java=$java sha=$javaSha runtime=${System.getProperty("java.runtime.version")}")
    inputs.forEachIndexed { index, file -> appendLine("${expected[index]}  $file") }
    appendLine("adapterSource=${sha(source)} adapterClass=${sha(compiled)}")
})
for (index in 0..1) {
    val command = listOf(java.path, "-Xms256m", "-Xmx512m", "-XX:+UseG1GC", "-javaagent:${inputs[2]}", "-cp",
        listOf(output.path, inputs[2].path, inputs[index].path, inputs[3].path).joinToString(File.pathSeparator),
        "SharedCache529", inputs[index].path, inputs[2].path, output.path)
    File(output, "$index-argv.txt").writeText(command.joinToString("\n", postfix = "\n"))
    val builder = ProcessBuilder(command).redirectErrorStream(true).redirectOutput(File(output, "$index.log"))
    builder.environment().clear();builder.environment().putAll(mapOf("LANG" to "C", "TZ" to "UTC"))
    val child = builder.start()
    var failure: Throwable? = null
    try {
        File(output, "$index-identity.txt").writeText("pid=${child.pid()} start=${child.toHandle().info().startInstant().orElse(null)}\n")
        check(child.waitFor(30, TimeUnit.SECONDS)) { "Owned cache observer deadline" }
        check(child.exitValue() == 0)
    } catch (caught: Throwable) { failure = caught;throw caught }
    finally {
        val capturedInterrupt = Thread.interrupted()
        var interrupted = capturedInterrupt || failure is InterruptedException
        if (child.isAlive) {
            try {
                child.destroyForcibly()
                val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10)
                while (child.isAlive && System.nanoTime() < deadline) {
                    try { child.waitFor(maxOf(1L, deadline-System.nanoTime()), TimeUnit.NANOSECONDS) }
                    catch (_: InterruptedException) { interrupted = true }
                }
                check(!child.isAlive) { "Owned cache observer survived: ${child.pid()}" }
            } catch (cleanup: Throwable) { if(failure!=null)failure.addSuppressed(cleanup) else throw cleanup }
        }
        if (interrupted) Thread.currentThread().interrupt()
    }
}
verify();check(sha(java)==javaSha && sha(observerScript)==observerSha)
check(sha(source)==adapterSourceSha && sha(compiled)==adapterClassSha)
check(File(output,"0.log").readText().trim()=="CACHE,ABSENT,0,0,0")
check(File(output,"1.log").readText().trim().startsWith("CACHE,PRESENT,"))
println("PASS shared cache Instrumentation observation; array/header/singleton separate from152 raw cells")
