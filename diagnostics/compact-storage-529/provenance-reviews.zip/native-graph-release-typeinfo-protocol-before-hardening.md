# Native Debug/Release finite metadata comparison

Status: prepared inline analysis, NOT EXECUTED. Run only in the owner-agreed gap, not during timed campaigns. No builds or numerical bodies are executed/read. This inspects immutable own Mach-O binaries and their class metadata only.

The comparison fails closed on target/header/pointer format/field mismatch. It decodes actual LC_SYMTAB and DYLD_CHAINED_PTR_64_OFFSET(6) metadata; unsupported bind/high8/reserved encodings are rejected. Format reference is the installed Apple SDK mach-o/fixup-chains.h, lines102 and164–173. Pointer offsets20/32/40 and optional extended metadata are validated against pinned runtime dumper and actual Debug dump fields. If Release lacks full extended fields, that remains explicit; no automatic full ownership/physical-retained transfer follows.

```sh
python3 - <<'PY'
from pathlib import Path
import struct,json,hashlib
P=Path('.codex-work/529');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def image(path):
 b=Path(path).read_bytes();assert len(b)<134217728 and struct.unpack_from('<II',b)[0:2]==(0xfeedfacf,0x100000c)
 u32=lambda at:struct.unpack_from('<I',b,at)[0]
 i32=lambda at:struct.unpack_from('<i',b,at)[0]
 u64=lambda at:struct.unpack_from('<Q',b,at)[0]
 segments=[];symtab=None;fix=None;at=32
 for _ in range(u32(16)):
  cmd,size=u32(at),u32(at+4);assert size>=8 and at+size<=len(b)
  if cmd==0x19:segments.append({'name':b[at+8:at+24].split(b'\0')[0].decode(),'vm':u64(at+24),'vmsize':u64(at+32),'file':u64(at+40),'filesize':u64(at+48)})
  if cmd==2:symtab=tuple(u32(at+x) for x in [8,12,16,20])
  if cmd==0x80000034:fix=(u32(at+8),u32(at+12))
  at+=size
 assert symtab and fix;symbols={}
 so,ns,st,ss=symtab
 for i in range(ns):
  x=so+i*16;name=u32(x);kind=b[x+4];value=u64(x+8);assert name<ss
  if kind&0x0e==0x0e:
   end=b.index(0,st+name,st+ss);symbols[b[st+name:end].decode()]=value
 base=next(s['vm'] for s in segments if s['name']=='__TEXT');fd,fs=fix;assert u32(fd)==0
 starts=fd+u32(fd+4);sc=u32(starts);assert sc==len(segments);formats={}
 for i in range(sc):
  rel=u32(starts+4+4*i)
  if rel:formats[i]=struct.unpack_from('<H',b,starts+rel+6)[0]
 def fileoff(va,n=1):
  matches=[s['file']+va-s['vm'] for s in segments if s['vm']<=va and va+n<=s['vm']+s['filesize']]
  assert len(matches)==1,(hex(va),n);return matches[0]
 def ptr(va):
  raw=u64(fileoff(va,8))
  if raw==0:return 0
  idx=next(i for i,s in enumerate(segments) if s['vm']<=va<s['vm']+s['vmsize'])
  assert formats.get(idx)==6 and raw>>63==0 and (raw>>36)&255==0 and (raw>>44)&127==0
  return base+(raw&((1<<36)-1))
 def ints(va,n):
  assert 0<=n<=10000
  return list(struct.unpack_from('<'+'i'*n,b,fileoff(va,n*4))) if n else []
 def cstr(va):
  start=fileoff(va);end=b.index(0,start,min(len(b),start+65536));return b[start:end].decode()
 def typeinfo(name):
  symbol='_kclass:'+name
  if symbol not in symbols:return None
  va=symbols[symbol];size=i32(fileoff(va+20,4));count=i32(fileoff(va+40,4));assert 0<=count<=10000
  offsets=ints(ptr(va+32),count);ext=ptr(va+8);fields=None
  if ext:
   fc=i32(fileoff(ext,4))
   if fc>0:
    assert fc<=10000;offs=ints(ptr(ext+8),fc);kt=ptr(ext+16);names=ptr(ext+24)
    fields=[{'name':cstr(ptr(names+8*i)),'offset':offs[i],'kind':b[fileoff(kt+i)]} for i in range(fc)]
  return {'symbol':symbol,'address':hex(va),'instance_size_or_negative_element_width':size,'reference_offsets':offsets,'extended_fields':fields}
 return {'path':str(path),'sha256':sha(path),'typeinfo':typeinfo,'pointer_formats':formats}
audit=json.loads((P/'native-graph-paired-debug-audit.json').read_text());rows=[]
names=['io.heapy.krogu.math.BigInteger','io.heapy.krogu.math.BigDecimal','kotlin.Array','kotlin.ByteArray','kotlin.IntArray','kotlin.LongArray','io.heapy.krogu.math.CompactInteger529','bench.NativeGraphRoot529']
for impl in ['baseline','candidate']:
 debug=image(P/f'artifacts/native-debug-{impl}-d6d594f/benchmarks.kexe');release=image(P/f'artifacts/portable-{impl}-d6d594f/benchmarks.kexe')
 schemas={}
 for row in audit['rows']:
  if row['implementation']==impl:
   for name,schema in row['actual_type_schemas'].items():
    if name in schemas:assert schemas[name]==schema
    schemas[name]=schema
 items=[]
 for name in names:
  d=debug['typeinfo'](name);r=release['typeinfo'](name)
  if d is None or r is None:
   assert d is None and r is None and name=='io.heapy.krogu.math.CompactInteger529';continue
  assert d['instance_size_or_negative_element_width']==r['instance_size_or_negative_element_width'] and d['reference_offsets']==r['reference_offsets'],(impl,name,d,r)
  if name in schemas:
   s=schemas[name];expected=-s['serialized_instance_or_element_bytes'] if s['flags']&1 else s['serialized_instance_or_element_bytes']+8
   assert d['instance_size_or_negative_element_width']==expected
   assert d['reference_offsets']==[x+8 for x in s['reference_offsets']]
   if d['extended_fields'] is not None:
    assert d['extended_fields']==[dict(x,offset=x['offset']+8) for x in s['fields']]
  if d['extended_fields'] is not None and r['extended_fields'] is not None:assert d['extended_fields']==r['extended_fields']
  items.append({'type':name,'debug':d,'release':r,'size_and_reference_offsets_equal':True,'complete_extended_fields_equal':None if d['extended_fields'] is None or r['extended_fields'] is None else True})
 rows.append({'implementation':impl,'debug_path':debug['path'],'debug_sha256':debug['sha256'],'release_path':release['path'],'release_sha256':release['sha256'],'pointer_formats':release['pointer_formats'],'types':items})
result={'status':'ACTUAL_DEBUG_RELEASE_TYPEINFO_METADATA_COMPARISON_PASS_SCOPED','implementations':rows,'scope':'Actual own-binary TypeInfo size/reference offset/available extended-field comparison, matched source/runtimeABI. No new Release heap capture or allocator-retained total inferred. Missing Release extended fields explicitlyvisible; observedDebugownership remains source/configuration-scoped.'}
(P/'native-graph-debug-release-typeinfo-binding.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['status']);print([(r['implementation'],[(t['type'],t['complete_extended_fields_equal']) for t in r['types']]) for r in rows])
PY
```
