# Final 9641 compact-storage owned graph audit

Actual candidate captures JS 9567 and Wasm 45869 completed with exit 0. Eight phases per runtime were parsed and SHA-checked against each capture/recovery ledger. These are new candidate snapshots of 9641a959a591a3265a24e17ab4250d63959d6c5f; unchanged accepted537 baseline captures are reused, not relabelled. Node 24.16.0 / V8 13.6.233.17-node.49, arm64, explicit GC, 512 MiB snapshot envelope. Numerical/retention timing is separate.

| Actual owned cohort average, B/root | Baseline | New candidate | Change |
|---|---:|---:|---:|
| JS BigInteger small | 264 | 96 | -168 |
| JS BigDecimal small | 320 | 96 | -224 |
| JS BigInteger wide | 331.5 | 371.5 | +40 |
| JS BigDecimal wide | 387.5 | 467.5 | +80 |
| Wasm BigInteger small | 144 | 72 | -72 |
| Wasm BigDecimal small | 216 | 80 | -136 |
| Wasm BigInteger wide | 203 | 219 | +16 |
| Wasm BigDecimal wide | 275 | 299 | +24 |

The observed new candidate cohorts match the earlier ef3 cohorts, now supported by actual fresh module/snapshot bindings. These are 256-root cohort averages, not universal object sizes. The actual lexical JS retained529 context or compiled Wasm global 550 → reference slot 533 leads to the carrier and 256 distinct numeric roots. New Wasm names/field layouts and reference-global ordinals were independently extracted from module SHA 15ee39091f224630f19c45ed510fff3f234e05c06ec7b7d3a793f54ed124f4c1. Compact JS numeric roots include their real 40 B PropertyArray (56+40=96 B), but no retained Long wrapper, magnitude array or materialized coefficient. Wide graphs include typed arrays, ArrayBuffers, inline/native backing and both numeric wrapper stores. Carrier sizes (JS 2096 B, Wasm 2128 B) are separately excluded. Unit is independently shared.

All phases validate strong reachability with the carrier removed. Only independently externally reachable shared nodes and zero-size virtual scalar nodes are excluded. JS follows every strong edge, including PropertyArray and inline backing. Wasm follows explicit storage references and separately proves metadata sharing. ByteArray256−ByteArray0 and IntArray64−ByteArray0 both show an actual 256 B payload contrast on both runtimes. Wasm backing elements are opaque; no lengths/values are imputed. Arithmetic CHECKs establish wide value truth separately.

## Shared 19-power cache, separate from per-number graphs

The helper is globally reachable and excluded from per-number ownership. Fresh candidate snapshots actually expose the new cache in all eight phases, including Unit (factory setup already initialized it).

| Runtime | Cache graph | Associated helper shallow | Boundary |
|---|---:|---:|---|
| JVM | 168 B array | 16 B | Instrumentation; array includes header/alignment, 152 B logical cells |
| JS | 1072 B exclusive graph | 96 B | 19 Long objects 760 B, Array 32 B, elements 168 B, PropertyArray 40 B, exclusively held V8 Map 72 B |
| Wasm | 232 B storage | 64 B | LongArray wrapper 56 B + WasmLongArray backing 176 B |

JS cache ownership was proved by removing the cache array from complete strong reachability, retaining every positive-size dominated node—including its cache-specific Map. Thus metadata is not silently discarded when exclusively held. Wasm generic dominance independently confirms precisely the array wrapper/backing pair; rtti/vtable/itable are externally shared. Associated helper sizes are reported separately; they are not an incremental cache-only delta against the previous helper. MASK storage, shared prototype/class metadata, code and initialization transients are outside the cache-only total. JVM observed every power value independently; JS smi scalar nodes and Wasm opaque primitive backing do not expose all decoded values, so their contents are not invented. Compiled initializer and target correctness are distinct evidence.

## Limits and retained failed diagnostics

Original and updated JS post-GC runtime slopes remain FAILED/UNVERIFIED; none is relabelled PASS. JS TIME/CHECK was audited separately before RETAIN. Owned graph proof replaces the unobservable delta method for retained ownership; RSS/global census is not used as per-value memory. Layouts are observed on this pinned V8 build, heap state and cohorts; no cross-platform byte equality, allocation or universal performance claim follows. Shared cache cold initialization has a bounded but nonzero cost and is not measured by per-number cohort subtraction.

The heavy parsing slot was explicitly released immediately after terminal analysis to owner536. No numerical campaign was launched by this reviewer.

## Evidence and reproduction

Final files: independent-js-9641-owned-graph-audit.json, independent-wasm-9641-owned-graph-audit.json, independent-9641-cache-domination-audit.json, 9641-wasm-graph-layout-metadata.json, independent-shared-cache-observer-actual-audit.json. Original ef3 audits remain separately bound. Reproduction below is retained inline analysis, not standalone tooling; run only with an agreed heavy slot. The analysis merges previously verified baseline rows and parses only new candidate phases. Raw snapshots remain losslessly gzipped.

### Wasm compiled names

```sh
python3 - <<'PY'
from pathlib import Path
import json,hashlib
p=Path('.codex-work/529');old=json.loads((p/'final-wasm-graph-layout-metadata.json').read_text());f=p/'artifacts/portable-candidate-9641a95/wasm/krogu-math-benchmarks.wasm';b=f.read_bytes()
def leb(i):
 n=0;s=0
 while True:
  v=b[i];i+=1;n|=(v&127)<<s
  if v<128:return n,i
  s+=7
def string(i):
 n,i=leb(i);return b[i:i+n].decode(),i+n
def namemap(i):
 count,i=leb(i);d={}
 for _ in range(count):
  idx,i=leb(i);name,i=string(i);d[str(idx)]=name
 return d,i
names={};i=8
while i<len(b):
 tag=b[i];i+=1;n,i=leb(i);end=i+n
 if tag==0:
  name,k=string(i)
  if name=='name':
   while k<end:
    sub=b[k];k+=1;size,k=leb(k);stop=k+size
    if sub in [4,7]:names[sub],z=namemap(k);assert z==stop
    elif sub==10:
     count,z=leb(k);d={}
     for _ in range(count):
      idx,z=leb(z);d[str(idx)],z=namemap(z)
     assert z==stop;names[sub]=d
    k=stop
 i=end
assert names
selected={k:v for k,v in names[4].items() if any(x in v for x in ['BigInteger','BigDecimal','CompactInteger529','WasmLongArray','LongArray','WasmAnyArray','kotlin.Array','WasmIntArray','kotlin.IntArray','WasmByteArray','kotlin.ByteArray'])}
globals={k:v for k,v in names[7].items() if any(x in v for x in ['retained529','negativePowers','CompactInteger529'])}
old['modules']['candidate']={'artifact':str(f),'sha256':hashlib.sha256(b).hexdigest(),'type_names':selected,'field_names':{k:names[10][k] for k in selected if k in names.get(10,{})},'retained_global':{k:v for k,v in globals.items() if v=='bench.retained529'},'related_globals':globals}
old['status']='STATIC_NEW9641_NAME_METADATA_EXTRACTED_MAPPING_PENDING'
(p/'9641-wasm-graph-layout-metadata.json').write_text(json.dumps(old,indent=2)+'\n')
print(json.dumps(old['modules']['candidate'],indent=2))
PY
```

### Wasm global reference ordinal proof

```sh
python3 - <<'PY'
from pathlib import Path
import json
p=Path('.codex-work/529'); meta=json.loads((p/'9641-wasm-graph-layout-metadata.json').read_text())
for label in ['baseline','candidate']:
 b=Path(meta['modules'][label]['artifact']).read_bytes(); globaltypes=[]
 def leb(i):
  n=0;s=0
  while True:
   v=b[i];i+=1;n|=(v&127)<<s
   if v<128:return n,i
   s+=7
 def skipstr(i):n,i=leb(i);return i+n
 def val(i):
  c=b[i];i+=1
  if c in [0x63,0x64]: _,i=leb(i)
  return c not in [0x7f,0x7e,0x7d,0x7c,0x7b],i
 def limits(i):
  flags,i=leb(i);_,i=leb(i)
  if flags&1:_,i=leb(i)
  return i
 i=8; ins={}
 while i<len(b):
  tag=b[i];i+=1;n,i=leb(i);end=i+n
  if tag==2:
   count,k=leb(i)
   for z in range(count):
    k=skipstr(skipstr(k));kind=b[k];k+=1
    if kind==0:_,k=leb(k)
    elif kind==1:_,k=val(k);k=limits(k)
    elif kind==2:k=limits(k)
    elif kind==3:r,k=val(k);k+=1;globaltypes.append(r)
    elif kind==4:k+=1;_,k=leb(k)
    else:raise Exception(('importkind',kind))
   assert k==end
  if tag==6:
   count,k=leb(i)
   for z in range(count):
    r,k=val(k);k+=1;globaltypes.append(r)
    while True:
     op=b[k];k+=1;ins[hex(op)]=ins.get(hex(op),0)+1
     if op==0x0b:break
     elif op in [0x41,0x42,0x23,0xd0,0xd2]:_,k=leb(k)
     elif op==0x43:k+=4
     elif op==0x44:k+=8
     elif op==0xfb:
      sub,k=leb(k);ins['gc'+str(sub)]=ins.get('gc'+str(sub),0)+1
      if sub in [0,1,6,7]:_,k=leb(k)
      elif sub in [8,9,10]:_,k=leb(k);_,k=leb(k)
      elif sub in [26,27,28]:pass
      else:raise Exception(('GC initializer subop',sub,z,k))
     elif op in [0x6a,0x6b,0x6c,0x7c,0x7d,0x7e]:pass
     else:raise Exception(('initializeropcode',hex(op),z,k))
   assert k==end
  i=end
 target=int(next(iter(meta['modules'][label]['retained_global']))); assert globaltypes[target]; ordinal=sum(globaltypes[:target]); print(label,'global',target,'taggedrefordinal',ordinal,'totalglobals',len(globaltypes),'nonrefs_before',target-ordinal,'initops',ins)
 meta['modules'][label]['retained_global_ref_ordinal']=ordinal;
 if label=='candidate':
  meta['modules'][label]['related_global_ref_ordinals']={name:{'global_index':int(key),'ref_ordinal':sum(globaltypes[:int(key)])} for key,name in meta['modules'][label]['related_globals'].items() if globaltypes[int(key)]}
 meta['modules'][label]['global_mapping_proof']={'global_index':target,'reference_globals_before':ordinal,'nonreference_globals_before':target-ordinal,'total_globals':len(globaltypes),'initializer_opcodes':ins,'method':'Independent binary import/global-section value-type counting; validated complete section consumption and known initializer opcodes. Zero-based reference-global ordinal correlates V8 tagged_globals_buffer index.'}
(p/'9641-wasm-graph-layout-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
PY
```

### New JS eight-phase numeric/cache graphs

```sh
python3 - <<'PY'
from pathlib import Path
import gzip,json,hashlib,collections
P=Path('.codex-work/529'); phases=['unit','integer_small','integer_wide','decimal_small','decimal_wide','control_bytes0','control_bytes256','control_ints64'];reports=[x for x in json.loads((P/'independent-js-owned-graph-audit.json').read_text())['phase_graphs'] if x['label']=='baseline']
for label in ['candidate']:
 folder=P/'js-heap-candidate-9641a95';summary=json.loads((folder/'snapshot-summary.json').read_text());assert summary['node']=='v24.16.0' and summary['rootCount']==256 and [x['phase'] for x in summary['phases']]==phases
 for phase in phases:
  led=next(x for x in summary['phases'] if x['phase']==phase);path=folder/(led['file']+'.gz');compressed=path.read_bytes();raw=gzip.decompress(compressed);assert hashlib.sha256(raw).hexdigest()==led['sha256'] and len(raw)==led['bytes'];D=json.loads(raw);del raw;m=D['snapshot']['meta'];N=D['nodes'];E=D['edges'];S=D['strings'];nf=m['node_fields'];ef=m['edge_fields'];nw=len(nf);ew=len(ef);assert len(N)%nw==0 and len(E)%ew==0;nn=nf.index('name');sz=nf.index('self_size');ec=nf.index('edge_count');nt=nf.index('type');number=len(N)//nw;names=[S[N[i*nw+nn]] for i in range(number)];sizes=[N[i*nw+sz] for i in range(number)];kinds=[m['node_types'][nt][N[i*nw+nt]] for i in range(number)];starts=[];pos=0
  for i in range(number):starts.append(pos);pos+=N[i*nw+ec]*ew
  assert pos==len(E)
  def edges(i):
   for z in range(N[i*nw+ec]):
    k,key,to=E[starts[i]+z*ew:starts[i]+(z+1)*ew];kind=m['edge_types'][0][k];assert to%nw==0 and 0<=to<len(N);yield kind,key if kind in ['element','hidden'] else S[key],to//nw
  pairs=[]
  for i in range(number):
   if names[i]=='system / Context':
    for kind,key,to in edges(i):
     if kind=='context' and key=='retained529':pairs.append((i,to))
  assert len(pairs)==1;context,carrier=pairs[0];assert names[carrier]=='Array';roots={key:to for kind,key,to in edges(carrier) if kind=='element'};assert set(roots)==set(range(256));rootlist=[roots[i] for i in range(256)];expected={'unit':'Unit','integer_small':'BigInteger','integer_wide':'BigInteger','decimal_small':'BigDecimal','decimal_wide':'BigDecimal','control_bytes0':'Int8Array','control_bytes256':'Int8Array','control_ints64':'Int32Array'}[phase];assert all(names[i]==expected for i in rootlist);assert len(set(rootlist))==(1 if phase=='unit' else 256)
  parent={0:None};q=collections.deque([0])
  while q and carrier not in parent:
   i=q.popleft()
   for kind,key,to in edges(i):
    if kind!='weak' and to not in parent:parent[to]=(i,kind,key);q.append(to)
  assert carrier in parent;route=[];at=carrier
  while parent[at] is not None:
   before,kind,key=parent[at];route.append({'from':before,'from_name':names[before],'kind':kind,'edge':key,'to':at,'to_name':names[at]});at=before
  route.reverse();reached={0};q=collections.deque([0])
  while q:
   i=q.popleft()
   for kind,key,to in edges(i):
    if kind!='weak' and to!=carrier and to not in reached:reached.add(to);q.append(to)
  if phase=='unit':assert all(i in reached for i in rootlist)
  else:assert all(i not in reached for i in rootlist)
  owned=set();todo=list(set(rootlist));refs=[];excluded={}
  while todo:
   i=todo.pop()
   if i in owned:continue
   if i in reached:excluded[i]={'node':i,'name':names[i],'kind':kinds[i],'shallow_bytes':sizes[i],'reason':'Strongly reachable from root0 with carrier removed'};continue
   if sizes[i]==0:continue
   owned.add(i);assert len(owned)<=4096 and sum(sizes[j] for j in owned)<=16777216
   for kind,key,to in edges(i):
    if kind=='weak':continue
    refs.append({'from':i,'field':key,'kind':kind,'to':to,'type':names[to],'target_shallow_bytes':sizes[to]});todo.append(to)
  assert not owned&reached
  typesummary={}
  for i in owned:
   key=kinds[i]+'|'+names[i];r=typesummary.setdefault(key,{'count':0,'shallow_bytes':0});r['count']+=1;r['shallow_bytes']+=sizes[i]
  numericnodes=[i for i in owned if names[i] in ['BigInteger','BigDecimal']];assert not any(names[i] in ['Long','Long_0'] for i in owned)
  # Every expected live typed-array root owns its own ArrayBuffer/backing, not a census difference.
  buffers=[i for i in owned if names[i]=='ArrayBuffer'];native=[i for i in owned if names[i]=='system / JSArrayBufferData']
  if phase.startswith('control_'):
   assert len(buffers)==256
   if phase=='control_bytes0':assert not native
   else:assert len(native)==256 and all(sizes[i]==256 for i in native)
  if label=='candidate' and phase in ['integer_small','decimal_small']:
   assert set(names[i] for i in owned)<={expected,'system / PropertyArray'} and sum(names[i]==expected for i in owned)==256;assert not buffers and not native
  backing=[to for kind,key,to in edges(carrier) if key=='elements'];assert len(backing)==1;carrierbytes=sizes[carrier]+sizes[backing[0]]
  fieldsamples=[{'node':i,'type':names[i],'shallow_bytes':sizes[i],'fields':[{'kind':kind,'field':key,'to':to,'type':names[to],'target_kind':kinds[to],'target_shallow_bytes':sizes[to]} for kind,key,to in edges(i)]} for i in rootlist[:2]]
  reports.append({'label':label,'phase':phase,'raw_file':str(path),'raw_sha256':led['sha256'],'gzip_sha256':hashlib.sha256(compressed).hexdigest(),'snapshot_nodes':number,'lexical_context_node':context,'carrier_node':carrier,'carrier_elements_node':backing[0],'carrier_shallow_bytes':carrierbytes,'root_path':route,'root_node_ids':rootlist,'distinct_root_count':len(set(rootlist)),'root_shallow_bytes_each':sorted({sizes[i] for i in rootlist}),'owned_node_ids':sorted(owned),'owned_type_counts_shallow':typesummary,'exclusive_owned_bytes':sum(sizes[i] for i in owned),'owned_bytes_per_root_cohort_average':sum(sizes[i] for i in owned)/256,'storage_and_owned_edges':refs,'shared_excluded_nodes':list(excluded.values()),'field_examples':fieldsamples,'retained_JSLong_box_count':0,'proof':'Starting at observed numeric/typed roots, follow all non-weak edges. Exclude only nodes independently strongly reachable without carrier and zero-size primitive value nodes. Every remaining positive-size node included; no prototype/map/property-array/native backing implicitly omitted.'});print(label,phase,'owned',len(owned),'bytes/root',sum(sizes[i] for i in owned)/256,'types',typesummary)

  helpers=[i for i in range(number) if names[i]=='CompactInteger529' and kinds[i]=='object']
  caches=[]
  for helper in helpers:
   cs=[to for kind,key,to in edges(helper) if kind=='property' and key=='hc_1']
   for cache in cs:
    assert names[cache]=='Array'; vals={key:to for kind,key,to in edges(cache) if kind=='element'};assert set(vals)==set(range(19));assert all(names[t]=='Long' for t in vals.values())
    outside={0};q=collections.deque([0])
    while q:
     i=q.popleft()
     for kind,key,to in edges(i):
      if kind!='weak' and to!=cache and to not in outside:outside.add(to);q.append(to)
    cacheowned=set();todo=[cache];shared=[]
    while todo:
     i=todo.pop()
     if i in cacheowned:continue
     if i in outside:shared.append(i);continue
     if sizes[i]==0:continue
     cacheowned.add(i);assert len(cacheowned)<1024
     todo.extend(to for kind,key,to in edges(i) if kind!='weak')
    tc={}
    for i in cacheowned:
     k=kinds[i]+'|'+names[i];x=tc.setdefault(k,{'count':0,'shallow_bytes':0});x['count']+=1;x['shallow_bytes']+=sizes[i]
    caches.append({'helper_node':helper,'associated_helper_shallow_bytes':sizes[helper],'cache_field':'hc_1','cache_node':cache,'cache_elements':vals,'long_distinct_count':len(set(vals.values())),'exclusive_owned_bytes':sum(sizes[i] for i in cacheowned),'owned_type_counts_shallow':tc,'owned_node_ids':sorted(cacheowned),'shared_excluded_nodes':sorted(set(shared)),'logical_payload_bytes':152,'scope':'Cache array graph dominated by removing cache array, with helper itself and unrelated MASK excluded. Numeric per-root graph excludes this globally rooted cache.'})
  assert len(caches)==1,(phase,helpers,caches)
  reports[-1]['shared_cache_graphs']=caches
  print('CACHE',phase,[(x['exclusive_owned_bytes'],x['owned_type_counts_shallow']) for x in caches])

  del D,N,E,S,reached,parent
controls=[]
for label in ['baseline','candidate']:
 get=lambda phase:next(x for x in reports if x['label']==label and x['phase']==phase)
 zero=get('control_bytes0')['exclusive_owned_bytes'];byte=get('control_bytes256')['exclusive_owned_bytes'];ints=get('control_ints64')['exclusive_owned_bytes'];assert (byte-zero)/256==(ints-zero)/256==256;controls.append({'label':label,'byte256_minus_byte0_payload_contrast':256,'int64_minus_byte0_payload_contrast':256})
result={'status':'INDEPENDENT_JS_OWNED_GRAPH_AND_CONTROLS_PASS_SEPARATE_FROM_FAILED_GC_DELTAS','snapshots':16,'new_candidate_snapshots_parsed':8,'baseline_reused_from':'independent-js-owned-graph-audit.json','root_count_per_phase':256,'phase_graphs':reports,'payload_controls':controls,'failed_runtime_slopes_status':'23960 RETAIN remains FAILED_UNVERIFIED; no numerical rerun or metric threshold change. Arithmetic/time accepted separately.','scope':'Actual V8 snapshot exclusive owned cohort graphs, with all positive-size dominated objects including typed arrays/ArrayBuffers/native data/property storage. Shared/static metadata and equal carrier excluded by actual strong reachability. Cohort averages not universal object sizes; no heap delta/RSS substitution. JS primitive values not all numerically readable, paired CHECKs establish value truth.'};(P/'independent-js-9641-owned-graph-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('FINAL',result['status'])
PY
```

### New Wasm eight-phase numeric/cache graphs

```sh
python3 - <<'PY'
from pathlib import Path
import gzip,json,hashlib,collections,time
P=Path('.codex-work/529'); metadata=json.loads((P/'9641-wasm-graph-layout-metadata.json').read_text()); phases=['unit','integer_small','integer_wide','decimal_small','decimal_wide','control_bytes0','control_bytes256','control_ints64']; reports=[x for x in json.loads((P/'independent-wasm-owned-graph-audit.json').read_text())['phase_graphs'] if x['label']=='baseline']
for label in ['candidate']:
 folder=P/'wasm-heap-candidate-9641a95'; summary=json.loads((folder/'snapshot-summary.json').read_text()); assert summary['node']=='v24.16.0' and summary['rootCount']==256; assert [x['phase'] for x in summary['phases']]==phases
 ordinal=metadata['modules'][label]['retained_global_ref_ordinal']
 for phase in phases:
  led=next(x for x in summary['phases'] if x['phase']==phase); path=folder/(led['file']+'.gz'); compressed=path.read_bytes(); raw=gzip.decompress(compressed); rawsha=hashlib.sha256(raw).hexdigest(); assert rawsha==led['sha256'] and len(raw)==led['bytes']; D=json.loads(raw); del raw
  m=D['snapshot']['meta']; nf=m['node_fields']; ef=m['edge_fields']; N=D['nodes']; E=D['edges']; S=D['strings']; nw=len(nf); ew=len(ef); assert len(N)%nw==0 and len(E)%ew==0
  nt=nf.index('type'); nn=nf.index('name'); ns=nf.index('self_size'); nc=nf.index('edge_count'); et=ef.index('type'); en=ef.index('name_or_index'); eto=ef.index('to_node'); types=m['node_types'][nt]; ets=m['edge_types'][et]; number=len(N)//nw
  names=[S[N[i*nw+nn]] for i in range(number)]; sizes=[N[i*nw+ns] for i in range(number)]; starts=[]; pos=0
  for i in range(number): starts.append(pos);pos+=N[i*nw+nc]*ew
  assert pos==len(E)
  def edges(i):
   at=starts[i]
   for k in range(N[i*nw+nc]):
    off=at+k*ew; kind=ets[E[off+et]]; v=E[off+en]; target=E[off+eto]; assert target%nw==0 and 0<=target<len(N)
    yield (kind,v if kind in ['element','hidden'] else S[v],target//nw)
  def prop(i,name):
   x=[to for kind,key,to in edges(i) if key==name]; assert len(x)==1,(label,phase,i,name,x); return x[0]
  def els(i):return {int(key):to for kind,key,to in edges(i) if kind=='element'}
  expected={'unit':'$kotlin.Unit (wasm)','integer_small':'$io.heapy.krogu.math.BigInteger (wasm)','integer_wide':'$io.heapy.krogu.math.BigInteger (wasm)','decimal_small':'$io.heapy.krogu.math.BigDecimal (wasm)','decimal_wide':'$io.heapy.krogu.math.BigDecimal (wasm)','control_bytes0':'$kotlin.ByteArray (wasm)','control_bytes256':'$kotlin.ByteArray (wasm)','control_ints64':'$kotlin.IntArray (wasm)'}[phase]
  candidates=[]
  for i,name in enumerate(names):
   if name=='system / WasmTrustedInstanceData':
    for kind,key,buffer in edges(i):
     if key=='tagged_globals_buffer':
      for kind2,key2,carrier in edges(buffer):
       if str(key2)==str(ordinal) and names[carrier]=='$kotlin.Array (wasm)':
        storage=prop(carrier,'$storage'); values=els(storage)
        if set(values)==set(range(256)) and all(names[t]==expected for t in values.values()):candidates.append((i,buffer,carrier,storage,values))
  assert len(candidates)==1,(label,phase,candidates); instance,buffer,carrier,storage,values=candidates[0]; roots=[values[i] for i in range(256)]; assert len(set(roots))==(1 if phase=='unit' else 256)
  # Strong root-path proof, then dominance by removing the equal-length carrier.
  parent={0:None}; queue=collections.deque([0])
  while queue and carrier not in parent:
   i=queue.popleft()
   for kind,key,to in edges(i):
    if kind!='weak' and to not in parent:parent[to]=(i,kind,key);queue.append(to)
  assert carrier in parent; route=[]; at=carrier
  while parent[at] is not None:
   before,kind,key=parent[at];route.append({'from':before,'from_name':names[before],'kind':kind,'edge':key,'to':at,'to_name':names[at]});at=before
  route.reverse()
  reached={0}; queue=collections.deque([0])
  while queue:
   i=queue.popleft()
   for kind,key,to in edges(i):
    if kind!='weak' and to!=carrier and to not in reached:reached.add(to);queue.append(to)
  # Only explicit numeric/array storage references, never vtable/rtti/map metadata.
  owned=set(); todo=list(set(roots)); references=[]; scalars=[]
  while todo:
   i=todo.pop()
   if i in owned:continue
   owned.add(i); assert len(owned)<=4096 and sum(sizes[x] for x in owned)<=16777216
   name=names[i]; allowed=[]
   if name=='$io.heapy.krogu.math.BigInteger (wasm)':allowed=['$words' if label=='baseline' else '$wideWords']
   elif name=='$io.heapy.krogu.math.BigDecimal (wasm)':allowed=['$coefficient' if label=='baseline' else '$wideCoefficient','$stringCache']
   elif name in ['$kotlin.IntArray (wasm)','$kotlin.ByteArray (wasm)']:allowed=['$storage']
   elif name in ['$kotlin.wasm.internal.WasmIntArray (wasm)','$kotlin.wasm.internal.WasmByteArray (wasm)','$kotlin.Unit (wasm)']:pass
   else:raise AssertionError(('unexpected owned type',name))
   for field in allowed:
    to=prop(i,field); references.append({'from':i,'field':field,'to':to,'type':names[to]})
    if names[to]!='system / WasmNull':todo.append(to)
   if name.startswith('$io.heapy.krogu.math.'):
    vals={str(key):names[to] for kind,key,to in edges(i) if kind=='internal' and str(key).startswith('$')};scalars.append({'node':i,'type':name,'values':vals})
  external=sorted(owned&reached); exclusive=owned-reached
  if phase!='unit':assert not external,(label,phase,'unexpected externally retained graph nodes',external)
  if phase=='unit':assert external==list(set(roots))
  # All exposed numeric scalar fields checked; opaque primitive backing validated separately by CHECKs.
  def integer_value(i):
   if label=='candidate' and names[prop(i,'$wideWords')]=='system / WasmNull':
    hi=int(names[prop(i,'$compactHigh')]);lo=int(names[prop(i,'$compactLow')]);value=(hi<<32)|(lo&0xffffffff)
    assert int(names[prop(i,'$representation')])==1;return value
   words=prop(i,'$words' if label=='baseline' else '$wideWords');back=prop(words,'$storage');vv=els(back)
   if not vv:return None
   assert set(vv)==set(range(len(vv)));return int(names[prop(i,'$sign')])*sum(int(names[vv[k]])<<(30*k) for k in vv)
  for idx,i in enumerate(roots):
   if phase.startswith('integer_'):
    expectedvalue=12345000001+(idx&15) if phase.endswith('small') else int('123456789'*16+str(idx&15));actual=integer_value(i);assert actual is None or actual==expectedvalue
   elif phase.startswith('decimal_'):
    assert int(names[prop(i,'$decimalScale')])==2 and names[prop(i,'$stringCache')]=='system / WasmNull'
    if label=='candidate' and phase.endswith('small'):
     assert names[prop(i,'$wideCoefficient')]=='system / WasmNull' and int(names[prop(i,'$representation')])==1;actual=(int(names[prop(i,'$compactHigh')])<<32)|(int(names[prop(i,'$compactLow')])&0xffffffff)
    else:actual=integer_value(prop(i,'$coefficient' if label=='baseline' else '$wideCoefficient'))
    assert actual is None or actual==(12345000001+(idx&15) if phase.endswith('small') else int('123456789'*16+str(idx&15)))
   elif phase.startswith('control_'):
    backing=prop(i,'$storage');vv=els(backing);length={'control_bytes0':0,'control_bytes256':256,'control_ints64':64}[phase];assert not vv or len(vv)==length and all(int(names[t])==0 for t in vv.values())
  typesummary={}
  for i in owned:
   row=typesummary.setdefault(names[i],{'count':0,'shallow_bytes':0});row['count']+=1;row['shallow_bytes']+=sizes[i]
  excluded_metadata={}
  for ownednode in owned:
   for kind,key,to in edges(ownednode):
    if str(key) in ['$vtable','$itable','$rtti','map'] and to not in owned:
     excluded_metadata[to]={'node':to,'type':names[to],'shallow_bytes':sizes[to],'externally_strong_reachable_without_carrier':to in reached}
  row={'excluded_metadata':list(excluded_metadata.values()),'label':label,'phase':phase,'raw_file':str(path),'raw_sha256':rawsha,'gzip_sha256':hashlib.sha256(compressed).hexdigest(),'snapshot_nodes':number,'global_index':next(iter(metadata['modules'][label]['retained_global'])),'reference_global_ordinal':ordinal,'instance_node':instance,'globals_buffer_node':buffer,'carrier_node':carrier,'carrier_storage_node':storage,'carrier_shallow_bytes':sizes[carrier]+sizes[storage],'root_path':route,'root_node_ids':roots,'root_count':len(roots),'distinct_root_count':len(set(roots)),'root_shallow_bytes_each':sorted({sizes[x] for x in roots}),'owned_node_ids':sorted(owned),'owned_type_counts_shallow':typesummary,'owned_reachable_bytes':sum(sizes[x] for x in owned),'exclusive_numeric_or_array_bytes':sum(sizes[x] for x in exclusive),'exclusive_bytes_per_root':sum(sizes[x] for x in exclusive)/256,'externally_shared_owned_node_ids':external,'storage_references':references,'scalar_examples':scalars[:3],'primitive_array_contents':'V8 exposes owned backing node/type/self_size but not primitive elements/length. No numeric contents imputed; compact scalar fields checked directly, wide numeric outputs independently checked in paired arithmetic. Known array source controls and observed byte-size contrasts establish payload coverage.','proof':'Full snapshot strong-edge reachability with carrier removed leaves no numeric/array owned node reachable from root0. Unit singleton remains externally shared and excluded. Metadata vtable/itable/rtti/map, carrier and zero-size numeric value nodes excluded from owned graph.'}
  reports.append(row); print(label,phase,'roots',len(set(roots)),'owned',len(owned),'bytes/root',row['exclusive_bytes_per_root'],'carrier',row['carrier_shallow_bytes'])

  helperordinal=metadata['modules']['candidate']['related_global_ref_ordinals']['io.heapy.krogu.math.CompactInteger529_instance']['ref_ordinal']
  helper=next(to for kind,key,to in edges(buffer) if str(key)==str(helperordinal))
  assert names[helper]=='$io.heapy.krogu.math.CompactInteger529 (wasm)'
  cache=prop(helper,'$negativePowers'); assert names[cache]=='$kotlin.LongArray (wasm)'
  back=prop(cache,'$storage');assert names[back]=='$kotlin.wasm.internal.WasmLongArray (wasm)'
  cacheowned={cache,back};assert not cacheowned&owned
  # Both are real globally shared objects, never part of per-number ownership.
  assert cache in reached and back in reached
  primitivevals=els(back);assert not primitivevals or {int(k):int(names[v]) for k,v in primitivevals.items()}=={i:-(10**i) for i in range(19)}
  assert sizes[back]>=152
  row['shared_cache_graph']={'helper_global_reference_ordinal':helperordinal,'helper_node':helper,'associated_helper_shallow_bytes':sizes[helper],'cache_field':'$negativePowers','cache_node':cache,'backing_node':back,'cache_shallow_bytes':sizes[cache],'backing_shallow_bytes':sizes[back],'storage_owned_bytes':sizes[cache]+sizes[back],'logical_payload_bytes':152,'primitive_values_exposed':len(primitivevals),'fields':[{'kind':kind,'field':key,'to':to,'type':names[to],'shallow_bytes':sizes[to]} for source in [helper,cache,back] for kind,key,to in edges(source)],'scope':'Actual helper singleton globally roots LongArray/backing. Header-inclusive array storage separate from associated helper, Class/rtti/vtable metadata excluded. Backing elements not imputed when opaque.'}
  print('CACHE',phase,row['shared_cache_graph']['storage_owned_bytes'],sizes[helper])

  del D,N,E,S,parent,reached
# Controls prove actual shallow payload differences, not source-inferred bytes.
control=[]
for label in ['baseline','candidate']:
 get=lambda phase:next(x for x in reports if x['label']==label and x['phase']==phase)
 b0=get('control_bytes0');b256=get('control_bytes256');ints=get('control_ints64');contrast=(b256['exclusive_numeric_or_array_bytes']-b0['exclusive_numeric_or_array_bytes'])/256;icontrast=(ints['exclusive_numeric_or_array_bytes']-b0['exclusive_numeric_or_array_bytes'])/256;assert contrast==icontrast==256;control.append({'label':label,'byte256_minus_byte0_bytes_per_root':contrast,'int64_minus_byte0_bytes_per_root':icontrast})
result={'status':'INDEPENDENT_WASM_OWNED_GRAPH_AND_CONTROLS_PASS','snapshots':16,'new_candidate_snapshots_parsed':8,'baseline_reused_from':'independent-wasm-owned-graph-audit.json','root_count_per_phase':256,'module_mapping':metadata,'phase_graphs':reports,'payload_controls':control,'scope':'Actual strong-edge exclusive numeric/array graph bytes, excluding equal carrier, shared metadata/static objects and synthetic scalar value nodes. V8-reported node shallow sizes include headers/alignment; control contrasts independently expose actual256-byte primitive payload. Not process RSS, heap delta, transient allocation or cross-runtime object-size equality.'};(P/'independent-wasm-9641-owned-graph-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('FINAL',result['status'])
PY
```

### Cache generic dominance cross-check

```sh
python3 - <<'PY'
from pathlib import Path
import gzip,json,collections,hashlib
P=Path('.codex-work/529'); results=[]
for platform in ['js','wasm']:
 auditpath=P/f'independent-{platform}-9641-owned-graph-audit.json'; audit=json.loads(auditpath.read_text()); row=next(x for x in audit['phase_graphs'] if x['label']=='candidate' and x['phase']=='unit')
 D=json.loads(gzip.decompress(Path(row['raw_file']).read_bytes()));N=D['nodes'];E=D['edges'];S=D['strings'];m=D['snapshot']['meta'];nf=m['node_fields'];ef=m['edge_fields'];nw=len(nf);ew=len(ef);nn=nf.index('name');sz=nf.index('self_size');ec=nf.index('edge_count');names=[S[N[i+nn]] for i in range(0,len(N),nw)];sizes=[N[i+sz] for i in range(0,len(N),nw)];starts=[];pos=0
 for i in range(len(names)):starts.append(pos);pos+=N[i*nw+ec]*ew
 def edges(i):
  for z in range(N[i*nw+ec]):
   k,key,to=E[starts[i]+z*ew:starts[i]+(z+1)*ew];kind=m['edge_types'][0][k];yield kind,key if kind in ['element','hidden'] else S[key],to//nw
 cachegraph=row['shared_cache_graphs'][0] if platform=='js' else row['shared_cache_graph'];cache=cachegraph['cache_node'];helper=cachegraph['helper_node']
 outside={0};q=collections.deque([0])
 while q:
  i=q.popleft()
  for kind,key,to in edges(i):
   if kind!='weak' and to!=cache and to not in outside:outside.add(to);q.append(to)
 owned=set();todo=[cache];excluded=set()
 while todo:
  i=todo.pop()
  if i in owned:continue
  if i in outside:excluded.add(i);continue
  if sizes[i]==0:continue
  owned.add(i);todo.extend(to for kind,key,to in edges(i) if kind!='weak')
 total=sum(sizes[i] for i in owned)
 if platform=='js':
  assert total==1072 and sorted(owned)==cachegraph['owned_node_ids']
  vals={key:to for kind,key,to in edges(cache) if kind=='element'};examples=[]
  for idx,i in vals.items():
   f={key:names[to] for kind,key,to in edges(i) if kind=='property'}
   examples.append({'index':idx,'node':i,'fields':f})
  print('JS Long fields',examples[:2])
 else:assert owned=={cachegraph['cache_node'],cachegraph['backing_node']} and total==232
 out={'platform':platform,'raw_sha256':row['raw_sha256'],'helper_node':helper,'cache_node':cache,'exclusive_owned_node_ids':sorted(owned),'exclusive_owned_bytes':total,'all_excluded_positive_nodes':[{'node':i,'type':names[i],'shallow_bytes':sizes[i]} for i in sorted(excluded) if sizes[i]>0],'proof':'Generic all-nonweak-edges reachability with cache removed from root0. Every positive-size node not independently reachable is included, including cache-specific metadata.'}
 if platform=='js':out['long_field_examples']=examples
 results.append(out)
 del D,N,E,S,outside
(P/'independent-9641-cache-domination-audit.json').write_text(json.dumps({'status':'CACHE_DOMINATION_PASS_PRIMITIVE_VALUES_NOT_DECODED','graphs':results},indent=2)+'\n')
print([(r['platform'],r['exclusive_owned_bytes']) for r in results])
PY
```

