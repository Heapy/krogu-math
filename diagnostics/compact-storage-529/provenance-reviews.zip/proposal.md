Task 529 implementation proposal — read-only discovery, 2026-10-16
Source examined: main 7de2d8a56b81bd56a59001522b1d073c28f097a7, plus own
532 kernel draft (not a proposed 529 dependency until integrated).

Required contract boundary

Task529 requires primitive storage for small BigInteger and BigDecimal
coefficients, promotion/demotion, exact results/scale, Long endpoints, current
serialization, required subclass behavior, and measured graph/retained size and
arithmetic across target platforms including wide-object field overhead.
COMPATIBILITY.md 393–394,422,721–725 and docs/api-constructor-549-current-binding.md82
explicitly exclude cross-version/legacy/java.math stream compatibility. Therefore
old wire descriptors, serialPersistentFields, and bidirectional historical-stream
probes are OPTIONAL improvements, not mandatory work. The implementation should
preserve current-format roundtrip invariants with the simpler current format.
No serialization proxy: it would lose required subtype state/reference cycles.

Storage and invariants

BigInteger: immutable sign:Int, compactHigh:Int, compactLow:Int, wideWords:IntArray?.
The two Int fields encode one logical signed compactValue:Long without retaining
an emulated Long object on JS (see platform refinement below). A compact
instance has null wideWords and compactValue whose sign agrees with sign. A wide
instance has a nonempty normalized 30-bit-limb magnitude strictly outside the
signed Long range, compactValue=0, and sign +/-1. Include Long.MIN_VALUE as a
compact negative value; never use it as a sentinel. Positive 2^63 is wide while
negative -2^63 is compact. Zero is compact 0/sign0. All normalization boundaries
classify/narrow, not only public factories. Actual field layout measured later;
expect wide instances to pay the extra Long field.

BigDecimal: immutable scale:Int, compactCoefficientHigh/Low:Int, wideCoefficient:BigInteger?,
and an explicit representation discriminator if needed for serialized-state
validation. Full signed Long range remains available without a reserved sentinel.
These encode a logical signed Long coefficient. Compact branch retains no
coefficient BigInteger; unscaledValue() materializes
one only when requested. Wide branch owns/shares an already normalized immutable
BigInteger. Wide objects pay additional primitive/discriminator fields and this
must be included in the measured cost, not hidden by measuring only small values.

Do not introduce a computed words/coefficient getter that allocates on every
access. Existing BigInteger has hundreds of stored-limb accesses, and BigDecimal
frequently uses its coefficient internally. Migrate each fallback operation to a
single local borrowed/materialized operand snapshot. Compact/compact operations
must enter primitive arithmetic/metadata paths before requesting any array or
BigInteger. Prefer no mutable lazy cache initially; it introduces publication and
serialization concerns and can erase the retained-size gain after first use.

Construction and transitions

Long/String/byte constructors and valueOf classify small values before retaining
array/object storage. Small String parsing should accumulate with checked bounds,
then promote exactly once when the next digit requires it. Long.MIN_VALUE uses
negative-domain or unsigned-magnitude conversion, never overflowing abs().
Existing integer caches remain immutable; uncached small construction is the
important allocation case. Wide results that fit Long demote canonically.
BigDecimal(Long/Int), parsed compact decimal coefficients, and copied compact
values bypass BigInteger creation. Exact floating construction may naturally go
wide; finite decimal/context parsing keeps its existing final-range guarantees.

Primitive arithmetic

Checked signed add/subtract/multiply must detect overflow before accepting a
wrapped value. On overflow, promote to the wide kernel; no loss of sign/digits.
Handle division MIN_VALUE/-1 as a wide positive 2^63 and remainder zero, and keep
divisor-zero validation order. Negating MIN_VALUE promotes. Distinguish stored
unsigned magnitude bit length from java.math's negative two's-complement bitLength.
Comparisons, hash, Number conversions, sign, bit access and decimal digit count
must have direct compact paths so ordinary metadata calls do not materialize.
Mixed compact/wide fallback borrows wide operands and expands compact operands
once per operation. The 532 multiplication kernel remains the wide machinery.

For decimals, preserve Int scale and scale-sensitive equals/hash. Compare stored
compact coefficients directly when scales agree. Same-scale compact add/subtract
and checked product, integer scale shifts within signed Long, precision/sign,
text, and compact rounded division should avoid coefficient construction. Integrate
533's bounded power and compact division paths rather than duplicate them.
Scale differences/exponent and intermediate scale sums remain Long until checked.
Result rounding/promotion must not publish an oversized unnecessary intermediate
when the existing decimal private machinery supports the final result.

Subclass and source obligations

Public classes/constructor-like call surface remain source compatible. Methods
currently virtual stay virtual. Primitive fast paths must preserve required
explicit caller overrides/super calls and selected reachable callbacks, not
replace public virtual metadata with stored values indiscriminately. Constructor
normalization of a BigInteger subtype still consumes its reached toByteArray
encoding before classifying compact versus wide; calling private compactValue
on an unnormalized subtype would skip required construction behavior. Required
truthful coefficient subclass behavior after own-format deserialization remains
separate from construction. Existing Number JVM bridge and JS workaround behavior
must remain intact. Review current constructor/overload ledgers plus existing
callback suites rather than imposing universal arbitrary-subclass traces.

Current serialization only

Keep direct object serialization (subtype fields, repeated references, cycles).
Validate the branch discriminator, sign, compact/wide exclusivity, limb digit
range/nonzero top limb/supported size, and decimal coefficient branch. Clone
stream-owned wide arrays before publication, preserving final normal storage and
safe-publication semantics. New-format deserialize must reject inconsistent
states rather than opportunistically normalizing malformed fields. Reflection-
corruption tests should target actual representation invariants; fixtures that
assume every small value owns a words/coefficient object must be adapted with
wide fixtures plus explicit invalid-branch cases. Do not delete value/subclass/
cycle/alias assertions or treat a representation change as a waiver.

Implementation ownership and sequence

1. Land/rebase after 532/533 to avoid touching their active kernels. Own BigInteger,
   BigDecimal representation+constructors/primitive helpers, platform serializer
   restoration hooks, focused tests and new diagnostics/docs. Preserve existing
   kernel files unless an explicit compact boundary adapter is needed.
2. Add primitive storage + exact compact metadata/construction; enumerate every
   old words/coefficient access and make fallback materialization explicit/local.
3. Add compact arithmetic and all promotion/demotion edges; integrate533 helpers.
4. Repair/validate current serialization and rerun callback/source call forms.
5. Independently review compact invariants, MIN_VALUE, mixed representations,
   malformed-state reading and any new exposure of stored fields.
6. Four local targets plus broad existing arithmetic/decimal/serialization/caller
   regression; root handles matching integrated acceptance.

Meaningful evidence

Compare same seeded operands before/after with527 harness for construction,
metadata/formatting, arithmetic and coefficient extraction, including uncached
Long smalls, MIN/MAX, +/-2^63 neighbors, 30/60/63-bit transitions, mixed operands,
and long carry chains. JVM own diagnostic Instrumentation agent can measure
shallow object sizes and identity-deduplicated retained graphs without depending
on JOL. Record empty-cache/warmed-cache states and the graph before/after explicit
unscaledValue(). Report wide-object extra fields and any arithmetic slowdown.
For JS/Wasm/Native, report actual available runtime measurements and process peak
memory plus explicit graph counts/field payload; do not relabel RSS or allocated
bytes as exact retained size. If precise retained size is unavailable on a target,
state that limitation and add a supported measurement method before claiming that
part of acceptance. Preserve raw outputs, compiler/runtime/source/artifact bindings,
warmup/forks/iterations, and independent arithmetic verification. No speedup or
byte-count estimate becomes a fact until measured.

Concrete discovery anchors (7de2d8a source; 532 may shift BigInteger line numbers)
- BigInteger.kt:12 primary sign/words representation; :16–30 readObject validates
  normalized limbs then restoreSerializedMagnitude detaches stream array.
- BigInteger.kt:65–81 multiply/parallelMultiply before532; dispatch must survive.
- BigInteger.kt:1050-ish decimalCompactValue currently derives Long from limbs
  and excludes -2^63; this helper is not primitive storage.
- BigInteger.kt:1205-ish valueOf currently allocates IntArray(3) for uncached Long.
- BigInteger.kt:1348-ish normalized is a central narrowing/classification boundary.
- BigDecimal.kt:10–24 always-retained BigInteger coefficient, constructing subtype
  byte normalization, private-copy constructor, and basic readObject validation.
- BigDecimal.kt:44–49 coefficient/scale/precision/sign getters and unary operations.
- jvmMain/MathSerializable.kt:9–11 reflective restoration of final words field.
- jvmTest/SerializationConformanceTest.kt includes explicitUID, subtype state,
  repeated references/cycles, post-read array-alias mutation, invalid limb/sign and
  missing coefficient controls; required invariants remain while private-layout
  corruption fixtures adapt to valid compact/wide forms.
- COMPATIBILITY.md:393–394,422,721–725 define current-only serialization scope.
- docs/api-constructor-549-current-binding.md:82 separates constructing subtype
  byte encoding from restored truthful coefficient arithmetic and excludes legacy.

Important JS storage refinement (verified from current own generated output)

The current build has no ES2020 or -Xes-long-as-bigint option. The compiled own
krogu-math.js creates new Long(...) values; a retained common Long can therefore
retain an extra runtime object on JS. Prefer compactHigh:Int + compactLow:Int
(two's-complement high/low bits) as the physical primitive fields on the shared
representation, reconstructing Long transiently for exact arithmetic. JVM,
Native and Wasm still use eight primitive payload bytes; JS retains primitive
Number-valued fields rather than an emulated Long wrapper. Measure runtime layout
rather than assuming equal byte counts. Do not claim a one-object graph on JS
merely because the source field type is Long.

Official mapping reference, consulted without numerical implementation sources:
https://kotlinlang.org/docs/js-to-kotlin-interop.html#use-bigint-type-to-represent-kotlin-s-long-type
BigInt mapping is available with ES2020/explicit compiler support; enabling the
experimental flag globally is an alternative toolchain decision with its own
compatibility/performance verification, not a prerequisite silently added to529.
