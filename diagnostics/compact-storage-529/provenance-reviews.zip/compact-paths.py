from pathlib import Path
p=Path('src/commonMain/kotlin/io/heapy/krogu/math/BigInteger.kt');s=p.read_text()
# Place primitive work before the operation's first scratch snapshot.
def prefix(name,code):
 global s
 start=s.index('fun '+name+'('); pos=s.index('{',start)+1
 s=s[:pos]+'\n'+code+s[pos:]
prefix('add','''        if (representation == 1 && value.representation == 1) {
            val a = compactStoredValue529(); val b = value.compactStoredValue529()
            val result = a + b
            if (CompactInteger529.addFits(a, b, result)) return valueOf(result)
        }''')
prefix('subtract','''        if (representation == 1 && value.representation == 1) {
            val a = compactStoredValue529(); val b = value.compactStoredValue529()
            val result = a - b
            if (CompactInteger529.subtractFits(a, b, result)) return valueOf(result)
        }''')
prefix('multiply','''        if (representation == 1 && value.representation == 1) {
            val a = compactStoredValue529(); val b = value.compactStoredValue529()
            val result = a * b
            if (CompactInteger529.multiplyFits(a, b, result)) return valueOf(result)
        }''')
s=s.replace('open fun negate(): BigInteger = if (sign == 0) this else BigInteger(-sign, materializeMagnitude())','''open fun negate(): BigInteger {
        if (sign == 0) return this
        if (representation == 1 && compactStoredValue529() != Long.MIN_VALUE) return valueOf(-compactStoredValue529())
        return BigInteger(-sign, materializeMagnitude())
    }''')
# Receiver/argument scratch borrows exactly once in add/subtract/multiply/division.
for name in ['add','subtract','multiply']:
 a=s.index('fun '+name+'('); b=s.index('\n    }',a)
 t=s[a:b]; t=t.replace('val words = materializeMagnitude()','val words = materializeMagnitude()\n        val valueWords = if (value === this) words else value.materializeMagnitude()');t=t.replace('value.materializeMagnitude()', 'valueWords',t.count('value.materializeMagnitude()'))
 # restore declaration (the textual substitution must not refer to itself).
 t=t.replace('else valueWords','else value.materializeMagnitude()',1);s=s[:a]+t+s[b:]
# Division has the divisor-zero check first, then compact signed quotient including MIN/-1 promotion.
a=s.index('    private inline fun <T> selectStoredDivision('); b=s.index('    private fun normalizeStoredDivision',a);t=s[a:b]
t=t.replace('        val words = materializeMagnitude()\n','')
needle='        if (value.sign == 0) throw ArithmeticException("BigInteger divide by zero")'
assert needle in t
t=t.replace(needle,needle+'''
        if (representation == 1 && value.representation == 1) {
            val a = compactStoredValue529(); val b = value.compactStoredValue529()
            val quotient = if (!needQuotient) ZERO else if (a == Long.MIN_VALUE && b == -1L)
                BigInteger(1, intArrayOf(0, 0, 8)) else valueOf(a / b)
            return select(quotient, if (needRemainder) valueOf(a % b) else ZERO)
        }
        val words = materializeMagnitude()
        val valueWords = if (value === this) words else value.materializeMagnitude()''')
t=t.replace('value.materializeMagnitude()', 'valueWords');t=t.replace('else valueWords','else value.materializeMagnitude()',1);s=s[:a]+t+s[b:]
prefix('bitLength','''        if (representation == 1) {
            val value = compactStoredValue529()
            return 64 - (if (value < 0) value.inv() else value).countLeadingZeroBits()
        }''')
prefix('bitCount','''        if (representation == 1) {
            val value = compactStoredValue529()
            if (value >= 0) return value.countOneBits()
            // Keep the existing negative receiver's virtual lowest-set-bit callback.
            return (-value).countOneBits() + getLowestSetBit() - 1
        }''')
prefix('lowestSetBitValue','''        if (representation == 1) {
            val value = compactStoredValue529()
            return if (value == 0L) -1 else value.countTrailingZeroBits()
        }''')
prefix('firstNonzeroWord','''        if (representation == 1) return compactStoredValue529().countTrailingZeroBits() / LIMB_BITS''')
prefix('testBitValue','''        if (n < 0) throw ArithmeticException("Negative bit address")
        if (representation == 1) return if (n >= 64) sign < 0
            else compactStoredValue529() and (1L shl n) != 0L''')
prefix('compareTo','''        if (representation == 1 && other.representation == 1)
            return compactStoredValue529().compareTo(other.compactStoredValue529())''')
prefix('magnitudeWord32','''        if (representation == 1) {
            val value = compactStoredValue529()
            val magnitude = if (value < 0) -value else value
            return if (index in 0..1) (magnitude ushr (index * 32)) and 0xffffffffL else 0L
        }''')
prefix('toInt','''        if (representation == 1) return compactLow''')
prefix('toLong','''        if (representation == 1) return compactStoredValue529()''')
# decimalCompactValue deliberately keeps its established MIN exclusion.
a=s.index('    internal fun decimalCompactValue(): Long? {');b=s.index('\n    }',a)+6
s=s[:a]+'''    internal fun decimalCompactValue(): Long? {
        if (representation != 1) return null
        val value = compactStoredValue529()
        return if (value == Long.MIN_VALUE) null else value
    }'''+s[b:]
prefix('decimalMagnitudeDigits','''        if (representation == 1) return CompactInteger529.decimalDigits(compactStoredValue529())''')
# Metadata-only decline prefixes must not allocate compact scratch views.
for name,anchor in [
 ('alignedDecimalSum585','        return DecimalSum585.sum('),
 ('roundedDecimalProduct580','        return DecimalProduct580.rounded('),
 ('roundedDecimalQuotient581','        if (mc.precision > 646456993)'),
 ('integralDecimalQuotient582','        if (preferred < 0)'),
 ('fixedScaleDecimalQuotient592','        return DecimalDivision581.fixedScale592'),
 ('certifiedExactLowResidual590','        val exact = try {')]:
 a=s.index('fun '+name+'(');b=s.index('\n    }',a);t=s[a:b]
 t=t.replace('        val words = materializeMagnitude()\n','');i=t.index(anchor);t=t[:i]+'        val words = materializeMagnitude()\n'+t[i:];s=s[:a]+t+s[b:]
# Repeated exponent/base limb reads: snapshot once per selected operation, never per bit.
a=s.index('    private fun oddModPowStored(');b=s.index('\n    /** Fixed-modulus',a);t=s[a:b]
t=t.replace('        val trivialBase =','        val baseWords = base.materializeMagnitude()\n        val powerWords = power.materializeMagnitude()\n        val trivialBase =').replace('base.materializeMagnitude()', 'baseWords').replace('power.materializeMagnitude()', 'powerWords')
t=t.replace('val baseWords = baseWords','val baseWords = base.materializeMagnitude()').replace('val powerWords = powerWords','val powerWords = power.materializeMagnitude()');s=s[:a]+t+s[b:]
a=s.index('        fun pow(base: BigInteger, power: BigInteger, bits: Int)');b=s.index('\n        private fun ',a);t=s[a:b]
t=t.replace('            val workspace =','            val powerWords = power.materializeMagnitude()\n            val workspace =',1).replace('power.materializeMagnitude()[','powerWords[');s=s[:a]+t+s[b:]
# No array on primitive floating conversion (preserve virtual Number callbacks).
a=s.index('    private fun floatingValue(');b=s.index('    open fun intValueExact',a);t=s[a:b]
t=t.replace('        val words = materializeMagnitude()\n','').replace('        val shift =','        val words = materializeMagnitude()\n        val shift =',1);s=s[:a]+t+s[b:]
p.write_text(s)
p=Path('src/jvmMain/kotlin/io/heapy/krogu/math/MathSerializable.kt');s=p.read_text().replace('getDeclaredField("words")','getDeclaredField("wideWords")');p.write_text(s)
