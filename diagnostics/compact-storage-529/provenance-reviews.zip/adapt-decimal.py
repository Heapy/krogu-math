from pathlib import Path
import re
p=Path('src/commonMain/kotlin/io/heapy/krogu/math/BigDecimal.kt');s=p.read_text();a=s.index('open class BigDecimal(');b=s.index('    private fun readObjectNoData()',a)
s=s[:a]+'''open class BigDecimal private constructor(
    private val decimalScale: Int,
    private val compactHigh: Int,
    private val compactLow: Int,
    private val representation: Int,
    private val wideCoefficient: BigInteger?,
) : Number(), Comparable<BigDecimal>, MathSerializable {

    private constructor(value: Long, scale: Int) : this(scale, (value shr 32).toInt(), value.toInt(), 1, null)
    // The public constructor normalizes subclass byte encoding before selecting storage.
    constructor(coefficient: BigInteger, scale: Int) : this(normalizedCoefficient529(coefficient), scale, Unit)
    private constructor(coefficient: BigInteger, scale: Int, @Suppress("UNUSED_PARAMETER") owned: Unit) : this(
        scale,
        if (coefficient.hasCompactStorage529()) (coefficient.compactStoredValue529() shr 32).toInt() else 0,
        if (coefficient.hasCompactStorage529()) coefficient.compactStoredValue529().toInt() else 0,
        if (coefficient.hasCompactStorage529()) 1 else 2,
        if (coefficient.hasCompactStorage529()) null else coefficient,
    )
    private constructor(value: BigDecimal) : this(value.decimalScale, value.compactHigh, value.compactLow,
        value.representation, value.wideCoefficient)

    private fun compactValue529(): Long = CompactInteger529.value(compactHigh, compactLow)
    private fun coefficientSnapshot(): BigInteger = wideCoefficient ?: BigInteger.valueOf(compactValue529())
    @kotlin.jvm.JvmSynthetic
    internal fun hasCompactStorage529(): Boolean = representation == 1
    private fun storedSign529(): Int = if (representation == 1) compactValue529().compareTo(0L)
        else wideCoefficient!!.signum()
    private fun readObject(stream: MathObjectInputStream) {
        restoreSerializedFields(stream)
        when (representation) {
            1 -> if (wideCoefficient != null) invalidSerializedState("Invalid compact BigDecimal")
            2 -> {
                val restored = wideCoefficient ?: invalidSerializedState("Missing BigDecimal coefficient")
                if (compactHigh != 0 || compactLow != 0 ||
                    restored::class == BigInteger::class && restored.hasCompactStorage529())
                    invalidSerializedState("Invalid wide BigDecimal")
                // A stream-restored coefficient subclass keeps its virtual behavior,
                // subtype fields and graph identity. Public construction normalizes it.
            }
            else -> invalidSerializedState("Missing BigDecimal representation")
        }
    }
''' + s[b:]
s=s.replace('constructor(value: Long) : this(BigInteger.valueOf(value), 0)', 'constructor(value: Long) : this(value, 0)')
s=s.replace('BigDecimal(BigInteger.valueOf(unscaledVal), scale)','BigDecimal(unscaledVal, scale)')
# Explicit object snapshots, never a computed coefficient property.
s=re.sub(r'\b(\w+)\.coefficient\b',r'\1.coefficientSnapshot()',s)
# Snapshot the receiver once for block-bodied legacy fallbacks only.
limit=s.index('    companion object {');head=s[:limit];tail=s[limit:]
starts=list(re.finditer(r'^    (?:private |internal |open |override )*fun \w+\(',head,re.M))
for m in reversed(starts):
 name=re.search(r'fun (\w+)',m.group()).group(1)
 if name in ['readObject','coefficientSnapshot','compactValue529','hasCompactStorage529','storedSign529']:continue
 nextm=next((q.start() for q in starts if q.start()>m.start()),len(head))
 chunk=head[m.start():nextm]
 i=chunk.index('(');depth=1;i+=1
 while depth:
  if chunk[i]=='(':depth+=1
  elif chunk[i]==')':depth-=1
  i+=1
 rest=chunk[i:];first=re.search(r'[={]',rest)
 if not first or first.group()!='{': continue
 bodypos=i+first.start()+1
 code='\n'.join(line for line in chunk[bodypos:].splitlines() if not line.lstrip().startswith('//'))
 if re.search(r'(?<![\w.])coefficient\b',code):
  chunk=chunk[:bodypos]+'\n        val coefficient = coefficientSnapshot()'+chunk[bodypos:]
  head=head[:m.start()]+chunk+head[nextm:]
s=head+tail
# Scalar metadata and expression methods.
s=s.replace('open fun unscaledValue(): BigInteger = coefficient','open fun unscaledValue(): BigInteger = coefficientSnapshot()')
s=s.replace('private fun storedPrecision(): Int = coefficient.decimalMagnitudeDigits()', '''private fun storedPrecision(): Int = if (representation == 1) CompactInteger529.decimalDigits(compactValue529())
        else wideCoefficient!!.decimalMagnitudeDigits()''')
s=s.replace('open fun signum(): Int = coefficient.signum()', 'open fun signum(): Int = storedSign529()')
s=s.replace('open fun negate(): BigDecimal = BigDecimal(coefficient.negate(), decimalScale)', '''open fun negate(): BigDecimal = if (representation == 1 && compactValue529() != Long.MIN_VALUE)
        BigDecimal(-compactValue529(), decimalScale) else BigDecimal(coefficientSnapshot().negate(), decimalScale)''')
s=s.replace('if (coefficient.signum() == 0) roundValue(mc) else plus(mc)', 'if (storedSign529() == 0) roundValue(mc) else plus(mc)')
s=s.replace('open fun stripTrailingZeros(): BigDecimal = if (coefficient.signum() == 0)', 'open fun stripTrailingZeros(): BigDecimal = if (storedSign529() == 0)')
s=s.replace('open fun scaleByPowerOfTen(n: Int): BigDecimal = BigDecimal(coefficient, scaleForValue(decimalScale.toLong() - n, coefficient.signum() == 0))', '''open fun scaleByPowerOfTen(n: Int): BigDecimal = withScale529(scaleForValue(decimalScale.toLong() - n, storedSign529() == 0))''')
s=s.replace('override fun equals(other: Any?): Boolean = other is BigDecimal && decimalScale == other.decimalScale && coefficient == other.coefficientSnapshot()', '''override fun equals(other: Any?): Boolean = other is BigDecimal && decimalScale == other.decimalScale &&
        if (representation == 1 && other.representation == 1) compactHigh == other.compactHigh && compactLow == other.compactLow
        else coefficientSnapshot() == other.coefficientSnapshot()''')
s=s.replace('override fun hashCode(): Int = 31 * coefficient.hashCode() + decimalScale', '''override fun hashCode(): Int {
        if (representation != 1) return 31 * wideCoefficient.hashCode() + decimalScale
        val value = compactValue529()
        val magnitude = if (value < 0) -value else value
        val hash = (31L * (magnitude ushr 32).toInt() + (magnitude and 0xffffffffL)).toInt()
        return 31 * (if (value < 0) -hash else hash) + decimalScale
    }
    private fun withScale529(scale: Int): BigDecimal =
        BigDecimal(scale, compactHigh, compactLow, representation, wideCoefficient)''')
# Companion normalization is constructor-only, retaining virtual byte callback once.
pos=s.index('    companion object {')+len('    companion object {');s=s[:pos]+'''
        private fun normalizedCoefficient529(value: BigInteger): BigInteger =
            if (value::class == BigInteger::class) value else BigInteger(value.toByteArray())
'''+s[pos:]
p.write_text(s)
