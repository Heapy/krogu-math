#!/usr/bin/env kotlinr
// Task-owned launcher; never builds or changes numerical sources.
import java.io.File
import java.security.MessageDigest
import java.time.Instant
import java.util.concurrent.TimeUnit

require(args.size == 6) { "jvm|js|wasm|native baselineTree candidateTree runtimeBinary newOutput checkerScript" }
val platform = args[0]
require(platform in listOf("jvm", "js", "wasm", "native"))
val trees = listOf(File(args[1]).canonicalFile, File(args[2]).canonicalFile)
check(trees.distinct().size == 2 && trees.all { it.isDirectory })
val node = File(args[3]).canonicalFile
val output = File(args[4]).canonicalFile
val checker = File(args[5]).canonicalFile
check(!output.exists() && checker.isFile)
check(output.toPath().startsWith(File("/Users/yoda/dev/pet/krogu-math/.codex-work/529").toPath()))
check(output.mkdirs())
fun sha(file: File) = MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString("") { "%02x".format(it) }
fun tree(root: File) = root.walkTopDown().filter { it.isFile }.associate { it.relativeTo(root).path to sha(it) }.toSortedMap()
val frozen = trees.map(::tree)
val checkerSha = sha(checker)
val nodeSha = if (platform == "native") "NA" else sha(node)
val launcher = File("/Users/yoda/dev/pet/krogu-math/.codex-work/529/run-portable-pairs.main.kts")
val launcherSha = sha(launcher)
fun clean(builder: ProcessBuilder) {
    builder.environment().clear()
    builder.environment()["LANG"] = "C"
    builder.environment()["TZ"] = "UTC"
}
fun execute(command: List<String>, log: File, seconds: Long) {
    File(log.path + ".argv.txt").writeText(command.joinToString("\n", postfix = "\n"))
    val builder = ProcessBuilder(command).redirectErrorStream(true).redirectOutput(log)
    clean(builder)
    val child = builder.start()
    var completed = false
    var failure: Throwable? = null
    try {
        File(log.path + ".identity.txt").writeText("pid=${child.pid()} start=${child.toHandle().info().startInstant().orElse(null)}\n")
        completed = child.waitFor(seconds, TimeUnit.SECONDS)
        check(completed) { "Deadline: $log" }
        check(child.exitValue() == 0) { "Child failed: $log exit=${child.exitValue()}" }
    } catch (caught: Throwable) {
        failure = caught
        throw caught
    } finally {
        if (!completed || child.isAlive) {
            var cleanupFailure: Throwable? = null
            fun record(caught: Throwable) {
                if (cleanupFailure == null) cleanupFailure = caught else cleanupFailure!!.addSuppressed(caught)
            }
            val descendants = try { child.toHandle().descendants().toList() }
                catch (caught: Throwable) { record(caught); emptyList() }
            for (handle in descendants.asReversed() + child.toHandle()) {
                try { handle.destroyForcibly() } catch (caught: Throwable) { record(caught) }
            }
            val until = System.nanoTime() + TimeUnit.SECONDS.toNanos(10)
            val capturedInterrupt = Thread.interrupted()
            var interrupted = capturedInterrupt || failure is InterruptedException
            for (handle in descendants + child.toHandle()) {
                while (handle.isAlive && System.nanoTime() < until) {
                    try { handle.onExit().get(maxOf(1L, until - System.nanoTime()), TimeUnit.NANOSECONDS); break }
                    catch (_: InterruptedException) { interrupted = true }
                    catch (_: java.util.concurrent.TimeoutException) { break }
                    catch (caught: Throwable) { record(caught); break }
                }
            }
            val survivors = descendants.filter { it.isAlive }.map { it.pid() }
            if (child.isAlive || survivors.isNotEmpty())
                record(IllegalStateException("Owned cleanup survivors=$survivors rootAlive=${child.isAlive}"))
            if (interrupted) Thread.currentThread().interrupt()
            if (cleanupFailure != null) {
                if (failure != null) failure.addSuppressed(cleanupFailure!!) else throw cleanupFailure!!
            }
        }
    }
}
File(output, "binding-before.txt").writeText(buildString {
    appendLine("timestamp=${Instant.now()} platform=$platform launcher=$launcherSha checker=$checkerSha node=$nodeSha")
    trees.forEachIndexed { i, root ->
        appendLine("tree[$i]=$root")
        frozen[i].forEach { (path, digest) -> appendLine("$digest  $i/$path") }
    }
})
if (platform == "jvm") {
    execute(listOf(node.path, "-XshowSettings:properties", "-version"), File(output, "java-version.log"), 10)
    val version = File(output, "java-version.log").readText()
    check(version.contains("java.runtime.version = 25.0.4+9-LTS") && version.contains("java.vendor = BellSoft"))
} else if (platform != "native") {
    execute(listOf(node.path, "--version"), File(output, "node-version.log"), 10)
    check(File(output, "node-version.log").readText().trim() == "v24.16.0")
}
// Launch/wait budget; binding hashes and bounded cleanup add overhead beyond45minutes.
val campaignDeadline = System.nanoTime() + TimeUnit.MINUTES.toNanos(45)
for (fork in 0..2) {
    val order = if (fork % 2 == 0) listOf(0, 1) else listOf(1, 0)
    for (index in order) {
        check(System.nanoTime() < campaignDeadline)
        check(tree(trees[index]) == frozen[index])
        val commandPrefix = if (platform == "jvm") {
            val entries = File(trees[index], "jvm-classpath.txt").readLines().filter(String::isNotBlank).map { relative ->
                val file = File(trees[index], relative).canonicalFile
                check(file.exists() && file.toPath().startsWith(trees[index].toPath()))
                file.path
            }
            check(entries.isNotEmpty())
            listOf(node.path, "-Xms256m", "-Xmx512m", "-XX:+UseG1GC", "-cp", entries.joinToString(File.pathSeparator), "bench.MainKt")
        } else {
            val entry = File(trees[index], when (platform) {
                "js" -> "js/krogu-math-benchmarks.js"
                "wasm" -> "wasm/krogu-math-benchmarks.mjs"
                else -> "benchmarks.kexe"
            })
            check(entry.isFile)
            if (platform == "native") listOf(entry.path) else listOf(node.path, "--expose-gc", entry.path)
        }
        val command = commandPrefix + listOf("compact529", "3", "7", "20", "100000")
        val label = if (index == 0) "baseline" else "candidate"
        val seconds = minOf(600L, TimeUnit.NANOSECONDS.toSeconds(campaignDeadline - System.nanoTime()))
        check(seconds > 0)
        execute(command, File(output, "$fork-$label.log"), seconds)
        println("COMPLETE $platform $fork $label")
    }
}
check(trees.map(::tree) == frozen && sha(checker) == checkerSha && sha(launcher) == launcherSha)
check(platform == "native" || sha(node) == nodeSha)
// Child logs are retained even if the independent coverage checker rejects them.
File(output, "EXECUTED_SOURCE_BOUND_NOT_YET_METRICS_VALIDATED").writeText("six children exit0; checker/graph acceptance pending\n")
println("PASS execution and artifact binding; metric/graph validation remains separate")
