# Task529 independent literal acceptance

Verdict: substantive implementation, correctness and measurement requirements PASS; canonical packaging/committed-byte verification and serial integration remain pending. This is not a claim that task state is already done.

The live task was re-read under explicit owned session a6bbf558. It requires compact primitive representation for BOTH BigInteger and BigDecimal, preservation of public classes/constructors, immutability, scale/exact results, delayed coefficient materialization, fullLong/promotion/demotion/overflow/sign/current-format serialization/subclass checks, plus measured small/wide arithmetic and retained storage on target platforms including additional wide fields. It does not require universal speedup, an allocation-free path for every operation, JDK parity, exact allocator occupancy or a particular GC-delta method.

## Requirement and completed evidence

| Literal requirement | Accepted evidence |
|---|---|
| Both physical compact types, fullLong and wide fallback | Reviewed primitive halves/tag/nullable wide storage, no allocating computed facade; direct Long/MIN paths and canonical transition tests; composition source reviews retained |
| Exact results, scale, overflow and signs | Endpoint/carry/rounding/cohort common fixtures and6,776-case JVM public-oracle division matrix; full2055 regression |
| Public constructors, subclass and current-format serialization behavior | Full current-format/subtype/null/Float guard-sticky/callback suites, source-specific reviewed fixture setup changes and production publication repair; no existing failed assertions weakened |
| Current settled production correctness | 09e6dc36b3dfaae3878dbe6304b9c9dcaa96735d: focused84984 passed120 affected JVM methods, then unfiltered46319 passed684/457/457/457=2055 with0fail/error/skip; all320 source hashes and507 archived XML members independently checked |
| Current JVM small/wide arithmetic, transient allocation and owned graph | independent-jvm-fifth-raw-graph-audit.json:87962/1386 TIME/33 cases, exact prepared16 inputs and fresh roots;17 all-three wins, fresh accumulator sole all-three adverse; every pooled/per-fork and allocation cost retained |
| Current JS arithmetic | independent-portable-js-3-raw-audit.json:71641/882 TIME/21 cases;9 all-three wins,8 all-three adverse; JS GC-delta retained control remains FAILED_UNVERIFIED |
| Current Wasm arithmetic and available runtime metric | independent-portable-wasm-2-raw-audit.json:40973/882 TIME/486 RETAIN;15 all-three wins,4 adverse; known-payload controls PASS, slopes explicitly not exact graph |
| Current Native arithmetic | independent-portable-native-2-raw-audit.json:77132/882 TIME/21 cases;12 all-three wins,5 adverse; three GC-delta checkers failed and remain FAILED_UNVERIFIED |
| JS/Wasm retained graphs and shared-cache scope | Actual historical9641 root/strong-ownership/control graphs and cache observations retain their artifact identities. Final generated storage/factory/schema binding is explicitly scoped in independent-final-compiled-memory-applicability-review.json; no fresh final PropertyArray/hidden-class capture is claimed |
| Native actual storage evidence | Matched Debug16-phase actual ownership/field/payload/256-byte controls and independent permanentUnit proofs, with pinned runtime ABI extents separately modeled. independent-native-debug-final-report-review.json. Failed GC slopes are not relabelled. No allocator total or Release graph claim |
| Extra wide fields and new shared-cache cost | JVM wideBI+8/BD+16B; JS/Wasm observed cohort costs and NativeDebug modeled+12/+24B reported with exact scopes. Shared caches/helpers are separate from per-number graphs;152 logical payload is never total heap |
| Independent implementation and source provenance | All production changes are owned common Kotlin; no foreign numerical implementation bodies used. Runtime-only dump/schema/ABI metadata is separate provenance, not a numerical implementation source |

The initial full45317 identity-observation failures, setup failures, intermediate adverse timing campaigns, JS/Native failed runtime-memory methods and optional Release TypeInfo metadata failure must remain in the canonical package. Optional metadata failure preserves Debug-only memory scope; it creates no new acceptance gate. Current numeric measurements are not mixed with older source eras or compared across protocols as controlled isolated-stage effects.

Concrete avoidable costs found during review were repaired proportionately: duplicate snapshots, transition scratch, compact-divisor materialization, scalar-wide input arrays, repeated digit work/power construction and changed result publication. Remaining wide layout/fallback and platform-specific adverse timing are measured limits, not proven inherent lower bounds. No further numerical change or benchmark rerun is justified by the completed literal scope.

## Only remaining actions

Owner produces canonical report/tables/requirement matrix/raw selection/index in diagnostics/compact-storage-529. Coordinator verifies exact inventory/SHA/ZIP-member bytes, report scope/current source identities, committed Git blobs and unchanged tested production, then integrates serially into clean main. Only then transition the owned tracker session and preserve/clean its completed worktrees normally. No extra runtime gate is introduced here.
