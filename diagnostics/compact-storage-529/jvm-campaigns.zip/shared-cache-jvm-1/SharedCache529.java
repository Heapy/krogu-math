import java.io.File;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.Field;
public final class SharedCache529 {
    static void origin(Class<?> type, File expected) throws Exception {
        File actual=new File(type.getProtectionDomain().getCodeSource().getLocation().toURI()).getCanonicalFile();
        if(!actual.equals(expected))throw new AssertionError("origin "+type);
    }
    public static void main(String[] args) throws Exception {
        if(!System.getProperty("java.runtime.version").equals("25.0.4+9-LTS") || !System.getProperty("java.vendor").equals("BellSoft"))throw new AssertionError("runtime");
        if(Runtime.getRuntime().maxMemory()!=536870912L)throw new AssertionError("heap");
        File main=new File(args[0]).getCanonicalFile(),agent=new File(args[1]).getCanonicalFile();
        origin(SharedCache529.class,new File(args[2]).getCanonicalFile());
        origin(Class.forName("io.heapy.krogu.math.BigInteger",false,SharedCache529.class.getClassLoader()),main);
        Class<?> probe=Class.forName("Compact529Probe"); origin(probe,agent);
        Field instrument=probe.getDeclaredField("instrumentation");instrument.setAccessible(true);
        Instrumentation inst=(Instrumentation)instrument.get(null);
        if(inst==null)throw new AssertionError("agent missing");
        final Class<?> helper;
        try { helper=Class.forName("io.heapy.krogu.math.CompactInteger529"); }
        catch(ClassNotFoundException absent) { System.out.println("CACHE,ABSENT,0,0,0");return; }
        origin(helper,main);
        Field cache=helper.getDeclaredField("negativePowers");cache.setAccessible(true);
        long[] values=(long[])cache.get(null);
        if(values.length!=19)throw new AssertionError("length");
        long power=-1;
        for(int i=0;i<19;i++){if(values[i]!=power)throw new AssertionError("threshold "+i);if(i<18)power*=10;}
        Object instance=helper.getField("INSTANCE").get(null);
        System.out.println("CACHE,PRESENT,"+inst.getObjectSize(values)+","+inst.getObjectSize(instance)+",152");
    }
}