(function (_, kotlin_kotlin, kotlin_com_ionspin_kotlin_bignum, kotlin_io_heapy_krogu_krogu_math) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var Unit_instance = kotlin_kotlin.$_$.n1;
  var THROW_IAE = kotlin_kotlin.$_$.y5;
  var Enum = kotlin_kotlin.$_$.s5;
  var protoOf = kotlin_kotlin.$_$.m4;
  var initMetadataForClass = kotlin_kotlin.$_$.a4;
  var VOID = kotlin_kotlin.$_$.a;
  var getBooleanHashCode = kotlin_kotlin.$_$.x3;
  var getStringHashCode = kotlin_kotlin.$_$.y3;
  var constructCallableReference = kotlin_kotlin.$_$.u3;
  var Companion_getInstance = kotlin_com_ionspin_kotlin_bignum.$_$.d;
  var Companion_getInstance_0 = kotlin_com_ionspin_kotlin_bignum.$_$.c;
  var noWhenBranchMatchedException = kotlin_kotlin.$_$.m6;
  var THROW_CCE = kotlin_kotlin.$_$.x5;
  var BigInteger = kotlin_com_ionspin_kotlin_bignum.$_$.b;
  var BigDecimal = kotlin_com_ionspin_kotlin_bignum.$_$.a;
  var initMetadataForObject = kotlin_kotlin.$_$.d4;
  var BigInteger_init_$Create$ = kotlin_io_heapy_krogu_krogu_math.$_$.b;
  var BigDecimal_init_$Create$ = kotlin_io_heapy_krogu_krogu_math.$_$.a;
  var BigInteger_0 = kotlin_io_heapy_krogu_krogu_math.$_$.d;
  var BigDecimal_0 = kotlin_io_heapy_krogu_krogu_math.$_$.c;
  var toString = kotlin_kotlin.$_$.o4;
  var hashCode = kotlin_kotlin.$_$.z3;
  var equals = kotlin_kotlin.$_$.w3;
  var IllegalStateException_init_$Create$ = kotlin_kotlin.$_$.v1;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.d;
  var charArrayOf = kotlin_kotlin.$_$.o3;
  var split = kotlin_kotlin.$_$.g5;
  var listOf = kotlin_kotlin.$_$.m2;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.u1;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.o1;
  var to = kotlin_kotlin.$_$.p6;
  var println = kotlin_kotlin.$_$.r2;
  var Long = kotlin_kotlin.$_$.u5;
  var charSequenceLength = kotlin_kotlin.$_$.s3;
  var charSequenceGet = kotlin_kotlin.$_$.r3;
  var Char__toInt_impl_vasixd = kotlin_kotlin.$_$.g;
  var ValueTimeMark__elapsedNow_impl_eonqvs = kotlin_kotlin.$_$.c;
  var _Duration___get_inWholeNanoseconds__impl__r5x4mr = kotlin_kotlin.$_$.b;
  var endsWith = kotlin_kotlin.$_$.a5;
  var NoSuchElementException_init_$Create$ = kotlin_kotlin.$_$.y1;
  var toInt = kotlin_kotlin.$_$.l5;
  var subtract = kotlin_kotlin.$_$.l3;
  var compare = kotlin_kotlin.$_$.x2;
  var convertToInt = kotlin_kotlin.$_$.z2;
  var fromInt = kotlin_kotlin.$_$.c3;
  var add = kotlin_kotlin.$_$.t2;
  var Monotonic_instance = kotlin_kotlin.$_$.l1;
  var Regex_init_$Create$ = kotlin_kotlin.$_$.p1;
  var toLong = kotlin_kotlin.$_$.m5;
  var trimStart = kotlin_kotlin.$_$.q5;
  var trimEnd = kotlin_kotlin.$_$.p5;
  var repeat = kotlin_kotlin.$_$.e5;
  var numberToLong = kotlin_kotlin.$_$.h3;
  //endregion
  //region block: pre-declaration
  initMetadataForClass(ExactOperation, 'ExactOperation', VOID, Enum);
  initMetadataForClass(Capability, 'Capability');
  initMetadataForObject(IonsPinAdapter, 'IonsPinAdapter');
  initMetadataForObject(KroguAdapter, 'KroguAdapter');
  initMetadataForClass(TextPrepared598, 'TextPrepared598');
  initMetadataForClass(TimedCase598, 'TimedCase598');
  initMetadataForClass(Counters598, 'Counters598', Counters598);
  initMetadataForClass(ExactFixture598, 'ExactFixture598');
  initMetadataForClass(Preservation598, 'Preservation598');
  //endregion
  var static_init_called;
  function static_init() {
    if (static_init_called)
      return Unit_instance;
    static_init_called = true;
    ExactOperation_ADD_instance = new ExactOperation('ADD', 0);
    ExactOperation_SUBTRACT_instance = new ExactOperation('SUBTRACT', 1);
    ExactOperation_MULTIPLY_instance = new ExactOperation('MULTIPLY', 2);
  }
  var ExactOperation_ADD_instance;
  var ExactOperation_SUBTRACT_instance;
  var ExactOperation_MULTIPLY_instance;
  function valueOf(value) {
    static_init();
    switch (value) {
      case 'ADD':
        return ExactOperation_ADD_getInstance();
      case 'SUBTRACT':
        return ExactOperation_SUBTRACT_getInstance();
      case 'MULTIPLY':
        return ExactOperation_MULTIPLY_getInstance();
      default:
        THROW_IAE('No enum constant preparation598.ExactOperation.' + value);
        break;
    }
  }
  function ExactOperation(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function Capability(eligibleAfterFixtureGate, reason) {
    this.ms_1 = eligibleAfterFixtureGate;
    this.ns_1 = reason;
  }
  protoOf(Capability).toString = function () {
    return 'Capability(eligibleAfterFixtureGate=' + this.ms_1 + ', reason=' + this.ns_1 + ')';
  };
  protoOf(Capability).hashCode = function () {
    var result = getBooleanHashCode(this.ms_1);
    result = imul(result, 31) + getStringHashCode(this.ns_1) | 0;
    return result;
  };
  protoOf(Capability).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof Capability))
      return false;
    if (!(this.ms_1 === other.ms_1))
      return false;
    if (!(this.ns_1 === other.ns_1))
      return false;
    return true;
  };
  function ExactOperation_ADD_getInstance() {
    static_init();
    return ExactOperation_ADD_instance;
  }
  function ExactOperation_SUBTRACT_getInstance() {
    static_init();
    return ExactOperation_SUBTRACT_instance;
  }
  function ExactOperation_MULTIPLY_getInstance() {
    static_init();
    return ExactOperation_MULTIPLY_instance;
  }
  function PeerAdapter$integer$ref(p0) {
    return constructCallableReference(function (p0_0) {
      return p0.os(p0_0);
    }, 1, 0, 0, 'integer', [p0]);
  }
  function PeerAdapter$integerText$ref(p0) {
    return constructCallableReference(function (p0_0) {
      return p0.ps(p0_0);
    }, 1, 0, 1, 'integerText', [p0]);
  }
  function PeerAdapter$decimal$ref(p0) {
    return constructCallableReference(function (p0_0) {
      return p0.qs(p0_0);
    }, 1, 0, 2, 'decimal', [p0]);
  }
  function PeerAdapter$decimalText$ref(p0) {
    return constructCallableReference(function (p0_0) {
      return p0.rs(p0_0);
    }, 1, 0, 3, 'decimalText', [p0]);
  }
  function PeerAdapter$integer$ref_0(p0) {
    return constructCallableReference(function (p0_0) {
      return p0.os(p0_0);
    }, 1, 0, 0, 'integer', [p0]);
  }
  function PeerAdapter$integerText$ref_0(p0) {
    return constructCallableReference(function (p0_0) {
      return p0.ps(p0_0);
    }, 1, 0, 1, 'integerText', [p0]);
  }
  function PeerAdapter$integerOperation$ref(p0) {
    return constructCallableReference(function (p0_0, p1, p2) {
      return p0.ss(p0_0, p1, p2);
    }, 3, 0, 4, 'integerOperation', [p0]);
  }
  function PeerAdapter$decimal$ref_0(p0) {
    return constructCallableReference(function (p0_0) {
      return p0.qs(p0_0);
    }, 1, 0, 2, 'decimal', [p0]);
  }
  function PeerAdapter$decimalText$ref_0(p0) {
    return constructCallableReference(function (p0_0) {
      return p0.rs(p0_0);
    }, 1, 0, 3, 'decimalText', [p0]);
  }
  function PeerAdapter$decimalOperation$ref(p0) {
    return constructCallableReference(function (p0_0, p1, p2) {
      return p0.ts(p0_0, p1, p2);
    }, 3, 0, 5, 'decimalOperation', [p0]);
  }
  function PeerAdapter$integer$ref_1(p0) {
    return constructCallableReference(function (p0_0) {
      return p0.os(p0_0);
    }, 1, 0, 0, 'integer', [p0]);
  }
  function PeerAdapter$integerText$ref_1(p0) {
    return constructCallableReference(function (p0_0) {
      return p0.ps(p0_0);
    }, 1, 0, 1, 'integerText', [p0]);
  }
  function PeerAdapter$integerOperation$ref_0(p0) {
    return constructCallableReference(function (p0_0, p1, p2) {
      return p0.ss(p0_0, p1, p2);
    }, 3, 0, 4, 'integerOperation', [p0]);
  }
  function PeerAdapter$decimal$ref_1(p0) {
    return constructCallableReference(function (p0_0) {
      return p0.qs(p0_0);
    }, 1, 0, 2, 'decimal', [p0]);
  }
  function PeerAdapter$decimalText$ref_1(p0) {
    return constructCallableReference(function (p0_0) {
      return p0.rs(p0_0);
    }, 1, 0, 3, 'decimalText', [p0]);
  }
  function PeerAdapter$decimalOperation$ref_0(p0) {
    return constructCallableReference(function (p0_0, p1, p2) {
      return p0.ts(p0_0, p1, p2);
    }, 3, 0, 5, 'decimalOperation', [p0]);
  }
  function IonsPinAdapter() {
    IonsPinAdapter_instance = this;
    this.us_1 = 'ionspin-bignum-0.3.10';
    this.vs_1 = new Capability(false, 'DecimalMode precision/scale propagation is not JDK fixed-scale divide');
    this.ws_1 = new Capability(false, 'HALF_EVEN public mapping unverified; README tie descriptions conflict; untimed oracle gate pending');
  }
  protoOf(IonsPinAdapter).xs = function () {
    return this.us_1;
  };
  protoOf(IonsPinAdapter).os = function (text) {
    return Companion_getInstance().ji(text, 10);
  };
  protoOf(IonsPinAdapter).qs = function (text) {
    return Companion_getInstance_0().ll(text);
  };
  protoOf(IonsPinAdapter).ys = function (operation, a, b) {
    var tmp;
    switch (operation.v1_1) {
      case 0:
        tmp = a.si(b);
        break;
      case 1:
        tmp = a.ui(b);
        break;
      case 2:
        tmp = a.wi(b);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(IonsPinAdapter).ss = function (operation, a, b) {
    var tmp = a instanceof BigInteger ? a : THROW_CCE();
    return this.ys(operation, tmp, b instanceof BigInteger ? b : THROW_CCE());
  };
  protoOf(IonsPinAdapter).zs = function (operation, a, b) {
    var tmp;
    switch (operation.v1_1) {
      case 0:
        tmp = a.jm(b);
        break;
      case 1:
        tmp = a.em(b);
        break;
      case 2:
        tmp = a.dm(b);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(IonsPinAdapter).ts = function (operation, a, b) {
    var tmp = a instanceof BigDecimal ? a : THROW_CCE();
    return this.zs(operation, tmp, b instanceof BigDecimal ? b : THROW_CCE());
  };
  protoOf(IonsPinAdapter).at = function (value) {
    return value.mg(10);
  };
  protoOf(IonsPinAdapter).ps = function (value) {
    return this.at(value instanceof BigInteger ? value : THROW_CCE());
  };
  protoOf(IonsPinAdapter).bt = function (value) {
    return value.mm();
  };
  protoOf(IonsPinAdapter).rs = function (value) {
    return this.bt(value instanceof BigDecimal ? value : THROW_CCE());
  };
  var IonsPinAdapter_instance;
  function IonsPinAdapter_getInstance() {
    if (IonsPinAdapter_instance == null)
      new IonsPinAdapter();
    return IonsPinAdapter_instance;
  }
  function KroguAdapter() {
    KroguAdapter_instance = this;
    this.ct_1 = 'krogu-final539-PENDING';
    this.dt_1 = new Capability(true, 'explicit scale and HALF_UP; fixture gate required');
    this.et_1 = new Capability(true, 'MathContext available; original MC34 separate from fixed-scale');
  }
  protoOf(KroguAdapter).xs = function () {
    return this.ct_1;
  };
  protoOf(KroguAdapter).os = function (text) {
    return BigInteger_init_$Create$(text);
  };
  protoOf(KroguAdapter).qs = function (text) {
    return BigDecimal_init_$Create$(text);
  };
  protoOf(KroguAdapter).ft = function (operation, a, b) {
    var tmp;
    switch (operation.v1_1) {
      case 0:
        tmp = a.ad(b);
        break;
      case 1:
        tmp = a.yc(b);
        break;
      case 2:
        tmp = a.oc(b);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(KroguAdapter).ss = function (operation, a, b) {
    var tmp = a instanceof BigInteger_0 ? a : THROW_CCE();
    return this.ft(operation, tmp, b instanceof BigInteger_0 ? b : THROW_CCE());
  };
  protoOf(KroguAdapter).gt = function (operation, a, b) {
    var tmp;
    switch (operation.v1_1) {
      case 0:
        tmp = a.ie(b);
        break;
      case 1:
        tmp = a.je(b);
        break;
      case 2:
        tmp = a.ke(b);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  };
  protoOf(KroguAdapter).ts = function (operation, a, b) {
    var tmp = a instanceof BigDecimal_0 ? a : THROW_CCE();
    return this.gt(operation, tmp, b instanceof BigDecimal_0 ? b : THROW_CCE());
  };
  protoOf(KroguAdapter).ht = function (value) {
    return value.toString();
  };
  protoOf(KroguAdapter).ps = function (value) {
    return this.ht(value instanceof BigInteger_0 ? value : THROW_CCE());
  };
  protoOf(KroguAdapter).it = function (value) {
    return value.toString();
  };
  protoOf(KroguAdapter).rs = function (value) {
    return this.it(value instanceof BigDecimal_0 ? value : THROW_CCE());
  };
  var KroguAdapter_instance;
  function KroguAdapter_getInstance() {
    if (KroguAdapter_instance == null)
      new KroguAdapter();
    return KroguAdapter_instance;
  }
  function TextPrepared598(input, operation, checkResult, checkInput) {
    this.jt_1 = input;
    this.kt_1 = operation;
    this.lt_1 = checkResult;
    this.mt_1 = checkInput;
  }
  protoOf(TextPrepared598).toString = function () {
    return 'TextPrepared598(input=' + this.jt_1 + ', operation=' + toString(this.kt_1) + ', checkResult=' + toString(this.lt_1) + ', checkInput=' + toString(this.mt_1) + ')';
  };
  protoOf(TextPrepared598).hashCode = function () {
    var result = getStringHashCode(this.jt_1);
    result = imul(result, 31) + hashCode(this.kt_1) | 0;
    result = imul(result, 31) + hashCode(this.lt_1) | 0;
    result = imul(result, 31) + hashCode(this.mt_1) | 0;
    return result;
  };
  protoOf(TextPrepared598).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TextPrepared598))
      return false;
    if (!(this.jt_1 === other.jt_1))
      return false;
    if (!equals(this.kt_1, other.kt_1))
      return false;
    if (!equals(this.lt_1, other.lt_1))
      return false;
    if (!equals(this.mt_1, other.mt_1))
      return false;
    return true;
  };
  function textInput598(family, name) {
    var tmp;
    switch (family + '/' + name) {
      case 'int/zero':
        tmp = '0';
        break;
      case 'int/signed':
        tmp = '-7';
        break;
      case 'int/carry30':
        tmp = '1073741823';
        break;
      case 'int/wide10':
        tmp = '100000000000000000000';
        break;
      case 'decimal/zero':
        tmp = '0';
        break;
      case 'decimal/scale':
        tmp = '1.2';
        break;
      case 'decimal/signed':
        tmp = '-1.25';
        break;
      case 'decimal/wide10':
        tmp = '100000000000000000001.25';
        break;
      default:
        // Inline function 'kotlin.error' call

        var message = 'Unknown text fixture';
        throw IllegalStateException_init_$Create$(toString(message));
    }
    return tmp;
  }
  function textCase598(adapter, id) {
    var p = split(id, charArrayOf([_Char___init__impl__6a9atx(47)]));
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(p.i() === 3 && listOf(['PARSE', 'FORMAT']).p1(p.n(2)))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    var input = textInput598(p.n(0), p.n(1));
    var tmp;
    switch (p.n(0)) {
      case 'int':
        var tmp_0 = PeerAdapter$integer$ref(adapter);
        tmp = textCase598$typed(p, input, adapter, id, tmp_0, PeerAdapter$integerText$ref(adapter));
        break;
      case 'decimal':
        var tmp_1 = PeerAdapter$decimal$ref(adapter);
        tmp = textCase598$typed(p, input, adapter, id, tmp_1, PeerAdapter$decimalText$ref(adapter));
        break;
      default:
        // Inline function 'kotlin.error' call

        var message_0 = 'Unknown text family';
        throw IllegalStateException_init_$Create$(toString(message_0));
    }
    return tmp;
  }
  function verifyTextWorkloads598(adapter) {
    var count = 0;
    // Inline function 'kotlin.collections.mutableListOf' call
    var retained = ArrayList_init_$Create$();
    var _iterator__ex2g4s = listOf([to('int', listOf(['zero', 'signed', 'carry30', 'wide10'])), to('decimal', listOf(['zero', 'scale', 'signed', 'wide10']))]).f();
    while (_iterator__ex2g4s.g()) {
      var _destruct__k2r9zo = _iterator__ex2g4s.h();
      var family = _destruct__k2r9zo.u9();
      var names = _destruct__k2r9zo.v9();
      var _iterator__ex2g4s_0 = names.f();
      while (_iterator__ex2g4s_0.g()) {
        var name = _iterator__ex2g4s_0.h();
        var _iterator__ex2g4s_1 = listOf(['PARSE', 'FORMAT']).f();
        while (_iterator__ex2g4s_1.g()) {
          var op = _iterator__ex2g4s_1.h();
          var id = family + '/' + name + '/' + op;
          var case_0 = textCase598(adapter, id);
          // Inline function 'kotlin.repeat' call
          var inductionVariable = 0;
          if (inductionVariable < 2)
            do {
              var index = inductionVariable;
              inductionVariable = inductionVariable + 1 | 0;
              var result = case_0.kt_1();
              var observed = case_0.lt_1(result);
              case_0.mt_1();
              // Inline function 'kotlin.collections.forEach' call
              var _iterator__ex2g4s_2 = retained.f();
              while (_iterator__ex2g4s_2.g()) {
                var element = _iterator__ex2g4s_2.h();
                var old = element.u9();
                var value = element.v9();
                // Inline function 'kotlin.check' call
                if (!(old.lt_1(value) === old.jt_1)) {
                  throw IllegalStateException_init_$Create$('Check failed.');
                }
                old.mt_1();
              }
              // Inline function 'kotlin.collections.plusAssign' call
              var element_0 = to(case_0, result);
              retained.e(element_0);
              println('CHECK_TEXT598\t' + adapter.xs() + '\t' + id + '\t' + index + '\t' + case_0.jt_1 + '\t' + observed);
              count = count + 1 | 0;
            }
             while (inductionVariable < 2);
        }
      }
    }
    // Inline function 'kotlin.check' call
    if (!(count === 32)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    println('TEXT_GATE598_COUNT\t' + adapter.xs() + '\t' + count);
    return count;
  }
  function textCase598$typed$lambda($parse, $input) {
    return function () {
      return $parse($input);
    };
  }
  function textCase598$typed$lambda_0($text, $input, $adapter, $id) {
    return function (result) {
      var observed = $text(!(result == null) ? result : THROW_CCE());
      // Inline function 'kotlin.check' call
      if (!(observed === $input)) {
        var message = $adapter.xs() + ':' + $id + ' non-equivalent parse observation: ' + observed + ' vs ' + $input;
        throw IllegalStateException_init_$Create$(toString(message));
      }
      return observed;
    };
  }
  function textCase598$typed$lambda_1($input, $p) {
    return function () {
      // Inline function 'kotlin.check' call
      if (!($input === textInput598($p.n(0), $p.n(1)))) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      return Unit_instance;
    };
  }
  function textCase598$typed$lambda_2($text, $value) {
    return function () {
      // Inline function 'kotlin.checkNotNull' call
      var tmp0 = $value;
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.checkNotNull' call
        if (tmp0 == null) {
          var message = 'Required value was null.';
          throw IllegalStateException_init_$Create$(toString(message));
        } else {
          tmp$ret$1 = tmp0;
          break $l$block;
        }
      }
      var tmp$ret$0 = tmp$ret$1;
      return $text(tmp$ret$0);
    };
  }
  function textCase598$typed$lambda_3($input, $adapter, $id) {
    return function (result) {
      var tmp;
      if (typeof result === 'string') {
        tmp = equals(result, $input);
      } else {
        tmp = false;
      }
      // Inline function 'kotlin.check' call
      if (!tmp) {
        var message = $adapter.xs() + ':' + $id + ' non-equivalent format:' + toString(result) + ' vs ' + $input;
        throw IllegalStateException_init_$Create$(toString(message));
      }
      return result;
    };
  }
  function textCase598$typed$lambda_4($text, $value, $input) {
    return function () {
      // Inline function 'kotlin.checkNotNull' call
      var tmp0 = $value;
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.checkNotNull' call
        if (tmp0 == null) {
          var message = 'Required value was null.';
          throw IllegalStateException_init_$Create$(toString(message));
        } else {
          tmp$ret$1 = tmp0;
          break $l$block;
        }
      }
      var tmp$ret$0 = tmp$ret$1;
      // Inline function 'kotlin.check' call
      if (!($text(tmp$ret$0) === $input)) {
        var message_0 = 'Format input changed/non-equivalent';
        throw IllegalStateException_init_$Create$(toString(message_0));
      }
      return Unit_instance;
    };
  }
  function textCase598$typed(p, input, $adapter, $id, parse, text) {
    var value = p.n(2) === 'FORMAT' ? parse(input) : null;
    var tmp;
    if (p.n(2) === 'PARSE') {
      var tmp_0 = textCase598$typed$lambda(parse, input);
      var tmp_1 = textCase598$typed$lambda_0(text, input, $adapter, $id);
      tmp = new TextPrepared598(input, tmp_0, tmp_1, textCase598$typed$lambda_1(input, p));
    } else {
      var tmp_2 = textCase598$typed$lambda_2(text, value);
      var tmp_3 = textCase598$typed$lambda_3(input, $adapter, $id);
      tmp = new TextPrepared598(input, tmp_2, tmp_3, textCase598$typed$lambda_4(text, value, input));
    }
    return tmp;
  }
  function get_clock598() {
    _init_properties_Timing598_kt__b6e2s8();
    return clock598;
  }
  var clock598;
  function TimedCase598(peer, id, inputLeft, inputRight, relation, expected, operation, checkResult, checkInputs) {
    this.nt_1 = peer;
    this.ot_1 = id;
    this.pt_1 = inputLeft;
    this.qt_1 = inputRight;
    this.rt_1 = relation;
    this.st_1 = expected;
    this.tt_1 = operation;
    this.ut_1 = checkResult;
    this.vt_1 = checkInputs;
  }
  protoOf(TimedCase598).toString = function () {
    return 'TimedCase598(peer=' + this.nt_1 + ', id=' + this.ot_1 + ', inputLeft=' + this.pt_1 + ', inputRight=' + this.qt_1 + ', relation=' + this.rt_1 + ', expected=' + this.st_1 + ', operation=' + toString(this.tt_1) + ', checkResult=' + toString(this.ut_1) + ', checkInputs=' + toString(this.vt_1) + ')';
  };
  protoOf(TimedCase598).hashCode = function () {
    var result = getStringHashCode(this.nt_1);
    result = imul(result, 31) + getStringHashCode(this.ot_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.pt_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.qt_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.rt_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.st_1) | 0;
    result = imul(result, 31) + hashCode(this.tt_1) | 0;
    result = imul(result, 31) + hashCode(this.ut_1) | 0;
    result = imul(result, 31) + hashCode(this.vt_1) | 0;
    return result;
  };
  protoOf(TimedCase598).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof TimedCase598))
      return false;
    if (!(this.nt_1 === other.nt_1))
      return false;
    if (!(this.ot_1 === other.ot_1))
      return false;
    if (!(this.pt_1 === other.pt_1))
      return false;
    if (!(this.qt_1 === other.qt_1))
      return false;
    if (!(this.rt_1 === other.rt_1))
      return false;
    if (!(this.st_1 === other.st_1))
      return false;
    if (!equals(this.tt_1, other.tt_1))
      return false;
    if (!equals(this.ut_1, other.ut_1))
      return false;
    if (!equals(this.vt_1, other.vt_1))
      return false;
    return true;
  };
  function Counters598() {
    this.wt_1 = new Long(-1, -1);
    this.xt_1 = new Long(-1, -1);
    this.yt_1 = new Long(-1, -1);
    this.zt_1 = new Long(-1, -1);
  }
  function checksumString598(text) {
    _init_properties_Timing598_kt__b6e2s8();
    // Inline function 'kotlin.text.fold' call
    var accumulator = 0;
    var inductionVariable = 0;
    while (inductionVariable < charSequenceLength(text)) {
      var element = charSequenceGet(text, inductionVariable);
      inductionVariable = inductionVariable + 1 | 0;
      var h = accumulator;
      var tmp = imul(31, h);
      // Inline function 'kotlin.code' call
      accumulator = tmp + Char__toInt_impl_vasixd(element) | 0;
    }
    return accumulator;
  }
  function now598() {
    _init_properties_Timing598_kt__b6e2s8();
    return _Duration___get_inWholeNanoseconds__impl__r5x4mr(ValueTimeMark__elapsedNow_impl_eonqvs(get_clock598()));
  }
  function coreCase598(adapter, id) {
    _init_properties_Timing598_kt__b6e2s8();
    if (endsWith(id, '/PARSE') || endsWith(id, '/FORMAT')) {
      var t = textCase598(adapter, id);
      return new TimedCase598(adapter.xs(), id, t.jt_1, t.jt_1, 'unary-text', t.jt_1, t.kt_1, t.lt_1, t.mt_1);
    }
    var parts = split(id, charArrayOf([_Char___init__impl__6a9atx(47)]));
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(parts.i() === 3)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    var family = parts.n(0);
    var fixtureId = parts.n(1);
    var opName = parts.n(2);
    var tmp;
    if (family === 'int') {
      tmp = get_integerFixtures598();
    } else {
      // Inline function 'kotlin.require' call
      // Inline function 'kotlin.require' call
      if (!(family === 'decimal')) {
        var message_0 = 'Failed requirement.';
        throw IllegalArgumentException_init_$Create$(toString(message_0));
      }
      tmp = get_decimalFixtures598();
    }
    // Inline function 'kotlin.collections.single' call
    var single = null;
    var found = false;
    var _iterator__ex2g4s = tmp.f();
    while (_iterator__ex2g4s.g()) {
      var element = _iterator__ex2g4s.h();
      if (element.au_1 === fixtureId) {
        if (found)
          throw IllegalArgumentException_init_$Create$('Collection contains more than one matching element.');
        single = element;
        found = true;
      }
    }
    if (!found)
      throw NoSuchElementException_init_$Create$('Collection contains no element matching the predicate.');
    var f = single;
    var op = opName === 'self' ? ExactOperation_MULTIPLY_getInstance() : valueOf(opName);
    var tmp_0;
    switch (opName) {
      case 'ADD':
        tmp_0 = f.du_1;
        break;
      case 'SUBTRACT':
        tmp_0 = f.eu_1;
        break;
      case 'MULTIPLY':
        tmp_0 = f.fu_1;
        break;
      case 'self':
        tmp_0 = f.gu_1;
        break;
      default:
        // Inline function 'kotlin.error' call

        var message_1 = 'Unknown operation';
        throw IllegalStateException_init_$Create$(toString(message_1));
    }
    var expected = tmp_0;
    var tmp_1;
    if (family === 'int') {
      var tmp_2 = PeerAdapter$integer$ref_0(adapter);
      var tmp_3 = PeerAdapter$integerText$ref_0(adapter);
      tmp_1 = coreCase598$typed(f, opName, adapter, id, expected, op, family, tmp_2, tmp_3, PeerAdapter$integerOperation$ref(adapter));
    } else {
      var tmp_4 = PeerAdapter$decimal$ref_0(adapter);
      var tmp_5 = PeerAdapter$decimalText$ref_0(adapter);
      tmp_1 = coreCase598$typed(f, opName, adapter, id, expected, op, family, tmp_4, tmp_5, PeerAdapter$decimalOperation$ref(adapter));
    }
    return tmp_1;
  }
  function main(args) {
    _init_properties_Timing598_kt__b6e2s8();
    // Inline function 'kotlin.require' call
    if (!(args.length === 4)) {
      var message = 'peer workload fork order';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    // Inline function 'kotlin.collections.component1' call
    var peer = args[0];
    // Inline function 'kotlin.collections.component2' call
    var id = args[1];
    // Inline function 'kotlin.collections.component3' call
    var forkText = args[2];
    // Inline function 'kotlin.collections.component4' call
    var order = args[3];
    // Inline function 'kotlin.also' call
    var this_0 = toInt(forkText);
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(0 <= this_0 ? this_0 <= 2 : false)) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString(message_0));
    }
    var fork = this_0;
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(order === (fork === 1 ? 'reverse' : 'forward'))) {
      var message_1 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString(message_1));
    }
    var runtime = portableRuntime598();
    println('IDENTITY598\t' + runtime + '\t' + peer + '\t' + id + '\t' + fork + '\t' + order);
    var case_0 = selectedCase598(peer, id);
    // Inline function 'kotlin.check' call
    if (!(case_0.nt_1 === peer && case_0.ot_1 === id)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var before = new Counters598();
    var after = new Counters598();
    // Inline function 'kotlin.arrayOfNulls' call
    var ring = Array(64);
    println('INPUT598\t' + case_0.pt_1 + '\t' + case_0.qt_1 + '\t' + case_0.rt_1 + '\t' + case_0.st_1);
    println('SCOPE598\t' + metricScope598());
    println('COLD598_SCOPE\tFRESH_CHILD_FIRST_EXPLICIT_SELECTED_OP_AFTER_DECLARED_PREPARATION\tPRISTINE_VM_OR_INTERNAL_CACHE_NA');
    counters598(before, true);
    var firstStart = now598();
    var first = case_0.tt_1();
    ring[0] = first;
    publishRing598(ring);
    var firstNs = subtract(now598(), firstStart);
    counters598(after, false);
    // Inline function 'kotlin.check' call
    if (!(compare(firstNs, new Long(0, 0)) > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var firstText = case_0.ut_1(first);
    case_0.vt_1();
    println('FIRST598\t' + peer + '\t' + id + '\t' + fork + '\t1\t' + firstNs.toString() + '\t' + main$delta(before.wt_1, after.wt_1) + '\t' + main$delta(before.xt_1, after.xt_1) + '\t' + main$available(before.yt_1) + '\t' + main$available(after.yt_1) + '\t' + main$available(after.zt_1) + '\t' + checksumString598(firstText));
    verifyAll598();
    case_0.vt_1();
    println('GATE598_PASS\t' + peer + '\t' + id + '\t' + fork);
    var retainedFirstText = case_0.ut_1(first);
    var count = 1;
    var warmOps = new Long(0, 0);
    var warmStart = now598();
    while (compare(subtract(now598(), warmStart), new Long(200000000, 0)) < 0 && compare(warmOps, new Long(1048576, 0)) < 0) {
      var tmp0 = count;
      // Inline function 'kotlin.comparisons.minOf' call
      var b = convertToInt(subtract(new Long(1048576, 0), warmOps));
      var n = Math.min(tmp0, b);
      var elapsed = main$batch(before, ring, case_0, after, first, retainedFirstText, peer, id, fork, n, -1, false);
      // Inline function 'kotlin.Long.plus' call
      var this_1 = warmOps;
      warmOps = add(this_1, fromInt(n));
      if (compare(elapsed, new Long(20000000, 0)) < 0 && count < 1048576) {
        // Inline function 'kotlin.comparisons.minOf' call
        var a = imul(count, 2);
        count = Math.min(a, 1048576);
      }
    }
    println('WARM598\t' + peer + '\t' + id + '\t' + fork + '\t' + warmOps.toString() + '\t' + subtract(now598(), warmStart).toString() + '\t' + count + '\tTARGET200ms_CAP1048576ops_TARGET20msbatch');
    // Inline function 'kotlin.repeat' call
    var inductionVariable = 0;
    if (inductionVariable < 7)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        main$batch(before, ring, case_0, after, first, retainedFirstText, peer, id, fork, count, index, true);
      }
       while (inductionVariable < 7);
    println('COMPLETE598_TIMING_CHILD\t' + peer + '\t' + id + '\t' + fork);
  }
  function coreCase598$typed$canonical(family, value) {
    var tmp;
    if (family === 'int') {
      tmp = value;
    } else {
      // Inline function 'kotlin.let' call
      var it = canonicalDecimal598(value);
      tmp = it.s9_1 + '@' + it.t9_1.toString();
    }
    return tmp;
  }
  function coreCase598$typed$lambda($operation, $op, $a, $b) {
    return function () {
      return $operation($op, $a, $b);
    };
  }
  function coreCase598$typed$lambda_0($text, $expected, $adapter, $id, $family) {
    return function (value) {
      var actual = $text(!(value == null) ? value : THROW_CCE());
      // Inline function 'kotlin.check' call
      if (!(coreCase598$typed$canonical($family, actual) === coreCase598$typed$canonical($family, $expected))) {
        var message = $adapter.xs() + ':' + $id + ' result mismatch:' + actual + ' vs' + $expected;
        throw IllegalStateException_init_$Create$(toString(message));
      }
      return coreCase598$typed$canonical($family, actual);
    };
  }
  function coreCase598$typed$lambda_1($text, $a, $f, $b, $rightText, $family) {
    return function () {
      // Inline function 'kotlin.check' call
      if (!(coreCase598$typed$canonical($family, $text($a)) === coreCase598$typed$canonical($family, $f.bu_1) && coreCase598$typed$canonical($family, $text($b)) === coreCase598$typed$canonical($family, $rightText))) {
        var message = 'Input changed';
        throw IllegalStateException_init_$Create$(toString(message));
      }
      return Unit_instance;
    };
  }
  function coreCase598$typed(f, opName, $adapter, $id, expected, op, family, parse, text, operation) {
    var a = parse(f.bu_1);
    var b = opName === 'self' ? a : parse(f.cu_1);
    var rightText = opName === 'self' ? f.bu_1 : f.cu_1;
    var tmp = $adapter.xs();
    var tmp_0 = opName === 'self' ? 'self-alias' : a === b ? 'binary-native-alias' : 'binary-distinct';
    var tmp_1 = coreCase598$typed$lambda(operation, op, a, b);
    var tmp_2 = coreCase598$typed$lambda_0(text, expected, $adapter, $id, family);
    return new TimedCase598(tmp, $id, f.bu_1, rightText, tmp_0, expected, tmp_1, tmp_2, coreCase598$typed$lambda_1(text, a, f, b, rightText, family));
  }
  function main$available(value) {
    return compare(value, new Long(0, 0)) < 0 ? 'NA' : value.toString();
  }
  function main$delta(a, b) {
    if (compare(a, new Long(0, 0)) < 0 || compare(b, new Long(0, 0)) < 0)
      return 'NA';
    // Inline function 'kotlin.check' call
    if (!(compare(b, a) >= 0)) {
      var message = 'Counter decreased';
      throw IllegalStateException_init_$Create$(toString(message));
    }
    return subtract(b, a).toString();
  }
  function main$batch(before, ring, case_0, after, first, retainedFirstText, peer, id, fork, count, sample, record) {
    counters598(before, true);
    var start = now598();
    // Inline function 'kotlin.repeat' call
    var inductionVariable = 0;
    if (inductionVariable < count)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        ring[index & 63] = case_0.tt_1();
      }
       while (inductionVariable < count);
    publishRing598(ring);
    var elapsed = subtract(now598(), start);
    counters598(after, false);
    // Inline function 'kotlin.check' call
    if (!(compare(elapsed, new Long(0, 0)) > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var digest = 0;
    // Inline function 'kotlin.comparisons.minOf' call
    // Inline function 'kotlin.repeat' call
    var times = Math.min(count, 64);
    var inductionVariable_0 = 0;
    if (inductionVariable_0 < times)
      do {
        var index_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        var tmp = imul(31, digest);
        // Inline function 'kotlin.checkNotNull' call
        var tmp0 = ring[index_0];
        var tmp$ret$7;
        $l$block: {
          // Inline function 'kotlin.checkNotNull' call
          if (tmp0 == null) {
            var message = 'Required value was null.';
            throw IllegalStateException_init_$Create$(toString(message));
          } else {
            tmp$ret$7 = tmp0;
            break $l$block;
          }
        }
        var tmp$ret$6 = tmp$ret$7;
        digest = tmp + checksumString598(case_0.ut_1(tmp$ret$6)) | 0;
      }
       while (inductionVariable_0 < times);
    case_0.vt_1();
    // Inline function 'kotlin.check' call
    if (!(case_0.ut_1(first) === retainedFirstText)) {
      var message_0 = 'Retained FIRST result changed';
      throw IllegalStateException_init_$Create$(toString(message_0));
    }
    if (record) {
      println('TIME598\t' + peer + '\t' + id + '\t' + fork + '\t' + sample + '\t' + count + '\t' + elapsed.toString() + '\t' + main$delta(before.wt_1, after.wt_1) + '\t' + main$delta(before.xt_1, after.xt_1) + '\t' + main$available(before.yt_1) + '\t' + main$available(after.yt_1) + '\t' + main$available(after.zt_1) + '\t' + digest);
    }
    return elapsed;
  }
  var properties_initialized_Timing598_kt_9xk22u;
  function _init_properties_Timing598_kt__b6e2s8() {
    if (!properties_initialized_Timing598_kt_9xk22u) {
      properties_initialized_Timing598_kt_9xk22u = true;
      clock598 = Monotonic_instance.a8();
    }
  }
  function mainWrapper() {
    main([]);
  }
  function get_integerFixtures598() {
    _init_properties_TimingUntimed598_kt__2426lc();
    return integerFixtures598;
  }
  var integerFixtures598;
  function get_decimalFixtures598() {
    _init_properties_TimingUntimed598_kt__2426lc();
    return decimalFixtures598;
  }
  var decimalFixtures598;
  function ExactFixture598(id, a, b, sum, difference, product, square) {
    this.au_1 = id;
    this.bu_1 = a;
    this.cu_1 = b;
    this.du_1 = sum;
    this.eu_1 = difference;
    this.fu_1 = product;
    this.gu_1 = square;
  }
  protoOf(ExactFixture598).toString = function () {
    return 'ExactFixture598(id=' + this.au_1 + ', a=' + this.bu_1 + ', b=' + this.cu_1 + ', sum=' + this.du_1 + ', difference=' + this.eu_1 + ', product=' + this.fu_1 + ', square=' + this.gu_1 + ')';
  };
  protoOf(ExactFixture598).hashCode = function () {
    var result = getStringHashCode(this.au_1);
    result = imul(result, 31) + getStringHashCode(this.bu_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.cu_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.du_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.eu_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.fu_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.gu_1) | 0;
    return result;
  };
  protoOf(ExactFixture598).equals = function (other) {
    if (this === other)
      return true;
    if (!(other instanceof ExactFixture598))
      return false;
    if (!(this.au_1 === other.au_1))
      return false;
    if (!(this.bu_1 === other.bu_1))
      return false;
    if (!(this.cu_1 === other.cu_1))
      return false;
    if (!(this.du_1 === other.du_1))
      return false;
    if (!(this.eu_1 === other.eu_1))
      return false;
    if (!(this.fu_1 === other.fu_1))
      return false;
    if (!(this.gu_1 === other.gu_1))
      return false;
    return true;
  };
  function canonicalDecimal598(text) {
    _init_properties_TimingUntimed598_kt__2426lc();
    var containsArg = text.length;
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(1 <= containsArg ? containsArg <= 10000 : false)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString(message));
    }
    var tmp0_elvis_lhs = Regex_init_$Create$('([+-]?)([0-9]+)(?:\\.([0-9]+))?(?:[eE]([+-]?[0-9]+))?').e7(text);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.error' call
      var message_0 = 'Unsupported public decimal observation: ' + text;
      throw IllegalStateException_init_$Create$(toString(message_0));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var match = tmp;
    var fraction = match.t7().n(3);
    // Inline function 'kotlin.text.ifEmpty' call
    var this_0 = match.t7().n(4);
    var tmp_0;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(this_0) === 0) {
      tmp_0 = '0';
    } else {
      tmp_0 = this_0;
    }
    var tmp$ret$4 = tmp_0;
    // Inline function 'kotlin.also' call
    var this_1 = toLong(tmp$ret$4);
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(new Long(-1000000, -1), this_1) <= 0 ? compare(this_1, new Long(1000000, 0)) <= 0 : false)) {
      var message_1 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString(message_1));
    }
    var exponent = this_1;
    var coefficient = trimStart(match.t7().n(2) + fraction, charArrayOf([_Char___init__impl__6a9atx(48)]));
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(coefficient) === 0)
      return to('0', new Long(0, 0));
    var digits = trimEnd(coefficient, charArrayOf([_Char___init__impl__6a9atx(48)]));
    var tmp0 = subtract(fromInt(fraction.length), exponent);
    // Inline function 'kotlin.Long.minus' call
    var other = coefficient.length - digits.length | 0;
    var scale = subtract(tmp0, fromInt(other));
    return to((match.t7().n(1) === '-' ? '-' : '') + digits, scale);
  }
  function verifyRetained($this) {
    var _iterator__ex2g4s = $this.iu_1.f();
    while (_iterator__ex2g4s.g()) {
      var _destruct__k2r9zo = _iterator__ex2g4s.h();
      var value = _destruct__k2r9zo.u9();
      var text = _destruct__k2r9zo.v9();
      // Inline function 'kotlin.check' call
      if (!($this.hu_1(value) === text)) {
        var message = 'Earlier result observation changed';
        throw IllegalStateException_init_$Create$(toString(message));
      }
    }
  }
  function Preservation598(observe) {
    this.hu_1 = observe;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.iu_1 = ArrayList_init_$Create$();
  }
  protoOf(Preservation598).ju = function (a, b, operation) {
    verifyRetained(this);
    var aBefore = this.hu_1(a);
    var bBefore = this.hu_1(b);
    var result = operation();
    // Inline function 'kotlin.check' call
    if (!(this.hu_1(a) === aBefore && this.hu_1(b) === bBefore)) {
      var message = 'Input observation changed';
      throw IllegalStateException_init_$Create$(toString(message));
    }
    verifyRetained(this);
    var tmp0 = this.iu_1;
    // Inline function 'kotlin.collections.plusAssign' call
    var element = to(result, this.hu_1(result));
    tmp0.e(element);
    return result;
  };
  function checkFamily598(peer, family, fixtures, parse, observe, operation, equivalent) {
    _init_properties_TimingUntimed598_kt__2426lc();
    var preservation = new Preservation598(observe);
    var core = {_v: 0};
    var distinct = {_v: 0};
    var _iterator__ex2g4s = fixtures.f();
    while (_iterator__ex2g4s.g()) {
      var fixture = _iterator__ex2g4s.h();
      var a = parse(fixture.bu_1);
      var b = parse(fixture.cu_1);
      // Inline function 'kotlin.check' call
      if (!(equivalent(observe(a), fixture.bu_1) && equivalent(observe(b), fixture.cu_1))) {
        var message = 'Parsed input value mismatch';
        throw IllegalStateException_init_$Create$(toString(message));
      }
      checkFamily598$repeated(preservation, observe, equivalent, peer, family, fixture, distinct, core, operation, 'add', a, b, ExactOperation_ADD_getInstance(), fixture.du_1);
      checkFamily598$repeated(preservation, observe, equivalent, peer, family, fixture, distinct, core, operation, 'subtract', a, b, ExactOperation_SUBTRACT_getInstance(), fixture.eu_1);
      checkFamily598$repeated(preservation, observe, equivalent, peer, family, fixture, distinct, core, operation, 'multiply', a, b, ExactOperation_MULTIPLY_getInstance(), fixture.fu_1);
      checkFamily598$repeated(preservation, observe, equivalent, peer, family, fixture, distinct, core, operation, 'self-alias', a, a, ExactOperation_MULTIPLY_getInstance(), fixture.gu_1);
      var equal = parse(fixture.bu_1);
      if (equal === a) {
        println('NA598\t' + peer + '\t' + family + '/' + fixture.au_1 + '/distinct-equal\tParser reused identity');
      } else {
        checkFamily598$repeated(preservation, observe, equivalent, peer, family, fixture, distinct, core, operation, 'distinct-equal', a, equal, ExactOperation_MULTIPLY_getInstance(), fixture.gu_1, true);
      }
    }
    var tmp;
    var tmp_0;
    if (core._v === 32) {
      var containsArg = distinct._v;
      tmp_0 = 0 <= containsArg ? containsArg <= 8 : false;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = (distinct._v % 2 | 0) === 0;
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.check' call
    if (!tmp) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return to(core._v, distinct._v);
  }
  function verifyPortableUntimed598() {
    _init_properties_TimingUntimed598_kt__2426lc();
    var runtime = portableRuntime598();
    println('BEGIN598_UNTIMED\t' + runtime + '\tKotlin2.4.21\tNO_PERFORMANCE_CLAIM');
    var core = {_v: 0};
    var distinct = {_v: 0};
    verifyPortableUntimed598$peer(core, distinct, KroguAdapter_getInstance());
    verifyPortableUntimed598$peer(core, distinct, IonsPinAdapter_getInstance());
    var tmp;
    if (core._v === 128) {
      var containsArg = distinct._v;
      tmp = 0 <= containsArg ? containsArg <= 32 : false;
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.check' call
    if (!tmp) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    println('NA598\tJDK\t' + runtime + '\tPublic java.math unavailable on this target; JVM entrypoint is separate');
    println('NA598\tKBigNum0.0.20\t' + runtime + '\tNo published JS/Wasm/macOS variant in pinned metadata');
    println('COMPLETE598_UNTIMED_ONLY\tcore=' + core._v + '\tdistinct=' + distinct._v);
  }
  function checkFamily598$repeated$lambda($operation, $op, $left, $right) {
    return function () {
      return $operation($op, $left, $right);
    };
  }
  function checkFamily598$repeated(preservation, $observe, $equivalent, $peer, $family, fixture, distinct, core, $operation, id, left, right, op, expected, isDistinct) {
    isDistinct = isDistinct === VOID ? false : isDistinct;
    var previousText = null;
    // Inline function 'kotlin.repeat' call
    var inductionVariable = 0;
    if (inductionVariable < 2)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var result = preservation.ju(left, right, checkFamily598$repeated$lambda($operation, op, left, right));
        var actual = $observe(result);
        // Inline function 'kotlin.check' call
        if (!$equivalent(actual, expected)) {
          var message = $peer + '/' + $family + '/' + fixture.au_1 + '/' + id + ': ' + actual + ' versus ' + expected;
          throw IllegalStateException_init_$Create$(toString(message));
        }
        // Inline function 'kotlin.check' call
        if (!(previousText == null || previousText === actual)) {
          var message_0 = 'Repeated result observation changed';
          throw IllegalStateException_init_$Create$(toString(message_0));
        }
        previousText = actual;
        println('CHECK598\t' + $peer + '\t' + $family + '/' + fixture.au_1 + '/' + id + '\t' + index + '\t' + actual + '\t' + expected + '\tVALUE_ONLY');
        if (isDistinct) {
          distinct._v = distinct._v + 1 | 0;
        } else {
          core._v = core._v + 1 | 0;
        }
      }
       while (inductionVariable < 2);
  }
  function verifyPortableUntimed598$peer$lambda(actual, expected) {
    _init_properties_TimingUntimed598_kt__2426lc();
    return actual === expected;
  }
  function verifyPortableUntimed598$peer$lambda_0(actual, expected) {
    _init_properties_TimingUntimed598_kt__2426lc();
    return canonicalDecimal598(actual).equals(canonicalDecimal598(expected));
  }
  function verifyPortableUntimed598$peer(core, distinct, adapter) {
    var tmp = adapter.xs();
    var tmp_0 = get_integerFixtures598();
    var tmp_1 = PeerAdapter$integer$ref_1(adapter);
    var tmp_2 = PeerAdapter$integerText$ref_1(adapter);
    var tmp_3 = PeerAdapter$integerOperation$ref_0(adapter);
    var integer = checkFamily598(tmp, 'int', tmp_0, tmp_1, tmp_2, tmp_3, verifyPortableUntimed598$peer$lambda);
    var tmp_4 = adapter.xs();
    var tmp_5 = get_decimalFixtures598();
    var tmp_6 = PeerAdapter$decimal$ref_1(adapter);
    var tmp_7 = PeerAdapter$decimalText$ref_1(adapter);
    var tmp_8 = PeerAdapter$decimalOperation$ref_0(adapter);
    var decimal = checkFamily598(tmp_4, 'decimal', tmp_5, tmp_6, tmp_7, tmp_8, verifyPortableUntimed598$peer$lambda_0);
    verifyTextWorkloads598(adapter);
    core._v = core._v + (integer.s9_1 + decimal.s9_1 | 0) | 0;
    distinct._v = distinct._v + (integer.t9_1 + decimal.t9_1 | 0) | 0;
    println('NA598\t' + adapter.xs() + '\tdecimal-cohort\tValue-only oracle does not establish internal scale');
    println('NA598\t' + adapter.xs() + '\tsignificant-HALF_EVEN\tNot exercised; no ambiguous mapping inferred');
  }
  var properties_initialized_TimingUntimed598_kt_tdvgaq;
  function _init_properties_TimingUntimed598_kt__2426lc() {
    if (!properties_initialized_TimingUntimed598_kt_tdvgaq) {
      properties_initialized_TimingUntimed598_kt_tdvgaq = true;
      integerFixtures598 = listOf([new ExactFixture598('zero', '0', '0', '0', '0', '0', '0'), new ExactFixture598('signed', '-7', '3', '-4', '-10', '-21', '49'), new ExactFixture598('carry30', '1073741823', '1', '1073741824', '1073741822', '1073741823', '1152921502459363329'), new ExactFixture598('wide10', '100000000000000000000', '-10', '99999999999999999990', '100000000000000000010', '-1000000000000000000000', '1' + repeat('0', 40))]);
      decimalFixtures598 = listOf([new ExactFixture598('zero', '0.00', '-0.000', '0.000', '0.000', '0.00000', '0.0000'), new ExactFixture598('scale', '1.20', '3.400', '4.600', '-2.200', '4.08000', '1.4400'), new ExactFixture598('signed', '-1.25', '0.05', '-1.20', '-1.30', '-0.0625', '1.5625'), new ExactFixture598('wide10', '100000000000000000000.0', '-10.00', '99999999999999999990.00', '100000000000000000010.00', '-1000000000000000000000.000', '1' + repeat('0', 40) + '.00')]);
    }
  }
  var escaped598;
  function nodeVersion598() {
    var tmp = process.versions.node;
    return (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE();
  }
  function cpu598() {
    var tmp = function () {
      const u = process.cpuUsage();
      return (u.user + u.system) * 1000;
    }();
    return (!(tmp == null) ? typeof tmp === 'number' : false) ? tmp : THROW_CCE();
  }
  function heap598() {
    var tmp = process.memoryUsage().heapUsed;
    return (!(tmp == null) ? typeof tmp === 'number' : false) ? tmp : THROW_CCE();
  }
  function rss598() {
    var tmp = process.resourceUsage().maxRSS * 1024;
    return (!(tmp == null) ? typeof tmp === 'number' : false) ? tmp : THROW_CCE();
  }
  function portableRuntime598() {
    // Inline function 'kotlin.check' call
    if (!(nodeVersion598() === '24.16.0')) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return 'JS/Node24.16.0';
  }
  function publishRing598(ring) {
    escaped598 = ring;
  }
  function counters598(destination, before) {
    destination.wt_1 = numberToLong(cpu598());
    destination.xt_1 = new Long(-1, -1);
    destination.yt_1 = numberToLong(heap598());
    destination.zt_1 = numberToLong(rss598());
  }
  function metricScope598() {
    return 'Node process CPU(user+system); JS whole-process used-heap snapshots; process maxRSS through snapshot; allocation/owned-retained NA; adapter/ring escape overhead included';
  }
  function selectedCase598(peer, id) {
    var tmp;
    switch (peer) {
      case 'krogu-final539-PENDING':
        tmp = coreCase598(KroguAdapter_getInstance(), id);
        break;
      case 'ionspin-bignum-0.3.10':
        tmp = coreCase598(IonsPinAdapter_getInstance(), id);
        break;
      default:
        // Inline function 'kotlin.error' call

        var message = 'Peer not published for JS:' + peer;
        throw IllegalStateException_init_$Create$(toString(message));
    }
    return tmp;
  }
  function verifyAll598() {
    verifyPortableUntimed598();
  }
  //region block: init
  escaped598 = null;
  //endregion
  mainWrapper();
  return _;
}(module.exports, require('./kotlin-kotlin-stdlib.js'), require('./KotlinBigInteger-bignum.js'), require('./krogu-math.js')));

//# sourceMappingURL=peer598-timing.js.map
