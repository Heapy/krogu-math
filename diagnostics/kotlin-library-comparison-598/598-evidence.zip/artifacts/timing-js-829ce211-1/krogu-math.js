(function (_, kotlin_kotlin) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var clz32 = Math.clz32;
  var getKClassFromExpression = kotlin_kotlin.$_$.v4;
  var getKClass = kotlin_kotlin.$_$.w4;
  var NumberFormatException_init_$Create$ = kotlin_kotlin.$_$.z1;
  var isFinite = kotlin_kotlin.$_$.l6;
  var toBits = kotlin_kotlin.$_$.n6;
  var shiftRightUnsigned = kotlin_kotlin.$_$.j3;
  var Long = kotlin_kotlin.$_$.u5;
  var bitwiseAnd = kotlin_kotlin.$_$.u2;
  var convertToInt = kotlin_kotlin.$_$.z2;
  var fromInt = kotlin_kotlin.$_$.c3;
  var subtract = kotlin_kotlin.$_$.l3;
  var bitwiseOr = kotlin_kotlin.$_$.v2;
  var countTrailingZeroBits = kotlin_kotlin.$_$.j6;
  var ArithmeticException_init_$Create$ = kotlin_kotlin.$_$.s1;
  var compare = kotlin_kotlin.$_$.x2;
  var Unit_instance = kotlin_kotlin.$_$.n1;
  var equalsLong = kotlin_kotlin.$_$.b3;
  var coerceIn = kotlin_kotlin.$_$.s4;
  var divide = kotlin_kotlin.$_$.a3;
  var modulo = kotlin_kotlin.$_$.e3;
  var negate = kotlin_kotlin.$_$.g3;
  var add = kotlin_kotlin.$_$.t2;
  var equals = kotlin_kotlin.$_$.w3;
  var noWhenBranchMatchedException = kotlin_kotlin.$_$.m6;
  var shiftRight = kotlin_kotlin.$_$.k3;
  var protoOf = kotlin_kotlin.$_$.m4;
  var objectCreate = kotlin_kotlin.$_$.l4;
  var ensureNotNull = kotlin_kotlin.$_$.k6;
  var multiply = kotlin_kotlin.$_$.f3;
  var VOID = kotlin_kotlin.$_$.a;
  var compareTo = kotlin_kotlin.$_$.t3;
  var charCodeAt = kotlin_kotlin.$_$.q3;
  var toString = kotlin_kotlin.$_$.h;
  var substring = kotlin_kotlin.$_$.i5;
  var removePrefix = kotlin_kotlin.$_$.d5;
  var repeat = kotlin_kotlin.$_$.e5;
  var substring_0 = kotlin_kotlin.$_$.j5;
  var initMetadataForCompanion = kotlin_kotlin.$_$.b4;
  var Number_0 = kotlin_kotlin.$_$.v5;
  var THROW_CCE = kotlin_kotlin.$_$.x5;
  var hashCode = kotlin_kotlin.$_$.z3;
  var initMetadataForClass = kotlin_kotlin.$_$.a4;
  var _Char___init__impl__6a9atx = kotlin_kotlin.$_$.d;
  var toString_0 = kotlin_kotlin.$_$.o4;
  var IllegalStateException_init_$Create$ = kotlin_kotlin.$_$.v1;
  var copyOf = kotlin_kotlin.$_$.g2;
  var shiftLeft = kotlin_kotlin.$_$.i3;
  var IndexOutOfBoundsException_init_$Create$ = kotlin_kotlin.$_$.x1;
  var get_lastIndex = kotlin_kotlin.$_$.j2;
  var last = kotlin_kotlin.$_$.l2;
  var get_ONE = kotlin_kotlin.$_$.s2;
  var countTrailingZeroBits_0 = kotlin_kotlin.$_$.i6;
  var StringBuilder_init_$Create$ = kotlin_kotlin.$_$.q1;
  var _ULong___init__impl__c78o9k = kotlin_kotlin.$_$.v;
  var ULong = kotlin_kotlin.$_$.e6;
  var _ULong___get_data__impl__fggpzb = kotlin_kotlin.$_$.w;
  var invert = kotlin_kotlin.$_$.d3;
  var countLeadingZeroBits = kotlin_kotlin.$_$.g6;
  var countOneBits = kotlin_kotlin.$_$.h6;
  var contentEquals = kotlin_kotlin.$_$.c2;
  var StringBuilder_init_$Create$_0 = kotlin_kotlin.$_$.r1;
  var IllegalArgumentException_init_$Create$ = kotlin_kotlin.$_$.u1;
  var toByte = kotlin_kotlin.$_$.n4;
  var longArray = kotlin_kotlin.$_$.i4;
  var bitwiseXor = kotlin_kotlin.$_$.w2;
  var initMetadataForObject = kotlin_kotlin.$_$.d4;
  var get_lastIndex_0 = kotlin_kotlin.$_$.k2;
  var convertToByte = kotlin_kotlin.$_$.y2;
  var to = kotlin_kotlin.$_$.p6;
  var numberRangeToNumber = kotlin_kotlin.$_$.j4;
  var ClosedRange = kotlin_kotlin.$_$.r4;
  var isInterface = kotlin_kotlin.$_$.f4;
  var contains = kotlin_kotlin.$_$.t4;
  var contains_0 = kotlin_kotlin.$_$.y4;
  var DoubleCompanionObject_instance = kotlin_kotlin.$_$.j1;
  var doubleFromBits = kotlin_kotlin.$_$.v3;
  var ArrayList_init_$Create$ = kotlin_kotlin.$_$.o1;
  var take = kotlin_kotlin.$_$.k5;
  var padEnd = kotlin_kotlin.$_$.c5;
  var listOf = kotlin_kotlin.$_$.m2;
  var fill = kotlin_kotlin.$_$.h2;
  var charArray = kotlin_kotlin.$_$.p3;
  var StringBuilder = kotlin_kotlin.$_$.x4;
  var initMetadataForInterface = kotlin_kotlin.$_$.c4;
  var charSequenceLength = kotlin_kotlin.$_$.s3;
  var charSequenceGet = kotlin_kotlin.$_$.r3;
  var Char = kotlin_kotlin.$_$.r5;
  var digitToIntOrNull = kotlin_kotlin.$_$.z4;
  var Char__toInt_impl_vasixd = kotlin_kotlin.$_$.g;
  var Companion_instance = kotlin_kotlin.$_$.m1;
  var getOrNull = kotlin_kotlin.$_$.i2;
  var enumEntries = kotlin_kotlin.$_$.q2;
  var Enum = kotlin_kotlin.$_$.s5;
  var Error_init_$Create$ = kotlin_kotlin.$_$.t1;
  var IndexOutOfBoundsException = kotlin_kotlin.$_$.t5;
  var IndexOutOfBoundsException_init_$Init$ = kotlin_kotlin.$_$.w1;
  var captureStack = kotlin_kotlin.$_$.n3;
  //endregion
  //region block: pre-declaration
  initMetadataForCompanion(Companion);
  initMetadataForClass(BigDecimal, 'BigDecimal', VOID, Number_0);
  initMetadataForClass(ParsedMagnitude537, 'ParsedMagnitude537', ParsedMagnitude537);
  initMetadataForCompanion(Companion_0);
  initMetadataForClass(BigInteger, 'BigInteger', VOID, Number_0);
  initMetadataForObject(CompactInteger529, 'CompactInteger529');
  initMetadataForObject(DecimalPowers597, 'DecimalPowers597');
  initMetadataForClass(View, 'View');
  initMetadataForClass(Cells, 'Cells');
  initMetadataForClass(Digits, 'Digits');
  initMetadataForObject(DecimalSum585, 'DecimalSum585');
  initMetadataForClass(Lexical, 'Lexical');
  initMetadataForClass(Cells_0, 'Cells');
  initMetadataForClass(Digits_0, 'Digits');
  initMetadataForObject(DecimalText588, 'DecimalText588');
  initMetadataForObject(MagnitudeLimits, 'MagnitudeLimits');
  initMetadataForClass(Arena, 'Arena');
  initMetadataForObject(MagnitudeMultiplication, 'MagnitudeMultiplication');
  initMetadataForCompanion(Companion_1);
  initMetadataForClass(MathContext, 'MathContext');
  initMetadataForClass(RadixDigits537, 'RadixDigits537');
  function characters(value, start, end) {
    var inductionVariable = start;
    if (inductionVariable < end)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.pg(value[index]);
      }
       while (inductionVariable < end);
  }
  initMetadataForInterface(NumericSink537, 'NumericSink537');
  initMetadataForClass(AppendableSink537, 'AppendableSink537', VOID, VOID, [NumericSink537]);
  initMetadataForCompanion(Companion_2);
  initMetadataForClass(NumericText537, 'NumericText537');
  initMetadataForCompanion(Companion_3);
  initMetadataForClass(RoundingMode, 'RoundingMode', VOID, Enum);
  initMetadataForClass(ArrayIndexOutOfBoundsException, 'ArrayIndexOutOfBoundsException', VOID, IndexOutOfBoundsException);
  //endregion
  function normalizedCoefficient529($this, value) {
    return getKClassFromExpression(value).equals(getKClass(BigInteger)) ? value : BigInteger_init_$Create$_2(value.db());
  }
  function parse($this, value) {
    return DecimalText588_getInstance().nb(value, Companion_getInstance_1().fb_1);
  }
  function fromDouble($this, value) {
    if (!isFinite(value))
      throw NumberFormatException_init_$Create$('Infinite or NaN');
    if (value === 0.0)
      return $this.pb_1;
    var bits = toBits(value);
    var field = convertToInt(bitwiseAnd(shiftRightUnsigned(bits, 52), new Long(2047, 0)));
    // Inline function 'kotlin.Long.minus' call
    var this_0 = new Long(0, 1048576);
    var tmp$ret$0 = subtract(this_0, fromInt(1));
    var mantissa = bitwiseAnd(bits, tmp$ret$0);
    if (!(field === 0))
      mantissa = bitwiseOr(mantissa, new Long(0, 1048576));
    var exponent = ((field === 0 ? 1 : field) - 1023 | 0) - 52 | 0;
    if (exponent < 0) {
      var tmp0 = countTrailingZeroBits(mantissa);
      // Inline function 'kotlin.comparisons.minOf' call
      var b = -exponent | 0;
      var remove = Math.min(tmp0, b);
      mantissa = shiftRightUnsigned(mantissa, remove);
      exponent = exponent + remove | 0;
    }
    var coefficient = Companion_getInstance_0().mc(mantissa);
    var scale;
    if (exponent >= 0) {
      coefficient = coefficient.pc(exponent);
      scale = 0;
    } else {
      scale = -exponent | 0;
      coefficient = coefficient.oc(Companion_getInstance_0().mc(new Long(5, 0)).nc(scale));
    }
    return BigDecimal_init_$Create$_0(value < 0 ? coefficient.qc() : coefficient, scale);
  }
  function tenPow($this, exponent) {
    if (compare(exponent, new Long(0, 0)) < 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    if (compare(exponent, new Long(646456992, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    if (compare(exponent, fromInt($this.bc_1.length)) < 0)
      return $this.bc_1[convertToInt(exponent)];
    var tmp0_safe_receiver = DecimalPowers597_getInstance().tc(convertToInt(exponent));
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    return Companion_getInstance_0().ic_1.nc(convertToInt(exponent));
  }
  function checkedScale($this, scale) {
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false))
      throw ArithmeticException_init_$Create$(compare(scale, new Long(0, 0)) < 0 ? 'Overflow' : 'Underflow');
    return convertToInt(scale);
  }
  function checkedRoundingScale($this, scale) {
    var narrowed = convertToInt(scale);
    if (!equalsLong(fromInt(narrowed), scale))
      throw ArithmeticException_init_$Create$(narrowed > 0 ? 'Underflow' : 'Overflow');
    return narrowed;
  }
  function saturatedScale($this, scale) {
    return convertToInt(coerceIn(scale, new Long(-2147483648, -1), new Long(2147483647, 0)));
  }
  function scaleForValue($this, scale, zero) {
    return zero ? saturatedScale($this, scale) : checkedScale($this, scale);
  }
  function exponentText($this, exponent) {
    return 'E' + (compare(exponent, new Long(0, 0)) >= 0 ? '+' : '') + exponent.toString();
  }
  function roundedDivide($this, numerator, denominator, mode) {
    if (getKClassFromExpression(numerator).equals(getKClass(BigInteger)) && getKClassFromExpression(denominator).equals(getKClass(BigInteger))) {
      var a = numerator.uc();
      var b = denominator.uc();
      if (!(a == null) && !(b == null) && !equals(b, new Long(0, 0))) {
        var quotient = divide(a, b);
        var remainder = modulo(a, b);
        if (equalsLong(remainder, new Long(0, 0)))
          return Companion_getInstance_0().mc(quotient);
        var sign = compare(a, new Long(0, 0)) < 0 === compare(b, new Long(0, 0)) < 0 ? 1 : -1;
        var r = compare(remainder, new Long(0, 0)) < 0 ? negate(remainder) : remainder;
        var d = compare(b, new Long(0, 0)) < 0 ? negate(b) : b;
        var half = r.d2(subtract(d, r));
        var tmp = Companion_getInstance_0();
        var tmp_0;
        if (increment($this, mode, sign, half, !equalsLong(bitwiseAnd(quotient, new Long(1, 0)), new Long(0, 0)))) {
          // Inline function 'kotlin.Long.plus' call
          tmp_0 = add(quotient, fromInt(sign));
        } else {
          tmp_0 = quotient;
        }
        return tmp.mc(tmp_0);
      }
    }
    var qr = numerator.vc(denominator);
    if (qr[1].wc() === 0)
      return qr[0];
    var sign_0 = imul(numerator.wc(), denominator.wc());
    var remainder_0 = qr[1].xc();
    var divisor = denominator.xc();
    var half_0 = remainder_0.zc(divisor.yc(remainder_0));
    return increment($this, mode, sign_0, half_0, qr[0].bd(0)) ? qr[0].ad(Companion_getInstance_0().mc(fromInt(sign_0))) : qr[0];
  }
  function roundTiny($this, sign, mode) {
    return increment($this, mode, sign, -1, false) ? Companion_getInstance_0().mc(fromInt(sign)) : Companion_getInstance_0().fc_1;
  }
  function increment($this, mode, sign, half, odd) {
    var tmp;
    switch (mode.v1_1) {
      case 0:
        tmp = true;
        break;
      case 1:
        tmp = false;
        break;
      case 2:
        tmp = sign > 0;
        break;
      case 3:
        tmp = sign < 0;
        break;
      case 4:
        tmp = half >= 0;
        break;
      case 5:
        tmp = half > 0;
        break;
      case 6:
        tmp = half > 0 || (half === 0 && odd);
        break;
      case 7:
        throw ArithmeticException_init_$Create$('Rounding necessary');
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  function BigDecimal_init_$Init$(value, scale, $this) {
    BigDecimal.call($this, scale, convertToInt(shiftRight(value, 32)), convertToInt(value), 1, null);
    return $this;
  }
  function BigDecimal_init_$Create$(value, scale) {
    return BigDecimal_init_$Init$(value, scale, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_0(coefficient, decimalScale, $this) {
    BigDecimal_init_$Init$_1(normalizedCoefficient529(Companion_getInstance(), coefficient), decimalScale, Unit_instance, $this);
    return $this;
  }
  function BigDecimal_init_$Create$_0(coefficient, decimalScale) {
    return BigDecimal_init_$Init$_0(coefficient, decimalScale, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_1(coefficient, scale, owned, $this) {
    BigDecimal.call($this, scale, coefficient.dd() ? convertToInt(shiftRight(coefficient.cd(), 32)) : 0, coefficient.dd() ? convertToInt(coefficient.cd()) : 0, coefficient.dd() ? 1 : 2, coefficient.dd() ? null : coefficient);
    return $this;
  }
  function BigDecimal_init_$Init$_2(value, $this) {
    BigDecimal.call($this, value.ed_1, value.fd_1, value.gd_1, value.hd_1, value.id_1);
    return $this;
  }
  function compactValue529($this) {
    return CompactInteger529_getInstance().nd($this.fd_1, $this.gd_1);
  }
  function coefficientSnapshot($this) {
    var tmp0_elvis_lhs = $this.id_1;
    return tmp0_elvis_lhs == null ? Companion_getInstance_0().mc(compactValue529($this)) : tmp0_elvis_lhs;
  }
  function storedSign529($this) {
    return $this.hd_1 === 1 ? CompactInteger529_getInstance().od(compactValue529($this)) : ensureNotNull($this.id_1).wc();
  }
  function BigDecimal_init_$Init$_3(value, $this) {
    BigDecimal_init_$Init$(value, 0, $this);
    return $this;
  }
  function BigDecimal_init_$Create$_1(value) {
    return BigDecimal_init_$Init$_3(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_4(value, $this) {
    BigDecimal_init_$Init$_2(parse(Companion_getInstance(), value), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_2(value) {
    return BigDecimal_init_$Init$_4(value, objectCreate(protoOf(BigDecimal)));
  }
  function BigDecimal_init_$Init$_5(value, $this) {
    BigDecimal_init_$Init$_2(fromDouble(Companion_getInstance(), value), $this);
    return $this;
  }
  function BigDecimal_init_$Create$_3(value) {
    return BigDecimal_init_$Init$_5(value, objectCreate(protoOf(BigDecimal)));
  }
  function storedPrecision($this) {
    if ($this.hd_1 === 2 && !getKClassFromExpression(ensureNotNull($this.id_1)).equals(getKClass(BigInteger)))
      return $this.id_1.pd();
    var cached = $this.jd_1;
    if (!(cached === 0))
      return cached;
    var digits = $this.hd_1 === 1 ? CompactInteger529_getInstance().qd(compactValue529($this)) : ensureNotNull($this.id_1).pd();
    $this.jd_1 = digits;
    return digits;
  }
  function rawSum585($this, other, subtract_0, mc) {
    if ($this.hd_1 === 1 && other.hd_1 === 1) {
      var tmp0 = $this.ed_1;
      // Inline function 'kotlin.comparisons.maxOf' call
      var b = other.ed_1;
      var scale = Math.max(tmp0, b);
      var tmp = compactValue529($this);
      var tmp0_0 = fromInt(scale);
      // Inline function 'kotlin.Long.minus' call
      var other_0 = $this.ed_1;
      var tmp$ret$1 = subtract(tmp0_0, fromInt(other_0));
      var a = scaledCompact529($this, tmp, tmp$ret$1);
      var tmp_0 = compactValue529(other);
      var tmp0_1 = fromInt(scale);
      // Inline function 'kotlin.Long.minus' call
      var other_1 = other.ed_1;
      var tmp$ret$2 = subtract(tmp0_1, fromInt(other_1));
      var b_0 = scaledCompact529($this, tmp_0, tmp$ret$2);
      if (!(a == null) && !(b_0 == null)) {
        var result = subtract_0 ? subtract(a, b_0) : add(a, b_0);
        if (subtract_0 ? CompactInteger529_getInstance().sd(a, b_0, result) : CompactInteger529_getInstance().rd(a, b_0, result)) {
          var decimal = BigDecimal_init_$Create$(result, scale);
          return mc == null ? decimal : roundValue(decimal, mc);
        }
      }
    }
    var coefficient = coefficientSnapshot($this);
    var otherCoefficient529 = coefficientSnapshot(other);
    var tmp0_elvis_lhs = coefficient.td(otherCoefficient529, $this.ed_1, other.ed_1, subtract_0, mc);
    var tmp_1;
    if (tmp0_elvis_lhs == null) {
      return null;
    } else {
      tmp_1 = tmp0_elvis_lhs;
    }
    var result_0 = tmp_1;
    return BigDecimal_init_$Create$_0(result_0.s9_1, result_0.t9_1);
  }
  function addValue($this, augend) {
    var tmp0 = $this.ed_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = augend.ed_1;
    var scale = Math.max(tmp0, b);
    return BigDecimal_init_$Create$_0(scaledCoefficient($this, scale).ad(scaledCoefficient(augend, scale)), scale);
  }
  function multiplyValue($this, multiplicand) {
    var tmp = Companion_getInstance();
    var tmp0 = fromInt($this.ed_1);
    // Inline function 'kotlin.Long.plus' call
    var other = multiplicand.ed_1;
    var tmp$ret$0 = add(tmp0, fromInt(other));
    var scale = scaleForValue(tmp, tmp$ret$0, storedSign529($this) === 0);
    if ($this.hd_1 === 1 && multiplicand.hd_1 === 1) {
      var a = compactValue529($this);
      var b = compactValue529(multiplicand);
      var result = multiply(a, b);
      if (CompactInteger529_getInstance().ud(a, b, result))
        return BigDecimal_init_$Create$(result, scale);
    }
    var coefficient = coefficientSnapshot($this);
    var multiplicandCoefficient529 = coefficientSnapshot(multiplicand);
    var otherCoefficient = multiplicandCoefficient529;
    return BigDecimal_init_$Create$_0(coefficient.oc(otherCoefficient), scale);
  }
  function roundValue($this, mc) {
    if (mc.vd_1 === 0)
      return $this;
    var drop = $this.xd() - mc.vd_1 | 0;
    if (drop <= 0)
      return $this;
    if ($this.hd_1 === 1 && getKClassFromExpression($this).equals(getKClass(BigDecimal))) {
      var compact = compactValue529($this);
      var scale = $this.ed_1;
      while (drop > 0) {
        var tmp = Companion_getInstance();
        var tmp0 = fromInt(scale);
        // Inline function 'kotlin.Long.minus' call
        var other = drop;
        var tmp$ret$0 = subtract(tmp0, fromInt(other));
        scale = checkedRoundingScale(tmp, tmp$ret$0);
        compact = roundedCompactPower529($this, compact, fromInt(drop), mc.wd_1);
        drop = CompactInteger529_getInstance().qd(compact) - mc.vd_1 | 0;
      }
      return BigDecimal_init_$Create$(compact, scale);
    }
    var coefficient = coefficientSnapshot($this);
    var value = coefficient;
    var scale_0 = $this.ed_1;
    while (drop > 0) {
      var tmp_0 = Companion_getInstance();
      var tmp0_0 = fromInt(scale_0);
      // Inline function 'kotlin.Long.minus' call
      var other_0 = drop;
      var tmp$ret$1 = subtract(tmp0_0, fromInt(other_0));
      scale_0 = checkedRoundingScale(tmp_0, tmp$ret$1);
      value = roundedDivide(Companion_getInstance(), value, tenPow(Companion_getInstance(), fromInt(drop)), mc.wd_1);
      drop = value.pd() - mc.vd_1 | 0;
    }
    return BigDecimal_init_$Create$_0(value, scale_0);
  }
  function setScaleValue($this, newScale, roundingMode) {
    if ($this.ed_1 === newScale)
      return $this;
    if ($this.wc() === 0)
      return BigDecimal_init_$Create$_0(Companion_getInstance_0().fc_1, newScale);
    var tmp0 = fromInt(newScale);
    // Inline function 'kotlin.Long.minus' call
    var other = $this.ed_1;
    var shift = subtract(tmp0, fromInt(other));
    if ($this.hd_1 === 1 && getKClassFromExpression($this).equals(getKClass(BigDecimal))) {
      var compact = compactValue529($this);
      if (compare(shift, new Long(0, 0)) <= 0)
        return BigDecimal_init_$Create$(roundedCompactPower529($this, compact, negate(shift), roundingMode), newScale);
      var scaled = scaledCompact529($this, compact, shift);
      if (!(scaled == null))
        return BigDecimal_init_$Create$(scaled, newScale);
    }
    var coefficient = coefficientSnapshot($this);
    var tmp;
    if (compare(shift, new Long(0, 0)) > 0) {
      var distance = checkedScale(Companion_getInstance(), shift);
      if (distance > 646456992)
        throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
      tmp = coefficient.oc(tenPow(Companion_getInstance(), shift));
    } else {
      var digits = fromInt(storedPrecision($this));
      tmp = compare(negate(shift), digits) > 0 ? roundTiny(Companion_getInstance(), $this.wc(), roundingMode) : equalsLong(negate(shift), digits) ? roundSubunitCoefficient($this, negate(shift), roundingMode) : roundedDivide(Companion_getInstance(), coefficient, tenPow(Companion_getInstance(), negate(shift)), roundingMode);
    }
    var value = tmp;
    return BigDecimal_init_$Create$_0(value, newScale);
  }
  function roundSubunitCoefficient($this, digits, mode) {
    var coefficient = coefficientSnapshot($this);
    var tmp = coefficient.xc();
    var tmp_0 = Companion_getInstance();
    // Inline function 'kotlin.Long.minus' call
    var tmp$ret$0 = subtract(digits, fromInt(1));
    var qr = tmp.vc(tenPow(tmp_0, tmp$ret$0));
    var leadingHalf = qr[0].zc(Companion_getInstance_0().mc(new Long(5, 0)));
    var half = leadingHalf === 0 && !(qr[1].wc() === 0) ? 1 : leadingHalf;
    var sign = coefficient.wc();
    return increment(Companion_getInstance(), mode, sign, half, false) ? Companion_getInstance_0().mc(fromInt(sign)) : Companion_getInstance_0().fc_1;
  }
  function stripTo($this, minScale, failOnOverflow) {
    failOnOverflow = failOnOverflow === VOID ? false : failOnOverflow;
    var scale = $this.ed_1;
    if ($this.hd_1 === 1) {
      var unscaled = compactValue529($this);
      while (!equalsLong(unscaled, new Long(0, 0)) && scale > minScale && equalsLong(modulo(unscaled, new Long(10, 0)), new Long(0, 0))) {
        unscaled = divide(unscaled, new Long(10, 0));
        scale = scale - 1 | 0;
      }
      if (failOnOverflow && scale === -2147483648 && !equalsLong(unscaled, new Long(0, 0)) && equalsLong(modulo(unscaled, new Long(10, 0)), new Long(0, 0)))
        throw ArithmeticException_init_$Create$('Overflow');
      return scale === $this.ed_1 ? $this : BigDecimal_init_$Create$(unscaled, scale);
    }
    var value = coefficientSnapshot($this);
    if (!(value.wc() === 0) && scale > minScale) {
      var qr = value.vc(Companion_getInstance_0().ic_1);
      if (qr[1].wc() === 0) {
        value = qr[0];
        scale = scale - 1 | 0;
        var twos = value.yd();
        $l$loop_0: while (scale > minScale && twos > 0) {
          var tmp0 = new Long(9, 0);
          // Inline function 'kotlin.Long.minus' call
          var this_0 = fromInt(scale);
          var tmp2 = subtract(this_0, fromInt(minScale));
          // Inline function 'kotlin.comparisons.minOf' call
          // Inline function 'kotlin.comparisons.minOf' call
          var b = fromInt(twos);
          // Inline function 'kotlin.comparisons.minOf' call
          var b_0 = compare(tmp2, b) <= 0 ? tmp2 : b;
          var tmp$ret$1 = compare(tmp0, b_0) <= 0 ? tmp0 : b_0;
          var chunk = convertToInt(tmp$ret$1);
          var remainder = ensureNotNull(value.zd(tenPow(Companion_getInstance(), fromInt(chunk))).uc());
          var exact = chunk;
          if (!equalsLong(remainder, new Long(0, 0))) {
            var low = remainder;
            exact = 0;
            while (equalsLong(modulo(low, new Long(10, 0)), new Long(0, 0))) {
              low = divide(low, new Long(10, 0));
              exact = exact + 1 | 0;
            }
          }
          if (exact === 0)
            break $l$loop_0;
          value = value.ae(tenPow(Companion_getInstance(), fromInt(exact)));
          scale = scale - exact | 0;
          twos = twos - exact | 0;
          if (exact < chunk)
            break $l$loop_0;
        }
      }
    }
    if (failOnOverflow && scale === -2147483648 && !(value.wc() === 0) && value.zd(Companion_getInstance_0().ic_1).wc() === 0)
      throw ArithmeticException_init_$Create$('Overflow');
    return scale === $this.ed_1 ? $this : BigDecimal_init_$Create$_0(value, scale);
  }
  function compareMagnitude($this, other) {
    if ($this.hd_1 === 1 && other.hd_1 === 1) {
      var left = compactValue529($this);
      var right = compactValue529(other);
      if (equalsLong(left, new Long(0, 0)) || equalsLong(right, new Long(0, 0)))
        return compareTo(equalsLong(left, new Long(0, 0)) ? 0 : 1, equalsLong(right, new Long(0, 0)) ? 0 : 1);
      var negativeLeft = compare(left, new Long(0, 0)) > 0 ? negate(left) : left;
      var negativeRight = compare(right, new Long(0, 0)) > 0 ? negate(right) : right;
      if ($this.ed_1 === other.ed_1)
        return negativeRight.d2(negativeLeft);
      var exponent = adjustedExponent($this).d2(adjustedExponent(other));
      if (!(exponent === 0))
        return exponent;
      return CompactInteger529_getInstance().be(left, right);
    }
    var coefficient = coefficientSnapshot($this);
    var otherCoefficient529 = coefficientSnapshot(other);
    var left_0 = coefficient.xc();
    var right_0 = otherCoefficient529.xc();
    if (left_0.wc() === 0 || right_0.wc() === 0)
      return compareTo(left_0.wc(), right_0.wc());
    if ($this.ed_1 === other.ed_1)
      return left_0.zc(right_0);
    var exponent_0 = adjustedExponent($this).d2(adjustedExponent(other));
    if (!(exponent_0 === 0))
      return exponent_0;
    return left_0.ce(right_0);
  }
  function roundedCompactPower529($this, value, drop, mode) {
    if (equalsLong(drop, new Long(0, 0)) || equalsLong(value, new Long(0, 0)))
      return value;
    var sign = CompactInteger529_getInstance().od(value);
    if (compare(drop, new Long(19, 0)) >= 0) {
      var negative = compare(value, new Long(0, 0)) > 0 ? negate(value) : value;
      var half = compare(drop, new Long(19, 0)) > 0 ? -1 : (new Long(-1156841472, -1164153219)).d2(negative);
      return increment(Companion_getInstance(), mode, sign, half, false) ? fromInt(sign) : new Long(0, 0);
    }
    var divisor = CompactInteger529_getInstance().de(convertToInt(drop));
    var quotient = divide(value, divisor);
    var remainder = modulo(value, divisor);
    if (equalsLong(remainder, new Long(0, 0)))
      return quotient;
    var magnitude = compare(remainder, new Long(0, 0)) < 0 ? negate(remainder) : remainder;
    var half_0 = magnitude.d2(subtract(divisor, magnitude));
    var tmp;
    if (increment(Companion_getInstance(), mode, sign, half_0, !equalsLong(bitwiseAnd(quotient, new Long(1, 0)), new Long(0, 0)))) {
      // Inline function 'kotlin.Long.plus' call
      tmp = add(quotient, fromInt(sign));
    } else {
      tmp = quotient;
    }
    return tmp;
  }
  function scaledCompact529($this, value, raise) {
    if (equalsLong(value, new Long(0, 0)))
      return new Long(0, 0);
    if (compare(raise, new Long(18, 0)) > 0)
      return null;
    var result = value;
    // Inline function 'kotlin.repeat' call
    var times = convertToInt(raise);
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var next = multiply(result, new Long(10, 0));
        if (!CompactInteger529_getInstance().ud(result, new Long(10, 0), next))
          return null;
        result = next;
      }
       while (inductionVariable < times);
    return result;
  }
  function adjustedExponent($this) {
    var tmp0 = fromInt($this.xd());
    // Inline function 'kotlin.Long.minus' call
    var other = $this.ed_1;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    return subtract(this_0, fromInt(1));
  }
  function scaledCoefficient($this, scale) {
    var coefficient = coefficientSnapshot($this);
    if (coefficient.wc() === 0)
      return coefficient;
    var tmp = Companion_getInstance();
    var tmp0 = fromInt(scale);
    // Inline function 'kotlin.Long.minus' call
    var other = $this.ed_1;
    var tmp$ret$0 = subtract(tmp0, fromInt(other));
    var distance = checkedScale(tmp, tmp$ret$0);
    return coefficient.oc(tenPow(Companion_getInstance(), fromInt(distance)));
  }
  function canonicalStringValue($this) {
    var digits = magnitudeDigits529($this);
    var sign = layoutSign($this);
    var tmp0 = fromInt(digits.length);
    // Inline function 'kotlin.Long.minus' call
    var other = $this.ed_1;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    var exponent = subtract(this_0, fromInt(1));
    if ($this.ed_1 >= 0 && compare(exponent, new Long(-6, -1)) >= 0)
      return canonicalPlain($this, digits, sign);
    var tmp;
    if (digits.length === 1) {
      tmp = digits;
    } else {
      // Inline function 'kotlin.text.plus' call
      var this_1 = charCodeAt(digits, 0);
      tmp = toString(this_1) + '.' + substring(digits, 1);
    }
    var body = tmp;
    return (sign < 0 ? '-' : '') + body + exponentText(Companion_getInstance(), exponent);
  }
  function magnitudeDigits529($this) {
    return $this.hd_1 === 1 ? removePrefix(compactValue529($this).toString(), '-') : ensureNotNull($this.id_1).xc().toString();
  }
  function layoutSign($this) {
    var compact = $this.hd_1 === 1 && !equalsLong(compactValue529($this), new Long(0, -2147483648)) ? compactValue529($this) : null;
    var directSign = $this.ed_1 === 0 || ($this.ed_1 === 2 && !(compact == null) && compare(compact, new Long(0, 0)) >= 0 && compare(compact, new Long(2147483647, 0)) < 0);
    return directSign ? storedSign529($this) : $this.wc();
  }
  function canonicalPlain($this, digits, sign) {
    if (compare(plainStringLength($this, digits.length, sign), new Long(2147483647, 0)) > 0) {
      plainStringTooLarge();
    }
    var body = $this.ed_1 === 0 ? digits : $this.ed_1 < digits.length ? substring_0(digits, 0, digits.length - $this.ed_1 | 0) + '.' + substring(digits, digits.length - $this.ed_1 | 0) : '0.' + repeat('0', $this.ed_1 - digits.length | 0) + digits;
    return (sign < 0 ? '-' : '') + body;
  }
  function plainStringLength($this, digits, sign) {
    var signLength = sign < 0 ? new Long(1, 0) : new Long(0, 0);
    return add(signLength, $this.ed_1 <= 0 ? subtract(fromInt(digits), fromInt($this.ed_1)) : $this.ed_1 < digits ? add(fromInt(digits), new Long(1, 0)) : add(fromInt($this.ed_1), new Long(2, 0)));
  }
  function Companion() {
    Companion_instance_0 = this;
    this.ob_1 = new Long(-108976049, 1422333271);
    this.pb_1 = BigDecimal_init_$Create$_0(Companion_getInstance_0().fc_1, 0);
    this.qb_1 = BigDecimal_init_$Create$_0(Companion_getInstance_0().gc_1, 0);
    this.rb_1 = BigDecimal_init_$Create$_0(Companion_getInstance_0().hc_1, 0);
    this.sb_1 = BigDecimal_init_$Create$_0(Companion_getInstance_0().ic_1, 0);
    this.tb_1 = 0;
    this.ub_1 = 1;
    this.vb_1 = 2;
    this.wb_1 = 3;
    this.xb_1 = 4;
    this.yb_1 = 5;
    this.zb_1 = 6;
    this.ac_1 = 7;
    var tmp = this;
    var tmp_0 = 0;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(19);
    while (tmp_0 < 19) {
      var tmp_2 = tmp_0;
      tmp_1[tmp_2] = Companion_getInstance_0().mc(CompactInteger529_getInstance().de(tmp_2));
      tmp_0 = tmp_0 + 1 | 0;
    }
    tmp.bc_1 = tmp_1;
  }
  protoOf(Companion).mc = function (value) {
    return BigDecimal_init_$Create$_1(value);
  };
  protoOf(Companion).ee = function (unscaledVal, scale) {
    return BigDecimal_init_$Create$(unscaledVal, scale);
  };
  protoOf(Companion).fe = function (value) {
    return BigDecimal_init_$Create$_2(decimalDoubleString(value));
  };
  var Companion_instance_0;
  function Companion_getInstance() {
    if (Companion_instance_0 == null)
      new Companion();
    return Companion_instance_0;
  }
  function BigDecimal(decimalScale, compactHigh, compactLow, representation, wideCoefficient) {
    Companion_getInstance();
    Number_0.call(this);
    this.ed_1 = decimalScale;
    this.fd_1 = compactHigh;
    this.gd_1 = compactLow;
    this.hd_1 = representation;
    this.id_1 = wideCoefficient;
    this.jd_1 = 0;
    this.kd_1 = null;
  }
  protoOf(BigDecimal).ge = function () {
    return coefficientSnapshot(this);
  };
  protoOf(BigDecimal).he = function () {
    return this.ed_1;
  };
  protoOf(BigDecimal).xd = function () {
    return storedPrecision(this);
  };
  protoOf(BigDecimal).wc = function () {
    return storedSign529(this);
  };
  protoOf(BigDecimal).ie = function (augend) {
    var tmp0_elvis_lhs = rawSum585(this, augend, false, null);
    return tmp0_elvis_lhs == null ? addValue(this, augend) : tmp0_elvis_lhs;
  };
  protoOf(BigDecimal).je = function (subtrahend) {
    var operand = subtrahend;
    var tmp0_safe_receiver = rawSum585(this, operand, true, null);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var tmp0 = this.ed_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = operand.ed_1;
    var scale = Math.max(tmp0, b);
    return BigDecimal_init_$Create$_0(scaledCoefficient(this, scale).yc(scaledCoefficient(operand, scale)), scale);
  };
  protoOf(BigDecimal).ke = function (multiplicand) {
    return multiplyValue(this, multiplicand);
  };
  protoOf(BigDecimal).le = function (newScale) {
    return this.me(newScale, 7);
  };
  protoOf(BigDecimal).me = function (newScale, roundingMode) {
    return setScaleValue(this, newScale, Companion_instance_4.ne(roundingMode));
  };
  protoOf(BigDecimal).oe = function () {
    return storedSign529(this) === 0 ? Companion_getInstance().pb_1 : stripTo(this, -2147483648, true);
  };
  protoOf(BigDecimal).pe = function (other) {
    if (this.ed_1 === other.ed_1 && this.hd_1 === 1 && other.hd_1 === 1 && !equalsLong(compactValue529(this), new Long(0, -2147483648)) && !equalsLong(compactValue529(other), new Long(0, -2147483648))) {
      var order = compactValue529(this).d2(compactValue529(other));
      return order < 0 ? -1 : order > 0 ? 1 : 0;
    }
    var coefficient = coefficientSnapshot(this);
    var operand = other;
    var operandCoefficient529 = coefficientSnapshot(operand);
    if (this.ed_1 === operand.ed_1) {
      var left = coefficient.uc();
      var right = operandCoefficient529.uc();
      if (!(left == null) && !(right == null)) {
        var order_0 = left.d2(right);
        return order_0 < 0 ? -1 : order_0 > 0 ? 1 : 0;
      }
    }
    var leftSign = this.wc();
    var rightSign = operand.wc();
    if (!(leftSign === rightSign))
      return leftSign < rightSign ? -1 : 1;
    if (leftSign === 0)
      return 0;
    var magnitude = compareMagnitude(this, operand);
    return magnitude < 0 ? leftSign > 0 ? -1 : 1 : magnitude > 0 ? leftSign > 0 ? 1 : -1 : 0;
  };
  protoOf(BigDecimal).o1 = function (other) {
    return this.pe(other instanceof BigDecimal ? other : THROW_CCE());
  };
  protoOf(BigDecimal).equals = function (other) {
    var tmp;
    var tmp_0;
    if (other instanceof BigDecimal) {
      tmp_0 = this.ed_1 === other.ed_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.hd_1 === 1 && other.hd_1 === 1 ? this.fd_1 === other.fd_1 && this.gd_1 === other.gd_1 : coefficientSnapshot(this).equals(coefficientSnapshot(other));
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(BigDecimal).hashCode = function () {
    if (!(this.hd_1 === 1)) {
      // Inline function 'kotlin.hashCode' call
      var tmp0_safe_receiver = this.id_1;
      var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
      var tmp$ret$0 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
      return imul(31, tmp$ret$0) + this.ed_1 | 0;
    }
    var value = compactValue529(this);
    var magnitude = compare(value, new Long(0, 0)) < 0 ? negate(value) : value;
    var tmp0 = new Long(31, 0);
    // Inline function 'kotlin.Long.times' call
    var other = convertToInt(shiftRightUnsigned(magnitude, 32));
    var tmp$ret$1 = multiply(tmp0, fromInt(other));
    var hash = convertToInt(add(tmp$ret$1, bitwiseAnd(magnitude, new Long(-1, 0))));
    return imul(31, compare(value, new Long(0, 0)) < 0 ? -hash | 0 : hash) + this.ed_1 | 0;
  };
  protoOf(BigDecimal).toString = function () {
    var tmp0_safe_receiver = this.kd_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    // Inline function 'kotlin.also' call
    var this_0 = canonicalStringValue(this);
    this.kd_1 = this_0;
    return this_0;
  };
  protoOf(BigDecimal).qe = function () {
    var text = this.hd_1 === 1 ? compactValue529(this).toString() : ensureNotNull(this.id_1).toString();
    if (this.ed_1 === 0)
      return text;
    if (this.ed_1 < 0) {
      if (this.wc() === 0)
        return '0';
      if (compare(subtract(fromInt(text.length), fromInt(this.ed_1)), new Long(2147483647, 0)) > 0) {
        plainStringTooLarge();
      }
      return text + repeat('0', convertToInt(negate(fromInt(this.ed_1))));
    }
    return canonicalPlain(this, magnitudeDigits529(this), this.wc());
  };
  function parse_0($this, value, radix) {
    return parse_1($this, Companion_instance_3.re(value), radix);
  }
  function decimalPrefixBuilder529($this, value, first, digits) {
    var builder = new ParsedMagnitude537();
    var index = first;
    var remaining = digits;
    var width = ((digits - 1 | 0) % 9 | 0) + 1 | 0;
    while (remaining > 0) {
      var power = 1;
      var block = 0;
      var count = 0;
      $l$loop: while (count < width) {
        var _unary__edvuaz = index;
        index = _unary__edvuaz + 1 | 0;
        var c = value.b(_unary__edvuaz);
        if (c === _Char___init__impl__6a9atx(46))
          continue $l$loop;
        var tmp = imul(block, 10);
        // Inline function 'kotlin.checkNotNull' call
        var tmp0 = numericDigit537(c, 10);
        var tmp$ret$1;
        $l$block: {
          // Inline function 'kotlin.checkNotNull' call
          if (tmp0 == null) {
            var message = 'Required value was null.';
            throw IllegalStateException_init_$Create$(toString_0(message));
          } else {
            tmp$ret$1 = tmp0;
            break $l$block;
          }
        }
        block = tmp + tmp$ret$1 | 0;
        power = imul(power, 10);
        count = count + 1 | 0;
      }
      builder.ze(power, block);
      remaining = remaining - width | 0;
      width = 9;
    }
    return builder;
  }
  function parse_1($this, value, radix) {
    if (!(2 <= radix ? radix <= 36 : false))
      throw NumberFormatException_init_$Create$('Radix out of range');
    if (value.ve_1 === 0)
      throw NumberFormatException_init_$Create$('Zero length BigInteger');
    var inductionVariable = 1;
    var last = value.ve_1;
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (value.b(index) === _Char___init__impl__6a9atx(45) || value.b(index) === _Char___init__impl__6a9atx(43))
          throw NumberFormatException_init_$Create$('Illegal embedded sign character');
      }
       while (inductionVariable < last);
    var start = 0;
    var sign = 1;
    if (value.b(0) === _Char___init__impl__6a9atx(45) || value.b(0) === _Char___init__impl__6a9atx(43)) {
      sign = value.b(0) === _Char___init__impl__6a9atx(45) ? -1 : 1;
      start = start + 1 | 0;
    }
    if (start === value.ve_1)
      throw NumberFormatException_init_$Create$('Zero length BigInteger');
    while (start < value.ve_1 && numericDigit537(value.b(start), radix) === 0) {
      start = start + 1 | 0;
    }
    if (start === value.ve_1)
      return $this.fc_1;
    if (MagnitudeLimits_instance.cf(value.ve_1 - start | 0, radix)) {
      var inductionVariable_0 = start;
      var last_0 = value.ve_1;
      if (inductionVariable_0 < last_0)
        do {
          var i = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          if (numericDigit537(value.b(i), radix) == null) {
            invalidIntegerDigit($this, value, radix, start, i);
          }
        }
         while (inductionVariable_0 < last_0);
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    }
    var groupPower = radix;
    var groupWidth = 1;
    $l$loop: while (true) {
      // Inline function 'kotlin.Long.times' call
      var this_0 = fromInt(groupPower);
      var tmp$ret$0 = multiply(this_0, fromInt(radix));
      if (!(compare(tmp$ret$0, new Long(2147483647, 0)) <= 0)) {
        break $l$loop;
      }
      groupPower = imul(groupPower, radix);
      groupWidth = groupWidth + 1 | 0;
    }
    var builder = new ParsedMagnitude537();
    var index_0 = start;
    var width = (((value.ve_1 - start | 0) - 1 | 0) % groupWidth | 0) + 1 | 0;
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_1 = radix - 1 | 0;
    var radixUpperBits = 32 - clz32(this_1) | 0;
    while (index_0 < value.ve_1) {
      var tmp = fromInt(builder.df());
      // Inline function 'kotlin.Long.times' call
      var this_2 = fromInt(width);
      var tmp$ret$2 = multiply(this_2, fromInt(radixUpperBits));
      if (compare(add(tmp, tmp$ret$2), new Long(2147483647, 0)) > 0) {
        var n = builder.ef(1);
        var base = $this.mc(fromInt(radix));
        var inductionVariable_1 = index_0;
        var last_1 = value.ve_1;
        if (inductionVariable_1 < last_1)
          do {
            var at = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var tmp0_elvis_lhs = numericDigit537(value.b(at), radix);
            var tmp_0;
            if (tmp0_elvis_lhs == null) {
              invalidIntegerDigit($this, value, radix, start, at);
            } else {
              tmp_0 = tmp0_elvis_lhs;
            }
            var digit = tmp_0;
            n = n.oc(base).ad($this.mc(fromInt(digit)));
          }
           while (inductionVariable_1 < last_1);
        return sign < 0 ? n.qc() : n;
      }
      var block = 0;
      var power = 1;
      // Inline function 'kotlin.repeat' call
      var times = width;
      var inductionVariable_2 = 0;
      if (inductionVariable_2 < times)
        do {
          var index_1 = inductionVariable_2;
          inductionVariable_2 = inductionVariable_2 + 1 | 0;
          var tmp0_elvis_lhs_0 = numericDigit537(value.b(index_0), radix);
          var tmp_1;
          if (tmp0_elvis_lhs_0 == null) {
            invalidIntegerDigit(Companion_getInstance_0(), value, radix, start, index_0);
          } else {
            tmp_1 = tmp0_elvis_lhs_0;
          }
          var digit_0 = tmp_1;
          block = imul(block, radix) + digit_0 | 0;
          power = imul(power, radix);
          index_0 = index_0 + 1 | 0;
        }
         while (inductionVariable_2 < times);
      builder.ze(power, block);
      width = groupWidth;
    }
    return builder.ef(sign);
  }
  function ParsedMagnitude537() {
    this.we_1 = new Long(0, 0);
    this.xe_1 = null;
    this.ye_1 = 0;
  }
  protoOf(ParsedMagnitude537).df = function () {
    var tmp0_safe_receiver = this.xe_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      var tmp_0;
      if (this.ye_1 === 0) {
        tmp_0 = 0;
      } else {
        var tmp_1 = imul(this.ye_1 - 1 | 0, 30) + 32 | 0;
        // Inline function 'kotlin.countLeadingZeroBits' call
        var this_0 = tmp0_safe_receiver[this.ye_1 - 1 | 0];
        tmp_0 = tmp_1 - clz32(this_0) | 0;
      }
      tmp = tmp_0;
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? CompactInteger529_getInstance().ff(this.we_1) : tmp1_elvis_lhs;
  };
  protoOf(ParsedMagnitude537).ze = function (power, block) {
    var tmp0_elvis_lhs = this.xe_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.run' call
      var tmp_0 = this.we_1;
      // Inline function 'kotlin.Long.div' call
      var this_0 = new Long(0, -2147483648);
      var tmp$ret$2 = divide(this_0, fromInt(power));
      if (compare(tmp_0, tmp$ret$2) >= 0) {
        // Inline function 'kotlin.Long.times' call
        var this_1 = this.we_1;
        var product = multiply(this_1, fromInt(power));
        // Inline function 'kotlin.Long.plus' call
        var this_2 = new Long(0, -2147483648);
        var tmp$ret$4 = add(this_2, fromInt(block));
        if (compare(product, tmp$ret$4) >= 0) {
          var tmp_1 = this;
          // Inline function 'kotlin.Long.minus' call
          tmp_1.we_1 = subtract(product, fromInt(block));
          return Unit_instance;
        }
      }
      var magnitude = CompactInteger529_getInstance().gf(convertToInt(shiftRight(this.we_1, 32)), convertToInt(this.we_1));
      this.ye_1 = magnitude.length;
      // Inline function 'kotlin.comparisons.maxOf' call
      var b = this.ye_1 + 1 | 0;
      var tmp$ret$6 = Math.max(4, b);
      // Inline function 'kotlin.also' call
      var this_3 = copyOf(magnitude, tmp$ret$6);
      this.xe_1 = this_3;
      tmp = this_3;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var words = tmp;
    var carry = fromInt(block);
    var inductionVariable = 0;
    var last = this.ye_1;
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_4 = fromInt(words[index]);
        var tmp$ret$9 = multiply(this_4, fromInt(power));
        var part = add(tmp$ret$9, carry);
        words[index] = convertToInt(bitwiseAnd(part, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(part, 30);
      }
       while (inductionVariable < last);
    while (!equalsLong(carry, new Long(0, 0))) {
      if (this.ye_1 === words.length) {
        // Inline function 'kotlin.Long.plus' call
        var this_5 = new Long(2147483647, 0);
        // Inline function 'kotlin.Long.minus' call
        var this_6 = add(this_5, fromInt(30));
        // Inline function 'kotlin.Long.div' call
        var this_7 = subtract(this_6, fromInt(1));
        var tmp0 = divide(this_7, fromInt(30));
        // Inline function 'kotlin.Long.times' call
        var this_8 = fromInt(words.length);
        // Inline function 'kotlin.comparisons.minOf' call
        var b_0 = multiply(this_8, fromInt(2));
        var tmp$ret$14 = compare(tmp0, b_0) <= 0 ? tmp0 : b_0;
        var next = convertToInt(tmp$ret$14);
        if (next === words.length)
          throw ArithmeticException_init_$Create$('BigInteger overflow');
        words = copyOf(words, next);
        this.xe_1 = words;
      }
      var tmp_2 = words;
      var _unary__edvuaz = this.ye_1;
      this.ye_1 = _unary__edvuaz + 1 | 0;
      tmp_2[_unary__edvuaz] = convertToInt(bitwiseAnd(carry, new Long(1073741823, 0)));
      carry = shiftRightUnsigned(carry, 30);
    }
    if (this.ye_1 > 0) {
      MagnitudeLimits_instance.hf(this.ye_1, words[this.ye_1 - 1 | 0]);
    }
  };
  protoOf(ParsedMagnitude537).ef = function (sign) {
    var words = this.xe_1;
    if (!(words == null))
      return normalized(Companion_getInstance_0(), sign, copyOf(words, this.ye_1));
    var tmp;
    if (sign < 0) {
      tmp = Companion_getInstance_0().mc(this.we_1);
    } else if (equalsLong(this.we_1, new Long(0, -2147483648))) {
      // Inline function 'kotlin.intArrayOf' call
      var tmp$ret$0 = new Int32Array([0, 0, 8]);
      tmp = BigInteger_init_$Create$_0(1, tmp$ret$0);
    } else {
      tmp = Companion_getInstance_0().mc(negate(this.we_1));
    }
    return tmp;
  };
  protoOf(ParsedMagnitude537).if = function (sign, scale) {
    if (this.xe_1 == null && (sign < 0 || !equalsLong(this.we_1, new Long(0, -2147483648))))
      return Companion_getInstance().ee(sign < 0 ? this.we_1 : negate(this.we_1), scale);
    return BigDecimal_init_$Create$_0(this.ef(sign), scale);
  };
  function invalidIntegerDigit($this, value, radix, start, invalid) {
    var power = fromInt(radix);
    var width = 1;
    $l$loop: while (true) {
      // Inline function 'kotlin.Long.times' call
      var this_0 = power;
      var tmp$ret$0 = multiply(this_0, fromInt(radix));
      if (!(compare(tmp$ret$0, new Long(2147483647, 0)) <= 0)) {
        break $l$loop;
      }
      // Inline function 'kotlin.Long.times' call
      var this_1 = power;
      power = multiply(this_1, fromInt(radix));
      width = width + 1 | 0;
    }
    var firstWidth = (((value.ve_1 - start | 0) - 1 | 0) % width | 0) + 1 | 0;
    var groupStart = invalid < (start + firstWidth | 0) ? start : (start + firstWidth | 0) + imul(((invalid - start | 0) - firstWidth | 0) / width | 0, width) | 0;
    var groupEnd = groupStart === start ? start + firstWidth | 0 : groupStart + width | 0;
    var suffix = radix === 10 ? '' : ' under radix ' + radix;
    throw NumberFormatException_init_$Create$('For input string: "' + value.jf(groupStart, groupEnd) + '"' + suffix);
  }
  function fromBytes($this, bytes, off, len, twos) {
    var tmp;
    if (twos) {
      // Inline function 'kotlin.collections.isEmpty' call
      tmp = bytes.length === 0;
    } else {
      tmp = false;
    }
    if (tmp)
      throw NumberFormatException_init_$Create$('Zero length BigInteger');
    checkBounds($this, bytes, off, len);
    if (len === 0)
      return $this.fc_1;
    var negative = twos && bytes[off] < 0;
    var start = off;
    var end = off + len | 0;
    if (negative) {
      while ((end - start | 0) > 1 && bytes[start] === -1) {
        start = start + 1 | 0;
      }
    } else {
      while (start < end && bytes[start] === 0) {
        start = start + 1 | 0;
      }
      if (start === end)
        return $this.fc_1;
    }
    var result = new Int32Array(MagnitudeLimits_instance.kf(end - start | 0, negative));
    var buffer = new Long(0, 0);
    var bufferedBits = 0;
    var word = 0;
    var carry = negative ? 1 : 0;
    var inductionVariable = end - 1 | 0;
    var last = start;
    if (last <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var raw = bytes[i] & 255;
        var converted = negative ? (raw ^ 255) + carry | 0 : raw;
        if (negative)
          carry = converted >>> 8 | 0;
        buffer = bitwiseOr(buffer, shiftLeft(fromInt(converted & 255), bufferedBits));
        bufferedBits = bufferedBits + 8 | 0;
        if (bufferedBits >= 30) {
          var _unary__edvuaz = word;
          word = _unary__edvuaz + 1 | 0;
          result[_unary__edvuaz] = convertToInt(bitwiseAnd(buffer, new Long(1073741823, 0)));
          buffer = shiftRightUnsigned(buffer, 30);
          bufferedBits = bufferedBits - 30 | 0;
        }
      }
       while (!(i === last));
    buffer = bitwiseOr(buffer, shiftLeft(fromInt(carry), bufferedBits));
    if (!equalsLong(buffer, new Long(0, 0))) {
      result[word] = convertToInt(buffer);
    }
    return normalized($this, negative ? -1 : 1, result);
  }
  function signedBytes($this, signum, bytes, off, len) {
    if (!(-1 <= signum ? signum <= 1 : false))
      throw NumberFormatException_init_$Create$('Invalid signum value');
    var magnitude = bytes;
    if (signum === 0) {
      checkBounds($this, magnitude, off, len);
      var inductionVariable = off;
      var last = off + len | 0;
      if (inductionVariable < last)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!(magnitude[i] === 0))
            throw NumberFormatException_init_$Create$('signum-magnitude mismatch');
        }
         while (inductionVariable < last);
      return $this.fc_1;
    }
    var n = fromBytes($this, magnitude, off, len, false);
    return signum < 0 ? n.qc() : n;
  }
  function checkBounds($this, bytes, off, len) {
    if (off < 0 || len < 0 || off > (bytes.length - len | 0))
      throw IndexOutOfBoundsException_init_$Create$('Range [' + off + ', ' + off + ' + ' + len + ') out of bounds for length ' + bytes.length);
  }
  function compactResult529($this, value) {
    return equalsLong(value, new Long(0, 0)) ? $this.fc_1 : BigInteger_init_$Create$(value);
  }
  function normalized($this, sign, words) {
    var length = words.length;
    while (length > 0 && words[length - 1 | 0] === 0) {
      length = length - 1 | 0;
    }
    if (length === 0)
      return $this.fc_1;
    MagnitudeLimits_instance.hf(length, words[length - 1 | 0]);
    return BigInteger_init_$Create$_0(sign, length === words.length ? words : copyOf(words, length));
  }
  function compareMagnitude_0($this, a, b) {
    if (!(a.length === b.length))
      return compareTo(a.length, b.length);
    var inductionVariable = a.length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        if (!(a[i] === b[i]))
          return compareTo(a[i], b[i]);
      }
       while (0 <= inductionVariable);
    return 0;
  }
  function addMagnitude($this, a, b) {
    var tmp0 = a.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_0 = b.length;
    var tmp$ret$0 = Math.max(tmp0, b_0);
    var out = new Int32Array(tmp$ret$0 + 1 | 0);
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = get_lastIndex(out);
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.collections.getOrElse' call
        var tmp;
        if (0 <= i ? i <= (a.length - 1 | 0) : false) {
          tmp = a[i];
        } else {
          tmp = 0;
        }
        var tmp$ret$1 = tmp;
        var tmp0_0 = fromInt(tmp$ret$1);
        // Inline function 'kotlin.collections.getOrElse' call
        var tmp_0;
        if (0 <= i ? i <= (b.length - 1 | 0) : false) {
          tmp_0 = b[i];
        } else {
          tmp_0 = 0;
        }
        // Inline function 'kotlin.Long.plus' call
        var other = tmp_0;
        var tmp$ret$5 = add(tmp0_0, fromInt(other));
        var n = add(tmp$ret$5, carry);
        out[i] = convertToInt(bitwiseAnd(n, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(n, 30);
      }
       while (inductionVariable < last);
    out[get_lastIndex(out)] = convertToInt(carry);
    return out;
  }
  function subtractMagnitude($this, a, b) {
    var out = new Int32Array(a.length);
    var borrow = new Long(0, 0);
    var inductionVariable = 0;
    var last = a.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = fromInt(a[i]);
        // Inline function 'kotlin.collections.getOrElse' call
        var tmp;
        if (0 <= i ? i <= (b.length - 1 | 0) : false) {
          tmp = b[i];
        } else {
          tmp = 0;
        }
        // Inline function 'kotlin.Long.minus' call
        var other = tmp;
        var tmp$ret$2 = subtract(tmp0, fromInt(other));
        var n = subtract(tmp$ret$2, borrow);
        out[i] = convertToInt(bitwiseAnd(n, new Long(1073741823, 0)));
        borrow = compare(n, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
      }
       while (inductionVariable <= last);
    return out;
  }
  function BigInteger_init_$Init$(value, $this) {
    BigInteger.call($this, CompactInteger529_getInstance().od(value), convertToInt(shiftRight(value, 32)), convertToInt(value), 1, null);
    return $this;
  }
  function BigInteger_init_$Create$(value) {
    return BigInteger_init_$Init$(value, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_0(sign, words, $this) {
    BigInteger.call($this, sign, CompactInteger529_getInstance().mf(sign, words) ? convertToInt(shiftRight(CompactInteger529_getInstance().lf(sign, words), 32)) : 0, CompactInteger529_getInstance().mf(sign, words) ? convertToInt(CompactInteger529_getInstance().lf(sign, words)) : 0, CompactInteger529_getInstance().mf(sign, words) ? 1 : 2, CompactInteger529_getInstance().mf(sign, words) ? null : words);
    return $this;
  }
  function BigInteger_init_$Create$_0(sign, words) {
    return BigInteger_init_$Init$_0(sign, words, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_1(value, $this) {
    BigInteger.call($this, value.ya_1, value.za_1, value.ab_1, value.bb_1, value.cb_1);
    return $this;
  }
  function materializeMagnitude($this) {
    var tmp0_elvis_lhs = $this.cb_1;
    return tmp0_elvis_lhs == null ? CompactInteger529_getInstance().gf($this.za_1, $this.ab_1) : tmp0_elvis_lhs;
  }
  function BigInteger_init_$Init$_2(value, $this) {
    BigInteger_init_$Init$_3(value, 10, $this);
    return $this;
  }
  function BigInteger_init_$Create$_1(value) {
    return BigInteger_init_$Init$_2(value, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_3(value, radix, $this) {
    BigInteger_init_$Init$_1(parse_0(Companion_getInstance_0(), value, radix), $this);
    return $this;
  }
  function BigInteger_init_$Init$_4(value, $this) {
    BigInteger_init_$Init$_1(fromBytes(Companion_getInstance_0(), value, 0, value.length, true), $this);
    return $this;
  }
  function BigInteger_init_$Create$_2(value) {
    return BigInteger_init_$Init$_4(value, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_5(signum, magnitude, $this) {
    BigInteger_init_$Init$_6(signum, magnitude, 0, magnitude.length, $this);
    return $this;
  }
  function BigInteger_init_$Create$_3(signum, magnitude) {
    return BigInteger_init_$Init$_5(signum, magnitude, objectCreate(protoOf(BigInteger)));
  }
  function BigInteger_init_$Init$_6(signum, magnitude, off, len, $this) {
    BigInteger_init_$Init$_1(signedBytes(Companion_getInstance_0(), signum, magnitude, off, len), $this);
    return $this;
  }
  function overflowingCompactResult529($this, wrapped, resultSign) {
    var magnitude = resultSign < 0 ? negate(wrapped) : wrapped;
    var high = convertToInt(shiftRightUnsigned(magnitude, 60)) | (equalsLong(wrapped, new Long(0, 0)) ? 16 : 0);
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$0 = new Int32Array([convertToInt(bitwiseAnd(magnitude, new Long(1073741823, 0))), convertToInt(bitwiseAnd(shiftRightUnsigned(magnitude, 30), new Long(1073741823, 0))), high]);
    return BigInteger_init_$Create$_0(resultSign, tmp$ret$0);
  }
  function compactCancellation529($this, other, subtract) {
    var wide;
    var small;
    var wideSign;
    var smallSign;
    if ($this.bb_1 === 2 && other.bb_1 === 1) {
      wide = $this;
      small = other;
      wideSign = $this.ya_1;
      smallSign = subtract ? -other.ya_1 | 0 : other.ya_1;
    } else if ($this.bb_1 === 1 && other.bb_1 === 2) {
      wide = other;
      small = $this;
      wideSign = subtract ? -other.ya_1 | 0 : other.ya_1;
      smallSign = $this.ya_1;
    } else
      return null;
    if (wideSign === smallSign)
      return null;
    var magnitude = ensureNotNull(wide.cb_1);
    var tmp;
    if (!(magnitude.length === 3)) {
      tmp = true;
    } else {
      var containsArg = magnitude[2];
      tmp = !(8 <= containsArg ? containsArg <= 15 : false);
    }
    if (tmp)
      return null;
    var offset = bitwiseOr(bitwiseOr(shiftLeft(fromInt(magnitude[2] & 7), 60), shiftLeft(fromInt(magnitude[1]), 30)), fromInt(magnitude[0]));
    var value = small.cd();
    var delta = add(offset, compare(value, new Long(0, 0)) > 0 ? negate(value) : value);
    if (equalsLong(delta, new Long(0, 0)) && wideSign < 0)
      return compactResult529(Companion_getInstance_0(), new Long(0, -2147483648));
    if (compare(delta, new Long(0, 0)) >= 0)
      return null;
    var result = add(add(new Long(-1, 2147483647), delta), new Long(1, 0));
    return compactResult529(Companion_getInstance_0(), wideSign < 0 ? negate(result) : result);
  }
  function quotientStored($this, value) {
    var tmp$ret$0;
    $l$block_1: {
      // Inline function 'io.heapy.krogu.math.BigInteger.selectStoredDivision' call
      if (value.ya_1 === 0)
        throw ArithmeticException_init_$Create$('BigInteger divide by zero');
      if ($this.bb_1 === 1 && value.bb_1 === 1) {
        var a = $this.cd();
        var b = value.cd();
        var tmp;
        if (!true) {
          tmp = Companion_getInstance_0().fc_1;
        } else if (equalsLong(a, new Long(0, -2147483648)) && equalsLong(b, new Long(-1, -1))) {
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$1 = new Int32Array([0, 0, 8]);
          tmp = BigInteger_init_$Create$_0(1, tmp$ret$1);
        } else {
          tmp = compactResult529(Companion_getInstance_0(), divide(a, b));
        }
        var quotient = tmp;
        false ? compactResult529(Companion_getInstance_0(), modulo(a, b)) : Companion_getInstance_0().fc_1;
        tmp$ret$0 = quotient;
        break $l$block_1;
      }
      var words = materializeMagnitude($this);
      var valueWords = value.bb_1 === 1 ? null : value === $this ? words : materializeMagnitude(value);
      if (!(valueWords == null) && compareMagnitude_0(Companion_getInstance_0(), words, valueWords) < 0) {
        false ? normalized(Companion_getInstance_0(), $this.ya_1, words) : Companion_getInstance_0().fc_1;
        tmp$ret$0 = Companion_getInstance_0().fc_1;
        break $l$block_1;
      }
      var tmp1_elvis_lhs = valueWords == null ? null : valueWords.length;
      var n = tmp1_elvis_lhs == null ? ((magnitudeBits(value) + 30 | 0) - 1 | 0) / 30 | 0 : tmp1_elvis_lhs;
      var compactDivisor = valueWords == null ? value.cd() : new Long(0, 0);
      if (n === 1) {
        var tmp3_elvis_lhs = valueWords == null ? null : valueWords[0];
        var divisorWord = tmp3_elvis_lhs == null ? CompactInteger529_getInstance().nf(value.za_1, value.ab_1, 0) : tmp3_elvis_lhs;
        var result = true ? new Int32Array(words.length) : null;
        var remainder = new Long(0, 0);
        var inductionVariable = words.length - 1 | 0;
        if (0 <= inductionVariable)
          do {
            var i = inductionVariable;
            inductionVariable = inductionVariable + -1 | 0;
            var tmp0 = shiftLeft(remainder, 30);
            // Inline function 'kotlin.Long.plus' call
            var other = words[i];
            var part = add(tmp0, fromInt(other));
            if (!(result == null)) {
              // Inline function 'kotlin.Long.div' call
              var tmp$ret$5 = divide(part, fromInt(divisorWord));
              result[i] = convertToInt(tmp$ret$5);
            }
            // Inline function 'kotlin.Long.rem' call
            remainder = modulo(part, fromInt(divisorWord));
          }
           while (0 <= inductionVariable);
        var tmp0_0 = !(result == null) ? normalized(Companion_getInstance_0(), imul($this.ya_1, value.ya_1), result) : Companion_getInstance_0().fc_1;
        var tmp_0;
        if (false) {
          var tmp_1 = Companion_getInstance_0();
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$7 = new Int32Array([convertToInt(remainder)]);
          tmp_0 = normalized(tmp_1, $this.ya_1, tmp$ret$7);
        } else {
          tmp_0 = Companion_getInstance_0().fc_1;
        }
        tmp$ret$0 = tmp0_0;
        break $l$block_1;
      }
      var tmp5_elvis_lhs = valueWords == null ? null : last(valueWords);
      var highWord = tmp5_elvis_lhs == null ? CompactInteger529_getInstance().nf(value.za_1, value.ab_1, n - 1 | 0) : tmp5_elvis_lhs;
      // Inline function 'kotlin.countLeadingZeroBits' call
      var shift = clz32(highWord) - 2 | 0;
      var divisor = new Int32Array(n);
      if (!(valueWords == null)) {
        // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < n)
          do {
            var i_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp$ret$11 = valueWords[i_0];
            var digit = bitwiseOr(shiftLeft(fromInt(tmp$ret$11), shift), carry);
            divisor[i_0] = convertToInt(bitwiseAnd(digit, new Long(1073741823, 0)));
            carry = shiftRightUnsigned(digit, 30);
          }
           while (inductionVariable_0 < n);
        convertToInt(carry);
      } else {
        // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
        var carry_0 = new Long(0, 0);
        var inductionVariable_1 = 0;
        if (inductionVariable_1 < n)
          do {
            var i_1 = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var tmp$ret$13 = CompactInteger529_getInstance().nf(convertToInt(shiftRight(compactDivisor, 32)), convertToInt(compactDivisor), i_1);
            var digit_0 = bitwiseOr(shiftLeft(fromInt(tmp$ret$13), shift), carry_0);
            divisor[i_1] = convertToInt(bitwiseAnd(digit_0, new Long(1073741823, 0)));
            carry_0 = shiftRightUnsigned(digit_0, 30);
          }
           while (inductionVariable_1 < n);
        convertToInt(carry_0);
      }
      var dividend = new Int32Array(words.length + 1 | 0);
      var tmp_2 = words.length;
      // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
      var sourceSize = words.length;
      var carry_1 = new Long(0, 0);
      var inductionVariable_2 = 0;
      if (inductionVariable_2 < sourceSize)
        do {
          var i_2 = inductionVariable_2;
          inductionVariable_2 = inductionVariable_2 + 1 | 0;
          var tmp$ret$15 = words[i_2];
          var digit_1 = bitwiseOr(shiftLeft(fromInt(tmp$ret$15), shift), carry_1);
          dividend[i_2] = convertToInt(bitwiseAnd(digit_1, new Long(1073741823, 0)));
          carry_1 = shiftRightUnsigned(digit_1, 30);
        }
         while (inductionVariable_2 < sourceSize);
      dividend[tmp_2] = convertToInt(carry_1);
      var quotient_0 = true ? new Int32Array((words.length - n | 0) + 1 | 0) : null;
      // Inline function 'kotlin.Long.plus' call
      var this_0 = new Long(1073741823, 0);
      var radix = add(this_0, fromInt(1));
      var high = fromInt(divisor[n - 1 | 0]);
      var next = fromInt(divisor[n - 2 | 0]);
      var inductionVariable_3 = words.length - n | 0;
      if (0 <= inductionVariable_3)
        do {
          var j = inductionVariable_3;
          inductionVariable_3 = inductionVariable_3 + -1 | 0;
          var tmp0_1 = shiftLeft(fromInt(dividend[j + n | 0]), 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = dividend[(j + n | 0) - 1 | 0];
          var top = add(tmp0_1, fromInt(other_0));
          var tmp0_2 = divide(top, high);
          // Inline function 'kotlin.comparisons.minOf' call
          var b_0 = new Long(1073741823, 0);
          var estimate = compare(tmp0_2, b_0) <= 0 ? tmp0_2 : b_0;
          var residual = subtract(top, multiply(estimate, high));
          $l$loop: while (true) {
            var tmp_3;
            if (compare(residual, radix) < 0) {
              var tmp_4 = multiply(estimate, next);
              var tmp0_3 = shiftLeft(residual, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_1 = dividend[(j + n | 0) - 2 | 0];
              var tmp$ret$19 = add(tmp0_3, fromInt(other_1));
              tmp_3 = compare(tmp_4, tmp$ret$19) > 0;
            } else {
              tmp_3 = false;
            }
            if (!tmp_3) {
              break $l$loop;
            }
            var _unary__edvuaz = estimate;
            estimate = subtract(_unary__edvuaz, get_ONE());
            residual = add(residual, high);
          }
          var borrow = new Long(0, 0);
          var inductionVariable_4 = 0;
          if (inductionVariable_4 < n)
            do {
              var i_3 = inductionVariable_4;
              inductionVariable_4 = inductionVariable_4 + 1 | 0;
              var tmp0_4 = estimate;
              // Inline function 'kotlin.Long.times' call
              var other_2 = divisor[i_3];
              var tmp$ret$20 = multiply(tmp0_4, fromInt(other_2));
              var product = add(tmp$ret$20, borrow);
              var difference = subtract(fromInt(dividend[j + i_3 | 0]), bitwiseAnd(product, new Long(1073741823, 0)));
              dividend[j + i_3 | 0] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
              var tmp0_5 = shiftRightUnsigned(product, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_3 = compare(difference, new Long(0, 0)) < 0 ? 1 : 0;
              borrow = add(tmp0_5, fromInt(other_3));
            }
             while (inductionVariable_4 < n);
          var difference_0 = subtract(fromInt(dividend[j + n | 0]), borrow);
          dividend[j + n | 0] = convertToInt(bitwiseAnd(difference_0, new Long(1073741823, 0)));
          if (compare(difference_0, new Long(0, 0)) < 0) {
            var _unary__edvuaz_0 = estimate;
            estimate = subtract(_unary__edvuaz_0, get_ONE());
            var carry_2 = new Long(0, 0);
            var inductionVariable_5 = 0;
            if (inductionVariable_5 < n)
              do {
                var i_4 = inductionVariable_5;
                inductionVariable_5 = inductionVariable_5 + 1 | 0;
                var tmp0_6 = fromInt(dividend[j + i_4 | 0]);
                // Inline function 'kotlin.Long.plus' call
                var other_4 = divisor[i_4];
                var tmp$ret$22 = add(tmp0_6, fromInt(other_4));
                var sum = add(tmp$ret$22, carry_2);
                dividend[j + i_4 | 0] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
                carry_2 = shiftRightUnsigned(sum, 30);
              }
               while (inductionVariable_5 < n);
            dividend[j + n | 0] = convertToInt(bitwiseAnd(add(fromInt(dividend[j + n | 0]), carry_2), new Long(1073741823, 0)));
          }
          if (!(quotient_0 == null)) {
            quotient_0[j] = convertToInt(estimate);
          }
        }
         while (0 <= inductionVariable_3);
      var remainder_0 = false ? new Int32Array(n) : null;
      if (!(remainder_0 == null)) {
        var inductionVariable_6 = 0;
        if (inductionVariable_6 < n)
          do {
            var i_5 = inductionVariable_6;
            inductionVariable_6 = inductionVariable_6 + 1 | 0;
            remainder_0[i_5] = shift === 0 ? dividend[i_5] : dividend[i_5] >>> shift | 0 | convertToInt(bitwiseAnd(shiftLeft(fromInt(dividend[i_5 + 1 | 0]), 30 - shift | 0), new Long(1073741823, 0)));
          }
           while (inductionVariable_6 < n);
      }
      !(remainder_0 == null) ? normalized(Companion_getInstance_0(), $this.ya_1, remainder_0) : Companion_getInstance_0().fc_1;
      tmp$ret$0 = !(quotient_0 == null) ? normalized(Companion_getInstance_0(), imul($this.ya_1, value.ya_1), quotient_0) : Companion_getInstance_0().fc_1;
    }
    return tmp$ret$0;
  }
  function remainderStored($this, value) {
    var tmp$ret$0;
    $l$block_1: {
      // Inline function 'io.heapy.krogu.math.BigInteger.selectStoredDivision' call
      if (value.ya_1 === 0)
        throw ArithmeticException_init_$Create$('BigInteger divide by zero');
      if ($this.bb_1 === 1 && value.bb_1 === 1) {
        var a = $this.cd();
        var b = value.cd();
        var tmp;
        if (!false) {
          tmp = Companion_getInstance_0().fc_1;
        } else if (equalsLong(a, new Long(0, -2147483648)) && equalsLong(b, new Long(-1, -1))) {
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$1 = new Int32Array([0, 0, 8]);
          tmp = BigInteger_init_$Create$_0(1, tmp$ret$1);
        } else {
          tmp = compactResult529(Companion_getInstance_0(), divide(a, b));
        }
        var quotient = tmp;
        tmp$ret$0 = true ? compactResult529(Companion_getInstance_0(), modulo(a, b)) : Companion_getInstance_0().fc_1;
        break $l$block_1;
      }
      var words = materializeMagnitude($this);
      var valueWords = value.bb_1 === 1 ? null : value === $this ? words : materializeMagnitude(value);
      if (!(valueWords == null) && compareMagnitude_0(Companion_getInstance_0(), words, valueWords) < 0) {
        Companion_getInstance_0().fc_1;
        tmp$ret$0 = true ? normalized(Companion_getInstance_0(), $this.ya_1, words) : Companion_getInstance_0().fc_1;
        break $l$block_1;
      }
      var tmp1_elvis_lhs = valueWords == null ? null : valueWords.length;
      var n = tmp1_elvis_lhs == null ? ((magnitudeBits(value) + 30 | 0) - 1 | 0) / 30 | 0 : tmp1_elvis_lhs;
      var compactDivisor = valueWords == null ? value.cd() : new Long(0, 0);
      if (n === 1) {
        var tmp3_elvis_lhs = valueWords == null ? null : valueWords[0];
        var divisorWord = tmp3_elvis_lhs == null ? CompactInteger529_getInstance().nf(value.za_1, value.ab_1, 0) : tmp3_elvis_lhs;
        var result = false ? new Int32Array(words.length) : null;
        var remainder = new Long(0, 0);
        var inductionVariable = words.length - 1 | 0;
        if (0 <= inductionVariable)
          do {
            var i = inductionVariable;
            inductionVariable = inductionVariable + -1 | 0;
            var tmp0 = shiftLeft(remainder, 30);
            // Inline function 'kotlin.Long.plus' call
            var other = words[i];
            var part = add(tmp0, fromInt(other));
            if (!(result == null)) {
              // Inline function 'kotlin.Long.div' call
              var tmp$ret$5 = divide(part, fromInt(divisorWord));
              result[i] = convertToInt(tmp$ret$5);
            }
            // Inline function 'kotlin.Long.rem' call
            remainder = modulo(part, fromInt(divisorWord));
          }
           while (0 <= inductionVariable);
        !(result == null) ? normalized(Companion_getInstance_0(), imul($this.ya_1, value.ya_1), result) : Companion_getInstance_0().fc_1;
        var tmp_0;
        if (true) {
          var tmp_1 = Companion_getInstance_0();
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$7 = new Int32Array([convertToInt(remainder)]);
          tmp_0 = normalized(tmp_1, $this.ya_1, tmp$ret$7);
        } else {
          tmp_0 = Companion_getInstance_0().fc_1;
        }
        tmp$ret$0 = tmp_0;
        break $l$block_1;
      }
      var tmp5_elvis_lhs = valueWords == null ? null : last(valueWords);
      var highWord = tmp5_elvis_lhs == null ? CompactInteger529_getInstance().nf(value.za_1, value.ab_1, n - 1 | 0) : tmp5_elvis_lhs;
      // Inline function 'kotlin.countLeadingZeroBits' call
      var shift = clz32(highWord) - 2 | 0;
      var divisor = new Int32Array(n);
      if (!(valueWords == null)) {
        // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < n)
          do {
            var i_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp$ret$11 = valueWords[i_0];
            var digit = bitwiseOr(shiftLeft(fromInt(tmp$ret$11), shift), carry);
            divisor[i_0] = convertToInt(bitwiseAnd(digit, new Long(1073741823, 0)));
            carry = shiftRightUnsigned(digit, 30);
          }
           while (inductionVariable_0 < n);
        convertToInt(carry);
      } else {
        // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
        var carry_0 = new Long(0, 0);
        var inductionVariable_1 = 0;
        if (inductionVariable_1 < n)
          do {
            var i_1 = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var tmp$ret$13 = CompactInteger529_getInstance().nf(convertToInt(shiftRight(compactDivisor, 32)), convertToInt(compactDivisor), i_1);
            var digit_0 = bitwiseOr(shiftLeft(fromInt(tmp$ret$13), shift), carry_0);
            divisor[i_1] = convertToInt(bitwiseAnd(digit_0, new Long(1073741823, 0)));
            carry_0 = shiftRightUnsigned(digit_0, 30);
          }
           while (inductionVariable_1 < n);
        convertToInt(carry_0);
      }
      var dividend = new Int32Array(words.length + 1 | 0);
      var tmp_2 = words.length;
      // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
      var sourceSize = words.length;
      var carry_1 = new Long(0, 0);
      var inductionVariable_2 = 0;
      if (inductionVariable_2 < sourceSize)
        do {
          var i_2 = inductionVariable_2;
          inductionVariable_2 = inductionVariable_2 + 1 | 0;
          var tmp$ret$15 = words[i_2];
          var digit_1 = bitwiseOr(shiftLeft(fromInt(tmp$ret$15), shift), carry_1);
          dividend[i_2] = convertToInt(bitwiseAnd(digit_1, new Long(1073741823, 0)));
          carry_1 = shiftRightUnsigned(digit_1, 30);
        }
         while (inductionVariable_2 < sourceSize);
      dividend[tmp_2] = convertToInt(carry_1);
      var quotient_0 = false ? new Int32Array((words.length - n | 0) + 1 | 0) : null;
      // Inline function 'kotlin.Long.plus' call
      var this_0 = new Long(1073741823, 0);
      var radix = add(this_0, fromInt(1));
      var high = fromInt(divisor[n - 1 | 0]);
      var next = fromInt(divisor[n - 2 | 0]);
      var inductionVariable_3 = words.length - n | 0;
      if (0 <= inductionVariable_3)
        do {
          var j = inductionVariable_3;
          inductionVariable_3 = inductionVariable_3 + -1 | 0;
          var tmp0_0 = shiftLeft(fromInt(dividend[j + n | 0]), 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = dividend[(j + n | 0) - 1 | 0];
          var top = add(tmp0_0, fromInt(other_0));
          var tmp0_1 = divide(top, high);
          // Inline function 'kotlin.comparisons.minOf' call
          var b_0 = new Long(1073741823, 0);
          var estimate = compare(tmp0_1, b_0) <= 0 ? tmp0_1 : b_0;
          var residual = subtract(top, multiply(estimate, high));
          $l$loop: while (true) {
            var tmp_3;
            if (compare(residual, radix) < 0) {
              var tmp_4 = multiply(estimate, next);
              var tmp0_2 = shiftLeft(residual, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_1 = dividend[(j + n | 0) - 2 | 0];
              var tmp$ret$19 = add(tmp0_2, fromInt(other_1));
              tmp_3 = compare(tmp_4, tmp$ret$19) > 0;
            } else {
              tmp_3 = false;
            }
            if (!tmp_3) {
              break $l$loop;
            }
            var _unary__edvuaz = estimate;
            estimate = subtract(_unary__edvuaz, get_ONE());
            residual = add(residual, high);
          }
          var borrow = new Long(0, 0);
          var inductionVariable_4 = 0;
          if (inductionVariable_4 < n)
            do {
              var i_3 = inductionVariable_4;
              inductionVariable_4 = inductionVariable_4 + 1 | 0;
              var tmp0_3 = estimate;
              // Inline function 'kotlin.Long.times' call
              var other_2 = divisor[i_3];
              var tmp$ret$20 = multiply(tmp0_3, fromInt(other_2));
              var product = add(tmp$ret$20, borrow);
              var difference = subtract(fromInt(dividend[j + i_3 | 0]), bitwiseAnd(product, new Long(1073741823, 0)));
              dividend[j + i_3 | 0] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
              var tmp0_4 = shiftRightUnsigned(product, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_3 = compare(difference, new Long(0, 0)) < 0 ? 1 : 0;
              borrow = add(tmp0_4, fromInt(other_3));
            }
             while (inductionVariable_4 < n);
          var difference_0 = subtract(fromInt(dividend[j + n | 0]), borrow);
          dividend[j + n | 0] = convertToInt(bitwiseAnd(difference_0, new Long(1073741823, 0)));
          if (compare(difference_0, new Long(0, 0)) < 0) {
            var _unary__edvuaz_0 = estimate;
            estimate = subtract(_unary__edvuaz_0, get_ONE());
            var carry_2 = new Long(0, 0);
            var inductionVariable_5 = 0;
            if (inductionVariable_5 < n)
              do {
                var i_4 = inductionVariable_5;
                inductionVariable_5 = inductionVariable_5 + 1 | 0;
                var tmp0_5 = fromInt(dividend[j + i_4 | 0]);
                // Inline function 'kotlin.Long.plus' call
                var other_4 = divisor[i_4];
                var tmp$ret$22 = add(tmp0_5, fromInt(other_4));
                var sum = add(tmp$ret$22, carry_2);
                dividend[j + i_4 | 0] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
                carry_2 = shiftRightUnsigned(sum, 30);
              }
               while (inductionVariable_5 < n);
            dividend[j + n | 0] = convertToInt(bitwiseAnd(add(fromInt(dividend[j + n | 0]), carry_2), new Long(1073741823, 0)));
          }
          if (!(quotient_0 == null)) {
            quotient_0[j] = convertToInt(estimate);
          }
        }
         while (0 <= inductionVariable_3);
      var remainder_0 = true ? new Int32Array(n) : null;
      if (!(remainder_0 == null)) {
        var inductionVariable_6 = 0;
        if (inductionVariable_6 < n)
          do {
            var i_5 = inductionVariable_6;
            inductionVariable_6 = inductionVariable_6 + 1 | 0;
            remainder_0[i_5] = shift === 0 ? dividend[i_5] : dividend[i_5] >>> shift | 0 | convertToInt(bitwiseAnd(shiftLeft(fromInt(dividend[i_5 + 1 | 0]), 30 - shift | 0), new Long(1073741823, 0)));
          }
           while (inductionVariable_6 < n);
      }
      !(quotient_0 == null) ? normalized(Companion_getInstance_0(), imul($this.ya_1, value.ya_1), quotient_0) : Companion_getInstance_0().fc_1;
      tmp$ret$0 = !(remainder_0 == null) ? normalized(Companion_getInstance_0(), $this.ya_1, remainder_0) : Companion_getInstance_0().fc_1;
    }
    return tmp$ret$0;
  }
  function divideStored($this, value) {
    var tmp$ret$0;
    $l$block_1: {
      // Inline function 'io.heapy.krogu.math.BigInteger.selectStoredDivision' call
      if (value.ya_1 === 0)
        throw ArithmeticException_init_$Create$('BigInteger divide by zero');
      if ($this.bb_1 === 1 && value.bb_1 === 1) {
        var a = $this.cd();
        var b = value.cd();
        var tmp;
        if (!true) {
          tmp = Companion_getInstance_0().fc_1;
        } else if (equalsLong(a, new Long(0, -2147483648)) && equalsLong(b, new Long(-1, -1))) {
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$1 = new Int32Array([0, 0, 8]);
          tmp = BigInteger_init_$Create$_0(1, tmp$ret$1);
        } else {
          tmp = compactResult529(Companion_getInstance_0(), divide(a, b));
        }
        var quotient = tmp;
        // Inline function 'kotlin.arrayOf' call
        // Inline function 'kotlin.js.unsafeCast' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp$ret$0 = [quotient, true ? compactResult529(Companion_getInstance_0(), modulo(a, b)) : Companion_getInstance_0().fc_1];
        break $l$block_1;
      }
      var words = materializeMagnitude($this);
      var valueWords = value.bb_1 === 1 ? null : value === $this ? words : materializeMagnitude(value);
      if (!(valueWords == null) && compareMagnitude_0(Companion_getInstance_0(), words, valueWords) < 0) {
        // Inline function 'kotlin.arrayOf' call
        // Inline function 'kotlin.js.unsafeCast' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp$ret$0 = [Companion_getInstance_0().fc_1, true ? normalized(Companion_getInstance_0(), $this.ya_1, words) : Companion_getInstance_0().fc_1];
        break $l$block_1;
      }
      var tmp1_elvis_lhs = valueWords == null ? null : valueWords.length;
      var n = tmp1_elvis_lhs == null ? ((magnitudeBits(value) + 30 | 0) - 1 | 0) / 30 | 0 : tmp1_elvis_lhs;
      var compactDivisor = valueWords == null ? value.cd() : new Long(0, 0);
      if (n === 1) {
        var tmp3_elvis_lhs = valueWords == null ? null : valueWords[0];
        var divisorWord = tmp3_elvis_lhs == null ? CompactInteger529_getInstance().nf(value.za_1, value.ab_1, 0) : tmp3_elvis_lhs;
        var result = true ? new Int32Array(words.length) : null;
        var remainder = new Long(0, 0);
        var inductionVariable = words.length - 1 | 0;
        if (0 <= inductionVariable)
          do {
            var i = inductionVariable;
            inductionVariable = inductionVariable + -1 | 0;
            var tmp0 = shiftLeft(remainder, 30);
            // Inline function 'kotlin.Long.plus' call
            var other = words[i];
            var part = add(tmp0, fromInt(other));
            if (!(result == null)) {
              // Inline function 'kotlin.Long.div' call
              var tmp$ret$11 = divide(part, fromInt(divisorWord));
              result[i] = convertToInt(tmp$ret$11);
            }
            // Inline function 'kotlin.Long.rem' call
            remainder = modulo(part, fromInt(divisorWord));
          }
           while (0 <= inductionVariable);
        var tmp0_0 = !(result == null) ? normalized(Companion_getInstance_0(), imul($this.ya_1, value.ya_1), result) : Companion_getInstance_0().fc_1;
        var tmp_0;
        if (true) {
          var tmp_1 = Companion_getInstance_0();
          // Inline function 'kotlin.intArrayOf' call
          var tmp$ret$13 = new Int32Array([convertToInt(remainder)]);
          tmp_0 = normalized(tmp_1, $this.ya_1, tmp$ret$13);
        } else {
          tmp_0 = Companion_getInstance_0().fc_1;
        }
        // Inline function 'kotlin.arrayOf' call
        // Inline function 'kotlin.js.unsafeCast' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp$ret$0 = [tmp0_0, tmp_0];
        break $l$block_1;
      }
      var tmp5_elvis_lhs = valueWords == null ? null : last(valueWords);
      var highWord = tmp5_elvis_lhs == null ? CompactInteger529_getInstance().nf(value.za_1, value.ab_1, n - 1 | 0) : tmp5_elvis_lhs;
      // Inline function 'kotlin.countLeadingZeroBits' call
      var shift = clz32(highWord) - 2 | 0;
      var divisor = new Int32Array(n);
      if (!(valueWords == null)) {
        // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < n)
          do {
            var i_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp$ret$20 = valueWords[i_0];
            var digit = bitwiseOr(shiftLeft(fromInt(tmp$ret$20), shift), carry);
            divisor[i_0] = convertToInt(bitwiseAnd(digit, new Long(1073741823, 0)));
            carry = shiftRightUnsigned(digit, 30);
          }
           while (inductionVariable_0 < n);
        convertToInt(carry);
      } else {
        // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
        var carry_0 = new Long(0, 0);
        var inductionVariable_1 = 0;
        if (inductionVariable_1 < n)
          do {
            var i_1 = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var tmp$ret$22 = CompactInteger529_getInstance().nf(convertToInt(shiftRight(compactDivisor, 32)), convertToInt(compactDivisor), i_1);
            var digit_0 = bitwiseOr(shiftLeft(fromInt(tmp$ret$22), shift), carry_0);
            divisor[i_1] = convertToInt(bitwiseAnd(digit_0, new Long(1073741823, 0)));
            carry_0 = shiftRightUnsigned(digit_0, 30);
          }
           while (inductionVariable_1 < n);
        convertToInt(carry_0);
      }
      var dividend = new Int32Array(words.length + 1 | 0);
      var tmp_2 = words.length;
      // Inline function 'io.heapy.krogu.math.BigInteger.normalizeStoredDivision' call
      var sourceSize = words.length;
      var carry_1 = new Long(0, 0);
      var inductionVariable_2 = 0;
      if (inductionVariable_2 < sourceSize)
        do {
          var i_2 = inductionVariable_2;
          inductionVariable_2 = inductionVariable_2 + 1 | 0;
          var tmp$ret$24 = words[i_2];
          var digit_1 = bitwiseOr(shiftLeft(fromInt(tmp$ret$24), shift), carry_1);
          dividend[i_2] = convertToInt(bitwiseAnd(digit_1, new Long(1073741823, 0)));
          carry_1 = shiftRightUnsigned(digit_1, 30);
        }
         while (inductionVariable_2 < sourceSize);
      dividend[tmp_2] = convertToInt(carry_1);
      var quotient_0 = true ? new Int32Array((words.length - n | 0) + 1 | 0) : null;
      // Inline function 'kotlin.Long.plus' call
      var this_0 = new Long(1073741823, 0);
      var radix = add(this_0, fromInt(1));
      var high = fromInt(divisor[n - 1 | 0]);
      var next = fromInt(divisor[n - 2 | 0]);
      var inductionVariable_3 = words.length - n | 0;
      if (0 <= inductionVariable_3)
        do {
          var j = inductionVariable_3;
          inductionVariable_3 = inductionVariable_3 + -1 | 0;
          var tmp0_1 = shiftLeft(fromInt(dividend[j + n | 0]), 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = dividend[(j + n | 0) - 1 | 0];
          var top = add(tmp0_1, fromInt(other_0));
          var tmp0_2 = divide(top, high);
          // Inline function 'kotlin.comparisons.minOf' call
          var b_0 = new Long(1073741823, 0);
          var estimate = compare(tmp0_2, b_0) <= 0 ? tmp0_2 : b_0;
          var residual = subtract(top, multiply(estimate, high));
          $l$loop: while (true) {
            var tmp_3;
            if (compare(residual, radix) < 0) {
              var tmp_4 = multiply(estimate, next);
              var tmp0_3 = shiftLeft(residual, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_1 = dividend[(j + n | 0) - 2 | 0];
              var tmp$ret$28 = add(tmp0_3, fromInt(other_1));
              tmp_3 = compare(tmp_4, tmp$ret$28) > 0;
            } else {
              tmp_3 = false;
            }
            if (!tmp_3) {
              break $l$loop;
            }
            var _unary__edvuaz = estimate;
            estimate = subtract(_unary__edvuaz, get_ONE());
            residual = add(residual, high);
          }
          var borrow = new Long(0, 0);
          var inductionVariable_4 = 0;
          if (inductionVariable_4 < n)
            do {
              var i_3 = inductionVariable_4;
              inductionVariable_4 = inductionVariable_4 + 1 | 0;
              var tmp0_4 = estimate;
              // Inline function 'kotlin.Long.times' call
              var other_2 = divisor[i_3];
              var tmp$ret$29 = multiply(tmp0_4, fromInt(other_2));
              var product = add(tmp$ret$29, borrow);
              var difference = subtract(fromInt(dividend[j + i_3 | 0]), bitwiseAnd(product, new Long(1073741823, 0)));
              dividend[j + i_3 | 0] = convertToInt(bitwiseAnd(difference, new Long(1073741823, 0)));
              var tmp0_5 = shiftRightUnsigned(product, 30);
              // Inline function 'kotlin.Long.plus' call
              var other_3 = compare(difference, new Long(0, 0)) < 0 ? 1 : 0;
              borrow = add(tmp0_5, fromInt(other_3));
            }
             while (inductionVariable_4 < n);
          var difference_0 = subtract(fromInt(dividend[j + n | 0]), borrow);
          dividend[j + n | 0] = convertToInt(bitwiseAnd(difference_0, new Long(1073741823, 0)));
          if (compare(difference_0, new Long(0, 0)) < 0) {
            var _unary__edvuaz_0 = estimate;
            estimate = subtract(_unary__edvuaz_0, get_ONE());
            var carry_2 = new Long(0, 0);
            var inductionVariable_5 = 0;
            if (inductionVariable_5 < n)
              do {
                var i_4 = inductionVariable_5;
                inductionVariable_5 = inductionVariable_5 + 1 | 0;
                var tmp0_6 = fromInt(dividend[j + i_4 | 0]);
                // Inline function 'kotlin.Long.plus' call
                var other_4 = divisor[i_4];
                var tmp$ret$31 = add(tmp0_6, fromInt(other_4));
                var sum = add(tmp$ret$31, carry_2);
                dividend[j + i_4 | 0] = convertToInt(bitwiseAnd(sum, new Long(1073741823, 0)));
                carry_2 = shiftRightUnsigned(sum, 30);
              }
               while (inductionVariable_5 < n);
            dividend[j + n | 0] = convertToInt(bitwiseAnd(add(fromInt(dividend[j + n | 0]), carry_2), new Long(1073741823, 0)));
          }
          if (!(quotient_0 == null)) {
            quotient_0[j] = convertToInt(estimate);
          }
        }
         while (0 <= inductionVariable_3);
      var remainder_0 = true ? new Int32Array(n) : null;
      if (!(remainder_0 == null)) {
        var inductionVariable_6 = 0;
        if (inductionVariable_6 < n)
          do {
            var i_5 = inductionVariable_6;
            inductionVariable_6 = inductionVariable_6 + 1 | 0;
            remainder_0[i_5] = shift === 0 ? dividend[i_5] : dividend[i_5] >>> shift | 0 | convertToInt(bitwiseAnd(shiftLeft(fromInt(dividend[i_5 + 1 | 0]), 30 - shift | 0), new Long(1073741823, 0)));
          }
           while (inductionVariable_6 < n);
      }
      // Inline function 'kotlin.arrayOf' call
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp$ret$0 = [!(quotient_0 == null) ? normalized(Companion_getInstance_0(), imul($this.ya_1, value.ya_1), quotient_0) : Companion_getInstance_0().fc_1, !(remainder_0 == null) ? normalized(Companion_getInstance_0(), $this.ya_1, remainder_0) : Companion_getInstance_0().fc_1];
    }
    return tmp$ret$0;
  }
  function shiftPower($this, value, distance) {
    var tmp;
    if (distance > 0 && !(value.ya_1 === 0)) {
      // Inline function 'kotlin.Long.plus' call
      var this_0 = fromInt(magnitudeBits(value));
      var tmp$ret$0 = add(this_0, fromInt(distance));
      tmp = compare(tmp$ret$0, new Long(2147483647, 0)) > 0;
    } else {
      tmp = false;
    }
    if (tmp)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    return shiftLeftValue(value, distance);
  }
  function shiftLeftValue($this, n) {
    if ($this.ya_1 === 0)
      return Companion_getInstance_0().fc_1;
    if (n === 0)
      return $this;
    if (n < 0)
      return n === -2147483648 ? $this.ya_1 < 0 ? Companion_getInstance_0().gc_1.qc() : Companion_getInstance_0().fc_1 : shiftRightValue($this, -n | 0);
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(magnitudeBits($this));
    var tmp$ret$0 = add(this_0, fromInt(n));
    if (compare(tmp$ret$0, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    if ($this.bb_1 === 1 && n < 64) {
      var value = $this.cd();
      var shifted = shiftLeft(value, n);
      if (equalsLong(shiftRight(shifted, n), value))
        return compactResult529(Companion_getInstance_0(), shifted);
    }
    var words = materializeMagnitude($this);
    var whole = n / 30 | 0;
    var bits = n % 30 | 0;
    var result = new Int32Array((words.length + whole | 0) + 1 | 0);
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = words.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var v = bitwiseOr(shiftLeft(fromInt(words[i]), bits), carry);
        result[i + whole | 0] = convertToInt(bitwiseAnd(v, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(v, 30);
      }
       while (inductionVariable <= last);
    result[words.length + whole | 0] = convertToInt(carry);
    return normalized(Companion_getInstance_0(), $this.ya_1, result);
  }
  function shiftRightValue($this, n) {
    if ($this.ya_1 === 0)
      return Companion_getInstance_0().fc_1;
    if (n === 0)
      return $this;
    if (n < 0) {
      if (n === -2147483648)
        throw ArithmeticException_init_$Create$('BigInteger overflow');
      return shiftLeftValue($this, -n | 0);
    }
    if (n >= magnitudeBits($this))
      return $this.ya_1 < 0 ? Companion_getInstance_0().gc_1.qc() : Companion_getInstance_0().fc_1;
    if ($this.bb_1 === 1)
      return compactResult529(Companion_getInstance_0(), shiftRight($this.cd(), n));
    var words = materializeMagnitude($this);
    var whole = n / 30 | 0;
    var bits = n % 30 | 0;
    var result = new Int32Array(words.length - whole | 0);
    var inductionVariable = 0;
    var last = result.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var v = words[i + whole | 0] >>> bits | 0;
        if (!(bits === 0) && ((i + whole | 0) + 1 | 0) < words.length)
          v = v | words[(i + whole | 0) + 1 | 0] << (30 - bits | 0) & 1073741823;
        result[i] = v;
      }
       while (inductionVariable <= last);
    var truncated = normalized(Companion_getInstance_0(), $this.ya_1, result);
    return $this.ya_1 < 0 && lowestSetBitValue($this) < n ? truncated.yc(Companion_getInstance_0().gc_1) : truncated;
  }
  function magnitudeBits($this) {
    var tmp;
    if ($this.bb_1 === 1) {
      tmp = CompactInteger529_getInstance().ff($this.cd());
    } else {
      var tmp_0 = imul(ensureNotNull($this.cb_1).length - 1 | 0, 30) + 32 | 0;
      // Inline function 'kotlin.countLeadingZeroBits' call
      var this_0 = last($this.cb_1);
      tmp = tmp_0 - clz32(this_0) | 0;
    }
    return tmp;
  }
  function lowestSetBitValue($this) {
    if ($this.bb_1 === 1) {
      var value = $this.cd();
      return equalsLong(value, new Long(0, 0)) ? -1 : countTrailingZeroBits(value);
    }
    var words = materializeMagnitude($this);
    var inductionVariable = 0;
    var last = words.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(words[i] === 0))
          return imul(i, 30) + countTrailingZeroBits_0(words[i]) | 0;
      }
       while (inductionVariable <= last);
    return -1;
  }
  function firstNonzeroWord($this) {
    if ($this.bb_1 === 1)
      return countTrailingZeroBits($this.cd()) / 30 | 0;
    var words = materializeMagnitude($this);
    var first = 0;
    while (words[first] === 0) {
      first = first + 1 | 0;
    }
    return first;
  }
  function testBitValue($this, n) {
    if (n < 0)
      throw ArithmeticException_init_$Create$('Negative bit address');
    if ($this.bb_1 === 1)
      return n >= 64 ? $this.ya_1 < 0 : !equalsLong(bitwiseAnd($this.cd(), shiftLeft(new Long(1, 0), n)), new Long(0, 0));
    var words = materializeMagnitude($this);
    if (n < 0)
      throw ArithmeticException_init_$Create$('Negative bit address');
    var index = n / 30 | 0;
    // Inline function 'kotlin.collections.getOrElse' call
    var tmp;
    if (0 <= index ? index <= (words.length - 1 | 0) : false) {
      tmp = words[index];
    } else {
      tmp = 0;
    }
    var raw = tmp;
    var tmp_0;
    if ($this.ya_1 >= 0) {
      tmp_0 = raw;
    } else {
      var first = firstNonzeroWord($this);
      tmp_0 = index < first ? 0 : index === first ? -raw | 0 : ~raw;
    }
    var word = tmp_0;
    return !((word & 1 << (n % 30 | 0)) === 0);
  }
  function magnitudeWord32($this, index) {
    if ($this.bb_1 === 1) {
      var value = $this.cd();
      var magnitude = compare(value, new Long(0, 0)) < 0 ? negate(value) : value;
      return (0 <= index ? index <= 1 : false) ? bitwiseAnd(shiftRightUnsigned(magnitude, imul(index, 32)), new Long(-1, 0)) : new Long(0, 0);
    }
    var words = materializeMagnitude($this);
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(index);
    var start = multiply(this_0, fromInt(32));
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$1 = divide(start, fromInt(30));
    var word = convertToInt(tmp$ret$1);
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$2 = modulo(start, fromInt(30));
    var offset = convertToInt(tmp$ret$2);
    var chunk = shiftRightUnsigned(fromInt(words[word]), offset);
    if ((word + 1 | 0) < words.length)
      chunk = bitwiseOr(chunk, shiftLeft(fromInt(words[word + 1 | 0]), 30 - offset | 0));
    return bitwiseAnd(chunk, new Long(-1, 0));
  }
  function toPowerOfTwoString($this, radix, negative) {
    var words = materializeMagnitude($this);
    var bitsPerDigit;
    switch (radix) {
      case 2:
        bitsPerDigit = 1;
        break;
      case 4:
        bitsPerDigit = 2;
        break;
      case 8:
        bitsPerDigit = 3;
        break;
      case 16:
        bitsPerDigit = 4;
        break;
      default:
        bitsPerDigit = 5;
        break;
    }
    var top = last(words);
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(words.length - 1 | 0);
    var tmp0 = multiply(this_0, fromInt(30));
    // Inline function 'kotlin.countLeadingZeroBits' call
    // Inline function 'kotlin.Long.plus' call
    var other = 32 - clz32(top) | 0;
    var bitLength = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = bitsPerDigit;
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(bitLength, fromInt(other_0));
    var tmp0_0 = subtract(this_1, fromInt(1));
    // Inline function 'kotlin.Long.div' call
    var other_1 = bitsPerDigit;
    var digitCountLong = divide(tmp0_0, fromInt(other_1));
    // Inline function 'kotlin.Long.plus' call
    var other_2 = negative ? 1 : 0;
    var capacityLong = add(digitCountLong, fromInt(other_2));
    if (compare(capacityLong, new Long(2147483647, 0)) > 0) {
      plainStringTooLarge();
    }
    var digitCount = convertToInt(digitCountLong);
    // Inline function 'kotlin.Long.minus' call
    var this_2 = shiftLeft(new Long(1, 0), bitsPerDigit);
    var mask = subtract(this_2, fromInt(1));
    var text = StringBuilder_init_$Create$(convertToInt(capacityLong));
    if (negative) {
      text.y4(_Char___init__impl__6a9atx(45));
    }
    var inductionVariable = digitCount - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0_1 = fromInt(index);
        // Inline function 'kotlin.Long.times' call
        var other_3 = bitsPerDigit;
        var bit = multiply(tmp0_1, fromInt(other_3));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$9 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$9);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$10 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$10);
        var digit = shiftRightUnsigned(fromInt(words[word]), offset);
        if ((offset + bitsPerDigit | 0) > 30 && (word + 1 | 0) < words.length)
          digit = bitwiseOr(digit, shiftLeft(fromInt(words[word + 1 | 0]), 30 - offset | 0));
        text.y4(charCodeAt('0123456789abcdefghijklmnopqrstuvwxyz', convertToInt(bitwiseAnd(digit, mask))));
      }
       while (0 <= inductionVariable);
    return text.toString();
  }
  function divideDecimalChunk($this, magnitude, length, divisor) {
    var remainder = new Long(0, 0);
    var inductionVariable = length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = shiftLeft(remainder, 30);
        // Inline function 'kotlin.Long.plus' call
        var other = magnitude[i];
        var part = add(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$1 = divide(part, fromInt(divisor));
        magnitude[i] = convertToInt(tmp$ret$1);
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(divisor));
      }
       while (0 <= inductionVariable);
    return convertToInt(remainder);
  }
  function compareDecimalScratch($this, magnitude, length, other) {
    if (!(length === other.length))
      return compareTo(length, other.length);
    var inductionVariable = length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var order = compareTo(magnitude[i], other[i]);
        if (!(order === 0))
          return order;
      }
       while (0 <= inductionVariable);
    return 0;
  }
  function Companion_0() {
    Companion_instance_1 = this;
    this.cc_1 = new Long(-1455686883, -1929601249);
    this.dc_1 = 30;
    this.ec_1 = new Long(1073741823, 0);
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$0 = new Int32Array([]);
    tmp.fc_1 = BigInteger_init_$Create$_0(0, tmp$ret$0);
    var tmp_0 = this;
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$1 = new Int32Array([1]);
    tmp_0.gc_1 = BigInteger_init_$Create$_0(1, tmp$ret$1);
    var tmp_1 = this;
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$2 = new Int32Array([2]);
    tmp_1.hc_1 = BigInteger_init_$Create$_0(1, tmp$ret$2);
    var tmp_2 = this;
    // Inline function 'kotlin.intArrayOf' call
    var tmp$ret$3 = new Int32Array([10]);
    tmp_2.ic_1 = BigInteger_init_$Create$_0(1, tmp$ret$3);
    var tmp_3 = this;
    var tmp_4 = 0;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_5 = Array(33);
    while (tmp_4 < 33) {
      var tmp_6 = tmp_4;
      var value = tmp_6 - 16 | 0;
      var tmp_7;
      switch (value) {
        case 0:
          tmp_7 = Companion_getInstance_0().fc_1;
          break;
        case 1:
          tmp_7 = Companion_getInstance_0().gc_1;
          break;
        case 2:
          tmp_7 = Companion_getInstance_0().hc_1;
          break;
        case 10:
          tmp_7 = Companion_getInstance_0().ic_1;
          break;
        default:
          var tmp_8 = value < 0 ? -1 : 1;
          // Inline function 'kotlin.intArrayOf' call

          var tmp$ret$6 = new Int32Array([value < 0 ? -value | 0 : value]);
          tmp_7 = BigInteger_init_$Create$_0(tmp_8, tmp$ret$6);
          break;
      }
      tmp_5[tmp_6] = tmp_7;
      tmp_4 = tmp_4 + 1 | 0;
    }
    tmp_3.jc_1 = tmp_5;
    this.kc_1 = BigInteger_init_$Create$_1('3317044064679887385961981');
    var tmp_9 = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp_9.lc_1 = new Int32Array([2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41]);
  }
  protoOf(Companion_0).mc = function (value) {
    if (compare(new Long(-16, -1), value) <= 0 ? compare(value, new Long(16, 0)) <= 0 : false) {
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$0 = add(value, fromInt(16));
      return this.jc_1[convertToInt(tmp$ret$0)];
    }
    return BigInteger_init_$Create$(value);
  };
  protoOf(Companion_0).of = function (value, radix, maxDigits) {
    var power = radix;
    var width = 1;
    $l$loop: while (true) {
      // Inline function 'kotlin.Long.times' call
      var this_0 = fromInt(power);
      var tmp$ret$0 = multiply(this_0, fromInt(radix));
      if (!(compare(tmp$ret$0, new Long(2147483647, 0)) <= 0)) {
        break $l$loop;
      }
      power = imul(power, radix);
      width = width + 1 | 0;
    }
    var negative = compare(value, new Long(0, 0)) > 0 ? negate(value) : value;
    var chunks = new Int32Array(3);
    var size = 0;
    do {
      var _unary__edvuaz = size;
      size = _unary__edvuaz + 1 | 0;
      var tmp0 = negative;
      // Inline function 'kotlin.Long.rem' call
      var other = power;
      var tmp$ret$1 = modulo(tmp0, fromInt(other));
      chunks[_unary__edvuaz] = -convertToInt(tmp$ret$1) | 0;
      var tmp0_0 = negative;
      // Inline function 'kotlin.Long.div' call
      var other_0 = power;
      negative = divide(tmp0_0, fromInt(other_0));
    }
     while (!equalsLong(negative, new Long(0, 0)));
    var result = new RadixDigits537(chunks, size, radix, width);
    checkTextLimit537(result.vf_1, maxDigits);
    return result;
  };
  protoOf(Companion_0).wf = function (value, first, digits, sign, scale) {
    return decimalPrefixBuilder529(this, value, first, digits).if(sign, scale);
  };
  var Companion_instance_1;
  function Companion_getInstance_0() {
    if (Companion_instance_1 == null)
      new Companion_0();
    return Companion_instance_1;
  }
  function BigInteger(sign, compactHigh, compactLow, representation, wideWords) {
    Companion_getInstance_0();
    Number_0.call(this);
    this.ya_1 = sign;
    this.za_1 = compactHigh;
    this.ab_1 = compactLow;
    this.bb_1 = representation;
    this.cb_1 = wideWords;
  }
  protoOf(BigInteger).dd = function () {
    return this.bb_1 === 1;
  };
  protoOf(BigInteger).cd = function () {
    return CompactInteger529_getInstance().nd(this.za_1, this.ab_1);
  };
  protoOf(BigInteger).wc = function () {
    return this.ya_1;
  };
  protoOf(BigInteger).xc = function () {
    return this.ya_1 < 0 ? this.qc() : this;
  };
  protoOf(BigInteger).qc = function () {
    if (this.ya_1 === 0)
      return this;
    if (this.bb_1 === 1 && !equalsLong(this.cd(), new Long(0, -2147483648)))
      return BigInteger_init_$Create$(negate(this.cd()));
    return BigInteger_init_$Create$_0(-this.ya_1 | 0, materializeMagnitude(this));
  };
  protoOf(BigInteger).ad = function (value) {
    if (this.ya_1 === 0)
      return value;
    if (value.ya_1 === 0)
      return this;
    if (this.bb_1 === 1 && value.bb_1 === 1) {
      var a = this.cd();
      var b = value.cd();
      var result = add(a, b);
      if (CompactInteger529_getInstance().rd(a, b, result))
        return compactResult529(Companion_getInstance_0(), result);
      return overflowingCompactResult529(this, result, this.ya_1);
    }
    var tmp0_safe_receiver = compactCancellation529(this, value, false);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var words = materializeMagnitude(this);
    var valueWords = value === this ? words : materializeMagnitude(value);
    if (this.ya_1 === value.ya_1)
      return normalized(Companion_getInstance_0(), this.ya_1, addMagnitude(Companion_getInstance_0(), words, valueWords));
    var cmp = compareMagnitude_0(Companion_getInstance_0(), words, valueWords);
    return cmp === 0 ? Companion_getInstance_0().fc_1 : cmp > 0 ? normalized(Companion_getInstance_0(), this.ya_1, subtractMagnitude(Companion_getInstance_0(), words, valueWords)) : normalized(Companion_getInstance_0(), value.ya_1, subtractMagnitude(Companion_getInstance_0(), valueWords, words));
  };
  protoOf(BigInteger).yc = function (value) {
    if (value.ya_1 === 0)
      return this;
    if (this.ya_1 === 0)
      return value.qc();
    if (this.bb_1 === 1 && value.bb_1 === 1) {
      var a = this.cd();
      var b = value.cd();
      var result = subtract(a, b);
      if (CompactInteger529_getInstance().sd(a, b, result))
        return compactResult529(Companion_getInstance_0(), result);
      return overflowingCompactResult529(this, result, this.ya_1);
    }
    var tmp0_safe_receiver = compactCancellation529(this, value, true);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var words = materializeMagnitude(this);
    var valueWords = value === this ? words : materializeMagnitude(value);
    if (!(this.ya_1 === value.ya_1))
      return normalized(Companion_getInstance_0(), this.ya_1, addMagnitude(Companion_getInstance_0(), words, valueWords));
    var cmp = compareMagnitude_0(Companion_getInstance_0(), words, valueWords);
    return cmp === 0 ? Companion_getInstance_0().fc_1 : cmp > 0 ? normalized(Companion_getInstance_0(), this.ya_1, subtractMagnitude(Companion_getInstance_0(), words, valueWords)) : normalized(Companion_getInstance_0(), -this.ya_1 | 0, subtractMagnitude(Companion_getInstance_0(), valueWords, words));
  };
  protoOf(BigInteger).oc = function (value) {
    if (this.ya_1 === 0 || value.ya_1 === 0)
      return Companion_getInstance_0().fc_1;
    if (this.bb_1 === 1 && value.bb_1 === 1) {
      var a = this.cd();
      var b = value.cd();
      var result = multiply(a, b);
      if (CompactInteger529_getInstance().ud(a, b, result))
        return compactResult529(Companion_getInstance_0(), result);
    }
    if (this.bb_1 === 1 && value.bb_1 === 2 && magnitudeBits(this) <= 30) {
      MagnitudeMultiplication_getInstance().cg(magnitudeBits(this), magnitudeBits(value));
      var scalar = this.cd();
      var word = convertToInt(compare(scalar, new Long(0, 0)) < 0 ? negate(scalar) : scalar);
      return normalized(Companion_getInstance_0(), imul(this.ya_1, value.ya_1), MagnitudeMultiplication_getInstance().dg(word, ensureNotNull(value.cb_1)));
    }
    if (this.bb_1 === 2 && value.bb_1 === 1 && magnitudeBits(value) <= 30) {
      MagnitudeMultiplication_getInstance().cg(magnitudeBits(this), magnitudeBits(value));
      var scalar_0 = value.cd();
      var word_0 = convertToInt(compare(scalar_0, new Long(0, 0)) < 0 ? negate(scalar_0) : scalar_0);
      return normalized(Companion_getInstance_0(), imul(this.ya_1, value.ya_1), MagnitudeMultiplication_getInstance().dg(word_0, ensureNotNull(this.cb_1)));
    }
    var words = materializeMagnitude(this);
    var valueWords = value === this ? words : materializeMagnitude(value);
    MagnitudeMultiplication_getInstance().cg(magnitudeBits(this), magnitudeBits(value));
    return normalized(Companion_getInstance_0(), imul(this.ya_1, value.ya_1), MagnitudeMultiplication_getInstance().eg(words, valueWords));
  };
  protoOf(BigInteger).td = function (value, leftScale, rightScale, subtract, mc) {
    var tmp1_elvis_lhs = mc == null ? null : mc.vd_1;
    var precision = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    if (leftScale === rightScale && (precision === 0 || precision > 646456993))
      return null;
    var rightSign = subtract ? -value.ya_1 | 0 : value.ya_1;
    if (materializedDecimalSum585(this.ya_1, rightSign, magnitudeBits(this), magnitudeBits(value), leftScale, rightScale))
      return null;
    var leftDigits = this.ya_1 === 0 ? 0 : this.pd();
    var rightDigits = value.ya_1 === 0 ? 0 : value.pd();
    if (!certifiedDecimalSumSpan585(leftDigits, rightDigits, leftScale, rightScale, precision))
      return null;
    var words = materializeMagnitude(this);
    return DecimalSum585_getInstance().jg(this.ya_1, words, leftScale, rightSign, materializeMagnitude(value), rightScale, mc);
  };
  protoOf(BigInteger).ae = function (value) {
    return quotientStored(this, value);
  };
  protoOf(BigInteger).zd = function (value) {
    return remainderStored(this, value);
  };
  protoOf(BigInteger).vc = function (value) {
    return divideStored(this, value);
  };
  protoOf(BigInteger).nc = function (exponent) {
    if (exponent < 0)
      throw ArithmeticException_init_$Create$('Negative exponent');
    if (exponent === 0)
      return Companion_getInstance_0().gc_1;
    if (this.equals(Companion_getInstance_0().gc_1))
      return Companion_getInstance_0().gc_1;
    if (this.ya_1 === 0 || exponent === 1)
      return this;
    var absolute = this.xc();
    var twos = absolute.yd();
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(twos);
    var shift = multiply(this_0, fromInt(exponent));
    if (compare(shift, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    var part = absolute.kg(twos);
    var bits = part.lg();
    var negative = this.ya_1 < 0 && !((exponent & 1) === 0);
    if (bits === 1)
      return shiftPower(this, negative ? Companion_getInstance_0().mc(new Long(-1, -1)) : Companion_getInstance_0().gc_1, convertToInt(shift));
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(bits);
    // Inline function 'kotlin.Long.times' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = multiply(this_2, fromInt(exponent));
    if (compare(tmp$ret$2, new Long(2147483647, 0)) >= 0)
      throw ArithmeticException_init_$Create$('BigInteger would overflow supported range');
    // Inline function 'kotlin.Long.times' call
    var this_3 = fromInt(bits);
    var estimate = multiply(this_3, fromInt(exponent));
    if (compare(estimate, new Long(64, 0)) <= 0) {
      if (part.ya_1 === 0) {
        emptyPowMagnitude();
      }
      // Inline function 'kotlin.Long.plus' call
      var this_4 = fromInt(magnitudeBits(part));
      // Inline function 'kotlin.Long.div' call
      var this_5 = add(this_4, fromInt(31));
      var tmp$ret$5 = divide(this_5, fromInt(32));
      var count = convertToInt(tmp$ret$5);
      var factor = magnitudeWord32(part, count - 1 | 0);
      var e = equalsLong(factor, new Long(2, 0)) ? 0 : exponent;
      var product = equalsLong(factor, new Long(2, 0)) ? shiftLeft(new Long(1, 0), exponent) : new Long(1, 0);
      while (!(e === 0)) {
        if (!((e & 1) === 0))
          product = multiply(product, factor);
        e = e >>> 1 | 0;
        if (!(e === 0))
          factor = multiply(factor, factor);
      }
      var compactShift = compare(add(estimate, shift), new Long(64, 0)) <= 0;
      if (compactShift)
        product = shiftLeft(product, convertToInt(shift));
      // Inline function 'kotlin.toULong' call
      var this_6 = product;
      var magnitude = _ULong___init__impl__c78o9k(this_6);
      var packed = new Int32Array(3);
      var size = 0;
      while (!equals(new ULong(magnitude), new ULong(_ULong___init__impl__c78o9k(new Long(0, 0))))) {
        var _unary__edvuaz = size;
        size = _unary__edvuaz + 1 | 0;
        var tmp0 = magnitude;
        // Inline function 'kotlin.toULong' call
        var this_7 = new Long(1073741823, 0);
        // Inline function 'kotlin.ULong.and' call
        var other = _ULong___init__impl__c78o9k(this_7);
        // Inline function 'kotlin.ULong.toInt' call
        var this_8 = _ULong___init__impl__c78o9k(bitwiseAnd(_ULong___get_data__impl__fggpzb(tmp0), _ULong___get_data__impl__fggpzb(other)));
        packed[_unary__edvuaz] = convertToInt(_ULong___get_data__impl__fggpzb(this_8));
        // Inline function 'kotlin.ULong.shr' call
        var this_9 = magnitude;
        magnitude = _ULong___init__impl__c78o9k(shiftRightUnsigned(_ULong___get_data__impl__fggpzb(this_9), 30));
      }
      var tmp;
      if (size === 0) {
        // Inline function 'kotlin.intArrayOf' call
        var tmp$ret$11 = new Int32Array([]);
        tmp = BigInteger_init_$Create$_0(0, tmp$ret$11);
      } else {
        tmp = normalized(Companion_getInstance_0(), negative ? -1 : 1, packed);
      }
      var value = tmp;
      return compactShift ? value : shiftPower(this, value, convertToInt(shift));
    }
    var e_0 = exponent;
    var base = normalized(Companion_getInstance_0(), part.ya_1, materializeMagnitude(part));
    var result = Companion_getInstance_0().gc_1;
    while (!(e_0 === 0)) {
      if (!((e_0 & 1) === 0))
        result = result.oc(base);
      e_0 = e_0 >>> 1 | 0;
      if (!(e_0 === 0))
        base = base.oc(base);
    }
    return shiftPower(this, negative ? result.qc() : result, convertToInt(shift));
  };
  protoOf(BigInteger).pc = function (n) {
    return shiftLeftValue(this, n);
  };
  protoOf(BigInteger).kg = function (n) {
    return shiftRightValue(this, n);
  };
  protoOf(BigInteger).lg = function () {
    if (this.bb_1 === 1) {
      var value = this.cd();
      return 64 - countLeadingZeroBits(compare(value, new Long(0, 0)) < 0 ? invert(value) : value) | 0;
    }
    var words = materializeMagnitude(this);
    var bits = magnitudeBits(this);
    if (this.ya_1 >= 0 || !(countOneBits(last(words)) === 1))
      return bits;
    var inductionVariable = 0;
    var last_0 = get_lastIndex(words);
    if (inductionVariable < last_0)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(words[i] === 0))
          return bits;
      }
       while (inductionVariable < last_0);
    return bits - 1 | 0;
  };
  protoOf(BigInteger).yd = function () {
    return lowestSetBitValue(this);
  };
  protoOf(BigInteger).bd = function (n) {
    return testBitValue(this, n);
  };
  protoOf(BigInteger).zc = function (other) {
    if (this.bb_1 === 1 && other.bb_1 === 1) {
      var order = this.cd().d2(other.cd());
      return order < 0 ? -1 : order > 0 ? 1 : 0;
    }
    var words = materializeMagnitude(this);
    var operand = other;
    if (!(this.ya_1 === operand.ya_1))
      return this.ya_1 < operand.ya_1 ? -1 : 1;
    var magnitude = compareMagnitude_0(Companion_getInstance_0(), words, materializeMagnitude(operand));
    return magnitude < 0 ? -this.ya_1 | 0 : magnitude > 0 ? this.ya_1 : 0;
  };
  protoOf(BigInteger).o1 = function (other) {
    return this.zc(other instanceof BigInteger ? other : THROW_CCE());
  };
  protoOf(BigInteger).equals = function (other) {
    var tmp;
    var tmp_0;
    if (other instanceof BigInteger) {
      tmp_0 = this.ya_1 === other.ya_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.bb_1 === 1 ? other.bb_1 === 1 && this.za_1 === other.za_1 && this.ab_1 === other.ab_1 : other.bb_1 === 2 && contentEquals(ensureNotNull(this.cb_1), ensureNotNull(other.cb_1));
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(BigInteger).hashCode = function () {
    var hash = 0;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(magnitudeBits(this));
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(31));
    var tmp$ret$1 = divide(this_1, fromInt(32));
    var count = convertToInt(tmp$ret$1);
    var inductionVariable = count - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var chunk = magnitudeWord32(this, i);
        var tmp0 = new Long(31, 0);
        // Inline function 'kotlin.Long.times' call
        var other = hash;
        var tmp$ret$2 = multiply(tmp0, fromInt(other));
        hash = convertToInt(add(tmp$ret$2, chunk));
      }
       while (0 <= inductionVariable);
    return imul(hash, this.ya_1);
  };
  protoOf(BigInteger).toString = function () {
    return this.mg(10);
  };
  protoOf(BigInteger).mg = function (radix) {
    if (this.ya_1 === 0)
      return '0';
    var r = (2 <= radix ? radix <= 36 : false) ? radix : 10;
    var magnitude = this.xc();
    if ((2 <= radix ? radix <= 36 : false) && getKClassFromExpression(this).equals(getKClass(BigInteger)) && getKClassFromExpression(magnitude).equals(getKClass(BigInteger)) && magnitude.ya_1 > 0) {
      switch (r) {
        case 2:
        case 4:
        case 8:
        case 16:
        case 32:
          return toPowerOfTwoString(magnitude, r, this.ya_1 < 0);
      }
    }
    if (getKClassFromExpression(this).equals(getKClass(BigInteger)) && getKClassFromExpression(magnitude).equals(getKClass(BigInteger)) && magnitude.ya_1 > 0) {
      var digits = this.ng(r);
      var tmp0 = digits.vf_1;
      // Inline function 'kotlin.Long.plus' call
      var other = this.ya_1 < 0 ? 1 : 0;
      var length = add(tmp0, fromInt(other));
      if (compare(length, new Long(2147483647, 0)) > 0) {
        plainStringTooLarge();
      }
      // Inline function 'kotlin.text.buildString' call
      var capacity = convertToInt(length);
      // Inline function 'kotlin.apply' call
      var this_0 = StringBuilder_init_$Create$(capacity);
      var sink = new AppendableSink537(this_0);
      if (this.ya_1 < 0) {
        sink.pg(_Char___init__impl__6a9atx(45));
      }
      digits.qg(sink);
      return this_0.toString();
    }
    var divisor = Companion_getInstance_0().mc(fromInt(r));
    var text = StringBuilder_init_$Create$_0();
    var value = magnitude;
    while (!(value.ya_1 === 0)) {
      var qr = value.vc(divisor);
      text.y4(charCodeAt('0123456789abcdefghijklmnopqrstuvwxyz', qr[1].rg()));
      value = qr[0];
    }
    if (this.ya_1 < 0) {
      text.y4(_Char___init__impl__6a9atx(45));
    }
    return text.u().toString();
  };
  protoOf(BigInteger).sg = function (radix, maxDigits) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(2 <= radix ? radix <= 36 : false)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (this.bb_1 === 1)
      return Companion_getInstance_0().of(this.cd(), radix, maxDigits);
    var words = ensureNotNull(this.cb_1);
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_0 = radix - 1 | 0;
    var upperBits = 32 - clz32(this_0) | 0;
    var tmp;
    if (this.ya_1 === 0) {
      tmp = new Long(1, 0);
    } else {
      // Inline function 'kotlin.Long.div' call
      var this_1 = fromInt(magnitudeBits(this) - 1 | 0);
      // Inline function 'kotlin.Long.plus' call
      var this_2 = divide(this_1, fromInt(upperBits));
      tmp = add(this_2, fromInt(1));
    }
    var lowerDigits = tmp;
    checkTextLimit537(lowerDigits, maxDigits);
    if (this.ya_1 === 0) {
      // Inline function 'kotlin.intArrayOf' call
      var tmp$ret$6 = new Int32Array([0]);
      return new RadixDigits537(tmp$ret$6, 1, radix, 1);
    }
    var power = radix;
    var width = 1;
    $l$loop: while (true) {
      // Inline function 'kotlin.Long.times' call
      var this_3 = fromInt(power);
      var tmp$ret$7 = multiply(this_3, fromInt(radix));
      if (!(compare(tmp$ret$7, new Long(2147483647, 0)) <= 0)) {
        break $l$loop;
      }
      power = imul(power, radix);
      width = width + 1 | 0;
    }
    if ((radix & (radix - 1 | 0)) === 0) {
      var bitsPerDigit = countTrailingZeroBits_0(radix);
      var bitsPerChunk = imul(bitsPerDigit, width);
      var bitLength = fromInt(magnitudeBits(this));
      // Inline function 'kotlin.Long.plus' call
      // Inline function 'kotlin.Long.minus' call
      var this_4 = add(bitLength, fromInt(bitsPerDigit));
      // Inline function 'kotlin.Long.div' call
      var this_5 = subtract(this_4, fromInt(1));
      var digits = divide(this_5, fromInt(bitsPerDigit));
      checkTextLimit537(digits, maxDigits);
      // Inline function 'kotlin.Long.plus' call
      // Inline function 'kotlin.Long.minus' call
      var this_6 = add(bitLength, fromInt(bitsPerChunk));
      // Inline function 'kotlin.Long.div' call
      var this_7 = subtract(this_6, fromInt(1));
      var tmp$ret$13 = divide(this_7, fromInt(bitsPerChunk));
      var count = convertToInt(tmp$ret$13);
      var chunks = new Int32Array(count);
      var inductionVariable = 0;
      var last = chunks.length - 1 | 0;
      if (inductionVariable <= last)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          // Inline function 'kotlin.Long.times' call
          var this_8 = fromInt(index);
          var bit = multiply(this_8, fromInt(bitsPerChunk));
          // Inline function 'kotlin.Long.div' call
          var tmp$ret$15 = divide(bit, fromInt(30));
          var word = convertToInt(tmp$ret$15);
          // Inline function 'kotlin.Long.rem' call
          var tmp$ret$16 = modulo(bit, fromInt(30));
          var offset = convertToInt(tmp$ret$16);
          var chunk = shiftRightUnsigned(fromInt(words[word]), offset);
          if ((offset + bitsPerChunk | 0) > 30 && (word + 1 | 0) < words.length)
            chunk = bitwiseOr(chunk, shiftLeft(fromInt(words[word + 1 | 0]), 30 - offset | 0));
          chunks[index] = convertToInt(bitwiseAnd(chunk, fromInt(power - 1 | 0)));
        }
         while (inductionVariable <= last);
      return new RadixDigits537(chunks, count, radix, width);
    }
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var scratch = words.slice();
    var remaining = scratch.length;
    var chunks_0 = new Int32Array(4);
    var count_0 = 0;
    while (remaining > 0) {
      if (count_0 === chunks_0.length) {
        var tmp0 = new Long(2147483647, 0);
        // Inline function 'kotlin.Long.times' call
        var this_9 = fromInt(chunks_0.length);
        // Inline function 'kotlin.comparisons.minOf' call
        var b = multiply(this_9, fromInt(2));
        var tmp$ret$20 = compare(tmp0, b) <= 0 ? tmp0 : b;
        var next = convertToInt(tmp$ret$20);
        if (next === chunks_0.length) {
          plainStringTooLarge();
        }
        chunks_0 = copyOf(chunks_0, next);
      }
      var tmp_0 = chunks_0;
      var _unary__edvuaz = count_0;
      count_0 = _unary__edvuaz + 1 | 0;
      tmp_0[_unary__edvuaz] = divideDecimalChunk(this, scratch, remaining, power);
      while (remaining > 0 && scratch[remaining - 1 | 0] === 0) {
        remaining = remaining - 1 | 0;
      }
    }
    return new RadixDigits537(chunks_0, count_0, radix, width);
  };
  protoOf(BigInteger).ng = function (radix, maxDigits, $super) {
    maxDigits = maxDigits === VOID ? null : maxDigits;
    return $super === VOID ? this.sg(radix, maxDigits) : $super.sg.call(this, radix, maxDigits);
  };
  protoOf(BigInteger).db = function () {
    var length = (this.lg() / 8 | 0) + 1 | 0;
    var magnitude = this.ya_1 < 0 ? this.xc().yc(Companion_getInstance_0().gc_1) : this;
    var tmp = 0;
    var tmp_0 = new Int8Array(length);
    while (tmp < length) {
      var tmp_1 = tmp;
      var byte = 0;
      var inductionVariable = 0;
      if (inductionVariable <= 7)
        do {
          var b = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (magnitude.bd(imul((length - tmp_1 | 0) - 1 | 0, 8) + b | 0))
            byte = byte | 1 << b;
        }
         while (inductionVariable <= 7);
      tmp_0[tmp_1] = toByte(this.ya_1 < 0 ? ~byte : byte);
      tmp = tmp + 1 | 0;
    }
    return tmp_0;
  };
  protoOf(BigInteger).rg = function () {
    if (this.bb_1 === 1)
      return this.ab_1;
    var words = materializeMagnitude(this);
    // Inline function 'kotlin.collections.getOrElse' call
    var tmp;
    if (0 <= 0 ? 0 <= (words.length - 1 | 0) : false) {
      tmp = words[0];
    } else {
      tmp = 0;
    }
    var tmp_0 = tmp;
    // Inline function 'kotlin.collections.getOrElse' call
    var tmp_1;
    if (0 <= 1 ? 1 <= (words.length - 1 | 0) : false) {
      tmp_1 = words[1];
    } else {
      tmp_1 = 0;
    }
    var low = tmp_0 | tmp_1 << 30;
    return this.ya_1 < 0 ? -low | 0 : low;
  };
  protoOf(BigInteger).uc = function () {
    if (!(this.bb_1 === 1))
      return null;
    var value = this.cd();
    return equalsLong(value, new Long(0, -2147483648)) ? null : value;
  };
  protoOf(BigInteger).tg = function () {
    return this.ya_1 === 0 ? 1 : convertToInt(shiftRightUnsigned(multiply(fromInt(magnitudeBits(this) - 1 | 0), new Long(1292913986, 0)), 32)) + 1 | 0;
  };
  protoOf(BigInteger).pd = function () {
    if (this.bb_1 === 1)
      return CompactInteger529_getInstance().qd(this.cd());
    var words = materializeMagnitude(this);
    if (this.ya_1 === 0)
      return 1;
    var lower = this.tg();
    if (lower === 646456993)
      return lower;
    var tmp0_elvis_lhs = DecimalPowers597_getInstance().tc(lower);
    var threshold = tmp0_elvis_lhs == null ? Companion_getInstance_0().ic_1.nc(lower) : tmp0_elvis_lhs;
    return lower + (compareMagnitude_0(Companion_getInstance_0(), words, materializeMagnitude(threshold)) >= 0 ? 1 : 0) | 0;
  };
  protoOf(BigInteger).ce = function (other) {
    if (this.bb_1 === 1 && other.bb_1 === 1)
      return CompactInteger529_getInstance().be(this.cd(), other.cd());
    var words = materializeMagnitude(this);
    if (this.ya_1 === 0 || other.ya_1 === 0)
      return compareTo(this.ya_1 === 0 ? 0 : 1, other.ya_1 === 0 ? 0 : 1);
    var difference = this.pd() - other.pd() | 0;
    if (difference === 0)
      return compareMagnitude_0(Companion_getInstance_0(), words, materializeMagnitude(other));
    var longer = difference > 0 ? this : other;
    var shorter = difference > 0 ? other : this;
    // Inline function 'kotlin.collections.copyOf' call
    // Inline function 'kotlin.js.asDynamic' call
    var quotient = materializeMagnitude(longer).slice();
    var length = quotient.length;
    var drop = difference > 0 ? difference : -difference | 0;
    var sticky = false;
    while (drop >= 9) {
      var remainder = divideDecimalChunk(this, quotient, length, 1000000000);
      sticky = sticky || !(remainder === 0);
      while (length > 0 && quotient[length - 1 | 0] === 0) {
        length = length - 1 | 0;
      }
      drop = drop - 9 | 0;
    }
    if (drop > 0) {
      var divisor = 1;
      // Inline function 'kotlin.repeat' call
      var times = drop;
      var inductionVariable = 0;
      if (inductionVariable < times)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          divisor = imul(divisor, 10);
        }
         while (inductionVariable < times);
      var remainder_0 = divideDecimalChunk(this, quotient, length, divisor);
      sticky = sticky || !(remainder_0 === 0);
      while (length > 0 && quotient[length - 1 | 0] === 0) {
        length = length - 1 | 0;
      }
    }
    var quotientOrder = compareDecimalScratch(this, quotient, length, materializeMagnitude(shorter));
    var order = !(quotientOrder === 0) ? quotientOrder : sticky ? 1 : 0;
    return difference > 0 ? order : -order | 0;
  };
  function CompactInteger529() {
    CompactInteger529_instance = this;
    this.ld_1 = new Long(1073741823, 0);
    var tmp = this;
    // Inline function 'kotlin.run' call
    var power = {_v: new Long(-1, -1)};
    var tmp_0 = 0;
    var tmp_1 = longArray(19);
    while (tmp_0 < 19) {
      var tmp_2 = tmp_0;
      if (!(tmp_2 === 0)) {
        power._v = multiply(power._v, new Long(10, 0));
      }
      tmp_1[tmp_2] = power._v;
      tmp_0 = tmp_0 + 1 | 0;
    }
    tmp.md_1 = tmp_1;
  }
  protoOf(CompactInteger529).od = function (value) {
    return compare(value, new Long(0, 0)) < 0 ? -1 : compare(value, new Long(0, 0)) > 0 ? 1 : 0;
  };
  protoOf(CompactInteger529).nd = function (high, low) {
    return bitwiseOr(shiftLeft(fromInt(high), 32), bitwiseAnd(fromInt(low), new Long(-1, 0)));
  };
  protoOf(CompactInteger529).rd = function (a, b, result) {
    return compare(bitwiseAnd(bitwiseXor(a, result), bitwiseXor(b, result)), new Long(0, 0)) >= 0;
  };
  protoOf(CompactInteger529).sd = function (a, b, result) {
    return compare(bitwiseAnd(bitwiseXor(a, b), bitwiseXor(a, result)), new Long(0, 0)) >= 0;
  };
  protoOf(CompactInteger529).ud = function (a, b, result) {
    return equalsLong(a, new Long(0, 0)) || equalsLong(b, new Long(0, 0)) || ((!equalsLong(a, new Long(0, -2147483648)) || !equalsLong(b, new Long(-1, -1))) && (!equalsLong(b, new Long(0, -2147483648)) || !equalsLong(a, new Long(-1, -1))) && equalsLong(divide(result, a), b));
  };
  protoOf(CompactInteger529).de = function (exponent) {
    return negate(this.md_1[exponent]);
  };
  protoOf(CompactInteger529).qd = function (value) {
    var negative = compare(value, new Long(0, 0)) > 0 ? negate(value) : value;
    var lower = 1;
    var upper = 19;
    while (lower < upper) {
      var middle = (lower + upper | 0) >>> 1 | 0;
      if (compare(negative, this.md_1[middle]) > 0)
        upper = middle;
      else
        lower = middle + 1 | 0;
    }
    return lower;
  };
  protoOf(CompactInteger529).be = function (a, b) {
    return this.ug(a, b, this.qd(a), this.qd(b));
  };
  protoOf(CompactInteger529).ug = function (a, b, leftDigits, rightDigits) {
    var left = compare(a, new Long(0, 0)) > 0 ? negate(a) : a;
    var right = compare(b, new Long(0, 0)) > 0 ? negate(b) : b;
    var difference = leftDigits - rightDigits | 0;
    var sticky = false;
    if (difference > 0) {
      // Inline function 'kotlin.repeat' call
      var inductionVariable = 0;
      if (inductionVariable < difference)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var tmp;
          if (sticky) {
            tmp = true;
          } else {
            // Inline function 'kotlin.Long.rem' call
            var this_0 = left;
            var tmp$ret$2 = modulo(this_0, fromInt(10));
            tmp = !equalsLong(tmp$ret$2, new Long(0, 0));
          }
          sticky = tmp;
          // Inline function 'kotlin.Long.div' call
          var this_1 = left;
          left = divide(this_1, fromInt(10));
        }
         while (inductionVariable < difference);
    }
    if (difference < 0) {
      // Inline function 'kotlin.repeat' call
      var times = -difference | 0;
      var inductionVariable_0 = 0;
      if (inductionVariable_0 < times)
        do {
          var index_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          var tmp_0;
          if (sticky) {
            tmp_0 = true;
          } else {
            // Inline function 'kotlin.Long.rem' call
            var this_2 = right;
            var tmp$ret$6 = modulo(this_2, fromInt(10));
            tmp_0 = !equalsLong(tmp$ret$6, new Long(0, 0));
          }
          sticky = tmp_0;
          // Inline function 'kotlin.Long.div' call
          var this_3 = right;
          right = divide(this_3, fromInt(10));
        }
         while (inductionVariable_0 < times);
    }
    var order = right.d2(left);
    return !(order === 0) ? order : !sticky ? 0 : difference > 0 ? 1 : -1;
  };
  protoOf(CompactInteger529).ff = function (value) {
    var magnitude = compare(value, new Long(0, 0)) < 0 ? negate(value) : value;
    return 64 - countLeadingZeroBits(magnitude) | 0;
  };
  protoOf(CompactInteger529).mf = function (sign, words) {
    return words.length < 3 || (words.length === 3 && (words[2] < 8 || (sign < 0 && words[2] === 8 && words[1] === 0 && words[0] === 0)));
  };
  protoOf(CompactInteger529).lf = function (sign, words) {
    var magnitude = new Long(0, 0);
    var inductionVariable = words.length - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        magnitude = bitwiseOr(shiftLeft(magnitude, 30), fromInt(words[i]));
      }
       while (0 <= inductionVariable);
    return sign < 0 ? negate(magnitude) : magnitude;
  };
  protoOf(CompactInteger529).nf = function (high, low, index) {
    var negative = high < 0;
    var lo = negative ? -low | 0 : low;
    var hi = negative ? ~high + (low === 0 ? 1 : 0) | 0 : high;
    switch (index) {
      case 0:
        return lo & 1073741823;
      case 1:
        return (lo >>> 30 | 0 | hi << 2) & 1073741823;
      case 2:
        return hi >>> 28 | 0;
      default:
        return 0;
    }
  };
  protoOf(CompactInteger529).gf = function (high, low) {
    var bits = this.ff(this.nd(high, low));
    var tmp = 0;
    var tmp_0 = (bits + 29 | 0) / 30 | 0;
    var tmp_1 = new Int32Array(tmp_0);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      tmp_1[tmp_2] = CompactInteger529_getInstance().nf(high, low, tmp_2);
      tmp = tmp + 1 | 0;
    }
    return tmp_1;
  };
  var CompactInteger529_instance;
  function CompactInteger529_getInstance() {
    if (CompactInteger529_instance == null)
      new CompactInteger529();
    return CompactInteger529_instance;
  }
  function DecimalPowers597() {
    DecimalPowers597_instance = this;
    this.rc_1 = 128;
    var tmp = this;
    // Inline function 'kotlin.run' call
    var value = {_v: Companion_getInstance_0().gc_1};
    var tmp_0 = 0;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(129);
    while (tmp_0 < 129) {
      var tmp_2 = tmp_0;
      if (!(tmp_2 === 0)) {
        value._v = value._v.oc(Companion_getInstance_0().ic_1);
      }
      tmp_1[tmp_2] = value._v;
      tmp_0 = tmp_0 + 1 | 0;
    }
    tmp.sc_1 = tmp_1;
  }
  protoOf(DecimalPowers597).tc = function (exponent) {
    return (0 <= exponent ? exponent <= 128 : false) ? this.sc_1[exponent] : null;
  };
  var DecimalPowers597_instance;
  function DecimalPowers597_getInstance() {
    if (DecimalPowers597_instance == null)
      new DecimalPowers597();
    return DecimalPowers597_instance;
  }
  function materializedDecimalSum585(leftSign, rightSign, leftBits, rightBits, leftScale, rightScale) {
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$0 = Math.max(leftScale, rightScale);
    var scale = fromInt(tmp$ret$0);
    var limit = !(leftSign === 0) && leftSign === rightSign ? new Long(2147483646, 0) : new Long(2147483647, 0);
    return materializedDecimalSum585$supported(scale, limit, leftSign, leftBits, leftScale) && materializedDecimalSum585$supported(scale, limit, rightSign, rightBits, rightScale);
  }
  function certifiedDecimalSumSpan585(leftDigits, rightDigits, leftScale, rightScale, precision) {
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$0 = Math.max(leftScale, rightScale);
    var scale = fromInt(tmp$ret$0);
    var tmp;
    if (leftDigits === 0) {
      tmp = new Long(0, 0);
    } else {
      // Inline function 'kotlin.Long.minus' call
      var this_0 = add(fromInt(leftDigits), scale);
      tmp = subtract(this_0, fromInt(leftScale));
    }
    var left = tmp;
    var tmp_0;
    if (rightDigits === 0) {
      tmp_0 = new Long(0, 0);
    } else {
      // Inline function 'kotlin.Long.minus' call
      var this_1 = add(fromInt(rightDigits), scale);
      tmp_0 = subtract(this_1, fromInt(rightScale));
    }
    var right = tmp_0;
    // Inline function 'kotlin.comparisons.maxOf' call
    var largest = compare(left, right) >= 0 ? left : right;
    return precision === 0 || precision > 646456993 ? compare(largest, new Long(646456994, 0)) <= 0 : compare(largest, new Long(1292913989, 0)) <= 0;
  }
  function decimal($this, words, scratch) {
    // Inline function 'kotlin.collections.isEmpty' call
    if (words.length === 0)
      return new Digits(0);
    var inductionVariable = 0;
    var last = words.length - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        scratch.xg(i, words[i]);
      }
       while (inductionVariable <= last);
    var size = words.length;
    var tmp0 = new Long(646456993, 0);
    var tmp0_0 = new Long(10, 0);
    // Inline function 'kotlin.Long.times' call
    var other = words.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(tmp0_0, fromInt(other));
    var bound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bound, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = divide(this_0, fromInt(9));
    var tmp$ret$5 = add(this_1, fromInt(1));
    var result = new Digits(convertToInt(tmp$ret$5));
    while (size > 0) {
      var remainder = new Long(0, 0);
      var inductionVariable_0 = size - 1 | 0;
      if (0 <= inductionVariable_0)
        do {
          var i_0 = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0 + -1 | 0;
          var tmp0_1 = shiftLeft(remainder, 30);
          // Inline function 'kotlin.Long.plus' call
          var other_0 = scratch.n(i_0);
          var part = add(tmp0_1, fromInt(other_0));
          // Inline function 'kotlin.Long.div' call
          var other_1 = 1000000000;
          var tmp$ret$7 = divide(part, fromInt(other_1));
          scratch.xg(i_0, convertToInt(tmp$ret$7));
          // Inline function 'kotlin.Long.rem' call
          var other_2 = 1000000000;
          remainder = modulo(part, fromInt(other_2));
        }
         while (0 <= inductionVariable_0);
      result.xg(result.zg_1, convertToInt(remainder));
      result.zg_1 = result.zg_1 + 1 | 0;
      while (size > 0 && scratch.n(size - 1 | 0) === 0) {
        size = size - 1 | 0;
      }
    }
    return result;
  }
  function aligned($this, value, raise) {
    if (value.zg_1 === 0)
      return new View(value, new Long(0, 0));
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$0 = modulo(raise, fromInt(9));
    var factor = $this.ig_1[convertToInt(tmp$ret$0)];
    var carry = new Long(0, 0);
    var oldSize = value.zg_1;
    var inductionVariable = 0;
    if (inductionVariable < oldSize)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = fromInt(value.n(i));
        var tmp$ret$1 = multiply(this_0, fromInt(factor));
        var part = add(tmp$ret$1, carry);
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        var tmp$ret$2 = modulo(part, fromInt(other));
        value.xg(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.div' call
        var other_0 = 1000000000;
        carry = divide(part, fromInt(other_0));
      }
       while (inductionVariable < oldSize);
    if (!equalsLong(carry, new Long(0, 0))) {
      value.xg(oldSize, convertToInt(carry));
      value.zg_1 = value.zg_1 + 1 | 0;
    }
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$4 = divide(raise, fromInt(9));
    return new View(value, tmp$ret$4);
  }
  function View(value, offset) {
    this.ah_1 = value;
    this.bh_1 = offset;
  }
  protoOf(View).ch = function () {
    var tmp;
    if (this.ah_1.zg_1 === 0) {
      tmp = new Long(0, 0);
    } else {
      var tmp0 = this.bh_1;
      // Inline function 'kotlin.Long.plus' call
      var other = this.ah_1.zg_1;
      tmp = add(tmp0, fromInt(other));
    }
    return tmp;
  };
  protoOf(View).dh = function (at) {
    return !(this.ah_1.zg_1 === 0) && compare(at, this.bh_1) >= 0 && compare(at, this.ch()) < 0;
  };
  protoOf(View).eh = function (at) {
    return this.dh(at) ? this.ah_1.n(convertToInt(subtract(at, this.bh_1))) : 0;
  };
  protoOf(View).fh = function (at, limit) {
    var tmp;
    if (!(this.ah_1.zg_1 === 0) && compare(at, this.bh_1) < 0) {
      // Inline function 'kotlin.comparisons.minOf' call
      var a = this.bh_1;
      tmp = compare(a, limit) <= 0 ? a : limit;
    } else {
      tmp = limit;
    }
    return tmp;
  };
  protoOf(View).gh = function () {
    return this.ah_1.zg_1 === 0 ? new Long(0, 0) : add(multiply(new Long(9, 0), this.bh_1), this.ah_1.gh());
  };
  function compare_0($this, a, b) {
    var order = a.gh().d2(b.gh());
    if (!(order === 0))
      return order;
    var tmp0 = a.ch();
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_0 = b.ch();
    var at = compare(tmp0, b_0) >= 0 ? tmp0 : b_0;
    while (compare(at, new Long(0, 0)) > 0) {
      var _unary__edvuaz = at;
      at = subtract(_unary__edvuaz, get_ONE());
      var cell = compareTo(a.eh(at), b.eh(at));
      if (!(cell === 0))
        return cell;
    }
    return 0;
  }
  function publish($this, decimal, sign, scale) {
    if (compare(decimal.gh(), new Long(646456993, 0)) > 0)
      return null;
    var tmp0 = new Long(2147483647, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(new Long(4, 0), decimal.gh());
    var bound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bound, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = divide(this_0, fromInt(30));
    var tmp$ret$3 = add(this_1, fromInt(1));
    var binary = new Cells(convertToInt(tmp$ret$3));
    var size = 0;
    var inductionVariable = decimal.zg_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var carry = fromInt(decimal.n(i));
        var j = 0;
        while (j < size) {
          var tmp0_0 = fromInt(binary.n(j));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$4 = multiply(tmp0_0, fromInt(other));
          var part = add(tmp$ret$4, carry);
          binary.xg(j, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
          j = j + 1 | 0;
        }
        if (!equalsLong(carry, new Long(0, 0))) {
          var _unary__edvuaz = size;
          size = _unary__edvuaz + 1 | 0;
          binary.xg(_unary__edvuaz, convertToInt(carry));
        }
        var tmp0_1 = new Long(30, 0);
        // Inline function 'kotlin.Long.times' call
        var other_0 = size - 1 | 0;
        // Inline function 'kotlin.Long.plus' call
        var this_2 = multiply(tmp0_1, fromInt(other_0));
        var tmp0_2 = add(this_2, fromInt(32));
        // Inline function 'kotlin.countLeadingZeroBits' call
        var this_3 = binary.n(size - 1 | 0);
        // Inline function 'kotlin.Long.minus' call
        var other_1 = clz32(this_3);
        var bits = subtract(tmp0_2, fromInt(other_1));
        if (compare(bits, new Long(2147483647, 0)) > 0)
          return null;
      }
       while (0 <= inductionVariable);
    var tmp0_3 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_4 = multiply(tmp0_3, fromInt(other_2));
    var tmp0_4 = add(this_4, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_5 = binary.n(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_5);
    var bits_0 = subtract(tmp0_4, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_6 = add(bits_0, fromInt(7));
    var tmp$ret$14 = divide(this_6, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$14));
    var inductionVariable_0 = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_7 = new Long(8, 0);
        var bit = multiply(this_7, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$16 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$16);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$17 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$17);
        var value = shiftRightUnsigned(fromInt(binary.n(word)), offset);
        if (offset > 22 && (word + 1 | 0) < size)
          value = bitwiseOr(value, shiftLeft(fromInt(binary.n(word + 1 | 0)), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last);
    return to(BigInteger_init_$Create$_3(sign, bytes), scale);
  }
  function Cells(capacity) {
    this.vg_1 = capacity;
    var tmp = this;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(this.vg_1);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(8192));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = divide(this_2, fromInt(8192));
    // Inline function 'kotlin.arrayOfNulls' call
    var size = convertToInt(tmp$ret$2);
    tmp.wg_1 = Array(size);
  }
  protoOf(Cells).n = function (index) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.vg_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tmp0_safe_receiver = this.wg_1[index / 8192 | 0];
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver[index % 8192 | 0];
    return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  };
  protoOf(Cells).xg = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.vg_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var slot = index / 8192 | 0;
    var page = this.wg_1[slot];
    if (page == null) {
      if (value === 0)
        return Unit_instance;
      // Inline function 'kotlin.Long.times' call
      var this_0 = fromInt(slot);
      var start = multiply(this_0, fromInt(8192));
      var tmp0 = new Long(8192, 0);
      // Inline function 'kotlin.comparisons.minOf' call
      var b = subtract(fromInt(this.vg_1), start);
      var tmp$ret$2 = compare(tmp0, b) <= 0 ? tmp0 : b;
      page = new Int32Array(convertToInt(tmp$ret$2));
      this.wg_1[slot] = page;
    }
    page[index % 8192 | 0] = value;
  };
  protoOf(Cells).hh = function (end) {
    var start = new Long(0, 0);
    var indexedObject = this.wg_1;
    var inductionVariable = 0;
    var last = indexedObject.length;
    $l$loop: while (inductionVariable < last) {
      var page = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (compare(start, fromInt(end)) >= 0)
        break $l$loop;
      if (!(page == null)) {
        var tmp0 = fromInt(page.length);
        // Inline function 'kotlin.comparisons.minOf' call
        var b = subtract(fromInt(end), start);
        var tmp$ret$0 = compare(tmp0, b) <= 0 ? tmp0 : b;
        var count = convertToInt(tmp$ret$0);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < count)
          do {
            var i = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            if (!(page[i] === 0))
              return true;
          }
           while (inductionVariable_0 < count);
      }
      // Inline function 'kotlin.Long.plus' call
      var this_0 = start;
      start = add(this_0, fromInt(8192));
    }
    return false;
  };
  function Digits(capacity) {
    this.yg_1 = new Cells(capacity);
    this.zg_1 = 0;
  }
  protoOf(Digits).n = function (index) {
    return this.yg_1.n(index);
  };
  protoOf(Digits).xg = function (index, value) {
    this.yg_1.xg(index, value);
  };
  protoOf(Digits).ih = function (start, end, value) {
    var inductionVariable = start;
    if (inductionVariable < end)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.yg_1.xg(i, value);
      }
       while (inductionVariable < end);
  };
  protoOf(Digits).jh = function () {
    while (this.zg_1 > 0 && this.yg_1.n(this.zg_1 - 1 | 0) === 0) {
      this.zg_1 = this.zg_1 - 1 | 0;
    }
  };
  protoOf(Digits).gh = function () {
    // Inline function 'kotlin.check' call
    if (!(this.zg_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var width = 1;
    while (width < 9 && this.yg_1.n(this.zg_1 - 1 | 0) >= DecimalSum585_getInstance().ig_1[width]) {
      width = width + 1 | 0;
    }
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.zg_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = width;
    return add(tmp0_0, fromInt(other_0));
  };
  protoOf(Digits).hh = function (end) {
    return this.yg_1.hh(end);
  };
  protoOf(Digits).kh = function (whole, divisor) {
    var result = new Digits((this.zg_1 - whole | 0) + 1 | 0);
    var remainder = new Long(0, 0);
    var inductionVariable = this.zg_1 - 1 | 0;
    if (whole <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.yg_1.n(i);
        var part = add(tmp0_0, fromInt(other_0));
        var tmp = i - whole | 0;
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(divisor));
        result.xg(tmp, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(divisor));
      }
       while (!(i === whole));
    result.zg_1 = this.zg_1 - whole | 0;
    result.jh();
    return result;
  };
  protoOf(Digits).lh = function () {
    var at = 0;
    while (at < this.zg_1 && this.yg_1.n(at) === 999999999) {
      this.yg_1.xg(at, 0);
      at = at + 1 | 0;
    }
    this.yg_1.xg(at, at === this.zg_1 ? 1 : this.yg_1.n(at) + 1 | 0);
    if (at === this.zg_1) {
      this.zg_1 = this.zg_1 + 1 | 0;
    }
  };
  protoOf(Digits).mh = function () {
    var remainder = new Long(0, 0);
    var inductionVariable = this.zg_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.yg_1.n(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(10));
        this.yg_1.xg(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(10));
      }
       while (0 <= inductionVariable);
    this.jh();
    return convertToInt(remainder);
  };
  function DecimalSum585() {
    DecimalSum585_instance = this;
    this.fg_1 = 1000000000;
    this.gg_1 = 8192;
    this.hg_1 = new Long(646456993, 0);
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.ig_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalSum585).jg = function (leftSign, left, leftScale, rightSign, right, rightScale, context) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!((-1 <= leftSign ? leftSign <= 1 : false) && (-1 <= rightSign ? rightSign <= 1 : false))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    var tmp_0 = leftSign === 0;
    // Inline function 'kotlin.collections.isEmpty' call
    if (tmp_0 === (left.length === 0)) {
      var tmp_1 = rightSign === 0;
      // Inline function 'kotlin.collections.isEmpty' call
      tmp = tmp_1 === (right.length === 0);
    } else {
      tmp = false;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message_0));
    }
    // Inline function 'kotlin.comparisons.maxOf' call
    var scale = Math.max(leftScale, rightScale);
    var tmp1_elvis_lhs = context == null ? null : context.vd_1;
    var precision = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    var tmp0 = left.length;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = right.length;
    var tmp$ret$9 = Math.max(tmp0, b);
    var scratch = new Cells(tmp$ret$9);
    var a = decimal(this, left, scratch);
    var b_0 = decimal(this, right, scratch);
    var da = a.zg_1 === 0 ? 0 : convertToInt(a.gh());
    var db = b_0.zg_1 === 0 ? 0 : convertToInt(b_0.gh());
    if (!certifiedDecimalSumSpan585(da, db, leftScale, rightScale, precision))
      return null;
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(scale);
    var tmp$ret$10 = subtract(this_0, fromInt(leftScale));
    var av = aligned(this, a, tmp$ret$10);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = fromInt(scale);
    var tmp$ret$11 = subtract(this_1, fromInt(rightScale));
    var bv = aligned(this, b_0, tmp$ret$11);
    var order = compare_0(this, av, bv);
    if (!(leftSign === rightSign) && order === 0 || (leftSign === 0 && rightSign === 0))
      return to(Companion_getInstance_0().fc_1, scale);
    var subtract_0 = !(leftSign === 0) && !(rightSign === 0) && !(leftSign === rightSign);
    var high = subtract_0 && order < 0 ? bv : av;
    var low = subtract_0 && order < 0 ? av : bv;
    var sign = leftSign === 0 || (subtract_0 && order < 0) ? rightSign : leftSign;
    var tmp0_0 = high.ch();
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_1 = low.ch();
    var end = compare(tmp0_0, b_1) >= 0 ? tmp0_0 : b_1;
    var result = new Digits(convertToInt(add(end, new Long(1, 0))));
    var at = new Long(0, 0);
    var carry = 0;
    $l$loop: while (compare(at, end) < 0) {
      if (!high.dh(at) && !low.dh(at)) {
        var tmp0_1 = high.fh(at, end);
        // Inline function 'kotlin.comparisons.minOf' call
        var b_2 = low.fh(at, end);
        var next = compare(tmp0_1, b_2) <= 0 ? tmp0_1 : b_2;
        // Inline function 'kotlin.check' call
        if (!(compare(next, at) > 0)) {
          throw IllegalStateException_init_$Create$('Check failed.');
        }
        if (subtract_0) {
          if (!(carry === 0)) {
            result.ih(convertToInt(at), convertToInt(next), 999999999);
          }
        } else if (!(carry === 0)) {
          result.xg(convertToInt(at), 1);
          carry = 0;
        }
        at = next;
        continue $l$loop;
      }
      var h = high.eh(at);
      var l = low.eh(at);
      if (subtract_0) {
        // Inline function 'kotlin.Long.minus' call
        var this_2 = fromInt(h);
        var tmp0_2 = subtract(this_2, fromInt(l));
        // Inline function 'kotlin.Long.minus' call
        var other = carry;
        var part = subtract(tmp0_2, fromInt(other));
        var tmp_2 = convertToInt(at);
        var tmp_3;
        if (compare(part, new Long(0, 0)) < 0) {
          // Inline function 'kotlin.Long.plus' call
          var other_0 = 1000000000;
          tmp_3 = add(part, fromInt(other_0));
        } else {
          tmp_3 = part;
        }
        result.xg(tmp_2, convertToInt(tmp_3));
        carry = compare(part, new Long(0, 0)) < 0 ? 1 : 0;
      } else {
        // Inline function 'kotlin.Long.plus' call
        var this_3 = fromInt(h);
        var tmp0_3 = add(this_3, fromInt(l));
        // Inline function 'kotlin.Long.plus' call
        var other_1 = carry;
        var part_0 = add(tmp0_3, fromInt(other_1));
        var tmp_4 = convertToInt(at);
        // Inline function 'kotlin.Long.rem' call
        var other_2 = 1000000000;
        var tmp$ret$20 = modulo(part_0, fromInt(other_2));
        result.xg(tmp_4, convertToInt(tmp$ret$20));
        // Inline function 'kotlin.Long.div' call
        var other_3 = 1000000000;
        var tmp$ret$21 = divide(part_0, fromInt(other_3));
        carry = convertToInt(tmp$ret$21);
      }
      var _unary__edvuaz = at;
      at = add(_unary__edvuaz, get_ONE());
    }
    if (subtract_0) {
      // Inline function 'kotlin.check' call
      if (!(carry === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
    } else if (!(carry === 0)) {
      result.xg(convertToInt(end), carry);
    }
    result.zg_1 = convertToInt(end) + (!subtract_0 && !(carry === 0) ? 1 : 0) | 0;
    result.jh();
    if (result.zg_1 === 0)
      return to(Companion_getInstance_0().fc_1, scale);
    var digits = result.gh();
    if (precision === 0 || compare(digits, fromInt(precision)) <= 0)
      return publish(this, result, sign, scale);
    if (compare(fromInt(precision), new Long(646456993, 0)) > 0)
      return null;
    // Inline function 'kotlin.Long.minus' call
    var drop = subtract(digits, fromInt(precision));
    // Inline function 'kotlin.Long.div' call
    var tmp$ret$24 = divide(drop, fromInt(9));
    var whole = convertToInt(tmp$ret$24);
    // Inline function 'kotlin.Long.rem' call
    var tmp$ret$25 = modulo(drop, fromInt(9));
    var tail = convertToInt(tmp$ret$25);
    var guardCell = tail === 0 ? whole - 1 | 0 : whole;
    var guardPlace = tail === 0 ? 8 : tail - 1 | 0;
    var guard = (result.n(guardCell) / this.ig_1[guardPlace] | 0) % 10 | 0;
    var sticky = !((result.n(guardCell) % this.ig_1[guardPlace] | 0) === 0) || result.hh(guardCell);
    var inexact = !(guard === 0) || sticky;
    // Inline function 'kotlin.checkNotNull' call
    var tmp$ret$27;
    $l$block: {
      // Inline function 'kotlin.checkNotNull' call
      if (context == null) {
        var message_1 = 'Required value was null.';
        throw IllegalStateException_init_$Create$(toString_0(message_1));
      } else {
        tmp$ret$27 = context;
        break $l$block;
      }
    }
    var mode = tmp$ret$27.wd_1;
    if (inexact && mode.equals(RoundingMode_UNNECESSARY_getInstance()))
      return null;
    var quotient = result.kh(whole, this.ig_1[tail]);
    var half = guard === 5 && sticky ? 1 : compareTo(guard, 5);
    var tmp_5;
    if (inexact) {
      var tmp_6;
      switch (mode.v1_1) {
        case 0:
          tmp_6 = true;
          break;
        case 1:
          tmp_6 = false;
          break;
        case 2:
          tmp_6 = sign > 0;
          break;
        case 3:
          tmp_6 = sign < 0;
          break;
        case 4:
          tmp_6 = half >= 0;
          break;
        case 5:
          tmp_6 = half > 0;
          break;
        case 6:
          tmp_6 = half > 0 || (half === 0 && !((quotient.n(0) % 2 | 0) === 0));
          break;
        case 7:
          tmp_6 = false;
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
      tmp_5 = tmp_6;
    } else {
      tmp_5 = false;
    }
    var increment = tmp_5;
    if (increment) {
      quotient.lh();
    }
    var finalScale = subtract(fromInt(scale), drop);
    if (compare(quotient.gh(), fromInt(precision)) > 0) {
      // Inline function 'kotlin.check' call
      if (!(quotient.mh() === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      var _unary__edvuaz_0 = finalScale;
      finalScale = subtract(_unary__edvuaz_0, get_ONE());
    }
    if (!(compare(new Long(-2147483648, -1), finalScale) <= 0 ? compare(finalScale, new Long(2147483647, 0)) <= 0 : false))
      return null;
    return publish(this, quotient, sign, convertToInt(finalScale));
  };
  var DecimalSum585_instance;
  function DecimalSum585_getInstance() {
    if (DecimalSum585_instance == null)
      new DecimalSum585();
    return DecimalSum585_instance;
  }
  function materializedDecimalSum585$supported(scale, limit, sign, bits, sourceScale) {
    if (sign === 0)
      return true;
    // Inline function 'kotlin.Long.minus' call
    var raise = subtract(scale, fromInt(sourceScale));
    return (compare(new Long(0, 0), raise) <= 0 ? compare(raise, new Long(646456992, 0)) <= 0 : false) && compare(add(fromInt(bits), multiply(new Long(4, 0), raise)), limit) <= 0;
  }
  function Lexical(sign, scale, first, digits, guard, sticky) {
    this.nh_1 = sign;
    this.oh_1 = scale;
    this.ph_1 = first;
    this.qh_1 = digits;
    this.rh_1 = guard;
    this.sh_1 = sticky;
  }
  function scan($this, input, precision) {
    if (input.ve_1 === 0)
      throw NumberFormatException_init_$Create$('Empty BigDecimal');
    var i = 0;
    var sign = 1;
    if (input.b(i) === _Char___init__impl__6a9atx(45) || input.b(i) === _Char___init__impl__6a9atx(43)) {
      if (input.b(i) === _Char___init__impl__6a9atx(45))
        sign = -1;
      i = i + 1 | 0;
    }
    var seenDigit = false;
    var point = false;
    var fraction = new Long(0, 0);
    var first = -1;
    var digits = new Long(0, 0);
    var guard = 0;
    var sticky = false;
    var guardOrdinal = add(fromInt(precision), new Long(1, 0));
    $l$loop: while (i < input.ve_1 && !(input.b(i) === _Char___init__impl__6a9atx(101)) && !(input.b(i) === _Char___init__impl__6a9atx(69))) {
      var at = i;
      var _unary__edvuaz = i;
      i = _unary__edvuaz + 1 | 0;
      var c = input.b(_unary__edvuaz);
      if (c === _Char___init__impl__6a9atx(46) && !point) {
        point = true;
        continue $l$loop;
      }
      var tmp0_elvis_lhs = numericDigit537(c, 10);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        throw NumberFormatException_init_$Create$('Invalid decimal digit');
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var digit = tmp;
      seenDigit = true;
      if (point) {
        var _unary__edvuaz_0 = fraction;
        fraction = add(_unary__edvuaz_0, get_ONE());
      }
      if (first < 0 && !(digit === 0))
        first = at;
      if (first >= 0) {
        var _unary__edvuaz_1 = digits;
        digits = add(_unary__edvuaz_1, get_ONE());
        if (precision > 0) {
          if (equalsLong(digits, guardOrdinal))
            guard = digit;
          else if (compare(digits, guardOrdinal) > 0 && !(digit === 0))
            sticky = true;
        }
      }
    }
    if (!seenDigit)
      throw NumberFormatException_init_$Create$('No digits');
    var exponent = new Long(0, 0);
    if (i < input.ve_1) {
      i = i + 1 | 0;
      var exponentSign = 1;
      if (i < input.ve_1 && (input.b(i) === _Char___init__impl__6a9atx(43) || input.b(i) === _Char___init__impl__6a9atx(45))) {
        if (input.b(i) === _Char___init__impl__6a9atx(45))
          exponentSign = -1;
        i = i + 1 | 0;
      }
      if (i === input.ve_1)
        throw NumberFormatException_init_$Create$('No exponent digits');
      while (i < input.ve_1) {
        var _unary__edvuaz_2 = i;
        i = _unary__edvuaz_2 + 1 | 0;
        var tmp1_elvis_lhs = numericDigit537(input.b(_unary__edvuaz_2), 10);
        var tmp_0;
        if (tmp1_elvis_lhs == null) {
          throw NumberFormatException_init_$Create$('Invalid exponent');
        } else {
          tmp_0 = tmp1_elvis_lhs;
        }
        var digit_0 = tmp_0;
        // Inline function 'kotlin.Long.times' call
        var this_0 = exponent;
        // Inline function 'kotlin.Long.plus' call
        var this_1 = multiply(this_0, fromInt(10));
        exponent = add(this_1, fromInt(digit_0));
        var tmp_1 = exponent;
        // Inline function 'kotlin.Long.plus' call
        var this_2 = new Long(2147483647, 0);
        var tmp$ret$2 = add(this_2, fromInt(1));
        if (compare(tmp_1, add(tmp$ret$2, fraction)) > 0)
          throw NumberFormatException_init_$Create$('Exponent overflow');
      }
      var tmp0 = exponent;
      // Inline function 'kotlin.Long.times' call
      var other = exponentSign;
      exponent = multiply(tmp0, fromInt(other));
    }
    var scale = subtract(fraction, exponent);
    if (!(compare(new Long(-2147483648, -1), scale) <= 0 ? compare(scale, new Long(2147483647, 0)) <= 0 : false))
      throw NumberFormatException_init_$Create$('Scale out of range');
    return new Lexical(sign, convertToInt(scale), first, digits, guard, sticky);
  }
  function parse_2($this, input, context) {
    var lexical = scan($this, input, context.vd_1);
    if (equalsLong(lexical.qh_1, new Long(0, 0)))
      return BigDecimal_init_$Create$_0(Companion_getInstance_0().fc_1, lexical.oh_1);
    var kept = retainedDecimalText588(lexical.qh_1, context.vd_1);
    if (compare(kept, new Long(646456993, 0)) > 0) {
      overflow($this);
    }
    if (context.vd_1 === 0)
      return Companion_getInstance_0().wf(input, lexical.ph_1, convertToInt(kept), lexical.nh_1, lexical.oh_1);
    var drop = subtract(lexical.qh_1, kept);
    var scale = roundingScale($this, subtract(fromInt(lexical.oh_1), drop));
    var inexact = !(lexical.rh_1 === 0) || lexical.sh_1;
    if (compare(drop, new Long(0, 0)) > 0 && inexact && context.wd_1.equals(RoundingMode_UNNECESSARY_getInstance()))
      throw ArithmeticException_init_$Create$('Rounding necessary');
    var prefix_0 = prefix($this, input, lexical.ph_1, convertToInt(kept));
    if (compare(drop, new Long(0, 0)) > 0 && inexact) {
      var half = lexical.rh_1 === 5 && lexical.sh_1 ? 1 : compareTo(lexical.rh_1, 5);
      var tmp;
      switch (context.wd_1.v1_1) {
        case 0:
          tmp = true;
          break;
        case 1:
          tmp = false;
          break;
        case 2:
          tmp = lexical.nh_1 > 0;
          break;
        case 3:
          tmp = lexical.nh_1 < 0;
          break;
        case 4:
          tmp = half >= 0;
          break;
        case 5:
          tmp = half > 0;
          break;
        case 6:
          tmp = half > 0 || (half === 0 && !((prefix_0.n(0) % 2 | 0) === 0));
          break;
        case 7:
          tmp = false;
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
      var increment = tmp;
      if (increment) {
        prefix_0.lh();
      }
    }
    if (compare(prefix_0.gh(), kept) > 0) {
      // Inline function 'kotlin.check' call
      if (!(prefix_0.mh() === 0)) {
        throw IllegalStateException_init_$Create$('Check failed.');
      }
      // Inline function 'kotlin.Long.minus' call
      var this_0 = fromInt(scale);
      var tmp$ret$1 = subtract(this_0, fromInt(1));
      scale = roundingScale($this, tmp$ret$1);
    }
    return publishDecimal529($this, prefix_0, lexical.nh_1, scale);
  }
  function roundingScale($this, scale) {
    var narrowed = convertToInt(scale);
    if (!equalsLong(fromInt(narrowed), scale))
      throw ArithmeticException_init_$Create$(narrowed > 0 ? 'Underflow' : 'Overflow');
    return narrowed;
  }
  function overflow($this) {
    throw ArithmeticException_init_$Create$('BigInteger overflow');
  }
  function prefix($this, input, first, kept) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(kept);
    // Inline function 'kotlin.Long.div' call
    var this_1 = add(this_0, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = divide(this_1, fromInt(9));
    var tmp$ret$2 = add(this_2, fromInt(1));
    var result = new Digits_0(convertToInt(tmp$ret$2));
    var i = first;
    var consumed = 0;
    var block = 0;
    var inBlock = 0;
    $l$loop: while (consumed < kept) {
      var _unary__edvuaz = i;
      i = _unary__edvuaz + 1 | 0;
      var c = input.b(_unary__edvuaz);
      if (c === _Char___init__impl__6a9atx(46))
        continue $l$loop;
      var tmp = imul(block, 10);
      // Inline function 'kotlin.checkNotNull' call
      var tmp0 = numericDigit537(c, 10);
      var tmp$ret$4;
      $l$block: {
        // Inline function 'kotlin.checkNotNull' call
        if (tmp0 == null) {
          var message = 'Required value was null.';
          throw IllegalStateException_init_$Create$(toString_0(message));
        } else {
          tmp$ret$4 = tmp0;
          break $l$block;
        }
      }
      block = tmp + tmp$ret$4 | 0;
      consumed = consumed + 1 | 0;
      inBlock = inBlock + 1 | 0;
      if (inBlock === 9) {
        var _unary__edvuaz_0 = result.uh_1;
        result.uh_1 = _unary__edvuaz_0 + 1 | 0;
        result.xg(_unary__edvuaz_0, block);
        block = 0;
        inBlock = 0;
      }
    }
    var low = 0;
    var high = result.uh_1 - 1 | 0;
    while (low < high) {
      var cell = result.n(low);
      var _unary__edvuaz_1 = low;
      low = _unary__edvuaz_1 + 1 | 0;
      result.xg(_unary__edvuaz_1, result.n(high));
      var _unary__edvuaz_2 = high;
      high = _unary__edvuaz_2 - 1 | 0;
      result.xg(_unary__edvuaz_2, cell);
    }
    if (inBlock > 0) {
      var factor = $this.mb_1[inBlock];
      var carry = fromInt(block);
      var inductionVariable = 0;
      var last = result.uh_1;
      if (inductionVariable < last)
        do {
          var at = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          // Inline function 'kotlin.Long.times' call
          var this_3 = fromInt(result.n(at));
          var tmp$ret$6 = multiply(this_3, fromInt(factor));
          var part = add(tmp$ret$6, carry);
          // Inline function 'kotlin.Long.rem' call
          var other = 1000000000;
          var tmp$ret$7 = modulo(part, fromInt(other));
          result.xg(at, convertToInt(tmp$ret$7));
          // Inline function 'kotlin.Long.div' call
          var other_0 = 1000000000;
          carry = divide(part, fromInt(other_0));
        }
         while (inductionVariable < last);
      if (!equalsLong(carry, new Long(0, 0))) {
        var _unary__edvuaz_3 = result.uh_1;
        result.uh_1 = _unary__edvuaz_3 + 1 | 0;
        result.xg(_unary__edvuaz_3, convertToInt(carry));
      }
    }
    // Inline function 'kotlin.check' call
    if (!(result.uh_1 > 0 && !(result.n(result.uh_1 - 1 | 0) === 0))) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return result;
  }
  function Cells_0(capacity) {
    this.vh_1 = capacity;
    var tmp = this;
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(this.vh_1);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(8192));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$2 = divide(this_2, fromInt(8192));
    // Inline function 'kotlin.arrayOfNulls' call
    var size = convertToInt(tmp$ret$2);
    tmp.wh_1 = Array(size);
  }
  protoOf(Cells_0).n = function (index) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.vh_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var tmp0_safe_receiver = this.wh_1[index / 8192 | 0];
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver[index % 8192 | 0];
    return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  };
  protoOf(Cells_0).xg = function (index, value) {
    // Inline function 'kotlin.check' call
    if (!(index >= 0 && index < this.vh_1)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    var slot = index / 8192 | 0;
    var page = this.wh_1[slot];
    if (page == null) {
      if (value === 0)
        return Unit_instance;
      // Inline function 'kotlin.comparisons.minOf' call
      var b = this.vh_1 - imul(slot, 8192) | 0;
      var tmp$ret$1 = Math.min(8192, b);
      page = new Int32Array(tmp$ret$1);
      this.wh_1[slot] = page;
    }
    page[index % 8192 | 0] = value;
  };
  function Digits_0(capacity) {
    this.th_1 = new Cells_0(capacity);
    this.uh_1 = 0;
  }
  protoOf(Digits_0).n = function (index) {
    return this.th_1.n(index);
  };
  protoOf(Digits_0).xg = function (index, value) {
    this.th_1.xg(index, value);
  };
  protoOf(Digits_0).gh = function () {
    var top = this.th_1.n(this.uh_1 - 1 | 0);
    var count = 0;
    do {
      count = count + 1 | 0;
      top = top / 10 | 0;
    }
     while (!(top === 0));
    var tmp0 = new Long(9, 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.uh_1 - 1 | 0;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = count;
    return add(tmp0_0, fromInt(other_0));
  };
  protoOf(Digits_0).lh = function () {
    var i = 0;
    while (i < this.uh_1 && this.th_1.n(i) === 999999999) {
      this.th_1.xg(i, 0);
      i = i + 1 | 0;
    }
    if (i === this.uh_1) {
      this.th_1.xg(i, 1);
      this.uh_1 = this.uh_1 + 1 | 0;
    } else {
      this.th_1.xg(i, this.th_1.n(i) + 1 | 0);
    }
  };
  protoOf(Digits_0).mh = function () {
    var remainder = new Long(0, 0);
    var inductionVariable = this.uh_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = remainder;
        // Inline function 'kotlin.Long.times' call
        var other = 1000000000;
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = this.th_1.n(i);
        var part = add(tmp0_0, fromInt(other_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$2 = divide(part, fromInt(10));
        this.th_1.xg(i, convertToInt(tmp$ret$2));
        // Inline function 'kotlin.Long.rem' call
        remainder = modulo(part, fromInt(10));
      }
       while (0 <= inductionVariable);
    while (this.uh_1 > 0 && this.th_1.n(this.uh_1 - 1 | 0) === 0) {
      this.uh_1 = this.uh_1 - 1 | 0;
    }
    // Inline function 'kotlin.check' call
    if (!(this.uh_1 > 0)) {
      throw IllegalStateException_init_$Create$('Check failed.');
    }
    return convertToInt(remainder);
  };
  function publishDecimal529($this, decimal, sign, scale) {
    if (decimal.uh_1 <= 3) {
      var negative = new Long(0, 0);
      var compact = true;
      var inductionVariable = decimal.uh_1 - 1 | 0;
      if (0 <= inductionVariable)
        $l$loop_0: do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + -1 | 0;
          var block = decimal.n(index);
          var tmp = negative;
          var tmp0 = new Long(0, -2147483648);
          // Inline function 'kotlin.Long.div' call
          var other = 1000000000;
          var tmp$ret$0 = divide(tmp0, fromInt(other));
          if (compare(tmp, tmp$ret$0) < 0) {
            compact = false;
            break $l$loop_0;
          }
          var tmp0_0 = negative;
          // Inline function 'kotlin.Long.times' call
          var other_0 = 1000000000;
          var product = multiply(tmp0_0, fromInt(other_0));
          // Inline function 'kotlin.Long.plus' call
          var this_0 = new Long(0, -2147483648);
          var tmp$ret$2 = add(this_0, fromInt(block));
          if (compare(product, tmp$ret$2) < 0) {
            compact = false;
            break $l$loop_0;
          }
          // Inline function 'kotlin.Long.minus' call
          negative = subtract(product, fromInt(block));
        }
         while (0 <= inductionVariable);
      if (compact && (sign < 0 || !equalsLong(negative, new Long(0, -2147483648))))
        return Companion_getInstance().ee(sign < 0 ? negative : negate(negative), scale);
    }
    return BigDecimal_init_$Create$_0(publish_0($this, decimal, sign), scale);
  }
  function publish_0($this, decimal, sign) {
    var tmp0 = new Long(2147483647, 0);
    // Inline function 'kotlin.comparisons.minOf' call
    var b = multiply(new Long(4, 0), decimal.gh());
    var bound = compare(tmp0, b) <= 0 ? tmp0 : b;
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_0 = add(bound, fromInt(29));
    // Inline function 'kotlin.Long.plus' call
    var this_1 = divide(this_0, fromInt(30));
    var tmp$ret$3 = add(this_1, fromInt(1));
    var binary = new Cells_0(convertToInt(tmp$ret$3));
    var size = 0;
    var inductionVariable = decimal.uh_1 - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var carry = fromInt(decimal.n(i));
        var j = 0;
        while (j < size) {
          var tmp0_0 = fromInt(binary.n(j));
          // Inline function 'kotlin.Long.times' call
          var other = 1000000000;
          var tmp$ret$4 = multiply(tmp0_0, fromInt(other));
          var part = add(tmp$ret$4, carry);
          binary.xg(j, convertToInt(bitwiseAnd(part, new Long(1073741823, 0))));
          carry = shiftRightUnsigned(part, 30);
          j = j + 1 | 0;
        }
        if (!equalsLong(carry, new Long(0, 0))) {
          var _unary__edvuaz = size;
          size = _unary__edvuaz + 1 | 0;
          binary.xg(_unary__edvuaz, convertToInt(carry));
        }
        var tmp0_1 = new Long(30, 0);
        // Inline function 'kotlin.Long.times' call
        var other_0 = size - 1 | 0;
        // Inline function 'kotlin.Long.plus' call
        var this_2 = multiply(tmp0_1, fromInt(other_0));
        var tmp0_2 = add(this_2, fromInt(32));
        // Inline function 'kotlin.countLeadingZeroBits' call
        var this_3 = binary.n(size - 1 | 0);
        // Inline function 'kotlin.Long.minus' call
        var other_1 = clz32(this_3);
        var bits = subtract(tmp0_2, fromInt(other_1));
        if (compare(bits, new Long(2147483647, 0)) > 0) {
          overflow($this);
        }
      }
       while (0 <= inductionVariable);
    var tmp0_3 = new Long(30, 0);
    // Inline function 'kotlin.Long.times' call
    var other_2 = size - 1 | 0;
    // Inline function 'kotlin.Long.plus' call
    var this_4 = multiply(tmp0_3, fromInt(other_2));
    var tmp0_4 = add(this_4, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    var this_5 = binary.n(size - 1 | 0);
    // Inline function 'kotlin.Long.minus' call
    var other_3 = clz32(this_5);
    var bits_0 = subtract(tmp0_4, fromInt(other_3));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.div' call
    var this_6 = add(bits_0, fromInt(7));
    var tmp$ret$14 = divide(this_6, fromInt(8));
    var bytes = new Int8Array(convertToInt(tmp$ret$14));
    var inductionVariable_0 = 0;
    var last = bytes.length - 1 | 0;
    if (inductionVariable_0 <= last)
      do {
        var i_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        // Inline function 'kotlin.Long.times' call
        var this_7 = new Long(8, 0);
        var bit = multiply(this_7, fromInt(i_0));
        // Inline function 'kotlin.Long.div' call
        var tmp$ret$16 = divide(bit, fromInt(30));
        var word = convertToInt(tmp$ret$16);
        // Inline function 'kotlin.Long.rem' call
        var tmp$ret$17 = modulo(bit, fromInt(30));
        var offset = convertToInt(tmp$ret$17);
        var value = shiftRightUnsigned(fromInt(binary.n(word)), offset);
        if (offset > 22 && (word + 1 | 0) < size)
          value = bitwiseOr(value, shiftLeft(fromInt(binary.n(word + 1 | 0)), 30 - offset | 0));
        bytes[get_lastIndex_0(bytes) - i_0 | 0] = convertToByte(bitwiseAnd(value, new Long(255, 0)));
      }
       while (inductionVariable_0 <= last);
    return BigInteger_init_$Create$_3(sign, bytes);
  }
  function DecimalText588() {
    DecimalText588_instance = this;
    this.jb_1 = new Long(646456993, 0);
    this.kb_1 = 1000000000;
    this.lb_1 = 8192;
    var tmp = this;
    // Inline function 'kotlin.intArrayOf' call
    tmp.mb_1 = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000]);
  }
  protoOf(DecimalText588).nb = function (value, context) {
    return parse_2(this, Companion_instance_3.re(value), context);
  };
  var DecimalText588_instance;
  function DecimalText588_getInstance() {
    if (DecimalText588_instance == null)
      new DecimalText588();
    return DecimalText588_instance;
  }
  function retainedDecimalText588(digits, precision) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(compare(digits, new Long(0, 0)) >= 0 && precision >= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var tmp;
    if (precision === 0) {
      tmp = digits;
    } else {
      // Inline function 'kotlin.comparisons.minOf' call
      var b = fromInt(precision);
      tmp = compare(digits, b) <= 0 ? digits : b;
    }
    return tmp;
  }
  function decimalDoubleString(value) {
    if (!isFinite(value))
      throw NumberFormatException_init_$Create$('Infinite or NaN');
    if (value === 0.0)
      return '0.0';
    var magnitude = value < 0 ? -value : value;
    var stripped = shortestDoubleDecimal(magnitude).oe();
    var tmp0 = fromInt(stripped.xd());
    // Inline function 'kotlin.Long.minus' call
    var other = stripped.he();
    // Inline function 'kotlin.Long.minus' call
    var this_0 = subtract(tmp0, fromInt(other));
    var exponent = subtract(this_0, fromInt(1));
    // Inline function 'kotlin.ranges.contains' call
    var this_1 = numberRangeToNumber(-3, 6);
    if (contains(isInterface(this_1, ClosedRange) ? this_1 : THROW_CCE(), exponent)) {
      var plain = stripped.qe();
      var text = contains_0(plain, _Char___init__impl__6a9atx(46)) ? plain : plain + '.0';
      return (value < 0 ? '-' : '') + text;
    }
    var digits = stripped.ge().xc().toString();
    // Inline function 'kotlin.text.plus' call
    var this_2 = charCodeAt(digits, 0);
    var mantissa = toString(this_2) + '.' + (digits.length === 1 ? '0' : substring(digits, 1));
    return (value < 0 ? '-' : '') + mantissa + 'E' + exponent.toString();
  }
  function shortestDoubleDecimal(magnitude) {
    var exact = BigDecimal_init_$Create$_3(magnitude);
    var exactDigits = exact.ge().toString();
    var exponent = (exactDigits.length - exact.he() | 0) - 1 | 0;
    var bits = toBits(magnitude);
    // Inline function 'kotlin.Long.minus' call
    // Inline function 'kotlin.fromBits' call
    var bits_0 = subtract(bits, fromInt(1));
    var tmp$ret$1 = doubleFromBits(bits_0);
    var previous = BigDecimal_init_$Create$_3(tmp$ret$1);
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.fromBits' call
    var bits_1 = add(bits, fromInt(1));
    var next = doubleFromBits(bits_1);
    var successor = isFinite(next) ? BigDecimal_init_$Create$_3(next) : null;
    var includesMidpoints = equalsLong(bitwiseAnd(bits, new Long(1, 0)), new Long(0, 0));
    var tmp0 = exact.he();
    var tmp2 = previous.he();
    var tmp1_elvis_lhs = successor == null ? null : successor.he();
    // Inline function 'kotlin.comparisons.maxOf' call
    var c = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    var tmp0_0 = Math.max(tmp0, tmp2, c);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = 16 - exponent | 0;
    var commonScale = Math.max(tmp0_0, b) + 1 | 0;
    var exactCoefficient = exact.le(commonScale).ge();
    var previousCoefficient = previous.le(commonScale).ge();
    var lowerCoefficient = exactCoefficient.ad(previousCoefficient).kg(1);
    var tmp;
    if (!(successor == null)) {
      tmp = exactCoefficient.ad(successor.le(commonScale).ge()).kg(1);
    } else {
      tmp = exactCoefficient.ad(exactCoefficient.yc(previousCoefficient).kg(1));
    }
    var upperCoefficient = tmp;
    // Inline function 'kotlin.collections.buildList' call
    // Inline function 'kotlin.collections.buildListInternal' call
    // Inline function 'kotlin.apply' call
    var this_0 = ArrayList_init_$Create$();
    var unit = Companion_getInstance_0().ic_1.nc((commonScale + exponent | 0) - 16 | 0);
    // Inline function 'kotlin.repeat' call
    var inductionVariable = 0;
    if (inductionVariable < 17)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this_0.e(unit);
        unit = unit.oc(Companion_getInstance_0().ic_1);
      }
       while (inductionVariable < 17);
    var units = this_0.g3();
    var inductionVariable_0 = 2;
    if (inductionVariable_0 <= 17)
      do {
        var digits = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        var minimum = Companion_getInstance_0().ic_1.nc(digits - 1 | 0);
        var maximum = minimum.oc(Companion_getInstance_0().ic_1).yc(Companion_getInstance_0().gc_1);
        var best = null;
        var bestDistance = null;
        var offsets = digits === 2 ? numberRangeToNumber(-1, 1) : numberRangeToNumber(0, 0);
        var inductionVariable_1 = offsets.a9_1;
        var last = offsets.b9_1;
        if (inductionVariable_1 <= last)
          do {
            var offset = inductionVariable_1;
            inductionVariable_1 = inductionVariable_1 + 1 | 0;
            var scale = ((digits - 1 | 0) - exponent | 0) - offset | 0;
            var unit_0 = units.n((17 - digits | 0) + offset | 0);
            var length = digits - offset | 0;
            var floor = BigInteger_init_$Create$_1(padEnd(take(exactDigits, length), length, _Char___init__impl__6a9atx(48)));
            var _iterator__ex2g4s = listOf([floor, floor.ad(Companion_getInstance_0().gc_1)]).f();
            $l$loop: while (_iterator__ex2g4s.g()) {
              var coefficient = _iterator__ex2g4s.h();
              var bounded = coefficient.zc(minimum) < 0 ? minimum : coefficient.zc(maximum) > 0 ? maximum : coefficient;
              var aligned = bounded.oc(unit_0);
              var lowerComparison = aligned.zc(lowerCoefficient);
              var upperComparison = aligned.zc(upperCoefficient);
              if (lowerComparison < 0 || upperComparison > 0 || (!includesMidpoints && (lowerComparison === 0 || upperComparison === 0)))
                continue $l$loop;
              var decimal = BigDecimal_init_$Create$_0(bounded, scale).oe();
              var distance = exactCoefficient.yc(aligned).xc();
              var tmp2_safe_receiver = bestDistance;
              var tmp_0;
              if (tmp2_safe_receiver == null) {
                tmp_0 = null;
              } else {
                // Inline function 'kotlin.let' call
                tmp_0 = distance.zc(tmp2_safe_receiver);
              }
              var tmp3_elvis_lhs = tmp_0;
              var comparison = tmp3_elvis_lhs == null ? -1 : tmp3_elvis_lhs;
              if (comparison < 0 || (comparison === 0 && !decimal.ge().bd(0))) {
                best = decimal;
                bestDistance = distance;
              }
            }
          }
           while (!(offset === last));
        if (!(best == null))
          return best;
      }
       while (inductionVariable_0 <= 17);
    // Inline function 'kotlin.error' call
    var message = 'No seventeen-digit round-trip decimal';
    throw IllegalStateException_init_$Create$(toString_0(message));
  }
  function MagnitudeLimits() {
    this.af_1 = 30;
    this.bf_1 = 268435456;
  }
  protoOf(MagnitudeLimits).kf = function (byteCount, extraCarryBit) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(byteCount >= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (byteCount > 268435456)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    // Inline function 'kotlin.Long.times' call
    var this_0 = fromInt(byteCount);
    var tmp0 = multiply(this_0, fromInt(8));
    // Inline function 'kotlin.Long.plus' call
    var other = extraCarryBit ? 1 : 0;
    var bits = add(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(bits, fromInt(30));
    // Inline function 'kotlin.Long.div' call
    var this_2 = subtract(this_1, fromInt(1));
    var tmp$ret$7 = divide(this_2, fromInt(30));
    return convertToInt(tmp$ret$7);
  };
  protoOf(MagnitudeLimits).hf = function (wordCount, highWord) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(wordCount > 0 && (1 <= highWord ? highWord < 1073741824 : false))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(wordCount);
    // Inline function 'kotlin.Long.times' call
    var this_1 = subtract(this_0, fromInt(1));
    // Inline function 'kotlin.Long.plus' call
    var this_2 = multiply(this_1, fromInt(30));
    var tmp0 = add(this_2, fromInt(32));
    // Inline function 'kotlin.countLeadingZeroBits' call
    // Inline function 'kotlin.Long.minus' call
    var other = clz32(highWord);
    var bits = subtract(tmp0, fromInt(other));
    if (compare(bits, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    return convertToInt(bits);
  };
  protoOf(MagnitudeLimits).cf = function (significantDigits, radix) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(significantDigits > 0 && (2 <= radix ? radix <= 36 : false))) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.countLeadingZeroBits' call
    var bitsPerDigit = 31 - clz32(radix) | 0;
    var tmp = new Long(1, 0);
    // Inline function 'kotlin.Long.minus' call
    var this_0 = fromInt(significantDigits);
    // Inline function 'kotlin.Long.times' call
    var this_1 = subtract(this_0, fromInt(1));
    var tmp$ret$5 = multiply(this_1, fromInt(bitsPerDigit));
    var minimumBits = add(tmp, tmp$ret$5);
    return compare(minimumBits, new Long(2147483647, 0)) > 0;
  };
  var MagnitudeLimits_instance;
  function MagnitudeLimits_getInstance() {
    return MagnitudeLimits_instance;
  }
  function multiplyAdaptiveJs539($this, a, b) {
    if (a.length >= 16 && a.length < 128 && a === b) {
      var out = new Int32Array(a.length + b.length | 0);
      square($this, a, 0, a.length, out, 0);
      return out;
    }
    var out_0 = new Int32Array(a.length + b.length | 0);
    var tmp0 = a.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b_0 = b.length;
    var small = Math.min(tmp0, b_0);
    if (small < 32) {
      school($this, a, 0, a.length, b, 0, b.length, out_0, 0);
      return out_0;
    }
    var threshold = !(a === b) && a.length === b.length ? 32 : 64;
    if (small < threshold) {
      school($this, a, 0, a.length, b, 0, b.length, out_0, 0);
    } else {
      var arena = new Arena($this.xh(a.length, b.length, threshold));
      product($this, a, 0, a.length, b, 0, b.length, out_0, 0, arena, threshold, 16);
    }
    return out_0;
  }
  function Arena(size) {
    this.yh_1 = new Int32Array(size);
    this.zh_1 = 0;
  }
  protoOf(Arena).ai = function (size) {
    var offset = this.zh_1;
    // Inline function 'kotlin.check' call
    if (!(size <= (this.yh_1.length - offset | 0))) {
      var message = 'Multiplication scratch bound';
      throw IllegalStateException_init_$Create$(toString_0(message));
    }
    this.zh_1 = this.zh_1 + size | 0;
    return offset;
  };
  function product($this, a, ao, al, b, bo, bl, out, oo, arena, threshold, squareThreshold) {
    fill(out, 0, oo, (oo + al | 0) + bl | 0);
    if (al === 0 || bl === 0)
      return Unit_instance;
    // Inline function 'kotlin.comparisons.minOf' call
    var small = Math.min(al, bl);
    // Inline function 'kotlin.comparisons.maxOf' call
    var large = Math.max(al, bl);
    if (small < threshold) {
      if (a === b && ao === bo && al === bl && al >= squareThreshold) {
        square($this, a, ao, al, out, oo);
      } else {
        school($this, a, ao, al, b, bo, bl, out, oo);
      }
      return Unit_instance;
    }
    var mark = arena.zh_1;
    var tmp = fromInt(large);
    // Inline function 'kotlin.Long.times' call
    var this_0 = new Long(2, 0);
    var tmp$ret$2 = multiply(this_0, fromInt(small));
    if (compare(tmp, tmp$ret$2) > 0) {
      var longer = al >= bl ? a : b;
      var lo = al >= bl ? ao : bo;
      var shorter = al >= bl ? b : a;
      var so = al >= bl ? bo : ao;
      var temp = arena.ai(imul(2, small));
      var position = 0;
      while (position < large) {
        // Inline function 'kotlin.comparisons.minOf' call
        var b_0 = large - position | 0;
        var length = Math.min(small, b_0);
        product($this, longer, lo + position | 0, length, shorter, so, small, arena.yh_1, temp, arena, threshold, squareThreshold);
        addAt($this, out, oo + position | 0, arena.yh_1, temp, length + small | 0);
        position = position + length | 0;
      }
      arena.zh_1 = mark;
      return Unit_instance;
    }
    var split = large / 2 | 0;
    // Inline function 'kotlin.comparisons.minOf' call
    var aLow = Math.min(al, split);
    // Inline function 'kotlin.comparisons.minOf' call
    var bLow = Math.min(bl, split);
    var aHigh = al - aLow | 0;
    var bHigh = bl - bLow | 0;
    product($this, a, ao, aLow, b, bo, bLow, out, oo, arena, threshold, squareThreshold);
    if (aHigh > 0 && bHigh > 0) {
      product($this, a, ao + aLow | 0, aHigh, b, bo + bLow | 0, bHigh, out, oo + imul(2, split) | 0, arena, threshold, squareThreshold);
    }
    // Inline function 'kotlin.comparisons.maxOf' call
    var ac = Math.max(aLow, aHigh) + 1 | 0;
    // Inline function 'kotlin.comparisons.maxOf' call
    var bc = Math.max(bLow, bHigh) + 1 | 0;
    var sumA = arena.ai(ac);
    var sumB = arena.ai(bc);
    var middle = arena.ai(ac + bc | 0);
    var aLength = sum($this, a, ao, aLow, ao + aLow | 0, aHigh, arena.yh_1, sumA, ac);
    var bLength = sum($this, b, bo, bLow, bo + bLow | 0, bHigh, arena.yh_1, sumB, bc);
    product($this, arena.yh_1, sumA, aLength, arena.yh_1, sumB, bLength, arena.yh_1, middle, arena, threshold, squareThreshold);
    var middleLength = aLength + bLength | 0;
    subtract_0($this, arena.yh_1, middle, middleLength, out, oo, aLow + bLow | 0);
    if (aHigh > 0 && bHigh > 0) {
      subtract_0($this, arena.yh_1, middle, middleLength, out, oo + imul(2, split) | 0, aHigh + bHigh | 0);
    }
    addAt($this, out, oo + split | 0, arena.yh_1, middle, trimmed($this, arena.yh_1, middle, middleLength));
    arena.zh_1 = mark;
  }
  function school($this, a, ao, al, b, bo, bl, out, oo) {
    var inductionVariable = 0;
    if (inductionVariable < al)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp2 = a[ao + i | 0];
        // Inline function 'io.heapy.krogu.math.MagnitudeMultiplication.schoolRow' call
        var oo_0 = oo + i | 0;
        var carry = new Long(0, 0);
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < bl)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp0 = fromInt(tmp2);
            // Inline function 'kotlin.Long.times' call
            var other = b[bo + j | 0];
            var tmp0_0 = multiply(tmp0, fromInt(other));
            // Inline function 'kotlin.Long.plus' call
            var other_0 = out[oo_0 + j | 0];
            var tmp$ret$2 = add(tmp0_0, fromInt(other_0));
            var value = add(tmp$ret$2, carry);
            out[oo_0 + j | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
            carry = shiftRightUnsigned(value, 30);
          }
           while (inductionVariable_0 < bl);
        out[oo_0 + bl | 0] = convertToInt(carry);
      }
       while (inductionVariable < al);
  }
  function square($this, a, offset, length, out, oo) {
    var inductionVariable = 0;
    if (inductionVariable < length)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var word = fromInt(a[offset + i | 0]);
        var tmp0 = multiply(word, word);
        // Inline function 'kotlin.Long.plus' call
        var other = out[oo + imul(2, i) | 0];
        var diagonal = add(tmp0, fromInt(other));
        out[oo + imul(2, i) | 0] = convertToInt(bitwiseAnd(diagonal, new Long(1073741823, 0)));
        var carry = shiftRightUnsigned(diagonal, 30);
        var inductionVariable_0 = i + 1 | 0;
        if (inductionVariable_0 < length)
          do {
            var j = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            var tmp0_0 = multiply(new Long(2, 0), word);
            // Inline function 'kotlin.Long.times' call
            var other_0 = a[offset + j | 0];
            var tmp0_1 = multiply(tmp0_0, fromInt(other_0));
            // Inline function 'kotlin.Long.plus' call
            var other_1 = out[(oo + i | 0) + j | 0];
            var tmp$ret$2 = add(tmp0_1, fromInt(other_1));
            var value = add(tmp$ret$2, carry);
            out[(oo + i | 0) + j | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
            carry = shiftRightUnsigned(value, 30);
          }
           while (inductionVariable_0 < length);
        var index = (oo + i | 0) + length | 0;
        while (!equalsLong(carry, new Long(0, 0))) {
          var value_0 = add(fromInt(out[index]), carry);
          var _unary__edvuaz = index;
          index = _unary__edvuaz + 1 | 0;
          out[_unary__edvuaz] = convertToInt(bitwiseAnd(value_0, new Long(1073741823, 0)));
          carry = shiftRightUnsigned(value_0, 30);
        }
      }
       while (inductionVariable < length);
  }
  function sum($this, a, low, lowLength, high, highLength, out, offset, capacity) {
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    var last = capacity - 1 | 0;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var value = add(add(i < lowLength ? fromInt(a[low + i | 0]) : new Long(0, 0), i < highLength ? fromInt(a[high + i | 0]) : new Long(0, 0)), carry);
        out[offset + i | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(value, 30);
      }
       while (inductionVariable < last);
    out[(offset + capacity | 0) - 1 | 0] = convertToInt(carry);
    return trimmed($this, out, offset, capacity);
  }
  function subtract_0($this, out, offset, length, b, bo, bl) {
    var borrow = new Long(0, 0);
    var inductionVariable = 0;
    if (inductionVariable < length)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var value = subtract(subtract(fromInt(out[offset + i | 0]), i < bl ? fromInt(b[bo + i | 0]) : new Long(0, 0)), borrow);
        out[offset + i | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
        borrow = compare(value, new Long(0, 0)) < 0 ? new Long(1, 0) : new Long(0, 0);
      }
       while (inductionVariable < length);
    // Inline function 'kotlin.check' call
    if (!equalsLong(borrow, new Long(0, 0))) {
      var message = 'Negative Karatsuba cross product';
      throw IllegalStateException_init_$Create$(toString_0(message));
    }
  }
  function addAt($this, out, offset, b, bo, length) {
    var carry = new Long(0, 0);
    var i = 0;
    while (i < length || !equalsLong(carry, new Long(0, 0))) {
      var value = add(add(fromInt(out[offset + i | 0]), i < length ? fromInt(b[bo + i | 0]) : new Long(0, 0)), carry);
      out[offset + i | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
      carry = shiftRightUnsigned(value, 30);
      i = i + 1 | 0;
    }
  }
  function trimmed($this, a, offset, length) {
    var size = length;
    while (size > 0 && a[(offset + size | 0) - 1 | 0] === 0) {
      size = size - 1 | 0;
    }
    return size;
  }
  function MagnitudeMultiplication() {
    MagnitudeMultiplication_instance = this;
    this.xf_1 = 64;
    this.yf_1 = 16;
    this.zf_1 = 384;
    this.ag_1 = 30;
    this.bg_1 = new Long(1073741823, 0);
  }
  protoOf(MagnitudeMultiplication).cg = function (left, right) {
    // Inline function 'kotlin.Long.plus' call
    var this_0 = fromInt(left);
    // Inline function 'kotlin.Long.minus' call
    var this_1 = add(this_0, fromInt(right));
    var tmp$ret$1 = subtract(this_1, fromInt(1));
    if (compare(tmp$ret$1, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
  };
  protoOf(MagnitudeMultiplication).bi = function (a, b) {
    return (false || false) && !(a === b) && a.length === b.length ? 32 : 64;
  };
  protoOf(MagnitudeMultiplication).ci = function () {
    return false ? 128 : 384;
  };
  protoOf(MagnitudeMultiplication).eg = function (a, b) {
    if (false)
      return multiplyAdaptiveJs539(this, a, b);
    if (true && true)
      return this.di(a, b, 384);
    if (a === b && a.length >= 16 && a.length < this.ci()) {
      var out = new Int32Array(a.length + b.length | 0);
      square(this, a, 0, a.length, out, 0);
      return out;
    }
    return this.ei(a, b, this.bi(a, b), 16);
  };
  protoOf(MagnitudeMultiplication).di = function (a, b, squareEntryThreshold) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(squareEntryThreshold >= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (a.length >= 16 && a.length < squareEntryThreshold && a === b) {
      var out = new Int32Array(a.length + b.length | 0);
      square(this, a, 0, a.length, out, 0);
      return out;
    }
    return this.fi(a, b);
  };
  protoOf(MagnitudeMultiplication).ei = function (a, b, threshold, squareThreshold) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(threshold >= 4 && squareThreshold >= 1)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var out = new Int32Array(a.length + b.length | 0);
    var tmp0 = a.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b_0 = b.length;
    if (Math.min(tmp0, b_0) < threshold) {
      if (a.length >= squareThreshold && a === b) {
        square(this, a, 0, a.length, out, 0);
      } else {
        school(this, a, 0, a.length, b, 0, b.length, out, 0);
      }
    } else {
      var arena = new Arena(this.xh(a.length, b.length, threshold));
      product(this, a, 0, a.length, b, 0, b.length, out, 0, arena, threshold, squareThreshold);
    }
    return out;
  };
  protoOf(MagnitudeMultiplication).fi = function (a, b, threshold, squareThreshold, $super) {
    threshold = threshold === VOID ? 64 : threshold;
    squareThreshold = squareThreshold === VOID ? 16 : squareThreshold;
    return $super === VOID ? this.ei(a, b, threshold, squareThreshold) : $super.ei.call(this, a, b, threshold, squareThreshold);
  };
  protoOf(MagnitudeMultiplication).xh = function (a, b, threshold) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(a >= 0 && b >= 0 && threshold >= 4)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    // Inline function 'kotlin.comparisons.minOf' call
    var small = Math.min(a, b);
    if (small < threshold)
      return 0;
    var tmp;
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$4 = Math.max(a, b);
    var tmp_0 = fromInt(tmp$ret$4);
    // Inline function 'kotlin.Long.times' call
    var this_0 = new Long(2, 0);
    var tmp$ret$5 = multiply(this_0, fromInt(small));
    if (compare(tmp_0, tmp$ret$5) > 0) {
      tmp = small;
    } else {
      // Inline function 'kotlin.comparisons.maxOf' call
      tmp = Math.max(a, b);
    }
    var size = tmp;
    var tmp_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var tmp$ret$7 = Math.max(a, b);
    var tmp_2 = fromInt(tmp$ret$7);
    // Inline function 'kotlin.Long.times' call
    var this_1 = new Long(2, 0);
    var tmp$ret$8 = multiply(this_1, fromInt(small));
    if (compare(tmp_2, tmp$ret$8) > 0) {
      // Inline function 'kotlin.Long.times' call
      var this_2 = new Long(2, 0);
      tmp_1 = multiply(this_2, fromInt(small));
    } else {
      tmp_1 = new Long(0, 0);
    }
    var total = tmp_1;
    while (size >= threshold) {
      // Inline function 'kotlin.Long.plus' call
      var this_3 = fromInt(size);
      // Inline function 'kotlin.Long.div' call
      var this_4 = add(this_3, fromInt(1));
      // Inline function 'kotlin.Long.plus' call
      var this_5 = divide(this_4, fromInt(2));
      var tmp$ret$12 = add(this_5, fromInt(1));
      size = convertToInt(tmp$ret$12);
      var tmp_3 = total;
      var tmp0 = new Long(4, 0);
      // Inline function 'kotlin.Long.times' call
      var other = size;
      var tmp$ret$13 = multiply(tmp0, fromInt(other));
      total = add(tmp_3, tmp$ret$13);
    }
    if (compare(total, new Long(2147483647, 0)) > 0)
      throw ArithmeticException_init_$Create$('BigInteger overflow');
    return convertToInt(total);
  };
  protoOf(MagnitudeMultiplication).dg = function (word, borrowedWide) {
    var out = new Int32Array(borrowedWide.length + 1 | 0);
    // Inline function 'io.heapy.krogu.math.MagnitudeMultiplication.schoolRow' call
    var bl = borrowedWide.length;
    var carry = new Long(0, 0);
    var inductionVariable = 0;
    if (inductionVariable < bl)
      do {
        var j = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp0 = fromInt(word);
        // Inline function 'kotlin.Long.times' call
        var other = borrowedWide[0 + j | 0];
        var tmp0_0 = multiply(tmp0, fromInt(other));
        // Inline function 'kotlin.Long.plus' call
        var other_0 = out[0 + j | 0];
        var tmp$ret$2 = add(tmp0_0, fromInt(other_0));
        var value = add(tmp$ret$2, carry);
        out[0 + j | 0] = convertToInt(bitwiseAnd(value, new Long(1073741823, 0)));
        carry = shiftRightUnsigned(value, 30);
      }
       while (inductionVariable < bl);
    out[0 + bl | 0] = convertToInt(carry);
    return out;
  };
  var MagnitudeMultiplication_instance;
  function MagnitudeMultiplication_getInstance() {
    if (MagnitudeMultiplication_instance == null)
      new MagnitudeMultiplication();
    return MagnitudeMultiplication_instance;
  }
  function Companion_1() {
    Companion_instance_2 = this;
    this.eb_1 = new Long(527827455, 1299129800);
    this.fb_1 = new MathContext(0, RoundingMode_HALF_UP_getInstance());
    this.gb_1 = new MathContext(7, RoundingMode_HALF_EVEN_getInstance());
    this.hb_1 = new MathContext(16, RoundingMode_HALF_EVEN_getInstance());
    this.ib_1 = new MathContext(34, RoundingMode_HALF_EVEN_getInstance());
  }
  var Companion_instance_2;
  function Companion_getInstance_1() {
    if (Companion_instance_2 == null)
      new Companion_1();
    return Companion_instance_2;
  }
  function MathContext(precision, roundingMode) {
    Companion_getInstance_1();
    this.vd_1 = precision;
    // Inline function 'kotlin.require' call
    if (!(this.vd_1 >= 0)) {
      var message = 'Digits < 0';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    this.wd_1 = roundingMode;
  }
  protoOf(MathContext).equals = function (other) {
    var tmp;
    var tmp_0;
    if (other instanceof MathContext) {
      tmp_0 = this.vd_1 === other.vd_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.wd_1.equals(other.wd_1);
    } else {
      tmp = false;
    }
    return tmp;
  };
  protoOf(MathContext).hashCode = function () {
    return this.vd_1 + imul(this.wd_1.hashCode(), 59) | 0;
  };
  protoOf(MathContext).toString = function () {
    return 'precision=' + this.vd_1 + ' roundingMode=' + this.wd_1.toString();
  };
  var ZERO_BLOCK537;
  function RadixDigits537(chunks, size, radix, width) {
    this.pf_1 = chunks;
    this.qf_1 = size;
    this.rf_1 = radix;
    this.sf_1 = width;
    this.tf_1 = (this.qf_1 === 1 && this.pf_1[0] === 0);
    var tmp = this;
    // Inline function 'kotlin.run' call
    var rest = this.pf_1[this.qf_1 - 1 | 0];
    var count = 1;
    while (rest >= this.rf_1) {
      rest = rest / this.rf_1 | 0;
      count = count + 1 | 0;
    }
    tmp.uf_1 = count;
    var tmp_0 = this;
    var tmp0 = fromInt(this.qf_1 - 1 | 0);
    // Inline function 'kotlin.Long.times' call
    var other = this.sf_1;
    var tmp0_0 = multiply(tmp0, fromInt(other));
    // Inline function 'kotlin.Long.plus' call
    var other_0 = this.uf_1;
    tmp_0.vf_1 = add(tmp0_0, fromInt(other_0));
  }
  protoOf(RadixDigits537).gi = function (sink, start, end) {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!((compare(new Long(0, 0), start) <= 0 ? compare(start, end) <= 0 : false) && compare(end, this.vf_1) <= 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    var buffer = charArray(this.sf_1);
    var powerOfTwo = (this.rf_1 & (this.rf_1 - 1 | 0)) === 0;
    var shift = countTrailingZeroBits_0(this.rf_1);
    var cursor = new Long(0, 0);
    var inductionVariable = this.qf_1 - 1 | 0;
    if (0 <= inductionVariable)
      $l$loop: do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var count = index === (this.qf_1 - 1 | 0) ? this.uf_1 : this.sf_1;
        // Inline function 'kotlin.Long.plus' call
        var this_0 = cursor;
        var after = add(this_0, fromInt(count));
        if (compare(after, start) > 0 && compare(cursor, end) < 0) {
          var rest = this.pf_1[index];
          if (powerOfTwo) {
            var inductionVariable_0 = count - 1 | 0;
            if (0 <= inductionVariable_0)
              do {
                var digit = inductionVariable_0;
                inductionVariable_0 = inductionVariable_0 + -1 | 0;
                buffer[digit] = charCodeAt('0123456789abcdefghijklmnopqrstuvwxyz', rest & (this.rf_1 - 1 | 0));
                rest = rest >>> shift | 0;
              }
               while (0 <= inductionVariable_0);
          } else {
            var inductionVariable_1 = count - 1 | 0;
            if (0 <= inductionVariable_1)
              do {
                var digit_0 = inductionVariable_1;
                inductionVariable_1 = inductionVariable_1 + -1 | 0;
                buffer[digit_0] = charCodeAt('0123456789abcdefghijklmnopqrstuvwxyz', rest % this.rf_1 | 0);
                rest = rest / this.rf_1 | 0;
              }
               while (0 <= inductionVariable_1);
          }
          var tmp0 = new Long(0, 0);
          // Inline function 'kotlin.comparisons.maxOf' call
          var b = subtract(start, cursor);
          var tmp$ret$4 = compare(tmp0, b) >= 0 ? tmp0 : b;
          var tmp = convertToInt(tmp$ret$4);
          var tmp0_0 = fromInt(count);
          // Inline function 'kotlin.comparisons.minOf' call
          var b_0 = subtract(end, cursor);
          var tmp$ret$5 = compare(tmp0_0, b_0) <= 0 ? tmp0_0 : b_0;
          sink.hi(buffer, tmp, convertToInt(tmp$ret$5));
        }
        cursor = after;
      }
       while (compare(cursor, end) < 0 && 0 <= inductionVariable);
  };
  protoOf(RadixDigits537).qg = function (sink, start, end, $super) {
    start = start === VOID ? new Long(0, 0) : start;
    end = end === VOID ? this.vf_1 : end;
    var tmp;
    if ($super === VOID) {
      this.gi(sink, start, end);
      tmp = Unit_instance;
    } else {
      tmp = $super.gi.call(this, sink, start, end);
    }
    return tmp;
  };
  function AppendableSink537(destination) {
    this.og_1 = destination;
  }
  protoOf(AppendableSink537).pg = function (value) {
    this.og_1.y4(value);
  };
  protoOf(AppendableSink537).hi = function (value, start, end) {
    var tmp = this.og_1;
    if (tmp instanceof StringBuilder)
      this.og_1.t6(value, start, end);
    else {
      characters.call(this, value, start, end);
    }
  };
  function checkTextLimit537(length, maxChars) {
    _init_properties_NumericOutput537_kt__qgqdrp();
    // Inline function 'kotlin.require' call
    if (!(maxChars == null || compare(maxChars, new Long(0, 0)) >= 0)) {
      var message = 'maxChars must be nonnegative';
      throw IllegalArgumentException_init_$Create$(toString_0(message));
    }
    if (!(maxChars == null) && compare(length, maxChars) > 0)
      throw ArithmeticException_init_$Create$('Output character limit exceeded');
  }
  function NumericSink537() {
  }
  var properties_initialized_NumericOutput537_kt_otjohf;
  function _init_properties_NumericOutput537_kt__qgqdrp() {
    if (!properties_initialized_NumericOutput537_kt_otjohf) {
      properties_initialized_NumericOutput537_kt_otjohf = true;
      ZERO_BLOCK537 = repeat('0', 256);
    }
  }
  function checkRange($this, size, offset, length) {
    if (offset < 0 || length < 0 || offset > (size - length | 0))
      throw NumberFormatException_init_$Create$('Bad character range');
  }
  function Companion_2() {
  }
  protoOf(Companion_2).ii = function (value, offset, length) {
    checkRange(this, charSequenceLength(value), offset, length);
    return new NumericText537(value, null, offset, length);
  };
  protoOf(Companion_2).re = function (value, offset, length, $super) {
    offset = offset === VOID ? 0 : offset;
    length = length === VOID ? charSequenceLength(value) : length;
    return $super === VOID ? this.ii(value, offset, length) : $super.ii.call(this, value, offset, length);
  };
  var Companion_instance_3;
  function Companion_getInstance_2() {
    return Companion_instance_3;
  }
  function NumericText537(text, characters, offset, length) {
    this.se_1 = text;
    this.te_1 = characters;
    this.ue_1 = offset;
    this.ve_1 = length;
  }
  protoOf(NumericText537).b = function (index) {
    var tmp0_safe_receiver = this.se_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : charSequenceGet(tmp0_safe_receiver, this.ue_1 + index | 0);
    var tmp;
    var tmp_0 = tmp1_elvis_lhs;
    if ((tmp_0 == null ? null : new Char(tmp_0)) == null) {
      tmp = ensureNotNull(this.te_1)[this.ue_1 + index | 0];
    } else {
      tmp = tmp1_elvis_lhs;
    }
    return tmp;
  };
  protoOf(NumericText537).jf = function (start, end) {
    // Inline function 'kotlin.text.buildString' call
    var capacity = end - start | 0;
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder_init_$Create$(capacity);
    var inductionVariable = start;
    if (inductionVariable < end)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this_0.y4(this.b(index));
      }
       while (inductionVariable < end);
    return this_0.toString();
  };
  function numericDigit537(character, radix) {
    var tmp;
    if (_Char___init__impl__6a9atx(48) <= character ? character <= _Char___init__impl__6a9atx(57) : false) {
      // Inline function 'kotlin.code' call
      var tmp_0 = Char__toInt_impl_vasixd(character);
      // Inline function 'kotlin.code' call
      var this_0 = _Char___init__impl__6a9atx(48);
      tmp = tmp_0 - Char__toInt_impl_vasixd(this_0) | 0;
    } else if (_Char___init__impl__6a9atx(97) <= character ? character <= _Char___init__impl__6a9atx(122) : false) {
      // Inline function 'kotlin.code' call
      var tmp_1 = Char__toInt_impl_vasixd(character);
      // Inline function 'kotlin.code' call
      var this_1 = _Char___init__impl__6a9atx(97);
      tmp = (tmp_1 - Char__toInt_impl_vasixd(this_1) | 0) + 10 | 0;
    } else if (_Char___init__impl__6a9atx(65) <= character ? character <= _Char___init__impl__6a9atx(90) : false) {
      // Inline function 'kotlin.code' call
      var tmp_2 = Char__toInt_impl_vasixd(character);
      // Inline function 'kotlin.code' call
      var this_2 = _Char___init__impl__6a9atx(65);
      tmp = (tmp_2 - Char__toInt_impl_vasixd(this_2) | 0) + 10 | 0;
    } else {
      return digitToIntOrNull(character, radix);
    }
    var ascii = tmp;
    // Inline function 'kotlin.takeIf' call
    var tmp_3;
    if (ascii < radix) {
      tmp_3 = ascii;
    } else {
      tmp_3 = null;
    }
    return tmp_3;
  }
  var static_init_called;
  function static_init() {
    if (static_init_called)
      return Unit_instance;
    static_init_called = true;
    RoundingMode_UP_instance = new RoundingMode('UP', 0);
    RoundingMode_DOWN_instance = new RoundingMode('DOWN', 1);
    RoundingMode_CEILING_instance = new RoundingMode('CEILING', 2);
    RoundingMode_FLOOR_instance = new RoundingMode('FLOOR', 3);
    RoundingMode_HALF_UP_instance = new RoundingMode('HALF_UP', 4);
    RoundingMode_HALF_DOWN_instance = new RoundingMode('HALF_DOWN', 5);
    RoundingMode_HALF_EVEN_instance = new RoundingMode('HALF_EVEN', 6);
    RoundingMode_UNNECESSARY_instance = new RoundingMode('UNNECESSARY', 7);
    if (Companion_instance_4 == null) {
      Companion_instance;
      new Companion_3();
    }
  }
  var RoundingMode_UP_instance;
  var RoundingMode_DOWN_instance;
  var RoundingMode_CEILING_instance;
  var RoundingMode_FLOOR_instance;
  var RoundingMode_HALF_UP_instance;
  var RoundingMode_HALF_DOWN_instance;
  var RoundingMode_HALF_EVEN_instance;
  var RoundingMode_UNNECESSARY_instance;
  function Companion_3() {
  }
  protoOf(Companion_3).ne = function (rm) {
    var tmp0_elvis_lhs = getOrNull(get_entries(), rm);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException_init_$Create$('Invalid rounding mode');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  };
  var Companion_instance_4;
  function Companion_getInstance_3() {
    return Companion_instance_4;
  }
  function values() {
    static_init();
    return [RoundingMode_UP_getInstance(), RoundingMode_DOWN_getInstance(), RoundingMode_CEILING_getInstance(), RoundingMode_FLOOR_getInstance(), RoundingMode_HALF_UP_getInstance(), RoundingMode_HALF_DOWN_getInstance(), RoundingMode_HALF_EVEN_getInstance(), RoundingMode_UNNECESSARY_getInstance()];
  }
  function get_entries() {
    static_init();
    if ($ENTRIES == null)
      $ENTRIES = enumEntries(values());
    return $ENTRIES;
  }
  var $ENTRIES;
  function RoundingMode(name, ordinal) {
    Enum.call(this, name, ordinal);
  }
  function RoundingMode_UP_getInstance() {
    static_init();
    return RoundingMode_UP_instance;
  }
  function RoundingMode_DOWN_getInstance() {
    static_init();
    return RoundingMode_DOWN_instance;
  }
  function RoundingMode_CEILING_getInstance() {
    static_init();
    return RoundingMode_CEILING_instance;
  }
  function RoundingMode_FLOOR_getInstance() {
    static_init();
    return RoundingMode_FLOOR_instance;
  }
  function RoundingMode_HALF_UP_getInstance() {
    static_init();
    return RoundingMode_HALF_UP_instance;
  }
  function RoundingMode_HALF_DOWN_getInstance() {
    static_init();
    return RoundingMode_HALF_DOWN_instance;
  }
  function RoundingMode_HALF_EVEN_getInstance() {
    static_init();
    return RoundingMode_HALF_EVEN_instance;
  }
  function RoundingMode_UNNECESSARY_getInstance() {
    static_init();
    return RoundingMode_UNNECESSARY_instance;
  }
  function plainStringTooLarge() {
    throw Error_init_$Create$('too large to fit in a String');
  }
  function emptyPowMagnitude() {
    arrayIndexFailure(0, 0);
  }
  function arrayIndexFailure(index, length) {
    throw new ArrayIndexOutOfBoundsException('Index ' + index + ' out of bounds for length ' + length);
  }
  function ArrayIndexOutOfBoundsException(message) {
    IndexOutOfBoundsException_init_$Init$(message, this);
    captureStack(this, ArrayIndexOutOfBoundsException);
  }
  //region block: init
  MagnitudeLimits_instance = new MagnitudeLimits();
  Companion_instance_3 = new Companion_2();
  Companion_instance_4 = new Companion_3();
  //endregion
  //region block: exports
  _.$_$ = _.$_$ || {};
  _.$_$.a = BigDecimal_init_$Create$_2;
  _.$_$.b = BigInteger_init_$Create$_1;
  _.$_$.c = BigDecimal;
  _.$_$.d = BigInteger;
  //endregion
  return _;
}(module.exports, require('./kotlin-kotlin-stdlib.js')));

//# sourceMappingURL=krogu-math.js.map
