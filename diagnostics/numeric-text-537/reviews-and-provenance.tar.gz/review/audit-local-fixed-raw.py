from pathlib import Path
import csv,json,hashlib,statistics as S,math
b=Path(__file__).resolve().parents[1];p=b/'local-final-2/results';stage=b/'local-artifacts-2';assert (p/'COMPLETE.txt').exists()
expected=set()
for size in [9,77,309,1234]:
 for reader in ['string','chars','sequence']:expected.add(f'integer/{size}/parse-{reader}')
 for radix in [3,10,16]:
  expected.add(f'integer/{size}/cold-format-{radix}');expected.add(f'integer/{size}/buffer-{radix}')
for name in ['small','wide','negative-scale','large-scale']:
 for reader in ['string','chars','sequence']:expected.add(f'decimal/{name}/parse-{reader}')
 for mode in ['cold-format','construction-format','cached-format-control','buffer-canonical','buffer-plain','buffer-engineering']:expected.add(f'decimal/{name}/{mode}')
assert len(expected)==72
for manifest in ['artifacts.sha256','runtime-libraries.sha256','controller-bindings.sha256']:
 q=p/manifest
 assert q.exists(),manifest
 for line in q.read_text().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(Path(n).read_bytes()).hexdigest()==h,n
for label in ['baseline','candidate']:
 for line in (p/f'{label}.sources.sha256').read_text().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256((stage/label/n).read_bytes()).hexdigest()==h,(label,n)
rows=[]
for label in ['baseline','candidate']:
 for fork in range(3):
  path=p/f'{label}-{fork}.csv';text=path.read_text();assert 'artifact_recheck=PASS cases=72 result_escape=PASS' in text
  data=list(csv.DictReader(l for l in text.splitlines() if l and not l.startswith('#')));assert len(data)==360
  assert {r['case'] for r in data}==expected
  assert len({(r['case'],r['sample']) for r in data})==360
  for name in expected:assert {int(r['sample']) for r in data if r['case']==name}==set(range(5))
  cmd=(p/f'{label}-{fork}.command.txt').read_text().splitlines()
  assert cmd[0]=='/Users/yoda/.sdkman/candidates/java/25.0.4-librca/bin/java'
  assert cmd[1:5]==['-Xms64m','-Xmx512m','-XX:+UseSerialGC','-XX:ActiveProcessorCount=1']
  assert cmd[-1]==('reverse' if fork==1 else 'forward')
  for r in data:
   assert r['variant']==label and int(r['fork'])==fork
   n=int(r['operations']);ns=float(r['ns_per_op']);alloc=float(r['allocated_bytes_per_op'])
   assert 1<=n<=2048 and n&(n-1)==0 and math.isfinite(ns) and ns>0 and math.isfinite(alloc) and alloc>=0
   assert abs(ns*n-round(ns*n))<1e-5 and abs(alloc*n-round(alloc*n))<1e-5
   rows.append(r)
assert len(rows)==2160
cases=[]
for name in sorted(expected):
 variants={}
 for label in ['baseline','candidate']:
  rr=[r for r in rows if r['variant']==label and r['case']==name]
  variants[label]={'ns':S.median(float(r['ns_per_op']) for r in rr),'bytes':S.median(float(r['allocated_bytes_per_op']) for r in rr),'perProcess':[{'fork':f,'ns':S.median(float(r['ns_per_op']) for r in rr if int(r['fork'])==f),'bytes':S.median(float(r['allocated_bytes_per_op']) for r in rr if int(r['fork'])==f)} for f in range(3)]}
 ratios=[variants['candidate']['perProcess'][f]['ns']/variants['baseline']['perProcess'][f]['ns'] for f in range(3)]
 cases.append({'case':name,'variants':variants,'candidateBaselineRatio':variants['candidate']['ns']/variants['baseline']['ns'],'perProcessRatios':ratios})
out={'status':'INDEPENDENT_RAW_BINDING_AND_2160_INVENTORY_PASS_INTERPRETATION_PENDING','host':'LOCALmacOSARM64;noexport/no remote numericalcampaign','handle':json.loads((b/'local-campaign-2-ledger.json').read_text())['handle'],'exit':0,'rows':2160,'cases':cases,'limitations':['same-host baseline/candidate; no JDKtimings inthiscampaign','72 deterministicfixtures; cold/cached/construction/buffer statesdistinct','sharedhost highload/swap;perprocess ratiosnotindependent15replicates','processenvelopepeakRSSnotperop retention']}
(b/'review/independent-local-fixed-raw-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print('2160 rows /72 cases /6 children;bindingsPASS')
for c in sorted(cases,key=lambda x:x['candidateBaselineRatio'],reverse=True)[:12]:
 print(c['case'],round(c['candidateBaselineRatio'],3),[round(r,3) for r in c['perProcessRatios']], 'B',round(c['variants']['baseline']['bytes'],2),round(c['variants']['candidate']['bytes'],2))
