# 537 source-only preparation

Status: no implementation, compilation, fixture, test, probe or benchmark execution. Main inspected at e95836f97e91433b49b005f9589ca6d359bfa2ac while 532 owns the heavy slot. Task/full feed is preserved in task-full.json. Priority remains completing 538 after integrated532+533 and composed review.

## Actual remaining work

The task's CharArray concatToString premise is stale. BigDecimal.kt:37–40 already delegates to DecimalText588. DecimalText588.kt:21 copies the selected array range into an owned reader; it no longer makes a whole String. Normal String construction still goes through BigDecimal.kt:1012: lexical scan + StringBuilder digits + digits.toString + BigInteger parser. String+MathContext deliberately keeps that route for proven-supported exact coefficient sizes, using588 only for longer input; preserve its error/range policy when unifying anything.

BigInteger.kt:1257 validates radix/sign/leading zeros then repeatedly immutable-multiplies/adds per digit. Its definitely-overflow preflight validates the entire remaining text before throwing; near the public support boundary ordinary incremental arithmetic may have different failure precedence. Error diagnostic grouping in invalidIntegerDigit is observable and already has a frozen public-JDK oracle.

BigDecimal.kt:820 caches canonical String after the first call. Plain/scientific/engineering layout still materializes the coefficient's complete digits, substrings and/or zero padding. Plain length preflight at838–857 and platform plainStringTooLarge must remain unchanged for existing APIs. BigInteger.kt:962 already directly formats power-of-two radices only under exact-working-class guards; generic radices repeatedly divide by one radix digit and preserve virtual fallback behavior.

## Focused design candidates (not implementation authority)

1. Define one private bounded input reader for immutable String, coherent CharSequence and CharArray offset/length. Keep existing range exceptions and full lexical grammar/scale/exponent rules. Add ASCII branches before the same Unicode digit conversion. CharArray no-copy use needs an explicit argument that unsupported concurrent mutation is not an atomic snapshot guarantee; a custom mutable CharSequence must describe coherent input for the entire call. Do not use its arbitrary toString implementation as parsing.
2. Group supported integer digits into radix powers fitting positive Int, with one private mutable magnitude builder rather than public per-digit wrappers. For B=2^30 and P<=Int.MAX_VALUE, cell*P+carry < B*P <2^61 if carry<P, giving an independent Long bound. Check normalized bit limits at the same observable boundary. Do NOT blindly validate every chunk before arithmetic: near overflow it could replace an old earlier ArithmeticException with a later bad-digit error. Prove a chunk cannot reach the boundary, otherwise use the existing incremental route for that boundary case. Keep error substring grouping exact.
3. Reuse588 lexical/context-prefix logic only after proof of constructor values, exact scale, endpoint rounding, exceptions and failure precedence. Keep unlimited huge-input support distinct from finite rounded-prefix support; no guessed input cap. Do not silently redirect public String/context semantics merely because the helper exists.
4. For ordinary integer generic formatting, consider radix^k division/chunk padding (decimal1e9 is one candidate), preserving existing power-of-two path and subtype callback fallback. Algorithm/crossover selection requires measurement; the current loop is an operation-count observation, not a measured root cause.
5. Add explicit streaming writers with clearly named canonical/plain/engineering mode, Appendable and supplied CharArray slice; decide API shape independently of task534 factories before editing. Compute length in Long before allocation/writing and reject opt-in maxChars/capacity early. Use bounded zero blocks and digit chunks. Buffer capacity failure should occur before modifying sentinel bytes; Appendable may partially write then propagate its original exception. Existing String methods/canonical cache and exceptions stay unchanged. Optional byte helpers are unnecessary unless a concrete uncovered contract needs them.
6. Respect future529 representation boundary: readers/writers consume private stored values or a documented ordinary snapshot, not an assumed exact-class storage tag and not overridable Number conversion. Do not touch worker532 multiplication kernel.

## Acceptance/test matrix

Retain current IntegerParserOracleTest/Jdk25IntegerParserResults, IntegerParserRange559Test, DecimalTextRounding588Test (5376 independent bounded rational cases), DecimalText588CallerJvmTest, PlainStringPreflight common/JVM tests, DecimalFormattingSubclassTest, existing parser/radix/text/format fixtures. Add meaningful slices across String/CharSequence/CharArray, offsets near Int endpoints, empty/sign-only, embedded sign, point/exponent boundaries, exponent overflow, scale endpoints, ASCII and Arabic/Devanagari/fullwidth digits and mixed valid/invalid Unicode. Compare coefficient+scale+canonical output and exact required error class/message/priority against existing frozen rows/public JDK calls only, never foreign bodies.

For output: zero cohorts and signs, scale0/positive/negative, -6 scientific cutoff, engineering multiples-of-three/zero branch, all integer radices including invalid-radix decimal fallback, buffer exact-fit/one-short/offset sentinels, zero/negative explicit limit, enormous-scale compact inputs rejected before huge padding, bounded partial writes and thrown Appendable identity. Repeated streaming writes must not retain mutable buffers or alter cached String identity. Include subclass callback traces for unchanged old methods and independently specify new API observations.

Cross-target JVM/JS/Wasm/macOS ARM64 gates after independent source review; fresh exact source/artifact bindings on integrated kernels. Existing public parser/format inputs, skips and range/error policies remain explicit, never widened by relabeling coverage.

## Measurement inventory and fairness

The16 existing527 IDs are integer/{9,77,309,1234}/{parse,format} and decimal/{small,wide,negative-scale,large-scale}/{parse,format}. All raw historical rows across platforms are copied (metadata only) to existing-527-parse-format-rows.json. Their workload expressions and IDs remain frozen. Historical host contention and loop overhead apply; decimal format is cached/reused by design and is NOT cold conversion.

Future additive cases should distinguish String, CharArray slice and coherent CharSequence parsing; ASCII/Unicode, leading-zero, late-invalid, ordinary/large fixed lengths; integer radix2/10/16/36 and threshold-adjacent group lengths. Keep setup/oracle preparation outside timings. For invalid input, exceptions are the measured operation and must be checked rather than swallowed into a null success.

Add cached-format (existing control), a separate cold-format ID with a bounded fresh-object pool prepared OUTSIDE each timed/allocated interval, streaming-to-reused Appendable and exact-size supplied buffer. For cold String output, each timed call consumes a previously unformatted object exactly once; fresh equivalent pools are prepared for every warmup/sample in both implementations. Pool construction/allocation is excluded from timing/ThreadMXBean counters, count/initial cache state and retained input pressure are matched. The pool size is bounded and sample count/coverage recorded; avoid a calibrated loop that formats the same object twice. A separately named construction-plus-format control may include wrapper construction, but cannot substitute for this cold case. Do not call cached toString as a proxy for formatting. The writer case includes output writes; avoid noisy subtraction to infer conversion-only time. A globally observable result ring/checksum and untimed exact result checks prevent DCE; sink/buffer reset policy must be identical. Fixed16 inputs for existing IDs and documented coverage for adaptive batch1.

Use fresh same-harness baseline/candidate from the same integrated production parent, differing only by537. Pin runtime/GC/CPU flags, source/JAR/probe SHA and actual class origin; alternating order,3 processes and configured warmup/sample IDs, minimum-one adaptive batches and bounded owned-process deadlines. Record wall/current-thread CPU/allocated bytes JVM; other targets report only actually available metrics. RSS is whole-process/runtime, not per-operation residency. Retain small-case per-ID regressions, adverse outcomes and host variability. Any throughput/allocation conclusion needs actual raw runs; none is claimed here.

## Execution ordering

No537 implementation begins during unfinished538 composition/runtime. After root scheduling: isolate worktree under project .codex-work/537, obtain scoped ownership and independently review source/API/proof; build correctness first; freeze actual source/JARs; then run the reviewed additive campaign in the shared serialized slot. No new /tmp probes, no scripts other than .main.kts, no foreign numeric implementation source.

## Frozen source evidence

The following SHA-256 pins make the file:line observations above reviewable even after532 integration changes line numbers. They credit current source structure only; already implemented588 semantics are accepted for537 only after the retained tests/contracts are verified on the final composed candidate.

| File | SHA-256 |
|---|---|
| `src/commonMain/kotlin/io/heapy/krogu/math/BigDecimal.kt` | `bd03fc2707b1219ca2e1ad747e9810285c3255fdc692d3941993fb37dd2b1afd` |
| `src/commonMain/kotlin/io/heapy/krogu/math/BigInteger.kt` | `5d820640e0e2df14197105aa5d20cb7c0b88a314a04350b338b4bc4bb69a473a` |
| `src/commonMain/kotlin/io/heapy/krogu/math/DecimalText588.kt` | `e70e9ff7488caab985056cbfcf349048301cd3700dbdcfff235d987846407d7c` |
| `src/commonMain/kotlin/io/heapy/krogu/math/TextExtensions.kt` | `e182d830cff8c096cc61fcbbbe79c1b09ace88dfacdc65df705e8404660ff977` |
| `src/commonMain/kotlin/io/heapy/krogu/math/PlainStringAllocation.kt` | `74ed828dfe1fc0e72a1bb81f0dfb572b8729b6394b91d68ceea4bb029b4a8fc1` |
| `benchmarks/src/commonMain/kotlin/bench/Workloads.kt` | `74dbf5a3894c0329acc7c6dc7003c25bb0e85d161e83972fc0e80748b14092a0` |
| `src/commonTest/kotlin/io/heapy/krogu/math/DecimalTextRounding588Test.kt` | `a08b163af94d09ec64b56793c04d06144740919821e85a674b15fb10a05fb3b4` |
| `src/commonTest/kotlin/io/heapy/krogu/math/IntegerParserOracleTest.kt` | `7160f7706bcee0c9da20b52212caccf7c31df9a2082e9beab024e562454c9743` |
| `src/jvmTest/kotlin/io/heapy/krogu/math/DecimalFormattingSubclassTest.kt` | `9144832e138ed5e7812c5c64caa574574ff282d77ebe4cca99b1ef1b36d3f4d2` |
| `benchmarks/results/2026-10-16-macos-arm64/summary.csv` | `e5605a522c83e7887dcbd098e1193eb4fea30c6936a66b6bba598db3cfa29d45` |

Machine-readable pins: source-evidence.json. Full task/feed snapshot: task-full.json. Existing parse/format raw metadata: existing-527-parse-format-rows.json.
